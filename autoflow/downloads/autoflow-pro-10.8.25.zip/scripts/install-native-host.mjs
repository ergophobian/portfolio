#!/usr/bin/env node
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import {
  AUTO_FLOW_NATIVE_HOST_NAME,
  buildExpectedNativeHostManifest,
  doctorNativeHostManifests,
  validateNativeHostExtensionId
} from "../src/core/native/native-host-manifests.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const HOST_NAME = AUTO_FLOW_NATIVE_HOST_NAME;
const WINDOWS_PACKAGE_DIR = "AutoFlowNativePackage";
const DEFAULT_TEMPLATE_PATH = path.join(root, "native-host/com.autoflow.agent.example.json");
const REQUIRED_HOST_FILES = [
  "auto-flow-native-host.mjs",
  "auto-flow-native-host-shim.cs",
  "broker.js",
  "host-core.js",
  "native-message.js"
];
const REQUIRED_PACKAGE_FILES = [
  "package.json",
  "src/core/agent/agent-bridge-protocol.js",
  "src/core/agent/browser-broker-transport.js",
  "src/core/agent/broker-health.js",
  "src/core/agent/browser-ref-import.js"
];
const execFileAsync = promisify(execFile);
const MAC_CHROME_MANIFEST_DIR = path.join(
  os.homedir(),
  "Library/Application Support/Google/Chrome/NativeMessagingHosts"
);
const MAC_AUTOFLOW_APP_SUPPORT_DIR = path.join(
  os.homedir(),
  "Library/Application Support/Auto Flow"
);
const MAC_NATIVE_HOST_LAUNCHER = path.join(MAC_AUTOFLOW_APP_SUPPORT_DIR, "native-host-launch.sh");
const MAC_NATIVE_HOST_RECEIPT = path.join(MAC_AUTOFLOW_APP_SUPPORT_DIR, "native-host-install.json");
const BRIDGE_PROTOCOL_VERSION = 1;
// Kept in sync with NATIVE_HOST_RESTART_REQUIREMENT in src/cli/index.js and
// src/mcp/autoflow-tools.js. Duplicated here because this script is bundled
// standalone into the native package and cannot import from src/.
const NATIVE_HOST_RESTART_REQUIREMENT =
  "Restart Chrome: fully quit the affected Chrome profile/window and reopen it so Chrome loads this native messaging manifest before you run `autoflow pair`.";

const args = parseArgs(process.argv.slice(2));
const platform = String(args.platform || process.platform);
const extensionIdCheck = validateNativeHostExtensionId(firstValue(args["extension-id"]) || process.env.AUTO_FLOW_EXTENSION_ID);
const extensionId = extensionIdCheck.value;
const hostScriptPath = path.resolve(String(firstValue(args["host-script-path"]) || await defaultHostScriptPath(platform, args)));
const hostPath = path.resolve(String(await defaultManifestHostPath(platform, args, hostScriptPath)));
const manifestDir = path.resolve(String(firstValue(args["manifest-dir"]) || defaultManifestDir(platform, hostPath)));
const manifestPath = path.join(manifestDir, `${HOST_NAME}.json`);
const receiptPath = path.resolve(String(firstValue(args["receipt-path"]) || MAC_NATIVE_HOST_RECEIPT));
const manifest = buildExpectedNativeHostManifest({ extensionId, hostPath });
const dryRun = isTrue(args["dry-run"]);
const fix = isTrue(args.fix) || isTrue(args.repair) || isTrue(args.write);
const reportMode = args.doctor || dryRun || fix;

if (reportMode) {
  if (fix && !dryRun && extensionIdCheck.ok && platform === "win32") {
    await prepareWindowsNativeHost({ hostPath, extensionId, args });
  }
  if (fix && !dryRun && extensionIdCheck.ok && platform === "darwin") {
    await prepareMacNativeHost({
      launcherPath: hostPath,
      hostScriptPath,
      nodePath: process.execPath
    });
  }
  const report = await installHostReport({
    extensionIdCheck,
    hostPath,
    hostScriptPath,
    manifestDir,
    manifestPath,
    manifest,
    dryRun,
    fix
  });
  if (fix && !dryRun && extensionIdCheck.ok) {
    await refreshInstallSideEffects({
      extensionId,
      hostPath,
      hostScriptPath,
      manifestPath
    });
  }
  console.log(JSON.stringify(report, null, 2));
  process.exit(report.ok ? 0 : 1);
}

if (!extensionIdCheck.ok) {
  printUsageAndExit();
}

if (platform === "win32" && !dryRun) {
  await prepareWindowsNativeHost({ hostPath, extensionId, args });
}
if (platform === "darwin" && !dryRun) {
  await prepareMacNativeHost({
    launcherPath: hostPath,
    hostScriptPath,
    nodePath: process.execPath
  });
}

const chmodEnabled = args.chmod !== "0" && args.chmod !== "false";
const hostExists = await checkHostExists(hostPath);
if (!hostExists.ok) {
  failInstall(hostExists.error || `${hostPath} is not a regular file`);
}

const hostDependencyDir = platform === "darwin" ? path.dirname(hostScriptPath) : path.dirname(hostPath);
const hostDependenciesCopied = await checkHostDependencies(hostDependencyDir);
if (!hostDependenciesCopied.ok) {
  const missing = Object.entries(hostDependenciesCopied.files)
    .filter(([, entry]) => !entry.ok)
    .map(([file]) => file);
  failInstall(`Native host dependency check failed in ${hostDependenciesCopied.directory}: ${missing.join(", ")}`);
}

if (platform !== "win32" && chmodEnabled && !dryRun) {
  await fs.chmod(hostPath, 0o755);
}

const hostExecutable = await checkHostExecutable(hostPath);
if (!hostExecutable.ok) {
  const hint = chmodEnabled && args["dry-run"]
    ? " Remove --dry-run to let the installer chmod the host executable."
    : "";
  failInstall(`${hostExecutable.error || "Native host path is not executable."}${hint}`);
}

if (dryRun) {
  console.log(JSON.stringify({
    ok: true,
    manifestPath,
    manifest,
    checks: {
      extensionIdValid: extensionIdCheck,
      hostExists,
      hostExecutable,
      hostDependenciesCopied,
      manifestTemplate: checkManifestTemplate(manifest)
    }
  }, null, 2));
  process.exit(0);
}

await fs.mkdir(manifestDir, { recursive: true });
await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
await writeInstallReceipt({
  receiptPath,
  extensionId,
  launcherPath: hostPath,
  hostScriptPath,
  manifestPath
});
if (platform === "win32") {
  await installWindowsRegistry(manifestPath, args);
}
console.log(`Installed ${HOST_NAME} native messaging manifest at ${manifestPath}`);
console.log(`Host path: ${hostPath}`);
if (platform === "darwin") {
  console.log(`Host script: ${hostScriptPath}`);
  console.log(`Node path: ${process.execPath}`);
}
console.log(`Allowed origin: chrome-extension://${extensionId}/`);
console.log(NATIVE_HOST_RESTART_REQUIREMENT);

async function defaultHostScriptPath(targetPlatform = platform, sourceArgs = args) {
  if (targetPlatform === "win32") {
    return path.join(windowsInstallRoot(), "native-host/auto-flow-native-host.exe");
  }
  const explicitHostPath = firstValue(sourceArgs["host-path"]);
  if (explicitHostPath && /\.mjs$/i.test(String(explicitHostPath))) {
    return path.resolve(String(explicitHostPath));
  }
  const distHostPath = path.join(root, "dist/native-host/auto-flow-native-host.mjs");
  try {
    await fs.access(distHostPath);
    return distHostPath;
  } catch {
    return path.join(root, "native-host/auto-flow-native-host.mjs");
  }
}

async function defaultManifestHostPath(targetPlatform = platform, sourceArgs = args, scriptPath = hostScriptPath) {
  if (targetPlatform === "darwin") {
    const explicitHostPath = firstValue(sourceArgs["host-path"]) ? String(firstValue(sourceArgs["host-path"])) : "";
    if (explicitHostPath && !/\.mjs$/i.test(explicitHostPath)) return explicitHostPath;
    return firstValue(sourceArgs["launcher-path"]) || MAC_NATIVE_HOST_LAUNCHER;
  }
  return firstValue(sourceArgs["host-path"]) || scriptPath;
}

async function installHostReport({ extensionIdCheck, hostPath, hostScriptPath, manifestDir, manifestPath, manifest, dryRun = false, fix = false }) {
  const nativeDoctor = await doctorNativeHostManifests({
    platform,
    homeDir: firstValue(args["home-dir"]),
    extensionId: extensionIdCheck.value,
    hostPath,
    manifestDirs: args["manifest-dir"],
    profileDirs: args["profile-dir"],
    allBrowserManifests: isTrue(args["all-browser-manifests"]),
    autoDetect: isTrue(args["auto-detect"]),
    fix,
    dryRun
  });
  const primaryManifest = nativeDoctor.manifests.find((entry) => entry.path === manifestPath) || nativeDoctor.manifests[0] || null;
  const legacy = args.doctor && !dryRun
    ? await doctorReport({ extensionIdCheck, hostPath, hostScriptPath, manifestDir, manifestPath, manifest })
    : {
        ok: extensionIdCheck.ok,
        hostName: HOST_NAME,
        platform,
        hostPath,
        hostScriptPath,
        manifestPath,
        receiptPath,
        expectedAllowedOrigins: manifest.allowed_origins,
        checks: {
          extensionIdValid: extensionIdCheck,
          manifestInstallPath: {
            ok: true,
            path: manifestPath,
            directory: manifestDir
          }
        }
      };
  const ok = legacy.ok === true && nativeDoctor.ok === true;
  return {
    ...legacy,
    ok,
    dryRun,
    fix,
    manifestPath: primaryManifest?.path || manifestPath,
    nativeHost: {
      hostName: HOST_NAME,
      launcherPath: hostPath,
      hostPath,
      hostScriptPath,
      nodePath: process.execPath,
      manifests: nativeDoctor.manifests
    },
    repairs: nativeDoctor.repairs,
    restartRequired: nativeDoctor.restartRequired,
    wouldRestart: nativeDoctor.wouldRestart
  };
}

async function refreshInstallSideEffects({ extensionId, hostPath, hostScriptPath, manifestPath }) {
  await writeInstallReceipt({
    receiptPath,
    extensionId,
    launcherPath: hostPath,
    hostScriptPath,
    manifestPath
  });
  if (platform === "win32") {
    await installWindowsRegistry(manifestPath, args);
  }
}

function windowsInstallRoot() {
  const appData = process.env.APPDATA || path.join(os.homedir(), "AppData/Roaming");
  return path.join(appData, WINDOWS_PACKAGE_DIR);
}

function defaultManifestDir(targetPlatform = platform, targetHostPath = hostPath) {
  if (targetPlatform === "win32") return path.dirname(targetHostPath);
  return MAC_CHROME_MANIFEST_DIR;
}

function parseArgs(argv) {
  const parsed = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (!arg.startsWith("--")) continue;
    const key = arg.slice(2);
    const next = argv[index + 1];
    if (next && !next.startsWith("--")) {
      setParsedArg(parsed, key, next);
      index += 1;
    } else {
      setParsedArg(parsed, key, true);
    }
  }
  return parsed;
}

function setParsedArg(parsed, key, value) {
  if (parsed[key] === undefined) {
    parsed[key] = value;
  } else if (Array.isArray(parsed[key])) {
    parsed[key].push(value);
  } else {
    parsed[key] = [parsed[key], value];
  }
}

function firstValue(value) {
  return Array.isArray(value) ? value[0] : value;
}

function isTrue(value) {
  return value === true || value === "1" || value === "true";
}

async function doctorReport({ extensionIdCheck, hostPath, hostScriptPath, manifestDir, manifestPath, manifest }) {
  const installedManifest = await readInstalledManifest(manifestPath);
  const checks = {
    extensionIdValid: extensionIdCheck,
    hostExists: await checkHostExists(hostPath),
    hostExecutable: await checkHostExecutable(hostPath),
    hostScriptExists: platform === "darwin"
      ? await checkHostExists(hostScriptPath)
      : { ok: true, skipped: true, platform },
    hostDependenciesCopied: await checkHostDependencies(platform === "darwin" ? path.dirname(hostScriptPath) : path.dirname(hostPath)),
    packageDependenciesCopied: await checkPackageDependencies(path.resolve(path.dirname(platform === "darwin" ? hostScriptPath : hostPath), "..")),
    manifestTemplate: checkManifestTemplate(manifest),
    manifestNativeMessaging: await checkExtensionManifestNativeMessaging(),
    manifestAllowedOrigin: checkManifestAllowedOrigin(manifest, extensionIdCheck),
    installedManifestExists: checkInstalledManifestExists(installedManifest, manifestPath),
    installedManifestValidJson: checkInstalledManifestValidJson(installedManifest, manifestPath),
    installedManifestName: checkInstalledManifestField(installedManifest, "name", HOST_NAME),
    installedManifestType: checkInstalledManifestField(installedManifest, "type", "stdio"),
    installedManifestPath: checkInstalledManifestField(installedManifest, "path", hostPath),
    installedManifestAllowedOrigin: checkManifestAllowedOrigin(installedManifest.value || {}, extensionIdCheck),
    manifestInstallPath: {
      ok: path.basename(manifestPath) === `${HOST_NAME}.json`,
      path: manifestPath,
      directory: manifestDir
    },
    macLauncher: platform === "darwin"
      ? await checkMacLauncher(hostPath, hostScriptPath)
      : { ok: true, skipped: true, platform },
    macLauncherSelfTest: platform === "darwin"
      ? await checkMacLauncherSelfTest(hostPath)
      : { ok: true, skipped: true, platform },
    brokerSocket: await checkBrokerSocket({ required: args["require-socket"] === true || args["require-socket"] === "1" || args["require-socket"] === "true" }),
    windowsRegistry: platform === "win32"
      ? await checkWindowsRegistry(manifestPath)
      : { ok: true, skipped: true, platform },
    windowsShim: platform === "win32"
      ? await checkWindowsShim(path.dirname(hostPath))
      : { ok: true, skipped: true, platform },
    socketModeExpectation: {
      ok: true,
      expected: platform === "win32" ? "named-pipe-user-scope" : "0600",
      detail: platform === "win32"
        ? "native-host/broker.js creates a per-Windows-user named pipe for the local CLI/MCP broker"
        : "native-host/broker.js creates the local CLI/MCP broker socket with owner read/write permissions only"
    }
  };
  return {
    ok: Object.values(checks).every((check) => check.ok),
    scope: "native-host-manifest",
    checksDescription: "Verifies the native messaging manifest, host launcher/executable, allowed origin, and (per platform) the Windows registry only. Does NOT check the live Auto Flow bridge, pairing, auth, or Flow project.",
    seeAlso: "Run `autoflow doctor` to check the live bridge (pairing, auth, active project, queue).",
    hostName: HOST_NAME,
    platform,
    hostPath,
    hostScriptPath,
    manifestPath,
    receiptPath,
    expectedAllowedOrigins: manifest.allowed_origins,
    installedManifest: installedManifest.value || null,
    checks
  };
}

async function checkHostExists(hostPath) {
  try {
    const stats = await fs.stat(hostPath);
    return {
      ok: stats.isFile(),
      code: stats.isFile() ? "OK" : "HOST_NOT_FILE",
      path: hostPath,
      executable: Boolean(stats.mode & 0o111),
      mode: fileMode(stats.mode),
      error: stats.isFile() ? undefined : `${hostPath} is not a regular file`
    };
  } catch (error) {
    return {
      ok: false,
      code: "HOST_NOT_FOUND",
      path: hostPath,
      error: error?.message || String(error)
    };
  }
}

async function checkHostExecutable(hostPath) {
  const result = await checkHostExists(hostPath);
  if (!result.ok) return result;
  if (platform === "win32") {
    if (path.extname(hostPath).toLowerCase() !== ".exe") {
      return {
        ...result,
        ok: false,
        code: "HOST_NOT_WINDOWS_EXE",
        error: `${hostPath} must be a Windows .exe native host`
      };
    }
    return {
      ...result,
      code: "OK"
    };
  }
  if (!result.executable) {
    return {
      ...result,
      ok: false,
      code: "HOST_NOT_EXECUTABLE",
      error: `${hostPath} is not executable`
    };
  }
  return {
    ...result,
    code: "OK"
  };
}

async function checkHostDependencies(hostDir) {
  const files = {};
  for (const file of REQUIRED_HOST_FILES) {
    const filePath = path.join(hostDir, file);
    try {
      const stats = await fs.stat(filePath);
      files[file] = { ok: stats.isFile(), mode: fileMode(stats.mode) };
    } catch (error) {
      files[file] = { ok: false, error: error?.message || String(error) };
    }
  }
  return {
    ok: Object.values(files).every((entry) => entry.ok),
    directory: hostDir,
    files
  };
}

async function checkPackageDependencies(packageRoot) {
  const files = {};
  for (const file of REQUIRED_PACKAGE_FILES) {
    const filePath = path.join(packageRoot, file);
    try {
      const stats = await fs.stat(filePath);
      files[file] = { ok: stats.isFile(), mode: fileMode(stats.mode) };
    } catch (error) {
      files[file] = { ok: false, error: error?.message || String(error) };
    }
  }
  return {
    ok: Object.values(files).every((entry) => entry.ok),
    directory: packageRoot,
    files
  };
}

function checkManifestTemplate(manifest) {
  const ok = manifest.name === HOST_NAME
    && manifest.type === "stdio"
    && path.isAbsolute(manifest.path)
    && Array.isArray(manifest.allowed_origins)
    && manifest.allowed_origins.length === 1
    && /^chrome-extension:\/\/[a-p]{32}\/$/i.test(manifest.allowed_origins[0]);
  return {
    ok,
    name: manifest.name,
    type: manifest.type,
    pathIsAbsolute: path.isAbsolute(manifest.path),
    allowedOrigins: manifest.allowed_origins
  };
}

function checkManifestAllowedOrigin(manifest, extensionIdCheck) {
  const expected = extensionIdCheck.ok ? `chrome-extension://${extensionIdCheck.value}/` : "";
  const allowedOrigins = Array.isArray(manifest.allowed_origins) ? manifest.allowed_origins : [];
  const ok = Boolean(expected) && allowedOrigins.length === 1 && allowedOrigins[0] === expected;
  return {
    ok,
    code: ok ? "OK" : "EXTENSION_ID_MISMATCH",
    expected,
    allowedOrigins
  };
}

async function readInstalledManifest(filePath) {
  try {
    const raw = await fs.readFile(filePath, "utf8");
    try {
      return {
        ok: true,
        exists: true,
        validJson: true,
        path: filePath,
        value: JSON.parse(raw)
      };
    } catch (error) {
      return {
        ok: false,
        exists: true,
        validJson: false,
        path: filePath,
        error: error?.message || String(error)
      };
    }
  } catch (error) {
    return {
      ok: false,
      exists: false,
      validJson: false,
      path: filePath,
      error: error?.message || String(error)
    };
  }
}

function checkInstalledManifestExists(installedManifest, filePath) {
  return {
    ok: installedManifest.exists === true,
    code: installedManifest.exists === true ? "OK" : "INSTALLED_MANIFEST_MISSING",
    path: filePath,
    error: installedManifest.exists === true ? undefined : installedManifest.error
  };
}

function checkInstalledManifestValidJson(installedManifest, filePath) {
  return {
    ok: installedManifest.validJson === true,
    code: installedManifest.validJson === true ? "OK" : "INSTALLED_MANIFEST_INVALID_JSON",
    path: filePath,
    error: installedManifest.validJson === true ? undefined : installedManifest.error
  };
}

function checkInstalledManifestField(installedManifest, field, expected) {
  const actual = installedManifest.value?.[field];
  const ok = installedManifest.validJson === true && actual === expected;
  return {
    ok,
    code: ok ? "OK" : `INSTALLED_MANIFEST_${field.toUpperCase()}_MISMATCH`,
    field,
    expected,
    actual
  };
}

async function checkExtensionManifestNativeMessaging() {
  const manifestPath = path.join(root, "manifest.json");
  try {
    const extensionManifest = JSON.parse(await fs.readFile(manifestPath, "utf8"));
    return {
      ok: Array.isArray(extensionManifest.permissions) && extensionManifest.permissions.includes("nativeMessaging"),
      path: manifestPath
    };
  } catch (error) {
    if (error?.code === "ENOENT") {
      return {
        ok: true,
        skipped: true,
        code: "EXTENSION_MANIFEST_NOT_PACKAGED",
        path: manifestPath,
        detail: "npm CLI/MCP packages do not include the unpacked Chrome extension manifest."
      };
    }
    return {
      ok: false,
      path: manifestPath,
      error: error?.message || String(error)
    };
  }
}

async function prepareMacNativeHost({ launcherPath, hostScriptPath, nodePath }) {
  const script = await checkHostExists(hostScriptPath);
  if (!script.ok) failInstall(script.error || `Native host script missing: ${hostScriptPath}`);
  const dependencies = await checkHostDependencies(path.dirname(hostScriptPath));
  if (!dependencies.ok) {
    const missing = Object.entries(dependencies.files)
      .filter(([, entry]) => !entry.ok)
      .map(([file]) => file);
    failInstall(`Native host dependency check failed in ${dependencies.directory}: ${missing.join(", ")}`);
  }
  await fs.mkdir(path.dirname(launcherPath), { recursive: true });
  const launcher = [
    "#!/bin/sh",
    "set -eu",
    `NODE_BIN=${shellSingleQuote(nodePath)}`,
    `HOST_SCRIPT=${shellSingleQuote(hostScriptPath)}`,
    "if [ \"${1:-}\" = \"--self-test\" ] || [ \"${1:-}\" = \"self-test\" ]; then",
    "  exec \"$NODE_BIN\" \"$HOST_SCRIPT\" --self-test",
    "fi",
    "exec \"$NODE_BIN\" \"$HOST_SCRIPT\" \"$@\"",
    ""
  ].join("\n");
  await fs.writeFile(launcherPath, launcher, { mode: 0o755 });
  await fs.chmod(launcherPath, 0o755);
}

async function writeInstallReceipt({ receiptPath, extensionId, launcherPath, hostScriptPath, manifestPath }) {
  const packageJson = await readPackageJson();
  const brokerPath = path.join(path.dirname(hostScriptPath), "broker.js");
  const receipt = {
    installedAt: new Date().toISOString(),
    extensionId,
    packageVersion: String(packageJson.version || ""),
    nativeHostVersion: String(packageJson.version || ""),
    bridgeProtocolVersion: BRIDGE_PROTOCOL_VERSION,
    nodePath: process.execPath,
    launcherPath,
    hostScriptPath,
    manifestPath,
    packageRoot: root,
    launcherSha256: await sha256File(launcherPath),
    hostScriptSha256: await sha256File(hostScriptPath),
    brokerSha256: await sha256File(brokerPath)
  };
  await fs.mkdir(path.dirname(receiptPath), { recursive: true });
  const tmpPath = `${receiptPath}.${process.pid}.tmp`;
  await fs.writeFile(tmpPath, `${JSON.stringify(receipt, null, 2)}\n`, { mode: 0o600 });
  await fs.rename(tmpPath, receiptPath);
  await fs.chmod(receiptPath, 0o600).catch(() => {});
}

async function readPackageJson() {
  try {
    return JSON.parse(await fs.readFile(path.join(root, "package.json"), "utf8"));
  } catch {
    return {};
  }
}

async function sha256File(filePath) {
  const bytes = await fs.readFile(filePath);
  return createHash("sha256").update(bytes).digest("hex");
}

async function checkMacLauncher(launcherPath, expectedHostScriptPath) {
  const exists = await checkHostExists(launcherPath);
  if (!exists.ok) {
    return {
      ...exists,
      code: "MAC_LAUNCHER_MISSING"
    };
  }
  if (!exists.executable) {
    return {
      ...exists,
      ok: false,
      code: "MAC_LAUNCHER_NOT_EXECUTABLE",
      error: `${launcherPath} is not executable`
    };
  }
  const content = await fs.readFile(launcherPath, "utf8").catch(() => "");
  const expectedNode = process.execPath;
  const hasExpectedNode = content.includes(expectedNode);
  const hasExpectedHostScript = content.includes(expectedHostScriptPath);
  return {
    ok: hasExpectedNode && hasExpectedHostScript,
    code: hasExpectedNode && hasExpectedHostScript ? "OK" : "MAC_LAUNCHER_STALE",
    path: launcherPath,
    expectedNode,
    expectedHostScriptPath,
    hasExpectedNode,
    hasExpectedHostScript,
    executable: exists.executable,
    mode: exists.mode,
    error: hasExpectedNode && hasExpectedHostScript ? undefined : "launcher points at a stale Node path or host script"
  };
}

async function checkMacLauncherSelfTest(launcherPath) {
  const exists = await checkHostExecutable(launcherPath);
  if (!exists.ok) {
    return {
      ok: false,
      code: "MAC_LAUNCHER_SELF_TEST_SKIPPED",
      path: launcherPath,
      error: exists.error || "launcher is not executable"
    };
  }
  try {
    const { stdout } = await execFileAsync("env", [
      "-i",
      `HOME=${os.homedir()}`,
      "PATH=/usr/bin:/bin",
      launcherPath,
      "--self-test"
    ], { timeout: 5000 });
    const parsed = JSON.parse(String(stdout || "{}"));
    return {
      ok: parsed.ok === true,
      code: parsed.ok === true ? "OK" : "MAC_LAUNCHER_SELF_TEST_FAILED",
      path: launcherPath,
      result: parsed
    };
  } catch (error) {
    return {
      ok: false,
      code: "MAC_LAUNCHER_SELF_TEST_FAILED",
      path: launcherPath,
      error: error?.message || String(error)
    };
  }
}

async function checkBrokerSocket(options = {}) {
  const socketPath = process.env.AUTOFLOW_BRIDGE_SOCKET
    || process.env.AUTOFLOW_BROKER_SOCKET
    || (platform === "win32" ? "" : path.join(os.homedir(), "Library/Application Support/Auto Flow/runtime/agent-bridge.sock"));
  if (!socketPath) return { ok: true, skipped: true, platform };
  const exists = await checkHostExists(socketPath);
  const present = exists.ok || exists.code === "HOST_NOT_FILE";
  return {
    ok: options.required === true ? present : true,
    code: present ? "OK" : "BROKER_SOCKET_MISSING",
    path: socketPath,
    present,
    required: options.required === true,
    detail: present ? "broker socket exists" : "broker socket is not present"
  };
}

async function prepareWindowsNativeHost({ hostPath, extensionId, args }) {
  await stageWindowsNativeHostPackage({ hostPath });
  const hostDir = path.dirname(hostPath);
  const shimSource = path.join(hostDir, "auto-flow-native-host-shim.cs");
  const scriptPath = path.join(hostDir, "auto-flow-native-host.mjs");
  const socketPath = windowsBrokerPipePath(args);
  await fs.mkdir(hostDir, { recursive: true });
  await writeWindowsConfig({
    hostDir,
    extensionId,
    scriptPath,
    socketPath,
    debugLogPath: String(args["debug-log"] || "")
  });

  const existing = await checkHostExists(hostPath);
  const source = await checkHostExists(shimSource);
  if (!source.ok) failInstall(`Windows native host shim source missing: ${shimSource}`);

  const needsCompile = args["force-compile"] === true || !existing.ok || await isSourceNewer(shimSource, hostPath);
  if (!needsCompile) return;

  const cscPath = await findWindowsCsc(args);
  if (!cscPath) {
    failInstall("Could not find csc.exe to compile the Windows native host shim. Install .NET Framework developer tools or pass --csc-path.");
  }
  try {
    await execFileAsync(cscPath, ["/nologo", "/target:exe", `/out:${hostPath}`, shimSource], {
      windowsHide: true
    });
  } catch (error) {
    if (existing.ok && args["force-compile"] !== true && !isForcedTrue(args["force-compile"]) && isWindowsCompileLock(error)) {
      console.warn("Existing Windows native host exe is locked; staged JS/protocol files were updated and Chrome will use them after the host restarts.");
      return;
    }
    throw error;
  }
}

function isWindowsCompileLock(error) {
  const text = `${error?.stdout || ""}\n${error?.stderr || ""}\n${error?.message || ""}`;
  return /process cannot access the file because it is being used by another process/i.test(text)
    || /CS0016/i.test(text);
}

function isForcedTrue(value) {
  return value === true || value === "1" || value === "true";
}

function shellSingleQuote(value = "") {
  return `'${String(value).replaceAll("'", "'\"'\"'")}'`;
}

async function stageWindowsNativeHostPackage({ hostPath }) {
  const installRoot = path.resolve(path.dirname(hostPath), "..");
  const hostDir = path.join(installRoot, "native-host");

  await fs.mkdir(hostDir, { recursive: true });
  for (const file of REQUIRED_HOST_FILES) {
    await copyIfDifferent(path.join(root, "native-host", file), path.join(hostDir, file));
  }

  for (const file of REQUIRED_PACKAGE_FILES) {
    await copyIfDifferent(path.join(root, file), path.join(installRoot, file));
  }
}

async function copyIfDifferent(sourcePath, targetPath) {
  const source = path.resolve(sourcePath);
  const target = path.resolve(targetPath);
  if (source === target) return;
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.copyFile(source, target);
}

async function writeWindowsConfig({ hostDir, extensionId, scriptPath, socketPath, debugLogPath }) {
  const configPath = path.join(hostDir, "auto-flow-native-host.windows.json");
  const config = {
    nodePath: process.execPath,
    scriptPath,
    extensionId,
    socketPath,
    ...(debugLogPath ? { debugLogPath } : {})
  };
  await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`);
}

async function isSourceNewer(sourcePath, targetPath) {
  const [source, target] = await Promise.all([
    fs.stat(sourcePath).catch(() => null),
    fs.stat(targetPath).catch(() => null)
  ]);
  if (!source || !target) return true;
  return source.mtimeMs > target.mtimeMs;
}

async function findWindowsCsc(args = {}) {
  if (args["csc-path"]) return path.resolve(String(args["csc-path"]));
  const candidates = [
    path.join(process.env.WINDIR || "C:\\Windows", "Microsoft.NET/Framework64/v4.0.30319/csc.exe"),
    path.join(process.env.WINDIR || "C:\\Windows", "Microsoft.NET/Framework/v4.0.30319/csc.exe")
  ];
  for (const candidate of candidates) {
    try {
      const stats = await fs.stat(candidate);
      if (stats.isFile()) return candidate;
    } catch {}
  }
  return "";
}

async function installWindowsRegistry(manifestPath, args = {}) {
  if (args["skip-registry"] === true || args["skip-registry"] === "1" || args["skip-registry"] === "true") return;
  await execFileAsync("reg.exe", [
    "ADD",
    `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`,
    "/ve",
    "/t",
    "REG_SZ",
    "/d",
    manifestPath,
    "/f"
  ], { windowsHide: true });
}

async function checkWindowsRegistry(manifestPath) {
  if (platform !== "win32") return { ok: true, skipped: true, platform };
  try {
    const { stdout } = await execFileAsync("reg.exe", [
      "QUERY",
      `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`,
      "/ve"
    ], { windowsHide: true });
    return {
      ok: stdout.includes(manifestPath),
      key: `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`,
      expectedManifestPath: manifestPath,
      stdout
    };
  } catch (error) {
    return {
      ok: false,
      key: `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`,
      expectedManifestPath: manifestPath,
      error: error?.message || String(error)
    };
  }
}

async function checkWindowsShim(hostDir) {
  const configPath = path.join(hostDir, "auto-flow-native-host.windows.json");
  const sourcePath = path.join(hostDir, "auto-flow-native-host-shim.cs");
  const [config, source] = await Promise.all([
    checkHostExists(configPath),
    checkHostExists(sourcePath)
  ]);
  return {
    ok: config.ok && source.ok,
    config,
    source
  };
}

function windowsBrokerPipePath(args = {}) {
  if (args["bridge-socket"]) return String(args["bridge-socket"]);
  const rawUser = process.env.USERNAME || process.env.USER || os.userInfo?.().username || "user";
  const suffix = String(rawUser)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    || "user";
  return `\\\\.\\pipe\\auto-flow-agent-bridge-${suffix}`;
}

function fileMode(mode) {
  return (mode & 0o777).toString(8).padStart(4, "0");
}

function failInstall(message) {
  console.error(message);
  process.exit(1);
}

function printUsageAndExit() {
  console.error("Usage: npm run agent:install-native-host -- --extension-id <32-char-extension-id>");
  console.error(`Default install location: ${manifestPath}`);
  console.error("Optional: --host-path <absolute-path> --manifest-dir <absolute-dir> --profile-dir <profile> --all-browser-manifests --fix --dry-run --doctor");
  process.exit(1);
}
