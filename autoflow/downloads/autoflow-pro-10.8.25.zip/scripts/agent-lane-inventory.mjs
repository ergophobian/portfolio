#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

export const DEFAULT_PORT = "9222";
export const FLOW_PROJECT_RE = /https:\/\/labs\.google(?:\.com)?\/fx\/(?:[^/?#]+\/)?tools\/flow\/project\/([0-9a-f-]{36})/i;
const EXTENSION_RE = /^chrome-extension:\/\/([a-p]{32})\//i;

export function parseArgs(argv = []) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = String(argv[index] || "");
    if (!token.startsWith("--")) continue;
    const [rawKey, inlineValue] = token.slice(2).split(/=(.*)/s, 2);
    const key = rawKey.replace(/-([a-z])/g, (_, char) => char.toUpperCase());
    if (["json", "help"].includes(key)) {
      options[key] = true;
      continue;
    }
    const next = argv[index + 1];
    if (inlineValue !== undefined) {
      options[key] = inlineValue;
    } else if (next && !String(next).startsWith("--")) {
      options[key] = next;
      index += 1;
    } else {
      options[key] = true;
    }
  }
  return options;
}

export function summarizeCdpTargets(targets = [], options = {}) {
  const port = normalizeCdpPort(options.port || DEFAULT_PORT);
  const requestedExtensionId = String(options.extensionId || "").trim();
  const flowProjects = findFlowProjects(targets);
  const brokenFlowProjects = flowProjects.filter(isBrokenFlowProject);
  const duplicateFlowProjects = duplicateFlowProjectGroups(flowProjects);
  const duplicateProjectIds = duplicateFlowProjects.map((group) => group.projectId);
  const extensionCandidates = findExtensionCandidates(targets);
  const selectedExtension = selectExtensionCandidate(extensionCandidates, requestedExtensionId);
  const selectedExtensionId = selectedExtension?.id || requestedExtensionId || "";
  const blockers = [];

  if (requestedExtensionId && !selectedExtension) {
    blockers.push(`requested extension ${requestedExtensionId} is not mounted`);
  }
  if (!selectedExtensionId) {
    blockers.push("no Auto Flow extension candidate detected");
  }
  if (!flowProjects.length) {
    blockers.push("no Flow project tab detected");
  }
  if (brokenFlowProjects.length) {
    blockers.push(`Flow project tab appears broken: ${brokenFlowProjects.map((project) => project.targetId || project.projectId).join(", ")}`);
  }
  if (duplicateProjectIds.length) {
    blockers.push(`duplicate Flow project tabs detected for: ${duplicateProjectIds.join(", ")}`);
  }
  if (flowProjects.length > 1) {
    blockers.push("multiple Flow project tabs detected; pass an explicit project/tab target before live submit");
  }

  const flowProject = flowProjects[0] || null;
  const chromeTabId = flowProject ? numericChromeTabId(flowProject) : null;
  const needsChromeTabId = Boolean(flowProjects.length === 1 && flowProject && chromeTabId === null);
  const liveSubmitBlockers = blockers.slice();
  if (needsChromeTabId) {
    liveSubmitBlockers.push("CDP target id is not a Chrome tab id; get activeTabId from autoflow status before live submit");
  }

  const liveSubmitSafe = Boolean(selectedExtensionId && flowProjects.length === 1 && !liveSubmitBlockers.length && chromeTabId !== null);
  const verifyCommand = selectedExtensionId
    ? `node scripts/verify-agent-mode.mjs --port ${shellEscape(port)} --extension-id ${shellEscape(selectedExtensionId)}`
    : "";
  const reconcileCommand = "node bin/autoflow.js agent reconcile --project current --json";
  const statusCommand = "node bin/autoflow.js status --json";

  return {
    ok: !blockers.length,
    port,
    targetCount: targets.length,
    extensionId: selectedExtensionId,
    extension: selectedExtension || null,
    extensionCandidates,
    flowProject,
    flowProjects,
    brokenFlowProjects,
    duplicateFlowProjects,
    duplicateProjectIds,
    recommended: {
      liveSubmitSafe,
      blockers,
      statusCommand,
      reconcileCommand,
      verifyCommand,
      needsChromeTabId,
      liveTarget: flowProject ? {
        projectId: flowProject.projectId || "",
        targetId: flowProject.targetId || flowProject.id || "",
        tabId: chromeTabId
      } : null,
      blockers: liveSubmitBlockers,
      liveSubmitRule: liveSubmitSafe
        ? "single Flow project tab and Chrome tab id detected; live submit can proceed one at a time"
        : needsChromeTabId
          ? "do not run live submit until the Chrome tab id is known from the extension runtime"
          : "do not run live submit until blockers are resolved"
    }
  };
}

export async function fetchCdpTargets(port = DEFAULT_PORT, options = {}) {
  const safePort = normalizeCdpPort(port);
  const timeoutMs = positiveInteger(options.timeoutMs, 5000);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`http://127.0.0.1:${safePort}/json/list`, {
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`CDP /json/list returned HTTP ${response.status}`);
    }
    const targets = await response.json();
    return Array.isArray(targets) ? targets : [];
  } finally {
    clearTimeout(timer);
  }
}

function findFlowProjects(targets = []) {
  return targets
    .filter((target) => target?.type === "page")
    .map(flowProjectFromTarget)
    .filter(Boolean);
}

function flowProjectFromTarget(target = {}) {
  const url = String(target.url || "");
  const title = String(target.title || "");
  const match = matchFlowProject(url) || matchFlowProject(title);
  if (!match) return null;
  return {
    targetId: String(target.id || ""),
    title,
    url,
    projectId: match[1] || "",
    tabId: numericChromeTabId(target),
    webSocketDebuggerUrl: String(target.webSocketDebuggerUrl || "")
  };
}

function numericChromeTabId(value = {}) {
  const candidate = value.chromeTabId ?? value.tabId ?? value.chrome?.tabId;
  const parsed = Number.parseInt(candidate, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function matchFlowProject(value = "") {
  return String(value || "").match(FLOW_PROJECT_RE);
}

function findExtensionCandidates(targets = []) {
  const byId = new Map();
  for (const target of targets) {
    const url = String(target?.url || "");
    const match = url.match(EXTENSION_RE);
    if (!match) continue;
    const id = match[1];
    const entry = byId.get(id) || {
      id,
      score: 0,
      targets: [],
      serviceWorkers: [],
      sidepanels: []
    };
    const compact = {
      targetId: String(target.id || ""),
      type: String(target.type || ""),
      title: String(target.title || ""),
      url,
      webSocketDebuggerUrl: String(target.webSocketDebuggerUrl || "")
    };
    entry.targets.push(compact);
    if (target.type === "service_worker") {
      entry.serviceWorkers.push(compact);
      if (url.includes("/src/background/service-worker.js")) entry.score += 10;
      else entry.score += 2;
    }
    if (target.type === "page" && url.includes("/src/sidepanel/index.html")) {
      entry.sidepanels.push(compact);
      entry.score += 8;
    }
    if (/auto flow/i.test(String(target.title || ""))) entry.score += 4;
    byId.set(id, entry);
  }
  return [...byId.values()].sort((left, right) => {
    if (right.score !== left.score) return right.score - left.score;
    return left.id.localeCompare(right.id);
  });
}

function selectExtensionCandidate(candidates = [], requestedExtensionId = "") {
  if (requestedExtensionId) {
    return candidates.find((candidate) => candidate.id === requestedExtensionId) || null;
  }
  return candidates[0] || null;
}

function isBrokenFlowProject(project = {}) {
  const title = String(project.title || "").toLowerCase();
  const url = String(project.url || "").toLowerCase();
  return title.includes("application error")
    || title.includes("client-side exception")
    || url.includes("chrome-error://");
}

function duplicateFlowProjectGroups(flowProjects = []) {
  const byProjectId = new Map();
  for (const project of flowProjects) {
    if (!project.projectId) continue;
    const group = byProjectId.get(project.projectId) || [];
    group.push(project);
    byProjectId.set(project.projectId, group);
  }
  return [...byProjectId.entries()]
    .filter(([, projects]) => projects.length > 1)
    .map(([projectId, projects]) => ({
      projectId,
      targetIds: projects.map((project) => project.targetId).filter(Boolean)
    }))
    .sort((left, right) => left.projectId.localeCompare(right.projectId));
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function normalizeCdpPort(value = DEFAULT_PORT) {
  const port = String(value || DEFAULT_PORT).trim();
  if (!/^[0-9]+$/.test(port)) {
    throw new Error(`invalid CDP port: ${port}`);
  }
  const parsed = Number.parseInt(port, 10);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`invalid CDP port: ${port}`);
  }
  return String(parsed);
}

function shellEscape(value = "") {
  const text = String(value);
  return /^[A-Za-z0-9._:/=-]+$/.test(text) ? text : `'${text.replaceAll("'", "'\\''")}'`;
}

function formatText(summary = {}) {
  const lines = [];
  lines.push(`Auto Flow Agent lane inventory`);
  lines.push(`CDP: 127.0.0.1:${summary.port}`);
  lines.push(`Targets: ${summary.targetCount}`);
  lines.push(`Extension: ${summary.extensionId || "not detected"}`);
  lines.push(`Flow projects: ${summary.flowProjects?.length || 0}`);
  for (const project of summary.flowProjects || []) {
    lines.push(`- ${project.projectId} ${project.title || ""}`.trim());
    lines.push(`  ${project.url}`);
  }
  if (summary.recommended?.blockers?.length) {
    lines.push(`Blockers:`);
    for (const blocker of summary.recommended.blockers) lines.push(`- ${blocker}`);
  }
  if (summary.duplicateFlowProjects?.length) {
    lines.push(`Duplicate Flow tabs:`);
    for (const group of summary.duplicateFlowProjects) {
      lines.push(`- ${group.projectId}: ${group.targetIds.join(", ")}`);
    }
  }
  lines.push(`Live submit safe: ${summary.recommended?.liveSubmitSafe ? "yes" : "no"}`);
  if (summary.recommended?.verifyCommand) {
    lines.push(`Verify: ${summary.recommended.verifyCommand}`);
  }
  lines.push(`Status: ${summary.recommended?.statusCommand || ""}`);
  lines.push(`Reconcile: ${summary.recommended?.reconcileCommand || ""}`);
  return `${lines.join("\n")}\n`;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname);
if (isMain) {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    process.stdout.write(`Usage: node scripts/agent-lane-inventory.mjs [--port 9222] [--extension-id ID] [--json] [--write report.json]\n`);
    process.exit(0);
  }
  try {
    const port = String(options.port || DEFAULT_PORT);
    const targets = await fetchCdpTargets(port, options);
    const summary = summarizeCdpTargets(targets, {
      port,
      extensionId: options.extensionId || ""
    });
    if (options.write && options.write !== true) {
      await fs.mkdir(path.dirname(path.resolve(String(options.write))), { recursive: true });
      await fs.writeFile(path.resolve(String(options.write)), `${JSON.stringify(summary, null, 2)}\n`);
    }
    process.stdout.write(options.json ? `${JSON.stringify(summary, null, 2)}\n` : formatText(summary));
    process.exit(summary.ok ? 0 : 2);
  } catch (error) {
    const failure = {
      ok: false,
      error: {
        code: "lane_inventory_failed",
        message: error?.message || String(error || "lane inventory failed")
      }
    };
    process.stdout.write(options.json ? `${JSON.stringify(failure, null, 2)}\n` : `${failure.error.message}\n`);
    process.exit(2);
  }
}
