#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const DEFAULT_OUT_ROOT = ".context/agent-live-smoke";
const DEFAULT_PORT = "9222";

export function parseArgs(argv = []) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = String(argv[index] || "");
    if (!token.startsWith("--")) continue;
    const [rawKey, inlineValue] = token.slice(2).split(/=(.*)/s, 2);
    const noPrefix = rawKey.startsWith("no-");
    const key = (noPrefix ? rawKey.slice(3) : rawKey).replace(/-([a-z])/g, (_, char) => char.toUpperCase());
    if (noPrefix) {
      options[key] = false;
      continue;
    }
    if (["json", "help"].includes(key)) {
      options[key] = true;
      continue;
    }
    const next = argv[index + 1];
    if (inlineValue !== undefined) {
      options[key] = inlineValue;
    } else if (next && !String(next).startsWith("--")) {
      options[key] = next;
      index += 1;
    } else {
      options[key] = true;
    }
  }
  return options;
}

export function buildAgentLiveSmokePack(options = {}) {
  const now = options.now instanceof Date ? options.now : new Date();
  const stamp = formatStamp(now);
  const runId = String(options.runId || `agent-live-smoke-${stamp}`).trim();
  const port = String(options.port || DEFAULT_PORT);
  const extensionId = String(options.extensionId || "<mounted-extension-id>").trim();
  const proofOnly = parseBooleanOption(options.proofOnly, true);
  const targeting = normalizeTargeting(options);
  const targetFlags = buildTargetFlags(targeting);
  const outRoot = String(options.out || DEFAULT_OUT_ROOT);
  const outDir = path.join(outRoot, runId);
  const imageTag = String(options.imageTag || `AF-LIVE-CI-${stamp}`).trim();
  const videoTag = String(options.videoTag || `AF-LIVE-TV-${stamp}`).trim();
  const imagePrompt = `[${imageTag}] a cinematic vertical photo of a glowing teal vending machine in a rainy Tokyo alley at night, wet pavement reflections, moody practical lighting, no people, no text, no watermark`;
  const videoPrompt = `[${videoTag}] a cinematic vertical video of a street musician playing saxophone in a rain-soaked subway entrance at night, steam drifting through neon reflections, slow handheld push-in, no visible text, no watermark`;
  const imagePromptFile = path.join(outDir, "create-image.prompt.txt");
  const videoPromptFile = path.join(outDir, "text-to-video.prompt.txt");
  const qaRowsFile = path.join(outDir, "qa-rows.json");
  const commandsFile = path.join(outDir, "commands.sh");
  const reportFile = path.join(outDir, "README.md");
  const laneInventoryFile = path.join(outDir, "lane-inventory.json");
  const imageOutDir = path.join(outDir, "create-image-matrix");
  const videoOutDir = path.join(outDir, "text-to-video-matrix");
  const outputPaths = {
    outDir,
    imagePrompt: imagePromptFile,
    videoPrompt: videoPromptFile,
    qaRows: qaRowsFile,
    commands: commandsFile,
    report: reportFile,
    laneInventoryReport: laneInventoryFile,
    imageMatrixDir: imageOutDir,
    videoMatrixDir: videoOutDir
  };

  const imageBuildCommand = command([
    "node bin/autoflow.js agent build-matrix",
    "--input", shellEscape(imagePromptFile),
    "--mode create-image",
    "--repeat 1",
    "--out", shellEscape(imageOutDir),
    "--json"
  ]);
  const imageDryRunCommand = command([
    "node bin/autoflow.js agent run",
    "--input", shellEscape(imagePromptFile),
    "--mode create-image",
    "--repeat 1",
    targetFlags,
    "--dry-run",
    "--json"
  ]);
  const imageLiveRunCommand = command([
    "node bin/autoflow.js agent run",
    "--input", shellEscape(imagePromptFile),
    "--mode create-image",
    "--repeat 1",
    targetFlags,
    "--json"
  ]);

  const commands = [
    "#!/usr/bin/env bash",
    "set -euo pipefail",
    "",
    "# 1. Confirm the lane is clean before burning credits.",
    `node scripts/agent-lane-inventory.mjs --port ${shellEscape(port)} --extension-id ${shellEscape(extensionId)} --json --write ${shellEscape(laneInventoryFile)}`,
    "node bin/autoflow.js status --json",
    "node bin/autoflow.js agent reconcile --project current --json",
    "",
    "# 2. Build one-image Agent Mode artifacts without burning credits.",
    imageBuildCommand,
    imageDryRunCommand,
    "",
    proofOnly
      ? "# 3. Proof-only default: no live submit command is included. Run only after lane inventory says liveSubmitSafe=true if you regenerate with --no-proof-only."
      : "# 3. Credit-burning Create Image live submit. Run only after lane inventory says liveSubmitSafe=true and explicit targeting matches the Flow tab.",
    proofOnly ? "" : imageLiveRunCommand,
    proofOnly ? "" : "node bin/autoflow.js agent reconcile --project current --json",
    "",
    "# 4. Optional transcript QA fixture. Not part of the one-image smoke path.",
    `node bin/autoflow.js qa transcripts --rows ${shellEscape(qaRowsFile)} --json`
  ].filter((line) => line !== "").join("\n");

  const qaRows = [
    {
      rowId: `[${videoTag}]`,
      mediaId: "",
      transcriptText: "",
      expectedDialogue: [],
      requiredPhrases: ["street musician"],
      notes: "Live smoke video has no required spoken dialogue; transcript may be empty and should require human review unless a transcript is supplied."
    }
  ];

  const readme = [
    "# Auto Flow Agent Live Smoke Pack",
    "",
    `Run id: \`${runId}\``,
    `CDP port: \`${port}\``,
    `Extension id: \`${extensionId}\``,
    `Proof only: \`${proofOnly ? "true" : "false"}\``,
    `Project id: \`${targeting.projectId || "not specified"}\``,
    `Tab id: \`${targeting.tabId || "not specified"}\``,
    `Lane id: \`${targeting.laneId || "not specified"}\``,
    "",
    "This pack is intentionally tiny. The default command path proves one CLI-driven Agent image setup without a live submit or any video-credit path.",
    "",
    "## Tags",
    "",
    `- Create Image: \`[${imageTag}]\``,
    `- Text-to-Video: \`[${videoTag}]\``,
    "",
    "## Files",
    "",
    `- Create Image prompt: \`${imagePromptFile}\``,
    `- Text-to-Video prompt: \`${videoPromptFile}\``,
    `- QA rows fixture: \`${qaRowsFile}\``,
    `- Commands: \`${commandsFile}\``,
    `- Lane inventory report: \`${laneInventoryFile}\``,
    `- Create Image matrix output: \`${imageOutDir}\``,
    "",
    "## Rules",
    "",
    "- Do not run the live submit commands unless lane inventory says `liveSubmitSafe=true`.",
    "- Default proof-only packs do not contain a live submit command.",
    "- Regenerate with `--no-proof-only` only when the intended action is exactly one Create Image live submit.",
    "- Do not run Text-to-Video from this smoke pack.",
    "- Record fresh media ids from reconcile after each live submit.",
    "- If the lane has duplicate Flow tabs or a broken Flow tab, clean the lane or use explicit targeting before live submit."
  ].join("\n");

  return {
    ok: true,
    runId,
    stamp,
    outDir,
    port,
    extensionId,
    proofOnly,
    targeting,
    tags: {
      image: imageTag,
      video: videoTag
    },
    files: {
      imagePromptFile,
      videoPromptFile,
      qaRowsFile,
      commandsFile,
      reportFile,
      laneInventoryFile,
      imageOutDir,
      videoOutDir
    },
    outputPaths,
    prompts: {
      imagePrompt,
      videoPrompt
    },
    qaRows,
    commands,
    readme
  };
}

export async function writeAgentLiveSmokePack(pack = {}, options = {}) {
  const cwd = options.cwd || process.cwd();
  const outDir = path.resolve(cwd, pack.outDir);
  await fs.mkdir(outDir, { recursive: true });
  await fs.writeFile(path.resolve(cwd, pack.files.imagePromptFile), `${pack.prompts.imagePrompt}\n`);
  await fs.writeFile(path.resolve(cwd, pack.files.videoPromptFile), `${pack.prompts.videoPrompt}\n`);
  await fs.writeFile(path.resolve(cwd, pack.files.qaRowsFile), `${JSON.stringify(pack.qaRows, null, 2)}\n`);
  await fs.writeFile(path.resolve(cwd, pack.files.commandsFile), `${pack.commands}\n`, { mode: 0o755 });
  await fs.writeFile(path.resolve(cwd, pack.files.reportFile), `${pack.readme}\n`);
  return {
    ...pack,
    outDir,
    files: Object.fromEntries(Object.entries(pack.files).map(([key, value]) => [key, path.resolve(cwd, value)])),
    outputPaths: Object.fromEntries(Object.entries(pack.outputPaths || {}).map(([key, value]) => [key, path.resolve(cwd, value)]))
  };
}

function formatStamp(date = new Date()) {
  const pad = (value) => String(value).padStart(2, "0");
  return [
    date.getUTCFullYear(),
    pad(date.getUTCMonth() + 1),
    pad(date.getUTCDate()),
    "-",
    pad(date.getUTCHours()),
    pad(date.getUTCMinutes()),
    pad(date.getUTCSeconds())
  ].join("");
}

function shellEscape(value = "") {
  const text = String(value);
  return /^[A-Za-z0-9._:/=\-[\]]+$/.test(text) ? text : `'${text.replaceAll("'", "'\\''")}'`;
}

function parseBooleanOption(value, fallback = false) {
  if (value == null) return fallback;
  if (typeof value === "boolean") return value;
  const normalized = String(value).trim().toLowerCase();
  if (["0", "false", "no", "off"].includes(normalized)) return false;
  if (["1", "true", "yes", "on"].includes(normalized)) return true;
  return fallback;
}

function normalizeTargeting(options = {}) {
  return {
    projectId: String(options.projectId || "").trim(),
    tabId: String(options.tabId || "").trim(),
    laneId: String(options.laneId || "").trim()
  };
}

function buildTargetFlags(targeting = {}) {
  return [
    targeting.projectId ? `--project-id ${shellEscape(targeting.projectId)}` : "",
    targeting.tabId ? `--tab-id ${shellEscape(targeting.tabId)}` : "",
    targeting.laneId ? `--lane-id ${shellEscape(targeting.laneId)}` : ""
  ].filter(Boolean).join(" ");
}

function command(parts = []) {
  return parts.filter((part) => String(part || "").trim()).join(" ");
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname);
if (isMain) {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    process.stdout.write("Usage: node scripts/create-agent-live-smoke-pack.mjs [--out .context/agent-live-smoke] [--run-id NAME] [--port 9222] [--extension-id ID] [--project-id PID] [--tab-id TID] [--lane-id LID] [--no-proof-only] [--json]\n");
    process.exit(0);
  }
  const pack = buildAgentLiveSmokePack(options);
  const written = await writeAgentLiveSmokePack(pack);
  if (options.json) {
    process.stdout.write(`${JSON.stringify({
      ok: true,
      runId: written.runId,
      outDir: written.outDir,
      proofOnly: written.proofOnly,
      targeting: written.targeting,
      tags: written.tags,
      files: written.files,
      outputPaths: written.outputPaths
    }, null, 2)}\n`);
  } else {
    process.stdout.write(`Created Agent live smoke pack: ${written.outDir}\n`);
    process.stdout.write(`Commands: ${written.files.commandsFile}\n`);
    process.stdout.write(`Proof only: ${written.proofOnly ? "true" : "false"}\n`);
    process.stdout.write(`Create Image tag: [${written.tags.image}]\n`);
    process.stdout.write(`Text-to-Video tag: [${written.tags.video}]\n`);
  }
}
