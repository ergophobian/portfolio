/**
 * Auto Flow browser client SDK.
 *
 * Connects PatchWork (and other web apps) to the package-owned broker over a
 * loopback WebSocket (`/v1/browser`) using the same agent bridge command
 * envelope as CLI/MCP — no Unix sockets and no manual window.autoflowTransport.
 */

import {
  AGENT_BRIDGE_PROTOCOL,
  AGENT_BRIDGE_VERSION,
  createAgentBridgeRequest
} from "../core/agent/agent-bridge-protocol.js";
import {
  BROWSER_BRIDGE_CAPABILITIES,
  BROWSER_BROKER_WS_PATH,
  BROWSER_CLIENT_HELLO_TYPE,
  BROWSER_TRANSPORT,
  browserPermissionEventFromBridgePayload,
  buildBrowserStreamEventsFromSubmitResult,
  findForbiddenBinaryMedia
} from "../core/agent/browser-broker-transport.js";

const DEFAULT_REQUEST_TIMEOUT_MS = 30000;
const DEFAULT_RECONNECT_BASE_MS = 500;
const DEFAULT_RECONNECT_MAX_MS = 8000;
const DEFAULT_CONTEXT_POLL_MS = 750;
const DEFAULT_WAIT_REPLY_TIMEOUT_MS = 45000;

export class AutoFlowBrowserClient {
  /**
   * @param {object} options
   * @param {string} [options.url] absolute browser WS url (ws://127.0.0.1:PORT/v1/browser)
   * @param {string} [options.httpUrl] broker hello base (http://127.0.0.1:PORT)
   * @param {string} [options.clientId]
   * @param {string} [options.clientName]
   * @param {string} [options.pairingToken]
   * @param {string[]} [options.requestedCapabilities]
   * @param {(event: object) => void} [options.onEvent]
   * @param {(event: object) => void} [options.onPermission]
   * @param {typeof WebSocket} [options.WebSocketCtor]
   * @param {typeof fetch} [options.fetchImpl]
   * @param {boolean} [options.autoReconnect]
   */
  constructor(options = {}) {
    this.url = String(options.url || options.browserWsUrl || "").trim();
    this.httpUrl = String(options.httpUrl || "").trim();
    this.clientId = String(options.clientId || "autoflow-browser-client").trim() || "autoflow-browser-client";
    this.clientName = String(options.clientName || this.clientId).trim() || this.clientId;
    this.pairingToken = String(options.pairingToken || "").trim();
    this.requestedCapabilities = Array.isArray(options.requestedCapabilities)
      ? options.requestedCapabilities.map((value) => String(value || "").trim()).filter(Boolean)
      : [...BROWSER_BRIDGE_CAPABILITIES];
    this.onEvent = typeof options.onEvent === "function" ? options.onEvent : () => {};
    this.onPermission = typeof options.onPermission === "function" ? options.onPermission : () => {};
    this.WebSocketCtor = options.WebSocketCtor || globalThis.WebSocket;
    this.fetchImpl = options.fetchImpl || globalThis.fetch?.bind(globalThis);
    this.autoReconnect = options.autoReconnect !== false;
    this.requestTimeoutMs = positiveInteger(options.requestTimeoutMs, DEFAULT_REQUEST_TIMEOUT_MS);
    this.reconnectBaseMs = positiveInteger(options.reconnectBaseMs, DEFAULT_RECONNECT_BASE_MS);
    this.reconnectMaxMs = positiveInteger(options.reconnectMaxMs, DEFAULT_RECONNECT_MAX_MS);

    this.socket = null;
    this.connected = false;
    this.hello = null;
    this.grantedCapabilities = [];
    this.pending = new Map();
    this.reconnectAttempt = 0;
    this.reconnectTimer = null;
    this.closedByUser = false;
    this.brokerInstanceId = "";
    this._openPromise = null;
  }

  /**
   * Discover browserWsUrl from the broker hello HTTP endpoint when url is omitted.
   */
  async discover(options = {}) {
    const httpUrl = String(options.httpUrl || this.httpUrl || "").replace(/\/$/, "");
    if (!httpUrl) {
      throw browserClientError(
        "BROWSER_DISCOVERY_URL_REQUIRED",
        "discover() requires httpUrl (for example http://127.0.0.1:17677)."
      );
    }
    if (typeof this.fetchImpl !== "function") {
      throw browserClientError("BROWSER_FETCH_UNAVAILABLE", "fetch is unavailable for broker discovery.");
    }
    const response = await this.fetchImpl(`${httpUrl}/v1/hello`, {
      method: "GET",
      headers: { accept: "application/json" }
    });
    if (!response.ok) {
      throw browserClientError(
        "BROWSER_DISCOVERY_FAILED",
        `Broker hello failed with HTTP ${response.status}`,
        { status: response.status }
      );
    }
    const payload = await response.json();
    this.httpUrl = httpUrl;
    this.url = String(payload.browserWsUrl || "").trim();
    this.brokerInstanceId = String(payload.brokerInstanceId || "");
    if (!this.url) {
      throw browserClientError(
        "BROWSER_WS_URL_MISSING",
        "Broker hello did not include browserWsUrl. Ensure the WS broker is running with browser transport support."
      );
    }
    this.emit({ type: "discovery", httpUrl, browserWsUrl: this.url, brokerInstanceId: this.brokerInstanceId });
    return payload;
  }

  async connect(options = {}) {
    this.closedByUser = false;
    if (options.url) this.url = String(options.url).trim();
    if (options.httpUrl) this.httpUrl = String(options.httpUrl).trim();
    if (options.pairingToken) this.pairingToken = String(options.pairingToken).trim();
    if (!this.url && this.httpUrl) await this.discover({ httpUrl: this.httpUrl });
    if (!this.url) {
      throw browserClientError(
        "BROWSER_WS_URL_REQUIRED",
        "connect() requires url (ws://127.0.0.1:PORT/v1/browser) or httpUrl for discovery."
      );
    }
    if (typeof this.WebSocketCtor !== "function") {
      throw browserClientError("BROWSER_WEBSOCKET_UNAVAILABLE", "WebSocket is unavailable in this runtime.");
    }
    if (this.socket && (this.socket.readyState === this.WebSocketCtor.OPEN || this.socket.readyState === this.WebSocketCtor.CONNECTING)) {
      if (this.hello) return this.hello;
      if (this._openPromise) return this._openPromise;
    }

    this._openPromise = new Promise((resolve, reject) => {
      let settled = false;
      const socket = new this.WebSocketCtor(this.url);
      this.socket = socket;

      const fail = (error) => {
        if (settled) return;
        settled = true;
        this.connected = false;
        this._openPromise = null;
        if (this.socket === socket) this.socket = null;
        if (socket.readyState === this.WebSocketCtor.OPEN || socket.readyState === this.WebSocketCtor.CONNECTING) {
          try { socket.close(1000, "hello_failed"); } catch {}
        }
        reject(error instanceof Error ? error : browserClientError("BROWSER_WS_CONNECT_FAILED", String(error)));
      };

      socket.addEventListener("open", async () => {
        this.connected = true;
        this.reconnectAttempt = 0;
        this.emit({ type: "connected", url: this.url, transport: BROWSER_TRANSPORT });
        try {
          const hello = await this.helloHandshake();
          if (!settled) {
            settled = true;
            this._openPromise = null;
            resolve(hello);
          }
        } catch (error) {
          fail(error);
        }
      });
      socket.addEventListener("message", (event) => {
        if (this.socket !== socket) return;
        this.handleSocketMessage(event.data);
      });
      socket.addEventListener("close", () => {
        if (this.socket !== socket) return;
        this.socket = null;
        this.connected = false;
        this.hello = null;
        this.rejectAllPending(browserClientError(
          "BROWSER_WS_DISCONNECTED",
          "Browser broker WebSocket disconnected."
        ));
        this.emit({ type: "disconnected", url: this.url });
        if (!settled) fail(browserClientError("BROWSER_WS_DISCONNECTED", "Browser broker WebSocket closed before ready."));
        this.scheduleReconnect();
      });
      socket.addEventListener("error", () => {
        this.emit({ type: "error", code: "BROWSER_WS_ERROR", message: "Browser broker WebSocket error." });
      });
    });
    return this._openPromise;
  }

  async helloHandshake() {
    const response = await this.sendRaw({
      protocol: AGENT_BRIDGE_PROTOCOL,
      version: AGENT_BRIDGE_VERSION,
      id: this.nextId("hello"),
      type: BROWSER_CLIENT_HELLO_TYPE,
      payload: {
        clientId: this.clientId,
        clientName: this.clientName,
        transport: BROWSER_TRANSPORT,
        requestedCapabilities: this.requestedCapabilities
      },
      session: {
        source: "autoflow_browser_client",
        clientId: this.clientId
      }
    });
    if (response?.ok !== true) {
      throw browserClientError(
        response?.error?.code || "BROWSER_HELLO_FAILED",
        response?.error?.message || "Browser client hello failed.",
        response?.error?.details
      );
    }
    this.hello = response.payload || {};
    this.grantedCapabilities = Array.isArray(this.hello.grantedCapabilities)
      ? this.hello.grantedCapabilities
      : (Array.isArray(this.hello.capabilities) ? this.hello.capabilities : []);
    this.brokerInstanceId = String(this.hello.brokerInstanceId || this.brokerInstanceId || "");
    this.emit({ type: "hello", payload: this.hello });
    return this.hello;
  }

  close() {
    this.closedByUser = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    const socket = this.socket;
    this.socket = null;
    this.connected = false;
    this.hello = null;
    this.rejectAllPending(browserClientError("BROWSER_WS_CLOSED", "Browser client closed."));
    try {
      socket?.close?.();
    } catch {}
  }

  async ensureConnected() {
    if (this.connected && this.hello && this.socket) return this.hello;
    return this.connect();
  }

  /**
   * Low-level bridge request using the shared command envelope.
   */
  async request(type, payload = {}, options = {}) {
    await this.ensureConnected();
    const forbidden = findForbiddenBinaryMedia(payload);
    if (forbidden) {
      throw browserClientError(
        "BROWSER_BINARY_MEDIA_FORBIDDEN",
        "Browser client never sends binary media through the bridge. Use mediaId/reference ids or local paths.",
        forbidden
      );
    }
    if (this.grantedCapabilities.length && !this.grantedCapabilities.includes(type)
      && type !== BROWSER_CLIENT_HELLO_TYPE) {
      throw browserClientError(
        "BROWSER_CAPABILITY_UNSUPPORTED",
        `Capability not granted for this browser session: ${type}`,
        { grantedCapabilities: this.grantedCapabilities }
      );
    }

    const request = createAgentBridgeRequest({
      id: options.requestId || this.nextId(type),
      type,
      payload,
      auth: {
        mode: "extension_session",
        ...(this.pairingToken ? { pairingToken: this.pairingToken } : {}),
        ...(options.auth && typeof options.auth === "object" ? options.auth : {})
      },
      session: {
        source: "autoflow_browser_client",
        clientId: this.clientId,
        ...(options.session && typeof options.session === "object" ? options.session : {})
      }
    });

    const response = await this.sendRaw(request, {
      timeoutMs: options.timeoutMs
    });
    this.maybeEmitPermission(response, { requestId: request.id, command: type });
    if (response?.ok === false || response?.error) {
      const error = browserClientError(
        response?.error?.code || "BRIDGE_ERROR",
        response?.error?.message || "Bridge request failed.",
        response?.error?.details
      );
      error.response = response;
      throw error;
    }
    return response;
  }

  async pairStart(payload = {}) {
    return this.request("pair.start", {
      clientName: this.clientName,
      ...payload
    });
  }

  async pairConfirm(pairingCode, payload = {}) {
    const response = await this.request("pair.confirm", {
      pairingCode: String(pairingCode || "").trim(),
      clientId: this.clientId,
      ...payload
    });
    const token = String(response?.payload?.pairingToken || "").trim();
    if (token) this.pairingToken = token;
    if (response?.payload?.clientId) this.clientId = String(response.payload.clientId);
    this.emit({ type: "paired", clientId: this.clientId, pairingTokenPreview: response?.payload?.pairingTokenPreview || "" });
    return response;
  }

  async getStatus(payload = {}) {
    return this.request("status.get", payload);
  }

  async getContext(payload = {}) {
    return this.request("agent.context.get", {
      project: payload.project || "current",
      ...payload
    });
  }

  /**
   * Submit an agent prompt. Prefer dryRun:true for no-credit diagnostics.
   * When stream:true, emits text/tool stream events from the result (and optional
   * waitForReply context polling). Never ships binary media.
   */
  async submitPrompt(payload = {}, options = {}) {
    const dryRun = payload.dryRun === true || options.dryRun === true;
    const stream = options.stream !== false;
    const waitForReply = options.waitForReply === true || payload.waitForReply === true;
    const requestPayload = {
      ...payload,
      dryRun,
      // Live paid generation is intentionally opt-in and still requires pairing + entitlement.
      ...(dryRun ? { dryRun: true } : {})
    };
    const requestId = options.requestId || this.nextId("agent.prompt.submit");
    if (stream) {
      this.emit({
        type: "stream",
        kind: "submit.started",
        requestId,
        dryRun
      });
    }

    let baselineKeys = null;
    if (waitForReply && !dryRun) {
      const baseline = await this.getContext({
        projectId: payload.projectId,
        tabId: payload.tabId,
        laneId: payload.laneId
      }).catch(() => null);
      baselineKeys = new Set(latestMessageKeys(baseline?.payload));
    }

    let response;
    try {
      response = await this.request("agent.prompt.submit", requestPayload, {
        requestId,
        timeoutMs: options.timeoutMs
      });
    } catch (error) {
      if (stream) {
        // Normalized stream contract even for typed no-credit / fail-closed diagnostics.
        this.emit({
          type: "stream",
          kind: "text",
          requestId,
          text: String(error?.message || "agent.prompt.submit failed"),
          role: "diagnostic"
        });
        this.emit({
          type: "stream",
          kind: "tool",
          requestId,
          name: dryRun ? "agent.prompt.submit.diagnostic" : "agent.prompt.submit",
          status: "no_credit_fail_closed",
          details: {
            code: error?.code || "BRIDGE_ERROR",
            message: error?.message || String(error),
            dryRun
          }
        });
        this.emit({
          type: "stream",
          kind: "submit.done",
          requestId,
          dryRun,
          submitted: false,
          ok: false,
          code: error?.code || "BRIDGE_ERROR"
        });
      }
      throw error;
    }
    const result = {
      ...(response.payload || {}),
      ok: response.ok !== false,
      dryRun
    };

    if (stream) {
      for (const event of buildBrowserStreamEventsFromSubmitResult(result, {
        requestId,
        dryRun
      })) {
        // started already emitted above; skip duplicate start
        if (event.kind === "submit.started") continue;
        this.emit(event);
      }
    }

    if (waitForReply && !dryRun) {
      const waited = await this.waitForReplyStream({
        requestId,
        projectId: payload.projectId || result.projectId,
        tabId: payload.tabId || result.page?.tabId,
        laneId: payload.laneId,
        baselineKeys,
        timeoutMs: options.waitTimeoutMs,
        pollMs: options.pollMs
      });
      result.reply = waited.reply;
      result.latestMessages = waited.latestMessages;
      if (stream) {
        this.emit({
          type: "stream",
          kind: "submit.done",
          requestId,
          dryRun,
          submitted: result.submitted === true,
          ok: true,
          waited: true
        });
      }
    }

    return {
      ...response,
      payload: result
    };
  }

  /**
   * Stage a reference from an allowlisted HTTPS URL in the local broker.
   * The WS payload carries metadata only; the broker fetches and verifies it.
   */
  async importRefUrl(payload = {}) {
    const forbidden = findForbiddenBinaryMedia(payload);
    if (forbidden) {
      throw browserClientError(
        "BROWSER_BINARY_MEDIA_FORBIDDEN",
        "importRefUrl accepts URL/metadata only; never binary media.",
        forbidden
      );
    }
    return this.request("agent.refs.importUrl", payload);
  }

  /**
   * Attach references by mediaId / path / structured refs — never binary bytes.
   */
  async attachRefs(payload = {}) {
    const forbidden = findForbiddenBinaryMedia(payload);
    if (forbidden) {
      throw browserClientError(
        "BROWSER_BINARY_MEDIA_FORBIDDEN",
        "attachRefs rejects binary media. Pass mediaId, rowId/mediaId, or local path references only.",
        forbidden
      );
    }
    return this.request("agent.refs.attach", payload);
  }

  /** Execute an exact-target, row/media-scoped download plan without returning bytes. */
  async executeDownloads(payload = {}) {
    const forbidden = findForbiddenBinaryMedia(payload);
    if (forbidden) {
      throw browserClientError(
        "BROWSER_BINARY_MEDIA_FORBIDDEN",
        "executeDownloads accepts scope and plan metadata only; never binary media.",
        forbidden
      );
    }
    return this.request("downloads.execute", payload);
  }

  /**
   * Confirm a visible credit permission once, or with persistentApproval/dontAskAgain.
   */
  async confirmPermission(payload = {}, options = {}) {
    const persistent = options.persistent === true
      || payload.persistentApproval === true
      || payload.dontAskAgain === true;
    return this.request("agent.credits.confirm", {
      ...payload,
      persistentApproval: persistent,
      dontAskAgain: persistent
    });
  }

  /**
   * Honest unsupported reject/cancel for credit dialogs.
   * Flow dialog cancel is not a bridge command yet.
   */
  async rejectPermission(payload = {}) {
    const error = browserClientError(
      "BROWSER_PERMISSION_REJECT_UNSUPPORTED",
      "Explicit credit reject/cancel is not wired on the Flow credit dialog path. Leave the dialog open or dismiss it in the Flow UI.",
      {
        confirmOnceSupported: true,
        persistentSupported: true,
        rejectSupported: false,
        payload
      }
    );
    this.emit({
      type: "permission",
      kind: "credit_confirmation",
      status: "reject_unsupported",
      rejectSupported: false,
      code: error.code,
      message: error.message
    });
    throw error;
  }

  /**
   * Guarded Agent settings read via page/agent context (no binary media).
   * Verifies project/tab identity when provided.
   */
  async getAgentSettings(payload = {}) {
    const context = await this.getContext({
      project: payload.project || "current",
      projectId: payload.projectId,
      tabId: payload.tabId,
      laneId: payload.laneId
    });
    const page = context?.payload?.page && typeof context.payload.page === "object"
      ? context.payload.page
      : {};
    const settings = {
      ...(context?.payload?.settings && typeof context.payload.settings === "object"
        ? context.payload.settings
        : {}),
      ...(page.settings && typeof page.settings === "object" ? page.settings : {}),
      state: context?.payload?.state || page.state || "",
      composerVisible: context?.payload?.composer?.visible === true || page.composerVisible === true,
      projectId: context?.payload?.projectId || page.projectId || "",
      tabId: String(context?.payload?.tabId || page.tabId || payload.tabId || "")
    };
    if (payload.projectId && settings.projectId && String(payload.projectId) !== String(settings.projectId)) {
      throw browserClientError(
        "AGENT_TARGET_MISMATCH",
        "getAgentSettings projectId does not match the live Agent page state.",
        { expectedProjectId: payload.projectId, actualProjectId: settings.projectId }
      );
    }
    const result = {
      ok: context?.ok !== false,
      settings,
      verified: true,
      source: "agent.context.get",
      neverBinaryMedia: true
    };
    this.emit({ type: "settings", kind: "get", payload: result });
    return { ...context, payload: { ...(context?.payload || {}), settings, settingsRead: result } };
  }

  /**
   * Agent settings mutation is intentionally fail-closed on the browser path.
   * Mode/model/aspect changes remain Flow-page / DOM-controlled to avoid burning paid jobs.
   */
  async setAgentSettings(payload = {}) {
    const error = browserClientError(
      "BROWSER_AGENT_SETTINGS_SET_UNSUPPORTED",
      "Browser clients may read Agent page settings but cannot mutate Flow Agent settings over the bridge. Change settings in the Flow UI or use a guarded CLI/DOM path.",
      {
        getSupported: true,
        setSupported: false,
        payload: {
          projectId: payload.projectId || "",
          tabId: payload.tabId || "",
          requestedKeys: Object.keys(payload.settings && typeof payload.settings === "object" ? payload.settings : payload)
            .filter((key) => !["projectId", "tabId", "laneId", "project"].includes(key))
            .slice(0, 20)
        }
      }
    );
    this.emit({
      type: "settings",
      kind: "set_unsupported",
      code: error.code,
      message: error.message
    });
    throw error;
  }

  /**
   * Durable event/job resume: re-read agent context + project media ids (no binary).
   * Callers use this after reconnect instead of replaying in-memory stream state.
   */
  async resumeSession(payload = {}) {
    const [context, media] = await Promise.all([
      this.getContext({
        project: payload.project || "current",
        projectId: payload.projectId,
        tabId: payload.tabId,
        laneId: payload.laneId
      }),
      this.listMedia({
        project: payload.project || "current",
        projectId: payload.projectId,
        tabId: payload.tabId,
        laneId: payload.laneId
      }).catch((error) => ({
        ok: false,
        error: {
          code: error?.code || "PROJECT_MEDIA_UNAVAILABLE",
          message: error?.message || String(error)
        }
      }))
    ]);
    const latestMessages = Array.isArray(context?.payload?.latestMessages)
      ? context.payload.latestMessages
      : [];
    const mediaIds = collectMediaIds(
      media?.payload?.rows,
      media?.payload?.items,
      media?.payload?.media
    );
    const result = {
      ok: context?.ok !== false,
      projectId: context?.payload?.projectId || media?.payload?.projectId || "",
      tabId: String(context?.payload?.tabId || payload.tabId || ""),
      state: context?.payload?.state || "",
      latestMessageCount: latestMessages.length,
      latestMessages,
      mediaIds,
      durable: true,
      neverBinaryMedia: true,
      source: "browser_client.resumeSession"
    };
    this.emit({ type: "resume", payload: result });
    return result;
  }

  async listMedia(payload = {}) {
    return this.request("project.media.list", {
      project: payload.project || "current",
      ...payload
    });
  }

  async getProjectMetadata(payload = {}) {
    return this.request("project.metadata.get", {
      project: payload.project || "current",
      ...payload
    });
  }

  /**
   * Media reconciliation helper: list project media + optional metadata.
   * Does not download or transfer binary media through the bridge.
   */
  async reconcileMedia(payload = {}) {
    const [media, metadata] = await Promise.all([
      this.listMedia(payload),
      this.getProjectMetadata(payload).catch((error) => ({
        ok: false,
        error: {
          code: error?.code || "METADATA_UNAVAILABLE",
          message: error?.message || String(error)
        }
      }))
    ]);
    const rows = Array.isArray(media?.payload?.rows) ? media.payload.rows : [];
    const items = Array.isArray(media?.payload?.items) ? media.payload.items : [];
    const mediaItems = Array.isArray(media?.payload?.media) ? media.payload.media : [];
    const result = {
      ok: media?.ok !== false,
      projectId: media?.payload?.projectId || metadata?.payload?.projectId || "",
      rows,
      items,
      media: mediaItems,
      metadata: metadata?.payload?.metadata || metadata?.payload?.projectInitialData || null,
      mediaIds: collectMediaIds(rows, items, mediaItems),
      source: "browser_client.reconcileMedia",
      neverBinaryMedia: true
    };
    this.emit({ type: "reconcile", payload: result });
    return result;
  }

  async planDownloads(payload = {}) {
    return this.request("downloads.plan", payload);
  }

  // --- internals ---

  sendRaw(message, options = {}) {
    const timeoutMs = positiveInteger(options.timeoutMs, this.requestTimeoutMs);
    const id = String(message.id || "").trim();
    if (!id) {
      return Promise.reject(browserClientError("INVALID_REQUEST_ID", "request id must be a non-empty string"));
    }
    if (!this.socket || this.socket.readyState !== this.WebSocketCtor.OPEN) {
      return Promise.reject(browserClientError("BROWSER_WS_NOT_CONNECTED", "Browser broker WebSocket is not connected."));
    }
    if (this.pending.has(id)) {
      return Promise.reject(browserClientError("DUPLICATE_REQUEST_ID", `request already pending: ${id}`));
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(browserClientError("BROWSER_REQUEST_TIMEOUT", `Browser bridge request timed out: ${id}`, {
          requestId: id,
          type: message.type
        }));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer, type: message.type });
      try {
        this.socket.send(JSON.stringify(message));
      } catch (error) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(browserClientError(
          "BROWSER_WS_SEND_FAILED",
          error?.message || String(error || "failed to send browser bridge frame")
        ));
      }
    });
  }

  handleSocketMessage(raw) {
    let message;
    try {
      message = JSON.parse(String(raw));
    } catch {
      this.emit({ type: "error", code: "BROWSER_WS_JSON_INVALID", message: "Invalid JSON from broker." });
      return;
    }
    const id = String(message?.id || "").trim();
    if (id && this.pending.has(id)) {
      const entry = this.pending.get(id);
      this.pending.delete(id);
      clearTimeout(entry.timer);
      entry.resolve(message);
      return;
    }
    // Unsolicited event frame (future extension)
    this.emit({ type: "broker_event", message });
  }

  maybeEmitPermission(response = {}, source = {}) {
    const payload = response?.payload && typeof response.payload === "object" ? response.payload : {};
    const event = browserPermissionEventFromBridgePayload(payload, source);
    if (!event) return;
    this.onPermission(event);
    this.emit(event);
  }

  async waitForReplyStream(options = {}) {
    const timeoutMs = positiveInteger(options.timeoutMs, DEFAULT_WAIT_REPLY_TIMEOUT_MS);
    const pollMs = positiveInteger(options.pollMs, DEFAULT_CONTEXT_POLL_MS);
    const deadline = Date.now() + timeoutMs;
    const seen = new Set(options.baselineKeys || []);
    let latestMessages = [];
    let reply = null;

    while (Date.now() < deadline) {
      const context = await this.getContext({
        projectId: options.projectId,
        tabId: options.tabId,
        laneId: options.laneId
      }).catch(() => null);
      latestMessages = Array.isArray(context?.payload?.latestMessages)
        ? context.payload.latestMessages
        : [];
      for (const message of latestMessages) {
        const key = messageKey(message);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        const text = String(message?.text || message?.content || message?.message || "").trim();
        if (text) {
          this.emit({
            type: "stream",
            kind: "text",
            requestId: options.requestId,
            text,
            role: String(message?.role || message?.author || "agent")
          });
        }
        if (message?.tool || message?.toolName) {
          this.emit({
            type: "stream",
            kind: "tool",
            requestId: options.requestId,
            name: String(message.tool || message.toolName),
            status: String(message.status || "update"),
            details: message
          });
        }
        reply = message;
      }
      if (reply) break;
      await delay(pollMs);
    }

    return { reply, latestMessages };
  }

  scheduleReconnect() {
    if (this.closedByUser || !this.autoReconnect) return;
    if (this.reconnectTimer) return;
    const attempt = this.reconnectAttempt + 1;
    this.reconnectAttempt = attempt;
    const delayMs = Math.min(this.reconnectMaxMs, this.reconnectBaseMs * (2 ** Math.min(attempt - 1, 5)));
    this.emit({ type: "reconnect_scheduled", attempt, delayMs });
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect().catch((error) => {
        this.emit({
          type: "reconnect_failed",
          attempt,
          code: error?.code || "BROWSER_WS_RECONNECT_FAILED",
          message: error?.message || String(error)
        });
        this.scheduleReconnect();
      });
    }, delayMs);
  }

  rejectAllPending(error) {
    for (const [id, entry] of this.pending.entries()) {
      clearTimeout(entry.timer);
      entry.reject(error);
      this.pending.delete(id);
    }
  }

  emit(event) {
    try {
      this.onEvent(event);
    } catch {}
  }

  nextId(prefix = "req") {
    const safe = String(prefix || "req").replace(/[^a-zA-Z0-9._-]+/g, "_").slice(0, 48);
    return `af-browser-${safe}-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
  }
}

export function createAutoFlowBrowserClient(options = {}) {
  return new AutoFlowBrowserClient(options);
}

export {
  BROWSER_BRIDGE_CAPABILITIES,
  BROWSER_BROKER_WS_PATH,
  BROWSER_CLIENT_HELLO_TYPE,
  BROWSER_TRANSPORT
};

function browserClientError(code, message, details) {
  const error = new Error(message || code);
  error.name = "AutoFlowBrowserClientError";
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}

function positiveInteger(value, fallback) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric) || numeric <= 0) return fallback;
  return Math.floor(numeric);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function latestMessageKeys(payload = {}) {
  const messages = Array.isArray(payload?.latestMessages) ? payload.latestMessages : [];
  return messages.map(messageKey).filter(Boolean);
}

function messageKey(message = {}) {
  const id = String(message?.id || message?.messageId || "").trim();
  if (id) return id;
  const text = String(message?.text || message?.content || message?.message || "").trim();
  const role = String(message?.role || message?.author || "").trim();
  if (!text && !role) return "";
  return `${role}:${text.slice(0, 160)}`;
}

function collectMediaIds(...groups) {
  const ids = new Set();
  for (const group of groups) {
    if (!Array.isArray(group)) continue;
    for (const entry of group) {
      const mediaId = String(entry?.mediaId || entry?.id || entry?.mediaName || "").trim();
      if (mediaId) ids.add(mediaId);
    }
  }
  return [...ids];
}

// Default export for simpler browser bundler interop.
export default AutoFlowBrowserClient;
