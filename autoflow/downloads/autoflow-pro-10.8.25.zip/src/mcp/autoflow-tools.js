import { BridgeResponseError, BridgeUnavailableError, isFlowAuthExpiredError, requestBridge } from "../cli/bridge-client.js";
import { resolveDownloadMediaKind } from "../core/media/download-media-kind.js";
import fsSync from "node:fs";
import fs from "node:fs/promises";
import path from "node:path";
import { getAutoFlowRuntimeDir } from "../../native-host/broker.js";
import {
  buildAgentPromptBundleFromFile,
  buildAgentPromptBundleFromText,
  buildRetryPayload,
  evaluateTranscriptRows,
  planAgentArtifacts,
  readJsonFile,
  reconcileExpectedProjectData,
  reconcileProjectData
} from "../cli/fixture-reconciler.js";
import { buildAgentPromptText } from "../core/agent/agent-mode.js";
import { buildAgentRuntimeContext } from "../core/agent/agent-context.js";
import {
  buildAgentRunWaitPollingPlan,
  waitForAgentRunCompletion
} from "../core/agent/agent-run-wait.js";
import {
  buildAgentRunProfile,
  missingRowsFromWaitProgress
} from "../core/agent/agent-run-profile.js";
import { createAgentRunId, prependAgentRunEnvelope } from "../core/agent/agent-run-preflight.js";
import {
  createCreditPolicyState,
  buildStandingCreditPolicy,
  buildCaptainAuthorizedCreditApproval,
  evaluateStandingCreditPolicy,
  hasStandingCreditLimit,
  isCaptainExplicitlyAuthorized,
  isSubmitConfirmCreditsAuthorized,
  resolveCreditApprovalDecision,
  resolveCreditPersistentApproval
} from "../core/agent/agent-credit-policy.js";
import {
  extractAgentArtifactRows,
  mediaIdsFromAgentArtifactPlan,
  rowIdsFromAgentArtifactRows,
  scopeAgentArtifactInput,
  scopeAgentArtifactPlan
} from "../core/agent/agent-artifact-scope.js";
import { buildAgentRenderFallbackInspection } from "../core/agent/agent-render-fallback.js";
import { planAgentRefAttachments, verifyAgentRefAttachmentChips } from "../core/agent/agent-ref-attachments.js";
import { buildAgentRetryPrompt } from "../core/agent/agent-retry-prompts.js";
import { agentTargetPayloadFields } from "../core/agent/agent-submit-guard.js";
import {
  fleetGenDurationSecondsFromInput,
  fleetGenInvalidDurationValue,
  fleetGenInvalidMediaType,
  fleetGenMediaTypeFromValue,
  fleetGenPerRowDurationPresent,
  fleetGenPromptRecordsFromInput,
  fleetGenSourceRoleError
} from "../core/agent/fleet-gen-request.js";
import { normalizeDownloadFilenameOptions } from "../core/gallery/download-filename-options.js";
import {
  buildFlowStateSnapshot,
  compactFlowStateError,
  flowStatePreconditionFailure,
  flowStateStatusSummary
} from "../core/agent/flow-state.js";
import {
  shouldAutoRetryAgentWait,
  summarizeAgentCreditPolicy
} from "../core/agent/agent-supervision-policy.js";
import {
  buildGalleryDownloadPlan,
  galleryMediaListTimeoutMs,
  galleryMediaFromProjectMediaList,
  isKnownGalleryType,
  isValidGalleryLatest,
  selectGalleryDownloadMedia,
  summarizeGalleryMedia
} from "../cli/gallery-media.js";
import { buildAgentLiveSmokePack } from "../../scripts/create-agent-live-smoke-pack.mjs";
import { fetchCdpTargets, summarizeCdpTargets } from "../../scripts/agent-lane-inventory.mjs";
import { bridgeUnavailable, invalidInput, toolFailure } from "./errors.js";

const UNKNOWN_VERSION = "unknown";
const NATIVE_HOST_RESTART_REQUIREMENT = "After repairing the native host manifest, fully quit the affected Chrome testing profile/window and reopen it so Chrome reloads the native messaging manifest.";

export async function runAutoFlowTool(name, args = {}, context = {}) {
  try {
    if (name === "autoflow_context") return agentContext();
    if (name === "autoflow_pair") return await pairBridge(args, context);
    if (name === "autoflow_bridge_targets") return await bridgeTargets(args, context);
    if (name === "autoflow_bridge_use") return await bridgeUse(args, context);
    if (name === "autoflow_lane_use") return await laneUse(args, context);
    if (name === "autoflow_lane_list") return await laneList(args, context);
    if (name === "autoflow_lane_unbind") return await laneUnbind(args, context);
    if (name === "autoflow_status") return await getStatus(args, context);
    if (name === "autoflow_connect") return await connectThisFlowTab(args, context);
    if (name === "autoflow_fleetgen") return await fleetGen(args, context);
    if (name === "autoflow_flow_state") return await getFlowState(args, context);
    if (name === "autoflow_flow_tabs") return await getFlowTabs(args, context);
    if (name === "autoflow_agent_context") return await getAgentContext(args, context);
    if (name === "autoflow_agent_screenshot") return await getAgentScreenshot(args, context);
    if (name === "autoflow_lane_inventory") return await laneInventory(args);
    if (name === "autoflow_build_smoke_pack") return buildSmokePack(args);
    if (name === "autoflow_run_agent_batch") return await runAgentBatch(args, context);
    if (name === "autoflow_reconcile_project") return await reconcileProject(args, context);
    if (name === "autoflow_agent_gallery_list") return await listAgentGallery(args, context);
    if (name === "autoflow_agent_gallery_download") return await downloadAgentGallery(args, context);
    if (name === "autoflow_wait_for_render") return await waitForRender(args, context);
    if (name === "autoflow_clip_pipeline_download") return await clipPipelineDownload(args, context);
    if (name === "autoflow_clip_pipeline_repair") return await clipPipelineRepair(args, context);
    if (name === "autoflow_fleet_generate") return await fleetGenerate(args, context);
    if (name === "autoflow_submit_agent_prompt") return await submitAgentPrompt(args, context);
    if (name === "autoflow_attach_refs") return await attachRefs(args, context);
    if (name === "autoflow_confirm_credits") return await confirmCredits(args, context);
    if (name === "autoflow_retry_rows") return await retryRows(args, context);
    if (name === "autoflow_download_outputs") return await downloadOutputs(args, context);
    if (name === "autoflow_qa_transcripts") return await qaTranscripts(args);
    return invalidInput(`Unknown Auto Flow tool: ${name}`);
  } catch (error) {
    return normalizeToolError(error);
  }
}

function agentContext() {
  return {
    ok: true,
    tool: "autoflow_context",
    readOnly: true,
    context: buildAgentRuntimeContext()
  };
}

async function pairBridge(args, context) {
  const action = String(args.action || "start");
  if (action === "status") return getStatus({ ...args, includeRuntime: true, includeProject: false, includeQueue: false }, context);
  const type = action === "confirm" ? "pair.confirm" : "pair.start";
  const payload = action === "confirm" ? { pairingCode: String(args.pairingCode || "") } : {};
  if (action === "confirm" && !payload.pairingCode) {
    return invalidInput("autoflow_pair confirm requires pairingCode.");
  }
  const bridgeResult = await requestBridge(type, payload, {
    ...bridgeOptions(args, context),
    serviceWorkerRequired: true,
    commandFallback: false
  });
  const response = unwrapBridgeResponse(bridgeResult);
  if (action === "confirm" && response.pairingToken) {
    context.pairingToken = response.pairingToken;
    context.clientId = response.clientId || context.clientId || args.clientId || "autoflow-cli";
    await writeMcpPairingCredential(args, context, {
      pairingToken: response.pairingToken,
      clientId: context.clientId,
      pairedAt: new Date().toISOString()
    });
  }
  const safeResponse = redactPairingToken(response);
  return {
    ok: true,
    tool: "autoflow_pair",
    action,
    source: "bridge",
    bridgeHost: bridgeResult.host,
    response: safeResponse
  };
}

async function bridgeTargets(args, context) {
  const payload = bridgeTargetPayloadFields(args, context);
  const bridgeResult = await requestBridge("bridge.targets.list", payload, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_bridge_targets",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    selectedExtension: response.selectedExtension || null,
    requestedTarget: response.requestedTarget || payload,
    response
  };
}

async function bridgeUse(args, context) {
  const missing = [];
  if (!compactString(args.projectId)) missing.push("projectId");
  if (!compactString(args.tabId)) missing.push("tabId");
  if (!compactString(args.laneId || laneIdFromArgs(args, context))) missing.push("laneId");
  if (missing.length) return invalidInput(`autoflow_bridge_use requires ${missing.join(", ")}.`);
  const payload = bridgeTargetPayloadFields(args, context);
  const bridgeResult = await requestBridge("bridge.target.use", payload, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_bridge_use",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    laneId: response.laneId || payload.laneId || "",
    selectedExtension: response.selectedExtension || null,
    requestedTarget: response.requestedTarget || payload,
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    response
  };
}

async function laneUse(args, context) {
  const laneId = laneIdFromArgs(args, context);
  if (!laneId) return invalidInput("autoflow_lane_use requires name or laneId.");
  const payload = {
    laneId,
    ...bridgeTargetPayloadFields({ ...args, laneId }, context)
  };
  const bridgeResult = await requestBridge("lane.use", payload, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  const selected = response.selectedTarget || response.selectedExtension || {};
  return {
    ok: true,
    tool: "autoflow_lane_use",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    laneId: response.laneId || laneId,
    name: response.name || response.laneId || laneId,
    projectId: selected.projectId || response.selection?.projectId || "",
    tabId: selected.tabId || response.selection?.tabId || "",
    selectedTarget: selected,
    selection: response.selection || null,
    indicator: response.indicator || null,
    response
  };
}

async function laneList(args, context) {
  const bridgeResult = await requestBridge("lane.list", {}, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_lane_list",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    lanes: Array.isArray(response.lanes) ? response.lanes : [],
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    response
  };
}

async function laneUnbind(args, context) {
  const laneId = laneIdFromArgs(args, context);
  if (!laneId) return invalidInput("autoflow_lane_unbind requires name or laneId.");
  const bridgeResult = await requestBridge("lane.unbind", { laneId }, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_lane_unbind",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    laneId: response.laneId || laneId,
    removed: response.removed === true,
    previous: response.previous || null,
    response
  };
}

async function getStatus(args, context) {
  args = withLaneDefault(args, context);
  const payload = {
    project: args.project || "current",
    ...bridgeTargetPayloadFields(args, context),
    includeRuntime: args.includeRuntime !== false,
    includeProject: args.includeProject !== false,
    includeQueue: args.includeQueue !== false
  };
  const bridgeResult = await requestBridge("status.get", payload, bridgeOptions(args, context));
  return {
    ok: true,
    tool: "autoflow_status",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    status: normalizeStatus(unwrapBridgeResponse(bridgeResult))
  };
}

async function fleetGen(args, context) {
  const method = compactString(args.method || args.command);
  const allowed = new Set(["setPrompts", "updateSettings", "launch", "executeDirect", "getCapabilities", "normalizeInputs", "getState", "getStatus", "getResult", "getOutbox"]);
  if (!allowed.has(method)) return invalidInput("autoflow_fleetgen received an unsupported Fleet Gen method.");
  if (method === "getResult" && !compactString(args.commandId)) return invalidInput("autoflow_fleetgen getResult requires commandId.");
  const type = `fleetgen.${method}`;
  const payload = {
    ...(method === "setPrompts" ? { prompts: Array.isArray(args.prompts) ? args.prompts : [] } : {}),
    ...(method === "updateSettings" ? { settings: args.settings && typeof args.settings === "object" ? args.settings : {} } : {}),
    ...(method === "executeDirect" ? { prompt: compactString(args.prompt), options: args.options && typeof args.options === "object" ? args.options : {} } : {}),
    ...((method === "launch" || method === "normalizeInputs") ? { options: args.options && typeof args.options === "object" ? args.options : {} } : {}),
    ...(method === "getResult" ? { commandId: compactString(args.commandId) } : {}),
    ...((method === "launch" || method === "executeDirect") ? { captainAuthorized: args.captainAuthorized === true } : {}),
    ...bridgeTargetPayloadFields(args, context),
    ...(args.timeoutMs ? { timeoutMs: args.timeoutMs } : {})
  };
  const bridgeResult = await requestBridge(type, payload, bridgeOptions(args, context));
  return {
    ok: true,
    tool: "autoflow_fleetgen",
    method,
    source: "bridge",
    bridgeHost: bridgeResult.host,
    response: unwrapBridgeResponse(bridgeResult)
  };
}

async function connectThisFlowTab(args, context) {
  args = withLaneDefault(args, context);
  const payload = {
    ...agentTargetPayloadFields(args),
    ...(Number(args.timeoutMs || 0) > 0 ? { timeoutMs: Number(args.timeoutMs) } : {})
  };
  const request = { type: "agent.tab.connect", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, payload, {
      ...bridgeOptions(args, context),
      serviceWorkerRequired: true,
      commandFallback: false
    });
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_connect" });
  }
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_connect",
    readOnly: true,
    source: "bridge",
    bridgeHost: bridgeResult.host,
    projectId: response.projectId || payload.projectId || "",
    tabId: response.tabId || payload.tabId || "",
    laneId: response.laneId || "",
    code: response.code || "FLOW_PAGE_CONNECTED",
    nextAction: response.nextAction || "",
    request,
    response
  };
}

async function getFlowState(args, context) {
  args = withLaneDefault(args, context);
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  const target = agentTargetPayloadFields(args);
  const statusRequest = {
    type: "status.get",
    payload: {
      project: args.project || "current",
      ...bridgeTargetPayloadFields(args),
      includeRuntime: true,
      includeProject: true,
      includeQueue: true
    }
  };
  let statusBridgeResult;
  try {
    statusBridgeResult = await requestBridge(statusRequest.type, statusRequest.payload, bridgeOptions(args, context));
  } catch (error) {
    if (error instanceof BridgeUnavailableError) {
      return {
        tool: "autoflow_flow_state",
        ...compactFlowStateError({
          code: "FLOW_STATE_BRIDGE_DOWN",
          precondition: "bridge_down",
          message: "flow_state precondition missing: Auto Flow native broker socket is unavailable.",
          request: statusRequest,
          details: error.details || {}
        })
      };
    }
    throw error;
  }

  const status = normalizeStatus(unwrapBridgeResponse(statusBridgeResult));
  const precondition = flowStatePreconditionFailure(status);
  if (precondition) {
    return {
      tool: "autoflow_flow_state",
      ...compactFlowStateError({
        ...precondition,
        status,
        request: statusRequest
      })
    };
  }

  const contextRequest = {
    type: "agent.context.get",
    payload: {
      project: args.project || "current",
      includeRaw: false,
      ...(expectedManifest ? { expectedManifest } : {}),
      ...target
    }
  };
  let agentContext;
  let contextBridgeResult = null;
  try {
    contextBridgeResult = await requestBridge(contextRequest.type, contextRequest.payload, bridgeOptions(args, context));
    agentContext = unwrapBridgeResponse(contextBridgeResult);
  } catch (error) {
    if (error instanceof BridgeUnavailableError) {
      return {
        tool: "autoflow_flow_state",
        ...compactFlowStateError({
          code: "FLOW_STATE_BRIDGE_DOWN",
          precondition: "bridge_down",
          message: "flow_state precondition missing: bridge went down before the Flow page snapshot could be read.",
          status,
          request: contextRequest,
          details: error.details || {}
        })
      };
    }
    if (error instanceof BridgeResponseError) {
      const code = bridgeResponseErrorCode(error).toUpperCase() || "BRIDGE_ERROR";
      const lowerCode = code.toLowerCase();
      const pagePrecondition = /target_mismatch|flow_tab|project|page/.test(lowerCode);
      return {
        tool: "autoflow_flow_state",
        ...compactFlowStateError({
          code: pagePrecondition ? "FLOW_STATE_PAGE_NOT_FLOW" : `FLOW_STATE_${code}`,
          precondition: pagePrecondition ? "page_not_flow" : "context_unavailable",
          message: pagePrecondition
            ? "flow_state precondition missing: active page is not the requested Google Flow project tab."
            : `flow_state precondition missing: Flow page snapshot unavailable (${code}).`,
          status,
          request: contextRequest,
          details: {
            response: error.response || {}
          }
        })
      };
    }
    throw error;
  }

  const snapshot = buildFlowStateSnapshot({
    status,
    agentContext,
    requestedTarget: target
  });
  return {
    ok: snapshot.ok,
    tool: "autoflow_flow_state",
    source: "bridge",
    bridgeHost: contextBridgeResult?.host || statusBridgeResult.host,
    compact: true,
    status: flowStateStatusSummary(status),
    ...snapshot
  };
}

async function getFlowTabs(args, context) {
  args = withLaneDefault(args, context);
  const payload = {
    project: args.project || "current",
    ...(args.projectId ? { projectId: String(args.projectId) } : {}),
    ...(args.laneId ? { laneId: String(args.laneId) } : {})
  };
  const request = { type: "flow.tabs.list", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_flow_tabs" });
  }
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: true,
    tool: "autoflow_flow_tabs",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    tabs: Array.isArray(response.tabs) ? response.tabs : [],
    targets: Array.isArray(response.targets) ? response.targets : [],
    response
  };
}

async function getAgentContext(args, context) {
  args = withLaneDefault(args, context);
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  const payload = {
    project: args.project || "current",
    includeRaw: args.includeRaw === true,
    ...(expectedManifest ? { expectedManifest } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.context.get", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_agent_context" });
  }
  return {
    ok: true,
    tool: "autoflow_agent_context",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    response: unwrapBridgeResponse(bridgeResult)
  };
}

async function getAgentScreenshot(args, context) {
  args = withLaneDefault(args, context);
  const payload = {
    project: args.project || "current",
    format: args.format || "jpeg",
    ...(args.quality ? { quality: Number(args.quality) } : {}),
    ...(args.fullPage === true ? { fullPage: true } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.screenshot.get", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_agent_screenshot" });
  }
  const response = unwrapBridgeResponse(bridgeResult);
  const screenshot = response?.screenshot || {};
  const base64 = String(screenshot.dataBase64 || "");
  if (!base64) return toolFailure("AGENT_SCREENSHOT_EMPTY", "Agent screenshot response did not include image data.", { response });
  const ext = screenshot.format === "png" ? "png" : "jpg";
  const outPath = path.resolve(context.cwd || process.cwd(), args.out && args.out !== true
    ? String(args.out)
    : path.join(".context", `autoflow-agent-screenshot-${Date.now()}.${ext}`));
  await fs.mkdir(path.dirname(outPath), { recursive: true });
  await fs.writeFile(outPath, Buffer.from(base64, "base64"));
  return {
    ok: true,
    tool: "autoflow_agent_screenshot",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    path: outPath,
    response: {
      ...response,
      screenshot: {
        ...screenshot,
        dataBase64: undefined,
        path: outPath
      }
    }
  };
}

async function laneInventory(args) {
  const port = String(args.port || "9222");
  const targets = Array.isArray(args.cdpTargets)
    ? args.cdpTargets
    : await fetchCdpTargets(port, { timeoutMs: args.timeoutMs });
  return {
    ok: true,
    tool: "autoflow_lane_inventory",
    readOnly: true,
    source: Array.isArray(args.cdpTargets) ? "provided_cdp_targets" : "cdp_json_list",
    summary: summarizeCdpTargets(targets, {
      port,
      extensionId: args.extensionId || ""
    })
  };
}

function buildSmokePack(args) {
  const now = parseOptionalDate(args.now);
  const pack = buildAgentLiveSmokePack({
    runId: args.runId,
    out: args.out,
    port: args.port,
    extensionId: args.extensionId,
    imageTag: args.imageTag,
    videoTag: args.videoTag,
    ...(now ? { now } : {})
  });
  return {
    ok: true,
    tool: "autoflow_build_smoke_pack",
    write: false,
    submit: false,
    pack
  };
}

async function reconcileProject(args, context) {
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  const projectMetadata = await readOptionalJson(args.projectMetadata, args.fixturePath);
  if (projectMetadata) {
    return reconcileProjectMetadata(projectMetadata, expectedManifest, {
      source: args.fixturePath ? "fixture" : "metadata",
      fixturePath: args.fixturePath || "",
      includeRawRows: args.includeRawRows === true
    });
  }
  args = withLaneDefault(args, context);

  const request = {
    type: "project.metadata.get",
    payload: {
      project: args.project || "current",
      ...agentTargetPayloadFields(args)
    }
  };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request);
  }
  const response = unwrapBridgeResponse(bridgeResult);
  const metadata = response.metadata || response.projectInitialData || response;
  return {
    ...reconcileProjectMetadata(metadata, expectedManifest, {
      source: "bridge",
      includeRawRows: args.includeRawRows === true
    }),
    bridgeHost: bridgeResult.host
  };
}

async function listAgentGallery(args, context) {
  args = withLaneDefault(args, context);
  const optionsError = galleryArgsError(args, ["project", "projectId", "tabId", "type", "latest", "mediaId"]);
  if (optionsError) return invalidInput(optionsError);
  const gallery = await fetchAgentGalleryForMcp(args, context);
  return {
    ok: true,
    tool: "autoflow_agent_gallery_list",
    source: "bridge",
    bridgeHost: gallery.bridgeHost,
    projectId: gallery.projectId,
    count: gallery.media.length,
    summary: summarizeGalleryMedia(gallery.media),
    filters: {
      type: args.type || "",
      latest: args.latest || ""
    },
    media: gallery.media
  };
}

async function downloadAgentGallery(args, context) {
  const optionsError = galleryArgsError(args, ["project", "projectId", "tabId", "type", "latest", "mediaId", "rowId"], {
    mediaIdMessage: "autoflow_agent_gallery_download requires mediaId or latest with type."
  });
  if (optionsError) return invalidInput(optionsError);
  const namingOptions = mcpDownloadFilenameOptions(args);
  if (namingOptions.error) return invalidInput(namingOptions.error);
  const mediaId = compactString(args.mediaId || "");
  if (!mediaId && !args.latest) {
    return invalidInput("autoflow_agent_gallery_download requires mediaId or latest with type.");
  }
  if (args.latest && !args.type) {
    return invalidInput("autoflow_agent_gallery_download latest requires type image or video.");
  }
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_agent_gallery_download");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const targetError = galleryDownloadTargetError(args);
  if (targetError) return invalidInput(targetError);

  const gallery = await fetchAgentGalleryForMcp(mediaId ? {
    ...args,
    latest: "",
    type: args.type || ""
  } : {
    ...args,
    latest: "",
    type: ""
  }, context);
  const selected = selectGalleryDownloadMedia(gallery.media, args);
  if (!selected.length) {
    return invalidInput(args.mediaId
      ? `No visible Flow media matched media id ${args.mediaId}.`
      : "No visible Flow media matched the gallery download selection.");
  }
  const plan = buildGalleryDownloadPlan(selected, {
    folder: args.folder || args.outputRoot,
    imageResolution: args.imageResolution,
    videoResolution: args.videoResolution,
    rowId: args.rowId,
    ...namingOptions.options
  });
  const downloadTimeoutMs = galleryDownloadTimeoutMs(args);
  const mediaIds = selected.map((record) => record.mediaId).filter(Boolean);
  const payload = {
    project: args.project || "current",
    mediaIds,
    plan,
    runName: args.runName || "Gallery",
    timeoutMs: downloadTimeoutMs,
    ...namingOptions.options,
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "downloads.execute", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, payload, {
      ...bridgeOptions(args, context),
      timeoutMs: downloadTimeoutMs + 15000
    });
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_agent_gallery_download" });
  }
  const response = unwrapBridgeResponse(bridgeResult);
  return {
    ok: response.ok !== false,
    tool: "autoflow_agent_gallery_download",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    projectId: gallery.projectId,
    count: selected.length,
    mediaIds,
    media: selected,
    plan,
    savedPaths: response.paths || {},
    response
  };
}

async function fetchAgentGalleryForMcp(args, context) {
  args = withLaneDefault(args, context);
  const mediaListTimeoutMs = galleryMediaListTimeoutMs(args);
  const payload = {
    project: args.project || "current",
    ...(args.mediaId ? { mediaId: args.mediaId } : {}),
    ...(args.type ? { type: args.type } : {}),
    ...(mediaListTimeoutMs ? { timeoutMs: mediaListTimeoutMs } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "project.media.list", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    throw error;
  }
  const response = unwrapBridgeResponse(bridgeResult);
  const projectId = String(response.projectId || args.projectId || "").trim();
  return {
    bridgeHost: bridgeResult.host,
    projectId,
    media: galleryMediaFromProjectMediaList(response, {
      projectId,
      type: args.type,
      latest: args.latest
    })
  };
}

const DOWNLOAD_ON_COMPLETE_BRIDGE_TIMEOUT_MS = 600000;

async function waitForRender(args, context) {
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  if (!expectedManifest && !hasExpectedCounts(args)) {
    return invalidInput("autoflow_wait_for_render requires expectedManifest, expectedManifestPath, expectedImages, or expectedVideos.");
  }
  if (!expectedManifest && args.downloadOnComplete !== false) {
    return invalidInput("autoflow_wait_for_render auto-download requires expectedManifest or expectedManifestPath; set downloadOnComplete=false for count-only waits.");
  }
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_wait_for_render");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);

  const payload = {
    project: args.project || "current",
    ...(expectedManifest ? { expectedManifest } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "project.metadata.get", payload };
  const polling = buildAgentRunWaitPollingPlan({
    timeoutMs: args.waitTimeoutMs ?? args.runTimeoutMs ?? args.timeoutMs,
    quietMs: args.quietMs ?? args.quietDelayMs,
    pollMs: args.pollMs ?? args.pollIntervalMs,
    stalledNoProgressPolls: args.stalledNoProgressPolls ?? args.noProgressPolls ?? args.maxUnchangedPolls
  });
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_wait_for_render",
      dryRun: true,
      request,
      polling,
      autoRetry: buildWaitAutoRetryPlan(args),
      nextActions: [
        "After submit or retry, call this tool with the expected manifest until it returns complete or timedOut.",
        "If timedOut with missingVideoTags, call autoflow_agent_context before retrying only the missing rows."
      ]
    };
  }

  const options = bridgeOptions({
    ...args,
    timeoutMs: args.bridgeTimeoutMs || args.metadataTimeoutMs || 30000
  }, context);
  let lastReconcile = null;
  try {
    const contextPayload = {
      project: args.project || "current",
      includeRaw: false,
      ...(expectedManifest ? { expectedManifest } : {}),
      ...agentTargetPayloadFields(args)
    };
    let lastAgentContext = null;
    const resolvedAgentActions = new Set();
    const creditPolicyState = createCreditPolicyState(buildStandingCreditPolicy(args, context.env || process.env));
    const waitOnce = () => waitForAgentRunCompletion({
      expectedImages: args.expectedImages ?? args.expectedImageCount,
      expectedVideos: args.expectedVideos ?? args.expectedVideoCount,
      timeoutMs: args.waitTimeoutMs ?? args.runTimeoutMs ?? args.timeoutMs,
      quietMs: args.quietMs ?? args.quietDelayMs,
      pollMs: args.pollMs ?? args.pollIntervalMs,
      stalledNoProgressPolls: args.stalledNoProgressPolls ?? args.noProgressPolls ?? args.maxUnchangedPolls,
      defaultMode: args.retryMode,
      reconcile: async () => {
        const bridgeResult = await requestBridge(request.type, request.payload, options);
        const response = unwrapBridgeResponse(bridgeResult);
        const metadata = response.metadata || response.projectInitialData || response;
        lastReconcile = expectedManifest
          ? {
              ...reconcileProjectMetadata(metadata, expectedManifest, {
                source: "bridge",
                includeRawRows: args.includeRawRows === true
              }),
              bridgeHost: bridgeResult.host
            }
          : {
              ...reconcileProjectMetadata(metadata, null, {
                source: "bridge",
                includeRawRows: args.includeRawRows === true
              }),
              bridgeHost: bridgeResult.host
        };
        return lastReconcile;
      },
      inspect: async ({ progress }) => {
        lastAgentContext = await requestAgentContextSnapshot(contextPayload, options).catch(() => null);
        const actionResolution = await maybeResolveAgentActionDuringWait({
          context: lastAgentContext,
          args,
          options,
          env: context.env || process.env,
          resolvedAgentActions,
          creditPolicyState
        });
        if (actionResolution) return actionResolution;
        const inspection = buildAgentRenderFallbackInspection({
          context: lastAgentContext,
          progress
        });
        return inspection;
      }
    });
    let wait = await waitOnce();
    const autoRetry = await maybeRetryMissingRenderRows({
      wait,
      args,
      expectedManifest,
      options,
      waitOnce,
      env: context.env || process.env
    });
    if (autoRetry?.rounds?.length) {
      wait = autoRetry.finalWait || wait;
    }
    const result = {
      ok: wait.ok,
      tool: "autoflow_wait_for_render",
      source: "bridge",
      wait,
      autoRetry,
      creditPolicy: summarizeAgentCreditPolicy(args, creditPolicyState),
      reconciliation: lastReconcile,
      agentContext: lastAgentContext ? summarizeAgentContextForWait(lastAgentContext) : null,
      nextActions: renderWaitNextActions(wait)
    };
    if (wait.ok && args.downloadOnComplete !== false) {
      const downloadableRows = extractAgentArtifactRows(lastReconcile || {});
      if (!downloadableRows.length) {
        result.download = {
          ok: true,
          tool: "autoflow_download_outputs",
          execute: false,
          skipped: true,
          reason: "no_downloadable_outputs",
          savedPaths: {}
        };
      } else {
        result.download = await downloadOutputs({
          ...args,
          execute: true,
          reconciled: lastReconcile,
          runName: args.runName,
          outputRoot: args.outputRoot,
          imageResolution: args.imageResolution,
          videoResolution: args.videoResolution,
          timeoutMs: args.downloadExecuteTimeoutMs ?? args.downloadTimeoutMs ?? DOWNLOAD_ON_COMPLETE_BRIDGE_TIMEOUT_MS
        }, context);
        const downloadFailure = summarizeDownloadOnCompleteFailure(result.download, { requireSavedPaths: false });
        if (downloadFailure) {
          result.ok = false;
          result.state = "download_failed";
          result.failedMediaIds = downloadFailure.failedMediaIds;
          result.errors = downloadFailure.errors;
          result.nextActions = downloadFailure.nextActions;
        } else {
          result.ok = wait.ok && result.download.ok === true;
          const savedPaths = result.download?.savedPaths || result.download?.response?.paths || {};
          const savedCount = Object.keys(savedPaths).filter((key) => savedPaths[key]).length;
          if (result.ok && savedCount === 0) {
            result.download.savedPathsEmpty = true;
            result.nextActions = [
              ...(Array.isArray(result.nextActions) ? result.nextActions : []),
              "Download reported success but saved no new files despite downloadable rows; verify the expected files already exist on disk before marking this workflow complete."
            ];
          }
        }
      }
    }
    return result;
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_wait_for_render" });
  }
}

function summarizeDownloadOnCompleteFailure(download = {}, options = {}) {
  const response = download.response || {};
  const savedPaths = download.savedPaths || response.paths || {};
  const errors = normalizeDownloadErrors(download.errors || response.errors || []);
  const failedMediaIds = uniqueStrings([
    ...errors.map((error) => error.mediaId),
    ...(Array.isArray(response.failedMediaIds) ? response.failedMediaIds : []),
    ...(Array.isArray(download.failedMediaIds) ? download.failedMediaIds : [])
  ]);
  const savedCount = Object.keys(savedPaths || {}).filter((key) => savedPaths[key]).length;
  if (options.requireSavedPaths === false) {
    if (download.ok === true && errors.length === 0 && failedMediaIds.length === 0) return null;
  } else if (download.ok === true && savedCount > 0 && errors.length === 0) {
    return null;
  }
  return {
    failedMediaIds,
    errors,
    nextActions: [
      "Download failed after render completed; inspect the failed media IDs and rerun autoflow_download_outputs for only those artifacts.",
      "Do not mark this content workflow complete until valid files are saved and validated."
    ]
  };
}

function summarizeClipPipelineDownloadFailure(downloads = [], resolvedMediaIds = new Set()) {
  const failures = (downloads || [])
    .map((download) => summarizeDownloadOnCompleteFailure(download))
    .filter(Boolean);
  const unresolvedFailures = failures
    .map((failure) => {
      const attributable = (failure.errors || []).some((error) => error.mediaId)
        || (failure.failedMediaIds || []).length > 0;
      const errors = (failure.errors || []).filter(
        (error) => !error.mediaId || !resolvedMediaIds.has(error.mediaId)
      );
      const failedMediaIds = (failure.failedMediaIds || []).filter(
        (mediaId) => !resolvedMediaIds.has(mediaId)
      );
      if (attributable && !errors.length && !failedMediaIds.length) return null;
      return { errors, failedMediaIds };
    })
    .filter(Boolean);
  if (!unresolvedFailures.length) return null;
  return {
    failedMediaIds: uniqueStrings(unresolvedFailures.flatMap((failure) => failure.failedMediaIds)),
    errors: unresolvedFailures.flatMap((failure) => failure.errors),
    nextActions: [
      "Clip pipeline render completed, but one or more downloads failed or saved no valid file.",
      "Rerun autoflow_clip_pipeline_download with downloadedMediaIds for successful files and the same rowIds/mediaIds to resume idempotently."
    ]
  };
}

function normalizeDownloadErrors(errors = []) {
  if (!Array.isArray(errors)) return [];
  return errors.map((error) => {
    if (error && typeof error === "object") {
      return {
        mediaId: String(error.mediaId || error.id || ""),
        code: String(error.code || error.error || "DOWNLOAD_FAILED"),
        message: String(error.message || error.reason || "Download failed.")
      };
    }
    return {
      mediaId: "",
      code: "DOWNLOAD_FAILED",
      message: String(error || "Download failed.")
    };
  });
}

async function clipPipelineDownload(args, context) {
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  const providedReconciled = await readOptionalJson(args.reconciled, args.reconciledPath);
  const providedRows = Array.isArray(args.reconciledRows) ? args.reconciledRows : [];
  const rowIds = normalizeRetryRows(args.rowIds || args.rows || args.rowId || []);
  const excludedMediaIds = new Set(uniqueStrings(args.excludeMediaIds || args.oldMediaIds || []));
  const completionExcludedMediaIds = Array.isArray(args.completionExcludeMediaIds)
    ? new Set(uniqueStrings(args.completionExcludeMediaIds))
    : excludedMediaIds;
  if (!expectedManifest && !providedReconciled && !providedRows.length) {
    return invalidInput("autoflow_clip_pipeline_download requires expectedManifest, expectedManifestPath, reconciledRows, or reconciledPath.");
  }
  if ((expectedManifest || args.wait === true) && liveAgentTargetError(args)) {
    return invalidInput(liveAgentTargetError(args));
  }

  if (!expectedManifest) {
    const requestedMediaIds = normalizeDownloadMediaIds(args.mediaIds);
    const namingOptions = mcpDownloadFilenameOptions(args, { defaultStyle: "" });
    if (namingOptions.error) return invalidInput(namingOptions.error);
    const scoped = scopeAgentArtifactInput(providedReconciled || { rows: providedRows }, {
      rowIds,
      mediaIds: requestedMediaIds
    });
    const plan = scopeAgentArtifactPlan(planAgentArtifacts(scoped, {
      runName: args.runName,
      outputRoot: args.outputRoot,
      latestOnly: requestedMediaIds.length ? false : args.latestOnly !== false,
      includeImages: args.includeImages,
      includeVideos: args.includeVideos,
      only: args.only,
      qaStatuses: args.qaStatuses,
      ...namingOptions.options
    }).plan, {
      rowIds,
      mediaIds: requestedMediaIds
    });
    const mediaIds = mediaIdsFromAgentArtifactPlan(plan).filter((mediaId) => !excludedMediaIds.has(mediaId));
    const scopedPlan = mediaIds.length
      ? scopeAgentArtifactPlan(plan, { mediaIds })
      : {
          ...plan,
          downloads: [],
          mediaDownloads: [],
          manifest: plan.manifest && typeof plan.manifest === "object"
            ? {
                ...plan.manifest,
                rows: [],
                summary: { ...(plan.manifest.summary || {}), rows: 0, images: 0, videos: 0, downloads: 0 }
              }
            : plan.manifest
        };
    if (args.execute === false) {
      return {
        ok: true,
        tool: "autoflow_clip_pipeline_download",
        execute: false,
        plan: scopedPlan
      };
    }
    if (!mediaIds.length) {
      return {
        ok: true,
        tool: "autoflow_clip_pipeline_download",
        mode: "download_existing",
        completedRowIds: rowIds.length ? rowIds : rowIdsFromAgentArtifactRows(extractAgentArtifactRows(scoped)),
        pendingRowIds: [],
        downloadedMediaIds: [],
        downloads: [],
        plan: scopedPlan
      };
    }
    const download = await downloadOutputs({
      ...args,
      reconciled: undefined,
      reconciledPath: undefined,
      execute: true,
      reconciledRows: extractAgentArtifactRows(scoped),
      rowIds,
      mediaIds
    }, context);
    const downloadFailure = summarizeClipPipelineDownloadFailure([download]);
    return {
      ok: !downloadFailure && download.ok === true,
      tool: "autoflow_clip_pipeline_download",
      mode: "download_existing",
      state: downloadFailure ? "download_failed" : undefined,
      completedRowIds: rowIds.length ? rowIds : rowIdsFromAgentArtifactRows(extractAgentArtifactRows(scoped)),
      pendingRowIds: [],
      downloadedMediaIds: Object.keys(download.savedPaths || download.response?.paths || {}),
      downloads: [download],
      failedMediaIds: downloadFailure?.failedMediaIds,
      errors: downloadFailure?.errors,
      download
    };
  }

  const options = bridgeOptions({
    ...args,
    timeoutMs: args.metadataTimeoutMs || args.bridgeTimeoutMs || 30000
  }, context);
  const polling = buildAgentRunWaitPollingPlan({
    timeoutMs: args.waitTimeoutMs ?? args.runTimeoutMs ?? args.timeoutMs,
    quietMs: args.quietMs ?? args.quietDelayMs,
    pollMs: args.pollMs ?? args.pollIntervalMs
  });
  const requestedRows = rowIds.length ? rowIds : rowIdsFromAgentArtifactRows(extractAgentArtifactRows(expectedManifest));
  if (!requestedRows.length) {
    return invalidInput("autoflow_clip_pipeline_download expectedManifest must include at least one row to watch and download.");
  }
  const downloadedMediaIds = new Set(uniqueStrings(args.downloadedMediaIds || []));
  const downloadBatches = [];
  const actionResolutions = [];
  const creditPolicyState = createCreditPolicyState(buildStandingCreditPolicy(args, context.env || process.env));
  const resolvedAgentActions = new Set();
  const startedAt = Date.now();
  const deadline = startedAt + polling.timeoutMs;
  let attempts = 0;
  let lastReconciliation = null;
  let lastAgentContext = null;
  if (polling.initialQuietMs > 0) await sleepMs(Math.min(polling.initialQuietMs, polling.timeoutMs));

  while (Date.now() < deadline) {
    attempts += 1;
    const metadataPayload = {
      project: args.project || "current",
      expectedManifest,
      ...agentTargetPayloadFields(args)
    };
    const metadataBridge = await requestBridge("project.metadata.get", metadataPayload, options);
    const metadataResponse = unwrapBridgeResponse(metadataBridge);
    const metadata = metadataResponse.metadata || metadataResponse.projectInitialData || metadataResponse;
    lastReconciliation = reconcileProjectMetadata(metadata, expectedManifest, {
      source: "bridge",
      includeRawRows: args.includeRawRows === true
    });
    const rows = scopedCompletedRows(lastReconciliation, { rowIds: requestedRows });
    const planResult = planAgentArtifacts({ rows }, {
      runName: args.runName,
      outputRoot: args.outputRoot,
      latestOnly: args.latestOnly !== false,
      includeImages: args.includeImages,
      includeVideos: args.includeVideos,
      only: args.only,
      qaStatuses: args.qaStatuses
    });
    const plan = scopeAgentArtifactPlan(planResult.plan, {
      rowIds: requestedRows,
      mediaIds: args.mediaIds
    });
    const readyMediaIds = mediaIdsFromAgentArtifactPlan(plan)
      .filter((mediaId) => !downloadedMediaIds.has(mediaId) && !excludedMediaIds.has(mediaId));
    if (readyMediaIds.length && args.execute !== false) {
      const batch = await downloadOutputs({
        ...args,
        reconciled: undefined,
        reconciledPath: undefined,
        execute: true,
        reconciledRows: rows,
        rowIds: requestedRows,
        mediaIds: readyMediaIds,
        runName: args.runName,
        outputRoot: args.outputRoot
      }, context);
      downloadBatches.push(batch);
      for (const mediaId of Object.keys(batch.savedPaths || batch.response?.paths || {})) {
        downloadedMediaIds.add(mediaId);
      }
    }
    const status = clipPipelineRowStatus(lastReconciliation, requestedRows, {
      excludeMediaIds: [...completionExcludedMediaIds]
    });
    if (status.pendingRowIds.length === 0) {
      const downloadFailure = args.execute !== false
        ? summarizeClipPipelineDownloadFailure(downloadBatches, downloadedMediaIds)
        : null;
      if (downloadFailure) {
        return {
          ok: false,
          tool: "autoflow_clip_pipeline_download",
          mode: "watch_and_download",
          state: "download_failed",
          attempts,
          timedOut: false,
          completedRowIds: status.completedRowIds,
          pendingRowIds: [],
          downloadedMediaIds: [...downloadedMediaIds],
          failedMediaIds: downloadFailure.failedMediaIds,
          errors: downloadFailure.errors,
          downloads: downloadBatches,
          actionResolutions,
          reconciliation: lastReconciliation,
          nextActions: downloadFailure.nextActions
        };
      }
      return {
        ok: true,
        tool: "autoflow_clip_pipeline_download",
        mode: "watch_and_download",
        attempts,
        timedOut: false,
        completedRowIds: status.completedRowIds,
        pendingRowIds: [],
        downloadedMediaIds: [...downloadedMediaIds],
        downloads: downloadBatches,
        actionResolutions,
        reconciliation: lastReconciliation
      };
    }

    lastAgentContext = await requestAgentContextSnapshot({
      project: args.project || "current",
      includeRaw: false,
      expectedManifest,
      progress: status,
      ...agentTargetPayloadFields(args)
    }, options).catch(() => null);
    const actionResolution = await maybeResolveAgentActionDuringWait({
      context: lastAgentContext,
      args,
      options,
      env: context.env || process.env,
      resolvedAgentActions,
      creditPolicyState
    });
    if (actionResolution?.stop === true) {
      return {
        ok: false,
        tool: "autoflow_clip_pipeline_download",
        mode: "watch_and_download",
        state: actionResolution.status || "blocked",
        reason: actionResolution.reason || "",
        attempts,
        completedRowIds: status.completedRowIds,
        pendingRowIds: status.pendingRowIds,
        downloadedMediaIds: [...downloadedMediaIds],
        downloads: downloadBatches,
        actionResolution,
        reconciliation: lastReconciliation,
        agentContext: lastAgentContext ? summarizeAgentContextForWait(lastAgentContext) : null
      };
    }
    if (actionResolution) actionResolutions.push(actionResolution);
    await sleepMs(Math.min(polling.pollIntervalMs, Math.max(0, deadline - Date.now())));
  }

  const status = clipPipelineRowStatus(lastReconciliation, requestedRows, {
    excludeMediaIds: [...completionExcludedMediaIds]
  });
  const downloadFailure = args.execute !== false
    ? summarizeClipPipelineDownloadFailure(downloadBatches, downloadedMediaIds)
    : null;
  return {
    ok: status.pendingRowIds.length === 0 && !downloadFailure,
    tool: "autoflow_clip_pipeline_download",
    mode: "watch_and_download",
    state: downloadFailure ? "download_failed" : undefined,
    attempts,
    timedOut: status.pendingRowIds.length > 0,
    completedRowIds: status.completedRowIds,
    pendingRowIds: status.pendingRowIds,
    downloadedMediaIds: [...downloadedMediaIds],
    failedMediaIds: downloadFailure?.failedMediaIds,
    errors: downloadFailure?.errors,
    downloads: downloadBatches,
    actionResolutions,
    reconciliation: lastReconciliation,
    agentContext: lastAgentContext ? summarizeAgentContextForWait(lastAgentContext) : null,
    nextActions: downloadFailure?.nextActions
  };
}

async function clipPipelineRepair(args, context) {
  const row = normalizeRetryRows(args.rowId || (Array.isArray(args.rows) ? args.rows[0] : "") || "")[0] || "";
  if (!row) return invalidInput("autoflow_clip_pipeline_repair requires rowId.");
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);
  const expectedManifest = await readOptionalJson(args.expectedManifest, args.expectedManifestPath);
  if (!expectedManifest) return invalidInput("autoflow_clip_pipeline_repair requires expectedManifest or expectedManifestPath.");
  const options = bridgeOptions(args, context);
  const beforeBridge = await requestBridge("project.metadata.get", {
    project: args.project || "current",
    expectedManifest,
    ...agentTargetPayloadFields(args)
  }, options);
  const beforeMetadataResponse = unwrapBridgeResponse(beforeBridge);
  const beforeReconciliation = reconcileProjectMetadata(beforeMetadataResponse.metadata || beforeMetadataResponse.projectInitialData || beforeMetadataResponse, expectedManifest, {
    source: "bridge",
    includeRawRows: args.includeRawRows === true
  });
  const scopedRows = extractAgentArtifactRows(scopeAgentArtifactInput(beforeReconciliation, { rowIds: [row] }));
  const oldMediaIds = mediaIdsFromRows(scopedRows);
  const retryPayload = buildRetryPayload([row], {
    project: args.project || "current",
    issue: args.issue || "bad timing",
    notes: args.note || args.notes || "",
    mode: args.mode || "video-only",
    runId: args.runId || "current",
    taskId: args.taskId,
    projectId: args.projectId,
    tabId: args.tabId,
    laneId: args.laneId,
    env: context.env || process.env,
    confirmCredits: isSubmitConfirmCreditsAuthorized(args, context.env || process.env),
    ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {})
  });
  const retryBridge = await requestBridge("agent.retry.submit", retryPayload, options);
  const retryResponse = unwrapBridgeResponse(retryBridge);
  const completionExcludeMediaIds = mediaIdsFromRows(scopedRows, repairReplacedMediaKinds(retryPayload.mode));
  const download = await clipPipelineDownload({
    ...args,
    expectedManifest,
    rowIds: [row],
    excludeMediaIds: oldMediaIds,
    completionExcludeMediaIds,
    execute: true
  }, context);
  const newMediaIds = (download.downloadedMediaIds || []).filter((mediaId) => !oldMediaIds.includes(mediaId));
  return {
    ok: download.ok === true && newMediaIds.length > 0,
    tool: "autoflow_clip_pipeline_repair",
    rowId: normalizeRetryRows([row])[0] || row,
    retry: {
      request: { type: "agent.retry.submit", payload: retryPayload },
      response: retryResponse
    },
    oldMediaIds,
    newMediaIds,
    replacement: {
      oldMediaIds,
      newMediaIds,
      savedPaths: mergeSavedPaths(download.downloads)
    },
    download
  };
}

function scopedCompletedRows(reconciliation = {}, scope = {}) {
  const scoped = scopeAgentArtifactInput(reconciliation, { rowIds: scope.rowIds });
  return extractAgentArtifactRows(scoped).filter(agentArtifactRowComplete);
}

function clipPipelineRowStatus(reconciliation = {}, requestedRows = [], options = {}) {
  const excludedMediaIds = new Set(uniqueStrings(options.excludeMediaIds || []));
  const rows = extractAgentArtifactRows(scopeAgentArtifactInput(reconciliation, { rowIds: requestedRows }));
  const completedRowIds = rowIdsFromAgentArtifactRows(rows.filter((row) => agentArtifactRowComplete(row, { excludedMediaIds })));
  const allRows = requestedRows.length ? requestedRows : rowIdsFromAgentArtifactRows(rows);
  const completedRowSet = new Set(completedRowIds.map((rowId) => String(rowId || "").toUpperCase()));
  const pendingRowIds = allRows.filter((rowId) => !completedRowSet.has(String(rowId || "").toUpperCase()));
  return {
    completedRowIds,
    pendingRowIds,
    complete: pendingRowIds.length === 0
  };
}

function agentArtifactRowComplete(row = {}, options = {}) {
  const excludedMediaIds = options.excludedMediaIds instanceof Set ? options.excludedMediaIds : new Set();
  const expectedVideos = Number(row.expectedVideos ?? row.expectedVideoCount ?? 0) || 0;
  const expectedImages = Number(row.expectedImages ?? row.expectedImageCount ?? 0) || 0;
  const presentVideos = excludedMediaIds.size
    ? mediaCountForRow(row, ["videoVersions", "videos"], ["video", "latestVideo"], excludedMediaIds)
    : Number(row.presentVideos ?? row.videoCount ?? 0) || mediaArray(row, ["videoVersions", "videos"]).length;
  const presentImages = excludedMediaIds.size
    ? mediaCountForRow(row, ["images", "imageVersions", "imageSlots"], [], excludedMediaIds)
    : Number(row.presentImages ?? row.mappedImages ?? row.imageCount ?? 0) || mediaArray(row, ["images", "imageVersions"]).length;
  const videosComplete = expectedVideos <= 0 || presentVideos >= expectedVideos;
  const imagesComplete = expectedImages <= 0 || presentImages >= expectedImages;
  const status = compactString(row.status || row.dispatchState).toLowerCase();
  return videosComplete && imagesComplete && (!status || ["landed", "complete", "completed", "provisional_match", "observed"].includes(status));
}

function mediaIdsFromRows(rows = [], kinds = { images: true, videos: true }) {
  const includeImages = kinds.images !== false;
  const includeVideos = kinds.videos !== false;
  return uniqueStrings((rows || []).flatMap((row) => [
    ...(includeImages ? mediaIdsForRow(row, ["images", "imageVersions", "imageSlots"]) : []),
    ...(includeVideos ? mediaIdsForRow(row, ["videoVersions", "videos"], ["video", "latestVideo"]) : [])
  ]));
}

function repairReplacedMediaKinds(mode = "") {
  const normalized = String(mode || "").trim().replace(/[_\s]+/g, "-").toLowerCase();
  if (normalized === "image-only") return { images: true, videos: false };
  if (normalized === "images-and-video") return { images: true, videos: true };
  return { images: false, videos: true };
}

function mediaCountForRow(row = {}, arrayFields = [], objectFields = [], excludedMediaIds = new Set()) {
  return mediaIdsForRow(row, arrayFields, objectFields)
    .filter((mediaId) => !excludedMediaIds.has(mediaId))
    .length;
}

function mediaIdsForRow(row = {}, arrayFields = [], objectFields = []) {
  return uniqueStrings([
    ...arrayFields.flatMap((field) => Array.isArray(row[field])
      ? row[field].map((item) => item?.mediaId || item?.id || item?.name || item?.mediaName)
      : []),
    ...objectFields.map((field) => row[field]?.mediaId || row[field]?.id || row[field]?.name || row[field]?.mediaName)
  ]);
}

function mediaArray(row = {}, fields = []) {
  for (const field of fields) {
    if (Array.isArray(row[field])) return row[field];
  }
  return [];
}

function mergeSavedPaths(downloads = []) {
  return Object.assign({}, ...((downloads || []).map((download) => download.savedPaths || download.response?.paths || {})));
}

function sleepMs(ms = 0) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

async function runAgentBatch(args, context) {
  const bundle = await buildBundleFromArgs(args, context);
  if (!bundle) return invalidInput("autoflow_run_agent_batch requires inputPath, promptText, prompt, or matrix.");
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_run_agent_batch");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const refFields = agentRunRefPayloadFields(args);
  const runProfile = buildAgentRunProfile(bundle, { ...args, env: context.env || process.env });
  const runId = String(args.runId || "").trim() || createAgentRunId({ dryRun: args.dryRun === true });
  const prompt = prependAgentRunEnvelope(bundle.promptText, {
    runId,
    batchId: bundle.matrix?.batch?.batchId || "BATCH-001",
    rowCount: bundle.rowsBuilt ?? bundle.matrix?.rows?.length ?? 0,
    expectedImages: bundle.expectedImages ?? bundle.manifestExpectedImages ?? 0,
    expectedVideos: bundle.expectedVideos ?? bundle.manifestExpectedVideos ?? 0
  });
  const payload = {
    project: args.project || "current",
    mode: args.mode || "agent",
    prompt,
    runId,
    matrix: bundle.matrix,
    manifest: bundle.manifest,
    runProfile,
    attachments: refFields.attachments || [],
    ...refFields,
    ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {}),
    ...(isSubmitConfirmCreditsAuthorized(args, context.env || process.env) ? { confirmCredits: true } : {}),
    ...(args.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.prompt.submit", payload };
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_run_agent_batch",
      dryRun: true,
      bundle: summarizeBundle(bundle),
      runProfile,
      request
    };
  }
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);
  try {
    const bridgeResult = await requestBridge(request.type, payload, bridgeOptions(args, context));
    return {
      ok: true,
      tool: "autoflow_run_agent_batch",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      bundle: summarizeBundle(bundle),
      runProfile,
      response: unwrapBridgeResponse(bridgeResult)
    };
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, {
      tool: "autoflow_run_agent_batch",
      bundle: summarizeBundle(bundle)
    });
  }
}

function agentRunRefPayloadFields(args = {}) {
  const refs = [
    ...(Array.isArray(args.refs) ? args.refs : []),
    ...(Array.isArray(args.references) ? args.references : []),
    ...(Array.isArray(args.attachments) ? args.attachments : [])
  ];
  const targetRefs = Array.isArray(args.targetRefs) ? args.targetRefs : [];
  if (!refs.length && !targetRefs.length) return { attachments: [] };
  const plan = planAgentRefAttachments({
    refs,
    targetRefs,
    projectId: args.projectId,
    tabId: args.tabId
  }, {
    liveAttach: args.dryRun !== true,
    projectId: args.projectId,
    tabId: args.tabId
  });
  return {
    refs,
    targetRefs,
    attachments: [],
    refPlan: plan,
    ...(args.forceAttach === true || args.forceAttachRefs === true ? { forceAttach: true } : {}),
    ...(args.timeoutMs ? { attachTimeoutMs: args.timeoutMs } : {})
  };
}

async function submitAgentPrompt(args, context) {
  const prompt = String(args.prompt || "").trim() || renderMatrixPrompt(args.matrix);
  if (!prompt) return invalidInput("autoflow_submit_agent_prompt requires prompt or matrix.");
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_submit_agent_prompt");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const refFields = agentRunRefPayloadFields(args);
  const runProfile = buildAgentRunProfile({ matrix: args.matrix || {} }, { ...args, env: context.env || process.env });
  const payload = {
    project: args.project || "current",
    mode: args.mode || "agent",
    prompt,
    matrix: args.matrix || null,
    runProfile,
    attachments: refFields.attachments || [],
    ...refFields,
    ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {}),
    ...(isSubmitConfirmCreditsAuthorized(args, context.env || process.env) ? { confirmCredits: true } : {}),
    ...(args.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(args)
  };
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_submit_agent_prompt",
      dryRun: true,
      request: { type: "agent.prompt.submit", payload }
    };
  }
  const request = { type: "agent.prompt.submit", payload };
  if (args.dryRun !== true) {
    const targetError = liveAgentTargetError(args);
    if (targetError) return invalidInput(targetError);
  }
  const options = bridgeOptions(args, context);
  const contextPayload = {
    project: args.project || "current",
    includeRaw: args.includeRaw === true,
    ...agentTargetPayloadFields(args)
  };
  let bridgeResult;
  try {
    const baseline = args.waitForReply === true
      ? await requestAgentContextSnapshot(contextPayload, options)
      : null;
    const baselineKeys = new Set(latestAgentMessages(baseline).map(agentMessageKey));
    bridgeResult = await requestBridge(request.type, request.payload, options);
    const response = unwrapBridgeResponse(bridgeResult);
    const wait = args.waitForReply === true
      ? await waitForAgentReply({
        contextPayload,
        bridgeOptions: options,
        baselineKeys,
        prompt,
        accepted: response?.submitted === true || response?.accepted?.ok === true,
        acceptedSignal: response?.accepted?.signal || "",
        timeoutMs: args.waitTimeoutMs || args.replyTimeoutMs || 60000,
        pollMs: args.pollMs || args.pollIntervalMs || 1000
      })
      : { enabled: false };
    return {
      ok: wait.enabled ? wait.ok : true,
      tool: "autoflow_submit_agent_prompt",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      response,
      wait
    };
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_submit_agent_prompt" });
  }
}

const FLEET_GENERATE_DEFAULT_WAIT_MS = 600000;
const FLEET_GENERATE_TRANSPORT_GRACE_MS = 30000;

function fleetGenerateExplicitTimeoutMs(args = {}) {
  if (args.timeoutMs === undefined || args.timeoutMs === null || args.timeoutMs === "" || args.timeoutMs === true || args.timeoutMs === false) return null;
  const parsed = Number(args.timeoutMs);
  if (!Number.isFinite(parsed) || parsed <= 0) return null;
  return fleetBoundedInteger(parsed, 1000, 600000);
}

export function fleetGenerateWaitTimeoutMs(args = {}) {
  const explicit = fleetGenerateExplicitTimeoutMs(args);
  if (explicit) return explicit;
  return args.waitUntilDone === false ? null : FLEET_GENERATE_DEFAULT_WAIT_MS;
}

export function fleetGenerateBridgeOptions(args, context) {
  const options = bridgeOptions(args, context);
  const waitMs = fleetGenerateWaitTimeoutMs(args);
  if (waitMs) options.timeoutMs = waitMs + FLEET_GENERATE_TRANSPORT_GRACE_MS;
  return options;
}

async function fleetGenerate(args, context) {
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_fleet_generate");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const promptsText = fleetPromptsText(args);
  if (!promptsText) return invalidInput("autoflow_fleet_generate requires promptsText, promptText, prompt, or prompts.");
  const durationValidation = validateFleetDurationSecondsArgs(args);
  if (durationValidation) return durationValidation;
  const invalidMediaType = fleetGenInvalidMediaType(args);
  if (invalidMediaType) {
    return invalidInput("autoflow_fleet_generate type must be image or video (or a recognized alias like t2i/t2v/i2v/v2v).", {
      code: "FLEET_MEDIA_TYPE_INVALID",
      type: invalidMediaType
    });
  }
  const sourceRoleError = fleetGenSourceRoleError(args);
  if (sourceRoleError) {
    return invalidInput(sourceRoleError.message, { code: sourceRoleError.code });
  }
  if (args.dryRun !== true && hasStandingCreditLimit(args, context.env || process.env)) {
    return invalidInput("autoflow_fleet_generate cannot enforce maxCreditsPerRun on the Fleet Gen iframe path because Fleet Gen does not expose a stable credit prompt API; omit the cap for a captain-authorized bounded proof or use a path with observable credit prompts.", {
      code: "FLEETGEN_CREDIT_CAP_UNSUPPORTED"
    });
  }
  const manifestPathCheck = resolveFleetManifestOutputPath(args, context);
  if (!manifestPathCheck.ok) return manifestPathCheck.result;
  const promptRecords = fleetPromptRecords(args);
  const durationSeconds = fleetDurationSecondsFromArgs(args);
  const settings = fleetSettingsFromArgs(args);
  const idempotencyKey = compactString(args.idempotencyKey) || fleetGenerateIdempotencyKey({
    promptsText,
    settings,
    projectId: args.projectId,
    tabId: args.tabId,
    agentId: args.agentId,
    batchId: args.batchId,
    sessionId: args.sessionId,
    direct: args.direct === true || args.executeDirect === true
  });
  const payload = {
    project: args.project || "current",
    promptsText,
    prompts: promptRecords.map((record) => record.prompt),
    settings,
    idempotencyKey,
    ...(durationSeconds ? { durationSeconds } : {}),
    ...(promptRecords.some((record) => record.durationSeconds) ? { promptSettings: promptRecords.map((record, index) => ({
      index,
      prompt: record.prompt,
      ...(record.durationSeconds ? { durationSeconds: record.durationSeconds, duration: record.durationSeconds } : {})
    })) } : {}),
    ...(Array.isArray(args.referenceImageMediaIds) ? { referenceImageMediaIds: args.referenceImageMediaIds } : {}),
    ...(compactString(args.firstFrameImageMediaId || args.firstFrameMediaId || args.startFrameImageMediaId || args.startFrameMediaId)
      ? { firstFrameImageMediaId: compactString(args.firstFrameImageMediaId || args.firstFrameMediaId || args.startFrameImageMediaId || args.startFrameMediaId) }
      : {}),
    ...(compactString(args.lastFrameImageMediaId || args.lastFrameMediaId)
      ? { lastFrameImageMediaId: compactString(args.lastFrameImageMediaId || args.lastFrameMediaId) }
      : {}),
    ...(compactString(args.sourceVideoMediaId) ? { sourceVideoMediaId: compactString(args.sourceVideoMediaId) } : {}),
    ...(compactString(args.sourceVideoMode) ? { sourceVideoMode: compactString(args.sourceVideoMode) } : {}),
    ...(compactString(args.type || args.mediaType) ? { type: compactString(args.type || args.mediaType) } : {}),
    ...(compactString(args.mediaType) ? { mediaType: compactString(args.mediaType) } : {}),
    ...(compactString(args.model) ? { model: compactString(args.model) } : {}),
    ...(compactString(args.modelDisplayName) ? { modelDisplayName: compactString(args.modelDisplayName) } : {}),
    ...(compactString(args.imageModel) ? { imageModel: compactString(args.imageModel) } : {}),
    ...(compactString(args.videoModel) ? { videoModel: compactString(args.videoModel) } : {}),
    ...(compactString(args.aspectRatio) ? { aspectRatio: compactString(args.aspectRatio) } : {}),
    ...(fleetBoundedInteger(args.concurrency, 1, 12) ? { concurrency: fleetBoundedInteger(args.concurrency, 1, 12) } : {}),
    ...(fleetBoundedInteger(args.countPerPrompt, 1, 12) ? { countPerPrompt: fleetBoundedInteger(args.countPerPrompt, 1, 12) } : {}),
    ...(compactString(args.agentId) ? { agentId: compactString(args.agentId) } : {}),
    ...(compactString(args.batchId) ? { batchId: compactString(args.batchId) } : {}),
    ...(compactString(args.sessionId) ? { sessionId: compactString(args.sessionId) } : {}),
    ...(args.metadata && typeof args.metadata === "object" ? { metadata: args.metadata } : {}),
    ...(args.direct === true ? { direct: true } : {}),
    ...(args.executeDirect === true ? { executeDirect: true } : {}),
    ...(args.waitUntilDone === false ? { waitUntilDone: false } : {}),
    ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {}),
    ...(isSubmitConfirmCreditsAuthorized(args, context.env || process.env) ? { confirmCredits: true } : {}),
    ...(Number.isFinite(Number(args.maxCreditsPerRun)) ? { maxCreditsPerRun: Number(args.maxCreditsPerRun) } : {}),
    ...(args.pollMs ? { pollMs: Number(args.pollMs) } : {}),
    ...(args.commandTimeoutMs ? { commandTimeoutMs: Number(args.commandTimeoutMs) } : {}),
    ...(fleetGenerateWaitTimeoutMs(args) ? { timeoutMs: fleetGenerateWaitTimeoutMs(args) } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "fleet.generate", payload };
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_fleet_generate",
      dryRun: true,
      request
    };
  }
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);
  try {
    const bridgeResult = await requestBridge(request.type, request.payload, fleetGenerateBridgeOptions(args, context));
    const response = unwrapBridgeResponse(bridgeResult);
    const manifestPath = await writeFleetManifestIfRequested(response, args, context, manifestPathCheck.outPath);
    return {
      ok: response.ok !== false,
      tool: "autoflow_fleet_generate",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      mcpCommand: "autoflow_fleet_generate",
      bridgeCommand: "fleet.generate",
      manifestPath,
      mediaReturned: response.mediaReturned === true,
      mediaIds: Array.isArray(response.mediaIds) ? response.mediaIds : [],
      urls: Array.isArray(response.urls) ? response.urls : [],
      outbox: Array.isArray(response.outbox) ? response.outbox : [],
      response
    };
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_fleet_generate" });
  }
}

function fleetSettingsFromArgs(args = {}) {
  const settings = args.settings && typeof args.settings === "object" ? { ...args.settings } : {};
  const referenceImageMediaIds = Array.isArray(args.referenceImageMediaIds)
    ? args.referenceImageMediaIds.map(compactString).filter(Boolean)
    : [];
  const durationSeconds = fleetDurationSecondsFromArgs(args);
  const promptRecords = fleetPromptRecords(args);
  const mediaType = normalizeFleetMediaType(args.type || args.mediaType || settings.type || settings.mediaType)
    || (durationSeconds || compactString(args.videoModel) || fleetGenPerRowDurationPresent(args) ? "video" : "image");
  if (referenceImageMediaIds.length) settings.referenceImageMediaIds = referenceImageMediaIds;
  if (mediaType) {
    settings.type = mediaType;
    settings.mediaType = mediaType;
  }
  const requestedMode = compactString(args.type || args.mediaType).toLowerCase().replace(/_/g, "-");
  if (["t2i", "text-to-image", "t2v", "text-to-video", "i2v", "image-to-video", "v2v", "video-to-video"].includes(requestedMode)) {
    settings.generationMode = requestedMode;
  }
  if (compactString(args.model)) {
    settings.model = compactString(args.model);
    settings.modelDisplayName = settings.modelDisplayName || compactString(args.model);
    settings.imageModel = settings.imageModel || compactString(args.model);
    if (mediaType === "video") settings.videoModel = settings.videoModel || compactString(args.model);
  }
  if (compactString(args.modelDisplayName)) settings.modelDisplayName = compactString(args.modelDisplayName);
  if (compactString(args.imageModel)) settings.imageModel = compactString(args.imageModel);
  if (compactString(args.videoModel)) settings.videoModel = compactString(args.videoModel);
  if (compactString(args.aspectRatio)) settings.aspectRatio = compactString(args.aspectRatio);
  const firstFrameImageMediaId = compactString(args.firstFrameImageMediaId || args.firstFrameMediaId || args.startFrameImageMediaId || args.startFrameMediaId);
  const lastFrameImageMediaId = compactString(args.lastFrameImageMediaId || args.lastFrameMediaId);
  if (firstFrameImageMediaId) settings.firstFrameImageMediaId = firstFrameImageMediaId;
  if (lastFrameImageMediaId) settings.lastFrameImageMediaId = lastFrameImageMediaId;
  if (compactString(args.sourceVideoMediaId)) settings.sourceVideoMediaId = compactString(args.sourceVideoMediaId);
  if (compactString(args.sourceVideoMode)) settings.sourceVideoMode = compactString(args.sourceVideoMode);
  if (durationSeconds) {
    settings.duration = durationSeconds;
    settings.durationSeconds = durationSeconds;
  }
  if (promptRecords.some((record) => record.durationSeconds)) {
    settings.promptSettings = promptRecords.map((record, index) => ({
      index,
      prompt: record.prompt,
      ...(record.durationSeconds ? { durationSeconds: record.durationSeconds, duration: record.durationSeconds } : {})
    }));
    settings.promptDurations = promptRecords.map((record) => record.durationSeconds || durationSeconds || null);
  }
  if (fleetBoundedInteger(args.concurrency, 1, 12)) settings.concurrency = fleetBoundedInteger(args.concurrency, 1, 12);
  if (fleetBoundedInteger(args.countPerPrompt, 1, 12)) settings.countPerPrompt = fleetBoundedInteger(args.countPerPrompt, 1, 12);
  if ("concurrency" in settings) {
    const boundedConcurrency = fleetBoundedInteger(settings.concurrency, 1, 12);
    if (boundedConcurrency) settings.concurrency = boundedConcurrency;
    else delete settings.concurrency;
  }
  if ("countPerPrompt" in settings) {
    const boundedCount = fleetBoundedInteger(settings.countPerPrompt, 1, 12);
    if (boundedCount) settings.countPerPrompt = boundedCount;
    else delete settings.countPerPrompt;
  }
  if (compactString(args.agentId)) settings.agentId = compactString(args.agentId);
  if (compactString(args.batchId)) settings.batchId = compactString(args.batchId);
  if (compactString(args.sessionId)) settings.sessionId = compactString(args.sessionId);
  if (args.metadata && typeof args.metadata === "object") settings.metadata = args.metadata;
  return settings;
}

function fleetGenerateIdempotencyKey(input = {}) {
  return `fleet:${hashCompactString(JSON.stringify({
    promptsText: compactString(input.promptsText),
    settings: input.settings && typeof input.settings === "object" ? input.settings : {},
    projectId: compactString(input.projectId),
    tabId: compactString(input.tabId),
    agentId: compactString(input.agentId),
    batchId: compactString(input.batchId),
    sessionId: compactString(input.sessionId),
    direct: input.direct === true
  }))}`;
}

function fleetPromptLines(args = {}) {
  return fleetPromptRecords(args).map((record) => record.prompt);
}

function fleetPromptRecords(args = {}) {
  return fleetGenPromptRecordsFromInput(args);
}

function fleetPromptsText(args = {}) {
  return fleetPromptLines(args).join("\n");
}

function fleetBoundedInteger(value, min, max) {
  if (value === undefined || value === null || value === "" || value === true || value === false) return null;
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return null;
  return Math.min(max, Math.max(min, Math.floor(parsed)));
}

function normalizeFleetMediaType(value = "") {
  return fleetGenMediaTypeFromValue(value);
}

function fleetDurationSecondsFromArgs(args = {}) {
  return fleetGenDurationSecondsFromInput(args);
}

function validateFleetDurationSecondsArgs(args = {}) {
  const invalid = fleetGenInvalidDurationValue(args);
  if (invalid !== null) {
    return invalidInput("autoflow_fleet_generate durationSeconds must be one of 4, 6, or 8 seconds.", {
      code: "FLEET_DURATION_SECONDS_INVALID",
      durationSeconds: invalid
    });
  }
  return null;
}

function resolveFleetManifestOutputPath(args = {}, context = {}) {
  const requested = args.manifestPath || args.outboxPath || args.outputPath || args.out;
  if (!requested) return { ok: true, outPath: "" };
  const baseDir = path.resolve(context.cwd || process.cwd());
  const outPath = path.resolve(baseDir, String(requested));
  const relative = path.relative(baseDir, outPath);
  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    return {
      ok: false,
      result: invalidInput("autoflow_fleet_generate manifestPath must stay inside the current workspace.", {
        code: "FLEET_MANIFEST_PATH_OUTSIDE_WORKSPACE",
        baseDir,
        requested: String(requested)
      })
    };
  }
  return { ok: true, outPath };
}

async function writeFleetManifestIfRequested(response = {}, args = {}, context = {}, resolvedOutPath = "") {
  const requested = args.manifestPath || args.outboxPath || args.outputPath || args.out;
  if (!requested) return "";
  const outPath = resolvedOutPath || resolveFleetManifestOutputPath(args, context).outPath;
  await fs.mkdir(path.dirname(outPath), { recursive: true });
  await fs.writeFile(outPath, `${JSON.stringify(response.manifest || response, null, 2)}\n`);
  return outPath;
}

function hashCompactString(value = "") {
  let hash = 5381;
  const text = String(value || "");
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash + text.charCodeAt(index)) >>> 0;
  }
  return hash.toString(16);
}

async function attachRefs(args, context) {
  const liveAttach = args.dryRun !== true;
  const laneResolution = await resolveNamedLaneTargetArgsForTool(
    liveAttach ? args : { ...args, dryRun: true },
    context,
    "autoflow_attach_refs"
  );
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  if (liveAttach) {
    const targetError = liveAgentTargetError(args);
    if (targetError) return invalidInput(targetError);
  }
  const plan = planAgentRefAttachments(args, {
    liveAttach,
    projectId: args.projectId,
    tabId: args.tabId
  });
  if (plan.ok !== true) {
    return invalidInput(plan.message || "Agent ref attachment plan is invalid.", {
      code: plan.code,
      errors: plan.errors || [],
      plan
    });
  }
  const visibleChips = Array.isArray(args.visibleChips) ? args.visibleChips : [];
  const chipProof = visibleChips.length ? verifyAgentRefAttachmentChips(plan, visibleChips) : null;
  const payload = {
    project: args.project || "current",
    refs: Array.isArray(args.refs) ? args.refs : [],
    targetRefs: Array.isArray(args.targetRefs) ? args.targetRefs : [],
    visibleChips,
    plan: chipProof?.ok === true ? chipProof : plan,
    ...(args.forceAttach === true || args.forceAttachRefs === true ? { forceAttach: true } : {}),
    ...(args.timeoutMs ? { timeoutMs: args.timeoutMs } : {}),
    ...(args.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.refs.attach", payload };
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_attach_refs",
      dryRun: true,
      plan,
      chipProof,
      request
    };
  }
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, {
      tool: "autoflow_attach_refs",
      plan,
      chipProof
    });
  }
  return {
    ok: true,
    tool: "autoflow_attach_refs",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    plan,
    chipProof,
    response: unwrapBridgeResponse(bridgeResult)
  };
}

async function confirmCredits(args, context) {
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_confirm_credits");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);
  const payload = {
    project: args.project || "current",
    persistentApproval: args.persistentApproval === true || args.dontAskAgain === true,
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.credits.confirm", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_confirm_credits" });
  }
  return {
    ok: true,
    tool: "autoflow_confirm_credits",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    response: unwrapBridgeResponse(bridgeResult)
  };
}

function liveAgentTargetError(args = {}) {
  const missing = [];
  if (!String(args.projectId || "").trim()) missing.push("projectId");
  if (!String(args.tabId || "").trim()) missing.push("tabId");
  if (!missing.length) return "";
  return `live Agent submits require ${missing.join(" and ")}. Call autoflow_lane_inventory first and pass the exact Flow target.`;
}

function galleryDownloadTargetError(args = {}) {
  const missing = [];
  if (!String(args.projectId || "").trim()) missing.push("projectId");
  if (!String(args.tabId || "").trim()) missing.push("tabId");
  if (!missing.length) return "";
  return `gallery downloads require ${missing.join(" and ")} so downloads cannot target the wrong Flow tab.`;
}

function mcpDownloadFilenameOptions(args = {}, normalizeOptions = {}) {
  const normalized = normalizeDownloadFilenameOptions(args, normalizeOptions);
  if (normalized.ok) {
    const options = { ...normalized.options };
    const imageResolution = compactString(args.imageResolution || "");
    const videoResolution = compactString(args.videoResolution || "");
    if (imageResolution) options.imageResolution = imageResolution;
    if (videoResolution) options.videoResolution = videoResolution;
    return { options };
  }
  return { error: normalized.message };
}

function galleryArgsError(args = {}, keys = [], options = {}) {
  for (const key of keys) {
    if (!Object.hasOwn(args, key)) continue;
    const value = args[key];
    if (value === true || value === false || Array.isArray(value) || compactString(value) === "") {
      if (key === "mediaId" && options.mediaIdMessage) return options.mediaIdMessage;
      return `gallery ${key} must be a non-empty value.`;
    }
  }
  if (Object.hasOwn(args, "type") && !isKnownGalleryType(args.type)) {
    return "gallery type must be image, images, video, videos, or all.";
  }
  if (Object.hasOwn(args, "latest") && !isValidGalleryLatest(args.latest)) {
    return "gallery latest must be a positive integer.";
  }
  return "";
}

function galleryDownloadTimeoutMs(args = {}) {
  const value = args.timeoutMs || args.downloadTimeoutMs || args.downloadExecuteTimeoutMs;
  if (value === undefined || value === null || value === "" || value === true || value === false) return 600000;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 600000;
}

function hasExpectedCounts(args = {}) {
  return Number.isFinite(Number(args.expectedImages))
    || Number.isFinite(Number(args.expectedVideos))
    || Number.isFinite(Number(args.expectedImageCount))
    || Number.isFinite(Number(args.expectedVideoCount));
}

function renderWaitNextActions(wait = {}) {
  if (wait.ok) {
    return [
      "autoflow_wait_for_render downloads completed outputs by default. If downloadOnComplete=false was set, run autoflow_download_outputs with the returned reconciliation.",
      "If dialogue matters, transcribe the saved videos and call autoflow_qa_transcripts before marking the run done."
    ];
  }
  const missing = Array.isArray(wait.progress?.missingVideoTags) && wait.progress.missingVideoTags.length
    ? ` Missing rows: ${wait.progress.missingVideoTags.join(", ")}.`
    : "";
  return [
    `Call autoflow_agent_context before guessing why render did not finish.${missing}`,
    "If Flow Agent shows a policy/third-party/prominent-person blocker, use the returned retryPrompts or autoflow_retry_rows for only the missing rows.",
    "If Flow Agent is still running, keep waiting instead of re-submitting the entire batch."
  ];
}

function buildWaitAutoRetryPlan(args = {}) {
  const retryFailedGenerations = args.autoRetryFailures !== false && args.autoRetryFailedGenerations !== false;
  const retryMissingOutputs = args.autoRetryMissing === true || args.retryMissing === true;
  return {
    enabled: retryMissingOutputs || retryFailedGenerations,
    retryMissingOutputs,
    retryFailedGenerations,
    maxRounds: clampPositiveInteger(args.maxRetryRounds || args.retryRounds, 1),
    issue: String(args.retryIssue || "missing output"),
    mode: String(args.retryMode || "video-only"),
    notes: String(args.retryNotes || "Generate only the missing row outputs. Do not regenerate completed rows or create extra variations.")
  };
}

async function maybeRetryMissingRenderRows({
  wait,
  args = {},
  expectedManifest = null,
  options = {},
  waitOnce,
  env = process.env
} = {}) {
  const plan = buildWaitAutoRetryPlan(args);
  const hasRetryableWait = wait?.retryable === true && normalizeRetryRows(wait?.retry?.rows).length > 0;
  if ((!plan.enabled && !hasRetryableWait) || wait?.ok || typeof waitOnce !== "function") {
    return {
      ...plan,
      rounds: [],
      finalWait: wait
    };
  }

  const rounds = [];
  let currentWait = wait;
  for (let round = 1; round <= plan.maxRounds; round += 1) {
    const retry = currentWait?.retry || {};
    const hasExplicitRetry = currentWait?.retryable === true && normalizeRetryRows(retry.rows).length > 0;
    if (currentWait?.blocked === true && currentWait?.retryable !== true) break;
    if (hasExplicitRetry && !shouldAutoRetryAgentWait({ wait: currentWait, plan, options: args })) break;
    if (!plan.retryMissingOutputs && !hasExplicitRetry) break;
    const rows = normalizeRetryRows(retry.rows).length
      ? normalizeRetryRows(retry.rows)
      : missingRowsFromWaitProgress(currentWait);
    if (!rows.length) break;
    const issue = compactString(retry.issue) || plan.issue;
    const notes = compactString(retry.notes) || plan.notes;
    const retryPayload = buildRetryPayload(rows, {
      project: args.project || "current",
      issue,
      mode: compactString(retry.mode) || plan.mode,
      notes,
      runId: args.runId || "current",
      taskId: args.taskId,
      projectId: args.projectId,
      tabId: args.tabId,
      laneId: args.laneId,
      env,
      confirmCredits: isSubmitConfirmCreditsAuthorized(args, env),
      ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {})
    });
    const rowRetryPrompts = retryPromptsForRows(retry.retryPrompts, rows);
    const payload = {
      ...retryPayload,
      taskId: args.taskId || retryPayload.taskId || "",
      runId: args.runId || retryPayload.runId || "",
      expectedManifest,
      runProfile: buildAgentRunProfile({ manifest: expectedManifest }, { ...args, env }),
      ...(rowRetryPrompts.length ? { retryPrompts: rowRetryPrompts } : {}),
      ...agentTargetPayloadFields(args)
    };
    const request = { type: "agent.retry.submit", payload };
    const bridgeResult = await requestBridge(request.type, request.payload, options);
    currentWait = await waitOnce();
    rounds.push({
      round,
      rows,
      reason: currentWait?.blockedReason || currentWait?.blocker?.failureClass || "",
      request,
      response: unwrapBridgeResponse(bridgeResult),
      wait: currentWait
    });
    if (currentWait.ok) break;
  }

  return {
    ...plan,
    rounds,
    finalWait: currentWait
  };
}

async function retryRows(args, context) {
  if (!Array.isArray(args.rows) || !args.rows.length) return invalidInput("autoflow_retry_rows requires rows.");
  if (!args.issue) return invalidInput("autoflow_retry_rows requires issue.");
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_retry_rows");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  const retryPayload = buildRetryPayload(args.rows, {
    project: args.project || "current",
    issue: args.issue,
    issues: args.issues,
    notes: args.notes,
    mode: args.mode,
    runId: args.runId,
    taskId: args.taskId,
    projectId: args.projectId,
    tabId: args.tabId,
    laneId: args.laneId,
    env: context.env || process.env,
    confirmCredits: isSubmitConfirmCreditsAuthorized(args, context.env || process.env),
    ...(isCaptainExplicitlyAuthorized(args) ? { captainAuthorized: true } : {}),
    expectedDialogue: args.expectedDialogue,
    latestMediaContext: args.latestMediaContext
  });
  const payload = {
    ...retryPayload,
    taskId: args.taskId || retryPayload.taskId || "",
    runId: args.runId || retryPayload.runId || "",
    notes: args.notes || "",
    expectedManifest: args.expectedManifest || null,
    transcripts: Array.isArray(args.transcripts) ? args.transcripts : [],
    retryPrompts: buildRetryPrompts(args),
    ...(args.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(args)
  };
  const request = { type: "agent.retry.submit", payload };
  if (args.dryRun === true) {
    return {
      ok: true,
      tool: "autoflow_retry_rows",
      dryRun: true,
      request
    };
  }
  const targetError = liveAgentTargetError(args);
  if (targetError) return invalidInput(targetError);
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_retry_rows" });
  }
  return {
    ok: true,
    tool: "autoflow_retry_rows",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    payload,
    response: unwrapBridgeResponse(bridgeResult)
  };
}

function normalizeDownloadMediaIds(mediaIds = []) {
  return [...new Set((Array.isArray(mediaIds) ? mediaIds : [])
    .map((mediaId) => String(mediaId || "").trim())
    .filter(Boolean))];
}

async function downloadOutputs(args, context) {
  const reconciled = await readOptionalJson(args.reconciled, args.reconciledPath);
  const rows = Array.isArray(args.reconciledRows) ? args.reconciledRows : [];
  const hasReconciledRows = Boolean(reconciled) || rows.length > 0;
  const namingOptions = mcpDownloadFilenameOptions(args, {
    defaultStyle: hasReconciledRows ? "" : undefined
  });
  if (namingOptions.error) return invalidInput(namingOptions.error);
  if (reconciled || rows.length) {
    const requestedMediaIds = normalizeDownloadMediaIds(args.mediaIds);
    const scopedInput = scopeAgentArtifactInput(reconciled || { rows }, {
      rowIds: args.rowIds,
      mediaIds: args.mediaIds
    });
    const result = planAgentArtifacts(scopedInput, {
      runName: args.runName,
      outputRoot: args.outputRoot,
      only: args.only,
      qaStatuses: args.qaStatuses,
      latestOnly: requestedMediaIds.length ? false : args.latestOnly !== false,
      imageResolution: args.imageResolution,
      videoResolution: args.videoResolution,
      ...namingOptions.options
    });
    result.plan = scopeAgentArtifactPlan(result.plan, {
      rowIds: args.rowIds,
      mediaIds: args.mediaIds
    });
    const plan = result.plan;
    if (args.execute !== true) {
      return {
        ok: true,
        tool: "autoflow_download_outputs",
        execute: false,
        plan
      };
    }
    const mediaIds = mediaIdsFromAgentArtifactPlan(plan);
    const payload = {
      project: args.project || "current",
      taskId: args.taskId || "",
      runName: args.runName || "",
      outputRoot: args.outputRoot || "",
      rowIds: Array.isArray(args.rowIds) ? args.rowIds : [],
      mediaIds,
      reconciledRows: extractAgentArtifactRows(scopedInput),
      plan,
      latestOnly: requestedMediaIds.length ? false : args.latestOnly !== false,
      ...namingOptions.options,
      ...agentTargetPayloadFields(args)
    };
    return await executeDownloadPayload(payload, args, context);
  }
  const payload = {
    project: args.project || "current",
    taskId: args.taskId || "",
    runName: args.runName || "",
    outputRoot: args.outputRoot || "",
    rowIds: Array.isArray(args.rowIds) ? args.rowIds : [],
    mediaIds: Array.isArray(args.mediaIds) ? args.mediaIds : [],
    reconciledRows: rows,
    latestOnly: args.latestOnly !== false,
    imageResolution: args.imageResolution,
    videoResolution: args.videoResolution,
    ...namingOptions.options,
    ...agentTargetPayloadFields(args)
  };
  return await executeDownloadPayload(payload, args, context);
}

async function executeDownloadPayload(payload, args, context) {
  if (args.execute !== true) {
    return {
      ok: true,
      tool: "autoflow_download_outputs",
      execute: false,
      plan: payload
    };
  }
  const laneResolution = await resolveNamedLaneTargetArgsForTool(args, context, "autoflow_download_outputs");
  if (!laneResolution.ok) return laneResolution.result;
  args = laneResolution.args;
  payload = {
    ...payload,
    ...agentTargetPayloadFields(args)
  };
  if (!payload.taskId && !payload.mediaIds.length && !payload.reconciledRows.length) {
    return invalidInput("autoflow_download_outputs execute requires mediaIds, taskId, or reconciledRows.");
  }
  const targetError = liveAgentTargetError(payload);
  if (targetError) return invalidInput(`download execution requires ${targetError.replace(/^live Agent submits require\s+/, "")}`);
  // execute:true runs the real download inside the extension and returns mediaId -> absolute path.
  const request = { type: "downloads.execute", payload };
  let bridgeResult;
  try {
    bridgeResult = await requestBridge(request.type, payload, bridgeOptions(args, context));
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    return bridgeUnavailableWithRequest(error, request, { tool: "autoflow_download_outputs" });
  }
  const response = unwrapBridgeResponse(bridgeResult);
  const guidance = downloadFailureGuidance(response);
  return {
    ok: response.ok !== false,
    tool: "autoflow_download_outputs",
    source: "bridge",
    execute: true,
    bridgeHost: bridgeResult.host,
    savedPaths: response.paths || {},
    ...guidance,
    response
  };
}

function downloadFailureGuidance(response = {}) {
  const errors = Array.isArray(response.errors) ? response.errors : [];
  const authError = errors.find((entry) => {
    const code = String(entry?.code || "").toUpperCase();
    const failureClass = String(entry?.failureClass || "").toLowerCase();
    if (code === "FLOW_DOWNLOAD_AUTH_EXPIRED" || failureClass === "download_auth") return true;
    const error = String(entry?.error || "");
    if (!/^download_bad_content:html_/i.test(error)) return false;
    // Only positive image evidence (image kind, or an image filename) counts as auth
    // expiry. Video and genuinely-unknown media stay retryable so slow-but-valid video
    // readiness lag is never lifted into FLOW_DOWNLOAD_AUTH_EXPIRED guidance.
    return resolveDownloadMediaKind(
      entry?.kind || entry?.mediaKind,
      entry?.filename || entry?.plannedFilename || entry?.relativePath
    ) === "images";
  });
  if (!authError) return {};
  return {
    code: "FLOW_DOWNLOAD_AUTH_EXPIRED",
    failureClass: "download_auth",
    actionNeeded: authError.actionNeeded || "Refresh or re-authenticate the target Flow lane, then rerun reconcile and downloads. Do not regenerate the media just to fix downloads.",
    nextActions: Array.isArray(authError.nextActions) && authError.nextActions.length
      ? authError.nextActions
      : [
          "Refresh the exact Flow tab/project used for this run and confirm the Google/Flow session is still signed in.",
          "Rerun autoflow_reconcile_project with the same projectId/tabId.",
          "Rerun autoflow_download_outputs execute:true with the same reconciled rows."
        ]
  };
}

async function qaTranscripts(args) {
  if (!Array.isArray(args.rows) || !args.rows.length) return invalidInput("autoflow_qa_transcripts requires rows.");
  const result = await evaluateTranscriptRows(args.rows, {
    aliasMap: args.aliasMap,
    generateRetryPrompts: args.generateRetryPrompts !== false
  });
  return {
    ...result,
    tool: "autoflow_qa_transcripts"
  };
}

function reconcileProjectMetadata(projectMetadata, expectedManifest, options = {}) {
  if (expectedManifest) {
    return {
      tool: "autoflow_reconcile_project",
      fixturePath: options.fixturePath || "",
      ...reconcileExpectedProjectData(projectMetadata, expectedManifest, {
        source: options.source,
        includeRawRows: options.includeRawRows
      })
    };
  }
  const result = argsFixtureResult(projectMetadata, options);
  return {
    ok: true,
    tool: "autoflow_reconcile_project",
    ...result
  };
}

function argsFixtureResult(projectMetadata, options) {
  return reconcileProjectData(projectMetadata, {
    source: options.source,
    fixture: options.fixturePath || null
  });
}

function renderMatrixPrompt(matrix) {
  if (!matrix || typeof matrix !== "object") return "";
  return buildAgentPromptText(matrix);
}

async function buildBundleFromArgs(args = {}, context = {}) {
  const bundleArgs = stripLiveRefArgs(args);
  if (args.inputPath) {
    return await buildAgentPromptBundleFromFile(args.inputPath, {
      ...bundleArgs,
      cwd: context.cwd || process.cwd()
    });
  }
  const promptText = String(args.promptText || args.prompt || "").trim();
  if (promptText) {
    return await buildAgentPromptBundleFromText(promptText, {
      ...bundleArgs,
      cwd: context.cwd || process.cwd()
    });
  }
  if (args.matrix && typeof args.matrix === "object") {
    const prompt = buildAgentPromptText(args.matrix);
    return {
      ok: true,
      inputKind: "matrix",
      rowsBuilt: Array.isArray(args.matrix.rows) ? args.matrix.rows.length : 0,
      matrixKind: args.matrix.kind || "agent_matrix",
      expectedImages: args.matrix.expectedImages ?? 0,
      expectedVideos: args.matrix.expectedVideos ?? 0,
      manifestExpectedImages: args.matrix.manifest?.expectedImageCount ?? 0,
      manifestExpectedVideos: args.matrix.manifest?.expectedVideoCount ?? 0,
      matrix: args.matrix,
      manifest: args.matrix.manifest || null,
      promptText: prompt
    };
  }
  return null;
}

function stripLiveRefArgs(args = {}) {
  const {
    refs,
    references,
    attachments,
    targetRefs,
    visibleChips,
    refPlan,
    ...rest
  } = args || {};
  return rest;
}

function buildRetryPrompts(args = {}) {
  return (Array.isArray(args.rows) ? args.rows : []).map((rowId) => ({
    rowId,
    prompt: buildAgentRetryPrompt({
      sceneId: rowId,
      issues: args.issue === "other" ? "wrong dialogue" : args.issue,
      details: args.notes || "",
      expectedDialogue: dialogueForRow(rowId, args)
    })
  }));
}

function retryPromptsForRows(retryPrompts = [], rows = []) {
  const rowSet = new Set(normalizeRetryRows(rows).map((rowId) => rowId.toUpperCase()));
  return (Array.isArray(retryPrompts) ? retryPrompts : [])
    .map((entry) => ({
      rowId: normalizeRetryRowId(entry?.rowId),
      prompt: String(entry?.prompt || entry?.text || "").trim()
    }))
    .filter((entry) => entry.rowId && entry.prompt && (!rowSet.size || rowSet.has(entry.rowId.toUpperCase())));
}

function buildRetryPromptForRow(row = {}, qa = {}) {
  const chips = Array.isArray(row.issueChips) && row.issueChips.length
    ? row.issueChips
    : issuesFromQa(qa);
  if (!chips.length) return "";
  return buildAgentRetryPrompt({
    sceneId: row.rowId,
    issues: chips,
    details: row.notes || "",
    expectedDialogue: expectedDialogueText(row.expectedDialogue || [])
  });
}

function dialogueForRow(rowId, args = {}) {
  const transcriptRow = (Array.isArray(args.transcripts) ? args.transcripts : []).find((row) => row.rowId === rowId);
  return expectedDialogueText(transcriptRow?.expectedDialogue || []);
}

function expectedDialogueText(lines = []) {
  return (Array.isArray(lines) ? lines : [lines]).map((line) => {
    if (line && typeof line === "object") return line.text || line.dialogue || line.line || "";
    return line;
  }).map((line) => String(line || "").trim()).filter(Boolean);
}

function issuesFromQa(qa = {}) {
  const issueTypes = new Set((qa.issues || []).map((issue) => issue.type));
  const issues = [];
  if (issueTypes.has("ending_cutoff")) issues.push("ending cut off");
  if (issueTypes.has("missing_line") || issueTypes.has("missing_required_phrase")) issues.push("missing line");
  if (!issues.length && qa.level && qa.level !== "pass") issues.push("wrong dialogue");
  return issues;
}

function summarizeQa(rows = []) {
  const counts = rows.reduce((acc, row) => {
    acc[row.level] = (acc[row.level] || 0) + 1;
    return acc;
  }, {});
  return {
    total: rows.length,
    pass: counts.pass || 0,
    warn: counts.warn || 0,
    fail: counts.fail || 0,
    needsHumanReview: counts.needs_human_review || 0
  };
}

function summarizeBundle(bundle = {}) {
  return {
    inputKind: bundle.inputKind,
    rowsBuilt: bundle.rowsBuilt,
    matrixKind: bundle.matrixKind,
    expectedImages: bundle.expectedImages,
    expectedVideos: bundle.expectedVideos,
    manifestExpectedImages: bundle.manifestExpectedImages,
    manifestExpectedVideos: bundle.manifestExpectedVideos
  };
}

async function readOptionalJson(value, path) {
  if (value && typeof value === "object") return value;
  if (!path) return null;
  return await readJsonFile(path);
}

function bridgeOptions(args, context) {
  const stored = readMcpPairingCredential(args, context);
  return {
    cwd: context.cwd || process.cwd(),
    env: context.env || process.env,
    bridgeSocket: args.bridgeSocket,
    timeoutMs: args.timeoutMs,
    pairingToken: args.pairingToken || context.pairingToken || stored.pairingToken,
    clientId: args.clientId || context.clientId || stored.clientId,
    serviceWorkerRequired: true,
    commandFallback: false
  };
}

function bridgeTargetPayloadFields(args = {}, context = {}) {
  const fields = {};
  if (compactString(args.projectId)) fields.projectId = compactString(args.projectId);
  if (compactString(args.tabId)) fields.tabId = compactString(args.tabId);
  const laneId = laneIdFromArgs(args, context);
  if (laneId) fields.laneId = laneId;
  if (compactString(args.port)) fields.port = compactString(args.port);
  return fields;
}

function withLaneDefault(args = {}, context = {}) {
  const laneId = laneIdFromArgs(args, context);
  if (!laneId || compactString(args.laneId)) return args;
  return {
    ...args,
    laneId
  };
}

async function resolveNamedLaneTargetArgs(args = {}, context = {}) {
  const laneId = laneIdFromArgs(args, context);
  if (!laneId) return args;
  if (compactString(args.projectId) && compactString(args.tabId)) {
    return {
      ...args,
      laneId
    };
  }
  const payload = {
    laneId,
    ...bridgeTargetPayloadFields({ ...args, laneId }, context)
  };
  const bridgeResult = await requestBridge("lane.use", payload, bridgeOptions(args, context));
  const response = unwrapBridgeResponse(bridgeResult);
  const selected = response.selectedTarget || response.selectedExtension || response.selection || {};
  const projectId = compactString(selected.projectId || response.selection?.projectId);
  const tabId = compactString(selected.tabId || response.selection?.tabId);
  return {
    ...args,
    laneId: response.laneId || laneId,
    ...(projectId ? { projectId } : {}),
    ...(tabId ? { tabId } : {})
  };
}

async function resolveNamedLaneTargetArgsForTool(args = {}, context = {}, tool = "") {
  try {
    return {
      ok: true,
      args: args.dryRun === true ? withLaneDefault(args, context) : await resolveNamedLaneTargetArgs(args, context)
    };
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    const laneId = laneIdFromArgs(args, context);
    const request = {
      type: "lane.use",
      payload: {
        laneId,
        ...bridgeTargetPayloadFields({ ...args, laneId }, context)
      }
    };
    return {
      ok: false,
      result: bridgeUnavailableWithRequest(error, request, { tool })
    };
  }
}

function isRetryPayloadFallbackError(error) {
  if (error instanceof BridgeUnavailableError) return true;
  return error instanceof BridgeResponseError
    && compactString(error.code).toUpperCase() === "EXTENSION_BRIDGE_NOT_CONNECTED";
}

function laneIdFromArgs(args = {}, context = {}) {
  const env = context.env || process.env;
  return compactString(args.laneId || args.name || args.lane || args.laneName || env.AUTOFLOW_LANE || "");
}

function readMcpPairingCredential(args = {}, context = {}) {
  try {
    const credential = JSON.parse(fsSync.readFileSync(mcpPairingCredentialPath(args, context), "utf8"));
    return credential && typeof credential === "object" ? credential : {};
  } catch {
    return {};
  }
}

async function writeMcpPairingCredential(args = {}, context = {}, credential = {}) {
  const pairingToken = String(credential.pairingToken || "").trim();
  if (!pairingToken) return null;
  const filePath = mcpPairingCredentialPath(args, context);
  await fs.mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 });
  await fs.writeFile(filePath, `${JSON.stringify({
    pairingToken,
    clientId: credential.clientId || "autoflow-cli",
    pairedAt: credential.pairedAt || new Date().toISOString()
  }, null, 2)}\n`, { mode: 0o600 });
  await fs.chmod(filePath, 0o600).catch(() => {});
  return filePath;
}

function mcpPairingCredentialPath(args = {}, context = {}) {
  const env = context.env || process.env;
  if (args.pairingStore) return path.resolve(context.cwd || process.cwd(), String(args.pairingStore));
  if (env.AUTOFLOW_PAIRING_STORE) return path.resolve(env.AUTOFLOW_PAIRING_STORE);
  return path.join(getAutoFlowRuntimeDir({ env }), "cli-pairing.json");
}

function redactPairingToken(response = {}) {
  if (!response || typeof response !== "object" || !response.pairingToken) return response;
  const pairingToken = String(response.pairingToken || "");
  const preview = response.pairingTokenPreview || `${pairingToken.slice(0, 4)}...${pairingToken.slice(-4)}`;
  const { pairingToken: _pairingToken, ...rest } = response;
  return {
    ...rest,
    pairingTokenPreview: preview,
    pairingTokenStored: true
  };
}

function unwrapBridgeResponse(bridgeResult = {}) {
  return bridgeResult.response?.payload || bridgeResult.response?.result || bridgeResult.response || {};
}

function normalizeStatus(response = {}) {
  const bridge = response.bridge || response.nativeBridge || {};
  const extension = response.extension || {};
  const versions = response.versions || {};
  const nativeRuntime = response.nativeRuntime && typeof response.nativeRuntime === "object" ? response.nativeRuntime : null;
  const installedNativeHost = response.installedNativeHost && typeof response.installedNativeHost === "object" ? response.installedNativeHost : null;
  const runtime = response.runtime || {};
  const runtimeAgentBridge = runtime.agentBridge && typeof runtime.agentBridge === "object" ? runtime.agentBridge : {};
  const preferredTransport = response.preferredTransport || bridge.preferredTransport || runtimeAgentBridge.preferredTransport || "ws_broker";
  const activeTransport = response.activeTransport || bridge.activeTransport || runtimeAgentBridge.activeTransport || null;
  const packageVersion = nonblankVersion(
    bridge.packageVersion
      || versions.packageVersion
      || response.packageVersion
      || nativeRuntime?.packageVersion
      || installedNativeHost?.packageVersion
  );
  const extensionVersion = nonblankVersion(extension.version || versions.extensionVersion || response.extensionVersion);
  const nativeHostVersion = nonblankVersion(
    bridge.nativeHostVersion
      || versions.nativeHostVersion
      || response.nativeHostVersion
      || nativeRuntime?.nativeHostVersion
      || installedNativeHost?.nativeHostVersion
  );
  const bridgeProtocolVersion = positiveProtocolVersion(
    bridge.bridgeProtocolVersion
      ?? versions.bridgeProtocolVersion
      ?? response.bridgeProtocolVersion
      ?? nativeRuntime?.bridgeProtocolVersion
      ?? installedNativeHost?.bridgeProtocolVersion
  );
  const result = {
    bridge: {
      ...bridge,
      preferredTransport,
      activeTransport,
      packageVersion,
      nativeHostVersion,
      bridgeProtocolVersion
    },
    preferredTransport,
    activeTransport,
    transports: normalizeTransportDiagnostics(response.transports || bridge.transports || runtimeAgentBridge),
    extension: {
      ...extension,
      version: extensionVersion
    },
    versions: {
      extensionVersion,
      packageVersion,
      nativeHostVersion,
      bridgeProtocolVersion
    },
    auth: response.auth || response.session || {},
    project: response.project || response.flowProject || {},
    runtime,
    queue: response.queue || {},
    nativeRuntime,
    installedNativeHost,
    blockers: Array.isArray(response.blockers) ? response.blockers.filter((entry) => entry && typeof entry === "object") : [],
    raw: response
  };
  result.nativeHostHealth = buildNativeHostHealth(result);
  result.blockers = enrichNativeHostBlockers(result.blockers, result.nativeHostHealth);
  return result;
}

function nonblankVersion(value) {
  const text = String(value ?? "").trim();
  return text || UNKNOWN_VERSION;
}

function positiveProtocolVersion(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function normalizeTransportDiagnostics(value = {}) {
  const source = value && typeof value === "object" ? value : {};
  const ws = source.ws_broker && typeof source.ws_broker === "object" ? source.ws_broker : {};
  const cdp = source.cdp_bridge && typeof source.cdp_bridge === "object" ? source.cdp_bridge : {};
  const nativeLegacy = source.native_messaging_legacy && typeof source.native_messaging_legacy === "object"
    ? source.native_messaging_legacy
    : {};
  return {
    ws_broker: {
      enabled: ws.enabled === true,
      state: compactString(ws.state || (ws.connected ? "connected" : "unknown")),
      connected: ws.connected === true,
      brokenLink: compactString(ws.brokenLink),
      code: compactString(ws.code || ws.errorCode),
      nextAction: compactString(ws.nextAction),
      wsUrl: compactString(ws.wsUrl || ws.brokerUrl),
      httpUrl: compactString(ws.httpUrl)
    },
    cdp_bridge: {
      enabled: cdp.enabled === true,
      state: compactString(cdp.state || "dev_discovery_only"),
      connected: cdp.connected === true,
      brokenLink: compactString(cdp.brokenLink || "cdp_bridge.discovery_only"),
      code: compactString(cdp.code || cdp.errorCode || "CDP_DISCOVERY_ONLY"),
      nextAction: compactString(cdp.nextAction || "Ignore for normal onboarding; CDP is dev/discovery tooling only.")
    },
    native_messaging_legacy: {
      enabled: nativeLegacy.enabled === true,
      state: compactString(nativeLegacy.state || "disabled"),
      connected: nativeLegacy.connected === true,
      brokenLink: compactString(nativeLegacy.brokenLink || (nativeLegacy.connected ? "" : "native_messaging_legacy.disabled")),
      code: compactString(nativeLegacy.code || nativeLegacy.errorCode || (nativeLegacy.connected ? "" : "NATIVE_MESSAGING_LEGACY_DISABLED")),
      nextAction: compactString(nativeLegacy.nextAction || (nativeLegacy.connected ? "" : "No action needed unless legacy native messaging was explicitly enabled."))
    }
  };
}

function buildNativeHostHealth(result = {}) {
  const installed = result.installedNativeHost && typeof result.installedNativeHost === "object" ? result.installedNativeHost : {};
  const runtime = result.nativeRuntime && typeof result.nativeRuntime === "object" ? result.nativeRuntime : {};
  const blocker = statusBlocker(result, "STALE_NATIVE_HOST_PROCESS");
  const extensionId = chromeExtensionId(result.extension?.id || "");
  const installedExtensionId = chromeExtensionId(installed.extensionId || "");
  const actualOrigins = nativeHostActualOrigins(installed, installedExtensionId);
  const manifestPath = compactString(installed.manifestPath || installed.manifest || "");
  const hostPath = compactString(installed.hostPath || installed.path || installed.launcherPath || installed.hostScriptPath || runtime.hostScriptPath || "");
  const expectedOrigin = extensionId ? `chrome-extension://${extensionId}/` : "";
  const repairCommand = extensionId
    ? `autoflow native install-host --extension-id ${extensionId}`
    : "autoflow native install-host --extension-id <extension-id>";
  const mismatches = Array.isArray(blocker?.details?.mismatches) ? blocker.details.mismatches : [];

  return {
    state: blocker ? "stale_native_host" : (result.bridge?.state || "unknown"),
    actionable: Boolean(blocker || manifestPath || hostPath || expectedOrigin || actualOrigins.length),
    manifestPath,
    expectedOrigin,
    actualOrigin: actualOrigins[0] || "",
    actualOrigins,
    hostPath,
    hostScriptPath: compactString(installed.hostScriptPath || runtime.hostScriptPath || ""),
    runningHostPath: compactString(runtime.hostScriptPath || ""),
    repairCommand,
    restartRequirement: NATIVE_HOST_RESTART_REQUIREMENT,
    mismatches
  };
}

function nativeHostActualOrigins(installed = {}, installedExtensionId = "") {
  const explicit = Array.isArray(installed.allowedOrigins)
    ? installed.allowedOrigins
    : (Array.isArray(installed.allowed_origins) ? installed.allowed_origins : []);
  const origins = explicit
    .map((origin) => compactString(origin))
    .filter(Boolean);
  if (!origins.length && installedExtensionId) origins.push(`chrome-extension://${installedExtensionId}/`);
  return [...new Set(origins)];
}

function enrichNativeHostBlockers(blockers = [], nativeHostHealth = {}) {
  if (!Array.isArray(blockers) || !blockers.length) return blockers;
  return blockers.map((blocker) => {
    if (String(blocker?.code || "").toUpperCase() !== "STALE_NATIVE_HOST_PROCESS") return blocker;
    return {
      ...blocker,
      details: {
        ...(blocker.details || {}),
        actionable: nativeHostHealth
      }
    };
  });
}

function statusBlocker(result = {}, code = "") {
  const normalizedCode = String(code || "").toUpperCase();
  return (Array.isArray(result.blockers) ? result.blockers : []).find((blocker) => String(blocker?.code || "").toUpperCase() === normalizedCode) || null;
}

function chromeExtensionId(value = "") {
  const raw = compactString(value).replace(/^chrome-extension:\/\//i, "").replace(/\/$/, "");
  return /^[a-p]{32}$/i.test(raw) ? raw.toLowerCase() : "";
}

function clampPositiveInteger(value, fallback = 1) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 1) return fallback;
  return parsed;
}

function parseOptionalDate(value) {
  if (!value) return null;
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) {
    throw new Error("autoflow_build_smoke_pack now must be a valid ISO timestamp.");
  }
  return date;
}

function omitMediaRecords(reconciled = {}) {
  const { mediaRecords, ...rest } = reconciled;
  return rest;
}

async function requestAgentContextSnapshot(payload = {}, options = {}) {
  const bridgeResult = await requestBridge("agent.context.get", payload, options);
  return unwrapBridgeResponse(bridgeResult);
}

async function waitForAgentReply({
  contextPayload = {},
  bridgeOptions = {},
  baselineKeys = new Set(),
  prompt = "",
  accepted = false,
  acceptedSignal = "",
  timeoutMs = 60000,
  pollMs = 1000
} = {}) {
  const startedAt = Date.now();
  const timeout = Math.max(1000, Number(timeoutMs) || 60000);
  const interval = Math.max(250, Number(pollMs) || 1000);
  const promptText = String(prompt || "").replace(/\s+/g, " ").trim();
  let attempts = 0;
  let lastContext = null;
  let emptyConversationPolls = 0;
  while (Date.now() - startedAt < timeout) {
    attempts += 1;
    lastContext = await requestAgentContextSnapshot(contextPayload, bridgeOptions);
    const messages = latestAgentMessages(lastContext);
    const newMessages = messages.filter((message) => {
      const key = agentMessageKey(message);
      const text = String(message.text || "").replace(/\s+/g, " ").trim();
      return key && !baselineKeys.has(key) && text && text !== promptText;
    });
    if (newMessages.length) {
      return {
        enabled: true,
        ok: true,
        attempts,
        elapsedMs: Date.now() - startedAt,
        latestMessage: newMessages.at(-1),
        latestMessages: messages,
        context: lastContext
      };
    }
    const context = lastContext?.response || lastContext || {};
    const conversationHistoryDisappeared = accepted === true
      && baselineKeys.size > 0
      && messages.length === 0
      && context?.composer?.visible === true
      && context?.generationActive !== true
      && context?.composer?.generationActive !== true;
    emptyConversationPolls = conversationHistoryDisappeared ? emptyConversationPolls + 1 : 0;
    if (emptyConversationPolls >= 5) {
      return {
        enabled: true,
        ok: false,
        attempts,
        elapsedMs: Date.now() - startedAt,
        latestMessages: messages,
        context: lastContext,
        accepted: true,
        sideEffectRetryBlocked: true,
        reconcileOnly: true,
        error: {
          code: "AGENT_CHAT_SESSION_RESET_AFTER_ACCEPTANCE",
          message: "Flow accepted the chat submit, then the visible conversation history disappeared before a reply was observed. Do not submit the prompt again; reconcile the accepted session read-only."
        },
        details: {
          acceptedSignal: String(acceptedSignal || ""),
          baselineMessageCount: baselineKeys.size,
          emptyConversationPolls
        }
      };
    }
    await new Promise((resolve) => setTimeout(resolve, interval));
  }
  return {
    enabled: true,
    ok: false,
    attempts,
    elapsedMs: Date.now() - startedAt,
    latestMessages: latestAgentMessages(lastContext),
    context: lastContext,
    error: {
      code: "AGENT_REPLY_TIMEOUT",
      message: `No new visible Flow Agent reply detected within ${timeout}ms.`
    }
  };
}

function latestAgentMessages(context = {}) {
  const response = context.response || context;
  return Array.isArray(response.latestMessages) ? response.latestMessages : [];
}

function agentMessageKey(message = {}) {
  const text = String(message.text || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (!text) return "";
  return text;
}

function summarizeAgentContextForWait(context = {}) {
  return {
    state: context.state || "unknown",
    blockers: Array.isArray(context.blockers) ? context.blockers : [],
    retryPrompts: Array.isArray(context.retryPrompts) ? context.retryPrompts : [],
    latestMessages: Array.isArray(context.latestMessages) ? context.latestMessages.slice(-3) : [],
    uiState: context.uiState || {}
  };
}

async function maybeResolveAgentActionDuringWait({
  context = {},
  args = {},
  options = {},
  env = process.env,
  resolvedAgentActions = new Set(),
  creditPolicyState = createCreditPolicyState(buildStandingCreditPolicy(args, env))
} = {}) {
  const action = context?.uiState?.actionRequired || null;
  if (!action?.kind) return null;
  const key = agentActionResolutionKey(context, action);
  if (key && resolvedAgentActions.has(key)) return null;

  if (action.kind === "model_duration_choice" && action.autoResolvable === true && action.recommendedResponse) {
    if (key) resolvedAgentActions.add(key);
    const payload = {
      project: args.project || "current",
      mode: "agent",
      prompt: String(action.recommendedResponse || "").trim(),
      ...agentTargetPayloadFields(args)
    };
    const bridgeResult = await requestBridge("agent.prompt.submit", payload, options);
    return {
      stop: false,
      status: "action_resolved",
      reason: "agent_model_duration_choice_answered",
      actionRequired: compactAgentAction(action),
      actionResolution: {
        type: "agent_prompt_reply",
        request: { type: "agent.prompt.submit", payload },
        response: unwrapBridgeResponse(bridgeResult)
      }
    };
  }

  if (action.kind === "credit_confirmation") {
    const standingDecision = evaluateStandingCreditPolicy(action, context, creditPolicyState);
    const creditLimitConfigured = creditPolicyState.policy?.limitConfigured === true;
    const captainApproval = buildCaptainAuthorizedCreditApproval(args, env);
    const approvalDecision = resolveCreditApprovalDecision(standingDecision, captainApproval);
    if (!approvalDecision.approved) {
      const reason = creditApprovalBlockReason(standingDecision, creditLimitConfigured);
      return {
        stop: true,
        status: "waiting_for_credit_approval",
        reason,
        actionRequired: compactAgentAction(action),
        creditPolicy: {
          approved: false,
          reason: standingDecision.reason,
          creditAmount: standingDecision.creditAmount,
          remainingCredits: standingDecision.remainingCredits,
          creditCap: Number.isFinite(Number(creditPolicyState.policy?.maxCreditsPerRun))
            ? Number(creditPolicyState.policy.maxCreditsPerRun)
            : undefined
        }
      };
    }
    if (key) resolvedAgentActions.add(key);
    const payload = {
      project: args.project || "current",
      persistentApproval: resolveCreditPersistentApproval(approvalDecision, args),
      creditPromptEvent: compactAgentAction(action),
      ...agentTargetPayloadFields(args)
    };
    const bridgeResult = await requestBridge("agent.credits.confirm", payload, options);
    const response = unwrapBridgeResponse(bridgeResult);
    if (response?.confirmed === true) {
      if (key) resolvedAgentActions.add(key);
      return {
        stop: false,
        status: "action_resolved",
        reason: "agent_credit_confirmation_answered",
        actionRequired: compactAgentAction(action),
        actionResolution: {
          type: "credit_confirmation",
          request: { type: "agent.credits.confirm", payload },
          response,
          creditPolicy: approvalDecision
        }
      };
    }
    return {
      stop: true,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_confirmation_required",
      actionRequired: compactAgentAction(action),
      actionResolution: {
        type: "credit_confirmation",
        request: { type: "agent.credits.confirm", payload },
        response,
        creditPolicy: approvalDecision
      }
    };
  }

  return {
    stop: true,
    status: "waiting_for_user",
    reason: `agent_${String(action.kind || "message_response")}_required`,
    actionRequired: compactAgentAction(action)
  };
}

function agentActionResolutionKey(context = {}, action = {}) {
  const latest = Array.isArray(context.latestMessages) ? context.latestMessages.at(-1) : null;
  const text = String(latest?.text || action.recommendedResponse || action.recommendedAction || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (action.kind === "credit_confirmation") {
    const dialogKey = String(action.dialogId || action.id || latest?.id || text || "visible_dialog").trim().toLowerCase();
    return `credit_confirmation:${String(action.creditAmount || "").trim() || "unknown"}:${dialogKey}`;
  }
  return `${String(action.kind || "action").trim()}:${text}`;
}

function creditApprovalBlockReason(decision = {}, creditLimitConfigured = false) {
  if (creditLimitConfigured && decision.reason === "credit_policy_exceeded") return "agent_credit_cap_exceeded";
  if (decision.reason === "credit_amount_unknown") return "agent_credit_amount_unknown";
  return "agent_credit_confirmation_requires_captain_authorization";
}

function compactAgentAction(action = {}) {
  const compact = {
    kind: String(action.kind || "").trim(),
    autoResolvable: action.autoResolvable === true,
    recommendedResponse: String(action.recommendedResponse || "").trim(),
    recommendedAction: String(action.recommendedAction || "").trim(),
    defaultChoice: String(action.defaultChoice || "").trim(),
    choices: Array.isArray(action.choices) ? action.choices.map(compactAgentChoice).filter(Boolean).slice(0, 6) : []
  };
  if (action.draftHash) compact.draftHash = String(action.draftHash || "").trim();
  if (action.draftText) compact.draftText = String(action.draftText || "").trim();
  if (Number.isFinite(Number(action.creditAmount))) compact.creditAmount = Number(action.creditAmount);
  if (action.creditAmountKnown === true) compact.creditAmountKnown = true;
  if (action.freeTier === true) compact.freeTier = true;
  if (action.currency) compact.currency = String(action.currency || "").trim();
  return compact;
}

function compactAgentChoice(choice = "") {
  if (choice && typeof choice === "object") {
    const id = String(choice.id || "").trim();
    const label = String(choice.label || choice.text || id || "").trim();
    if (!id && !label) return null;
    return {
      id: id || label,
      label,
      persistent: choice.persistent === true
    };
  }
  const label = String(choice || "").trim();
  return label ? { id: "", label, persistent: false } : null;
}

function normalizeRetryRowId(value = "") {
  const entry = String(value || "").trim().replace(/^\[/, "").replace(/\]$/, "");
  return /^v\d+-s\d+(?:-img\d+)?$/i.test(entry) ? entry.toUpperCase() : entry;
}

function normalizeRetryRows(value = []) {
  return [...new Set((Array.isArray(value) ? value : [value])
    .map(normalizeRetryRowId)
    .filter(Boolean))];
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function uniqueStrings(values = []) {
  const list = values instanceof Set ? [...values] : (Array.isArray(values) ? values : [values]);
  return [...new Set(list.map((value) => String(value || "").trim()).filter(Boolean))];
}

const NON_TERMINAL_AGENT_STATE_CODES = new Set([
  "dispatch_uncertain",
  "visible_unmapped_output",
  "provisional_match",
  "waiting_for_agent",
  "waiting_for_choice",
  "policy_blocked"
]);

function bridgeResponseErrorCode(error) {
  return String(
    error?.code
    || error?.response?.error?.code
    || error?.response?.code
    || ""
  ).trim().toLowerCase();
}

function normalizeBridgeResponseDetails(error) {
  const details = error?.response?.error?.details || error?.response?.details || {};
  return details && typeof details === "object" ? details : {};
}

function suggestedNextActionsForNonTerminal(code) {
  if (code === "waiting_for_choice") return ["Read latestMessage and answer the visible Flow Agent choice before submitting new prompts."];
  if (code === "waiting_for_agent") return ["Wait for the Flow Agent to finish or call autoflow_wait_for_render with the same target."];
  if (code === "policy_blocked") return ["Ask the Flow Agent to rephrase the same intent at a safer level, then retry the blocked rows."];
  if (code === "visible_unmapped_output" || code === "provisional_match") return ["Preview or download visible candidates before regenerating; do not mark the row missing yet."];
  if (code === "dispatch_uncertain") return ["Check latestMessages and visibleCandidates; reconcile again before resubmitting."];
  return ["Inspect state and continue the Agent conversation instead of treating this as a terminal tool failure."];
}

function nonTerminalBridgeState(error) {
  const code = bridgeResponseErrorCode(error);
  if (!NON_TERMINAL_AGENT_STATE_CODES.has(code)) return null;
  const details = normalizeBridgeResponseDetails(error);
  return {
    ok: true,
    nonTerminal: true,
    code,
    state: compactString(details.state || code),
    message: compactString(error?.message || error?.response?.error?.message || code),
    latestMessage: compactString(details.latestMessage || details.latestAgentMessage || ""),
    latestMessages: Array.isArray(details.latestMessages) ? details.latestMessages : [],
    pendingControls: Array.isArray(details.pendingControls) ? details.pendingControls : [],
    visibleCandidates: Array.isArray(details.visibleCandidates) ? details.visibleCandidates : [],
    matchEvidence: details.matchEvidence || details.evidence || {},
    bridgeCapabilities: details.bridgeCapabilities || details.capabilities || {},
    nextActions: Array.isArray(details.nextActions) && details.nextActions.length
      ? details.nextActions
      : suggestedNextActionsForNonTerminal(code),
    response: error?.response || {}
  };
}

function normalizeToolError(error) {
  if (error instanceof BridgeUnavailableError) {
    return bridgeUnavailable({
      details: error.details || {}
    });
  }
  if (error instanceof BridgeResponseError) {
    const nonTerminal = nonTerminalBridgeState(error);
    if (nonTerminal) return nonTerminal;
    const authFailure = flowAuthFailureGuidance(error);
    if (authFailure) {
      return {
        ok: false,
        ...authFailure,
        details: { response: error.response }
      };
    }
    return toolFailure(
      String(error.code || "BRIDGE_ERROR").toUpperCase(),
      error.message,
      { response: error.response }
    );
  }
  return toolFailure("TOOL_EXECUTION_FAILED", error?.message || String(error));
}

function flowAuthFailureGuidance(error = {}) {
  if (!isFlowAuthExpiredError(error)) return null;
  return {
    code: "FLOW_AUTH_EXPIRED",
    failureClass: "flow_auth",
    message: "Flow page/API authentication expired for the target lane.",
    actionNeeded: "Refresh or re-authenticate the target Flow lane, then rerun the same read/download command. Do not regenerate media just to fix expired Flow auth.",
    nextActions: [
      "Refresh the exact Flow tab/project used for this run and confirm the Google/Flow session is still signed in.",
      "Rerun autoflow_status and the same reconcile/download tool with the same projectId/tabId.",
      "If auth still returns 401, switch to a lane where Flow metadata loads without an OAuth callback or sign-in page."
    ]
  };
}

function bridgeUnavailableWithRequest(error, request, extra = {}) {
  return bridgeUnavailable({
    ...extra,
    details: error.details || {},
    request,
    actionNeeded: "Enable Auto Flow Bridge in the extension and run autoflow_pair with action=start, then retry this request."
  });
}
