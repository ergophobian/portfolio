import { invalidInput, toMcpToolResult } from "./errors.js";
import { TOOL_DEFINITIONS, TOOL_NAMES } from "./tool-definitions.js";
import { runAutoFlowTool } from "./autoflow-tools.js";

const TOOL_SCHEMA_BY_NAME = new Map(TOOL_DEFINITIONS.map((tool) => [tool.name, tool.inputSchema]));

export async function callAutoFlowTool(name, args = {}, context = {}) {
  if (!TOOL_NAMES.has(name)) {
    return toMcpToolResult(invalidInput(`Unknown Auto Flow tool: ${name}`), { isError: true });
  }
  const validation = validateToolArgs(name, args);
  if (validation) return toMcpToolResult(validation, { isError: true });
  const payload = await runAutoFlowTool(name, args, context);
  return toMcpToolResult(payload);
}

function validateToolArgs(name, args = {}) {
  if (!args || typeof args !== "object" || Array.isArray(args)) {
    return invalidInput("Tool arguments must be a JSON object.");
  }
  const schemaIssue = validateJsonSchemaSubset(args, TOOL_SCHEMA_BY_NAME.get(name), name);
  if (schemaIssue) return invalidInput(schemaIssue.message, schemaIssue.details);
  if (name === "autoflow_run_agent_batch" && !hasText(args.inputPath) && !hasText(args.promptText) && !hasText(args.prompt) && !isObject(args.matrix)) {
    return invalidInput("autoflow_run_agent_batch requires inputPath, promptText, prompt, or matrix.");
  }
  if (name === "autoflow_submit_agent_prompt" && !hasText(args.prompt) && !isObject(args.matrix)) {
    return invalidInput("autoflow_submit_agent_prompt requires either prompt or matrix.");
  }
  if (name === "autoflow_retry_rows") {
    if (!Array.isArray(args.rows) || args.rows.length === 0) {
      return invalidInput("autoflow_retry_rows requires at least one row id.");
    }
    if (!hasText(args.issue)) {
      return invalidInput("autoflow_retry_rows requires an issue.");
    }
  }
  if (name === "autoflow_qa_transcripts" && (!Array.isArray(args.rows) || args.rows.length === 0)) {
    return invalidInput("autoflow_qa_transcripts requires at least one row.");
  }
  return null;
}

function validateJsonSchemaSubset(value, schema, path = "arguments") {
  if (!schema || typeof schema !== "object") return null;
  if (Array.isArray(schema.oneOf)) {
    const issues = schema.oneOf
      .map((candidate) => validateJsonSchemaSubset(value, candidate, path))
      .filter(Boolean);
    return issues.length === schema.oneOf.length
      ? { message: `${path} does not match any supported schema.`, details: { path, issues } }
      : null;
  }
  if (schema.type) {
    const typeIssue = validateJsonType(value, schema.type, path);
    if (typeIssue) return typeIssue;
  }
  if (Array.isArray(schema.enum) && !schema.enum.includes(value)) {
    return { message: `${path} must be one of: ${schema.enum.join(", ")}.`, details: { path, allowed: schema.enum } };
  }
  if (schema.type === "integer") {
    if (Number.isFinite(schema.minimum) && value < schema.minimum) {
      return { message: `${path} must be at least ${schema.minimum}.`, details: { path, minimum: schema.minimum } };
    }
    if (Number.isFinite(schema.maximum) && value > schema.maximum) {
      return { message: `${path} must be at most ${schema.maximum}.`, details: { path, maximum: schema.maximum } };
    }
  }
  if (schema.type === "array") {
    if (Number.isFinite(schema.minItems) && value.length < schema.minItems) {
      return { message: `${path} must include at least ${schema.minItems} item${schema.minItems === 1 ? "" : "s"}.`, details: { path, minItems: schema.minItems } };
    }
    if (schema.items) {
      for (let index = 0; index < value.length; index += 1) {
        const issue = validateJsonSchemaSubset(value[index], schema.items, `${path}[${index}]`);
        if (issue) return issue;
      }
    }
  }
  if (schema.type === "object") {
    const properties = schema.properties || {};
    for (const required of schema.required || []) {
      if (!Object.prototype.hasOwnProperty.call(value, required)) {
        return { message: `${path}.${required} is required.`, details: { path: `${path}.${required}` } };
      }
    }
    for (const key of Object.keys(value)) {
      if (!Object.prototype.hasOwnProperty.call(properties, key)) {
        if (schema.additionalProperties === false) {
          return { message: `${path}.${key} is not a supported argument.`, details: { path: `${path}.${key}` } };
        }
        if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
          const issue = validateJsonSchemaSubset(value[key], schema.additionalProperties, `${path}.${key}`);
          if (issue) return issue;
        }
        continue;
      }
      const issue = validateJsonSchemaSubset(value[key], properties[key], `${path}.${key}`);
      if (issue) return issue;
    }
  }
  return null;
}

function validateJsonType(value, type, path) {
  if (type === "integer") {
    return Number.isInteger(value)
      ? null
      : { message: `${path} must be an integer.`, details: { path, expectedType: type } };
  }
  if (type === "array") {
    return Array.isArray(value)
      ? null
      : { message: `${path} must be an array.`, details: { path, expectedType: type } };
  }
  if (type === "object") {
    return isObject(value)
      ? null
      : { message: `${path} must be an object.`, details: { path, expectedType: type } };
  }
  if (type === "boolean") {
    return typeof value === "boolean"
      ? null
      : { message: `${path} must be a boolean.`, details: { path, expectedType: type } };
  }
  if (type === "string") {
    return typeof value === "string"
      ? null
      : { message: `${path} must be a string.`, details: { path, expectedType: type } };
  }
  return null;
}

function hasText(value) {
  return typeof value === "string" && value.trim().length > 0;
}

function isObject(value) {
  return value && typeof value === "object" && !Array.isArray(value);
}
