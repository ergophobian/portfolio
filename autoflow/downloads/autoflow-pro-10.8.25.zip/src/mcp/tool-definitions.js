import {
  DOWNLOAD_FILENAME_STYLES,
  TEMPLATE_DATES,
  TEMPLATE_INDEXES,
  TEMPLATE_PROMPT_PARTS,
  TEMPLATE_SEPARATORS,
  TEMPLATE_SUFFIXES
} from "../core/gallery/download-filename-options.js";

const stringArray = {
  type: "array",
  items: { type: "string" },
  default: []
};

const attachmentSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    path: { type: "string", description: "Absolute local path to an attachment." },
    role: { type: "string", description: "Reference role, such as product, identity, style, start_frame, or end_frame." },
    handle: { type: "string", description: "Stable handle used inside the Agent prompt." },
    mediaId: { type: "string", description: "Existing Flow media id when already uploaded." },
    sha256: { type: "string", description: "Optional content hash for auditability." }
  }
};

const agentRefAttachmentSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    handle: { type: "string", description: "Stable prompt handle, such as HOST_001 or PRODUCT_REF." },
    sourceType: { type: "string", enum: ["local-upload", "flow-generated"], description: "Reference source type." },
    path: { type: "string", description: "Absolute local file path for local-upload refs." },
    from: { type: "string", description: "Flow source shorthand, for example flow:V1-S1/media-id." },
    rowId: { type: "string", description: "Source row id for a Flow-generated ref." },
    mediaId: { type: "string", description: "Source Flow media id for a Flow-generated ref." }
  }
};

const autonomySchema = {
  type: "string",
  enum: ["none", "credit-only", "full-self-heal"],
  default: "full-self-heal",
  description: "How much autonomy Flow Agent has after submit. full-self-heal lets Flow Agent rewrite blocked/missing/failed rows at the same intent level before escalating."
};

const autoApproveSchema = {
  type: "string",
  default: "rephrases,missing_outputs",
  description: "Comma-separated approvals for the automation loop. Supported: rephrases, missing_outputs, credits. Credits still require explicit user approval before use."
};

const maxSelfHealRetriesSchema = {
  type: "integer",
  minimum: 0,
  maximum: 5,
  default: 2,
  description: "Maximum safe at-level Flow Agent repair attempts per affected row before escalating."
};

const suppressOnScreenTextSchema = {
  type: "boolean",
  default: true,
  description: "Ask Flow Agent to suppress unintended on-screen text, subtitles, captions, labels, watermarks, and AFID text."
};

const filenameNamingSchema = {
  type: "object",
  additionalProperties: false,
  description: "Download filename naming. Valid styles: auto_flow ({V#-S#}_{letter}_{slug}.{ext}), detailed ({NN}_{letter}_{slug}.{ext}), prompt_prefix ({slug}_{NN}_{letter}.{ext}), custom_template (template fields below). For reconciledRows, omit this to keep the agent artifact convention with row/slot/version/media-id names; for raw mediaIds and gallery downloads the default style is auto_flow.",
  properties: {
    style: {
      type: "string",
      enum: DOWNLOAD_FILENAME_STYLES,
      description: "Filename style. Valid values: auto_flow, detailed, prompt_prefix, custom_template."
    },
    template: {
      type: "object",
      additionalProperties: false,
      description: "Used when style is custom_template. If any template field is supplied without style, custom_template is assumed.",
      properties: {
        prefix: { type: "string", description: "Optional filename prefix." },
        index: { type: "string", enum: TEMPLATE_INDEXES, default: "nn" },
        promptPart: { type: "string", enum: TEMPLATE_PROMPT_PARTS, default: "first_3_words" },
        date: { type: "string", enum: TEMPLATE_DATES, default: "none" },
        suffix: { type: "string", enum: TEMPLATE_SUFFIXES, default: "none" },
        separator: { type: "string", enum: TEMPLATE_SEPARATORS, default: "_" }
      }
    }
  }
};

const transcriptRowSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    rowId: { type: "string", description: "Stable row id, for example V1-S1." },
    expectedDialogue: {
      type: "array",
      description: "Dialogue lines or required phrases expected in the output.",
      items: {
        oneOf: [
          { type: "string" },
          {
            type: "object",
            additionalProperties: true,
            properties: {
              speaker: { type: "string" },
              text: { type: "string" }
            },
            required: ["text"]
          }
        ]
      },
      default: []
    },
    transcript: { type: "string", description: "Transcript text to QA." },
    transcriptPath: { type: "string", description: "Optional local transcript file path." },
    issueChips: {
      type: "array",
      items: {
        type: "string",
        enum: [
          "wrong speaker",
          "wrong dialogue",
          "missing line",
          "ending cut off",
          "identity drift",
          "outfit drift",
          "wrong product",
          "bad vial",
          "bad timing"
        ]
      },
      default: []
    },
    notes: { type: "string", description: "Human QA notes to include in retry generation." }
  },
  required: ["rowId"]
};

export const TOOL_DEFINITIONS = [
  {
    name: "autoflow_context",
    title: "Get Auto Flow Generation Context",
    description: "Return read-only operating context for Auto Flow generation. Fleet Gen is the default creation path through autoflow_fleet_generate; Agent Mode/DOM remain optional repair, legacy queue, and fallback paths. Call before planning live generation. Show the defaults first, then ask only for overrides or unknown required values. Cheapest/cost-safe video default is Veo 3.1 - Lite [Lower Priority]; Omni Flash is not the cheapest and is for Omni-specific workflows after approval.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {}
    }
  },
  {
    name: "autoflow_pair",
    title: "Pair Auto Flow Bridge",
    description: "Start, confirm, or inspect Auto Flow Bridge pairing over the WS broker happy path. The package broker auto-starts locally; preserve the sidepanel Pair Bridge approval click. Do not chase CDP ports or native-host restarts unless ws_broker diagnostics explicitly say legacy fallback is enabled.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        action: {
          type: "string",
          enum: ["start", "confirm", "status"],
          default: "start"
        },
        pairingCode: {
          type: "string",
          description: "Short code shown by the extension when confirming a pairing request."
        },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_bridge_targets",
    title: "List Auto Flow Bridge Targets",
    description: "List every connected Auto Flow extension target known to the package broker, including stale and selected lane targets. Uses ws_broker by default; CDP is only a diagnostic hint.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        projectId: { type: "string", description: "Optional requested Flow project id to compare against connected targets." },
        tabId: { type: "string", description: "Optional requested Chrome tab id to compare against connected targets." },
        laneId: { type: "string", description: "Optional lane label whose selected target should be returned." },
        port: { type: "string", description: "Optional CDP port hint used for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      }
    }
  },
  {
    name: "autoflow_fleetgen",
    title: "Run Flow Tool Builder Fleet Gen Command",
    description: "Call the in-Flow Tool Builder window.fleetGen page bridge through Auto Flow's ws_broker transport. Supported methods include setPrompts, updateSettings, launch, executeDirect, getCapabilities, normalizeInputs, getState, getStatus, getResult, and getOutbox when the saved tool exposes them. This is not Playwright/CDP browser control; it runs inside the Flow page context and fails closed if window.fleetGen is absent.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        method: { type: "string", enum: ["setPrompts", "updateSettings", "launch", "executeDirect", "getCapabilities", "normalizeInputs", "getState", "getStatus", "getResult", "getOutbox"] },
        prompts: { type: "array", items: { type: "string" }, default: [] },
        settings: { type: "object", additionalProperties: true },
        prompt: { type: "string", description: "Prompt for executeDirect." },
        options: { type: "object", additionalProperties: true, description: "Atomic options for executeDirect, launch, or normalizeInputs." },
        commandId: { type: "string", description: "Command id for getResult when the saved tool exposes a durable outbox." },
        captainAuthorized: { type: "boolean", description: "Required true for launch/executeDirect because those methods can spend generation credits." },
        projectId: { type: "string", description: "Optional Flow project id to fail closed against." },
        tabId: { type: "string", description: "Optional Chrome tab id to fail closed against." },
        laneId: { type: "string", description: "Optional named lane target." },
        bridgeSocket: { type: "string", description: "Broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      },
      required: ["method"]
    }
  },
  {
    name: "autoflow_bridge_use",
    title: "Select Auto Flow Bridge Target",
    description: "Bind a lane id to a specific connected Auto Flow extension target. Later lane-aware tools route to that selected target and fail closed on mismatch.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        projectId: { type: "string", description: "Required Flow project id to bind." },
        tabId: { type: "string", description: "Required Chrome tab id to bind." },
        laneId: { type: "string", description: "Required lane label to persist, for example t5-rc." },
        port: { type: "string", description: "Optional CDP port hint used for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      },
      required: ["projectId", "tabId", "laneId"]
    }
  },
  {
    name: "autoflow_lane_use",
    title: "Use Named Auto Flow Lane",
    description: "Bind or resolve a human named lane such as fruit-vids or peak-revival to one exact Flow project tab. If the lane already exists and Chrome restarted, it rebinds by saved project only when exactly one matching tab is open. If the bound tab is gone or two tabs share the same project, it fails closed with the re-bind command instead of choosing another tab.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        name: { type: "string", description: "Human lane name, for example fruit-vids. Alias: laneId." },
        laneId: { type: "string", description: "Lane name alias for callers that already use laneId." },
        projectId: { type: "string", description: "Optional Flow project id. Required with tabId to bind a specific tab." },
        tabId: { type: "string", description: "Optional Chrome tab id from autoflow_flow_tabs or autoflow_lane_inventory." },
        port: { type: "string", description: "Optional CDP port hint used for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      }
    }
  },
  {
    name: "autoflow_lane_list",
    title: "List Named Auto Flow Lanes",
    description: "List persisted named lanes with name, projectId, tabId, connected state, last-used time, and the exact re-bind command for gone or ambiguous lanes. Use this before multi-terminal work to confirm each terminal is on the intended Flow tab.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      }
    }
  },
  {
    name: "autoflow_lane_unbind",
    title: "Unbind Named Auto Flow Lane",
    description: "Remove a persisted named lane without closing Chrome tabs. Use when a terminal should stop targeting an old Flow project/tab.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        name: { type: "string", description: "Human lane name to remove. Alias: laneId." },
        laneId: { type: "string", description: "Lane name alias." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      }
    }
  },
  {
    name: "autoflow_status",
    title: "Get Auto Flow Status",
    description: "Return bridge, extension, queue, and active Flow project status when available.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Optional expected Flow project id for lane-aware status." },
        tabId: { type: "string", description: "Optional expected Chrome tab id for lane-aware status." },
        laneId: { type: "string", description: "Optional selected bridge lane id, for example t5-rc." },
        port: { type: "string", description: "Optional CDP port hint used for diagnostics." },
        includeRuntime: { type: "boolean", default: true },
        includeProject: { type: "boolean", default: true },
        includeQueue: { type: "boolean", default: true },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 15000 }
      }
    }
  },
  {
    name: "autoflow_connect",
    title: "Connect This Flow Tab",
    description: "Attach the exact Google Flow project tab so CLI/MCP commands can run. Recovers the page bridge in the same Chrome profile/window, then proves agent context is available. Call this when autoflow_flow_state or autoflow_agent_context returns context_unavailable / flow_bridge_degraded. Fails closed on target ambiguity or another window/profile. Does not generate or spend credits.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        projectId: { type: "string", description: "Optional expected Flow project id. If provided and the resolved tab differs, the command fails closed." },
        tabId: { type: "string", description: "Optional expected Chrome tab id. Use autoflow_flow_tabs or autoflow_status when more than one Flow tab is open." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_flow_state",
    title: "Read Flow UI State Snapshot",
    description: "Read one compact, read-only snapshot of the current Google Flow UI state. Call this before any write action (submit, retry, refs attach, credit confirm, download execute) and after any tool error. Fields: page is the current Flow project/tab; mode/settings are the visible or prompt-store generation settings, with unknown when not readable; dialogs lists open confirm/continue/credits/upload dialogs; buttons lists visible decision buttons; composerReady says whether the resolved composer target can accept a write now; auth.valid reports Auto Flow session validity; pending reports active generation, queue, blockers, and pending Agent choices. It fails closed with a precondition code for bridge_down, extension_asleep, page_not_flow, or context_unavailable instead of guessing.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Optional expected Flow project id. If provided and the active tab differs, the command fails closed." },
        tabId: { type: "string", description: "Optional expected Chrome tab id. Use the value from autoflow_flow_state.page or autoflow_flow_tabs for exact targeting." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        expectedManifest: {
          type: "object",
          additionalProperties: true,
          description: "Optional expected Agent manifest or matrix with rows. Used only to map visible blockers; this tool never submits."
        },
        expectedManifestPath: { type: "string", description: "Optional path to a JSON expected manifest." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 10000 }
      }
    }
  },
  {
    name: "autoflow_agent_context",
    title: "Read Live Flow Agent Screen",
    description: "Read the active Flow Agent screen through the paired extension. Use this after reconcile says an output is missing/stalled or when Flow shows a failed/policy card. Returns latestMessages, uiState, blockers, and retryPrompts so the caller can answer the Flow Agent's visible question or retry the affected row without guessing; it does not submit or spend credits.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Optional expected Flow project id. If provided and the active tab differs, the command fails closed." },
        tabId: { type: "string", description: "Optional expected Chrome tab id. Use the value from autoflow_status for exact targeting." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        expectedManifest: {
          type: "object",
          additionalProperties: true,
          description: "Expected Agent manifest or matrix with rows. Used to assign visible blockers to row ids."
        },
        expectedManifestPath: { type: "string", description: "Optional path to a JSON expected manifest." },
        includeRaw: { type: "boolean", default: false, description: "Include raw visible screen blocks. Leave false for compact agent repair context." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 10000 }
      }
    }
  },
  {
    name: "autoflow_agent_screenshot",
    title: "Capture Flow Agent Screenshot",
    description: "Capture the current Flow project tab through the paired Auto Flow extension and save it to a local image file. Use this when text context is ambiguous and the agent needs to visually inspect the page before deciding the next action.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Optional expected Flow project id. If provided and the active tab differs, the command fails closed." },
        tabId: { type: "string", description: "Optional expected Chrome tab id. Use the value from autoflow_status for exact targeting." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        out: { type: "string", description: "Local output path. Defaults to .context/autoflow-agent-screenshot-<timestamp>.jpg." },
        format: { type: "string", enum: ["jpeg", "png"], default: "jpeg" },
        quality: { type: "integer", minimum: 30, maximum: 90, default: 65 },
        fullPage: { type: "boolean", default: false },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 10000 }
      }
    }
  },
  {
    name: "autoflow_lane_inventory",
    title: "Inventory Auto Flow Lane",
    description: "Read CDP targets and summarize the mounted extension, Flow project tabs, and live-submit blockers. This tool does not submit jobs or run shell commands.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        port: { type: "string", default: "9222", description: "Local Chrome DevTools Protocol port to inspect." },
        extensionId: { type: "string", description: "Expected mounted Auto Flow extension id." },
        cdpTargets: {
          type: "array",
          items: { type: "object", additionalProperties: true },
          description: "Optional already-fetched /json/list targets for deterministic read-only analysis."
        },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 5000 }
      }
    }
  },
  {
    name: "autoflow_flow_tabs",
    title: "List Flow Tab Targets",
    description: "Ask the paired Auto Flow extension for exact open Flow project tabs, including Chrome tabId and Flow projectId. Use this before any live Agent submit when multiple Flow tabs are open.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Optional Flow project id filter. Omit to list all open Flow project tabs." },
        laneId: { type: "string", description: "Optional lane label to include in returned target snippets." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_build_smoke_pack",
    title: "Build Agent Smoke Pack",
    description: "Prepare guarded Agent Mode smoke prompts, QA rows, and command text without writing files or submitting generation.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        runId: { type: "string", description: "Optional stable run id." },
        out: { type: "string", default: ".context/agent-live-smoke", description: "Output root used in returned path planning only." },
        port: { type: "string", default: "9222" },
        extensionId: { type: "string", description: "Mounted extension id to place in the guarded command text." },
        imageTag: { type: "string", description: "Optional stable Create Image tag." },
        videoTag: { type: "string", description: "Optional stable Text-to-Video tag." },
        now: { type: "string", description: "Optional ISO timestamp for deterministic tag generation." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_reconcile_project",
    title: "Reconcile Flow Project",
    description: "Map expected Agent Mode rows to current Flow project media metadata.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        expectedManifest: {
          type: "object",
          additionalProperties: true,
          description: "Expected Agent manifest or matrix with rows."
        },
        expectedManifestPath: { type: "string", description: "Optional path to a JSON expected manifest." },
        projectMetadata: {
          type: "object",
          additionalProperties: true,
          description: "Optional raw Flow project metadata. If omitted, the bridge fetches current metadata."
        },
        fixturePath: { type: "string", description: "Optional local Flow projectInitialData JSON fixture." },
        includeRawRows: { type: "boolean", default: false },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_wait_for_render",
    title: "Wait For Agent Render",
    description: "Long-poll the live Flow project until the expected Agent manifest is complete or the wait times out. Call this after submit or retry so Claude/Codex auto-resumes with progress instead of stopping after a partial batch. Completed runs auto-download by default through autoflow_download_outputs when expectedManifest/expectedManifestPath is supplied; set downloadOnComplete=false for count-only waits or when the caller explicitly opts out. Visible retryable Flow failures, such as unbilled failed-generation cards, are mapped to the affected row and retried once when safe; ambiguous failures return row candidates instead of guessing.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        tabId: { type: "string", description: "Target Chrome tab id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        laneId: { type: "string", description: "Named lane to resolve before waiting. Defaults to AUTOFLOW_LANE when set." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        expectedManifest: {
          type: "object",
          additionalProperties: true,
          description: "Expected Agent manifest or matrix with rows. Preferred because it lets the wait identify missing row ids."
        },
        expectedManifestPath: { type: "string", description: "Optional path to a JSON expected manifest." },
        expectedImages: { type: "integer", minimum: 0, description: "Fallback expected image count when no manifest is available." },
        expectedVideos: { type: "integer", minimum: 0, description: "Fallback expected video count when no manifest is available." },
        quietMs: { type: "integer", minimum: 0, maximum: 3600000, default: 18000, description: "Initial quiet period before tight polling, so the agent does not over-poll while Flow starts rendering." },
        pollMs: { type: "integer", minimum: 250, maximum: 600000, default: 5000, description: "Polling interval after quietMs." },
        maxUnchangedPolls: { type: "integer", minimum: 0, maximum: 120, default: 0, description: "When greater than zero, stop with stalled_no_progress after this many unchanged reconcile snapshots unless the Agent screen still shows a queue/running signal." },
        waitTimeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 1200000, description: "Maximum total wait time." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, description: "Alias for waitTimeoutMs when a client only has a generic timeout field." },
        metadataTimeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000, description: "Per metadata bridge request timeout." },
        includeRawRows: { type: "boolean", default: false },
        downloadOnComplete: { type: "boolean", default: true, description: "Defaults true. When not explicitly false, execute autoflow_download_outputs automatically after completion. Requires expectedManifest or expectedManifestPath so downloadable rows can be planned; set false for count-only waits." },
        downloadTimeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 600000, description: "Bridge/tool-call timeout for the automatic download-on-complete step. Does not affect the wait polling timeout." },
        downloadExecuteTimeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, description: "Alias for downloadTimeoutMs when a client distinguishes execute timeouts from wait timeouts." },
        autoRetryFailures: { type: "boolean", default: true, description: "When true, immediately retry a visible retryable Flow Agent failure card, such as an unbilled failed generation, when it maps to one row." },
        autoRetryMissing: { type: "boolean", default: false, description: "When true, retry only missing row ids once the wait times out or returns partial. Bounded by maxRetryRounds." },
        maxRetryRounds: { type: "integer", minimum: 1, maximum: 5, default: 1, description: "Maximum targeted missing-output retry rounds." },
        retryIssue: { type: "string", default: "missing output", description: "Retry issue label for automatic missing-output repair." },
        retryNotes: { type: "string", description: "Extra retry instruction for automatic missing-output repair." },
        autonomy: autonomySchema,
        autoApprove: autoApproveSchema,
        maxSelfHealRetries: maxSelfHealRetriesSchema,
        suppressOnScreenText: suppressOnScreenTextSchema,
        confirmCredits: { type: "boolean", default: false, description: "One-run approval fallback: honored only inside a captain-authorized batch and only when no standing credit cap is configured. A configured creditCap is a hard ceiling that confirmCredits cannot override." },
        captainAuthorized: { type: "boolean", description: "Marks this wait loop as a captain-authorized batch. Visible Flow credit prompts may be auto-confirmed and Auto Flow prefers persistent approval when Flow offers it." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        creditCap: { type: "number", minimum: 0, description: "Optional per-wait credit ceiling. Credit dialogs are auto-confirmed only while cumulative approved credits stay at or below this cap; over-cap spend returns waiting_for_credit_approval." },
        runName: { type: "string", description: "Run name used for download planning when downloadOnComplete is true." },
        outputRoot: { type: "string", description: "Destination root used when downloadOnComplete is true." },
        imageResolution: { type: "string", enum: ["1k", "2k", "4k"], default: "1k", description: "Image download resolution forwarded to autoflow_download_outputs when downloadOnComplete is enabled." },
        videoResolution: { type: "string", enum: ["720p", "1080p", "4k"], default: "720p", description: "Video download resolution forwarded to autoflow_download_outputs when downloadOnComplete is enabled." },
        dryRun: { type: "boolean", default: false }
      }
    }
  },
  {
    name: "autoflow_clip_pipeline_download",
    title: "Watch And Download Clip Pipeline Outputs",
    description: "One-call clip pipeline: wait for the requested Agent run or row ids, download each row as soon as its outputs complete, keep watching pending rows, and stay idempotent by mediaId. Use this for 'download all outputs for run/rows X'.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Required when waiting live." },
        tabId: { type: "string", description: "Target Chrome tab id. Required when waiting live." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        expectedManifest: { type: "object", additionalProperties: true, description: "Expected Agent manifest with rows for live wait/reconcile." },
        expectedManifestPath: { type: "string", description: "Optional path to expected Agent manifest JSON." },
        reconciledRows: { type: "array", items: { type: "object", additionalProperties: true }, default: [], description: "Already reconciled rows for immediate scoped download without waiting." },
        reconciledPath: { type: "string", description: "Optional path to reconciled rows JSON." },
        rowId: { type: "string", description: "Single row id to watch/download." },
        rowIds: { type: "array", items: { type: "string" }, default: [], description: "Row ids to watch/download. Omit to download every manifest row." },
        rows: { type: "array", items: { type: "string" }, default: [], description: "Alias for rowIds." },
        mediaIds: { type: "array", items: { type: "string" }, default: [], description: "Optional explicit media id subset." },
        excludeMediaIds: { type: "array", items: { type: "string" }, default: [], description: "Media ids that must not be downloaded, used by one-shot repair to avoid old outputs." },
        downloadedMediaIds: { type: "array", items: { type: "string" }, default: [], description: "Already-downloaded media ids for idempotent resumed watches." },
        runName: { type: "string", description: "Run name used for row-tag artifact folders." },
        outputRoot: { type: "string", description: "Download folder/root used in planned artifact paths." },
        only: { type: "string", description: "Optional QA/status filter such as passed." },
        includeImages: { type: "boolean", default: true, description: "Download generated image outputs requested by the manifest. Input reference images are always excluded." },
        includeVideos: { type: "boolean", default: true, description: "Download generated video outputs requested by the manifest." },
        latestOnly: { type: "boolean", default: true },
        execute: { type: "boolean", default: true, description: "When false, return the scoped plan for already reconciled rows without executing downloads." },
        autoApprove: autoApproveSchema,
        maxCreditsPerRun: { type: "integer", minimum: 0, maximum: 100000, description: "Standing policy: auto-confirm visible Flow credit prompts up to this many credits per run." },
        autoApproveFree: { type: "boolean", default: true, description: "Standing policy: always approve prompts with a spend-phrased free/0-credit signal such as 'uses 0 credits' or 'free generation'; balance copy like 'You have 0 credits' does not count." },
        confirmCredits: { type: "boolean", default: false, description: "Explicit one-run approval fallback, honored only inside a captain-authorized batch and only when no standing credit cap is configured. A configured maxCreditsPerRun (or AUTOFLOW_MAX_CREDITS_PER_RUN) is a hard ceiling that confirmCredits cannot override." },
        captainAuthorized: { type: "boolean", description: "Marks this clip pipeline run as a captain-authorized batch. Visible Flow credit prompts may be auto-confirmed and Auto Flow prefers persistent approval when Flow offers it." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        quietMs: { type: "integer", minimum: 0, maximum: 3600000, default: 18000, description: "Initial settle window before polling Agent rows for completed media." },
        pollMs: { type: "integer", minimum: 1, maximum: 600000, default: 5000, description: "Delay between Agent row metadata polls while waiting for completion." },
        waitTimeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 1200000, description: "Overall watch window for Agent row completion and partial-batch downloads." },
        metadataTimeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000, description: "Per-call timeout for bridge metadata snapshots during the watch loop." },
        includeRawRows: { type: "boolean", default: false },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 1200000, description: "Fallback bridge/tool-call timeout used by download requests when a narrower timeout is not provided." }
      }
    }
  },
  {
    name: "autoflow_clip_pipeline_repair",
    title: "Regenerate One Clip Row And Download Replacement",
    description: "One-shot repair: retry one Agent row with an optional note, wait for the replacement output, download it, and report old vs new media ids/paths.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id." },
        tabId: { type: "string", description: "Target Chrome tab id." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        rowId: { type: "string", description: "Row id to regenerate, for example V1-S7." },
        issue: { type: "string", default: "bad timing", description: "Repair issue label." },
        note: { type: "string", description: "Optional repair note." },
        notes: { type: "string", description: "Optional repair notes alias." },
        mode: { type: "string", enum: ["image-only", "video-only", "images-and-video"], default: "video-only" },
        expectedManifest: { type: "object", additionalProperties: true },
        expectedManifestPath: { type: "string", description: "Path to expected Agent manifest JSON." },
        runName: { type: "string" },
        outputRoot: { type: "string" },
        autoApprove: autoApproveSchema,
        maxCreditsPerRun: { type: "integer", minimum: 0, maximum: 100000, description: "Standing policy: auto-confirm visible Flow credit prompts up to this many credits for the repair run." },
        autoApproveFree: { type: "boolean", default: true, description: "Standing policy: always approve repair prompts with a spend-phrased free/0-credit signal such as 'uses 0 credits' or 'free generation'; balance copy like 'You have 0 credits' does not count." },
        confirmCredits: { type: "boolean", default: false, description: "Explicit one-run approval fallback for a visible repair credit prompt, honored only inside a captain-authorized batch and only when no standing credit cap is configured. A configured maxCreditsPerRun (or AUTOFLOW_MAX_CREDITS_PER_RUN) is a hard ceiling that confirmCredits cannot override." },
        captainAuthorized: { type: "boolean", description: "Marks this clip repair as a captain-authorized batch. Visible Flow credit prompts may be auto-confirmed and Auto Flow prefers persistent approval when Flow offers it." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        quietMs: { type: "integer", minimum: 0, maximum: 3600000, default: 18000, description: "Initial settle window before polling the repaired row for replacement media." },
        pollMs: { type: "integer", minimum: 1, maximum: 600000, default: 5000, description: "Delay between repaired-row metadata polls while waiting for replacement media." },
        waitTimeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 1200000, description: "Overall watch window for the replacement row to complete and download." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 86400000, default: 1200000, description: "Fallback bridge/tool-call timeout used by retry and download requests when a narrower timeout is not provided." }
      },
      required: ["projectId", "tabId", "rowId"]
    }
  },
  {
    name: "autoflow_fleet_generate",
    title: "Generate Through AutoFlow Fleet Gen",
    description: "Default Auto Flow generation engine for new image/video batches. Drives the AutoFlow Fleet Gen Flow Tool through the iframe-scoped MCP bridge: sets prompts, updates settings, launches, polls getState, and returns media IDs, downloadable media bytes/URLs when exposed, plus a session-router outbox. Set direct/executeDirect for the smallest one-prompt iframe proof using fleetGen.executeDirect.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Required for live generation." },
        tabId: { type: "string", description: "Target Chrome tab id. Required for live generation." },
        laneId: { type: "string", description: "Named/opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        promptsText: { type: "string", description: "Newline-delimited prompts for Fleet Gen." },
        promptText: { type: "string", description: "Alias for promptsText." },
        prompt: { type: "string", description: "Single prompt or newline-delimited prompts." },
        prompts: {
          type: "array",
          items: {
            oneOf: [
              { type: "string" },
              {
                type: "object",
                additionalProperties: true,
                properties: {
                  prompt: { type: "string" },
                  text: { type: "string" },
                  durationSeconds: { type: "integer", enum: [4, 6, 8], description: "Optional per-row video duration." },
                  videoDurationSeconds: { type: "integer", enum: [4, 6, 8], description: "Alias for durationSeconds." }
                }
              }
            ]
          },
          default: []
        },
        referenceImageMediaIds: { type: "array", items: { type: "string" }, default: [], description: "Existing Flow image media IDs to pass as Fleet Gen references." },
        firstFrameImageMediaId: { type: "string", description: "Existing Flow image media ID to use as the exact first frame for I2V." },
        lastFrameImageMediaId: { type: "string", description: "Optional existing Flow image media ID to use as the last frame." },
        sourceVideoMediaId: { type: "string", description: "Existing Flow video media ID for V2V/edit/extend workflows." },
        sourceVideoMode: { type: "string", description: "Fleet Gen source-video operation, such as edit or extend." },
        type: { type: "string", enum: ["image", "video", "t2i", "t2v", "i2v", "v2v"], description: "Fleet Gen generation mode. I2V requires firstFrameImageMediaId; V2V requires sourceVideoMediaId." },
        mediaType: { type: "string", enum: ["image", "video", "t2i", "t2v", "i2v", "v2v"], description: "Alias for type." },
        model: { type: "string", description: "Image model label. Also forwarded as modelDisplayName/imageModel when those are omitted." },
        modelDisplayName: { type: "string", description: "Flow Tool modelDisplayName override." },
        imageModel: { type: "string", description: "Fleet Gen image model label, such as Nano Banana Pro." },
        videoModel: { type: "string", description: "Fleet Gen video model label, such as Omni Flash." },
        aspectRatio: { type: "string", default: "16:9" },
        durationSeconds: { type: "integer", enum: [4, 6, 8], description: "Video duration for Fleet Gen video runs. Auto Flow forwards this to Fleet Gen as settings.duration/settings.durationSeconds so Flow.generate.video receives durationSeconds." },
        videoDurationSeconds: { type: "integer", enum: [4, 6, 8], description: "Alias for durationSeconds." },
        concurrency: { type: "integer", minimum: 1, maximum: 12, default: 1 },
        countPerPrompt: { type: "integer", minimum: 1, maximum: 12, default: 1 },
        agentId: { type: "string", description: "Session-router agent id for outbox rows." },
        batchId: { type: "string", description: "Session-router batch id for outbox rows." },
        sessionId: { type: "string", description: "Optional session-router session id." },
        metadata: { type: "object", additionalProperties: true },
        idempotencyKey: { type: "string", description: "Optional paid-run idempotency key. Auto Flow derives a stable key when omitted." },
        settings: { type: "object", additionalProperties: true, description: "Raw Fleet Gen updateSettings config. Auto Flow merges first-class fields into this object before sending the bridge request." },
        maxCreditsPerRun: { type: "integer", minimum: 0, maximum: 100000, description: "Standing policy cap for paths with observable Flow credit prompts. Fleet Gen live runs fail closed when this is configured because the iframe tool does not expose a stable credit prompt API." },
        confirmCredits: { type: "boolean", default: false, description: "Explicit one-run approval fallback, honored only inside a captain-authorized batch and only when no standing credit cap is configured. A configured maxCreditsPerRun (or AUTOFLOW_MAX_CREDITS_PER_RUN) is a hard ceiling that confirmCredits cannot override." },
        captainAuthorized: { type: "boolean", description: "Marks this Fleet Gen run as captain-authorized for visible Flow credit prompts." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        direct: { type: "boolean", default: false, description: "Use fleetGen.executeDirect for a single prompt proof instead of batch launch." },
        executeDirect: { type: "boolean", default: false, description: "Alias for direct." },
        waitUntilDone: { type: "boolean", default: true },
        dryRun: { type: "boolean", default: false, description: "Return the bridge request without live generation." },
        manifestPath: { type: "string", description: "Optional local JSON path for the returned session-router manifest/outbox." },
        outboxPath: { type: "string", description: "Alias for manifestPath." },
        outputPath: { type: "string", description: "Alias for manifestPath." },
        out: { type: "string", description: "Alias for manifestPath." },
        pollMs: { type: "integer", minimum: 250, maximum: 600000, default: 2000 },
        commandTimeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 600000, default: 600000, description: "Max blocking wait for the single Fleet Gen bridge call, in ms. Capped at 600000 (10 min): the native broker hard-caps the extension forward at 600000 and the service worker clamps its poll+harvest budget to the same ceiling, so larger values cannot extend the wait. Split longer batches into multiple runs (or use a future async submit + state-polling flow) instead of requesting a single wait beyond this cap." }
      }
    }
  },
  {
    name: "autoflow_run_agent_batch",
    title: "Run Agent Batch",
    description: "Optional Agent Mode path for repair, legacy row manifests, and fallback workflows after Fleet Gen. Build an Agent Mode prompt packet from text, a file, or a matrix, then dry-run or submit it through Auto Flow Bridge. Call autoflow_context first for run profile defaults, self-heal autonomy, and model cost guidance. Before live submit, show the defaults, then ask only for overrides or unknown required values: Return silent videos for video workflows, reference-chip readiness, and exact credit approval. Do not pre-fix prompts when full-self-heal is enabled; hand intent to Flow Agent and let it repair safe policy/missing-output failures.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. The submit fails closed (AGENT_TARGET_MISMATCH) if the active Flow tab is a different project." },
        tabId: { type: "string", description: "Target Chrome tab id. Prevents a newer Flow tab from stealing this submit." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics. The live-submit safety lock is per Chrome tab." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        inputPath: { type: "string", description: "Local .txt prompt packet or row manifest file." },
        promptText: { type: "string", description: "Raw prompt packet or [V#-S#] row text." },
        prompt: { type: "string", description: "Fully rendered Agent prompt text. Prefer promptText/inputPath when building a packet." },
        matrix: {
          type: "object",
          additionalProperties: true,
          description: "Prebuilt Agent matrix."
        },
        mode: {
          type: "string",
          enum: ["agent", "text-to-video", "image-to-video", "text-to-image", "ingredients-to-video"],
          default: "agent"
        },
        rows: {
          oneOf: [{ type: "string" }, { type: "integer" }],
          description: "Rows to include from packet input, or all for Omni packets."
        },
        repeatCount: { type: "integer", minimum: 1, maximum: 100, default: 1, description: "Outputs per row. Defaults to the run profile unless the user overrides; Flow video output count should be 1-4." },
        outputs: { type: "integer", minimum: 1, maximum: 100, description: "Alias for repeatCount when the workflow output type is obvious." },
        imageOutputs: { type: "integer", minimum: 1, maximum: 100, description: "Image outputs per prompt for Create Image rows." },
        videoOutputs: { type: "integer", minimum: 1, maximum: 4, description: "Video outputs per row for video rows. Flow video output count is usually 1-4." },
        videoLength: { type: "string", default: "8", description: "Video length. Defaults to the run profile unless the user overrides." },
        aspectRatio: { type: "string", default: "portrait", description: "Generation aspect ratio. Defaults to the run profile or active Flow UI setting unless the user overrides." },
        model: { type: "string", description: "Requested Flow model family label. Defaults to the run profile unless the user overrides; status may still depend on the active Flow UI model." },
        imageModel: { type: "string", description: "Requested image model label, such as Nano Banana 2 or Nano Banana Pro." },
        videoModel: { type: "string", description: "Requested video model label, such as Veo 3.1 - Lite [Lower Priority]." },
        returnSilentVideos: { type: "boolean", description: "Requested Return silent videos setting. This is request metadata until Flow UI settings automation confirms it." },
        autonomy: autonomySchema,
        autoApprove: autoApproveSchema,
        maxSelfHealRetries: maxSelfHealRetriesSchema,
        suppressOnScreenText: suppressOnScreenTextSchema,
        refs: {
          type: "array",
          items: {
            oneOf: [
              { type: "string" },
              agentRefAttachmentSchema
            ]
          },
          default: [],
          description: "Reference images to attach before submit. Strings can be HOST_001=/abs/ref.png or HOST_001=flow:V1-S1/media-id."
        },
        targetRefs: { type: "array", items: { type: "string" }, default: [], description: "Reference handles that must be visible as Flow Agent prompt chips before submit." },
        forceAttach: { type: "boolean", default: false, description: "Force re-attaching refs even if a compatible prompt media chip is already visible. Use only when testing/replacing continuity chips." },
        attachments: { type: "array", items: attachmentSchema, default: [] },
	        dryRun: {
	          type: "boolean",
	          default: false,
	          description: "When true, return the exact bridge request without submitting."
	        },
	        confirmCredits: {
	          type: "boolean",
	          default: false,
	          description: "Only honored inside a captain-authorized batch; outside that context credit prompts stop and escalate. Defaults false."
	        },
	        captainAuthorized: {
	          type: "boolean",
	          default: false,
	          description: "Marks this batch as captain-authorized for visible Flow credit prompts; Auto Flow prefers persistent approval when Flow offers it."
	        },
	        authorizedBatch: {
	          type: "boolean",
	          default: false,
	          description: "Alias for captainAuthorized."
	        },
	        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      }
    }
  },
  {
    name: "autoflow_submit_agent_prompt",
    title: "Submit Agent Prompt",
    description: "Optional Agent Mode chat/repair path after Fleet Gen. Send an Agent Mode prompt or matrix to the paired Auto Flow extension. Call autoflow_context first for run profile defaults, self-heal autonomy, and model cost guidance. Use waitForReply for conversational steering so the tool returns the newest visible Flow Agent reply instead of forcing a separate guess. Before live submit, show the defaults, then ask only for overrides or unknown required values: Return silent videos for video workflows, reference-chip readiness, and exact credit approval.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. The submit fails closed (AGENT_TARGET_MISMATCH) if the active Flow tab is a different project." },
        tabId: { type: "string", description: "Target Chrome tab id. Prevents a newer Flow tab from stealing this submit." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics. The live-submit safety lock is per Chrome tab." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        prompt: { type: "string", description: "Fully rendered Agent prompt text." },
        matrix: {
          type: "object",
          additionalProperties: true,
          description: "Agent matrix to render through shared core helpers before submit."
        },
        refs: {
          type: "array",
          items: {
            oneOf: [
              { type: "string" },
              agentRefAttachmentSchema
            ]
          },
          default: [],
          description: "Reference images to attach before submit. Strings can be HOST_001=/abs/ref.png or HOST_001=flow:V1-S1/media-id."
        },
        targetRefs: { type: "array", items: { type: "string" }, default: [], description: "Reference handles that must be visible as Flow Agent prompt chips before submit." },
        forceAttach: { type: "boolean", default: false, description: "Force re-attaching refs even if a compatible prompt media chip is already visible. Use only when testing/replacing continuity chips." },
        attachments: { type: "array", items: attachmentSchema, default: [] },
	        mode: {
	          type: "string",
	          enum: ["agent", "text-to-video", "image-to-video", "text-to-image", "ingredients-to-video"],
	          default: "agent"
	        },
	        confirmCredits: {
	          type: "boolean",
	          default: false,
	          description: "Only honored inside a captain-authorized batch; outside that context credit prompts stop and escalate. Defaults false."
	        },
        captainAuthorized: { type: "boolean", description: "Marks this submit as captain-authorized for visible Flow credit prompts; Auto Flow prefers persistent approval when Flow offers it." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        autonomy: autonomySchema,
        autoApprove: autoApproveSchema,
        maxSelfHealRetries: maxSelfHealRetriesSchema,
        suppressOnScreenText: suppressOnScreenTextSchema,
	        dryRun: { type: "boolean", default: false },
        waitForReply: { type: "boolean", default: false, description: "After submit, poll the live Agent screen and return the first new visible Flow Agent reply. Use for chat-style steering and recovery prompts. If Flow resets the visible conversation after accepting the submit, returns AGENT_CHAT_SESSION_RESET_AFTER_ACCEPTANCE with sideEffectRetryBlocked=true; reconcile read-only and do not resubmit." },
        waitTimeoutMs: { type: "integer", minimum: 1000, maximum: 300000, default: 60000 },
        pollMs: { type: "integer", minimum: 250, maximum: 10000, default: 1000 },
        includeRaw: { type: "boolean", default: false, description: "Include raw context while waiting for replies. Leave false unless debugging selector issues." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      }
    }
  },
  {
    name: "autoflow_attach_refs",
    title: "Plan Or Attach Agent References",
    description: "Plan reference images for Flow Agent Mode and, when live support is available, attach them through the paired extension before submit. Use this for character/product continuity. Dry-run first, then require visible reference chips before live submit.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Live attach fails closed if the active tab is different." },
        tabId: { type: "string", description: "Target Chrome tab id. Required for live attach." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        refs: {
          type: "array",
          items: {
            oneOf: [
              { type: "string" },
              agentRefAttachmentSchema
            ]
          },
          minItems: 1,
          description: "Reference descriptors. Strings can be HOST_001=/abs/ref.png or HOST_001=flow:V1-S1/media-id."
        },
        targetRefs: { type: "array", items: { type: "string" }, default: [], description: "Handles that must be visible as Flow Agent prompt chips before submit." },
        forceAttach: { type: "boolean", default: false, description: "Force re-attaching refs even if a compatible prompt media chip is already visible. Use only when testing/replacing continuity chips." },
        visibleChips: { type: "array", items: { type: "string" }, default: [], description: "Visible Flow Agent chip handles from screen context, used for readiness proof." },
        dryRun: { type: "boolean", default: false },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      },
      required: ["refs"]
    }
  },
  {
    name: "autoflow_confirm_credits",
    title: "Confirm Flow Agent Credit Dialog",
    description: "Click a currently visible Flow Agent credit confirmation dialog for an already-submitted run. Use this to resume a stalled image-to-video row without re-submitting the image. Requires explicit user approval for the specific credit spend.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        tabId: { type: "string", description: "Target Chrome tab id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        laneId: { type: "string", description: "Named lane to resolve before confirming credits. Defaults to AUTOFLOW_LANE when set." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        dontAskAgain: {
          type: "boolean",
          default: false,
          description: "If true, prefer the persistent Yes-and-don't-ask-again choice. Only use after explicit user approval."
        },
        persistentApproval: {
          type: "boolean",
          default: false,
          description: "Alias for dontAskAgain."
        },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 900000, default: 600000 }
      }
    }
  },
  {
    name: "autoflow_retry_rows",
    title: "Retry Agent Rows",
    description: "Build and submit targeted retry requests for failed Agent Mode rows.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Live retry fails closed if the active Flow tab is a different project." },
        tabId: { type: "string", description: "Target Chrome tab id. Required for live retry submits." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        runId: { type: "string", description: "Optional run id for bridge validation." },
        taskId: { type: "string", description: "Optional task id for bridge validation." },
        rows: { type: "array", items: { type: "string" }, minItems: 1 },
        mode: {
          type: "string",
          enum: ["image-only", "video-only", "images-and-video"],
          default: "video-only"
        },
        issue: {
          type: "string",
          enum: [
            "wrong speaker",
            "wrong dialogue",
            "missing line",
            "ending cut off",
            "identity drift",
            "outfit drift",
            "wrong product",
            "bad vial",
            "bad timing",
            "missing output",
            "other"
          ]
        },
        notes: { type: "string", description: "Human-readable retry instruction." },
        expectedDialogue: {
          type: "array",
          items: { type: "string" },
          default: []
        },
        latestMediaContext: {
          type: "object",
          additionalProperties: true,
          description: "Latest media context keyed by row id."
        },
        expectedManifest: { type: "object", additionalProperties: true },
        transcripts: { type: "array", items: transcriptRowSchema, default: [] },
        confirmCredits: {
          type: "boolean",
          default: false,
          description: "Explicitly allow Auto Flow to click a Flow credit confirmation dialog for this retry only inside a captain-authorized batch. Defaults false."
        },
        captainAuthorized: { type: "boolean", description: "Marks this retry as captain-authorized for visible Flow credit prompts; Auto Flow prefers persistent approval when Flow offers it." },
        authorizedBatch: { type: "boolean", description: "Alias for captainAuthorized." },
        dryRun: { type: "boolean", default: false },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      },
      required: ["rows", "issue"]
    }
  },
  {
    name: "autoflow_download_outputs",
    title: "Download Auto Flow Outputs",
    description: "Plan or actually save Agent Mode output files. This is the auto-download target used by autoflow_wait_for_render after completed Agent renders. With execute:true the extension downloads the media (it has the Flow session) and returns savedPaths: a map of mediaId -> absolute file path on disk. Call after autoflow_reconcile_project for manual downloads. Use naming.style for raw mediaId/taskId downloads; reconciledRows default to row/slot/version/media-id artifact names.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id (from autoflow_lane_inventory). Download fails closed if the active tab is a different project." },
        tabId: { type: "string", description: "Target Chrome tab id (from autoflow_lane_inventory)." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        taskId: { type: "string", description: "Optional task id for bridge validation." },
        runName: { type: "string", description: "Human-readable run name used for output folder planning." },
        outputRoot: { type: "string", description: "Download folder label/root used in planned artifact paths. MCP execute saves through Chrome downloads and returns actual savedPaths." },
        naming: filenameNamingSchema,
        imageResolution: { type: "string", enum: ["1k", "2k", "4k"], default: "1k", description: "Image export target. 1k uses the direct Flow media download; 2k/4k plan the upscale path." },
        videoResolution: { type: "string", enum: ["720p", "1080p", "4k"], default: "720p", description: "Video export target. 720p uses the direct Flow media download; 1080p/4k plan the upscale path when the media/aspect supports it." },
        reconciledRows: {
          type: "array",
          items: { type: "object", additionalProperties: true },
          default: [],
          description: "Rows from Agent reconciliation or Live Queue state."
        },
        reconciled: {
          type: "object",
          additionalProperties: true,
          description: "Full reconciled payload with a rows array or result.rows."
        },
        reconciledPath: { type: "string", description: "Optional JSON file containing reconciled rows." },
        only: {
          type: "string",
          enum: ["passed", "pass", "failed", "fail", "warn", "needs_human_review"],
          description: "Optional QA filter for planned downloads."
        },
        rowIds: stringArray,
        mediaIds: stringArray,
        imageResolution: { type: "string", enum: ["1k", "2k", "4k"], default: "1k", description: "Image download resolution for Agent output artifacts." },
        videoResolution: { type: "string", enum: ["720p", "1080p", "4k"], default: "720p", description: "Video download resolution for Agent output artifacts." },
        latestOnly: { type: "boolean", default: true },
        execute: {
          type: "boolean",
          default: false,
          description: "When false, return a plan only. When true, the extension downloads the files and the result includes savedPaths (mediaId -> absolute path on disk)."
        },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      }
    }
  },
  {
    name: "autoflow_agent_gallery_list",
    title: "List Visible Flow Gallery Media",
    description: "List visible Flow project gallery media by media id through the lightweight media-list bridge path, without Agent reconcile rows or a full project.metadata.get payload. Use this when reconcile returns zero rows but the Flow project already shows usable images or videos.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Expected Flow project id. If provided, the bridge fetches from that target." },
        tabId: { type: "string", description: "Expected Chrome tab id for exact Flow target binding." },
        laneId: { type: "string", description: "Opaque lane label for diagnostics." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        type: { type: "string", enum: ["image", "images", "video", "videos", "all"], default: "all" },
        latest: { type: "integer", minimum: 1, maximum: 100, description: "Optional newest N records after filtering by type." },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      }
    }
  },
  {
    name: "autoflow_agent_gallery_download",
    title: "Download Visible Flow Gallery Media",
    description: "Download visible Flow gallery media by mediaId or newest media type without requiring reconcile rows or full project.metadata.get. The extension performs the real download with Flow cookies and returns savedPaths. naming.style defaults to auto_flow and can be detailed, prompt_prefix, auto_flow, or custom_template.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        project: { type: "string", default: "current" },
        projectId: { type: "string", description: "Target Flow project id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        tabId: { type: "string", description: "Target Chrome tab id. Omit only when laneId or AUTOFLOW_LANE resolves to an exact named lane." },
        laneId: { type: "string", description: "Named lane to resolve before downloading. Defaults to AUTOFLOW_LANE when set." },
        bridgeSocket: { type: "string", description: "Native broker unix socket path for external usage (or set AUTOFLOW_BRIDGE_SOCKET)." },
        mediaId: { type: "string", description: "Exact visible Flow media id to download." },
        rowId: { type: "string", description: "Optional row tag such as V1-S1 to prefix prompts for row-tag-preserving auto_flow filenames when the gallery prompt is untagged." },
        type: { type: "string", enum: ["image", "images", "video", "videos"], description: "Media type for latest downloads." },
        latest: { type: "integer", minimum: 1, maximum: 100, description: "Newest N records of the requested type to download." },
        runName: { type: "string", default: "Gallery" },
        outputRoot: { type: "string", description: "Optional Flow download folder label." },
        folder: { type: "string", description: "Optional Flow download folder label. Defaults to Auto Flow Gallery." },
        naming: filenameNamingSchema,
        imageResolution: { type: "string", enum: ["1k", "2k", "4k"], default: "1k" },
        videoResolution: { type: "string", enum: ["720p", "1080p", "4k"], default: "720p" },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 60000 }
      }
    }
  },
  {
    name: "autoflow_qa_transcripts",
    title: "QA Agent Transcripts",
    description: "Compare expected dialogue against transcripts and optionally produce retry prompts.",
    inputSchema: {
      type: "object",
      additionalProperties: false,
      properties: {
        rows: { type: "array", items: transcriptRowSchema, minItems: 1 },
        aliasMap: {
          type: "object",
          additionalProperties: { type: "array", items: { type: "string" } },
          description: "Phrase aliases for transcript matching."
        },
        generateRetryPrompts: { type: "boolean", default: true },
        timeoutMs: { type: "integer", minimum: 1000, maximum: 120000, default: 30000 }
      },
      required: ["rows"]
    }
  }
];

export const TOOL_NAMES = new Set(TOOL_DEFINITIONS.map((tool) => tool.name));
