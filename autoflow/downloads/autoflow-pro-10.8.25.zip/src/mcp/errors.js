export const BRIDGE_UNAVAILABLE = Object.freeze({
  ok: false,
  code: "BRIDGE_UNAVAILABLE",
  message: "Turn on Auto Flow Bridge in the extension and run autoflow pair."
});

export function bridgeUnavailable(extra = {}) {
  return {
    ...BRIDGE_UNAVAILABLE,
    ...extra,
    ok: false,
    code: BRIDGE_UNAVAILABLE.code,
    message: BRIDGE_UNAVAILABLE.message
  };
}

export function invalidInput(message, details = {}) {
  return {
    ok: false,
    code: "INVALID_INPUT",
    message,
    details
  };
}

export function toolFailure(code, message, details = {}) {
  return {
    ok: false,
    code,
    message,
    details
  };
}

export function toMcpToolResult(payload, options = {}) {
  const normalized = payload && typeof payload === "object" ? payload : { ok: true, value: payload };
  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(normalized, null, 2)
      }
    ],
    structuredContent: normalized,
    isError: options.isError ?? normalized.ok === false
  };
}
