import { createInterface } from "node:readline";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { TOOL_DEFINITIONS } from "./tool-definitions.js";
import { callAutoFlowTool } from "./tool-handlers.js";

export const MCP_PROTOCOL_VERSION = "2025-06-18";
export const SERVER_NAME = "autoflow-mcp";

const JSON_RPC_VERSION = "2.0";
const ERRORS = Object.freeze({
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL_ERROR: -32603
});

export async function startMcpServer(options = {}) {
  const input = options.input || process.stdin;
  const output = options.output || process.stdout;
  const logger = options.logger || ((message) => process.stderr.write(`${message}\n`));
  const context = {
    cwd: options.cwd || process.cwd(),
    env: options.env || process.env
  };
  const packageInfo = await readPackageInfo();
  const rl = createInterface({ input, crlfDelay: Infinity });

  for await (const line of rl) {
    if (!line.trim()) continue;
    let message;
    try {
      message = JSON.parse(line);
    } catch (error) {
      writeMessage(output, errorResponse(null, ERRORS.PARSE_ERROR, "Parse error", { message: error.message }));
      continue;
    }

    try {
      const response = await handleMessage(message, { packageInfo, context });
      if (response) writeMessage(output, response);
    } catch (error) {
      logger(`Auto Flow MCP internal error: ${error?.stack || error?.message || error}`);
      writeMessage(output, errorResponse(message?.id ?? null, ERRORS.INTERNAL_ERROR, "Internal error"));
    }
  }
}

export async function handleMessage(message, options = {}) {
  if (!isJsonRpcMessage(message)) {
    return errorResponse(message?.id ?? null, ERRORS.INVALID_REQUEST, "Invalid JSON-RPC request");
  }
  if (!("id" in message)) return null;

  if (message.method === "initialize") {
    return successResponse(message.id, {
      protocolVersion: MCP_PROTOCOL_VERSION,
      capabilities: {
        tools: {
          listChanged: false
        }
      },
      serverInfo: {
        name: SERVER_NAME,
        version: options.packageInfo?.version || "0.0.0"
      },
      instructions: [
        "Use the Auto Flow WS broker happy path: call autoflow_status or autoflow_pair and let the CLI/package auto-start the local broker. The extension service worker connects out to ws_broker; users should not run a separate server, chase native-host manifests, or restart Chrome for normal bridge setup. CDP is discovery/dev-lane tooling only, and native_messaging_legacy is explicit fallback only.",
        "Fleet Gen is the default generation engine for new image/video batches through autoflow_fleet_generate; Flow Agent is the first-line repair agent, not the default creation path, and remains available for legacy row workflows or an explicit fallback.",
        "Preserve the sidepanel Pair Bridge approval model: call autoflow_pair start, have the user click Pair Bridge, then confirm with the returned pairing code. For multi-terminal work, prefer named lanes with autoflow_lane_use or AUTOFLOW_LANE; named lanes bind exact projectId/tabId targets and fail closed when ambiguous.",
        "Call autoflow_context before planning live generation so you know the run profile defaults, self-heal autonomy, auto-approve policy, and Flow model cost/speed tradeoffs: cheapest/cost-safe video default is Veo 3.1 - Lite [Lower Priority]; Omni Flash is not the cheapest and should be used for Omni-specific workflows only after approval. If autoflow_flow_state or autoflow_agent_context returns context_unavailable or flow_bridge_degraded, call autoflow_connect with the exact projectId/tabId first so the same-window Flow tab is attached before any write. Before any write action, and after any error, call autoflow_flow_state to read the current Flow page, dialogs/buttons, composerReady, auth validity, settings, and pending generation state; do not retry-guess through write-tool errors.",
        "Flow Agent is the first-line repair agent. Do not pre-fix prompts when autonomy is full-self-heal: submit the user intent, let Flow Agent safely rephrase blocked rows, repair missing/failed rows, report FIXED row changes, and escalate only hard safety blocks or exhausted retries. Auto-approve safe at-level rephrases and missing-output retries when policy allows.",
        "Before any live submit, retry, or credit confirmation, show the run profile defaults and ask only for overrides or unknown required values: Return silent videos, missing/visible reference chips, exact video length/model/output count/aspect ratio, self-heal autonomy, and exact credit approval. confirm credits only after explicit user approval or an explicit autoApprove=credits/confirmCredits setting; confirmCredits and autoApprove=credits are honored only inside a captain-authorized batch, outside one credit prompts stop as waiting_for_credit_approval. maxCreditsPerRun is a hard cap, zero is a valid cap that blocks credit spend, negative caps are invalid config, and confirmCredits cannot bypass a configured cap.",
        "Works from any folder: file-path args resolve against the caller cwd; set AUTOFLOW_BRIDGE_SOCKET only for external/custom broker usage. If multiple Flow tabs are open, call autoflow_flow_tabs and pass exact projectId/tabId/laneId targeting; submits fail closed on AGENT_TARGET_MISMATCH or AGENT_TARGET_BUSY.",
        "For continuity refs, call autoflow_attach_refs in dry-run mode to plan local/generated refs and required Flow Agent chips before submitting. Default to organized auto-download of images, videos, refs, and manifests unless the user opts out.",
        "For chat-style steering, call autoflow_submit_agent_prompt with waitForReply=true so the tool returns the newest visible Flow Agent reply. If it returns AGENT_CHAT_SESSION_RESET_AFTER_ACCEPTANCE with sideEffectRetryBlocked=true, do not resubmit; the chat was accepted and only read-only reconciliation is safe. After every live submit or retry with an expected manifest, call autoflow_wait_for_render with downloadOnComplete=true plus imageResolution and videoResolution; let it block, reconcile, and auto-download until the target manifest completes or times out. do not make the model poll manually, do not call autoflow_download_outputs separately for completed runs, and do not stop at a partial result.",
        "If autoflow_wait_for_render times out or reconcile says missing/stalled, call autoflow_flow_state before guessing, then use autoflow_agent_context only when you need full latestMessages/uiState/retryPrompts. If text context is ambiguous, call autoflow_agent_screenshot. If a run stalls on a visible Flow Agent credit dialog, use autoflow_confirm_credits after approval instead of re-submitting the row. For dialogue-heavy clips, download/transcribe externally when available, then call autoflow_qa_transcripts and retry only failed rows."
      ].join(" "),
    });
  }
  if (message.method === "ping") return successResponse(message.id, {});
  if (message.method === "tools/list") return successResponse(message.id, { tools: TOOL_DEFINITIONS });
  if (message.method === "tools/call") return handleToolCall(message, options.context || {});
  return errorResponse(message.id, ERRORS.METHOD_NOT_FOUND, `Method not found: ${message.method}`);
}

async function handleToolCall(message, context) {
  const params = message.params || {};
  if (!params || typeof params !== "object" || typeof params.name !== "string") {
    return errorResponse(message.id, ERRORS.INVALID_PARAMS, "tools/call requires params.name");
  }
  const result = await callAutoFlowTool(params.name, params.arguments || {}, context);
  return successResponse(message.id, result);
}

function isJsonRpcMessage(message) {
  return message
    && typeof message === "object"
    && !Array.isArray(message)
    && message.jsonrpc === JSON_RPC_VERSION
    && typeof message.method === "string";
}

function successResponse(id, result) {
  return {
    jsonrpc: JSON_RPC_VERSION,
    id,
    result
  };
}

function errorResponse(id, code, message, data) {
  return {
    jsonrpc: JSON_RPC_VERSION,
    id,
    error: {
      code,
      message,
      ...(data === undefined ? {} : { data })
    }
  };
}

function writeMessage(output, message) {
  output.write(`${JSON.stringify(message)}\n`);
}

export async function readPackageInfo() {
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    const packagePath = resolve(here, "../../package.json");
    return JSON.parse(await readFile(packagePath, "utf8"));
  } catch {
    return null;
  }
}
