/**
 * Settings → Subscription panel visibility and Stripe portal open results.
 * Keep this pure so the revenue-critical manage path can be unit-tested
 * without Chrome or a live Stripe session.
 */

export function subscriptionSettingsPanelVisibility(account = {}) {
  const signedIn = account.status === "signed_in";
  const hasAccess = account.hasProAccess === true || account.plan === "pro" || account.plan === "team";
  return {
    signedIn,
    manageVisible: signedIn,
    noSubVisible: !signedIn && !hasAccess
  };
}

export function resolveStripeBillingPortalUrl(portal = null) {
  if (!portal || typeof portal !== "object") return "";
  const candidates = [
    portal.portal_url,
    portal.portalUrl,
    portal.url,
    portal.session?.url,
    portal.portal?.url
  ];
  for (const candidate of candidates) {
    try {
      const url = new URL(String(candidate || ""));
      if (url.protocol === "https:" && url.hostname === "billing.stripe.com") return url.href;
    } catch {
      // Try the next known response shape.
    }
  }
  return "";
}

export function billingPortalFailureCode(portal = null) {
  if (!portal || typeof portal !== "object") return "missing_portal_url";
  if (resolveStripeBillingPortalUrl(portal)) return "";
  return String(portal.error || portal.reason || portal.code || "missing_portal_url");
}

export function billingPortalFailureMessage(portal = null) {
  const code = billingPortalFailureCode(portal);
  if (!code) return null;
  if (code === "stripe_customer_not_found") {
    return "We could not find the Stripe customer for this account. Refresh your subscription status, then contact support if it continues.";
  }
  if (code === "missing_portal_url") {
    return "Stripe did not return a billing portal link. Refresh your subscription status and try again.";
  }
  if (code === "stale_license_response") {
    return "Your account changed while Stripe was opening. Refresh your subscription status and try again.";
  }
  if (portal?.stripe_message) {
    return `Stripe could not create the billing portal: ${String(portal.stripe_message).slice(0, 300)}`;
  }
  return `Unable to open Stripe billing (${code}). Refresh your subscription status and try again.`;
}
