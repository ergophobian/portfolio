import { deriveBillingAccountState } from "./billing-state.js";
import {
  billingPortalFailureCode,
  billingPortalFailureMessage,
  resolveStripeBillingPortalUrl
} from "./subscription-settings-panel.js";

export const SUPABASE_URL = "https://yhcobtwwwhidignoifbg.supabase.co";
export const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InloY29idHd3d2hpZGlnbm9pZmJnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAzNjcyNTQsImV4cCI6MjA4NTk0MzI1NH0.d757ILAt7f3MAKxLZ0tm8CNKapItd3AUAFOPDzBR4O8";
export const CHECK_LICENSE_URL = `${SUPABASE_URL}/functions/v1/check-license`;
export const LICENSE_CACHE_KEY = "autoflow_license_cache";
export const AUTH_TOKEN_KEY = "autoflow_auth_token";
export const RATE_LIMIT_KEY = "autoflow_rate_limits";
const LICENSE_BACKOFF_KEY = "autoflow_license_backoff";
export const CHECKOUT_LOCK_KEY = "autoflow_checkout_lock";
export const CHECKOUT_LAST_KEY = "autoflow_checkout_last";

const CACHE_TTL_MS = 30 * 60 * 1000;
const FEATURE_CACHE_TTL_MS = 10 * 60 * 1000;
const RUNTIME_CAPABILITY_CACHE_TTL_MS = 60 * 60 * 1000;
const LICENSE_REFRESH_COOLDOWN_MS = 5 * 60 * 1000;
const LICENSE_BACKOFF_BASE_MS = 30 * 1000;
const LICENSE_BACKOFF_MAX_MS = 30 * 60 * 1000;
const MAGIC_LINK_MAX_PER_WINDOW = 3;
const MAGIC_LINK_WINDOW_MS = 90 * 1000;
const CHECKOUT_LOCK_TTL_MS = 20 * 1000;
const CHECKOUT_REUSE_TTL_MS = 3 * 60 * 1000;
const ACTIVE_PRO_GRACE_MS = 60 * 60 * 1000;
const HMAC_SALT = "af_cache_integrity_v1";

export function createChromeStorageAdapter() {
  return {
    get(keys) {
      return chrome.storage.local.get(keys);
    },
    set(values) {
      return chrome.storage.local.set(values);
    },
    remove(keys) {
      return chrome.storage.local.remove(keys);
    }
  };
}

export function defaultLicenseData(extra = {}) {
  return {
    tier: "free",
    prompts_today: 0,
    prompt_limit: 10,
    max_resolution: "1k",
    ...extra
  };
}

function normalizeEmail(email = "") {
  return String(email || "").trim().toLowerCase();
}

function normalizeStorageKeys(keys) {
  return Array.isArray(keys) ? keys : [keys];
}

function randomRequestId(now) {
  if (typeof crypto?.randomUUID === "function") return crypto.randomUUID();
  return `chk_${now}_${Math.random().toString(36).slice(2, 10)}`;
}

function decodeJwtDiagnostics(token = "") {
  const raw = String(token || "").trim();
  if (!raw) {
    return {
      tokenProjectRef: "",
      userIdPrefix: "",
      issuer: "",
      audience: "",
      emailHint: ""
    };
  }
  try {
    const [, payload] = raw.split(".");
    if (!payload) throw new Error("missing_payload");
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized + "=".repeat((4 - (normalized.length % 4 || 4)) % 4);
    const json = JSON.parse(atob(padded));
    const issuer = String(json.iss || "").trim();
    const issuerMatch = issuer.match(/https:\/\/([^.]+)\.supabase\.co/i);
    const userId = String(json.sub || "").trim();
    const email = normalizeEmail(json.email);
    return {
      tokenProjectRef: String(issuerMatch?.[1] || "").trim(),
      userIdPrefix: userId ? userId.slice(0, 8) : "",
      issuer,
      audience: String(json.aud || "").trim(),
      emailHint: email ? email.replace(/^(.{2}).*(@.*)$/, "$1***$2") : ""
    };
  } catch {
    return {
      tokenProjectRef: "",
      userIdPrefix: "",
      issuer: "",
      audience: "",
      emailHint: ""
    };
  }
}

function normalizeRuntimeCapabilities(data = {}) {
  const raw = data && typeof data === "object" ? data : null;
  if (!raw) return null;
  const normalized = {};
  const containers = [
    raw.capabilities,
    raw.runtime_capabilities,
    raw.runtimeCapabilities,
    raw.feature_flags,
    raw.featureFlags
  ];
  for (const container of containers) {
    if (!container || typeof container !== "object" || Array.isArray(container)) continue;
    for (const [key, value] of Object.entries(container)) {
      normalized[String(key)] = value === true;
    }
  }
  return Object.keys(normalized).length ? normalized : null;
}

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map((item) => stableJson(item)).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value)
      .filter((key) => value[key] !== undefined)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

function normalizeCachePayload(value = {}) {
  return JSON.parse(stableJson(value && typeof value === "object" ? value : {}));
}

export function createLicenseClient({
  fetchImpl = fetch,
  storage = createChromeStorageAdapter(),
  now = () => Date.now(),
  cryptoImpl = globalThis.crypto,
  runtimeIdProvider = () => chrome.runtime.id,
  buildInfoProvider = () => {
    const manifest = chrome.runtime.getManifest?.() || {};
    const version = String(manifest.version || "unknown").trim() || "unknown";
    const versionName = String(manifest.version_name || "").trim();
    return {
      buildId: versionName || version,
      version,
      versionName,
      extensionId: String(chrome.runtime.id || "").trim()
    };
  },
  environmentProvider = () => ({
    userAgent: globalThis.navigator?.userAgent || "",
    screen: {
      width: globalThis.screen?.width || 0,
      height: globalThis.screen?.height || 0
    }
  }),
  openTab = async (url) => chrome.tabs.create({ url }),
  featureRetryDelayMs = 2000,
  refreshRetryDelaysMs = [250, 750],
  refreshFreshnessWindowMs = 60000,
  random = Math.random
} = {}) {
  const featureValidationCache = new Map();
  let runtimeCapabilityCache = { value: null, at: 0 };
  let checkoutRequestPromise = null;
  const refreshInFlightByToken = new Map();
  const licenseInFlightByKey = new Map();
  const licenseBackoffByAction = new Map();
  let licenseBackoffHydrated = false;
  let licenseBackoffHydratePromise = null;
  let licenseAuthGeneration = 0;

  function invalidateLicenseAuthGeneration() {
    licenseAuthGeneration += 1;
    licenseInFlightByKey.clear();
  }
  let authRefreshDiagnostics = {
    lastAttemptAt: "",
    lastResult: "none",
    lastReason: "",
    lastErrorClass: "",
    lastStatus: 0,
    lastError: "",
    nextScheduledRefreshAt: "",
    expiresInMs: 0,
    inFlight: false
  };

  async function getStoredAuth() {
    const stored = await storage.get(AUTH_TOKEN_KEY);
    return stored?.[AUTH_TOKEN_KEY] || null;
  }

  function setAuthRefreshDiagnostics(patch = {}) {
    authRefreshDiagnostics = {
      lastAttemptAt: String(patch.lastAttemptAt ?? authRefreshDiagnostics.lastAttemptAt ?? ""),
      lastResult: String(patch.lastResult ?? authRefreshDiagnostics.lastResult ?? "none"),
      lastReason: String(patch.lastReason ?? authRefreshDiagnostics.lastReason ?? ""),
      lastErrorClass: String(patch.lastErrorClass ?? authRefreshDiagnostics.lastErrorClass ?? ""),
      lastStatus: Number(patch.lastStatus ?? authRefreshDiagnostics.lastStatus ?? 0) || 0,
      lastError: String(patch.lastError ?? authRefreshDiagnostics.lastError ?? "").slice(0, 240),
      nextScheduledRefreshAt: String(patch.nextScheduledRefreshAt ?? authRefreshDiagnostics.nextScheduledRefreshAt ?? ""),
      expiresInMs: Math.max(0, Number(patch.expiresInMs ?? authRefreshDiagnostics.expiresInMs ?? 0) || 0),
      inFlight: refreshInFlightByToken.size > 0
    };
    return getAuthRefreshDiagnostics();
  }

  function getAuthRefreshDiagnostics(extra = {}) {
    return {
      ...authRefreshDiagnostics,
      ...extra,
      inFlight: refreshInFlightByToken.size > 0 || extra.inFlight === true
    };
  }

  function clearFeatureValidationCache() {
    featureValidationCache.clear();
  }

  async function clearLicenseCache() {
    await storage.remove(LICENSE_CACHE_KEY);
    clearFeatureValidationCache();
    runtimeCapabilityCache = { value: null, at: 0 };
    await clearLicenseBackoff();
    invalidateLicenseAuthGeneration();
  }

  function authResult(auth, extra = {}) {
    const expiresInMs = Math.max(0, Number(auth?.expires_at || 0) - now());
    return {
      token: Object.prototype.hasOwnProperty.call(extra, "token") ? extra.token : auth?.access_token || null,
      authState: extra.authState || "cached_access_token",
      refreshAttempted: extra.refreshAttempted === true,
      refreshSucceeded: extra.refreshSucceeded === true,
      refreshResult: extra.refreshResult || "",
      refreshErrorClass: extra.refreshErrorClass || "",
      expiresInMs,
      email: normalizeEmail(auth?.email),
      authRefresh: getAuthRefreshDiagnostics({ expiresInMs }),
      ...decodeJwtDiagnostics(auth?.access_token)
    };
  }

  function refreshFailureMessage(data = {}) {
    return String(data?.error_description || data?.msg || data?.error || "").trim();
  }

  function classifyRefreshFailure(status = 0, data = {}, thrown = null) {
    if (thrown) {
      return {
        errorClass: "transient",
        message: String(thrown?.message || thrown || "refresh_network_error")
      };
    }
    const message = refreshFailureMessage(data);
    if (Number(status) === 401 || (Number(status) === 400 && /invalid_grant/i.test(message))) {
      return { errorClass: "auth_rejected", message: message || "refresh_rejected" };
    }
    if (Number(status) === 429 || Number(status) >= 500 || Number(status) <= 0) {
      return { errorClass: "transient", message: message || `refresh_transient_${status || "network"}` };
    }
    return { errorClass: "auth_rejected", message: message || `refresh_rejected_${status}` };
  }

  function refreshAttemptCount() {
    return Math.max(1, (Array.isArray(refreshRetryDelaysMs) ? refreshRetryDelaysMs.length : 0) + 1);
  }

  async function waitForRefreshRetry(attemptIndex) {
    const delays = Array.isArray(refreshRetryDelaysMs) ? refreshRetryDelaysMs : [];
    const delay = Math.max(0, Number(delays[Math.min(attemptIndex, delays.length - 1)] || 0) || 0);
    if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay));
  }

  function storedAuthMatchesRefreshToken(currentAuth, refreshToken) {
    return String(currentAuth?.refresh_token || "") === String(refreshToken || "");
  }

  async function performRefreshForAuth(auth = {}, options = {}) {
    const forceRefresh = options?.forceRefresh === true;
    const reason = String(options?.reason || (forceRefresh ? "forced_refresh" : "access_token_expired")).trim();
    const refreshToken = String(auth?.refresh_token || "");
    const startedAt = new Date(now()).toISOString();
    const previousExpiresInMs = Math.max(0, Number(auth?.expires_at || 0) - now());
    setAuthRefreshDiagnostics({
      lastAttemptAt: startedAt,
      lastResult: "started",
      lastReason: reason,
      lastErrorClass: "",
      lastStatus: 0,
      lastError: "",
      expiresInMs: previousExpiresInMs
    });

    if (!refreshToken) {
      await storage.remove([AUTH_TOKEN_KEY, LICENSE_CACHE_KEY]);
      clearFeatureValidationCache();
      runtimeCapabilityCache = { value: null, at: 0 };
      await clearLicenseBackoff();
      invalidateLicenseAuthGeneration();
      setAuthRefreshDiagnostics({
        lastResult: "auth_rejected",
        lastReason: reason,
        lastErrorClass: "auth_rejected",
        lastStatus: 0,
        lastError: "missing_refresh_token",
        expiresInMs: 0
      });
      return authResult(null, {
        authState: "missing_refresh_token",
        refreshAttempted: true,
        refreshSucceeded: false,
        refreshResult: "auth_rejected",
        refreshErrorClass: "auth_rejected"
      });
    }

    let lastFailure = { errorClass: "transient", message: "refresh_failed", status: 0 };
    const attempts = refreshAttemptCount();
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      let response = null;
      let data = {};
      try {
        response = await fetchImpl(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: SUPABASE_ANON_KEY
          },
          body: JSON.stringify({ refresh_token: refreshToken })
        });
        data = await response.json().catch(() => ({}));
      } catch (error) {
        lastFailure = { ...classifyRefreshFailure(0, {}, error), status: 0 };
        if (attempt < attempts - 1) {
          await waitForRefreshRetry(attempt);
          continue;
        }
        break;
      }

      if (response.ok) {
        const currentAuth = await getStoredAuth();
        if (!storedAuthMatchesRefreshToken(currentAuth, refreshToken)) {
          const currentResult = authResult(currentAuth, {
            authState: "stale_refresh_result_ignored",
            refreshAttempted: true,
            refreshSucceeded: false,
            refreshResult: "stale_success_ignored"
          });
          setAuthRefreshDiagnostics({
            lastResult: "stale_success_ignored",
            lastReason: reason,
            lastErrorClass: "",
            lastStatus: response.status,
            lastError: "",
            expiresInMs: currentResult.expiresInMs
          });
          return currentResult;
        }
        const nextAuth = {
          access_token: data.access_token,
          refresh_token: data.refresh_token || refreshToken,
          expires_at: now() + Number(data.expires_in || 0) * 1000,
          email: normalizeEmail(auth.email)
        };
        await storage.set({ [AUTH_TOKEN_KEY]: nextAuth });
        setAuthRefreshDiagnostics({
          lastResult: "success",
          lastReason: reason,
          lastErrorClass: "",
          lastStatus: response.status,
          lastError: "",
          expiresInMs: Math.max(0, Number(nextAuth.expires_at || 0) - now())
        });
        return authResult(nextAuth, {
          authState: forceRefresh ? "forced_refresh_token" : "refreshed_access_token",
          refreshAttempted: true,
          refreshSucceeded: true,
          refreshResult: "success"
        });
      }

      lastFailure = {
        ...classifyRefreshFailure(response.status, data),
        status: response.status
      };
      if (lastFailure.errorClass === "transient" && attempt < attempts - 1) {
        await waitForRefreshRetry(attempt);
        continue;
      }
      break;
    }

    if (lastFailure.errorClass === "auth_rejected") {
      const currentAuth = await getStoredAuth();
      if (!storedAuthMatchesRefreshToken(currentAuth, refreshToken)) {
        const currentResult = authResult(currentAuth, {
          authState: "stale_refresh_rejection_ignored",
          refreshAttempted: true,
          refreshSucceeded: false,
          refreshResult: "stale_rejection_ignored",
          refreshErrorClass: "auth_rejected"
        });
        setAuthRefreshDiagnostics({
          lastResult: "stale_rejection_ignored",
          lastReason: reason,
          lastErrorClass: "auth_rejected",
          lastStatus: lastFailure.status,
          lastError: lastFailure.message,
          expiresInMs: currentResult.expiresInMs
        });
        return currentResult;
      }
      await storage.remove([AUTH_TOKEN_KEY, LICENSE_CACHE_KEY]);
      clearFeatureValidationCache();
      runtimeCapabilityCache = { value: null, at: 0 };
      await clearLicenseBackoff();
      invalidateLicenseAuthGeneration();
      setAuthRefreshDiagnostics({
        lastResult: "auth_rejected",
        lastReason: reason,
        lastErrorClass: "auth_rejected",
        lastStatus: lastFailure.status,
        lastError: lastFailure.message,
        expiresInMs: 0
      });
      return authResult(null, {
        authState: "refresh_rejected",
        refreshAttempted: true,
        refreshSucceeded: false,
        refreshResult: "auth_rejected",
        refreshErrorClass: "auth_rejected"
      });
    }

    setAuthRefreshDiagnostics({
      lastResult: "transient_failed",
      lastReason: reason,
      lastErrorClass: "transient",
      lastStatus: lastFailure.status,
      lastError: lastFailure.message,
      expiresInMs: previousExpiresInMs
    });
    return authResult(auth, {
      token: null,
      authState: "refresh_transient_failed",
      refreshAttempted: true,
      refreshSucceeded: false,
      refreshResult: "transient_failed",
      refreshErrorClass: "transient"
    });
  }

  async function digestHex(text) {
    const digest = await cryptoImpl.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  async function hmacHex(payload) {
    try {
      const runtimeId = String(runtimeIdProvider() || "");
      const keyData = new TextEncoder().encode(runtimeId + HMAC_SALT);
      const key = await cryptoImpl.subtle.importKey(
        "raw",
        keyData,
        { name: "HMAC", hash: "SHA-256" },
        false,
        ["sign"]
      );
      const signature = await cryptoImpl.subtle.sign(
        "HMAC",
        key,
        new TextEncoder().encode(stableJson(payload))
      );
      return Array.from(new Uint8Array(signature)).map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch {
      return null;
    }
  }

  async function writeLicenseCache(data) {
    const payload = normalizeCachePayload({ ...data, cached_at: now() });
    const hmac = await hmacHex(payload);
    await storage.set({ [LICENSE_CACHE_KEY]: { payload, hmac } });
  }

  async function getCachedLicense(ignoreExpiry = false) {
    const stored = await storage.get(LICENSE_CACHE_KEY);
    const cached = stored?.[LICENSE_CACHE_KEY];
    if (!cached) return null;
    if (!cached.payload) {
      await storage.remove(LICENSE_CACHE_KEY);
      return null;
    }
    const normalizedPayload = normalizeCachePayload(cached.payload);
    const hmac = await hmacHex(normalizedPayload);
    if (!hmac || hmac !== cached.hmac) {
      await storage.remove(LICENSE_CACHE_KEY);
      return null;
    }
    if (!ignoreExpiry && now() - Number(normalizedPayload.cached_at || 0) > CACHE_TTL_MS) return null;
    return normalizedPayload;
  }

  async function getCachedActiveProLicense(options = {}) {
    const maxAgeMs = Number(options.maxAgeMs || ACTIVE_PRO_GRACE_MS);
    const cached = await getCachedLicense(true);
    if (!cached) return { ok: false, reason: "missing_verified_license_cache" };
    const ageMs = Math.max(0, now() - Number(cached.cached_at || 0));
    if (ageMs > maxAgeMs) return { ok: false, reason: "verified_license_cache_expired", ageMs };
    const account = deriveBillingAccountState({
      signedIn: Boolean(cached.email || cached.user_id || cached.userId),
      email: cached.email || "",
      tier: cached.tier || "free",
      license: cached
    });
    if (!account.hasProAccess) {
      return {
        ok: false,
        reason: "cached_license_not_active_pro",
        ageMs,
        tier: account.rawPlan,
        subscriptionStatus: account.subscriptionStatus,
        billingHealth: "stale_cached_pro_rejected"
      };
    }
    return {
      ok: true,
      source: "verified_license_cache",
      ageMs,
      tier: account.plan || "pro",
      subscriptionStatus: account.subscriptionStatus,
      email: normalizeEmail(cached.email || ""),
      license: cached
    };
  }

  function licenseAuthIdentityKey(authMeta = {}) {
    return stableJson({
      email: normalizeEmail(authMeta.email || ""),
      projectRef: String(authMeta.tokenProjectRef || ""),
      userIdPrefix: String(authMeta.userIdPrefix || "")
    });
  }

  function licenseAuthScopeKey(authMeta = {}, token = "") {
    return stableJson({
      identity: licenseAuthIdentityKey(authMeta),
      tokenPrefix: String(token || "").slice(0, 24)
    });
  }

  function licenseRequestKey(action, extraBody = {}, authMeta = {}, token = "") {
    return stableJson({
      action: String(action || "check"),
      body: normalizeCachePayload(extraBody || {}),
      auth: licenseAuthScopeKey(authMeta, token)
    });
  }

  function licenseAuthIdentityForAuth(auth = {}) {
    const diagnostics = decodeJwtDiagnostics(auth?.access_token || "");
    return licenseAuthIdentityKey({
      email: normalizeEmail(auth?.email || ""),
      tokenProjectRef: diagnostics.tokenProjectRef,
      userIdPrefix: diagnostics.userIdPrefix
    });
  }

  async function licenseAuthIdentityStillCurrent(identity) {
    const auth = await getStoredAuth();
    return licenseAuthIdentityForAuth(auth || {}) === identity;
  }

  function licenseBackoffKey(action) {
    return String(action || "check").trim() || "check";
  }

  function normalizeLicenseBackoffEntry(entry = {}) {
    const until = Number(entry.until || 0) || 0;
    if (until <= now()) return null;
    return {
      attempt: Math.max(1, Math.min(10, Number(entry.attempt || 1) || 1)),
      status: Number(entry.status || 0) || 0,
      error: String(entry.error || "").slice(0, 180),
      until
    };
  }

  async function persistLicenseBackoff() {
    licenseBackoffHydrated = true;
    const entries = {};
    for (const [key, entry] of licenseBackoffByAction.entries()) {
      const normalized = normalizeLicenseBackoffEntry(entry);
      if (normalized) entries[key] = normalized;
      else licenseBackoffByAction.delete(key);
    }
    if (Object.keys(entries).length > 0) {
      await storage.set({ [LICENSE_BACKOFF_KEY]: entries });
    } else {
      await storage.remove(LICENSE_BACKOFF_KEY);
    }
  }

  async function hydrateLicenseBackoff() {
    if (licenseBackoffHydrated) return;
    if (!licenseBackoffHydratePromise) {
      licenseBackoffHydratePromise = (async () => {
        licenseBackoffHydrated = true;
        const stored = await storage.get(LICENSE_BACKOFF_KEY);
        const entries = stored?.[LICENSE_BACKOFF_KEY];
        if (!entries || typeof entries !== "object" || Array.isArray(entries)) return;
        let changed = false;
        for (const [key, entry] of Object.entries(entries)) {
          const normalized = normalizeLicenseBackoffEntry(entry);
          if (normalized) licenseBackoffByAction.set(key, normalized);
          else {
            licenseBackoffByAction.delete(key);
            changed = true;
          }
        }
        if (changed) await persistLicenseBackoff();
      })().finally(() => {
        licenseBackoffHydratePromise = null;
      });
    }
    await licenseBackoffHydratePromise;
  }

  async function deleteLicenseBackoffEntry(action) {
    const key = licenseBackoffKey(action);
    if (licenseBackoffByAction.delete(key)) {
      await persistLicenseBackoff();
      return true;
    }
    if (!licenseBackoffHydrated) {
      await hydrateLicenseBackoff();
      if (licenseBackoffByAction.delete(key)) {
        await persistLicenseBackoff();
        return true;
      }
    }
    return false;
  }

  async function clearLicenseBackoff() {
    licenseBackoffByAction.clear();
    licenseBackoffHydrated = true;
    await storage.remove(LICENSE_BACKOFF_KEY);
  }

  function retryableLicenseFailure(status = 0) {
    const code = Number(status || 0) || 0;
    return code === 0 || code === 402 || code === 429 || code >= 500;
  }

  async function currentLicenseBackoff(action) {
    const key = licenseBackoffKey(action);
    await hydrateLicenseBackoff();
    const rawEntry = licenseBackoffByAction.get(key);
    const entry = normalizeLicenseBackoffEntry(rawEntry);
    if (!entry) {
      if (rawEntry) await deleteLicenseBackoffEntry(action);
      return null;
    }
    return {
      ...entry,
      retryAfterMs: Math.max(0, Number(entry.until || 0) - now())
    };
  }

  function licenseBackoffPayload(action, backoff) {
    return {
      action,
      error: "license_backoff_active",
      reason: "license_backoff_active",
      offline: true,
      retryAfterMs: backoff.retryAfterMs,
      backoffAttempt: Number(backoff.attempt || 1),
      lastStatus: Number(backoff.status || 0) || 0,
      lastError: String(backoff.error || "")
    };
  }

  async function noteLicenseRequestSuccess(action) {
    await deleteLicenseBackoffEntry(action);
  }

  async function noteLicenseRequestFailure(action, status = 0, error = "") {
    if (!retryableLicenseFailure(status)) return;
    const key = licenseBackoffKey(action);
    await hydrateLicenseBackoff();
    const previous = licenseBackoffByAction.get(key);
    const attempt = Math.min(10, Number(previous?.attempt || 0) + 1);
    const baseDelay = Math.min(LICENSE_BACKOFF_MAX_MS, LICENSE_BACKOFF_BASE_MS * (2 ** (attempt - 1)));
    const jitter = 0.75 + Math.max(0, Math.min(1, Number(random?.() ?? 0.5))) * 0.5;
    licenseBackoffByAction.set(key, {
      attempt,
      status: Number(status || 0) || 0,
      error: String(error || "").slice(0, 180),
      until: now() + Math.round(baseDelay * jitter)
    });
    await persistLicenseBackoff();
  }

  async function checkRateLimit(action, maxPerWindow, windowMs, scope = "global") {
    const stored = await storage.get(RATE_LIMIT_KEY);
    const limits = stored?.[RATE_LIMIT_KEY] || {};
    const key = `${action}:${scope}`;
    const current = now();
    const history = (limits[key] || []).filter((timestamp) => current - timestamp < windowMs);
    if (history.length >= maxPerWindow) {
      const waitSec = Math.ceil((history[0] + windowMs - current) / 1000);
      throw new Error(`Too many attempts. Try again in ${waitSec}s.`);
    }
    history.push(current);
    limits[key] = history;
    await storage.set({ [RATE_LIMIT_KEY]: limits });
  }

  async function getDeviceFingerprint() {
    const env = environmentProvider() || {};
    const screenInfo = env.screen || {};
    const raw = `${runtimeIdProvider()}-${env.userAgent || ""}-${screenInfo.width || 0}x${screenInfo.height || 0}`;
    return digestHex(raw);
  }

  async function signInWithMagicLink(email) {
    const normalizedEmail = normalizeEmail(email);
    if (!normalizedEmail) throw new Error("Enter your email first.");
    await checkRateLimit(
      "magic_link",
      MAGIC_LINK_MAX_PER_WINDOW,
      MAGIC_LINK_WINDOW_MS,
      normalizedEmail
    );
    const response = await fetchImpl(`${SUPABASE_URL}/auth/v1/otp`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_ANON_KEY
      },
      body: JSON.stringify({ email: normalizedEmail })
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      const retryAfter = Number.parseInt(response.headers?.get?.("retry-after") || "", 10);
      const msg = String(error.msg || error.error_description || error.error || "").trim();
      if (response.status === 429) {
        throw new Error(Number.isFinite(retryAfter) && retryAfter > 0
          ? `Too many attempts. Try again in ${retryAfter}s.`
          : "Too many attempts. Wait a minute, then resend the code.");
      }
      throw new Error(msg || `Code request failed (HTTP ${response.status || 0}). Check the email address and try again.`);
    }
    return true;
  }

  async function verifyOtpToken(email, token) {
    const response = await fetchImpl(`${SUPABASE_URL}/auth/v1/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: SUPABASE_ANON_KEY
      },
      body: JSON.stringify({
        email: normalizeEmail(email),
        token: String(token || "").trim(),
        type: "email",
        gotrue_meta_security: {}
      })
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.msg || error.error_description || "Invalid or expired code");
    }
    const data = await response.json();
    await clearLicenseCache();
    await storage.set({
      [AUTH_TOKEN_KEY]: {
        access_token: data.access_token,
        refresh_token: data.refresh_token,
        expires_at: now() + Number(data.expires_in || 0) * 1000,
        email: normalizeEmail(email)
      }
    });
    return data;
  }

  async function resolveAccessToken(options = {}) {
    const forceRefresh = options?.forceRefresh === true;
    const minFreshMs = Math.max(0, Number(options?.minFreshMs ?? refreshFreshnessWindowMs) || 0);
    const reason = String(options?.reason || (forceRefresh ? "forced_refresh" : "access_token")).trim();
    const auth = await getStoredAuth();
    if (!auth) {
      setAuthRefreshDiagnostics({
        lastResult: "missing_auth",
        lastReason: reason,
        lastErrorClass: "",
        lastStatus: 0,
        lastError: "",
        expiresInMs: 0
      });
      return {
        token: null,
        authState: "missing_auth",
        refreshAttempted: false,
        refreshSucceeded: false,
        expiresInMs: 0,
        authRefresh: getAuthRefreshDiagnostics({ expiresInMs: 0 })
      };
    }

    const expiresInMs = Math.max(0, Number(auth.expires_at || 0) - now());
    if (!forceRefresh && Number(auth.expires_at || 0) > now() + minFreshMs) {
      setAuthRefreshDiagnostics({
        expiresInMs
      });
      return authResult(auth, {
        authState: "cached_access_token",
        refreshAttempted: false,
        refreshSucceeded: false
      });
    }

    const refreshToken = String(auth.refresh_token || "");
    const flightKey = refreshToken || "__missing_refresh_token__";
    if (refreshInFlightByToken.has(flightKey)) {
      return refreshInFlightByToken.get(flightKey);
    }
    const promise = performRefreshForAuth(auth, { ...options, reason });
    refreshInFlightByToken.set(flightKey, promise);
    try {
      return await promise;
    } finally {
      refreshInFlightByToken.delete(flightKey);
      setAuthRefreshDiagnostics({});
    }
  }

  async function signOut() {
    await storage.remove([AUTH_TOKEN_KEY, LICENSE_CACHE_KEY]);
    clearFeatureValidationCache();
    runtimeCapabilityCache = { value: null, at: 0 };
    await clearLicenseBackoff();
    invalidateLicenseAuthGeneration();
  }

  async function checkLicense(action = "check", extraBody = {}, options = {}) {
    let authMeta = await resolveAccessToken();
    let token = authMeta.token;

    if (!token) {
      if (action !== "check") {
        return {
          action,
          error: authMeta.refreshErrorClass === "transient" ? "auth_refresh_transient_failed" : "not_signed_in",
          offline: true,
          authState: authMeta.authState,
          authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
        };
      }
      return defaultLicenseData({
        offline: authMeta.refreshErrorClass === "transient",
        error: authMeta.refreshErrorClass === "transient" ? "auth_refresh_transient_failed" : undefined,
        authState: authMeta.authState,
        authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
      });
    }

    if (action === "check" && options?.forceNetwork !== true) {
      const cached = await getCachedLicense();
      if (cached) return { ...cached, source: "cache", authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics() };
    }

    if (action === "validate_feature" && extraBody?.feature_key) {
      const featureKey = String(extraBody.feature_key || "");
      const canUseFeatureCache = featureKey !== "queue_start";
      const cached = canUseFeatureCache ? featureValidationCache.get(featureKey) : null;
      if (cached && now() - cached.at < FEATURE_CACHE_TTL_MS) return cached.data;
    }

    const activeBackoff = await currentLicenseBackoff(action);
    if (activeBackoff && options.bypassBackoff !== true) {
      if (action === "check") {
        const cachedPro = await getCachedActiveProLicense();
        if (cachedPro.ok) {
          return {
            ...cachedPro.license,
            source: "stale_cache_backoff",
            offline: true,
            licenseBackoff: licenseBackoffPayload(action, activeBackoff),
            authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
          };
        }
        return defaultLicenseData({
          offline: true,
          error: "license_backoff_active",
          reason: "license_backoff_active",
          licenseBackoff: licenseBackoffPayload(action, activeBackoff),
          authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
        });
      }
      return licenseBackoffPayload(action, activeBackoff);
    }

    const requestAuthIdentity = licenseAuthIdentityKey(authMeta);
    const requestKey = licenseRequestKey(action, extraBody, authMeta, token);
    if (licenseInFlightByKey.has(requestKey)) return licenseInFlightByKey.get(requestKey);

    const requestGeneration = licenseAuthGeneration;
    const requestStillCurrent = async () => requestGeneration === licenseAuthGeneration && await licenseAuthIdentityStillCurrent(requestAuthIdentity);
    const staleLicenseResponse = () => {
      const payload = {
        error: "stale_license_response",
        reason: "stale_license_response",
        offline: true,
        authState: authMeta?.authState,
        authRefresh: authMeta?.authRefresh || getAuthRefreshDiagnostics()
      };
      if (action !== "check") return { action, ...payload };
      return defaultLicenseData(payload);
    };
    const requestPromise = (async () => {
      const deviceHash = await getDeviceFingerprint();
      const requestBody = { action, device_hash: deviceHash, ...extraBody };
      const makeRequest = (bearerToken) => fetchImpl(CHECK_LICENSE_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${bearerToken}`,
          apikey: SUPABASE_ANON_KEY
        },
        body: JSON.stringify(requestBody)
      });

      let response = await makeRequest(token);
      if (!response.ok && response.status === 401) {
        authMeta = await resolveAccessToken({ forceRefresh: true });
        token = authMeta.token;
        if (token) response = await makeRequest(token);
      }

      const data = await response.json().catch(() => ({}));
      const currentRequest = await requestStillCurrent();
      if (!response.ok) {
        const message = data.error || data.message || `License check failed (${response.status || 0})`;
        if (currentRequest) await noteLicenseRequestFailure(action, response.status, message);
        else return staleLicenseResponse();
        if (response.status === 429 && data && typeof data === "object" && Object.keys(data).length > 0) {
          return {
            ...data,
            offline: true,
            rateLimited: true,
            authState: authMeta.authState,
            authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
          };
        }
        throw Object.assign(new Error(message), { status: response.status, data, backoffRecorded: true });
      }

      if (!currentRequest) return staleLicenseResponse();
      await noteLicenseRequestSuccess(action);
      const payload = {
        ...data,
        authState: authMeta.authState,
        authRefresh: authMeta.authRefresh || getAuthRefreshDiagnostics()
      };
      if (action === "check") await writeLicenseCache(payload);
      if (action === "validate_feature" && extraBody?.feature_key) {
        const featureKey = String(extraBody.feature_key || "");
        if (featureKey !== "queue_start") {
          featureValidationCache.set(featureKey, { data: payload, at: now() });
        }
      }
      return payload;
    })();
    const wrappedPromise = requestPromise.catch(async (error) => {
      if (!await requestStillCurrent()) return staleLicenseResponse();
      if (error?.backoffRecorded !== true) {
        await noteLicenseRequestFailure(action, Number(error?.status || 0) || 0, error?.message || "license_action_failed");
      }
      if (action !== "check") {
        const responseDetails = error?.data && typeof error.data === "object" ? error.data : {};
        return {
          action,
          error: error?.message || "license_action_failed",
          ...(responseDetails.stripe_status ? { stripe_status: Number(responseDetails.stripe_status) } : {}),
          ...(responseDetails.stripe_code ? { stripe_code: String(responseDetails.stripe_code) } : {}),
          ...(responseDetails.stripe_message ? { stripe_message: String(responseDetails.stripe_message).slice(0, 300) } : {}),
          offline: true,
          authState: authMeta?.authState,
          authRefresh: authMeta?.authRefresh || getAuthRefreshDiagnostics()
        };
      }
      const cachedPro = await getCachedActiveProLicense();
      const cached = cachedPro.ok ? cachedPro.license : null;
      if (cached) {
        return { ...cached, offline: true, authRefresh: authMeta?.authRefresh || getAuthRefreshDiagnostics() };
      }
      return defaultLicenseData({
        offline: true,
        error: String(error?.message || "license_check_failed"),
        authState: authMeta?.authState,
        authRefresh: authMeta?.authRefresh || getAuthRefreshDiagnostics()
      });
    }).finally(() => {
      if (licenseInFlightByKey.get(requestKey) === wrappedPromise) {
        licenseInFlightByKey.delete(requestKey);
      }
    });
    licenseInFlightByKey.set(requestKey, wrappedPromise);
    return wrappedPromise;
  }

  async function validateFeatureAccess(featureKey, resourceContext = {}) {
    let serverResponded = false;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      const data = await checkLicense("validate_feature", {
        feature_key: featureKey,
        resource_context: resourceContext
      });
      if (data?.error === "not_signed_in") {
        return { allowed: false, source: "auth", reason: "not_signed_in", authState: data.authState || "missing_auth" };
      }
      if (typeof data?.allowed === "boolean") return { ...data, source: "server" };
      if (!data?.offline) serverResponded = true;
      if (attempt === 0 && !serverResponded && featureRetryDelayMs > 0) {
        await new Promise((resolve) => setTimeout(resolve, featureRetryDelayMs));
      }
    }
    if (serverResponded) {
      return {
        allowed: false,
        source: "server",
        reason: "missing_feature_decision"
      };
    }
    return {
      allowed: false,
      source: "fallback",
      reason: "server_unavailable"
    };
  }

  function licenseFromUsageResponse(data = {}) {
    const nested = data?.license && typeof data.license === "object" ? data.license : null;
    const candidate = nested || data;
    if (!candidate || typeof candidate !== "object") return null;
    const hasLicenseShape = [
      "tier",
      "email",
      "prompts_today",
      "promptsToday",
      "prompt_limit",
      "promptLimit",
      "subscription_status",
      "subscriptionStatus"
    ].some((key) => candidate[key] !== undefined);
    return hasLicenseShape ? candidate : null;
  }

  async function recordPromptUsage(options = {}) {
    const promptCount = Math.max(1, Math.floor(Number(options.promptCount || options.prompt_count || 1) || 1));
    const usageType = String(options.usageType || options.usage_type || "prompt_use").trim() || "prompt_use";
    await storage.remove(LICENSE_CACHE_KEY);
    const data = await checkLicense("log_usage", {
      usage_type: usageType,
      prompt_count: promptCount,
      task_id: String(options.taskId || options.task_id || "").trim(),
      mode: String(options.mode || "").trim(),
      submit_path: String(options.submitPath || options.submit_path || "").trim(),
      source: String(options.source || "queue_submit").trim(),
      idempotency_key: String(options.idempotencyKey || options.idempotency_key || "").trim()
    });
    if (data?.error || data?.allowed === false) {
      return {
        ok: false,
        action: "log_usage",
        error: data?.error || data?.reason || "usage_recording_rejected",
        reason: data?.reason || data?.error || "usage_recording_rejected",
        offline: data?.offline === true,
        raw: data
      };
    }

    let license = licenseFromUsageResponse(data);
    if (license) {
      await writeLicenseCache(license);
    } else {
      license = await refreshLicense();
    }
    return {
      ok: true,
      action: "log_usage",
      promptCount,
      usageType,
      license,
      raw: data
    };
  }

  async function fetchRuntimeCapabilities(options = {}) {
    const force = options?.force === true;
    const requestedCapabilities = Array.isArray(options?.requestedCapabilities)
      ? [...new Set(options.requestedCapabilities.map((item) => String(item || "").trim()).filter(Boolean))]
      : [];
    const build = buildInfoProvider();
    if (!force && runtimeCapabilityCache.value && now() - runtimeCapabilityCache.at < RUNTIME_CAPABILITY_CACHE_TTL_MS) {
      return {
        ok: true,
        source: "server_cache",
        build,
        capabilities: { ...runtimeCapabilityCache.value }
      };
    }
    const data = await checkLicense("runtime_capabilities", {
      build_id: build.buildId,
      version: build.version,
      version_name: build.versionName,
      extension_id: build.extensionId,
      requested_capabilities: requestedCapabilities
    });
    const capabilities = normalizeRuntimeCapabilities(data);
    if (!capabilities) {
      return {
        ok: false,
        source: data?.offline ? "fallback" : "server",
        reason: data?.error || "invalid_capability_response",
        build,
        capabilities: {}
      };
    }
    runtimeCapabilityCache = { value: capabilities, at: now() };
    return { ok: true, source: "server", build, capabilities: { ...capabilities } };
  }

  async function refreshLicense(options = {}) {
    const token = await resolveAccessToken({ forceRefresh: false, reason: "refresh_license" });
    if (!token.token) {
      const cached = await getCachedLicense(true);
      if (token.refreshErrorClass === "transient" && cached) {
        return { ...cached, offline: true, authState: token.authState, authRefresh: token.authRefresh || getAuthRefreshDiagnostics() };
      }
      return defaultLicenseData({
        offline: token.refreshErrorClass === "transient",
        error: token.refreshErrorClass === "transient" ? "auth_refresh_transient_failed" : undefined,
        authState: token.authState,
        authRefresh: token.authRefresh || getAuthRefreshDiagnostics()
      });
    }
    const cached = await getCachedLicense(true);
    const cooldownMs = Math.max(0, Number(options.cooldownMs ?? LICENSE_REFRESH_COOLDOWN_MS) || 0);
    if (options.forceNetwork !== true && cached && now() - Number(cached.cached_at || 0) < cooldownMs) {
      const cachedPro = await getCachedActiveProLicense({ maxAgeMs: cooldownMs });
      if (cachedPro.ok) {
        return {
          ...cachedPro.license,
          source: "fresh_check_cooldown",
          refreshSuppressed: true,
          authState: token.authState,
          authRefresh: token.authRefresh || getAuthRefreshDiagnostics()
        };
      }
      // Non-Pro caches may become stale immediately after upgrade; live-write
      // gates need the server instead of suppressing the refresh.
    }
    const data = await checkLicense("check", {}, { forceNetwork: true });
    return data?.tier ? data : defaultLicenseData(data || {});
  }

  async function initLicense(options = {}) {
    const auth = await getStoredAuth();
    if (!auth?.email) return defaultLicenseData({ authRefresh: getAuthRefreshDiagnostics() });
    const data = options?.forceFresh === true
      ? await refreshLicense()
      : await checkLicense("check");
    if (data.email === undefined) data.email = normalizeEmail(auth.email);
    return data;
  }

  async function createCheckout(options = {}) {
    const current = now();
    const requestId = String(options.clientRequestId || options.idempotencyKey || randomRequestId(current));
    const stored = await storage.get([CHECKOUT_LOCK_KEY, CHECKOUT_LAST_KEY]);
    const lock = stored?.[CHECKOUT_LOCK_KEY];
    const last = stored?.[CHECKOUT_LAST_KEY];
    if (lock?.at && current - Number(lock.at || 0) < CHECKOUT_LOCK_TTL_MS) {
      return { ok: false, error: "checkout_in_progress" };
    }
    if (last?.checkout_url && last?.at && current - Number(last.at || 0) < CHECKOUT_REUSE_TTL_MS) {
      return { ok: true, checkout_url: last.checkout_url, reused: true };
    }
    await storage.set({
      [CHECKOUT_LOCK_KEY]: {
        at: current,
        request_id: requestId,
        source: String(options.source || "sidepanel")
      }
    });
    try {
      const data = await checkLicense("create_checkout", {
        client_request_id: requestId,
        idempotency_key: requestId,
        request_source: String(options.source || "sidepanel")
      });
      if (data.checkout_url) {
        await storage.set({
          [CHECKOUT_LAST_KEY]: {
            checkout_url: data.checkout_url,
            at: now(),
            request_id: requestId,
            source: String(options.source || "sidepanel")
          }
        });
        return { ok: true, checkout_url: data.checkout_url };
      }
      return { ok: false, error: data.error || "missing_checkout_url" };
    } finally {
      await storage.remove(CHECKOUT_LOCK_KEY);
    }
  }

  async function startUpgradeFlow(options = {}) {
    if (checkoutRequestPromise) return checkoutRequestPromise;
    checkoutRequestPromise = (async () => {
      const result = await createCheckout(options);
      if (result.checkout_url) await openTab(result.checkout_url);
      return result;
    })();
    try {
      return await checkoutRequestPromise;
    } finally {
      checkoutRequestPromise = null;
    }
  }

  async function openManageSubscription() {
    // This is an explicit user click. A prior portal failure may have armed the
    // general request backoff, but it must not make the button dead after the
    // backend/customer configuration has been repaired.
    const data = await checkLicense("create_portal", {}, { bypassBackoff: true });
    const portalUrl = resolveStripeBillingPortalUrl(data);
    if (portalUrl) {
      await openTab(portalUrl);
      return { ok: true, portal_url: portalUrl };
    }
    // Accept the common Stripe URL response shapes, but fail closed on any
    // missing or non-Stripe URL so the sidepanel never claims a tab opened.
    const code = billingPortalFailureCode(data) || "missing_portal_url";
    throw Object.assign(new Error(billingPortalFailureMessage({ ...data, code })), {
      code,
      data
    });
  }

  async function authSummary(data = null, options = {}) {
    const auth = await getStoredAuth();
    let license = data;
    if (!license && options?.allowNetwork === false) {
      let cached = await getCachedLicense(true);
      if (cached) {
        const cachedAccount = deriveBillingAccountState({
          signedIn: Boolean(cached.email || cached.user_id || cached.userId),
          email: cached.email || "",
          tier: cached.tier || "free",
          license: cached
        });
        if (cachedAccount.hasProAccess) {
          const cachedPro = await getCachedActiveProLicense();
          if (!cachedPro.ok) cached = null;
        }
      }
      license = cached
        ? { ...cached, source: cached.source || "cache_snapshot", authRefresh: getAuthRefreshDiagnostics() }
        : defaultLicenseData({ authRefresh: getAuthRefreshDiagnostics() });
    }
    if (!license) license = await initLicense(options);
    const billing = deriveBillingAccountState({
      signedIn: Boolean(auth?.email || license?.email),
      email: normalizeEmail(license?.email || auth?.email || ""),
      tier: license?.tier || "free",
      license
    });
    return {
      signedIn: billing.status === "signed_in",
      email: billing.email || "",
      tier: billing.rawPlan,
      license,
      hasActiveSubscription: billing.hasActiveSubscription,
      subscriptionStatus: billing.subscriptionStatus,
      billingHealth: billing.billingHealth,
      authRefresh: license?.authRefresh || getAuthRefreshDiagnostics()
    };
  }

  return {
    getDeviceFingerprint,
    signInWithMagicLink,
    verifyOtpToken,
    resolveAccessToken,
    signOut,
    checkLicense,
    validateFeatureAccess,
    recordPromptUsage,
    getCachedActiveProLicense,
    fetchRuntimeCapabilities,
    refreshLicense,
    initLicense,
    createCheckout,
    startUpgradeFlow,
    openManageSubscription,
    authSummary,
    getAuthRefreshDiagnostics
  };
}
