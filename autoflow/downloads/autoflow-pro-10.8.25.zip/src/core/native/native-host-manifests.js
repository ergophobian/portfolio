import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

export const AUTO_FLOW_NATIVE_HOST_NAME = "com.autoflow.agent";

const HOST_DESCRIPTION = "Auto Flow local agent bridge native messaging host";
const MAC_BROWSER_TARGETS = [
  {
    scope: "chrome-user",
    browser: "Google Chrome",
    relativeDir: "Library/Application Support/Google/Chrome/NativeMessagingHosts"
  },
  {
    scope: "chrome-testing-user",
    browser: "Chrome for Testing",
    relativeDir: "Library/Application Support/Google/Chrome for Testing/NativeMessagingHosts"
  },
  {
    scope: "chromium-user",
    browser: "Chromium",
    relativeDir: "Library/Application Support/Chromium/NativeMessagingHosts"
  }
];

export function validateNativeHostExtensionId(value = "") {
  const raw = String(value || "").trim();
  const match = raw.match(/^chrome-extension:\/\/([a-p]{32})\/?$/i);
  const id = match ? match[1] : raw;
  const ok = /^[a-p]{32}$/i.test(id);
  return {
    ok,
    code: ok ? "OK" : "INVALID_EXTENSION_ID",
    value: ok ? id.toLowerCase() : "",
    inputProvided: Boolean(raw),
    expected: "32 Chrome extension id characters in the range a-p, or chrome-extension://<id>/"
  };
}

export function buildExpectedNativeHostManifest({ extensionId = "", hostPath = "" } = {}) {
  const extensionIdCheck = validateNativeHostExtensionId(extensionId);
  return {
    name: AUTO_FLOW_NATIVE_HOST_NAME,
    description: HOST_DESCRIPTION,
    path: path.resolve(String(hostPath || "")),
    type: "stdio",
    allowed_origins: extensionIdCheck.ok ? [`chrome-extension://${extensionIdCheck.value}/`] : []
  };
}

export async function discoverNativeHostManifestTargets(options = {}) {
  const platform = String(options.platform || process.platform);
  const manifestDirs = optionList(options.manifestDirs ?? options.manifestDir ?? options["manifest-dir"]);
  const profileDirs = optionList(options.profileDirs ?? options.profileDir ?? options["profile-dir"]);
  const allBrowserManifests = truthy(options.allBrowserManifests) || truthy(options["all-browser-manifests"]);
  const autoDetect = truthy(options.autoDetect) || truthy(options["auto-detect"]);
  const targets = [];

  if (platform === "darwin") {
    const homeDir = path.resolve(String(options.homeDir || options["home-dir"] || os.homedir()));
    if (allBrowserManifests || autoDetect || !manifestDirs.length) {
      const browserTargets = allBrowserManifests || autoDetect ? MAC_BROWSER_TARGETS : MAC_BROWSER_TARGETS.slice(0, 1);
      for (const target of browserTargets) {
        targets.push(targetForDir(path.join(homeDir, target.relativeDir), {
          scope: target.scope,
          browser: target.browser
        }));
      }
    }
    for (const profileDir of profileDirs) {
      targets.push(...await profileTargets(profileDir));
    }
    for (const manifestDir of manifestDirs) {
      targets.push(targetForDir(manifestDir, {
        scope: "custom",
        browser: "unknown"
      }));
    }
    return dedupeTargets(targets);
  }

  if (platform === "win32") {
    const fallbackDir = options.hostPath
      ? path.dirname(path.resolve(String(options.hostPath)))
      : path.join(os.homedir(), "AppData/Roaming/AutoFlowNativePackage/native-host");
    return [targetForDir(manifestDirs[0] || fallbackDir, {
      scope: "windows-registry",
      browser: "Google Chrome"
    })];
  }

  for (const manifestDir of manifestDirs) {
    targets.push(targetForDir(manifestDir, {
      scope: "custom",
      browser: "unknown"
    }));
  }
  return dedupeTargets(targets);
}

export async function readNativeHostManifest(manifestPath = "") {
  const resolved = path.resolve(String(manifestPath || ""));
  try {
    const raw = await fs.readFile(resolved, "utf8");
    try {
      return {
        path: resolved,
        exists: true,
        validJson: true,
        raw,
        value: JSON.parse(raw)
      };
    } catch (error) {
      return {
        path: resolved,
        exists: true,
        validJson: false,
        raw,
        value: null,
        error: error?.message || String(error)
      };
    }
  } catch (error) {
    return {
      path: resolved,
      exists: false,
      validJson: false,
      raw: "",
      value: null,
      error: error?.message || String(error)
    };
  }
}

export async function analyzeNativeHostManifest(input = {}) {
  const manifestPath = path.resolve(String(input.path || ""));
  const expected = input.expected || {};
  const platform = String(input.platform || process.platform);
  const expectedAllowedOrigin = Array.isArray(expected.allowed_origins) ? String(expected.allowed_origins[0] || "") : "";
  const expectedHostPath = path.resolve(String(expected.path || ""));
  const installed = input.installed || await readNativeHostManifest(manifestPath);
  const manifest = installed.value || {};
  const actualAllowedOrigins = Array.isArray(manifest.allowed_origins) ? manifest.allowed_origins.map((entry) => String(entry)) : [];
  const actualHostPath = typeof manifest.path === "string" ? manifest.path : "";
  const hostStats = expectedHostPath ? await fileState(expectedHostPath, platform) : { exists: false, executable: false };

  let status = "ok";
  let repairAction = "none";
  if (!installed.exists) {
    status = "missing";
    repairAction = "write_manifest";
  } else if (!installed.validJson) {
    status = "invalid_json";
    repairAction = "write_manifest";
  } else if (!expectedAllowedOrigin || actualAllowedOrigins.length !== 1 || actualAllowedOrigins[0] !== expectedAllowedOrigin) {
    status = "stale_origin";
    repairAction = "replace_allowed_origin";
  } else if (path.resolve(actualHostPath || ".") !== expectedHostPath) {
    status = "stale_host_path";
    repairAction = "replace_host_path";
  } else if (!hostStats.exists) {
    status = "host_missing";
    repairAction = "none";
  } else if (!hostStats.executable) {
    status = "host_not_executable";
    repairAction = "chmod_host";
  }

  return {
    path: manifestPath,
    scope: input.scope || "custom",
    browser: input.browser || "unknown",
    profileDir: input.profileDir || "",
    exists: installed.exists === true,
    validJson: installed.validJson === true,
    expectedAllowedOrigin,
    actualAllowedOrigins,
    expectedHostPath,
    actualHostPath,
    hostExists: hostStats.exists === true,
    hostExecutable: hostStats.executable === true,
    status,
    repairAction,
    restartRequired: status !== "ok" && repairAction !== "none",
    error: installed.validJson === false || installed.exists === false ? installed.error || "" : ""
  };
}

export async function repairNativeHostManifest({ path: manifestPath = "", expected = {}, dryRun = false, target = {} } = {}) {
  const before = await analyzeNativeHostManifest({
    path: manifestPath,
    expected,
    ...target
  });
  const needsManifestWrite = ["missing", "invalid_json", "stale_origin", "stale_host_path"].includes(before.status);
  const needsChmod = before.status === "host_not_executable";
  const changed = needsManifestWrite || needsChmod;

  if (!dryRun && needsManifestWrite) {
    await fs.mkdir(path.dirname(before.path), { recursive: true });
    await fs.writeFile(before.path, `${JSON.stringify(expected, null, 2)}\n`);
  }
  if (!dryRun && needsChmod) {
    await fs.chmod(expected.path, 0o755);
  }

  const after = dryRun
    ? {
        ...before,
        plannedManifest: needsManifestWrite ? expected : undefined,
        status: changed ? before.status : "ok"
      }
    : await analyzeNativeHostManifest({
        path: manifestPath,
        expected,
        ...target
      });

  return {
    path: before.path,
    dryRun: dryRun === true,
    changed: dryRun ? false : changed,
    wouldChange: dryRun ? changed : false,
    repairAction: before.repairAction,
    restartRequired: dryRun ? false : changed,
    before,
    after
  };
}

export async function doctorNativeHostManifests(options = {}) {
  const extensionIdCheck = validateNativeHostExtensionId(options.extensionId || options["extension-id"]);
  const hostPath = path.resolve(String(options.hostPath || options.launcherPath || options["launcher-path"] || ""));
  const platform = String(options.platform || process.platform);
  const expected = buildExpectedNativeHostManifest({
    extensionId: extensionIdCheck.value,
    hostPath
  });
  const targets = await discoverNativeHostManifestTargets(options);
  const fix = truthy(options.fix) || truthy(options.repair) || truthy(options.write);
  const canFix = fix && extensionIdCheck.ok;
  const dryRun = truthy(options.dryRun) || truthy(options["dry-run"]);
  const repairResults = [];
  const manifests = [];

  for (const target of targets) {
    if (canFix) {
      const repair = await repairNativeHostManifest({
        path: target.path,
        expected,
        dryRun,
        target: { ...target, platform }
      });
      repairResults.push(repair);
      manifests.push(repair.after);
    } else {
      manifests.push(await analyzeNativeHostManifest({
        path: target.path,
        expected,
        ...target,
        platform
      }));
    }
  }

  const repairs = [
    ...(!extensionIdCheck.ok ? [{
      code: "EXTENSION_ID_REQUIRED",
      message: "Pass a valid --extension-id before repairing native messaging manifests.",
      command: ""
    }] : []),
    ...buildRepairEntries(manifests, {
      extensionId: extensionIdCheck.value,
      profileDirs: optionList(options.profileDirs ?? options.profileDir ?? options["profile-dir"])
    })
  ];
  const changed = repairResults.some((entry) => entry.changed);
  const wouldChange = repairResults.some((entry) => entry.wouldChange);

  return {
    ok: extensionIdCheck.ok && manifests.every((entry) => entry.status === "ok"),
    hostName: AUTO_FLOW_NATIVE_HOST_NAME,
    platform,
    extensionId: extensionIdCheck.value,
    extensionIdCheck,
    expectedAllowedOrigin: expected.allowed_origins[0] || "",
    launcherPath: hostPath,
    hostPath,
    manifests,
    repairs,
    repairResults,
    restartRequired: {
      browser: changed,
      clients: [],
      reason: changed ? "native messaging manifest changed" : ""
    },
    dryRun,
    wouldRestart: wouldChange
  };
}

export function buildNativeHostRepairCommand({ extensionId = "", profileDir = "", allBrowserManifests = true } = {}) {
  const idCheck = validateNativeHostExtensionId(extensionId);
  if (!idCheck.ok) return "";
  const parts = ["autoflow", "doctor", "--fix", "--extension-id", idCheck.value];
  if (allBrowserManifests) parts.push("--all-browser-manifests");
  if (profileDir) parts.push("--profile-dir", shellQuote(profileDir));
  return parts.join(" ");
}

function buildRepairEntries(manifests = [], context = {}) {
  const repairs = [];
  for (const manifest of manifests) {
    if (manifest.status === "ok") continue;
    const command = buildNativeHostRepairCommand({
      extensionId: context.extensionId,
      profileDir: manifest.profileDir || optionList(context.profileDirs)[0] || "",
      allBrowserManifests: true
    });
    if (manifest.status === "stale_origin") {
      repairs.push({
        code: "EXTENSION_ORIGIN_MISMATCH",
        path: manifest.path,
        message: `Manifest allows ${manifest.actualAllowedOrigins.join(", ") || "no extension origins"}; expected ${manifest.expectedAllowedOrigin}.`,
        command
      });
    }
    if (manifest.status === "stale_host_path" || (manifest.actualHostPath && manifest.actualHostPath !== manifest.expectedHostPath)) {
      repairs.push({
        code: "HOST_PATH_MISMATCH",
        path: manifest.path,
        message: `Manifest points at ${manifest.actualHostPath || "(missing)"}; expected ${manifest.expectedHostPath}.`,
        command
      });
    }
    if (manifest.status === "missing") {
      repairs.push({
        code: "NATIVE_HOST_MANIFEST_MISSING",
        path: manifest.path,
        message: "Native messaging manifest is missing.",
        command
      });
    }
    if (manifest.status === "invalid_json") {
      repairs.push({
        code: "NATIVE_HOST_MANIFEST_INVALID_JSON",
        path: manifest.path,
        message: manifest.error || "Native messaging manifest is not valid JSON.",
        command
      });
    }
    if (manifest.status === "host_missing") {
      repairs.push({
        code: "NATIVE_HOST_LAUNCHER_MISSING",
        path: manifest.path,
        message: `Native host launcher is missing: ${manifest.expectedHostPath}.`,
        command
      });
    }
    if (manifest.status === "host_not_executable") {
      repairs.push({
        code: "NATIVE_HOST_LAUNCHER_NOT_EXECUTABLE",
        path: manifest.path,
        message: `Native host launcher is not executable: ${manifest.expectedHostPath}.`,
        command
      });
    }
  }
  return repairs;
}

async function profileTargets(profileDir) {
  const root = path.resolve(String(profileDir || ""));
  const targets = [
    targetForDir(path.join(root, "NativeMessagingHosts"), {
      scope: "profile",
      browser: "unknown",
      profileDir: root
    }),
    targetForDir(path.join(root, "Default", "NativeMessagingHosts"), {
      scope: "profile-default",
      browser: "unknown",
      profileDir: path.join(root, "Default")
    })
  ];
  let children = [];
  try {
    children = await fs.readdir(root, { withFileTypes: true });
  } catch {}
  for (const child of children) {
    if (!child.isDirectory() || !/^Profile\b/i.test(child.name)) continue;
    const childProfileDir = path.join(root, child.name);
    targets.push(targetForDir(path.join(childProfileDir, "NativeMessagingHosts"), {
      scope: "profile",
      browser: "unknown",
      profileDir: childProfileDir
    }));
  }
  return targets;
}

function targetForDir(manifestDir, meta = {}) {
  const directory = path.resolve(String(manifestDir || ""));
  return {
    path: path.join(directory, `${AUTO_FLOW_NATIVE_HOST_NAME}.json`),
    directory,
    scope: meta.scope || "custom",
    browser: meta.browser || "unknown",
    profileDir: meta.profileDir || ""
  };
}

function dedupeTargets(targets = []) {
  const seen = new Set();
  const deduped = [];
  for (const target of targets) {
    if (seen.has(target.path)) continue;
    seen.add(target.path);
    deduped.push(target);
  }
  return deduped;
}

function optionList(value) {
  const values = Array.isArray(value) ? value : [value];
  return values
    .flatMap((entry) => String(entry || "").split(","))
    .map((entry) => entry.trim())
    .filter(Boolean);
}

async function fileState(filePath = "", platform = process.platform) {
  try {
    const stats = await fs.stat(filePath);
    const windowsExecutable = String(platform || process.platform) === "win32" && path.extname(filePath).toLowerCase() === ".exe";
    return {
      exists: stats.isFile(),
      executable: stats.isFile() && (windowsExecutable || Boolean(stats.mode & 0o111)),
      mode: (stats.mode & 0o777).toString(8).padStart(4, "0")
    };
  } catch {
    return {
      exists: false,
      executable: false,
      mode: ""
    };
  }
}

function truthy(value) {
  return value === true || value === "1" || value === "true";
}

function shellQuote(value = "") {
  const text = String(value);
  if (/^[A-Za-z0-9_./:=@+-]+$/.test(text)) return text;
  return `"${text.replace(/(["\\$`])/g, "\\$1")}"`;
}
