export const DEFAULT_DIALOGUE_ALIASES = {
  "G-H-K": ["GHK", "Gee Aitch Kay", "Gee H Kay"]
};

export const TRANSCRIPT_QA_LEVELS = ["pass", "warn", "fail", "needs_human_review"];

export function evaluateTranscriptQa({
  expectedDialogue,
  expectedLines = [],
  transcriptText = "",
  aliasMap = DEFAULT_DIALOGUE_ALIASES,
  requiredPhrases = [],
  extraPhraseWarnings = [],
  cutoffPrefixMinLength = 3
} = {}) {
  const expected = normalizeExpectedLines(selectExpectedDialogueInput(expectedLines, expectedDialogue));
  const required = normalizePhraseList(requiredPhrases);
  const warningPhrases = normalizePhraseList(extraPhraseWarnings);
  const normalizedTranscript = normalizeDialogueText(transcriptText, aliasMap);
  const labeledSegments = parseSpeakerLabeledSegments(transcriptText, aliasMap);
  const hasSpeakerLabels = labeledSegments.length > 0;
  const lines = expected.map((line, index) => {
    const normalizedExpected = normalizeDialogueText(line.text, aliasMap);
    const speakerMatch = line.speaker && hasSpeakerLabels
      ? findSpeakerMatch(labeledSegments, line, normalizedExpected)
      : null;
    const matched = Boolean(normalizedExpected && (
      containsNormalizedPhrase(normalizedTranscript, normalizedExpected)
        || speakerMatch?.matched
    ));
    return {
      index,
      id: line.id,
      speaker: line.speaker,
      normalizedSpeaker: normalizeSpeaker(line.speaker),
      expected: line.text,
      normalizedExpected,
      required: !line.optional,
      matched,
      speakerMatched: speakerMatch?.matched || false,
      observedSpeakers: speakerMatch?.observedSpeakers || []
    };
  });

  const issues = [];
  if (!normalizedTranscript) {
    issues.push({
      type: "transcript_unavailable",
      severity: "review",
      retryCategory: "no transcript",
      retryIssue: "wrong dialogue",
      retrySuggestion: "Request human review before retrying because no transcript text was available.",
      message: "No usable transcript text was available for automatic QA."
    });
    return buildResult({
      level: "needs_human_review",
      expected,
      lines,
      issues,
      normalizedTranscript
    });
  }

  if (!expected.length && !required.length) {
    issues.push({
      type: "expected_dialogue_unavailable",
      severity: "review",
      retryCategory: "human review",
      retryIssue: "wrong dialogue",
      retrySuggestion: "Provide expected dialogue or required phrases before using transcript QA for retry decisions.",
      message: "No expected dialogue or required phrases were provided for transcript QA."
    });
    return buildResult({
      level: "needs_human_review",
      expected,
      lines,
      issues,
      normalizedTranscript
    });
  }

  for (const line of lines) {
    if (line.matched || !line.required) continue;
    issues.push({
      type: "missing_line",
      severity: "fail",
      retryIssue: "missing line",
      retrySuggestion: "Retry the video with every required dialogue line included exactly.",
      index: line.index,
      id: line.id,
      speaker: line.speaker,
      expected: line.expected,
      message: `Expected dialogue line was not found: ${line.expected}`
    });
  }

  for (const phrase of required) {
    const normalizedPhrase = normalizeDialogueText(phrase.text, aliasMap);
    if (normalizedPhrase && containsNormalizedPhrase(normalizedTranscript, normalizedPhrase)) continue;
    issues.push({
      type: "missing_required_phrase",
      severity: "fail",
      retryCategory: "missing required phrase",
      retryIssue: "missing line",
      retrySuggestion: "Retry the video with every required phrase included exactly.",
      phrase: phrase.text,
      normalizedPhrase,
      message: `Required phrase was not found: ${phrase.text}`
    });
  }

  for (const issue of detectWrongSpeakerHints(lines, labeledSegments)) {
    issues.push(issue);
  }

  const cutoff = detectEndingCutoff({
    lines,
    normalizedTranscript,
    cutoffPrefixMinLength
  });
  if (cutoff) issues.push(cutoff);

  for (const phrase of warningPhrases) {
    const normalizedPhrase = normalizeDialogueText(phrase.text, aliasMap);
    if (!normalizedPhrase || !containsNormalizedPhrase(normalizedTranscript, normalizedPhrase)) continue;
    issues.push({
      type: "extra_phrase",
      severity: "warn",
      retryIssue: "wrong dialogue",
      retrySuggestion: "Retry only if the extra phrase changes meaning or violates the script.",
      phrase: phrase.text,
      normalizedPhrase,
      message: `Transcript contains configured hallucinated/extra phrase warning: ${phrase.text}`
    });
  }

  return buildResult({
    level: levelForIssues(issues),
    expected,
    lines,
    issues,
    normalizedTranscript
  });
}

export function normalizeDialogueText(text = "", aliasMap = DEFAULT_DIALOGUE_ALIASES) {
  let normalized = basicNormalize(text);
  if (!normalized) return "";
  for (const entry of buildAliasEntries(aliasMap)) {
    normalized = replaceNormalizedPhrase(normalized, entry.variant, entry.token);
  }
  return collapseSpaces(normalized);
}

function buildResult({ level, expected, lines, issues, normalizedTranscript }) {
  const matchedLineCount = lines.filter((line) => line.matched).length;
  const retrySuggestions = buildRetrySuggestions(issues);
  return {
    level,
    expectedLineCount: expected.length,
    matchedLineCount,
    normalizedTranscript,
    lines,
    issues,
    retrySuggestions,
    retryIssueChips: uniqueStrings(retrySuggestions.map((suggestion) => suggestion.retryIssue || suggestion.issue)),
    summary: buildSummary(level, expected.length, matchedLineCount, issues)
  };
}

function buildSummary(level, expectedLineCount, matchedLineCount, issues) {
  if (level === "needs_human_review") return "needs_human_review: transcript QA needs manual review";
  return `${level}: ${matchedLineCount}/${expectedLineCount} expected dialogue lines matched, ${issues.length} issue${issues.length === 1 ? "" : "s"}`;
}

function levelForIssues(issues = []) {
  if (issues.some((issue) => issue.severity === "review")) return "needs_human_review";
  if (issues.some((issue) => issue.severity === "fail")) return "fail";
  if (issues.some((issue) => issue.severity === "warn")) return "warn";
  return "pass";
}

function normalizeExpectedLines(lines = []) {
  const source = normalizeExpectedLineSource(lines);
  return source.map((line, index) => {
    if (line && typeof line === "object") {
      return {
        id: compactString(line.id || line.key || `line-${index + 1}`),
        speaker: compactString(line.speaker || ""),
        text: compactString(line.text || line.dialogue || line.line || ""),
        optional: line.optional === true || line.required === false
      };
    }
    return {
      id: `line-${index + 1}`,
      speaker: "",
      text: compactString(line),
      optional: false
    };
  }).filter((line) => line.text);
}

function selectExpectedDialogueInput(expectedLines, expectedDialogue) {
  if (Array.isArray(expectedLines)) return expectedLines.length ? expectedLines : expectedDialogue;
  if (expectedLines == null || expectedLines === "") return expectedDialogue;
  return expectedLines;
}

function normalizePhraseList(phrases = []) {
  return (Array.isArray(phrases) ? phrases : [phrases]).map((phrase) => {
    if (phrase && typeof phrase === "object") {
      return { text: compactString(phrase.text || phrase.phrase || "") };
    }
    return { text: compactString(phrase) };
  }).filter((phrase) => phrase.text);
}

function normalizeExpectedLineSource(lines = []) {
  if (lines && typeof lines === "object" && !Array.isArray(lines)) {
    if (Array.isArray(lines.lines)) return lines.lines;
    if (Array.isArray(lines.dialogue)) return lines.dialogue;
    if (Array.isArray(lines.expectedDialogue)) return lines.expectedDialogue;
  }
  return Array.isArray(lines) ? lines : [lines];
}

function detectEndingCutoff({ lines = [], normalizedTranscript = "", cutoffPrefixMinLength = 3 } = {}) {
  const lastLine = [...lines].reverse().find((line) => line.required);
  if (!lastLine || lastLine.matched || !lastLine.normalizedExpected) return null;
  const fragment = findExpectedPrefixAtTranscriptEnd(
    normalizedTranscript,
    lastLine.normalizedExpected,
    cutoffPrefixMinLength
  );
  if (!fragment) return null;
  return {
    type: "ending_cutoff",
    severity: "fail",
    retryIssue: "ending cut off",
    retrySuggestion: "Retry with enough timing for the final words to finish before the clip ends.",
    index: lastLine.index,
    id: lastLine.id,
    expected: lastLine.expected,
    observedFragment: fragment,
    message: `Transcript appears to cut off before the final expected line completes: ${lastLine.expected}`
  };
}

function detectWrongSpeakerHints(lines = [], labeledSegments = []) {
  if (!labeledSegments.length) return [];
  return lines.flatMap((line) => {
    if (!line.speaker || !line.normalizedExpected || !line.observedSpeakers.length) return [];
    if (line.speakerMatched) return [];
    const observed = line.observedSpeakers.filter(Boolean);
    if (!observed.length) return [];
    return [{
      type: "wrong_speaker_hint",
      severity: "warn",
      retryIssue: "wrong speaker",
      retrySuggestion: "Check the video manually and retry if the labeled transcript assigned this line to the wrong speaker.",
      index: line.index,
      id: line.id,
      speaker: line.speaker,
      observedSpeakers: observed,
      expected: line.expected,
      message: `Transcript labels suggest wrong speaker for expected line: ${line.expected}`
    }];
  });
}

function parseSpeakerLabeledSegments(transcriptText = "", aliasMap = DEFAULT_DIALOGUE_ALIASES) {
  return String(transcriptText || "").split(/\r?\n|(?<=\.)\s+(?=[A-Za-z][A-Za-z0-9 _-]{0,30}:)/)
    .map((raw) => {
      const match = String(raw || "").match(/^\s*([A-Za-z][A-Za-z0-9 _-]{0,30})\s*:\s*(.+?)\s*$/);
      if (!match) return null;
      const speaker = compactString(match[1]);
      const text = compactString(match[2]);
      if (!speaker || !text) return null;
      return {
        speaker,
        normalizedSpeaker: normalizeSpeaker(speaker),
        text,
        normalizedText: normalizeDialogueText(text, aliasMap)
      };
    })
    .filter(Boolean);
}

function findSpeakerMatch(segments = [], line = {}, normalizedExpected = "") {
  if (!normalizedExpected) return null;
  const expectedSpeaker = normalizeSpeaker(line.speaker);
  const matchingSegments = segments.filter((segment) => (
    containsNormalizedPhrase(segment.normalizedText, normalizedExpected)
  ));
  if (!matchingSegments.length) return {
    matched: false,
    observedSpeakers: []
  };
  return {
    matched: matchingSegments.some((segment) => speakersMatch(segment.normalizedSpeaker, expectedSpeaker)),
    observedSpeakers: uniqueStrings(matchingSegments.map((segment) => segment.speaker))
  };
}

function buildRetrySuggestions(issues = []) {
  const byIssue = new Map();
  for (const issue of issues) {
    const suggestionIssue = issue.retryCategory || issue.retryIssue;
    if (!suggestionIssue) continue;
    const retryIssue = issue.retryIssue || suggestionIssue;
    const current = byIssue.get(suggestionIssue) || {
      issue: suggestionIssue,
      retryIssue,
      severity: issue.severity,
      reasonTypes: [],
      details: [],
      reviewRequired: false
    };
    if (severityRank(issue.severity) > severityRank(current.severity)) current.severity = issue.severity;
    if (severityRank(issue.severity) >= severityRank("review")) current.reviewRequired = true;
    if (!current.reasonTypes.includes(issue.type)) current.reasonTypes.push(issue.type);
    if (issue.retrySuggestion && !current.details.includes(issue.retrySuggestion)) current.details.push(issue.retrySuggestion);
    byIssue.set(suggestionIssue, current);
  }
  return [...byIssue.values()];
}

function findExpectedPrefixAtTranscriptEnd(transcript, expected, minLength) {
  const transcriptWords = splitWords(transcript);
  const expectedWords = splitWords(expected);
  if (!transcriptWords.length || !expectedWords.length) return "";
  const maxWords = Math.min(expectedWords.length, transcriptWords.length, 8);
  for (let wordCount = maxWords; wordCount >= 1; wordCount -= 1) {
    const fragment = transcriptWords.slice(-wordCount).join(" ");
    if (fragment.length < minLength) continue;
    if (fragment === expected) continue;
    if (expected.startsWith(fragment)) return fragment;
  }
  const lastWord = transcriptWords[transcriptWords.length - 1];
  const expectedFirstWord = expectedWords[0];
  if (
    lastWord.length >= minLength
      && lastWord !== expectedFirstWord
      && expectedFirstWord.startsWith(lastWord)
  ) {
    return lastWord;
  }
  return "";
}

function containsNormalizedPhrase(haystack, needle) {
  if (!haystack || !needle) return false;
  return ` ${haystack} `.includes(` ${needle} `);
}

function speakersMatch(observed = "", expected = "") {
  if (!observed || !expected) return false;
  return observed === expected || observed.includes(expected) || expected.includes(observed);
}

function normalizeSpeaker(value = "") {
  return basicNormalize(value).replace(/\b(the|a|an)\b/g, "").replace(/\s+/g, " ").trim();
}

function severityRank(severity = "") {
  if (severity === "review") return 3;
  if (severity === "fail") return 2;
  if (severity === "warn") return 1;
  return 0;
}

function uniqueStrings(values = []) {
  return [...new Set(values.map(compactString).filter(Boolean))];
}

function buildAliasEntries(aliasMap = {}) {
  return Object.entries(aliasMap || {}).flatMap(([canonical, aliases]) => {
    const token = canonicalToken(canonical);
    if (!token) return [];
    const variants = [canonical, ...(Array.isArray(aliases) ? aliases : [aliases])];
    return variants.map((variant) => ({
      token,
      variant: basicNormalize(variant)
    })).filter((entry) => entry.variant);
  }).sort((a, b) => b.variant.length - a.variant.length);
}

function replaceNormalizedPhrase(text, phrase, replacement) {
  const escaped = escapeRegExp(phrase);
  return collapseSpaces(text.replace(new RegExp(`(^| )${escaped}(?= |$)`, "g"), `$1${replacement}`));
}

function canonicalToken(value) {
  return basicNormalize(value).replace(/\s+/g, "");
}

function basicNormalize(value = "") {
  return collapseSpaces(String(value || "")
    .toLowerCase()
    .replace(/[\u2019']/g, "")
    .replace(/[^a-z0-9]+/g, " "));
}

function splitWords(value = "") {
  return collapseSpaces(value).split(" ").filter(Boolean);
}

function collapseSpaces(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function compactString(value = "") {
  return String(value || "").trim();
}

function escapeRegExp(value = "") {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
