export const PRIVACY_CONSENT_KEY = "autoflow_privacy_consent_v1";
export const PRIVACY_CONSENT_VERSION = "2026-08-17";

export function normalizePrivacyConsent(value) {
  if (!value || typeof value !== "object") {
    return {
      accepted: false,
      version: "",
      acceptedAt: "",
      declinedAt: ""
    };
  }
  const accepted = value.accepted === true && String(value.version || "") === PRIVACY_CONSENT_VERSION;
  return {
    accepted,
    version: String(value.version || ""),
    acceptedAt: accepted ? String(value.acceptedAt || "") : "",
    declinedAt: value.accepted === false ? String(value.declinedAt || "") : ""
  };
}

export function privacyConsentAccepted(value) {
  return normalizePrivacyConsent(value).accepted;
}

export function createAcceptedPrivacyConsent(now = new Date()) {
  return {
    accepted: true,
    version: PRIVACY_CONSENT_VERSION,
    acceptedAt: now.toISOString(),
    notice: "autoflow_user_data_notice_v1"
  };
}

export function createDeclinedPrivacyConsent(now = new Date()) {
  return {
    accepted: false,
    version: PRIVACY_CONSENT_VERSION,
    declinedAt: now.toISOString(),
    notice: "autoflow_user_data_notice_v1"
  };
}

export async function readPrivacyConsent(storageArea) {
  if (!storageArea?.get) return normalizePrivacyConsent(null);
  const stored = await storageArea.get(PRIVACY_CONSENT_KEY).catch(() => ({}));
  return normalizePrivacyConsent(stored?.[PRIVACY_CONSENT_KEY]);
}

export async function writePrivacyConsent(storageArea, value) {
  if (!storageArea?.set) throw new Error("privacy_consent_storage_unavailable");
  const normalized = value?.accepted === true
    ? createAcceptedPrivacyConsent(new Date(value.acceptedAt || Date.now()))
    : createDeclinedPrivacyConsent(new Date(value.declinedAt || Date.now()));
  await storageArea.set({ [PRIVACY_CONSENT_KEY]: normalized });
  return normalizePrivacyConsent(normalized);
}

export function privacyConsentRequiredPayload() {
  return {
    ok: false,
    error: "privacy_consent_required",
    reason: "privacy_consent_required",
    consentVersion: PRIVACY_CONSENT_VERSION
  };
}
