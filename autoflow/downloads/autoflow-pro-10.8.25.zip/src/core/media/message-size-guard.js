// Hard size guard for chrome.runtime/chrome.tabs message payloads.
//
// Chrome enforces a ~64MiB cap on any single extension message (request or
// sendResponse callback data). A page-command result that carries a raw
// base64 media dataUrl (e.g. an upscaled 4K video) can exceed that cap, and
// Chrome throws synchronously wherever the oversized object is handed to
// sendResponse/sendMessage. That throw happens deep inside async IIFEs with
// no caller-side try/catch, so it becomes a silent, repeating failure
// instead of a typed error the caller can react to.
//
// Keep this threshold comfortably under Chrome's hard limit: the guarded
// payload is re-wrapped at least once more (PageCommandResult -> whatever
// envelope the sidepanel/MCP bridge layers on top), and JSON.stringify byte
// length is only an approximation of Chrome's internal structured-clone
// message size.
export const CHROME_RUNTIME_MESSAGE_HARD_LIMIT_BYTES = 64 * 1024 * 1024;

export const MAX_RUNTIME_MESSAGE_BYTES = 32 * 1024 * 1024;

// Mirrors the byte budget page-hook.js uses for its own inline-media guard
// (see MAX_INLINE_MEDIA_DATA_URL_BYTES there). Kept as a separate constant,
// duplicated intentionally: page-hook.js is injected standalone into the
// page world and cannot import this module. Keep both in sync by hand.
//
// Budget: 16MiB raw bytes base64-inflate to ~21.4MiB of dataUrl text, which
// leaves ~10.6MiB (~33%) of headroom under MAX_RUNTIME_MESSAGE_BYTES (32MiB)
// for the data: prefix, the PageCommandResult JSON envelope, and any outer
// bridge wrapping — so a payload that passes the source-side guard is
// guaranteed to also pass the message-side guard.
export const MAX_INLINE_MEDIA_SOURCE_BYTES = 16 * 1024 * 1024;

export const MESSAGE_PAYLOAD_TOO_LARGE_CODE = "MESSAGE_PAYLOAD_TOO_LARGE";

export class MessagePayloadTooLargeError extends Error {
  constructor(byteLength, limit, context = "") {
    super(`message_payload_too_large:${context || "unknown"}:${byteLength}>${limit}`);
    this.name = "MessagePayloadTooLargeError";
    this.code = MESSAGE_PAYLOAD_TOO_LARGE_CODE;
    this.byteLength = byteLength;
    this.limit = limit;
    this.context = String(context || "");
  }
}

// Approximates the byte size of a message the way Chrome's IPC will see it.
// Returns Infinity (never throws) for values that cannot be serialized —
// callers must treat that as "too large / unsafe to send", not as zero.
export function measurePayloadByteLength(value) {
  try {
    const json = JSON.stringify(value);
    if (typeof json !== "string") return Infinity;
    return new TextEncoder().encode(json).length;
  } catch {
    return Infinity;
  }
}

// Non-throwing guard: measures `payload` and reports whether it is safe to
// hand to chrome.runtime.sendMessage / chrome.tabs.sendMessage / sendResponse.
export function guardMessagePayload(payload, { limit = MAX_RUNTIME_MESSAGE_BYTES, context = "" } = {}) {
  const byteLength = measurePayloadByteLength(payload);
  const safeLimit = Number(limit) > 0 ? Number(limit) : MAX_RUNTIME_MESSAGE_BYTES;
  if (byteLength <= safeLimit) {
    return { ok: true, byteLength, limit: safeLimit };
  }
  return { ok: false, byteLength, limit: safeLimit, context: String(context || "") };
}

// Throwing variant for call sites that prefer try/catch flow control.
export function assertMessagePayloadSize(payload, options = {}) {
  const result = guardMessagePayload(payload, options);
  if (!result.ok) {
    throw new MessagePayloadTooLargeError(result.byteLength, result.limit, options.context);
  }
  return result;
}

// Safe-error shape sent to the caller in place of the oversized payload.
// Never includes raw bytes/tokens — only sizes and enough of an id
// (mediaId/mediaUrl, when the producer already resolved one) to let the
// caller retry idempotently against the same media via a bounded path
// (e.g. the direct Flow redirect URL) instead of the messaging bridge.
export function buildOversizedResultSummary(action, guard, sourceResult = {}) {
  return {
    ok: false,
    code: MESSAGE_PAYLOAD_TOO_LARGE_CODE,
    action: String(action || ""),
    byteLength: guard.byteLength,
    limit: guard.limit,
    mediaUrl: String(sourceResult?.mediaUrl || "").trim(),
    mediaId: String(sourceResult?.mediaId || sourceResult?.resultMediaName || "").trim()
  };
}
