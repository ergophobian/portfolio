/**
 * Download media-kind helpers.
 *
 * Owns singular/plural kind normalization, filename/MIME/URL kind inference,
 * completed-download validation (HTML + wrong-kind), and min-byte thresholds.
 *
 * Root cause class (Agent paid r3 / 0bd55620): when a video was expected, a
 * pre-existing 1199-byte JPEG reference image was claimed/downloaded instead
 * of an MP4. Validation must fail closed as download_wrong_media_kind — not
 * pass as a "valid" image download, and not burn video readiness retries as
 * download_too_small.
 */

export function isVideoDownloadKind(kind = "") {
  const value = String(kind || "").toLowerCase();
  return value === "videos" || value === "video";
}

export function isImageDownloadKind(kind = "") {
  const value = String(kind || "").toLowerCase();
  return value === "images" || value === "image";
}

export function resolveDownloadMediaKind(kind = "", filename = "") {
  if (isImageDownloadKind(kind)) return "images";
  if (isVideoDownloadKind(kind)) return "videos";
  const name = String(filename || "").toLowerCase();
  if (/\.(?:png|jpe?g|webp|avif)(?:$|\?)/.test(name)) return "images";
  if (/\.(?:mp4|mov|webm)(?:$|\?)/.test(name)) return "videos";
  return "";
}

/**
 * Infer actual media kind from completed-download evidence (filename, MIME,
 * final CDN URL). Empty string when unknown.
 */
export function detectArtifactMediaKind(item = {}) {
  const mime = String(item.mime || item.mimeType || item.contentType || "").toLowerCase();
  if (/^image\//.test(mime) || /image\/(?:jpeg|jpg|png|webp|avif|gif)/.test(mime)) return "images";
  if (/^video\//.test(mime) || /video\/(?:mp4|webm|quicktime)/.test(mime)) return "videos";

  const filename = String(item.filename || item.name || item.path || "").toLowerCase();
  if (/\.(?:png|jpe?g|webp|avif|gif)(?:$|\?)/.test(filename)) return "images";
  if (/\.(?:mp4|mov|webm|m4v)(?:$|\?)/.test(filename)) return "videos";

  const url = String(item.finalUrl || item.url || item.mediaUrl || item.redirectUrl || "").toLowerCase();
  // Flow CDN paths: flow-content.google/image/<id> vs /video/<id>
  if (/\/image\/[0-9a-f-]{8,}/i.test(url) || /[?&]mediaurltype=media_url_type_image\b/i.test(url)) {
    return "images";
  }
  if (/\/video\/[0-9a-f-]{8,}/i.test(url) || /[?&]mediaurltype=media_url_type_video\b/i.test(url)) {
    return "videos";
  }
  return "";
}

export function minValidDownloadBytes(filename = "", options = {}) {
  const name = String(filename || "").toLowerCase();
  const kind = resolveDownloadMediaKind(options.kind || options.mediaKind || "", name);
  if (kind === "videos" || name.endsWith(".mp4") || name.endsWith(".mov") || name.endsWith(".webm")) {
    return 16 * 1024;
  }
  if (kind === "images" || /\.(png|jpe?g|webp|avif)$/i.test(name)) return 512;
  return 1;
}

/**
 * Typed fail-closed reasons for a completed chrome.downloads item.
 * Empty string means the completed file is not rejected by this guard.
 *
 * Reasons:
 * - download_bad_content:html_file / html_mime
 * - download_wrong_media_kind:image_when_video_expected
 * - download_wrong_media_kind:video_when_image_expected
 */
export function invalidCompletedDownloadReason(item = {}, options = {}) {
  const actualName = String(item.filename || "").toLowerCase();
  const expectedName = String(options.filename || "").toLowerCase();
  const expectedKind = resolveDownloadMediaKind(
    options.kind || options.mediaKind || options.expectedKind || "",
    expectedName || actualName
  );
  const mime = String(item.mime || item.mimeType || item.contentType || "").toLowerCase();
  const expectsMedia = expectedKind === "videos"
    || expectedKind === "images"
    || /\.(mp4|mov|webm|png|jpe?g|webp|avif)$/i.test(expectedName);

  if (!expectsMedia && !expectedKind) return "";

  if (/\.html(?:$|\?)/i.test(actualName) || /\.xhtml(?:$|\?)/i.test(actualName)) {
    return "download_bad_content:html_file";
  }
  if (/text\/html|application\/xhtml\+xml/i.test(mime)) {
    return "download_bad_content:html_mime";
  }

  const actualKind = detectArtifactMediaKind({
    ...item,
    filename: item.filename || options.filename || ""
  });
  if (expectedKind === "videos" && actualKind === "images") {
    return "download_wrong_media_kind:image_when_video_expected";
  }
  if (expectedKind === "images" && actualKind === "videos") {
    return "download_wrong_media_kind:video_when_image_expected";
  }
  return "";
}

/**
 * Whether a completed-download failure should burn video readiness retries.
 * Wrong-kind artifacts are terminal for this mediaId (do not re-poll as lag).
 */
export function shouldRetryTinyVideoDownload(result = {}, plan = {}) {
  if (resolveDownloadMediaKind(plan.kind || plan.mediaKind, plan.filename) !== "videos") return false;
  const error = String(result.error || "");
  if (/^download_wrong_media_kind:/i.test(error)) return false;
  return /^download_too_small:/i.test(error)
    || /^download_bad_content:html_/i.test(error)
    || /SERVER_FAILED|SERVER_BAD_CONTENT|server failed|site wasn.t available|download_interrupted|download_timeout/i.test(error);
}
