export const MAX_VIDEO_EDIT_DURATION_SECONDS = 10;
export const MAX_INLINE_VIDEO_SOURCE_BYTES = 16 * 1024 * 1024;
export const VIDEO_EDIT_DURATION_METADATA_TOLERANCE_SECONDS = 0.1;

export function videoEditTrimWindow({ durationSeconds = 0, startSeconds = 0, maxDurationSeconds = MAX_VIDEO_EDIT_DURATION_SECONDS } = {}) {
  const duration = Math.max(0, Number(durationSeconds) || 0);
  const maxDuration = Math.max(0.1, Number(maxDurationSeconds) || MAX_VIDEO_EDIT_DURATION_SECONDS);
  const start = Math.max(0, Math.min(Number(startSeconds) || 0, Math.max(0, duration - 0.1)));
  // MP4/AAC container padding commonly reports a nominal ten-second clip as
  // 10.02–10.04 seconds. Re-recording that valid clip creates an unnecessary
  // WebM and can make Flow's resumable upload reject it. Preserve bounded
  // container drift while still trimming genuinely overlong sources.
  const exceedsDurationLimit = duration > maxDuration + VIDEO_EDIT_DURATION_METADATA_TOLERANCE_SECONDS;
  const end = duration > 0
    ? (exceedsDurationLimit || start > 0 ? Math.min(duration, start + maxDuration) : duration)
    : start + maxDuration;
  return {
    startSeconds: start,
    endSeconds: end,
    durationSeconds: Math.max(0, end - start),
    needsTrim: exceedsDurationLimit || start > 0
  };
}

export function videoEditFrameWindow({
  durationSeconds = 0,
  startSeconds = 0,
  maxDurationSeconds = MAX_VIDEO_EDIT_DURATION_SECONDS,
  framesPerSecond = 24
} = {}) {
  const trim = videoEditTrimWindow({ durationSeconds, startSeconds, maxDurationSeconds });
  const fps = Math.max(1, Number(framesPerSecond) || 24);
  return {
    ...trim,
    framesPerSecond: fps,
    startFrameIndex: Math.max(0, Math.floor(trim.startSeconds * fps)),
    endFrameIndex: Math.max(1, Math.floor(trim.endSeconds * fps))
  };
}

export function preferredVideoRecorderMimeType(MediaRecorderImpl = globalThis.MediaRecorder) {
  const candidates = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  if (!MediaRecorderImpl) return "";
  return candidates.find((type) => typeof MediaRecorderImpl.isTypeSupported !== "function" || MediaRecorderImpl.isTypeSupported(type)) || "";
}

function waitForEvent(target, eventName, errorName = "error") {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      target.removeEventListener(eventName, onReady);
      target.removeEventListener(errorName, onError);
    };
    const onReady = () => { cleanup(); resolve(); };
    const onError = () => { cleanup(); reject(new Error(`video_source_${errorName}`)); };
    target.addEventListener(eventName, onReady, { once: true });
    target.addEventListener(errorName, onError, { once: true });
  });
}

export async function inspectVideoFile(file, { documentImpl = globalThis.document, URLImpl = globalThis.URL } = {}) {
  if (!file || !documentImpl?.createElement || !URLImpl?.createObjectURL) throw new Error("VIDEO_SOURCE_UNREADABLE");
  const url = URLImpl.createObjectURL(file);
  const video = documentImpl.createElement("video");
  video.preload = "metadata";
  video.muted = true;
  video.src = url;
  try {
    if (video.readyState < 1) await waitForEvent(video, "loadedmetadata");
    return {
      durationSeconds: Number(video.duration || 0),
      width: Number(video.videoWidth || 0),
      height: Number(video.videoHeight || 0),
      mimeType: String(file.type || "video/mp4"),
      size: Number(file.size || 0)
    };
  } finally {
    video.removeAttribute("src");
    video.load?.();
    URLImpl.revokeObjectURL(url);
  }
}

export async function trimVideoFileToEditWindow(file, {
  startSeconds = 0,
  maxDurationSeconds = MAX_VIDEO_EDIT_DURATION_SECONDS,
  documentImpl = globalThis.document,
  URLImpl = globalThis.URL,
  MediaRecorderImpl = globalThis.MediaRecorder
} = {}) {
  const metadata = await inspectVideoFile(file, { documentImpl, URLImpl });
  const trim = videoEditTrimWindow({ durationSeconds: metadata.durationSeconds, startSeconds, maxDurationSeconds });
  if (!trim.needsTrim) return { file, metadata, trim, transcoded: false };
  const mimeType = preferredVideoRecorderMimeType(MediaRecorderImpl);
  if (!mimeType || !documentImpl?.createElement || !URLImpl?.createObjectURL) throw new Error("VIDEO_SOURCE_TRIM_UNAVAILABLE");

  const url = URLImpl.createObjectURL(file);
  const video = documentImpl.createElement("video");
  video.preload = "auto";
  video.muted = true;
  video.playsInline = true;
  video.src = url;
  try {
    if (video.readyState < 1) await waitForEvent(video, "loadedmetadata");
    video.currentTime = trim.startSeconds;
    if (Math.abs(video.currentTime - trim.startSeconds) > 0.05 || video.readyState < 2) await waitForEvent(video, "seeked");
    const stream = video.captureStream?.() || video.mozCaptureStream?.();
    if (!stream) throw new Error("VIDEO_SOURCE_TRIM_UNAVAILABLE");
    const chunks = [];
    const recorder = new MediaRecorderImpl(stream, { mimeType });
    recorder.addEventListener("dataavailable", (event) => {
      if (event.data?.size) chunks.push(event.data);
    });
    const stopped = waitForEvent(recorder, "stop", "error");
    recorder.start(250);
    await video.play();
    await new Promise((resolve) => {
      const timeout = setTimeout(resolve, Math.ceil(trim.durationSeconds * 1000) + 250);
      const onTime = () => {
        if (video.currentTime >= trim.endSeconds) {
          clearTimeout(timeout);
          video.removeEventListener("timeupdate", onTime);
          resolve();
        }
      };
      video.addEventListener("timeupdate", onTime);
    });
    video.pause();
    if (recorder.state !== "inactive") recorder.stop();
    await stopped;
    stream.getTracks?.().forEach((track) => track.stop());
    const blob = new Blob(chunks, { type: mimeType.split(";")[0] });
    if (!blob.size) throw new Error("VIDEO_SOURCE_TRIM_EMPTY");
    const stem = String(file.name || "source-video").replace(/\.[^.]+$/, "");
    const output = typeof File === "function"
      ? new File([blob], `${stem}-autoflow-10s.webm`, { type: blob.type, lastModified: Date.now() })
      : Object.assign(blob, { name: `${stem}-autoflow-10s.webm` });
    return {
      file: output,
      metadata: { ...metadata, durationSeconds: trim.durationSeconds, mimeType: blob.type, size: blob.size },
      trim,
      transcoded: true
    };
  } finally {
    video.pause?.();
    video.removeAttribute("src");
    video.load?.();
    URLImpl.revokeObjectURL(url);
  }
}
