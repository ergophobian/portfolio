// Poison-message backpressure for page commands whose result keeps tripping
// the runtime message-size guard (see message-size-guard.js).
//
// Without this, a repeated request against the same oversized media (e.g. a
// hi-res video-upscale download retried by a caller that only sees a bare
// failure) refetches the full media body from Flow and re-trips the size
// guard every single time — expensive, and indistinguishable from a live
// retry loop in the event log. After `thresholdStrikes` failures for the
// same (tab, action, media) key inside `cooldownMs`, further attempts for
// that exact key short-circuit until the cooldown lapses.
//
// Pure and deterministic: `now` is injectable so tests don't depend on wall
// clock timing.
export const DEFAULT_POISON_THRESHOLD_STRIKES = 3;
export const DEFAULT_POISON_COOLDOWN_MS = 5 * 60 * 1000;

// Deterministic FNV-1a hash over the payload's JSON shape. Used as the key
// discriminator for commands that carry no media identity (scanGallery,
// flowFetch, projectGeneratedMedia, ...) so distinct requests never share a
// strike bucket — three unrelated oversized results must not blanket-block
// an entire action on a tab. Stable across calls: same request shape, same
// key, so genuine repeated backoff still accumulates.
export function stablePayloadHash(value) {
  let json = "";
  try {
    json = JSON.stringify(value) || "";
  } catch {
    json = "";
  }
  let hash = 0x811c9dc5;
  for (let index = 0; index < json.length; index += 1) {
    hash ^= json.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

export function pageCommandPoisonKey(tabId, action, payload = {}) {
  const mediaKey = String(
    payload?.mediaId || payload?.mediaGenerationId || payload?.url || payload?.mediaUrl || ""
  ).trim();
  if (mediaKey) return `${tabId}:${action}:${mediaKey}`;
  return `${tabId}:${action}:req_${stablePayloadHash(payload?.request ?? payload)}`;
}

export function createPageCommandPoisonGuard({
  thresholdStrikes = DEFAULT_POISON_THRESHOLD_STRIKES,
  cooldownMs = DEFAULT_POISON_COOLDOWN_MS,
  now = () => Date.now()
} = {}) {
  const state = new Map();

  function noteStrike(key) {
    const nowMs = now();
    const previous = state.get(key) || { strikes: 0, firstStrikeAt: nowMs };
    const withinWindow = nowMs - previous.firstStrikeAt <= cooldownMs;
    const strikes = withinWindow ? previous.strikes + 1 : 1;
    const entry = {
      strikes,
      firstStrikeAt: withinWindow ? previous.firstStrikeAt : nowMs,
      cooldownUntil: strikes >= thresholdStrikes ? nowMs + cooldownMs : 0
    };
    state.set(key, entry);
    return entry;
  }

  function isCooldownActive(key) {
    const entry = state.get(key);
    if (!entry?.cooldownUntil) return false;
    if (now() >= entry.cooldownUntil) {
      state.delete(key);
      return false;
    }
    return true;
  }

  function clearStrikes(key) {
    if (key) state.delete(key);
  }

  function snapshot(key) {
    return state.get(key) ? { ...state.get(key) } : null;
  }

  return { key: pageCommandPoisonKey, noteStrike, isCooldownActive, clearStrikes, snapshot };
}
