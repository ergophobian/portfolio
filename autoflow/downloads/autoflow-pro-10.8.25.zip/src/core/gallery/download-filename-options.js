export const DOWNLOAD_FILENAME_STYLES = ["auto_flow", "detailed", "prompt_prefix", "custom_template"];
export const DEFAULT_DOWNLOAD_FILENAME_STYLE = "auto_flow";

export const TEMPLATE_INDEXES = ["none", "n", "nn", "nnn"];
export const TEMPLATE_PROMPT_PARTS = ["none", "first_word", "first_3_words", "slug_8"];
export const TEMPLATE_DATES = ["none", "yyyymmdd", "yymmdd_hhmm"];
export const TEMPLATE_SUFFIXES = ["none", "rand4", "rand8"];
export const TEMPLATE_SEPARATORS = ["_", "-"];

export function validDownloadFilenameStylesText() {
  return DOWNLOAD_FILENAME_STYLES.join(", ");
}

export function normalizeDownloadFilenameOptions(input = {}, options = {}) {
  const defaultStyle = options.defaultStyle ?? DEFAULT_DOWNLOAD_FILENAME_STYLE;
  if (input.naming !== undefined && (!input.naming || typeof input.naming !== "object" || Array.isArray(input.naming))) {
    return {
      ok: false,
      message: `naming must be an object with style set to one of: ${validDownloadFilenameStylesText()}.`
    };
  }
  const naming = input.naming && typeof input.naming === "object" && !Array.isArray(input.naming)
    ? input.naming
    : {};
  if (naming.template !== undefined && (!naming.template || typeof naming.template !== "object" || Array.isArray(naming.template))) {
    return {
      ok: false,
      message: "naming.template must be an object."
    };
  }
  const template = naming.template && typeof naming.template === "object" && !Array.isArray(naming.template)
    ? naming.template
    : {};
  const explicitStyle = firstPresent(naming.style, input.filenameStyle);
  const rawStyle = explicitStyle === undefined
    ? (hasTemplateInput(input, template) ? "custom_template" : defaultStyle)
    : explicitStyle;
  const style = compactString(rawStyle);
  if (style && !DOWNLOAD_FILENAME_STYLES.includes(style)) {
    return {
      ok: false,
      message: `filenameStyle must be one of: ${validDownloadFilenameStylesText()}.`
    };
  }

  const normalized = {};
  if (style) normalized.filenameStyle = style;

  const prefix = firstPresent(template.prefix, input.filenameTemplatePrefix);
  if (prefix !== undefined) normalized.filenameTemplatePrefix = compactString(prefix);

  const index = firstPresent(template.index, input.filenameTemplateIndex);
  if (index !== undefined) {
    const value = compactString(index);
    if (!TEMPLATE_INDEXES.includes(value)) {
      return invalidTemplateOption("filenameTemplateIndex", TEMPLATE_INDEXES);
    }
    normalized.filenameTemplateIndex = value;
  }

  const promptPart = firstPresent(template.promptPart, input.filenameTemplatePromptPart);
  if (promptPart !== undefined) {
    const value = compactString(promptPart);
    if (!TEMPLATE_PROMPT_PARTS.includes(value)) {
      return invalidTemplateOption("filenameTemplatePromptPart", TEMPLATE_PROMPT_PARTS);
    }
    normalized.filenameTemplatePromptPart = value;
  }

  const date = firstPresent(template.date, input.filenameTemplateDate);
  if (date !== undefined) {
    const value = compactString(date);
    if (!TEMPLATE_DATES.includes(value)) {
      return invalidTemplateOption("filenameTemplateDate", TEMPLATE_DATES);
    }
    normalized.filenameTemplateDate = value;
  }

  const suffix = firstPresent(template.suffix, input.filenameTemplateSuffix);
  if (suffix !== undefined) {
    const value = compactString(suffix);
    if (!TEMPLATE_SUFFIXES.includes(value)) {
      return invalidTemplateOption("filenameTemplateSuffix", TEMPLATE_SUFFIXES);
    }
    normalized.filenameTemplateSuffix = value;
  }

  const separator = firstPresent(template.separator, input.filenameTemplateSeparator);
  if (separator !== undefined) {
    const value = compactString(separator);
    if (!TEMPLATE_SEPARATORS.includes(value)) {
      return invalidTemplateOption("filenameTemplateSeparator", TEMPLATE_SEPARATORS);
    }
    normalized.filenameTemplateSeparator = value;
  }

  return {
    ok: true,
    options: normalized
  };
}

function invalidTemplateOption(name, validValues) {
  return {
    ok: false,
    message: `${name} must be one of: ${validValues.join(", ")}.`
  };
}

function firstPresent(...values) {
  return values.find((value) => value !== undefined && value !== null);
}

function hasTemplateInput(input = {}, template = {}) {
  return [
    template.prefix,
    template.index,
    template.promptPart,
    template.date,
    template.suffix,
    template.separator,
    input.filenameTemplatePrefix,
    input.filenameTemplateIndex,
    input.filenameTemplatePromptPart,
    input.filenameTemplateDate,
    input.filenameTemplateSuffix,
    input.filenameTemplateSeparator
  ].some((value) => value !== undefined && value !== null);
}

function compactString(value = "") {
  return String(value || "").trim();
}
