const RETRYABLE_UPSCALE_ERROR_RE = /status_media_generation_status_failed|http_(?:5\d\d)|internal error|internal server error|upscale_poll_failed|status_timeout/i;
const FAILED_MEDIA_STATUS_RE = /FAILED|CANCELLED|CANCELED|REJECTED|ERROR/i;

export function isRetryableUpscaleFailure(error = "") {
  return RETRYABLE_UPSCALE_ERROR_RE.test(String(error || ""));
}

export function isExplicitlyFailedMediaRow(row = {}) {
  const status = String(row.rawStatus || row.status || "").trim();
  return FAILED_MEDIA_STATUS_RE.test(status) && !/SUCCESSFUL|COMPLETE/i.test(status);
}

export function canRetryUpscaleFromFreshMedia({ error = "", row = null, refreshedMediaGenerationId = "", staleMediaGenerationId = "", recoveryAttempts = 0 } = {}) {
  if (Number(recoveryAttempts || 0) >= 1 || !isRetryableUpscaleFailure(error)) return false;
  if (row && isExplicitlyFailedMediaRow(row)) return false;
  const freshId = String(refreshedMediaGenerationId || "").trim();
  const staleId = String(staleMediaGenerationId || "").trim();
  return Boolean(row && freshId && freshId !== staleId);
}

export function fallbackFilenameForResolution(filename = "", resolution = "720p") {
  const source = String(filename || "media.mp4");
  const suffix = `.${String(resolution || "720p").trim().toLowerCase()}-fallback`;
  return source.replace(/(\.[^./]+)$/, `${suffix}$1`);
}

export function resolutionUnavailableError(requestedResolution = "", cause = "") {
  const requested = String(requestedResolution || "unknown").trim() || "unknown";
  const detail = String(cause || "upscale_unavailable").trim();
  return `download_resolution_unavailable:${requested}:${detail}`;
}
