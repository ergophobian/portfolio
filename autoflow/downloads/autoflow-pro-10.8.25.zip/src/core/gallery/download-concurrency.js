export const DIRECT_DOWNLOAD_CONCURRENCY = 4;
export const UPSCALE_DOWNLOAD_CONCURRENCY = 2;

function positiveLimit(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function createLimiter(limit) {
  const maximum = positiveLimit(limit, 1);
  let active = 0;
  const pending = [];
  const release = () => {
    active = Math.max(0, active - 1);
    const next = pending.shift();
    if (next) next();
  };
  return async (work) => {
    if (active >= maximum) await new Promise((resolve) => pending.push(resolve));
    active += 1;
    try {
      return await work();
    } finally {
      release();
    }
  };
}

/**
 * Runs independent downloads concurrently while preserving input order.
 * Upscales use a smaller lane than native downloads, and every mediaId is
 * serialized so the same source cannot receive overlapping upscale requests.
 */
export async function mapDownloadPlansWithConcurrency(plans = [], worker, options = {}) {
  if (typeof worker !== "function") throw new TypeError("download worker is required");
  const directLimit = createLimiter(positiveLimit(options.directConcurrency, DIRECT_DOWNLOAD_CONCURRENCY));
  const upscaleLimit = createLimiter(positiveLimit(options.upscaleConcurrency, UPSCALE_DOWNLOAD_CONCURRENCY));
  const mediaTails = new Map();

  const tasks = (Array.isArray(plans) ? plans : []).map((plan, index) => {
    const mediaKey = String(plan?.mediaId || plan?.artifactKey || `plan:${index}`).trim() || `plan:${index}`;
    const prior = mediaTails.get(mediaKey) || Promise.resolve();
    const lane = plan?.requiresUpscale === true ? upscaleLimit : directLimit;
    const current = prior.catch(() => {}).then(() => lane(() => worker(plan, index)));
    mediaTails.set(mediaKey, current);
    return current;
  });

  return Promise.all(tasks);
}
