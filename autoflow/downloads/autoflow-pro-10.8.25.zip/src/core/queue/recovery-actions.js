import { TaskStatus } from "./task-ledger.js";

export const STALE_SUBMITTING_THRESHOLD_MS = 2 * 60 * 1000;

const DOM_FIRST_MODES = new Set([
  "text-to-image",
  "text-to-video",
  "image-to-video",
  "start-end-image-to-video",
  "ingredients-to-video"
]);

const MODEL_ACCESS_FAILURE_CLASSES = new Set([
  "flow_model_access_denied",
  "api_first_model_access_denied",
  "flow_model_unavailable"
]);

const TERMINAL_STATUSES = new Set(["complete", "done", "failed", "blocked"]);
const COMPLETE_STATUSES = new Set(["complete", "done"]);
const ACTIVE_STATUSES = new Set(["submitting", "generating", "downloading"]);

function compactString(value = "") {
  return String(value || "").trim();
}

function compactIdList(values = []) {
  return [...new Set((values || []).map(compactString).filter(Boolean))];
}

function lower(value = "") {
  return compactString(value).toLowerCase();
}

function isoFromMs(value = Date.now()) {
  return new Date(Number(value || Date.now())).toISOString();
}

function taskStatus(task = {}) {
  return lower(task.status || TaskStatus.pending);
}

function taskSubmitPath(task = {}) {
  return lower(task.submitPathPreference || task.submitPath || "api_first");
}

function referenceMediaIdsFromTask(task = {}) {
  return new Set(compactIdList([
    ...(Array.isArray(task.refMediaIds) ? task.refMediaIds : []),
    task.startMediaId,
    task.endMediaId,
    ...(Array.isArray(task.refInputs) ? task.refInputs.map((ref) => ref?.mediaId || ref?.assetImageId) : []),
    task.startRefInput?.mediaId || task.startRefInput?.assetImageId,
    task.endRefInput?.mediaId || task.endRefInput?.assetImageId
  ]));
}

export function generatedMediaIdsFromTask(task = {}) {
  const references = referenceMediaIdsFromTask(task);
  return compactIdList([
    ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []),
    ...(Array.isArray(task.outputs) ? task.outputs.map((output) => output?.mediaId) : []),
    ...(Array.isArray(task.mediaIds) ? task.mediaIds : [])
  ]).filter((id) => !references.has(id));
}

export function hasTaskGeneratedOutput(task = {}) {
  if (generatedMediaIdsFromTask(task).length > 0) return true;
  if ((Array.isArray(task.outputs) ? task.outputs : []).some((output) => compactString(output?.mediaId))) return true;
  return Number(task.foundImages || 0) > 0 || Number(task.foundVideos || 0) > 0;
}

export function isTaskModelAccessDenied(task = {}) {
  const failureClass = lower(task.failureClass);
  if (MODEL_ACCESS_FAILURE_CLASSES.has(failureClass)) return true;
  const text = [
    task.flowErrorCode,
    task.lastError,
    task.error,
    task.userFacingFailureTitle,
    task.userFacingFailureBody
  ].map(compactString).join(" ");
  return /PUBLIC_ERROR_MODEL_ACCESS_DENIED|model_access_denied|model access denied|permission_denied/i.test(text);
}

export function canRunTaskDomFirst(task = {}) {
  return DOM_FIRST_MODES.has(compactString(task.mode));
}

export function isApiFirstBrowserModeAvailableTask(task = {}) {
  if (isTaskModelAccessDenied(task)) return false;
  if (lower(task.recoveryPolicy) === "browser_mode_available") return true;
  return task.apiFirstQuotaSuspected === true &&
    task.domVerificationAttempted === true &&
    (
      task.domVerificationResult === "success" ||
      task.finalQuotaClassification === "api_first_blocked_dom_available" ||
      task.failureClass === "api_first_blocked_dom_available"
    );
}

function candidateTaskStartedAtMs(task = {}) {
  for (const key of ["submitAttemptStartedAt", "submittedAt", "startedAt", "updatedAt"]) {
    const parsed = Date.parse(task?.[key] || "");
    if (Number.isFinite(parsed) && parsed > 0) return parsed;
  }
  return 0;
}

export function detectStaleSubmittingTask(tasks = [], options = {}) {
  const now = Number(options.now || Date.now());
  const staleMs = Number(options.staleMs || STALE_SUBMITTING_THRESHOLD_MS);
  const candidates = (Array.isArray(tasks) ? tasks : []).filter((task) => {
    const status = taskStatus(task);
    if (!["submitting", "generating"].includes(status)) return false;
    if (hasTaskGeneratedOutput(task)) return false;
    return canRunTaskDomFirst(task) && !isTaskModelAccessDenied(task);
  });
  for (const task of candidates) {
    const startedAtMs = candidateTaskStartedAtMs(task);
    const ageMs = startedAtMs > 0 ? Math.max(0, now - startedAtMs) : 0;
    if (ageMs >= staleMs) {
      return {
        detected: true,
        task,
        taskId: compactString(task.id),
        ageMs,
        resolution: "requeue_current_open_row_for_browser_mode"
      };
    }
  }
  return { detected: false, task: null, taskId: "", ageMs: 0, resolution: "" };
}

function countTasks(tasks = []) {
  const list = Array.isArray(tasks) ? tasks : [];
  return {
    total: list.length,
    completed: list.filter((task) => COMPLETE_STATUSES.has(taskStatus(task))).length,
    pending: list.filter((task) => taskStatus(task) === TaskStatus.pending).length,
    terminal: list.filter((task) => TERMINAL_STATUSES.has(taskStatus(task))).length,
    open: list.filter((task) => !TERMINAL_STATUSES.has(taskStatus(task))).length
  };
}

function normalizedButtonProbe(probe = {}) {
  const bbox = probe.recoveryContinueButtonBoundingBox || probe.boundingBox || {};
  return {
    recoveryModalShown: probe.recoveryModalShown === true,
    recoveryModalKind: compactString(probe.recoveryModalKind || "api_path_blocked"),
    recoveryModalInteractive: probe.recoveryModalInteractive === true,
    recoveryActionAvailable: probe.recoveryActionAvailable === true,
    recoveryContinueButtonPresent: probe.recoveryContinueButtonPresent === true,
    recoveryContinueButtonDisabled: probe.recoveryContinueButtonDisabled === true,
    recoveryContinueButtonAriaDisabled: probe.recoveryContinueButtonAriaDisabled === true,
    recoveryContinueButtonPointerEvents: compactString(probe.recoveryContinueButtonPointerEvents),
    recoveryContinueButtonBoundingBox: {
      x: Number(bbox.x || 0),
      y: Number(bbox.y || 0),
      width: Number(bbox.width || 0),
      height: Number(bbox.height || 0)
    },
    recoveryContinueButtonElementFromPointMatches: probe.recoveryContinueButtonElementFromPointMatches === true,
    recoveryContinueClickDispatchedAt: compactString(probe.recoveryContinueClickDispatchedAt),
    recoveryContinueClickHandlerFiredAt: compactString(probe.recoveryContinueClickHandlerFiredAt)
  };
}

function mergePatch(patchesById, id, patch = {}) {
  const taskId = compactString(id);
  if (!taskId) return;
  patchesById.set(taskId, {
    ...(patchesById.get(taskId) || {}),
    ...patch
  });
}

function shouldSwitchPendingTask(task = {}) {
  return taskStatus(task) === TaskStatus.pending &&
    taskSubmitPath(task) === "api_first" &&
    canRunTaskDomFirst(task) &&
    !isTaskModelAccessDenied(task);
}

function shouldRequeueSourceTask(task = {}, stale = {}) {
  if (!task?.id) return false;
  if (!canRunTaskDomFirst(task)) return false;
  if (isTaskModelAccessDenied(task)) return false;
  if (COMPLETE_STATUSES.has(taskStatus(task))) return false;
  if (hasTaskGeneratedOutput(task)) return false;
  if (taskStatus(task) === TaskStatus.pending) return true;
  if (["failed", "blocked"].includes(taskStatus(task)) && isApiFirstBrowserModeAvailableTask(task)) return true;
  if (ACTIVE_STATUSES.has(taskStatus(task))) {
    return stale.detected === true && compactString(stale.taskId) === compactString(task.id);
  }
  return false;
}

export function buildBrowserModeRecoveryPlan(tasks = [], options = {}) {
  const list = Array.isArray(tasks) ? tasks : [];
  const now = Number(options.now || Date.now());
  const at = isoFromMs(now);
  const sourceTaskId = compactString(options.sourceTaskId);
  const stale = detectStaleSubmittingTask(list, {
    now,
    staleMs: options.staleMs || STALE_SUBMITTING_THRESHOLD_MS
  });
  const sourceTask = list.find((task) => compactString(task?.id) === sourceTaskId)
    || stale.task
    || list.find(isApiFirstBrowserModeAvailableTask)
    || null;
  const countsBefore = countTasks(list);
  const buttonProbe = normalizedButtonProbe(options.recoveryUiProbe || {});
  const patchesById = new Map();
  const switchedIds = [];
  const requeuedIds = [];
  const skippedCompletedIds = [];
  const preservedCompletedIds = list
    .filter((task) => COMPLETE_STATUSES.has(taskStatus(task)))
    .map((task) => compactString(task.id))
    .filter(Boolean);

  if (sourceTask && isTaskModelAccessDenied(sourceTask)) {
    return {
      ok: false,
      skippedBecauseModelAccess: true,
      error: "model_access_denied_hard_stop",
      sourceTaskId: compactString(sourceTask.id),
      patches: [],
      switched: 0,
      switchedIds: [],
      requeuedIds: [],
      preservedCompletedIds,
      completedBeforeSwitch: countsBefore.completed,
      pendingBeforeSwitch: countsBefore.pending,
      completedAfterSwitch: countsBefore.completed,
      pendingAfterSwitch: countsBefore.pending,
      queueRunnerAliveBeforeSwitch: options.queueRunnerAliveBeforeSwitch === true,
      queueRunnerAliveAfterSwitch: false,
      staleSubmittingDetected: stale.detected,
      staleSubmittingTaskId: stale.taskId,
      staleSubmittingAgeMs: stale.ageMs,
      staleSubmittingResolution: stale.resolution,
      recoveryActionError: "model_access_denied_hard_stop"
    };
  }

  const basePatch = {
    submitPathPreference: "dom_first",
    submitPath: "dom_first",
    pendingRowsPreserved: true,
    switchedPendingRowsToDom: true,
    userConfirmedSwitchToDom: true,
    browserModeSwitchReason: "api_first_blocked_dom_available",
    browserModeSwitchAt: at,
    browserModeResumeStartedAt: at,
    recoveryContinueActionStartedAt: at,
    recoveryActionError: "",
    completedBeforeSwitch: countsBefore.completed,
    pendingBeforeSwitch: countsBefore.pending,
    queueRunnerAliveBeforeSwitch: options.queueRunnerAliveBeforeSwitch === true,
    staleSubmittingDetected: stale.detected,
    staleSubmittingTaskId: stale.taskId,
    staleSubmittingAgeMs: stale.ageMs,
    staleSubmittingResolution: stale.resolution,
    ...buttonProbe
  };

  for (const task of list) {
    if (COMPLETE_STATUSES.has(taskStatus(task))) {
      skippedCompletedIds.push(compactString(task.id));
      continue;
    }
    if (!shouldSwitchPendingTask(task)) continue;
    mergePatch(patchesById, task.id, basePatch);
    switchedIds.push(compactString(task.id));
  }

  if (sourceTask && shouldRequeueSourceTask(sourceTask, stale)) {
    mergePatch(patchesById, sourceTask.id, {
      ...basePatch,
      status: TaskStatus.pending,
      attempts: 0,
      previousStatusBeforeBrowserMode: sourceTask.status || "",
      previousSubmitPathBeforeBrowserMode: sourceTask.submitPath || sourceTask.submitPathPreference || "",
      previousFailureClassBeforeBrowserMode: sourceTask.failureClass || "",
      previousLastErrorBeforeBrowserMode: sourceTask.lastError || sourceTask.error || "",
      apiPathBlockResolvedByUserAt: at,
      lastError: "",
      healAction: "browser_mode_resume",
      failureScope: "task"
    });
    const id = compactString(sourceTask.id);
    if (!switchedIds.includes(id)) switchedIds.push(id);
    if (taskStatus(sourceTask) !== TaskStatus.pending) requeuedIds.push(id);
  } else if (sourceTask && COMPLETE_STATUSES.has(taskStatus(sourceTask))) {
    skippedCompletedIds.push(compactString(sourceTask.id));
  }

  const patched = applyBrowserModeRecoveryPlanToTasks(list, { patches: [...patchesById.entries()].map(([taskId, patch]) => ({ taskId, patch })) });
  const countsAfter = countTasks(patched);
  const patches = [...patchesById.entries()].map(([taskId, patch]) => ({
    taskId,
    patch: {
      ...patch,
      switchedPendingRowsToDomCount: switchedIds.length,
      completedAfterSwitch: countsAfter.completed,
      pendingAfterSwitch: countsAfter.pending
    }
  }));

  return {
    ok: patches.length > 0,
    skippedBecauseModelAccess: false,
    error: patches.length ? "" : "no_recoverable_api_first_rows",
    sourceTaskId: compactString(sourceTask?.id || sourceTaskId),
    patches,
    switched: switchedIds.length,
    switchedIds,
    requeuedIds,
    skippedCompletedIds: compactIdList(skippedCompletedIds),
    preservedCompletedIds: compactIdList(preservedCompletedIds),
    completedBeforeSwitch: countsBefore.completed,
    pendingBeforeSwitch: countsBefore.pending,
    completedAfterSwitch: countsAfter.completed,
    pendingAfterSwitch: countsAfter.pending,
    queueRunnerAliveBeforeSwitch: options.queueRunnerAliveBeforeSwitch === true,
    queueRunnerAliveAfterSwitch: false,
    staleSubmittingDetected: stale.detected,
    staleSubmittingTaskId: stale.taskId,
    staleSubmittingAgeMs: stale.ageMs,
    staleSubmittingResolution: stale.resolution,
    recoveryActionError: patches.length ? "" : "no_recoverable_api_first_rows"
  };
}

export function applyBrowserModeRecoveryPlanToTasks(tasks = [], plan = {}) {
  const patches = new Map((Array.isArray(plan.patches) ? plan.patches : [])
    .map((entry) => [compactString(entry.taskId), entry.patch || {}])
    .filter(([taskId]) => Boolean(taskId)));
  return (Array.isArray(tasks) ? tasks : []).map((task) => ({
    ...task,
    ...(patches.get(compactString(task.id)) || {})
  }));
}

export function buildQueueProofGate(input = {}) {
  const tasks = Array.isArray(input.tasks) ? input.tasks : [];
  const matrix = input.matrix || {};
  const openTasks = tasks.filter((task) => !TERMINAL_STATUSES.has(taskStatus(task)));
  const safeSkippedTasks = tasks.filter((task) => {
    const status = taskStatus(task);
    return ["failed", "blocked"].includes(status) &&
      lower(task.failureClass) === "unsafe_generation_policy_block" &&
      lower(task.failureScope) === "task";
  });
  const safeSkippedIds = new Set(safeSkippedTasks.map((task) => compactString(task.id)).filter(Boolean));
  const failedTasks = tasks.filter((task) => {
    const status = taskStatus(task);
    if (!["failed", "blocked"].includes(status)) return false;
    return !safeSkippedIds.has(compactString(task.id));
  });
  const reasons = [];
  if (input.queueRunning === true) reasons.push("queue_still_running");
  if (openTasks.length > 0) reasons.push("open_rows_remaining");
  if (failedTasks.length > 0) reasons.push("failed_or_blocked_rows_remaining");
  if (matrix.queue?.status && matrix.queue.status !== "PASS") reasons.push("queue_matrix_not_pass");
  if (matrix.submit?.status === "FAIL") reasons.push("submit_matrix_failed");
  if (matrix.refs?.status === "FAIL") reasons.push("refs_matrix_failed");
  if (matrix.downloads?.status === "FAIL") reasons.push("download_matrix_failed");
  const userPausedSafe = input.userPausedSafe === true && openTasks.length > 0 && failedTasks.length === 0;
  const status = reasons.length === 0 || userPausedSafe ? "PASS" : "FAIL";
  return {
    status,
    canCallRunGreen: status === "PASS",
    userPausedSafe,
    reasons,
    queueRunning: input.queueRunning === true,
    taskCount: tasks.length,
    terminal: tasks.length - openTasks.length,
    open: openTasks.length,
    failed: failedTasks.length,
    safeSkipped: safeSkippedTasks.length,
    openTaskIds: openTasks.map((task) => compactString(task.id)).filter(Boolean),
    failedTaskIds: failedTasks.map((task) => compactString(task.id)).filter(Boolean),
    safeSkippedTaskIds: safeSkippedTasks.map((task) => compactString(task.id)).filter(Boolean)
  };
}
