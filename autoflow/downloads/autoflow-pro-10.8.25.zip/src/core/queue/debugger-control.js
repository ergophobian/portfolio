export const DOM_DEBUGGER_CONTROL_CONFLICT = "DOM_DEBUGGER_CONTROL_CONFLICT";
export const DOM_DEBUGGER_CONTROL_CONFLICT_CLASS = "dom_debugger_control_conflict";
export const DEBUGGER_CONTROL_CONFLICT_USER_MESSAGE = "Auto Flow cannot control this Flow tab because another browser controller is attached. Close other automation/Claude/Codex tabs, stop other Auto Flow runs, fully restart Chrome if needed, then Resume.";

const CONFLICT_PATTERNS = [
  /another debugger/i,
  /already attached/i,
  /controlled on another instance/i,
  /being controlled on another instance/i,
  /target is already being controlled/i,
  /already being controlled/i,
  /detached while another client attached/i,
  /another client attached/i,
  /chrome_debugger_control_conflict/i,
  /dom_debugger_control_conflict/i,
  /dom_debugger_controlled_instance/i
];

const NON_CONFLICT_PATTERNS = [
  /debugger is not attached/i,
  /not attached to (?:the )?tab/i,
  /debugger.*detach(?:ed)? before/i,
  /detach(?:ed)? before click/i,
  /no debugger session/i,
  /session.*not found/i
];

export function debuggerControlErrorText(value, out = [], depth = 0, keyHint = "") {
  if (value === null || value === undefined || depth > 5) return out.join(" ");
  const keyRelevant = !keyHint || /error|message|status|reason|class|code|detail|debugger|control|conflict/i.test(String(keyHint));
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    const text = String(value || "").trim();
    if (text && keyRelevant) out.push(text);
    return out.join(" ");
  }
  if (value instanceof Error) {
    const text = String(value.message || value || "").trim();
    if (text) out.push(text);
    for (const key of ["code", "failureClass", "statusText", "rawDebuggerError"]) {
      if (value[key]) debuggerControlErrorText(value[key], out, depth + 1, key);
    }
    return out.join(" ");
  }
  if (Array.isArray(value)) {
    value.forEach((entry) => debuggerControlErrorText(entry, out, depth + 1, keyHint));
    return out.join(" ");
  }
  if (typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      debuggerControlErrorText(child, out, depth + 1, key);
    }
    return out.join(" ");
  }
  return out.join(" ");
}

export function isDebuggerControlConflictText(value) {
  const text = debuggerControlErrorText(value);
  if (!text) return false;
  if (new RegExp(DOM_DEBUGGER_CONTROL_CONFLICT, "i").test(text)) return true;
  if (new RegExp(DOM_DEBUGGER_CONTROL_CONFLICT_CLASS, "i").test(text)) return true;
  if (NON_CONFLICT_PATTERNS.some((pattern) => pattern.test(text))) return false;
  return CONFLICT_PATTERNS.some((pattern) => pattern.test(text));
}

export function debuggerControlConflictMessage(raw = "") {
  const detail = String(raw || "").trim();
  return detail ? `${DOM_DEBUGGER_CONTROL_CONFLICT}: ${detail}` : DOM_DEBUGGER_CONTROL_CONFLICT;
}

export function normalizeDebuggerControlConflictDetails(error, details = {}) {
  const rawDebuggerError = String(details.rawDebuggerError || debuggerControlErrorText(error) || "").trim();
  return {
    code: DOM_DEBUGGER_CONTROL_CONFLICT,
    failureClass: DOM_DEBUGGER_CONTROL_CONFLICT_CLASS,
    failureScope: "global",
    recoveryPolicy: "hard_stop",
    healAction: "user_action_required",
    pendingRowsPreserved: true,
    rawDebuggerError,
    tabId: Number.isFinite(Number(details.tabId)) ? Number(details.tabId) : null,
    projectId: String(details.projectId || ""),
    sessionMapHadTab: details.sessionMapHadTab === true,
    sessionCount: Number(details.sessionCount || 0),
    recoveryAttempted: details.recoveryAttempted === true,
    recoveryResult: String(details.recoveryResult || ""),
    userAction: DEBUGGER_CONTROL_CONFLICT_USER_MESSAGE
  };
}

export function createDebuggerControlConflictError(error, details = {}) {
  const normalized = normalizeDebuggerControlConflictDetails(error, details);
  const err = new Error(debuggerControlConflictMessage(normalized.rawDebuggerError));
  Object.assign(err, normalized);
  return err;
}

export function normalizeDebuggerControlConflictResult(result = {}, details = {}) {
  const normalized = normalizeDebuggerControlConflictDetails(result, {
    ...details,
    rawDebuggerError: details.rawDebuggerError || result?.rawDebuggerError || result?.data?.rawDebuggerError || debuggerControlErrorText(result)
  });
  const message = debuggerControlConflictMessage(normalized.rawDebuggerError);
  return {
    ...(result && typeof result === "object" ? result : {}),
    ok: false,
    status: Number(result?.status || 0),
    statusText: DOM_DEBUGGER_CONTROL_CONFLICT,
    error: message,
    failureClass: DOM_DEBUGGER_CONTROL_CONFLICT_CLASS,
    failureScope: "global",
    recoveryPolicy: "hard_stop",
    healAction: "user_action_required",
    pendingRowsPreserved: true,
    recoveryAttempted: normalized.recoveryAttempted,
    recoveryFinalOutcome: normalized.recoveryResult === "recovered"
      ? "recovered"
      : "blocked_browser_controller_conflict",
    recommendedNextAction: DEBUGGER_CONTROL_CONFLICT_USER_MESSAGE,
    data: {
      ...(result?.data || {}),
      error: message,
      rawDebuggerError: normalized.rawDebuggerError,
      transport: result?.data?.transport || result?.transport || "chrome_debugger",
      classification: DOM_DEBUGGER_CONTROL_CONFLICT_CLASS,
      debuggerControl: normalized,
      userAction: DEBUGGER_CONTROL_CONFLICT_USER_MESSAGE
    }
  };
}
