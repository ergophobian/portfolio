import { TaskStatus } from "./task-ledger.js";

const VIDEO_MODES = new Set([
  "text-to-video",
  "image-to-video",
  "start-end-image-to-video",
  "ingredients-to-video"
]);

const RETRY_MODE_ALIASES = Object.freeze({
  "text-to-image": "text-to-image",
  image: "text-to-image",
  "create-image": "text-to-image",
  "image-only": "text-to-image",
  "text-to-video": "text-to-video",
  video: "text-to-video",
  "video-only": "text-to-video",
  "image-to-video": "image-to-video",
  "frame-to-video": "image-to-video",
  "frames-to-video": "image-to-video",
  "start-end-image-to-video": "start-end-image-to-video",
  "start-end-frame-to-video": "start-end-image-to-video",
  frames: "image-to-video",
  "ingredients-to-video": "ingredients-to-video",
  ingredients: "ingredients-to-video"
});

const RETRY_SURFACE_BY_MODE = Object.freeze({
  "text-to-video": Object.freeze({
    mode: "text-to-video",
    kind: "prompt-only",
    modeLabel: "Text to Video",
    promptFirst: true,
    allowsImageInputs: false,
    imageInputsOptional: false,
    selectionLimit: 0,
    inputRoles: Object.freeze([]),
    frameSlots: Object.freeze([])
  }),
  "text-to-image": Object.freeze({
    mode: "text-to-image",
    kind: "reference-images",
    modeLabel: "Create Image",
    promptFirst: true,
    allowsImageInputs: true,
    imageInputsOptional: true,
    selectionLimit: 10,
    inputRoles: Object.freeze(["imagePromptRefs", "styleRefRefs", "omniRefRefs"]),
    frameSlots: Object.freeze([])
  }),
  "ingredients-to-video": Object.freeze({
    mode: "ingredients-to-video",
    kind: "ingredients",
    modeLabel: "Ingredients to Video",
    promptFirst: false,
    allowsImageInputs: true,
    imageInputsOptional: false,
    selectionLimit: 3,
    inputRoles: Object.freeze(["ingredientsRefs"]),
    frameSlots: Object.freeze([])
  }),
  "image-to-video": Object.freeze({
    mode: "image-to-video",
    kind: "frame-pair",
    modeLabel: "Frame to Video",
    promptFirst: false,
    allowsImageInputs: true,
    imageInputsOptional: false,
    selectionLimit: 2,
    inputRoles: Object.freeze(["startFrameRef", "endFrameRef"]),
    frameSlots: Object.freeze(["startFrameRef", "endFrameRef"])
  }),
  "start-end-image-to-video": Object.freeze({
    mode: "start-end-image-to-video",
    kind: "frame-pair",
    modeLabel: "Frame to Video",
    promptFirst: false,
    allowsImageInputs: true,
    imageInputsOptional: false,
    selectionLimit: 2,
    inputRoles: Object.freeze(["startFrameRef", "endFrameRef"]),
    frameSlots: Object.freeze(["startFrameRef", "endFrameRef"])
  })
});

export function isVideoTask(task = {}) {
  return VIDEO_MODES.has(String(task?.mode || ""));
}

export function normalizeRetryMode(rawMode = "") {
  const key = String(rawMode || "").trim().toLowerCase().replace(/[_\s]+/g, "-");
  return RETRY_MODE_ALIASES[key] || "";
}

export function retrySurfaceForMode(mode = "") {
  const normalized = normalizeRetryMode(mode) || "text-to-video";
  return RETRY_SURFACE_BY_MODE[normalized] || RETRY_SURFACE_BY_MODE["text-to-video"];
}

export function retryOriginalModeForTask(task = {}) {
  return normalizeRetryMode(
    task?.retryOriginalMode ||
    task?.originalMode ||
    task?.requestedMode ||
    task?.buildJobsMode ||
    task?.normalizedRuntimeMode ||
    task?.mode
  ) || inferRetryModeFromReason(task?.reason || task?.lastError || task?.failureClass);
}

export function retryFailureContextPatch(task = {}, reason = "") {
  const retryOriginalMode = retryOriginalModeForTask(task) || "text-to-video";
  const failureReason = compactString(reason || task?.reason || task?.lastError || task?.failureClass || "");
  const surface = retrySurfaceForMode(retryOriginalMode);
  return {
    reason: failureReason,
    retryOriginalMode,
    retrySurface: surface.kind,
    retryInputRoles: [...surface.inputRoles],
    retryFrameSlots: [...surface.frameSlots],
    retryMaxInputs: surface.selectionLimit,
    retryPromptFirst: surface.promptFirst
  };
}

export function buildRetryModalTask(source = {}) {
  if (!source || typeof source !== "object") return null;
  const context = retryFailureContextPatch(source);
  const surface = retrySurfaceForMode(context.retryOriginalMode);
  const normalized = {
    ...source,
    ...context,
    mode: context.retryOriginalMode,
    prompt: compactString(source.prompt || source.videoPrompt || source.imagePrompt || ""),
    refInputs: [],
    refMediaIds: [],
    startRefInput: null,
    endRefInput: null,
    startMediaId: "",
    endMediaId: "",
    retryEditSurface: {
      mode: surface.mode,
      kind: surface.kind,
      modeLabel: surface.modeLabel,
      promptFirst: surface.promptFirst,
      allowsImageInputs: surface.allowsImageInputs,
      imageInputsOptional: surface.imageInputsOptional,
      selectionLimit: surface.selectionLimit,
      inputRoles: [...surface.inputRoles],
      frameSlots: [...surface.frameSlots]
    }
  };

  if (surface.kind === "prompt-only") {
    return normalized;
  }

  if (surface.kind === "frame-pair") {
    const slots = frameSlotRefsFromTask(source);
    normalized.startRefInput = slots.start || null;
    normalized.endRefInput = slots.end || null;
    normalized.startMediaId = mediaIdFromRef(slots.start) || "";
    normalized.endMediaId = mediaIdFromRef(slots.end) || "";
    normalized.refInputs = [slots.start, slots.end].filter(Boolean);
    normalized.refMediaIds = normalized.refInputs.map(mediaIdFromRef).filter(Boolean);
    normalized.retryFrameSlotInputs = {
      startFrameRef: compactRetryRef(slots.start),
      endFrameRef: compactRetryRef(slots.end)
    };
    return normalized;
  }

  const refs = refsForRetrySurface(source, surface)
    .slice(0, surface.selectionLimit)
    .map((ref) => normalizeRetryRef(ref, surface.inputRoles[0] || ref?.role || ""));
  normalized.refInputs = refs;
  normalized.refMediaIds = refs.map(mediaIdFromRef).filter(Boolean);
  return normalized;
}

export function isComposerNotReadyVideoRetry(task = {}) {
  if (!isVideoTask(task)) return false;
  if (String(task?.status || "") !== TaskStatus.pending) return false;
  const error = String(task?.lastError || task?.statusText || task?.error || "").toLowerCase();
  return error.includes("composer_not_ready")
    && (error.includes("editor_missing") || error.includes("editor_unstable") || error.includes("flow_loading"));
}

export function activeVideoTaskBeforeComposerRetry(task = {}, tasks = []) {
  if (!isComposerNotReadyVideoRetry(task)) return null;
  const priorWaits = Math.max(0, Number(task?.composerRetryWaitCount || 0) || 0);
  const attempts = Math.max(1, Number(task?.attempts || 0) || 0);
  if (priorWaits >= attempts) return null;
  return (Array.isArray(tasks) ? tasks : []).find((candidate) => (
    candidate?.id &&
    candidate.id !== task.id &&
    String(candidate.status || "") === TaskStatus.generating &&
    isVideoTask(candidate)
  )) || null;
}

function inferRetryModeFromReason(reason = "") {
  const text = String(reason || "").toLowerCase();
  if (text.includes("ingredient") || text.includes("r2v")) return "ingredients-to-video";
  if (text.includes("frame") || text.includes("i2v") || text.includes("start image") || text.includes("end image")) return "image-to-video";
  if (text.includes("video")) return "text-to-video";
  if (text.includes("image")) return "text-to-image";
  return "";
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function normalizeRetryMediaId(value = "") {
  const raw = compactString(value);
  if (!raw) return "";
  const withoutAssetPrefix = raw.replace(/^fe_id_/i, "");
  const uuid = withoutAssetPrefix.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0] || "";
  return uuid || raw;
}

function mediaIdFromRef(ref = {}) {
  return normalizeRetryMediaId(ref?.mediaId || ref?.assetImageId || ref?.id || "");
}

function sameRetryRef(left = {}, right = {}) {
  const leftMediaId = mediaIdFromRef(left);
  const rightMediaId = mediaIdFromRef(right);
  if (leftMediaId && rightMediaId) return leftMediaId === rightMediaId;
  const leftBlob = compactString(left?.blobStoreId);
  const rightBlob = compactString(right?.blobStoreId);
  if (leftBlob && rightBlob) return leftBlob === rightBlob;
  const leftFile = compactString(left?.fileName || left?.name || left?.title);
  const rightFile = compactString(right?.fileName || right?.name || right?.title);
  return Boolean(leftFile && rightFile && leftFile === rightFile);
}

function normalizeRetryRef(ref = {}, fallbackRole = "") {
  if (!ref || typeof ref !== "object") return null;
  const mediaId = mediaIdFromRef(ref);
  const fileName = compactString(ref.fileName || ref.name || ref.title);
  if (!mediaId && !fileName && !ref.dataUrl && !ref.imageUrl && !ref.mediaUrl) return null;
  return {
    ...ref,
    role: compactString(ref.role || fallbackRole),
    mediaId,
    assetImageId: compactString(ref.assetImageId || ""),
    blobStoreId: compactString(ref.blobStoreId || ""),
    fileName: fileName || "reference.png",
    title: compactString(ref.title || fileName || "Reference"),
    mimeType: compactString(ref.mimeType || ref.type || "image/png"),
    imageUrl: compactString(ref.imageUrl || ref.url || ""),
    mediaUrl: compactString(ref.mediaUrl || ref.sourceUrl || ref.imageUrl || ref.url || ""),
    dataUrl: compactString(ref.dataUrl)
  };
}

function compactRetryRef(ref = {}) {
  if (!ref) return null;
  return {
    role: compactString(ref.role),
    mediaId: compactString(ref.mediaId),
    assetImageId: compactString(ref.assetImageId),
    blobStoreId: compactString(ref.blobStoreId),
    fileName: compactString(ref.fileName || ref.title || ref.name),
    hasInlineData: Boolean(ref.dataUrl || ref.imageUrl || ref.mediaUrl)
  };
}

function allTaskRefs(task = {}) {
  const refs = [];
  if (Array.isArray(task.refInputs)) refs.push(...task.refInputs);
  if (Array.isArray(task.refImages)) refs.push(...task.refImages);
  if (Array.isArray(task.refMediaIds)) {
    refs.push(...task.refMediaIds.map((mediaId) => ({ mediaId, role: "" })));
  }
  return refs.map((ref) => normalizeRetryRef(ref)).filter(Boolean);
}

function refsForRetrySurface(task = {}, surface = {}) {
  const roleSet = new Set(surface.inputRoles || []);
  const refs = allTaskRefs(task);
  const roleMatches = refs.filter((ref) => roleSet.has(ref.role));
  if (roleMatches.length) return roleMatches;
  const frameRoles = new Set(["startFrameRef", "endFrameRef"]);
  return refs.filter((ref) => !frameRoles.has(ref.role));
}

function frameSlotRefsFromTask(task = {}) {
  const refs = allTaskRefs(task);
  const byRole = (role) => refs.find((ref) => ref.role === role) || null;
  const start = normalizeRetryRef(task.startRefInput, "startFrameRef")
    || byRole("startFrameRef")
    || refs[0]
    || (task.startMediaId ? normalizeRetryRef({ mediaId: task.startMediaId, role: "startFrameRef" }) : null);
  const end = normalizeRetryRef(task.endRefInput, "endFrameRef")
    || byRole("endFrameRef")
    || refs.find((ref) => !sameRetryRef(ref, start))
    || (task.endMediaId ? normalizeRetryRef({ mediaId: task.endMediaId, role: "endFrameRef" }) : null);
  return {
    start: start ? normalizeRetryRef({ ...start, role: "startFrameRef" }, "startFrameRef") : null,
    end: end ? normalizeRetryRef({ ...end, role: "endFrameRef" }, "endFrameRef") : null
  };
}
