import {
  agentSelfHealPromptLines,
  buildAgentSelfHealPolicy,
  normalizeAgentAutonomy
} from "./agent-autonomy.js";

export const AGENT_SUBMIT_PATH = "agent_first";

const IMAGE_PROMPT_LABEL = "Image prompt";
const VIDEO_PROMPT_LABELS = ["Veo 3 prompt", "Video prompt", "VIDEO (Omni)", "VIDEO"];
export const MAX_AGENT_ROWS_PER_BATCH = 100;
// A single 100-row Agent request can fan out fast enough for Flow to return
// PUBLIC_ERROR_USER_REQUESTS_THROTTLED. Keep the hard ceiling for explicit
// tooling, but default product runs to small sequential batches.
export const DEFAULT_AGENT_ROWS_PER_BATCH = 10;
export const MAX_AGENT_REFERENCES_PER_BATCH = 10;
export const MAX_AGENT_ONE_TO_ONE_REFS_PER_BATCH = MAX_AGENT_REFERENCES_PER_BATCH;

export function parseAutoFlowAgentPacket(packetText = "") {
  const text = normalizeNewlines(packetText);
  const title = extractTitle(text);
  const clipMatches = [...text.matchAll(/^##\s+Clip\s+(\d+)\s*(?:[-:\u2013\u2014]\s*(.*?))?\s*$/gim)];
  const clips = clipMatches.map((match, index) => {
    const start = match.index + match[0].length;
    const end = clipMatches[index + 1]?.index ?? text.length;
    const body = text.slice(start, end);
    const videoBlock = extractLabeledBlock(body, VIDEO_PROMPT_LABELS);
    return {
      clipNumber: Number.parseInt(match[1], 10),
      title: cleanInlineText(match[2] || `Clip ${match[1]}`),
      imagePrompt: extractLabeledBlock(body, [IMAGE_PROMPT_LABEL]).text,
      frames: extractFrameBlocks(body),
      videoPrompt: videoBlock.text,
      videoPromptLabel: videoBlock.label,
      rawText: body.trim()
    };
  }).filter((clip) => Number.isFinite(clip.clipNumber) && (clip.imagePrompt || clip.frames.length || clip.videoPrompt));

  return { title, clips };
}

export function buildAgentF2VMatrix({
  packetText = "",
  rows = 1,
  repeatCount = 1,
  videoLength = "8",
  aspectRatio = "portrait",
  model = "Veo 3.1 Lite [Lower Priority]",
  reference = {},
  references = [],
  confirmCredits = false,
  autonomy,
  maxSelfHealRetries,
  suppressOnScreenText
} = {}) {
  const parsed = parseAutoFlowAgentPacket(packetText);
  const rowCount = normalizeRowsRequested(rows, parsed.clips.length, 1);
  const videosPerRow = clampInt(repeatCount, 1, 100, 1);
  const selectedClips = parsed.clips.slice(0, rowCount);
  const normalizedReferences = normalizeReferences({ references, reference });
  const normalizedReference = normalizedReferences[0] || (hasReferenceInput(reference) ? normalizeReference(reference) : {});
  const matrix = {
    kind: "agent_f2v_image_first",
    submitPath: AGENT_SUBMIT_PATH,
    title: parsed.title,
    mode: "image-to-video",
    rowsRequested: rowCount,
    rowsBuilt: selectedClips.length,
    repeatCount: videosPerRow,
    expectedImages: selectedClips.length,
    expectedVideos: selectedClips.length * videosPerRow,
    settings: {
      aspectRatio: String(aspectRatio || "portrait"),
      videoLength: String(videoLength || "8"),
      model: String(model || "Veo 3.1 Lite [Lower Priority]"),
      autonomy: normalizeAgentAutonomy(autonomy),
      maxSelfHealRetries,
      suppressOnScreenText
    },
    autonomy: normalizeAgentAutonomy(autonomy),
    selfHeal: buildAgentSelfHealPolicy({ autonomy, maxSelfHealRetries, suppressOnScreenText }),
    confirmCredits: confirmCredits === true,
    reference: normalizedReference,
    references: normalizedReferences,
    rows: []
  };

  matrix.rows = selectedClips.map((clip, index) => {
    const rowId = `CLIP-${String(clip.clipNumber).padStart(2, "0")}`;
    const row = {
      id: `clip-${String(clip.clipNumber).padStart(2, "0")}`,
      rowId,
      tag: `[${rowId}]`,
      finalVideoId: `[${rowId}]`,
      rowIndex: index + 1,
      clipNumber: clip.clipNumber,
      title: clip.title,
      imagePrompt: clip.imagePrompt,
      videoPrompt: clip.videoPrompt,
      reference: normalizedReference,
      references: normalizedReferences,
      expectedImages: 1,
      expectedVideos: videosPerRow,
      agentPrompt: ""
    };
    row.agentPrompt = buildAgentRowPrompt(row, matrix);
    return row;
  });
  matrix.batchPlan = buildAgentBatchPlan(matrix);

  return matrix;
}

export function buildAgentOmniMultiFrameMatrix({
  packetText = "",
  rows = "all",
  repeatCount = 1,
  videoLength = "8-10",
  aspectRatio = "portrait",
  model = "Omni",
  reference = {},
  references = [],
  confirmCredits = false,
  autonomy,
  maxSelfHealRetries,
  suppressOnScreenText
} = {}) {
  const parsed = parseAutoFlowAgentPacket(packetText);
  const rowCount = normalizeRowsRequested(rows, parsed.clips.length, parsed.clips.length);
  const videosPerRow = clampInt(repeatCount, 1, 100, 1);
  const selectedClips = parsed.clips
    .filter((clip) => clip.frames.length && clip.videoPrompt)
    .slice(0, rowCount);
  const normalizedReferences = normalizeReferences({ references, reference });
  const normalizedReference = normalizedReferences[0] || (hasReferenceInput(reference) ? normalizeReference(reference) : {});
  const matrix = {
    kind: "agent_omni_multiframe",
    submitPath: AGENT_SUBMIT_PATH,
    title: parsed.title,
    mode: "image-to-video",
    rowsRequested: rows === "all" ? "all" : rowCount,
    rowsBuilt: selectedClips.length,
    repeatCount: videosPerRow,
    expectedImages: selectedClips.reduce((sum, clip) => sum + clip.frames.length, 0),
    expectedVideos: selectedClips.length * videosPerRow,
    settings: {
      aspectRatio: String(aspectRatio || "portrait"),
      videoLength: String(videoLength || "8-10"),
      model: String(model || "Omni"),
      autonomy: normalizeAgentAutonomy(autonomy),
      maxSelfHealRetries,
      suppressOnScreenText
    },
    autonomy: normalizeAgentAutonomy(autonomy),
    selfHeal: buildAgentSelfHealPolicy({ autonomy, maxSelfHealRetries, suppressOnScreenText }),
    confirmCredits: confirmCredits === true,
    reference: normalizedReference,
    references: normalizedReferences,
    rows: []
  };

  matrix.rows = selectedClips.map((clip, index) => {
    const rowId = `CLIP-${String(clip.clipNumber).padStart(2, "0")}`;
    const row = {
      id: `clip-${String(clip.clipNumber).padStart(2, "0")}`,
      rowId,
      tag: `[${rowId}]`,
      finalVideoId: `[${rowId}]`,
      rowIndex: index + 1,
      clipNumber: clip.clipNumber,
      title: clip.title,
      frames: clip.frames,
      videoPrompt: clip.videoPrompt,
      videoPromptLabel: clip.videoPromptLabel,
      reference: normalizedReference,
      references: normalizedReferences,
      expectedImages: clip.frames.length,
      expectedVideos: videosPerRow,
      agentPrompt: ""
    };
    row.agentPrompt = buildAgentOmniRowPrompt(row, matrix);
    return row;
  });
  matrix.batchPlan = buildAgentBatchPlan(matrix);

  return matrix;
}

export function buildAgentGenericMatrix({
  mode = "text-to-image",
  prompts = [],
  repeatCount = 1,
  videoLength = "8",
  aspectRatio = "portrait",
  model = "",
  referenceStrategy = {},
  references = [],
  rowReferences = [],
  rowReferenceStrategies = [],
  confirmCredits = false,
  autonomy,
  maxSelfHealRetries,
  suppressOnScreenText
} = {}) {
  const normalizedMode = normalizeAgentMode(mode);
  const rows = normalizePromptLines(prompts);
  const outputsPerRow = clampInt(repeatCount, 1, 100, 1);
  const normalizedReferences = normalizeReferenceList(references);
  const normalizedRowReferences = rows.map((_, index) => normalizeReferenceList(Array.isArray(rowReferences?.[index]) ? rowReferences[index] : []));
  const normalizedRowReferenceStrategies = rows.map((_, index) => {
    const strategy = rowReferenceStrategies?.[index];
    return strategy && typeof strategy === "object"
      ? normalizeReferenceStrategy(strategy, normalizedMode)
      : null;
  });
  const hasPerRowReferences = normalizedRowReferences.some((entries) => entries.length > 0);
  const normalizedReferenceStrategy = normalizeReferenceStrategy(referenceStrategy, normalizedMode);
  const isImageMode = normalizedMode === "text-to-image";
  const matrix = {
    kind: "agent_generic_run",
    submitPath: AGENT_SUBMIT_PATH,
    title: "Auto Flow Agent Run",
    mode: normalizedMode,
    rowsRequested: rows.length,
    rowsBuilt: rows.length,
    repeatCount: outputsPerRow,
    expectedImages: isImageMode ? rows.length * outputsPerRow : 0,
    expectedVideos: isImageMode ? 0 : rows.length * outputsPerRow,
    settings: {
      aspectRatio: String(aspectRatio || "portrait"),
      videoLength: String(videoLength || "8"),
      model: String(model || defaultAgentModelForMode(normalizedMode)),
      autonomy: normalizeAgentAutonomy(autonomy),
      maxSelfHealRetries,
      suppressOnScreenText
    },
    autonomy: normalizeAgentAutonomy(autonomy),
    selfHeal: buildAgentSelfHealPolicy({ autonomy, maxSelfHealRetries, suppressOnScreenText }),
    confirmCredits: confirmCredits === true,
    referenceStrategy: normalizedReferenceStrategy,
    references: normalizedReferences,
    rowReferences: normalizedRowReferences,
    rowReferenceStrategies: normalizedRowReferenceStrategies,
    hasPerRowReferences,
    rows: []
  };

  matrix.rows = rows.map((prompt, index) => {
    const identity = genericRowIdentity(prompt, index);
    const referencesForRow = hasPerRowReferences ? normalizedRowReferences[index] : normalizedReferences;
    const row = {
      id: identity.id,
      rowId: identity.rowId,
      tag: identity.tag,
      finalVideoId: identity.finalVideoId,
      rowIndex: index + 1,
      title: identity.title,
      mode: normalizedMode,
      prompt,
      referenceStrategy: normalizedRowReferenceStrategies[index] || (hasPerRowReferences
        ? {
            kind: referencesForRow.length ? "per_row_reference_set" : "none",
            description: referencesForRow.length
              ? `Use only these attached references for this row: ${referencesForRow.map((entry) => `${entry.handle} (${entry.role})`).join(", ")}.`
              : "No reference images are required for this row."
          }
        : normalizedReferenceStrategy),
      references: referencesForRow,
      expectedImages: isImageMode ? outputsPerRow : 0,
      expectedVideos: isImageMode ? 0 : outputsPerRow,
      agentPrompt: ""
    };
    row.agentPrompt = buildAgentGenericRowPrompt(row, matrix);
    return row;
  });
  matrix.batchPlan = buildAgentBatchPlan(matrix);

  return matrix;
}

export function buildAgentBulkVideoEditMatrix({
  sources = [],
  persistentReferences = [],
  prompt = "",
  prompts = [],
  reusePromptForAll = true,
  aspectRatio = "portrait",
  model = "Omni Flash",
  confirmCredits = false,
  autonomy,
  maxSelfHealRetries,
  suppressOnScreenText
} = {}) {
  const normalizedSources = (Array.isArray(sources) ? sources : [])
    .map((source, index) => {
      const handle = `@video_${String(index + 1).padStart(4, "0")}`;
      const rowId = `V2V-${String(index + 1).padStart(4, "0")}`;
      return {
        ...source,
        handle,
        rowId,
        fileName: cleanInlineText(source?.fileName || source?.title || `source-${index + 1}.mp4`),
        mediaId: cleanInlineText(source?.mediaId || ""),
        role: `source video for ${rowId}`
      };
    })
    .filter((source) => source.fileName);
  if (!normalizedSources.length) {
    const error = new Error("Bulk Video Edit needs at least one source video.");
    error.code = "AGENT_BULK_VIDEO_SOURCES_REQUIRED";
    throw error;
  }
  const persistent = normalizeReferenceList(persistentReferences).slice(0, MAX_AGENT_REFERENCES_PER_BATCH - 1);
  const capacity = MAX_AGENT_REFERENCES_PER_BATCH - persistent.length;
  if (capacity < 1) {
    const error = new Error("Persistent references leave no Agent attachment slot for a source video.");
    error.code = "AGENT_BULK_VIDEO_ATTACHMENT_CAPACITY_EXCEEDED";
    throw error;
  }
  const normalizedPrompts = normalizePromptLines(prompts);
  const sharedPrompt = cleanBlockText(prompt || normalizedPrompts[0] || "");
  if (!sharedPrompt && (reusePromptForAll || normalizedPrompts.length < normalizedSources.length)) {
    const error = new Error("Bulk Video Edit needs one reusable prompt or one prompt per source video.");
    error.code = "AGENT_BULK_VIDEO_PROMPT_REQUIRED";
    throw error;
  }
  const settings = {
    aspectRatio: String(aspectRatio || "portrait"),
    videoLength: "source",
    model: String(model || "Omni Flash"),
    autonomy: normalizeAgentAutonomy(autonomy),
    maxSelfHealRetries,
    suppressOnScreenText
  };
  const matrix = {
    kind: "agent_bulk_video_edit",
    submitPath: AGENT_SUBMIT_PATH,
    title: "Auto Flow Bulk Video Edit",
    mode: "video-to-video",
    rowsRequested: normalizedSources.length,
    rowsBuilt: normalizedSources.length,
    repeatCount: 1,
    expectedImages: 0,
    expectedVideos: normalizedSources.length,
    reusePromptForAll: reusePromptForAll === true,
    attachmentCapacity: MAX_AGENT_REFERENCES_PER_BATCH,
    persistentReferenceCount: persistent.length,
    videosPerBatch: capacity,
    settings,
    autonomy: settings.autonomy,
    selfHeal: buildAgentSelfHealPolicy({ autonomy, maxSelfHealRetries, suppressOnScreenText }),
    confirmCredits: confirmCredits === true,
    referenceStrategy: {
      kind: "per_row_reference_sets",
      description: `Each Agent message carries up to ${capacity} source videos plus the same ${persistent.length} persistent reference image${persistent.length === 1 ? "" : "s"}; total attachments never exceed ${MAX_AGENT_REFERENCES_PER_BATCH}.`
    },
    references: persistent,
    hasPerRowReferences: true,
    rows: []
  };
  matrix.rows = normalizedSources.map((source, index) => {
    const rowPrompt = reusePromptForAll === true ? sharedPrompt : cleanBlockText(normalizedPrompts[index] || sharedPrompt);
    const sourceReference = normalizeReference({
      handle: source.handle,
      fileName: source.fileName,
      role: source.role,
      sha256: source.sha256 || source.hash || ""
    });
    const references = [sourceReference, ...persistent];
    return {
      id: source.rowId.toLowerCase(),
      rowId: source.rowId,
      tag: `[${source.rowId}]`,
      finalVideoId: `[${source.rowId}]`,
      rowIndex: index + 1,
      title: source.fileName,
      mode: "video-to-video",
      prompt: rowPrompt,
      videoPrompt: rowPrompt,
      sourceVideoHandle: sourceReference.handle,
      sourceVideoFileName: source.fileName,
      sourceVideoMediaId: source.mediaId,
      references,
      referenceStrategy: {
        kind: "source_video_plus_persistent_references",
        description: `Edit only ${sourceReference.handle} for ${source.rowId}; use the persistent image handles as visual instructions, never as replacement source videos.`
      },
      expectedImages: 0,
      expectedVideos: 1,
      agentPrompt: buildAgentBulkVideoEditRowPrompt({
        rowId: source.rowId,
        sourceReference,
        persistentReferences: persistent,
        prompt: rowPrompt
      })
    };
  });
  matrix.batchPlan = buildAgentBatchPlan(matrix);
  return matrix;
}

export function buildAgentBatchPlan(matrix = {}, options = {}) {
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  const oneToOneReferences = String(matrix.referenceStrategy?.kind || "").trim().toLowerCase() === "one_to_one_batch";
  const referenceUnion = matrix.hasPerRowReferences === true;
  const requestedLimit = Number.parseInt(options.maxRowsPerBatch, 10);
  const rowCeiling = Number.isFinite(requestedLimit) && requestedLimit > 0
    ? Math.min(requestedLimit, MAX_AGENT_ROWS_PER_BATCH)
    : DEFAULT_AGENT_ROWS_PER_BATCH;
  const maxRowsPerBatch = oneToOneReferences
    ? Math.min(rowCeiling, MAX_AGENT_ONE_TO_ONE_REFS_PER_BATCH)
    : rowCeiling;
  const batches = [];
  if (referenceUnion) {
    let start = 0;
    while (start < rows.length) {
      const referenceKeys = new Set();
      let end = start;
      while (end < rows.length && end - start < maxRowsPerBatch) {
        const rowReferences = normalizeReferenceList(rows[end]?.references || []);
        const rowKeys = uniqueReferenceKeys(rowReferences);
        if (rowKeys.length > MAX_AGENT_REFERENCES_PER_BATCH) {
          const error = new Error(`Agent row ${rows[end]?.rowId || end + 1} requires ${rowKeys.length} unique references; the composer limit is ${MAX_AGENT_REFERENCES_PER_BATCH}.`);
          error.code = "AGENT_ROW_REFERENCE_LIMIT_EXCEEDED";
          throw error;
        }
        const nextKeys = new Set([...referenceKeys, ...rowKeys]);
        if (end > start && nextKeys.size > MAX_AGENT_REFERENCES_PER_BATCH) break;
        rowKeys.forEach((key) => referenceKeys.add(key));
        end += 1;
      }
      batches.push(agentBatchPlanEntry(rows, start, end, batches.length, [...referenceKeys]));
      start = end;
    }
  } else {
    for (let start = 0; start < rows.length; start += maxRowsPerBatch) {
      const end = Math.min(rows.length, start + maxRowsPerBatch);
      batches.push(agentBatchPlanEntry(rows, start, end, batches.length));
    }
  }
  return {
    version: 1,
    strategy: referenceUnion ? "reference_union_partition" : oneToOneReferences ? "one_to_one_reference_partition" : "row_partition",
    maxRowsPerBatch,
    maxReferencesPerBatch: MAX_AGENT_REFERENCES_PER_BATCH,
    totalRows: rows.length,
    totalBatches: batches.length,
    requiresMultipleSubmissions: batches.length > 1,
    expectedImages: rows.reduce((sum, row) => sum + Math.max(0, Number(row?.expectedImages || 0)), 0),
    expectedVideos: rows.reduce((sum, row) => sum + Math.max(0, Number(row?.expectedVideos || 0)), 0),
    batches
  };
}

function agentBatchPlanEntry(rows = [], start = 0, end = 0, batchIndex = 0, referenceKeys = []) {
  const batchRows = rows.slice(start, end);
  return {
    batchId: `BATCH-${String(batchIndex + 1).padStart(3, "0")}`,
    batchIndex: batchIndex + 1,
    rowOffset: start,
    rowStart: start + 1,
    rowEnd: end,
    rowCount: batchRows.length,
    rowIds: batchRows.map((row) => String(row?.rowId || row?.id || "")).filter(Boolean),
    referenceKeys,
    uniqueReferenceCount: referenceKeys.length,
    expectedImages: batchRows.reduce((sum, row) => sum + Math.max(0, Number(row?.expectedImages || 0)), 0),
    expectedVideos: batchRows.reduce((sum, row) => sum + Math.max(0, Number(row?.expectedVideos || 0)), 0)
  };
}

export function buildAgentBatchMatrices(matrix = {}, options = {}) {
  const plan = buildAgentBatchPlan(matrix, options);
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  return plan.batches.map((batch) => {
    const originalBatchRows = rows.slice(batch.rowOffset, batch.rowOffset + batch.rowCount);
    const oneToOneReferences = plan.strategy === "one_to_one_reference_partition";
    const referenceUnion = plan.strategy === "reference_union_partition";
    const batchReferences = referenceUnion
      ? uniqueReferences(originalBatchRows.flatMap((row) => row.references || []))
      : oneToOneReferences
        ? normalizeReferenceList(matrix.references || []).slice(batch.rowOffset, batch.rowOffset + batch.rowCount)
        : normalizeReferenceList(matrix.references || []);
    const referenceStrategy = referenceUnion
      ? {
          kind: "per_row_reference_sets",
          description: `Use only each row's declared reference handles. This batch attaches ${batchReferences.length} unique references across global rows ${batch.rowStart}-${batch.rowEnd}.`
        }
      : oneToOneReferences
        ? {
            ...(matrix.referenceStrategy || {}),
            description: `Use each attached row-specific start-frame handle only for its matching global row ${batch.rowStart}-${batch.rowEnd}. Never reuse one row's frame for another row.`
          }
        : matrix.referenceStrategy;
    const batchRows = originalBatchRows.map((row) => {
      const nextRow = oneToOneReferences
        ? { ...row, references: batchReferences, referenceStrategy }
        : row;
      if ((oneToOneReferences || referenceUnion) && matrix.kind === "agent_generic_run") {
        nextRow.agentPrompt = buildAgentGenericRowPrompt(nextRow, {
          ...matrix,
          references: batchReferences,
          referenceStrategy
        });
      }
      return nextRow;
    });
    return {
      ...matrix,
      title: plan.totalBatches > 1
        ? `${cleanInlineText(matrix.title || "Auto Flow Agent Run")} — ${batch.batchId}`
        : matrix.title,
      rowsRequested: batch.rowCount,
      rowsBuilt: batch.rowCount,
      expectedImages: batch.expectedImages,
      expectedVideos: batch.expectedVideos,
      references: batchReferences,
      reference: batchReferences[0] || matrix.reference,
      referenceStrategy,
      rows: batchRows,
      batch: {
        ...batch,
        referenceHandles: batchReferences.map((reference) => reference.handle),
        totalBatches: plan.totalBatches,
        totalRows: plan.totalRows
      },
      batchPlan: plan
    };
  });
}

export function buildAgentPromptText(matrix = {}) {
  if (matrix.kind === "agent_bulk_video_edit") return buildAgentBulkVideoEditPromptText(matrix);
  if (matrix.kind === "agent_generic_run" && String(matrix.referenceStrategy?.kind || "").trim().toLowerCase() === "one_to_one_batch") {
    return buildAgentOneToOneBatchPromptText(matrix);
  }
  if (matrix.kind === "agent_generic_run") return buildAgentGenericPromptText(matrix);
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  const references = normalizeReferences({
    references: matrix.references || rows[0]?.references || [],
    reference: matrix.reference || rows[0]?.reference || {}
  });
  const reference = references[0] || normalizeReference(matrix.reference || rows[0]?.reference || {});
  const settings = matrix.settings || {};
  const expectedImages = Number(matrix.expectedImages ?? rows.reduce((sum, row) => sum + Number(row.expectedImages ?? 0), 0));
  const expectedVideos = Number(matrix.expectedVideos ?? rows.reduce((sum, row) => sum + Number(row.expectedVideos ?? 0), 0));
  const title = cleanInlineText(matrix.title || "Auto Flow Agent Matrix");
  const isOmniMultiFrame = matrix.kind === "agent_omni_multiframe";
  const primaryReferenceLine = references.length
    ? `Use attached \`${reference.fileName}\` as \`${reference.handle}\` (${reference.role}).`
    : "No reference images are attached for this contract.";
  const referenceLines = references.length > 1
    ? [
        "Attached references:",
        ...references.map((item) => `- \`${item.handle}\` = \`${item.fileName}\` (${item.role})${item.sha256 ? ` sha256=${item.sha256}` : ""}`)
      ]
    : [];
  return [
    "AUTO FLOW AGENT CONTRACT",
    "",
    `Project: ${title}`,
    ...agentBatchPromptLines(matrix.batch),
    primaryReferenceLine,
    references.length && reference.sha256 ? `Reference sha256: ${reference.sha256}` : "",
    ...referenceLines,
    "",
    "Global settings:",
    `- Mode: ${isOmniMultiFrame ? "Omni multi-frame image-to-video" : "image-first frame-to-video"}`,
    `- Aspect ratio: ${settings.aspectRatio || "portrait"}`,
    `- Video length: ${settings.videoLength || "8"} seconds`,
    `- Preferred video model: ${settings.model || "Veo 3.1 Lite [Lower Priority]"}`,
    `- Expected final count: ${expectedImages} image${expectedImages === 1 ? "" : "s"} and ${expectedVideos} video${expectedVideos === 1 ? "" : "s"}`,
    ...agentSelfHealPromptLines({
      autonomy: matrix.autonomy || settings.autonomy,
      maxSelfHealRetries: matrix.selfHeal?.maxRetries ?? settings.maxSelfHealRetries,
      suppressOnScreenText: matrix.selfHeal?.suppressOnScreenText ?? settings.suppressOnScreenText
    }),
    ...agentVideoPreflightLines(expectedVideos),
    ...agentReferenceAttachmentPreflightLines(references.length > 0),
    "- Do not create hidden stacks or extra variations beyond the requested counts.",
    references.length > 1 ? "- Use attached references strictly by their handles; do not swap identity, product, style, or frame references." : "",
    isOmniMultiFrame
      ? "- For each clip, generate every listed angle-frame still first, then use those exact generated stills as the multi-image/timed inputs for that clip's Omni video."
      : "- Generate each still first, then use that exact generated still as the start frame for its video row.",
    isOmniMultiFrame ? "- Do not create one video per frame; each clip gets one final video unless repeat count asks for more." : "",
    "",
    "Rows:",
    ...rows.flatMap((row) => [
      "",
      `## Clip ${row.clipNumber}: ${row.title}`,
      row.agentPrompt
    ])
  ].filter((line) => line !== "").join("\n");
}

function buildAgentBulkVideoEditPromptText(matrix = {}) {
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  const references = normalizeReferenceList(matrix.references || []);
  const batch = matrix.batch || {};
  const attachmentHandles = uniqueReferences(rows.flatMap((row) => row.references || []));
  return [
    "AUTO FLOW AGENT CONTRACT — BULK VIDEO EDIT — EXECUTE NOW",
    ...agentBatchPromptLines(batch),
    `Edit exactly ${rows.length} source video${rows.length === 1 ? "" : "s"} with Omni Flash and return exactly ${rows.length} edited video output${rows.length === 1 ? "" : "s"}.`,
    `Attachment contract: ${attachmentHandles.length}/${MAX_AGENT_REFERENCES_PER_BATCH} slots used. Every listed source video must produce one separately identifiable edited output.`,
    "Do not return a plan. Do not skip a source. Do not combine source videos. Do not modify or count the uploaded source assets as outputs.",
    "Preserve source motion, timing, framing, and audio unless the row instruction explicitly asks for a change.",
    "Keep every bracketed row ID in generation metadata only. Never render row IDs, captions, labels, logos, or watermarks.",
    "If a questionnaire appears, use the exact frozen contract in this message: Omni Flash, one edited output per source, and the source's original duration/aspect. Do not choose an option that changes those constraints.",
    references.length ? "Persistent visual references used for every source in this message:" : "No persistent visual references are attached.",
    ...references.map((reference) => `- ${reference.handle} = ${reference.fileName} (${reference.role})`),
    "",
    "Exact source-to-output map:",
    ...rows.map((row) => `- ${row.tag || `[${row.rowId}]`} ${row.sourceVideoHandle} (${row.sourceVideoFileName}): ${row.prompt}`)
  ].filter((line) => line !== "").join("\n");
}

function buildAgentBulkVideoEditRowPrompt({ rowId = "", sourceReference = {}, persistentReferences = [], prompt = "" } = {}) {
  const persistent = normalizeReferenceList(persistentReferences);
  return [
    `Edit ${sourceReference.handle} (${sourceReference.fileName}) exactly once as [${rowId}] using Omni Flash video-to-video editing.`,
    persistent.length ? `Use ${persistent.map((reference) => reference.handle).join(", ")} as persistent visual instruction${persistent.length === 1 ? "" : "s"}.` : "",
    `Edit instruction: ${cleanBlockText(prompt)}`,
    "Return one new edited video. Do not return the uploaded source video as the result and do not edit another row's source."
  ].filter(Boolean).join(" ");
}

function buildAgentOneToOneBatchPromptText(matrix = {}) {
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  const references = normalizeReferenceList(matrix.references || []);
  const settings = matrix.settings || {};
  const batch = matrix.batch || {};
  const maxRetries = Math.max(0, Number(matrix.selfHeal?.maxRetries ?? settings.maxSelfHealRetries ?? 2) || 0);
  const referenceForRow = (row, index) => {
    const expectedRole = `row ${Number(row?.rowIndex || 0)} start frame`;
    return references.find((reference) => String(reference.role || "").trim().toLowerCase() === expectedRole)
      || references[index]
      || {};
  };
  return [
    "AUTO FLOW AGENT CONTRACT — EXECUTE NOW",
    ...agentBatchPromptLines(batch),
    `Mode: Frame-to-Video. Generate exactly ${rows.length} videos and no other outputs.`,
    "Reference strategy: one_to_one_batch.",
    `Settings for every row: ${settings.aspectRatio || "portrait"}, ${settings.videoLength || "8"} seconds, ${settings.model || defaultAgentModelForMode("image-to-video")}, silent.`,
    "- Return silent videos: use the setting confirmed before submit; do not pause to re-check UI settings.",
    "- Attach every reference required by this strategy through Flow Agent's plus/Add to Prompt control before generation. Prompt asset chips must be visible before using those refs.",
    matrix.referenceStrategy?.description ? `- ${matrix.referenceStrategy.description}` : "",
    "The attached prompt-media chips are ordered row-specific start frames. Bind each listed handle/file only to its matching row's start-frame slot. Never reuse, swap, or treat a frame as a generic ingredient.",
    ...references.map((reference) => `- \`${reference.handle}\` = \`${reference.fileName}\` (${reference.role})`),
    "Generate immediately; do not return a plan, summary, prompt rewrite, still image, hidden stack, alternate, or unrelated output.",
    `If one row is safely repairable after a policy or unbilled generation failure, minimally repair and retry only that row up to ${maxRetries} times. Never retry completed rows.`,
    "Preserve each bracketed row ID in generation metadata for reconciliation, but never render IDs, labels, captions, logos, watermarks, or other text in the video.",
    "",
    "Exact row-to-frame bindings:",
    ...rows.map((row, index) => {
      const reference = referenceForRow(row, index);
      return `- ${row.tag || `[${row.rowId || `ROW-${row.rowIndex || index + 1}`}]`} <= ${reference.handle || `@row_${String(row.rowIndex || index + 1).padStart(3, "0")}_start_frame`} (${reference.fileName || `row-${row.rowIndex || index + 1} frame`}): ${row.prompt}`;
    })
  ].filter((line) => line !== "").join("\n");
}

function buildAgentGenericPromptText(matrix = {}) {
  const rows = Array.isArray(matrix.rows) ? matrix.rows : [];
  const settings = matrix.settings || {};
  const references = normalizeReferenceList(matrix.references || []);
  const referenceStrategy = normalizeReferenceStrategy(matrix.referenceStrategy || {}, matrix.mode);
  const expectedImages = Number(matrix.expectedImages ?? rows.reduce((sum, row) => sum + Number(row.expectedImages ?? 0), 0));
  const expectedVideos = Number(matrix.expectedVideos ?? rows.reduce((sum, row) => sum + Number(row.expectedVideos ?? 0), 0));
  return [
    "AUTO FLOW AGENT CONTRACT",
    "",
    "Project: Auto Flow Agent Run",
    ...agentBatchPromptLines(matrix.batch),
    "",
    "Global settings:",
    `- Mode: ${agentModeLabel(matrix.mode)}`,
    `- Aspect ratio: ${settings.aspectRatio || "portrait"}`,
    matrix.mode === "text-to-image" ? "" : `- Video length: ${settings.videoLength || "8"} seconds`,
    `- Preferred model: ${settings.model || defaultAgentModelForMode(matrix.mode)}`,
    `- Expected final count: ${expectedImages} image${expectedImages === 1 ? "" : "s"} and ${expectedVideos} video${expectedVideos === 1 ? "" : "s"}`,
    ...agentSelfHealPromptLines({
      autonomy: matrix.autonomy || settings.autonomy,
      maxSelfHealRetries: matrix.selfHeal?.maxRetries ?? settings.maxSelfHealRetries,
      suppressOnScreenText: matrix.selfHeal?.suppressOnScreenText ?? settings.suppressOnScreenText
    }),
    ...agentVideoPreflightLines(expectedVideos),
    `- Reference strategy: ${referenceStrategy.kind}`,
    referenceStrategy.description ? `- ${referenceStrategy.description}` : "",
    ...agentReferenceStrategyPreflightLines(referenceStrategy, references),
    ...agentReferenceRoleBindingLines(matrix.mode, references),
    "- Do not create hidden stacks, extra variations, or unrelated outputs beyond the requested counts.",
    ...(references.length ? [
      "Attached references:",
      ...references.map((reference) => `- \`${reference.handle}\` = \`${reference.fileName}\` (${reference.role})`)
    ] : []),
    "",
    "Rows:",
    ...rows.flatMap((row) => [
      "",
      `## Row ${row.rowIndex}: ${row.tag || agentModeLabel(row.mode)}`,
      row.agentPrompt
    ])
  ].filter((line) => line !== "").join("\n");
}

function agentBatchPromptLines(batch = {}) {
  const totalBatches = Math.max(0, Number(batch?.totalBatches || 0));
  if (totalBatches <= 1) return [];
  return [
    `Batch: ${batch.batchId || `BATCH-${String(batch.batchIndex || 1).padStart(3, "0")}`} (${batch.batchIndex || 1} of ${totalBatches})`,
    `Global row range: ${batch.rowStart || 1}-${batch.rowEnd || batch.rowCount || 0} of ${batch.totalRows || batch.rowEnd || batch.rowCount || 0}`,
    "Process only the rows in this batch. Preserve their global row IDs; do not renumber them within the batch."
  ];
}

function agentVideoPreflightLines(expectedVideos = 0) {
  if (Number(expectedVideos || 0) <= 0) return [];
  return ["- Return silent videos: use the setting confirmed before submit; do not pause to re-check UI settings."];
}

function agentReferenceAttachmentPreflightLines(hasReferences = false) {
  if (!hasReferences) return [];
  return ["- Reference preflight: each named reference must be attached in this Agent prompt through the plus/Add to Prompt control; typed handles, filenames, or media ids alone do not count."];
}

function agentReferenceStrategyPreflightLines(referenceStrategy = {}, references = []) {
  const kind = String(referenceStrategy?.kind || "").trim().toLowerCase();
  if (kind === "none" && !references.length) return [];
  return ["- Attach every reference required by this strategy through Flow Agent's plus/Add to Prompt control before generation. Prompt asset chips must be visible before using those refs."];
}

function agentReferenceRoleBindingLines(mode = "", references = [], rowIndex = 0) {
  const normalizedMode = normalizeAgentMode(mode);
  const normalizedReferences = normalizeReferenceList(references);
  if (normalizedMode === "image-to-video") {
    const rowStartRole = rowIndex > 0 ? `row ${rowIndex} start frame` : "";
    const rowStart = rowStartRole ? normalizedReferences.find((entry) => entry.role.toLowerCase() === rowStartRole) : null;
    if (rowStart) {
      return [`- Bind ${rowStart.handle} (${rowStart.fileName}) to global row ${rowIndex}'s start-frame slot only. Never use another row's frame.`];
    }
    const start = normalizedReferences.find((entry) => entry.role.toLowerCase() === "start frame");
    const end = normalizedReferences.find((entry) => entry.role.toLowerCase() === "end frame");
    if (start && end) {
      return [`- Bind ${start.handle} (${start.fileName}) to the start-frame slot and ${end.handle} (${end.fileName}) to the end-frame slot. Never swap them, reorder them, or use either as a generic ingredient.`];
    }
    if (start) return [`- Bind ${start.handle} (${start.fileName}) to the start-frame slot only.`];
    const orderedStarts = normalizedReferences.filter((entry) => /^row \d+ start frame$/i.test(entry.role));
    if (orderedStarts.length) {
      return orderedStarts.map((entry) => `- ${entry.role}: bind ${entry.handle} (${entry.fileName}) to that row's start-frame slot only.`);
    }
  }
  if (normalizedMode === "ingredients-to-video") {
    return normalizedReferences.map((entry, index) => `- Ingredient slot ${index + 1}: ${entry.handle} (${entry.fileName}); preserve this exact order and role.`);
  }
  return [];
}

function agentRowReferenceChipLine(hasReferences = false) {
  if (!hasReferences) return "";
  return "Prompt asset chips are required; typed reference names or media ids alone are not enough.";
}

function agentRowReferenceSourceLines(references = [], reference = {}) {
  if (!references.length) {
    return ["No external reference image is required; create the still image from the image prompt alone."];
  }
  return [
    `Use \`${reference.handle}\` from attached \`${reference.fileName}\` as the identity/reference source.`,
    agentRowReferenceChipLine(true)
  ];
}

function agentOmniReferenceSourceLines(references = [], reference = {}) {
  if (!references.length) {
    return ["No external reference image is required; create every angle-frame still from the frame prompts alone."];
  }
  return [
    `Use \`${reference.handle}\` from attached \`${reference.fileName}\` as the exact identity/reference source for every frame.`,
    agentRowReferenceChipLine(true)
  ];
}

function buildAgentRowPrompt(row = {}, matrix = {}) {
  const settings = matrix.settings || {};
  const references = normalizeReferences({ references: row.references || matrix.references || [], reference: row.reference || matrix.reference || {} });
  const reference = references[0] || normalizeReference(row.reference || matrix.reference || {});
  const expectedVideos = Number(row.expectedVideos ?? matrix.repeatCount ?? 1);
  const rowTag = row.tag || row.finalVideoId || (row.rowId ? `[${row.rowId}]` : `Clip ${row.clipNumber}`);
  const imageAfid = `AFID:${normalizeRowId(row.rowId || `CLIP-${String(row.clipNumber || 1).padStart(2, "0")}`)}-IMG1`;
  return [
    `Generate exactly 1 still image for ${rowTag} / Clip ${row.clipNumber}.`,
    `Image tracking marker: ${imageAfid}. Preserve it in prompt metadata only; do not render this marker, labels, captions, or text in the image.`,
    ...agentRowReferenceSourceLines(references, reference),
    references.length > 1 ? `Also use these attached references exactly when named: ${referenceSummary(references.slice(1))}.` : "",
    `Image prompt: ${row.imagePrompt}`,
    "",
    `After the still image for ${rowTag} is complete, use that exact generated still as the start frame and generate exactly ${expectedVideos} frame-to-video ${expectedVideos === 1 ? "output" : "outputs"} for ${rowTag}.`,
    `Video settings: ${settings.aspectRatio || "portrait"} aspect ratio, ${settings.videoLength || "8"} seconds, ${settings.model || "Veo 3.1 Lite [Lower Priority]"}.`,
    `Veo prompt: ${row.videoPrompt}`,
    `Preserve ${rowTag} in video prompt metadata. Do not render ${rowTag}, AFID, labels, captions, or text in the video.`,
    "",
    references.length
      ? "Do not create hidden stacks, extra stills, or unrelated alternate subjects. Keep the same character identity and wardrobe continuity from the reference."
      : "Do not create hidden stacks, extra stills, or unrelated alternate subjects. Keep visual continuity from the generated still into the final video."
  ].filter((line) => line !== "").join("\n");
}

function extractTitle(text = "") {
  const match = String(text || "").match(/^#\s+(.+?)\s*$/m);
  return cleanInlineText(match?.[1] || "Auto Flow Agent Matrix");
}

function buildAgentOmniRowPrompt(row = {}, matrix = {}) {
  const settings = matrix.settings || {};
  const references = normalizeReferences({ references: row.references || matrix.references || [], reference: row.reference || matrix.reference || {} });
  const reference = references[0] || normalizeReference(row.reference || matrix.reference || {});
  const expectedVideos = Number(row.expectedVideos ?? matrix.repeatCount ?? 1);
  const frames = Array.isArray(row.frames) ? row.frames : [];
  const rowTag = row.tag || row.finalVideoId || (row.rowId ? `[${row.rowId}]` : `Clip ${row.clipNumber}`);
  return [
    `Generate exactly ${frames.length} angle-frame still images for ${rowTag} / Clip ${row.clipNumber}.`,
    ...agentOmniReferenceSourceLines(references, reference),
    references.length > 1 ? `Use all attached references exactly when their handles are named in frame/video prompts: ${referenceSummary(references)}.` : "",
    "Create the angle-frame stills in this order and label them exactly as listed for this clip:",
    ...frames.map((frame, index) => `- AFID:${normalizeRowId(row.rowId || `CLIP-${String(row.clipNumber || 1).padStart(2, "0")}`)}-IMG${index + 1} ${frame.handle} [${frame.timeWindow}] ${frame.title ? `${frame.title}: ` : ""}${frame.prompt}`),
    "",
    `After all ${frames.length} angle-frame stills for ${rowTag} are complete, use those exact generated stills as the multi-image/timed inputs and generate exactly ${expectedVideos} Omni video ${expectedVideos === 1 ? "output" : "outputs"} for ${rowTag}.`,
    `Video settings: ${settings.aspectRatio || "portrait"} aspect ratio, ${settings.videoLength || "8-10"} seconds, ${settings.model || "Omni"}.`,
    `Omni video prompt: ${row.videoPrompt}`,
    `Preserve ${rowTag} in video prompt metadata. Do not render ${rowTag}, AFID, labels, captions, or text in the video.`,
    "",
    references.length
      ? "Do not create one video per frame. Do not create hidden stacks, extra stills, unrelated alternate subjects, captions, or watermarks. Keep the same character identity, wardrobe continuity, and voice continuity across every frame and the final video."
      : "Do not create one video per frame. Do not create hidden stacks, extra stills, unrelated alternate subjects, captions, or watermarks. Keep visual and motion continuity across every generated frame and the final video."
  ].filter((line) => line !== "").join("\n");
}

function buildAgentGenericRowPrompt(row = {}, matrix = {}) {
  const settings = matrix.settings || {};
  const referenceStrategy = normalizeReferenceStrategy(row.referenceStrategy || matrix.referenceStrategy || {}, row.mode);
  const expectedPrimary = String(row.mode || "") === "text-to-image" ? row.expectedImages : row.expectedVideos;
  const expectedFallback = String(row.mode || "") === "text-to-image" ? row.expectedVideos : row.expectedImages;
  const count = Math.max(1, Number(expectedPrimary ?? expectedFallback ?? matrix.repeatCount ?? 1) || 1);
  const outputType = agentOutputTypeLabel(row.mode);
  const rowLabel = row.tag || `Row ${row.rowIndex}`;
  const lines = [
    `Generate exactly ${count} ${outputType} output${count === 1 ? "" : "s"} for ${rowLabel}.`,
    `Prompt: ${row.prompt}`,
    "",
    `Settings: ${settings.aspectRatio || "portrait"} aspect ratio${row.mode === "text-to-image" ? "" : `, ${settings.videoLength || "8"} seconds`}, ${settings.model || defaultAgentModelForMode(row.mode)}.`,
    referenceStrategy.kind !== "none" ? "Use the reference strategy exactly." : "",
    referenceStrategy.kind !== "none" ? agentRowReferenceChipLine(true) : "",
    referenceStrategy.description ? `Reference strategy details: ${referenceStrategy.description}` : "",
    ...agentReferenceRoleBindingLines(row.mode, row.references || matrix.references || [], row.rowIndex),
    row.mode === "ingredients-to-video" ? "Use the attached images only as ordered Flow ingredients and preserve every declared subject/object/style role." : "",
    "",
    "Do not create hidden stacks or extra alternates. Keep each output tied to this row."
  ];
  return lines.filter((line) => line !== "").join("\n");
}

function extractFrameBlocks(body = "") {
  const text = normalizeNewlines(body);
  const frameHeadingRe = /^\s*\*\*\s*(@img\d+)\s*(?:\[([^\]]+)\])?\s*(?:[-:\u2013\u2014]\s*(.*?))?\s*\*\*\s*$/gim;
  const matches = [...text.matchAll(frameHeadingRe)];
  return matches.map((match, index) => {
    const start = match.index + match[0].length;
    const nextFrameIndex = matches[index + 1]?.index ?? Number.POSITIVE_INFINITY;
    const nextPromptIndex = findNextPromptHeadingIndex(text, start);
    const end = Math.min(nextFrameIndex, nextPromptIndex);
    const continuationPrompt = cleanBlockText(text.slice(start, Number.isFinite(end) ? end : text.length));
    return {
      handle: match[1],
      timeWindow: normalizeTimeWindow(match[2] || ""),
      title: cleanInlineText(match[3] || ""),
      prompt: continuationPrompt
    };
  }).filter((frame) => frame.handle && frame.prompt);
}

function extractLabeledBlock(body = "", labels = []) {
  const normalizedLabels = labels.map(labelPattern).join("|");
  const re = new RegExp(
    `^\\s*\\*\\*\\s*(${normalizedLabels})\\s*\\*\\*\\s*$`,
    "im"
  );
  const text = normalizeNewlines(body);
  const match = text.match(re);
  if (!match) return { label: "", text: "" };
  const start = match.index + match[0].length;
  const end = findNextPromptHeadingIndex(text, start);
  return {
    label: cleanInlineText(match[1]),
    text: cleanBlockText(text.slice(start, Number.isFinite(end) ? end : text.length))
  };
}

function normalizeReference(reference = {}) {
  const handle = String(reference.handle || "@image1").trim() || "@image1";
  return {
    handle: isStructuredReferenceHandle(handle) ? handle : `@${handle}`,
    fileName: cleanInlineText(reference.fileName || reference.name || "reference-image.jpg"),
    role: cleanInlineText(reference.role || "reference image"),
    sha256: cleanInlineText(reference.sha256 || reference.hash || "")
  };
}

function hasReferenceInput(reference = {}) {
  if (!reference || typeof reference !== "object") return false;
  return Object.keys(reference).some((key) => String(reference[key] || "").trim());
}

function normalizeReferenceList(references = []) {
  const list = Array.isArray(references) ? references : [];
  return list.map((reference, index) => normalizeReference({
    handle: reference?.handle || `@image${index + 1}`,
    fileName: reference?.fileName || reference?.name || `reference-${index + 1}.jpg`,
    role: reference?.role || `reference ${index + 1}`,
    sha256: reference?.sha256 || reference?.hash || ""
  }));
}

function normalizeReferences({ references = [], reference = {} } = {}) {
  const normalizedReferences = normalizeReferenceList(references);
  if (normalizedReferences.length) return normalizedReferences;
  if (reference && Object.keys(reference).length) return [normalizeReference(reference)];
  return [];
}

function referenceIdentity(reference = {}) {
  const normalized = normalizeReference(reference);
  return normalized.sha256
    ? `sha256:${normalized.sha256.toLowerCase()}`
    : normalized.handle
      ? `handle:${normalized.handle.toLowerCase()}`
      : `file:${normalized.fileName.toLowerCase()}`;
}

function uniqueReferenceKeys(references = []) {
  return [...new Set(normalizeReferenceList(references).map(referenceIdentity))];
}

function uniqueReferences(references = []) {
  const seen = new Set();
  const output = [];
  for (const reference of normalizeReferenceList(references)) {
    const key = referenceIdentity(reference);
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(reference);
  }
  return output;
}

function referenceSummary(references = []) {
  return normalizeReferenceList(references)
    .map((reference) => `\`${reference.handle}\`=${reference.fileName} (${reference.role})`)
    .join("; ");
}

function normalizeReferenceStrategy(strategy = {}, mode = "") {
  if (typeof strategy === "string") {
    return {
      kind: cleanInlineText(strategy) || defaultReferenceStrategyForMode(mode),
      description: ""
    };
  }
  return {
    kind: cleanInlineText(strategy.kind || defaultReferenceStrategyForMode(mode)),
    description: cleanInlineText(strategy.description || "")
  };
}

function defaultReferenceStrategyForMode(mode = "") {
  const normalized = normalizeAgentMode(mode);
  if (normalized === "image-to-video") return "repeat_first_or_row_match";
  if (normalized === "ingredients-to-video") return "ingredients_all";
  return "none";
}

function normalizePromptLines(prompts = []) {
  const list = Array.isArray(prompts) ? prompts : String(prompts || "").split(/\n+/);
  return list.map((prompt) => cleanBlockText(prompt)).filter(Boolean);
}

function genericRowIdentity(prompt = "", index = 0) {
  const fallbackId = `row-${String(index + 1).padStart(2, "0")}`;
  const tag = extractLeadingGenericTag(prompt);
  if (!tag) {
    return {
      id: fallbackId,
      rowId: fallbackId,
      tag: "",
      finalVideoId: `[ROW-${String(index + 1).padStart(2, "0")}]`,
      title: `Row ${index + 1}`
    };
  }
  const rowId = tag.slice(1, -1);
  return {
    id: rowId,
    rowId,
    tag,
    finalVideoId: tag,
    title: tag
  };
}

function extractLeadingGenericTag(prompt = "") {
  const match = String(prompt || "").match(/^\s*\[\s*([A-Za-z][A-Za-z0-9_-]*\d[A-Za-z0-9_-]*)\s*\]/);
  if (!match) return "";
  return `[${normalizeGenericRowId(match[1])}]`;
}

function normalizeGenericRowId(value = "") {
  return cleanInlineText(value).replace(/[^A-Za-z0-9_-]/g, "").toUpperCase();
}

function normalizeAgentMode(mode = "") {
  const raw = String(mode || "").trim();
  if (raw === "create-image" || raw === "image" || raw === "text-to-image") return "text-to-image";
  if (raw === "text-to-video" || raw === "t2v") return "text-to-video";
  if (raw === "frame-to-video" || raw === "image-to-video" || raw === "i2v") return "image-to-video";
  if (raw === "ingredients" || raw === "ingredients-to-video" || raw === "r2v") return "ingredients-to-video";
  if (raw === "video-to-video" || raw === "v2v" || raw === "video-edit") return "video-to-video";
  return "text-to-image";
}

function agentModeLabel(mode = "") {
  const normalized = normalizeAgentMode(mode);
  if (normalized === "text-to-image") return "Create Image";
  if (normalized === "text-to-video") return "Text-to-Video";
  if (normalized === "image-to-video") return "Frame-to-Video";
  if (normalized === "ingredients-to-video") return "Ingredients-to-Video";
  if (normalized === "video-to-video") return "Omni Video Edit";
  return "Agent";
}

function agentOutputTypeLabel(mode = "") {
  const normalized = normalizeAgentMode(mode);
  if (normalized === "text-to-image") return "image";
  if (normalized === "text-to-video") return "text-to-video";
  if (normalized === "image-to-video") return "frame-to-video";
  if (normalized === "ingredients-to-video") return "ingredients-to-video";
  if (normalized === "video-to-video") return "video-to-video";
  return "video";
}

function defaultAgentModelForMode(mode = "") {
  const normalized = normalizeAgentMode(mode);
  if (normalized === "text-to-image") return "Nano Banana Pro";
  if (normalized === "ingredients-to-video") return "Veo 3.1 Lite [Lower Priority]";
  if (normalized === "video-to-video") return "Omni Flash";
  return "Veo 3.1 Lite [Lower Priority]";
}

function findNextPromptHeadingIndex(text = "", start = 0) {
  const rest = text.slice(start);
  const stopRe = /^\s*\*\*\s*(?:@img\d+\s*(?:\[[^\]]+\])?\s*(?:[-:\u2013\u2014].*?)?|Image prompt|Veo 3 prompt|Video prompt|VIDEO(?:\s*\([^)]*\))?|Audio|Notes?)\s*\*\*/gim;
  const match = stopRe.exec(rest);
  return match ? start + match.index : Number.POSITIVE_INFINITY;
}

function normalizeRowsRequested(rows, available, fallback) {
  const availableRows = Math.max(0, Number.parseInt(available, 10) || 0);
  if (String(rows || "").toLowerCase() === "all") return availableRows;
  const requestedRows = Number.parseInt(rows, 10);
  const fallbackRows = Math.max(0, Number.parseInt(fallback, 10) || 0);
  if (!Number.isFinite(requestedRows)) return Math.min(availableRows, fallbackRows);
  return Math.min(availableRows, Math.max(1, requestedRows));
}

function normalizeTimeWindow(value = "") {
  return cleanInlineText(value)
    .replace(/[\u2012\u2013\u2014\u2212]/g, "-")
    .replace(/\s*-\s*/g, "-");
}

function isStructuredReferenceHandle(handle = "") {
  return handle.startsWith("@") || /^<<<[^>]+>>>$/.test(handle);
}

function labelPattern(label = "") {
  if (String(label).toUpperCase() === "VIDEO") return "VIDEO(?:\\s*\\([^)]*\\))?";
  if (String(label).toUpperCase() === "VIDEO (OMNI)") return "VIDEO\\s*\\(\\s*Omni\\s*\\)";
  return escapeRegExp(label);
}

function normalizeNewlines(value = "") {
  return String(value || "").replace(/\r\n?/g, "\n");
}

function cleanInlineText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function cleanBlockText(value = "") {
  return normalizeNewlines(value)
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => !/^-{3,}$/.test(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function normalizeRowId(value = "") {
  return cleanInlineText(value)
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "") || "ROW-01";
}

function clampInt(value, min, max, fallback) {
  const next = Number.parseInt(value, 10);
  if (!Number.isFinite(next)) return fallback;
  return Math.max(min, Math.min(max, next));
}

function escapeRegExp(value = "") {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
