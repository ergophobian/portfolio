import { extractAgentVideoTag } from "./agent-project-metadata.js";
import { isFreeCreditText, extractCreditAmount } from "./agent-credit-text.js";

const THIRD_PARTY_RE = /third[-\s]?party|content provider|copyright|rightsholder|trademark|licensed character/i;
const POLICY_RE = /can't generate|cannot generate|failed|policy|safety|prohibited|blocked|please edit your prompt|try again/i;
const DEMAND_RE = /high demand|currently in the queue|check back|queued/i;
const FLOW_AUTH_REQUIRED_RE = /\b(?:sign|log)[-\s]?in\b|\bsigned out\b|\bsession expired\b|\bchoose an account\b|\baccount picker\b|\bcontinue with google\b|\buse another account\b|\bverify it['’]?s you\b|\bauthentication required\b/i;
const FLOW_QUOTA_EXHAUSTED_RE = /resource[_\s-]*exhausted|error code\s*253|daily limit reached|quota (?:has been )?(?:reached|exceeded)|number of requests sent exceeds the quota limit|account quota|model quota/i;
const FLOW_CREDITS_EXHAUSTED_RE = /not enough credits|insufficient credits|credits? exhausted|out of credits|buy more credits|purchase credits|upgrade(?: your)? plan|billing plan/i;
const FLOW_RATE_LIMIT_RE = /PUBLIC_ERROR_(?:USER_)?REQUESTS?_THROTTLED|requests?_throttled|too many requests|heavy load|throttl(?:e|ed|ing)|\b429\b|\brate[-\s]?limit(?:ed|ing)?\b|\btry again later\b|\bslow down\b/i;
const UNBILLED_FAILED_GENERATION_RE = /failed.*(?:taking longer than expected|check again in a moment|will not be charged|failed generations)|(?:will not be charged).*failed/i;
const FLOW_CONTRACT_RE = /AUTO FLOW AGENT CONTRACT|AFID TRACKING CONTRACT|Expected manifest:|Preserve AFID in generation prompt metadata/i;
const ACTUAL_AGENT_FAILURE_RE = /^(?:failed\b|resource[_\s-]*exhausted\b|user quota reached\b|daily limit reached\b|PUBLIC_ERROR_[A-Z0-9_]+|STATUS:FAILED\b|(?:(?:model|account) )?quota (?:has been )?(?:reached|exceeded)\b|too many requests\b|rate[-\s]?limited\b|not enough credits\b|insufficient credits\b|out of credits\b|i can't generate|i cannot generate|cannot generate|please edit your prompt|you will not be charged)|\b(?:PUBLIC_ERROR_[A-Z0-9_]+|STATUS:FAILED\b|i can't generate|i cannot generate|cannot generate|please edit your prompt|you will not be charged|(?:generation|request|tool call) (?:has |just )?failed)\b/i;
const MODEL_DURATION_CHOICE_RE = /(?:maximum|max|limited|limit|supports?).{0,120}8[-\s]*(?:seconds?|s)\b|(?:10[-\s]?second|10\s*s).{0,120}(?:veo|lite).{0,120}(?:8[-\s]*(?:seconds?|s)|omni flash|shorten)/i;
const CREDIT_CONFIRMATION_RE = /(?:credit|credits|cost|costing|will use|spend).{0,160}(?:\byes\b|\bapprove\b|\bconfirm\b|\bcontinue\b|\buse credits\b|\bdon['’]?t ask\b|\bdont ask\b|\bask again\b|\bcancel\b|\breject\b)|(?:\byes\b|\bapprove\b),?\s+(?:and\s+)?don['’]?t\s+ask\s+again/i;
const CREDIT_CONFIRMATION_QUESTION_RE = /(?:would you like me to|should i|shall i|want me to).{0,120}(?:kick off|start|submit|generate|run|create).{0,160}(?:cost(?:ing)?|use|uses|using|spend|requires?|will use).{0,60}\b\d+\s*credits?\b/i;

export function classifyAgentScreenText(text = "") {
  const normalized = compactText(text);
  if (!normalized) {
    return {
      blocked: false,
      state: "unknown",
      failureClass: "",
      retryableWithPromptEdit: false,
      recommendedAction: ""
    };
  }

  if (isSubmittedAutoFlowContractText(normalized)) {
    return {
      blocked: false,
      state: "unknown",
      failureClass: "",
      category: "",
      retryableWithPromptEdit: false,
      recommendedAction: ""
    };
  }

  if (FLOW_AUTH_REQUIRED_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_flow_auth_required",
      category: "flow_auth",
      retryable: false,
      retryableWithPromptEdit: false,
      recommendedAction: "Surface the Google Flow sign-in or account-picker state to the user. Do not auto-click an account button or continue under an unverified Google identity."
    };
  }

  if (FLOW_QUOTA_EXHAUSTED_RE.test(normalized) && ACTUAL_AGENT_FAILURE_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_flow_quota_exhausted",
      category: "flow_quota",
      retryable: false,
      retryableWithPromptEdit: false,
      recommendedAction: "Stop the Agent batch and surface the Flow quota or RESOURCE_EXHAUSTED state. Do not retry or regenerate paid media until the quota state is cleared."
    };
  }

  if (FLOW_CREDITS_EXHAUSTED_RE.test(normalized) && ACTUAL_AGENT_FAILURE_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_flow_credits_exhausted",
      category: "flow_credits",
      retryable: false,
      retryableWithPromptEdit: false,
      recommendedAction: "Escalate to the user for billing or credit approval. Do not change plan, buy credits, or keep retrying automatically."
    };
  }

  if (FLOW_RATE_LIMIT_RE.test(normalized) && ACTUAL_AGENT_FAILURE_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_flow_rate_limited",
      category: "flow_rate_limit",
      retryable: false,
      retryableWithPromptEdit: false,
      recommendedAction: "Stop Agent retry pressure and surface the Flow rate-limit state. Resume only after the user confirms the Flow session is usable again."
    };
  }

  if (THIRD_PARTY_RE.test(normalized) && POLICY_RE.test(normalized) && ACTUAL_AGENT_FAILURE_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_third_party_content_block",
      category: "prompt_policy",
      retryableWithPromptEdit: true,
      recommendedAction: "Edit the row prompt to remove third-party, franchise, copyrighted, trademarked, or named provider references. Keep the same owned scene intent and retry the video row only."
    };
  }

  if (UNBILLED_FAILED_GENERATION_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_generation_failed_unbilled",
      category: "transient_generation_failure",
      retryable: true,
      retryableWithPromptEdit: false,
      retryStrategy: "retry_same_prompt",
      recommendedAction: "Retry the affected row only with the same prompt and attached inputs; the prior generation failed and was not charged."
    };
  }

  if (POLICY_RE.test(normalized) && ACTUAL_AGENT_FAILURE_RE.test(normalized)) {
    return {
      blocked: true,
      state: "blocked",
      failureClass: "agent_policy_prompt_block",
      category: "prompt_policy",
      retryableWithPromptEdit: true,
      recommendedAction: "Edit the row prompt to remove policy-sensitive wording while preserving the intended scene, then retry the affected row only."
    };
  }

  if (DEMAND_RE.test(normalized)) {
    return {
      blocked: false,
      state: "running",
      failureClass: "",
      category: "queue_wait",
      retryableWithPromptEdit: false,
      recommendedAction: "Do not retry yet. The Agent reports the video is still queued or running."
    };
  }

  return {
    blocked: false,
    state: "unknown",
    failureClass: "",
    category: "",
    retryableWithPromptEdit: false,
    recommendedAction: ""
  };
}

export function buildAgentScreenContext({ raw = {}, expectedManifest = {}, now = new Date().toISOString() } = {}) {
  const fallbackRowIds = expectedRowIds(expectedManifest);
  const bodyText = compactText(raw.bodyTextPreview || raw.bodyText || "");
  const latestMessages = normalizeAgentMessages(raw);
  const composer = normalizeAgentComposer(raw.composer);
  const generationActive = agentGenerationActive(raw);
  const uiState = detectAgentUiState(raw, latestMessages, { composer, expectedManifest });
  const dialogs = normalizeAgentDialogs(raw.dialogs);
  const actionRows = normalizeAgentActionRows(raw.actionRows);
  const choiceGroups = normalizeAgentChoiceGroups(raw.choiceGroups);
  const settings = normalizeAgentSettings(raw.settings);
  const credits = normalizeAgentCredits(raw.credits);
  const bodyBlocks = shouldClassifyBodyText(raw, bodyText) ? [{ id: "agent-screen-body", text: bodyText }] : [];
  const dialogBlocks = Array.isArray(raw.dialogs)
    ? raw.dialogs.map((dialog, index) => ({
        id: compactString(dialog?.id) || `agent-screen-dialog-${index + 1}`,
        text: dialog?.text || dialog?.label || dialog?.ariaLabel || dialog?.title || "",
        rect: dialog?.rect || null
      }))
    : [];
  const rawBlocks = Array.isArray(raw.blocks) ? raw.blocks : [];
  const blocks = dedupeAgentScreenBlocks([...bodyBlocks, ...dialogBlocks, ...rawBlocks]
    .map((block, index) => normalizeBlock(block, index, bodyText, fallbackRowIds))
    .filter((block) => block.classification.blocked || block.classification.state !== "unknown"));
  const blockers = blocks.filter((block) => block.classification.blocked).map(blockerSummary);
  const retryPrompts = blockers
    .filter((blocker) => blocker.rowId && (blocker.retryableWithPromptEdit || blocker.retryable))
    .map((blocker) => ({
      rowId: blocker.rowId,
      issue: blocker.failureClass,
      prompt: buildAgentRetryPrompt(blocker)
    }));

  return {
    ok: raw.ok !== false,
    source: "flow_agent_screen",
    checkedAt: now,
    state: blockers.length
      ? "blocked"
      : uiState.waitingOn
        ? "waiting_for_user"
        : generationActive || blocks.find((block) => block.classification.state === "running") ? "running" : "unknown",
    generationActive,
    blockers,
    retryPrompts,
    latestMessages,
    composer,
    dialogs,
    actionRows,
    choiceGroups,
    settings,
    credits,
    uiState: {
      ...uiState,
      openDialogs: dialogs,
      pendingButtons: actionRows
    },
    recommendedAction: uiState.recommendedAction || "",
    blocks,
    page: {
      href: compactString(raw.href),
      title: compactString(raw.title),
      projectId: compactString(raw.projectId),
      tabId: compactString(raw.tabId)
    }
  };
}

function normalizeAgentDialogs(dialogs = []) {
  if (!Array.isArray(dialogs)) return [];
  return dialogs
    .map((dialog, index) => {
      const text = compactText(dialog?.text || dialog?.label || dialog?.message || "");
      if (!text) return null;
      return {
        id: compactString(dialog?.id) || `agent-dialog-${index + 1}`,
        text,
        rect: dialog?.rect || null
      };
    })
    .filter(Boolean)
    .slice(0, 8);
}

function normalizeAgentActionRows(actionRows = []) {
  if (!Array.isArray(actionRows)) return [];
  return actionRows
    .map((row, index) => {
      const text = compactText(row?.text || row?.label || row?.ariaLabel || row?.title || "");
      if (!text) return null;
      return {
        id: compactString(row?.id) || `agent-action-row-${index + 1}`,
        text,
        role: compactString(row?.role || ""),
        persistent: row?.persistent === true,
        rect: row?.rect || null
      };
    })
    .filter(Boolean)
    .slice(0, 10);
}

function normalizeAgentChoiceGroups(groups = []) {
  if (!Array.isArray(groups)) return [];
  return groups
    .map((group, groupIndex) => {
      const choices = (Array.isArray(group?.choices) ? group.choices : [])
        .map((choice, choiceIndex) => {
          const label = compactText(choice?.label || choice?.text || "");
          if (!label) return null;
          return {
            id: compactString(choice?.id) || `agent-choice-${groupIndex + 1}-${choiceIndex + 1}`,
            label,
            selected: choice?.selected === true,
            rect: choice?.rect || null
          };
        })
        .filter(Boolean)
        .slice(0, 8);
      if (choices.length < 2) return null;
      return {
        id: compactString(group?.id) || `agent-choice-group-${groupIndex + 1}`,
        text: compactText(group?.text || ""),
        rect: group?.rect || null,
        choices
      };
    })
    .filter(Boolean)
    .slice(0, 4);
}

function normalizeAgentSettings(settings = {}) {
  if (!settings || typeof settings !== "object" || Array.isArray(settings)) {
    return {
      mode: "unknown",
      aspectRatio: "unknown",
      outputsPerPrompt: "unknown",
      selectedVideoDuration: "unknown",
      currentModelKeys: {},
      visible: {},
      panelOpen: "unknown",
      returnSilentVideos: "unknown"
    };
  }
  const store = settings.store && typeof settings.store === "object" ? settings.store : settings;
  const modelKeys = store.currentModelKeys && typeof store.currentModelKeys === "object" ? store.currentModelKeys : {};
  return {
    mode: compactString(settings.mode || store.mode || ""),
    aspectRatio: compactString(settings.aspectRatio || store.aspectRatio || ""),
    outputsPerPrompt: store.outputsPerPrompt ?? settings.outputsPerPrompt ?? "unknown",
    selectedVideoDuration: store.selectedVideoDuration ?? settings.selectedVideoDuration ?? "unknown",
    currentModelKeys: {
      imageModelKey: compactString(modelKeys.imageModelKey || settings.imageModelKey || ""),
      videoApi: compactString(modelKeys.videoApi || settings.videoApi || ""),
      videoModelKey: compactString(modelKeys.videoModelKey || settings.videoModelKey || "")
    },
    imageModelFamilyId: compactString(store.imageModelFamilyId || settings.imageModelFamilyId || ""),
    videoModelFamilyId: compactString(store.videoModelFamilyId || settings.videoModelFamilyId || ""),
    visible: settings.visible && typeof settings.visible === "object" ? settings.visible : {},
    panelOpen: settings.panelOpen === true || settings.panelOpen === false ? settings.panelOpen : "unknown",
    returnSilentVideos: settings.returnSilentVideos === true || settings.returnSilentVideos === false ? settings.returnSilentVideos : "unknown"
  };
}

function normalizeAgentCredits(credits = {}) {
  if (!credits || typeof credits !== "object" || Array.isArray(credits)) {
    return {
      balance: "unknown",
      source: "unknown"
    };
  }
  const balance = Number(credits.balance);
  return {
    balance: Number.isFinite(balance) ? balance : "unknown",
    source: compactString(credits.source || "") || "unknown"
  };
}

export function agentComposerSubmitReadiness(input = {}) {
  const composer = normalizeAgentComposer(input);
  const generationActive = input?.generationActive === true || input?.activeGeneration === true;
  const visible = composer.visible === true;
  const sendControlVisible = composer.sendControlVisible === true || Boolean(composer.sendControlRect);
  const sendEnabled = composer.sendEnabled === true;
  let reason = "";
  if (!visible) reason = "composer_not_visible";
  else if (!sendControlVisible) reason = "send_control_not_visible";
  else if (!sendEnabled) reason = "send_control_disabled";
  else if (generationActive) reason = "generation_active";
  return {
    ...composer,
    generationActive,
    sendControlVisible,
    readyForSubmit: visible && sendControlVisible && sendEnabled && !generationActive,
    reason
  };
}

export function summarizeAgentComposerProbeFrames(injections = [], options = {}) {
  const expectedProjectId = compactString(options.projectId || options.expectedProjectId || "");
  const frames = (Array.isArray(injections) ? injections : [])
    .map((entry) => ({
      frameId: Number(entry?.frameId || 0),
      ...(entry?.result && typeof entry.result === "object" ? entry.result : { error: "empty_composer_probe_frame" })
    }));
  const topFrame = frames.find((frame) => frame.frameId === 0) || frames[0] || null;
  const projectOk = !expectedProjectId || frames.some((frame) => frame.projectOk === true);
  const editRoute = frames.some((frame) => frame.editRoute === true);
  const framesWithReadiness = frames.map((frame) => ({
    ...frame,
    composerReadiness: agentComposerSubmitReadiness(frame.composer || {})
  }));
  const readyFrame = framesWithReadiness.find((frame) => frame.composerReadiness.readyForSubmit === true) || null;
  const visibleComposerFrame = framesWithReadiness.find((frame) => frame.composerReadiness.visible === true) || null;
  const addFrame = framesWithReadiness.find((frame) => frame.addButton) || null;
  const sampleFrame = readyFrame || addFrame || framesWithReadiness.find((frame) => Array.isArray(frame.sampleButtons) && frame.sampleButtons.length) || null;
  const composerFrame = readyFrame || visibleComposerFrame || null;
  return {
    // Root preflight proves composer existence. A blank draft may keep its
    // structural send control disabled until guarded insertion completes.
    ok: Boolean(projectOk && !editRoute && visibleComposerFrame),
    readyForSubmit: Boolean(projectOk && !editRoute && readyFrame),
    href: topFrame?.href || readyFrame?.href || "",
    projectOk,
    editRoute,
    composer: composerFrame?.composer || null,
    composerReadiness: composerFrame?.composerReadiness || agentComposerSubmitReadiness({}),
    addButton: readyFrame?.addButton || addFrame?.addButton || null,
    sampleButtons: Array.isArray(sampleFrame?.sampleButtons) ? sampleFrame.sampleButtons.slice(0, 3) : [],
    frames: framesWithReadiness.slice(0, 8).map((frame) => ({
      frameId: frame.frameId,
      href: frame.href || "",
      projectOk: frame.projectOk === true,
      editRoute: frame.editRoute === true,
      composer: frame.composer ? {
        visible: frame.composer.visible === true,
        sendEnabled: frame.composer.sendEnabled === true,
        sendControlVisible: frame.composer.sendControlVisible === true,
        sendControlRect: frame.composer.sendControlRect || null,
        sendControlDisabled: frame.composer.sendControlDisabled === true,
        sendControlAriaDisabled: compactString(frame.composer.sendControlAriaDisabled || ""),
        editorRect: frame.composer.editorRect || null,
        editorFingerprint: frame.composer.editorFingerprint || null,
        generationActive: frame.composer.generationActive === true,
        source: compactString(frame.composer.source || "")
      } : null,
      composerReadiness: frame.composerReadiness,
      hasAddButton: Boolean(frame.addButton),
      sampleButtonCount: Array.isArray(frame.sampleButtons) ? frame.sampleButtons.length : 0,
      error: compactString(frame.error || "")
    }))
  };
}

function detectAgentUiState(raw = {}, latestMessages = [], details = {}) {
  const dialogs = Array.isArray(raw.dialogs) ? raw.dialogs : [];
  const assetPicker = dialogs.find((dialog) => isAgentAssetPickerText(dialog?.text || ""));
  if (assetPicker) {
    return {
      assetPickerOpen: true,
      waitingOn: "asset_picker_selection",
      recommendedAction: "Click Add to Prompt if the selected media is correct, or close the asset picker before submitting the next Agent prompt.",
      dialog: {
        text: compactText(assetPicker.text).slice(0, 240),
        rect: assetPicker.rect || null
      }
    };
  }
  const creditAction = detectCreditConfirmationAction(raw, latestMessages);
  if (creditAction) {
    return {
      assetPickerOpen: false,
      waitingOn: "credit_confirmation",
      recommendedAction: creditAction.recommendedAction,
      actionRequired: creditAction,
      latestMessage: latestMessages.at(-1) || null
    };
  }
  const latest = latestMessages.at(-1);
  const structuredChoice = detectStructuredAgentChoice(raw.choiceGroups, latestMessages);
  if (structuredChoice) {
    return {
      assetPickerOpen: false,
      waitingOn: structuredChoice.kind,
      recommendedAction: structuredChoice.recommendedAction,
      actionRequired: structuredChoice,
      latestMessage: latest || null
    };
  }
  const latestAction = latest ? detectAgentActionRequired(latest.text) : null;
  const joinedAction = detectAgentActionRequired(latestMessages.map((message) => message.text).join("\n"));
  const actionRequired = latestAction || (joinedAction?.kind === "credit_confirmation" ? null : joinedAction);
  if (actionRequired) {
    return {
      assetPickerOpen: false,
      waitingOn: actionRequired.kind,
      recommendedAction: actionRequired.recommendedAction,
      actionRequired,
      latestMessage: latest
    };
  }
  const draftAction = detectDraftedFollowupAction(raw, details.composer || normalizeAgentComposer(raw.composer), details.expectedManifest || {});
  if (draftAction) {
    return {
      assetPickerOpen: false,
      waitingOn: "drafted_followup",
      recommendedAction: "Submit the existing Flow Agent composer draft exactly once, then continue waiting for the expected outputs.",
      actionRequired: draftAction,
      latestMessage: latest || null
    };
  }
  if (latest && isAgentWaitingMessage(latest.text)) {
    return {
      assetPickerOpen: false,
      waitingOn: "agent_message_response",
      recommendedAction: "Read latestMessages and answer the Flow Agent directly in the chat, then continue polling/reconcile instead of re-submitting the row.",
      latestMessage: latest
    };
  }
  return {
    assetPickerOpen: false,
    waitingOn: "",
    recommendedAction: ""
  };
}

function detectAgentActionRequired(text = "") {
  const value = compactText(text);
  if (!value) return null;
  if (isModelDurationChoiceMessage(value)) {
    return buildModelDurationChoiceAction(extractInlineRadioChoices(value));
  }
  if (isImageModelChoiceMessage(value)) {
    const choices = [
      /nano banana 2(?!\s+lite)(?:\s*\(default\))?/i.test(value) ? "Nano Banana 2 (Default)" : "",
      /nano banana pro/i.test(value) ? "Nano Banana Pro" : "",
      /nano banana 2 lite/i.test(value) ? "Nano Banana 2 Lite" : ""
    ].filter(Boolean);
    return {
      kind: "image_model_choice",
      autoResolvable: false,
      recommendedResponse: choices[0] || "",
      recommendedAction: "Answer the Flow Agent's image model question before continuing. Do not re-submit the original row.",
      choices,
      defaultChoice: choices[0] || "requires_user_model_choice"
    };
  }
  if (isCreditConfirmationMessage(value)) {
    return buildCreditConfirmationAction(value);
  }
  return null;
}

function detectStructuredAgentChoice(groups = [], latestMessages = []) {
  const normalized = normalizeAgentChoiceGroups(groups);
  const group = normalized.at(-1);
  if (!group) return null;
  const contextText = compactText([
    ...latestMessages.slice(-4).map((message) => message?.text || ""),
    group.text,
    ...group.choices.map((choice) => choice.label)
  ].join(" "));
  const labels = group.choices.map((choice) => choice.label);
  if (isModelDurationChoiceMessage(contextText)) {
    return { ...buildModelDurationChoiceAction(labels), choiceGroupId: group.id, structuralEvidence: true };
  }
  if (isImageModelChoiceMessage(contextText)) {
    return {
      kind: "image_model_choice",
      autoResolvable: false,
      recommendedResponse: "",
      recommendedAction: "Review every offered model against the frozen run contract. Auto Flow will not choose a different model implicitly.",
      choices: labels,
      defaultChoice: "requires_exact_contract_choice",
      choiceGroupId: group.id,
      structuralEvidence: true
    };
  }
  return {
    kind: "agent_choice",
    autoResolvable: false,
    recommendedResponse: "",
    recommendedAction: "Review the offered choices against the frozen run contract. Auto Flow will not select a variable Agent option unless one is proven to preserve every immutable setting.",
    choices: labels,
    defaultChoice: "requires_exact_contract_choice",
    choiceGroupId: group.id,
    structuralEvidence: true
  };
}

function buildModelDurationChoiceAction(choices = []) {
  const labels = (Array.isArray(choices) ? choices : []).map(compactText).filter(Boolean);
  return {
    kind: "model_duration_choice",
    autoResolvable: false,
    recommendedResponse: "",
    recommendedAction: "Stop before generation and compare every offered model/duration combination with the frozen run contract. Do not silently trade model for duration or duration for model.",
    choices: labels.length ? labels : [
      "Switch model while preserving requested duration",
      "Keep model while changing duration"
    ],
    defaultChoice: "requires_exact_contract_choice"
  };
}

function extractInlineRadioChoices(text = "") {
  return compactText(text)
    .split(/radio_button_(?:un)?checked/i)
    .map(compactText)
    .filter((value, index) => index > 0 && value)
    .slice(0, 8);
}

function detectCreditConfirmationAction(raw = {}, latestMessages = []) {
  // Keep credit evidence scoped to one coherent surface. Joining the whole page,
  // generic composer action rows, and chat text can manufacture a false prompt:
  // a diagnostic message ending in "do not use credits" plus a reference-chip
  // `cancel` button previously matched the broad credit regex even though no
  // credit dialog existed.
  const dialogTexts = [];
  if (Array.isArray(raw.dialogs)) {
    for (const dialog of raw.dialogs) dialogTexts.push(dialog?.text);
  }
  dialogTexts.push(raw.creditDialogText);
  const dialogText = compactText(dialogTexts.filter(Boolean).join(" "));
  if (isCreditConfirmationMessage(dialogText)) return buildCreditConfirmationAction(dialogText, raw);

  const actionRows = Array.isArray(raw.actionRows) ? raw.actionRows : [];
  const actionText = compactText(actionRows
    .map((row) => row?.text || row?.label || row?.ariaLabel || row?.title || "")
    .filter(Boolean)
    .join(" "));
  if (isCreditConfirmationMessage(actionText) || hasStructuralCreditChoiceRows(actionRows)) {
    return {
      ...buildCreditConfirmationAction(actionText, raw),
      structuralEvidence: hasStructuralCreditChoiceRows(actionRows)
    };
  }

  const latest = Array.isArray(latestMessages) ? latestMessages.at(-1) : null;
  const latestText = compactText(latest?.text || "");
  if (!isCreditConfirmationMessage(latestText)) return null;
  return buildCreditConfirmationAction(latestText, raw);
}

function hasStructuralCreditChoiceRows(rows = []) {
  const labels = (Array.isArray(rows) ? rows : [])
    .map((row) => compactText(row?.text || row?.label || row?.ariaLabel || row?.title || ""))
    .filter(Boolean);
  const affirmativeChoices = labels.filter((label) => /(?:^|\s)check(?:\s|$)/i.test(label));
  const rejectingChoices = labels.filter((label) => /(?:^|\s)close(?:\s|$)/i.test(label));
  return affirmativeChoices.length >= 2 && rejectingChoices.length >= 1;
}

function isModelDurationChoiceMessage(text = "") {
  const value = compactText(text);
  const hasLiteEightAndOmniTenChoice = /(?:use|keep)?\s*veo\s*3\.1\s*-\s*lite.{0,40}8\s*(?:seconds?|s)/i.test(value)
    && /switch to omni flash.{0,40}10\s*(?:seconds?|s)/i.test(value);
  return (MODEL_DURATION_CHOICE_RE.test(value) || hasLiteEightAndOmniTenChoice)
    && /(veo|lite|omni flash|shorten|seconds?)/i.test(value)
    && /(how would you like to proceed|switch to|keep|shorten|radio_button|option|use veo)/i.test(value);
}

function isImageModelChoiceMessage(text = "") {
  const value = compactText(text);
  const namedChoices = [
    /nano banana 2(?:\s*\(default\))?/i,
    /nano banana pro/i,
    /nano banana 2 lite/i
  ].filter((pattern) => pattern.test(value)).length;
  return namedChoices >= 2
    && /(which|choose|select|would you like|use instead|available models?)/i.test(value)
    && /(not supported|default|radio_button|model)/i.test(value);
}

function isCreditConfirmationMessage(text = "") {
  const value = compactText(text);
  return (CREDIT_CONFIRMATION_RE.test(value) || CREDIT_CONFIRMATION_QUESTION_RE.test(value))
    && !/AUTO FLOW AGENT CONTRACT|AFID TRACKING CONTRACT/i.test(value);
}

function buildCreditConfirmationAction(text = "", raw = {}) {
  const creditAmount = extractCreditAmount(text);
  return {
    kind: "credit_confirmation",
    autoResolvable: false,
    creditAmount,
    creditAmountKnown: hasExplicitCreditAmount(text),
    freeTier: creditAmount === 0 && isFreeCreditText(text),
    currency: "credits",
    recommendedResponse: "Approve",
    recommendedAction: "Do not submit a new prompt. Only call agent.credits.confirm after explicit per-run user approval; choose the one-time approval unless persistent approval was explicitly requested.",
    choices: buildCreditChoices(text, raw.actionRows),
    defaultChoice: "requires_user_credit_approval"
  };
}

function buildCreditChoices(text = "", actionRows = []) {
  const labels = [];
  for (const row of Array.isArray(actionRows) ? actionRows : []) {
    const label = compactText(row?.label || row?.text || row?.ariaLabel || row?.title || "");
    if (label) labels.push(label);
  }
  const value = compactText(text);
  if (/approve/i.test(value)) labels.push("Approve");
  if (/(?:approve|yes|confirm).{0,60}(?:don['’]?t ask|dont ask|ask again)/i.test(value)) {
    labels.push("Approve and don't ask again");
  }
  if (/\byes\b/i.test(value)) labels.push("Yes");
  if (/\b(?:no|cancel|reject)\b/i.test(value)) labels.push("Cancel");

  const choices = [];
  const addChoice = (choice) => {
    if (!choice?.id || choices.some((entry) => entry.id === choice.id)) return;
    choices.push(choice);
  };
  for (const label of labels) {
    if (isPersistentCreditChoice(label)) {
      addChoice({ id: "approve_persistent", label: normalizeCreditChoiceLabel(label, "Approve and don't ask again"), persistent: true });
    } else if (isCancelCreditChoice(label)) {
      addChoice({ id: "cancel", label: normalizeCreditChoiceLabel(label, "Cancel"), persistent: false });
    } else if (isOneTimeCreditChoice(label)) {
      addChoice({ id: "approve_once", label: normalizeCreditChoiceLabel(label, "Approve"), persistent: false });
    }
  }
  addChoice({ id: "approve_once", label: "Approve", persistent: false });
  addChoice({ id: "approve_persistent", label: "Approve and don't ask again", persistent: true });
  addChoice({ id: "cancel", label: "Cancel", persistent: false });
  return choices.slice(0, 3);
}

function normalizeCreditChoiceLabel(label = "", fallback = "") {
  const value = compactText(label);
  if (/^yes$/i.test(value)) return fallback || "Approve";
  if (/^no$/i.test(value)) return "Cancel";
  return value || fallback;
}

function hasExplicitCreditAmount(text = "") {
  const value = compactText(text);
  return extractCreditAmount(value) > 0 || /\b(?:uses?|using|will\s+use|cost(?:s|ing)?)\s+(?:0|zero)\s*credits?\b/i.test(value);
}

function isPersistentCreditChoice(text = "") {
  return /ask again|dont ask|don['’]?t ask/i.test(compactText(text));
}

function isCancelCreditChoice(text = "") {
  const value = compactText(text);
  return /^close(?:\s|$)/i.test(value)
    || /^(?:close\s+)?(?:no|cancel|reject|back)$/i.test(value)
    || /\b(?:no|cancel|reject|back)\b/i.test(value);
}

function isOneTimeCreditChoice(text = "") {
  const value = compactText(text);
  return /^check(?:\s|$)/i.test(value)
    || /^(?:check\s+)?(?:yes|approve|confirm|continue|use credits)$/i.test(value)
    || /\b(?:approve|confirm|continue|use credits)\b/i.test(value);
}

function normalizeAgentComposer(input = {}) {
  const text = compactText(input?.text || input?.draftText || input?.value || "");
  const normalizedTextHash = compactString(input?.normalizedTextHash || input?.draftHash || (text ? hashCompactText(text) : ""));
  return {
    visible: input?.visible === true || Boolean(text),
    text,
    normalizedTextHash,
    sendEnabled: input?.sendEnabled === true,
    sendControlVisible: input?.sendControlVisible === true,
    sendControlRect: input?.sendControlRect || (input?.sendControlVisible === true ? input?.rect : null) || null,
    generationActive: input?.generationActive === true || input?.activeGeneration === true,
    firstObservedAt: compactString(input?.firstObservedAt),
    lastChangedAt: compactString(input?.lastChangedAt),
    source: compactString(input?.source || (text ? "flow_agent_composer" : ""))
  };
}

function detectDraftedFollowupAction(raw = {}, composer = {}, expectedManifest = {}) {
  if (!composer.visible || !composer.text || !composer.normalizedTextHash) return null;
  if (agentComposerSubmitReadiness(composer).readyForSubmit !== true) return null;
  if (agentGenerationActive(raw)) return null;
  if (!hasMissingExpectedOutput(raw.progress, expectedManifest)) return null;
  if (!draftObservedAfterRunStarted(raw, composer)) return null;
  if (!targetMatchesCurrentRun(raw)) return null;
  if (runProfileDisallowsContinuation(raw)) return null;
  const priorHashes = new Set([
    ...stringArray(raw.submittedDraftHashes),
    ...stringArray(raw.submittedPromptHashes),
    ...stringArray(raw.previousDraftHashes)
  ]);
  if (priorHashes.has(composer.normalizedTextHash)) return null;
  const priorTexts = stringArray(raw.submittedPrompts || raw.previousPromptTexts).map((value) => compactText(value).toLowerCase());
  if (priorTexts.includes(composer.text.toLowerCase())) return null;
  return {
    kind: "drafted_followup",
    autoResolvable: true,
    draftHash: composer.normalizedTextHash,
    draftText: composer.text,
    recommendedAction: "submit_current_agent_draft"
  };
}

function agentGenerationActive(raw = {}) {
  return raw.generationActive === true
    || raw.activeGeneration === true
    || raw.agentResponding === true
    || raw.composer?.generationActive === true
    || raw.uiState?.generationActive === true;
}

function hasMissingExpectedOutput(progress = {}, expectedManifest = {}) {
  const missingImages = Number(progress?.missingImages);
  const missingVideos = Number(progress?.missingVideos);
  if ((Number.isFinite(missingImages) && missingImages > 0) || (Number.isFinite(missingVideos) && missingVideos > 0)) return true;
  const expectedImages = Number(progress?.expectedImages);
  const presentImages = Number(progress?.presentImages ?? progress?.mappedImages);
  const expectedVideos = Number(progress?.expectedVideos);
  const presentVideos = Number(progress?.presentVideos);
  if (Number.isFinite(expectedImages) && Number.isFinite(presentImages) && expectedImages > presentImages) return true;
  if (Number.isFinite(expectedVideos) && Number.isFinite(presentVideos) && expectedVideos > presentVideos) return true;
  const hasExplicitProgress = ["missingImages", "missingVideos", "expectedImages", "expectedVideos", "presentImages", "presentVideos", "mappedImages"]
    .some((field) => Object.hasOwn(progress || {}, field));
  if (!hasExplicitProgress) return false;
  const rows = Array.isArray(expectedManifest?.rows) ? expectedManifest.rows : [];
  return rows.some((row) => Number(row.expectedImageCount || row.expectedImages || 0) > 0 || Number(row.expectedVideoCount || row.expectedVideos || 0) > 0);
}

function draftObservedAfterRunStarted(raw = {}, composer = {}) {
  const runStartedAt = Date.parse(raw.runStartedAt || raw.runStartedAtIso || raw.baselineAt || "");
  const firstObservedAt = Date.parse(composer.firstObservedAt || "");
  if (!Number.isFinite(runStartedAt) || !Number.isFinite(firstObservedAt)) return false;
  return firstObservedAt >= runStartedAt;
}

function targetMatchesCurrentRun(raw = {}) {
  const requestedProjectId = compactString(raw.requestedProjectId || raw.targetProjectId);
  const requestedTabId = compactString(raw.requestedTabId || raw.targetTabId);
  const projectId = compactString(raw.projectId);
  const tabId = compactString(raw.tabId);
  if (requestedProjectId && projectId && requestedProjectId !== projectId) return false;
  if (requestedTabId && tabId && requestedTabId !== tabId) return false;
  return true;
}

function runProfileDisallowsContinuation(raw = {}) {
  const profile = raw.runProfile && typeof raw.runProfile === "object" ? raw.runProfile : {};
  return profile.allowContinuation === false || profile.permitContinuation === false;
}

function hashCompactText(value = "") {
  let hash = 2166136261;
  const text = compactText(value);
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16);
}

function stringArray(values = []) {
  if (!Array.isArray(values)) return [];
  return values.map(compactString).filter(Boolean);
}

function isSubmittedAutoFlowContractText(text = "") {
  const value = compactText(text);
  return FLOW_CONTRACT_RE.test(value) && !ACTUAL_AGENT_FAILURE_RE.test(value);
}

function normalizeAgentMessages(raw = {}) {
  const source = Array.isArray(raw.chatMessages)
    ? raw.chatMessages
    : Array.isArray(raw.latestMessages)
      ? raw.latestMessages
      : Array.isArray(raw.messages)
        ? raw.messages
        : Array.isArray(raw.visibleAgentTextBlocks)
          ? raw.visibleAgentTextBlocks
          : [];
  const seen = new Set();
  const normalized = [];
  for (const [index, message] of source.entries()) {
    const text = cleanAgentMessageText(compactText(message?.text || message?.message || ""));
    if (!text || text.length < 3) continue;
    const key = text.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    normalized.push({
      id: compactString(message?.id) || `agent-message-${index + 1}`,
      role: normalizeMessageRole(message?.role),
      text,
      rect: message?.rect || null
    });
  }
  return normalized.slice(-8);
}

function cleanAgentMessageText(text = "") {
  return compactText(text)
    .replace(/\s+(?:thumb_up\s+Good response|thumb_down\s+Bad response|content_copy\s+Copy Message|flag\s+Flag).*$/i, "")
    .replace(/\s+(?:undo|delete_forever|content_copy|flag|thumb_up|thumb_down)\b.*$/i, "")
    .trim();
}

function normalizeMessageRole(role = "") {
  const value = compactString(role).toLowerCase();
  if (/user|human|operator/.test(value)) return "user";
  if (/agent|assistant|model|flow/.test(value)) return "agent";
  return "unknown";
}

function isAgentWaitingMessage(text = "") {
  const value = compactText(text);
  if (!value) return false;
  return /please confirm|confirm that|tell me|let me know|waiting for|i(?:'|’)ve paused|i have paused|i must verify|before proceeding|should i|do you want me to|click|select|upload/i.test(value);
}

function isAgentAssetPickerText(text = "") {
  const value = compactText(text);
  if (!value) return false;
  return /add to prompt/i.test(value)
    && /(search|recent|uploads?|all media|images?|videos?|voices?|characters?|avatar)/i.test(value);
}

export function formatAgentScreenContextForBridge(context = {}, { includeRaw = false } = {}) {
  if (includeRaw) return context;
  const { blocks, ...compact } = context;
  return compact;
}

function dedupeAgentScreenBlocks(blocks = []) {
  const bestByKey = new Map();
  const passthrough = [];
  for (const block of blocks) {
    const classification = block.classification || {};
    if (!classification.blocked) {
      passthrough.push(block);
      continue;
    }
    const key = [
      block.rowId || "",
      classification.failureClass || "agent_policy_prompt_block",
      classification.category || "prompt_policy"
    ].join("|");
    const current = bestByKey.get(key);
    if (!current || scoreBlockForDedupe(block) > scoreBlockForDedupe(current)) {
      bestByKey.set(key, block);
    }
  }
  return [...bestByKey.values(), ...passthrough];
}

function scoreBlockForDedupe(block = {}) {
  const text = compactText(block.text);
  let score = 0;
  if (/^failed\b/i.test(text)) score += 1000;
  if (/can't generate|cannot generate/i.test(text)) score += 500;
  if (/please edit your prompt/i.test(text)) score += 250;
  if (/undo|delete_forever|thumb_up|thumb_down|content_copy|flag/i.test(text)) score -= 300;
  score -= Math.max(0, text.length - 180);
  return score;
}

function normalizeBlock(block = {}, index = 0, bodyText = "", fallbackRowIds = []) {
  const text = compactText(block.text || block.message || "");
  const rowId = rowIdForText(text, bodyText, fallbackRowIds);
  const classification = classifyAgentScreenText(text);
  return {
    id: compactString(block.id) || `agent-screen-block-${index + 1}`,
    text,
    rowId,
    rowIdCandidates: rowId ? [] : fallbackRowIds,
    needsRowDisambiguation: !rowId && fallbackRowIds.length > 1,
    rect: block.rect || null,
    classification
  };
}

function shouldClassifyBodyText(raw = {}, bodyText = "") {
  const value = compactText(bodyText);
  if (!value) return false;
  const hrefTitle = compactText([raw.href, raw.title, raw.pageState, raw.pageStateLabel].filter(Boolean).join(" "));
  if (/accounts\.google\.com|\/signin|oauth|login|sign in/i.test(hrefTitle)) return true;
  if (/resource[_\s-]*exhausted|error code\s*253|number of requests sent exceeds the quota limit|daily limit reached|quota (?:has been )?(?:reached|exceeded)|account quota|model quota/i.test(value)) return true;
  if (/not enough credits|insufficient credits|credits? exhausted|out of credits|buy more credits|purchase credits|billing plan/i.test(value)) return true;
  if (/(?:too many requests|\b429\b|\brate[-\s]?limit(?:ed|ing)?\b)/i.test(value)
    && /(?:flow|quota|request|requests|try again later)/i.test(value)) {
    return true;
  }
  return false;
}

function blockerSummary(block = {}) {
  const classification = block.classification || {};
  return {
    rowId: block.rowId,
    rowIdCandidates: Array.isArray(block.rowIdCandidates) ? block.rowIdCandidates : [],
    needsRowDisambiguation: block.needsRowDisambiguation === true,
    text: block.text,
    failureClass: classification.failureClass || "agent_policy_prompt_block",
    category: classification.category || "prompt_policy",
    retryable: classification.retryable === true,
    retryableWithPromptEdit: classification.retryableWithPromptEdit === true,
    retryStrategy: classification.retryStrategy || "",
    recommendedAction: classification.recommendedAction || ""
  };
}

function buildAgentRetryPrompt(blocker = {}) {
  if (blocker.retryableWithPromptEdit) return buildAgentPolicyRetryPrompt(blocker);
  return buildAgentSamePromptRetryPrompt(blocker);
}

function buildAgentPolicyRetryPrompt(blocker = {}) {
  const rowId = bracketlessRowId(blocker.rowId || "ROW-UNKNOWN");
  const failureText = compactText(blocker.text).slice(0, 360);
  return [
    `Repair and run [${rowId}] now.`,
    `Flow blocked the previous attempt: ${failureText}`,
    "Rewrite only the blocked row prompt so it complies with Flow policy; use your judgment to soften or generalize any unsafe, harmful, graphic, medical-distress, third-party, copyrighted, trademarked, public-figure, or named-provider wording.",
    "Preserve the user's creative intent, character continuity, product/subject continuity, camera move, aspect ratio, video model, duration, output count, and already-generated image/frame/reference inputs.",
    "Immediately generate the repaired row after rewriting it. Do not ask me to confirm the rewrite. Do not just say you will do it.",
    "Retry only the affected row and do not regenerate unaffected rows or create extra variations."
  ].join(" ");
}

function buildAgentSamePromptRetryPrompt(blocker = {}) {
  const rowId = bracketlessRowId(blocker.rowId || "ROW-UNKNOWN");
  const failureText = compactText(blocker.text).slice(0, 360);
  return [
    `Retry [${rowId}] video only.`,
    `Previous attempt failed without charge: ${failureText}`,
    "Use the same prompt, model, aspect ratio, duration, and already-attached image/frame inputs.",
    "Do not rewrite the creative direction unless Flow explicitly asks for prompt edits.",
    "Do not regenerate unaffected rows."
  ].join(" ");
}

function rowIdForText(text = "", bodyText = "", fallbackRowIds = []) {
  const direct = extractAgentVideoTag(text);
  if (direct) return bracketlessRowId(direct);
  const bodyTag = extractAgentVideoTag(bodyText);
  if (bodyTag) return bracketlessRowId(bodyTag);
  return fallbackRowIds.length === 1 ? fallbackRowIds[0] : "";
}

function expectedRowIds(expectedManifest = {}) {
  const rows = Array.isArray(expectedManifest)
    ? expectedManifest
    : Array.isArray(expectedManifest.rows)
      ? expectedManifest.rows
      : [];
  return rows.map((row) => {
    const raw = compactString(row.rowId || row.tag || row.videoTag || row.finalVideoId || row.id || row.sceneId);
    return bracketlessRowId(raw);
  }).filter(Boolean);
}

function bracketlessRowId(value = "") {
  return compactString(value).replace(/^\[|\]$/g, "");
}

function compactText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function compactString(value = "") {
  return String(value || "").trim();
}
