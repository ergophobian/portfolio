export const AGENT_MANAGED_PROTOCOL_VERSION = 2;
export const AGENT_MANAGED_PROTOCOL_TITLE = `Auto Flow Automation Protocol v${AGENT_MANAGED_PROTOCOL_VERSION}`;

export const AGENT_MANAGED_PROTOCOL_BODY = `AUTO FLOW AGENT CONTRACT — AUTOMATION PROTOCOL v2

SCOPE
- Treat each message's RUN_ID, BATCH_ID, ROW_ID, EXPECTED_IMAGES_TOTAL, and EXPECTED_VIDEOS_TOTAL as an exact execution contract.
- Preserve every creative prompt in the user's original language. Never merge, renumber, silently drop, or invent rows.

SETTINGS AND REFERENCES
- Native Flow settings and hard model limits are authoritative.
- Use only references visibly attached to the current message. Preserve row-specific, start-frame, end-frame, and ordered ingredient roles. Never inherit stale references.

EXECUTION AND TOTALS
- Generate exactly the requested count for every row and exactly the requested image/video totals for the batch.
- Do not create hidden stacks, extra alternates, or unrelated media.
- Never regenerate completed rows. Continue only explicitly missing or failed ROW_ID values.

FAILURE RECOVERY
- Classify the failure before acting. Never rewrite creative content for infrastructure failures.
- Transient, unbilled, server, or missing-output failure: retry only the affected row with the same prompt and references, at most 2 times.
- Actual safety or policy denial: minimally rewrite only the affected row into a compliant, non-explicit version while preserving safe high-level intent, subject continuity, camera, setting, and mood; retry at most 2 times. Never evade safeguards or preserve prohibited intent.
- Model, duration, ratio, or capability mismatch: do not offer substitutions, alternatives, or clarification cards. Execute the exact native settings when supported; otherwise fail once with the exact mismatch and stop.
- Confirmation is managed natively by Auto Flow as Never/AUTO_APPROVE. Do not ask for credit confirmation or create a confirmation choice. If Flow still asks, report settings drift and stop.
- Authentication, quota, account, project, billing, or uncertain submit acceptance: stop and report the blocker. Never submit again when acceptance is uncertain.

STATUS
- Use concise ASCII markers when possible:
  STATUS:STARTED [ROW_ID]
  STATUS:NEEDS_CREDIT [ROW_ID] amount
  STATUS:NEEDS_CLARIFICATION [ROW_ID] reason
  STATUS:ROW_COMPLETE [ROW_ID]
  STATUS:FAILED [ROW_ID] reason
  STATUS:TOTALS images=current/expected videos=current/expected
  STATUS:BATCH_COMPLETE [BATCH_ID]`;

export function compactAgentText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim();
}

export function hashAgentManagedText(value = "") {
  let hash = 2166136261;
  const text = compactAgentText(value);
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function managedAgentProtocol() {
  return {
    version: AGENT_MANAGED_PROTOCOL_VERSION,
    title: AGENT_MANAGED_PROTOCOL_TITLE,
    body: AGENT_MANAGED_PROTOCOL_BODY,
    hash: hashAgentManagedText(AGENT_MANAGED_PROTOCOL_BODY)
  };
}

export function verifyManagedAgentProtocol(input = {}, expected = managedAgentProtocol(), options = {}) {
  const title = String(input.title || "").trim();
  const body = String(input.body || "");
  const actualHash = body ? hashAgentManagedText(body) : "";
  const enabled = input.enabled === true;
  const present = Boolean(title || body);
  const titleMatches = title === expected.title;
  const titleRequired = options.titleRequired !== false;
  const bodyMatches = actualHash === expected.hash;
  return {
    ok: present && enabled && (!titleRequired || titleMatches) && bodyMatches,
    present,
    enabled,
    title,
    expectedTitle: expected.title,
    titleMatches,
    titleRequired,
    actualHash,
    expectedHash: expected.hash,
    bodyMatches,
    action: !present ? "install" : (((titleRequired && !titleMatches) || !bodyMatches) ? "update" : (!enabled ? "enable" : "none"))
  };
}

export function createAgentRunId(options = {}) {
  if (options.dryRun === true) return "AF-RUN-DRY";
  const now = options.now instanceof Date ? options.now : new Date(options.now || Date.now());
  const stamp = now.toISOString().replace(/[-:.TZ]/g, "").slice(0, 14);
  const random = typeof options.random === "function" ? options.random() : Math.random();
  const nonce = Math.max(0, Math.min(0.999999999, Number(random) || 0)).toString(36).slice(2, 8).toUpperCase().padEnd(6, "0");
  return `AF-RUN-${stamp}-${nonce}`;
}

export function prependAgentRunEnvelope(prompt = "", details = {}) {
  const text = String(prompt || "").trim();
  if (/^RUN_ID:\s*\S+/m.test(text)) return text;
  return [
    `RUN_ID: ${compactAgentText(details.runId)}`,
    `BATCH_ID: ${compactAgentText(details.batchId || "BATCH-001")}`,
    `ROW_COUNT: ${Math.max(0, Number(details.rowCount || 0))}`,
    `EXPECTED_IMAGES_TOTAL: ${Math.max(0, Number(details.expectedImages || 0))}`,
    `EXPECTED_VIDEOS_TOTAL: ${Math.max(0, Number(details.expectedVideos || 0))}`,
    "",
    text
  ].join("\n");
}

export function classifyAgentComposerPreflight(input = {}) {
  const draftText = compactAgentText(input.draftText || "");
  const promptText = compactAgentText(input.prompt || "");
  const draftHash = draftText ? hashAgentManagedText(draftText) : "";
  const promptHash = promptText ? hashAgentManagedText(promptText) : "";
  const submittedHashes = stringSet(input.submittedPromptHashes);
  const knownDraftHashes = stringSet(input.knownAutoFlowDraftHashes);

  if (input.generationActive === true) {
    return result("generation_active", false, false, "AGENT_GENERATION_ACTIVE", draftHash, promptHash);
  }
  if (!draftText) {
    return result("blank", true, true, "", draftHash, promptHash);
  }
  if (promptHash && draftHash === promptHash) {
    if (submittedHashes.has(promptHash) || input.currentPromptSubmitted === true) {
      return result("current_prompt_submitted", false, false, "AGENT_PROMPT_ALREADY_SUBMITTED", draftHash, promptHash);
    }
    return result("current_prompt_drafted", true, false, "", draftHash, promptHash, { reuseDraft: true });
  }
  if (submittedHashes.has(draftHash) || knownDraftHashes.has(draftHash)) {
    return result("known_stale_autoflow_draft", true, true, "", draftHash, promptHash, { clearKnownDraft: true });
  }
  return result("unknown_user_draft", false, false, "AGENT_COMPOSER_DRAFT_CONFLICT", draftHash, promptHash, {
    preserveDraft: true
  });
}

function result(state, ok, mayInsertPrompt, code, draftHash, promptHash, extra = {}) {
  return {
    ok,
    state,
    code,
    draftHash,
    promptHash,
    mayInsertPrompt,
    ...extra
  };
}

function stringSet(values = []) {
  return new Set((Array.isArray(values) ? values : [values])
    .map((value) => String(value || "").trim())
    .filter(Boolean));
}
