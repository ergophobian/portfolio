import {
  agentSelfHealContext,
  buildAgentAutoApprovePolicy,
  buildAgentSelfHealPolicy,
  DEFAULT_AGENT_AUTONOMY
} from "./agent-autonomy.js";

export const AGENT_MODEL_COST_GUIDE = Object.freeze({
  lastReviewed: "2026-07-15",
  source: "Observed Google Flow Agent settings and agentInfo model-family writes in the shared Auto Flow lane.",
  image: Object.freeze([
    Object.freeze({
      flowLabel: "Nano Banana 2",
      aliases: Object.freeze(["Nano Banana", "Banana 2"]),
      costTier: "zero-credit-observed",
      recommendation: "Use for cost-safe bulk image generation unless the user explicitly asks for Pro image output.",
      useWhen: "Default image generation, reference-image prep, and image slots before frame-to-video."
    }),
    Object.freeze({
      flowLabel: "Nano Banana 2 Lite",
      aliases: Object.freeze(["Banana 2 Lite", "nano_banana_2_lite", "harbor_seal"]),
      costTier: "lowest-cost-image-option",
      recommendation: "Use for larger image verification batches when quality-sensitive Pro output is not required. Still stop if Flow shows a credit dialog.",
      useWhen: "Bulk image smoke tests, filename/download proof, and inexpensive reference preparation."
    }),
    Object.freeze({
      flowLabel: "Nano Banana Pro",
      aliases: Object.freeze(["Banana Pro"]),
      costTier: "zero-credit-observed",
      recommendation: "Use when the user asks for the Pro image model or higher image quality. Still stop if Flow shows a credit dialog.",
      useWhen: "Higher quality stills or image references when the user chooses Pro."
    })
  ]),
  video: Object.freeze([
    Object.freeze({
      flowLabel: "Veo 3.1 - Lite [Lower Priority]",
      aliases: Object.freeze(["VEO 3.1 light priority", "Veo 3.1 Lite Lower Priority", "veo3_lite_low"]),
      costTier: "cheapest",
      recommendation: "Cheapest/cost-safe video choice for bulk tests and default low-cost runs. Prefer this before Omni Flash when Omni-specific behavior is not required.",
      useWhen: "Large batches, matrix smoke tests, free/low-credit verification, and normal text-to-video or frame-to-video runs."
    }),
    Object.freeze({
      flowLabel: "Veo 3.1 - Lite",
      aliases: Object.freeze(["Veo 3.1 Lite"]),
      costTier: "low",
      recommendation: "Use when the user wants a faster or more standard Lite queue than lower-priority, after confirming cost.",
      useWhen: "Low-cost videos where lower-priority wait time is not acceptable."
    }),
    Object.freeze({
      flowLabel: "Veo 3.1 - Fast",
      aliases: Object.freeze(["Veo 3.1 Fast"]),
      costTier: "medium",
      recommendation: "Use for speed-sensitive runs after the user accepts the cost tradeoff.",
      useWhen: "Faster video turnaround when cost is less important than latency."
    }),
    Object.freeze({
      flowLabel: "Veo 3.1 - Quality",
      aliases: Object.freeze(["Veo 3.1 Quality"]),
      costTier: "higher",
      recommendation: "Use only when the user chooses quality over speed/cost.",
      useWhen: "Final renders or quality-critical videos after explicit model approval."
    }),
    Object.freeze({
      flowLabel: "Omni Flash",
      aliases: Object.freeze(["Omni", "Flow Omni"]),
      costTier: "paid",
      recommendation: "Omni Flash is not the cheapest video model. Use it for Omni/multi-frame workflows only after explicit credit approval.",
      useWhen: "Multi-image or Omni-specific frame-to-video workflows that need Omni behavior."
    })
  ])
});

export function buildAgentRuntimeContext() {
  const selfHeal = buildAgentSelfHealPolicy({ autonomy: DEFAULT_AGENT_AUTONOMY });
  const autoApprove = buildAgentAutoApprovePolicy({ autonomy: DEFAULT_AGENT_AUTONOMY });
  const runProfileDefaults = {
    imageModel: "Nano Banana 2",
    imageOutputsPerPrompt: 1,
    imageAspectRatio: "use active Flow UI setting unless the user overrides",
    videoModel: "Veo 3.1 - Lite [Lower Priority]",
    videoOutputsPerRow: 1,
    videoAspectRatio: "use active Flow UI setting unless the user overrides",
    videoLengthSeconds: 8,
    autonomy: DEFAULT_AGENT_AUTONOMY,
    selfHeal,
    autoApprove,
    returnSilentVideos: "ask when the workflow includes video because audio intent is content-dependent",
    autoDownload: {
      images: true,
      videos: true,
      refs: true,
      manifests: true
    },
    outputRootTemplate: "outputs/<run-name>/",
    outputFolders: {
      images: "images/",
      videos: "videos/",
      refs: "refs/",
      manifests: "manifests/",
      transcripts: "transcripts/",
      retryPrompts: "retry-prompts/"
    },
    namingTemplate: "{rowId}_{kind}_{version}_{slug}"
  };
  return {
    product: "Auto Flow Agent Mode",
    modelCostGuide: AGENT_MODEL_COST_GUIDE,
    runProfileDefaults,
    agentSelfHeal: agentSelfHealContext(),
    recommendedDefaults: {
      imageModel: runProfileDefaults.imageModel,
      videoModel: runProfileDefaults.videoModel,
      autonomy: runProfileDefaults.autonomy,
      videoModelReason: "Cheapest/cost-safe video option observed in Flow Agent settings.",
      avoidDefaultingTo: "Omni Flash",
      avoidDefaultingReason: "Omni Flash is paid and is not the cheapest; only use it for Omni-specific workflows or when the user chooses it."
    },
    preflightPolicy: {
      askOnlyForOverrides: true,
      showDefaultsBeforeLiveRun: true,
      requireExplicitCreditApproval: true,
      requireProjectAndTabForLiveSubmit: true,
      unknownValuesThatMustBeResolved: [
        "Return silent videos for video workflows",
        "credit approval for paid video generation",
        "required reference assets and visible prompt chips"
      ],
      promptRewritePolicy: {
        defaultAutonomy: DEFAULT_AGENT_AUTONOMY,
        flowAgentFirstLineRepair: true,
        allowed: [
          "clarity",
          "continuity",
          "policy repair",
          "speaker/dialogue correction",
          "prompt formatting"
        ],
        preserve: [
          "row ids",
          "character identity",
          "dialogue intent",
          "output counts",
          "model/settings",
          "credit behavior"
        ]
      }
    },
    preflightChecklist: [
      "Show the current run profile defaults first, then ask only for overrides or unknown required values.",
      "Default to full-self-heal autonomy: do not pre-fix prompts; submit intent and let Flow Agent repair safe content/policy/missing-output failures first.",
      "Auto-approve safe at-level rephrases and missing-output retries in the loop, but require explicit approval before credit spend unless confirmCredits or autoApprove=credits is set.",
      "Use the default image model and output count unless the user overrides them.",
      "Use the cost-safe video model default unless the user chooses a different model after seeing the cost/speed tradeoff.",
      "For cost-safe video tests, recommend Veo 3.1 - Lite [Lower Priority] before Omni Flash.",
      "Ask for Return silent videos on/off when video audio intent is unknown.",
      "Ask whether to auto-download images, videos, refs, and manifests only if the user has not accepted the default organized output profile.",
      "Ask for explicit approval before confirming credit dialogs or using Yes-and-don't-ask-again."
    ],
    flowSettingsSeen: {
      imageModels: AGENT_MODEL_COST_GUIDE.image.map((model) => model.flowLabel),
      videoModels: AGENT_MODEL_COST_GUIDE.video.map((model) => model.flowLabel),
      confirmBeforeGenerating: ["Always", "Never"],
      imageOutputCounts: [1, 2, 3, 4],
      videoOutputCounts: [1, 2, 3, 4],
      imageRatios: ["16:9", "4:3", "1:1", "3:4", "9:16"],
      videoRatios: ["16:9", "9:16"]
    },
    caveats: [
      "Actual credits can vary by account, model, duration, output count, and Flow UI changes.",
      "If Flow shows a credit dialog, the dialog text is the source of truth for that specific spend.",
      "Do not assume Omni Flash is cheapest because it says Flash."
    ]
  };
}
