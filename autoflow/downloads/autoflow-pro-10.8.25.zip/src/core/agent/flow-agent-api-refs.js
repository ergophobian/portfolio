export const FLOW_AGENT_API_REF_MAX_BYTES = 16 * 1024 * 1024;
export const FLOW_AGENT_API_REF_MAX_COUNT = 10;
export const PATCHWORK_REF_ORIGINS = Object.freeze([
  "https://pub-41d1d99ea47d442592b42ae71b588835.r2.dev",
  "http://127.0.0.1",
  "http://localhost"
]);

export function planFlowAgentApiReferences(payload = {}) {
  const supplied = Array.isArray(payload?.refPlan?.attachments) ? payload.refPlan.attachments : [];
  if (!supplied.length) return { ok: true, attachments: [], mediaIds: [], targetRefs: [] };
  const targetRefs = orderedUnique(payload.targetRefs || payload.targetReferences);
  const bySource = new Map();
  for (let index = 0; index < supplied.length; index += 1) {
    const raw = supplied[index] || {};
    const handle = compact(raw.handle || raw.refHandle);
    const sourceIdentity = compact(raw.sourceIdentity || raw.sha256 || raw.mediaId || handle);
    if (!handle || !sourceIdentity) return invalid("AGENT_API_REF_IDENTITY_REQUIRED", "Every direct Agent API reference requires a stable handle and source identity.", { index });
    const existing = bySource.get(sourceIdentity);
    if (existing) {
      if (existing.handle !== handle && targetRefs.includes(handle)) {
        return invalid("AGENT_API_REF_CANONICAL_HANDLE_MISMATCH", "Duplicate reference sources must use one canonical target handle.", { sourceIdentity, handles: [existing.handle, handle] });
      }
      continue;
    }
    const mediaId = compact(raw.mediaId || raw.flowMediaId);
    if (mediaId) {
      bySource.set(sourceIdentity, { index, handle, sourceIdentity, mediaId, role: compact(raw.role), order: numericOrder(raw.order, index) });
      continue;
    }
    const sourceUrl = compact(raw.sourceUrl);
    const sha256 = normalizeSha256(raw.sha256 || (/^sha256:[a-f0-9]{64}$/i.test(sourceIdentity) ? sourceIdentity.slice(7) : ""));
    const byteLength = positiveInteger(raw.byteLength);
    const mimeType = compact(raw.mimeType).toLowerCase();
    if (!sourceUrl || !sha256 || !byteLength || !/^image\/(png|jpeg|webp)$/i.test(mimeType)) {
      return invalid("AGENT_API_REF_METADATA_REQUIRED", "Direct reference upload requires an exact sourceUrl, SHA-256, byte length, and PNG/JPEG/WebP MIME type.", {
        handle,
        hasSourceUrl: Boolean(sourceUrl),
        hasSha256: Boolean(sha256),
        byteLength,
        mimeType
      });
    }
    if (byteLength > FLOW_AGENT_API_REF_MAX_BYTES) {
      return invalid("AGENT_API_REF_TOO_LARGE", `Direct Agent API references must be ${FLOW_AGENT_API_REF_MAX_BYTES} bytes or smaller.`, { handle, byteLength });
    }
    bySource.set(sourceIdentity, {
      index,
      handle,
      sourceIdentity,
      sourceUrl,
      sha256,
      byteLength,
      mimeType,
      fileName: compact(raw.fileName || raw.name || `reference-${index + 1}.png`),
      role: compact(raw.role),
      order: numericOrder(raw.order, index)
    });
  }
  const attachments = [...bySource.values()].sort((left, right) => left.order - right.order || left.index - right.index);
  if (attachments.length > FLOW_AGENT_API_REF_MAX_COUNT) {
    return invalid("AGENT_API_REF_LIMIT_EXCEEDED", `Flow Agent accepts at most ${FLOW_AGENT_API_REF_MAX_COUNT} unique references.`, { count: attachments.length });
  }
  const handles = new Set(attachments.map((entry) => entry.handle));
  const missingTargets = targetRefs.filter((handle) => !handles.has(handle));
  if (missingTargets.length) return invalid("AGENT_API_TARGET_REF_UNRESOLVED", "One or more targetRefs do not resolve to an uploaded reference.", { missingTargets });
  return { ok: true, attachments, mediaIds: attachments.map((entry) => entry.mediaId).filter(Boolean), targetRefs };
}

export async function fetchFlowAgentApiReference(attachment = {}, options = {}) {
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== "function") throw refError("AGENT_API_REF_FETCH_UNAVAILABLE", "Reference fetch is unavailable.");
  const sourceUrl = validateSourceUrl(attachment.sourceUrl, options.allowedOrigins);
  const response = await fetchImpl(sourceUrl.href, {
    method: "GET",
    credentials: "omit",
    redirect: "error",
    cache: "no-store",
    headers: { accept: "image/png,image/jpeg,image/webp" }
  });
  if (!response.ok) throw refError("AGENT_API_REF_FETCH_FAILED", `Reference URL returned HTTP ${Number(response.status || 0)}.`, { status: Number(response.status || 0), handle: attachment.handle });
  const contentType = compact(response.headers?.get?.("content-type")).split(";")[0].toLowerCase();
  if (contentType !== attachment.mimeType) throw refError("AGENT_API_REF_MIME_MISMATCH", "Reference MIME type changed after PatchWork validation.", { expected: attachment.mimeType, actual: contentType });
  const declaredLength = Number(response.headers?.get?.("content-length") || 0);
  if (declaredLength && declaredLength !== attachment.byteLength) throw refError("AGENT_API_REF_LENGTH_MISMATCH", "Reference content length changed after PatchWork validation.", { expected: attachment.byteLength, actual: declaredLength });
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (bytes.byteLength !== attachment.byteLength || bytes.byteLength > FLOW_AGENT_API_REF_MAX_BYTES) {
    throw refError("AGENT_API_REF_LENGTH_MISMATCH", "Reference byte length changed after PatchWork validation.", { expected: attachment.byteLength, actual: bytes.byteLength });
  }
  const sha256 = await sha256Hex(bytes);
  if (sha256 !== attachment.sha256) throw refError("AGENT_API_REF_SHA256_MISMATCH", "Reference SHA-256 changed after PatchWork validation.", { expected: attachment.sha256, actual: sha256 });
  return { ...attachment, bytes, imageBytes: bytesToBase64(bytes), sha256 };
}

export function validateSourceUrl(value = "", allowedOrigins = PATCHWORK_REF_ORIGINS) {
  let url;
  try { url = new URL(String(value || "")); } catch {
    throw refError("AGENT_API_REF_URL_INVALID", "Direct Agent API reference URL is invalid.");
  }
  if (url.username || url.password || !["https:", "http:"].includes(url.protocol)) throw refError("AGENT_API_REF_URL_INVALID", "Direct Agent API reference URL must not contain credentials.");
  const origins = new Set((allowedOrigins || PATCHWORK_REF_ORIGINS).map((entry) => String(entry || "").replace(/\/$/, "")));
  if (!origins.has(url.origin)) throw refError("AGENT_API_REF_ORIGIN_FORBIDDEN", "Reference URL origin is not approved for direct Flow upload.", { origin: url.origin });
  if (url.protocol === "http:" && !["127.0.0.1", "localhost"].includes(url.hostname)) throw refError("AGENT_API_REF_ORIGIN_FORBIDDEN", "Insecure reference URLs are allowed only on loopback.");
  return url;
}

async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, "0")).join("");
}

function bytesToBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
  return btoa(binary);
}

function orderedUnique(values = []) {
  return [...new Set((Array.isArray(values) ? values : []).map(compact).filter(Boolean))];
}
function compact(value = "") { return String(value ?? "").trim(); }
function normalizeSha256(value = "") { const text = compact(value).toLowerCase().replace(/^sha256:/, ""); return /^[a-f0-9]{64}$/.test(text) ? text : ""; }
function positiveInteger(value) { const number = Number(value); return Number.isSafeInteger(number) && number > 0 ? number : 0; }
function numericOrder(value, fallback) { const number = Number(value); return Number.isFinite(number) ? number : fallback; }
function invalid(code, message, details) { return { ok: false, code, message, details }; }
function refError(code, message, details) { const error = new Error(message); error.code = code; if (details !== undefined) error.details = details; return error; }
