import {
  extractAgentImageAuditId,
  agentImageIndexFromAuditId,
  agentVideoTagFromImageAuditId,
  extractAgentVideoTag,
  parseAgentProjectMetadata
} from "./agent-project-metadata.js";

export function reconcileAgentProject({ projectInitialData = {}, expectedManifest = {} } = {}) {
  const records = parseAgentProjectMetadata(projectInitialData);
  const project = unwrapProjectInitialData(projectInitialData);
  const expectedRows = normalizeExpectedRows(expectedManifest);
  const imageRecords = records.filter((record) => record.kind === "image");
  const visibleImageCandidates = latestImageVersions(uniqueRecordsByMediaId(imageRecords))
    .sort(compareRecords)
    .map((record, index) => ({
      candidateId: `candidate-image-${index + 1}`,
      ...compactRecord(record)
    }));
  const imagesById = indexBy(imageRecords, "mediaId");
  const imagesByTag = groupImagesByTag(records);
  const videosByTag = groupBy(
    records.filter((record) => record.kind === "video" && record.videoTag),
    "videoTag"
  );
  const untaggedVideos = records.filter((record) => record.kind === "video" && !record.videoTag);
  const allowSingleVisibleImageProvisional = expectedRows.length === 1
    && expectedRows[0]?.expectedImages === 1
    && expectedRows[0]?.expectedVideos === 0
    && visibleImageCandidates.length === 1;

  const provisionalMatches = [];
  const rows = expectedRows.map((expected) => {
    const taggedVideos = uniqueRecordsByMediaId(expected.videoTags.flatMap((tag) => videosByTag.get(tag) || []))
      .map((video) => ({
        ...compactRecord(video),
        mapping: video.videoTag === expected.tag ? "deterministic" : "prompt_tag"
      }));
    const taggedVideoVersions = withLatestFlags(taggedVideos);
    const candidateImages = latestImageVersions(filterExpectedImageAuditIds(
      uniqueRecordsByMediaId(expected.imageTags.flatMap((tag) => imagesByTag.get(tag) || [])),
      expected.imageAuditIds
    ));
    const deterministicImages = sortImages(candidateImages).map((image) => ({
      ...compactRecord(image),
      mapping: image.imageAuditId ? "deterministic" : "prompt_tag"
    }));
    const inferredImages = deterministicImages.length
      ? []
      : inferImagesFromVideoInputs(taggedVideoVersions, imagesById).map((image) => ({
          ...compactRecord(image),
          mapping: "inferential"
    }));
    const provisionalImage = !deterministicImages.length && !inferredImages.length
      ? provisionalImageForExpected(expected, visibleImageCandidates, { allow: allowSingleVisibleImageProvisional })
      : null;
    const images = deterministicImages.length
      ? deterministicImages
      : (inferredImages.length ? inferredImages : (provisionalImage ? [provisionalImage] : []));
    const sourceMatchedVideos = expected.sourceVideoMediaId
      ? untaggedVideos
        .filter((video) => Array.isArray(video.videoInputMediaIds) && video.videoInputMediaIds.includes(expected.sourceVideoMediaId))
        .map((video) => ({
          ...compactRecord(video),
          mapping: "deterministic_source_video_input"
        }))
      : [];
    const inferredVideos = sourceMatchedVideos.length
      ? []
      : inferVideosFromImages(images, untaggedVideos, expected).map((video) => ({
          ...compactRecord(video),
          mapping: "inferential_from_image_inputs"
        }));
    const candidateVideoVersions = withLatestFlags(uniqueRecordsByMediaId([...taggedVideoVersions, ...sourceMatchedVideos, ...inferredVideos]));
    const videoVersions = expected.expectedVideos === 0 ? [] : candidateVideoVersions;
    const videoSlots = buildExpectedVideoSlots(videoVersions, expected.expectedVideos, expected.tag);
    const latestVideo = expected.expectedVideos === 1
      ? videoSlots[0]?.latestVideo || videoVersions.find((version) => version.isLatest) || null
      : null;
    const presentVideoCount = expected.expectedVideos > 1
      ? videoSlots.length
      : Math.min(videoVersions.length, expected.expectedVideos);
    const videoComplete = expected.expectedVideos === 0 || presentVideoCount >= expected.expectedVideos;
    const imageComplete = expected.expectedImages === 0 || images.length >= expected.expectedImages;
    const hasProvisionalImage = images.some((image) => image.mapping === "provisional_single_visible_image");
    const hasVisibleUnmappedImageOnlyOutput = expected.expectedVideos === 0
      && expected.expectedImages > 0
      && visibleImageCandidates.length > 0;
    if (hasProvisionalImage) {
      provisionalMatches.push({
        rowTag: expected.tag,
        candidateId: images[0].candidateId || "",
        mediaId: images[0].mediaId || "",
        kind: "image",
        evidence: {
          reason: "single_pending_image_slot_single_visible_image_candidate",
          expectedImages: expected.expectedImages,
          expectedVideos: expected.expectedVideos
        }
      });
    }

    return {
      tag: expected.tag,
      rowIndex: expected.rowIndex,
      title: expected.title,
      expectedImages: expected.expectedImages,
      expectedVideos: expected.expectedVideos,
      presentVideos: presentVideoCount,
      status: videoComplete && imageComplete
        ? (hasProvisionalImage ? "provisional_match" : "landed")
        : (hasVisibleUnmappedImageOnlyOutput ? "visible_unmapped_output" : "missing"),
      dispatchState: videoComplete && imageComplete
        ? (hasProvisionalImage ? "observed" : "landed")
        : (hasVisibleUnmappedImageOnlyOutput ? "observed_unmapped" : "not_observed"),
      videoVersions,
      videoSlots,
      latestVideo,
      images,
      imageMappingStrength: imageMappingStrength(deterministicImages, images)
    };
  });

  const missingVideoTags = rows
    .filter((row) => row.expectedVideos > 0 && row.presentVideos < row.expectedVideos)
    .map((row) => row.tag);

  return {
    projectId: compactString(project?.projectId),
    expectedVideos: expectedRows.reduce((sum, row) => sum + row.expectedVideos, 0),
    presentVideos: rows.reduce((sum, row) => sum + row.presentVideos, 0),
    missingVideos: rows.reduce((sum, row) => sum + Math.max(0, row.expectedVideos - row.presentVideos), 0),
    missingVideoTags,
    expectedImages: expectedRows.reduce((sum, row) => sum + row.expectedImages, 0),
    mappedImages: rows.reduce((sum, row) => sum + row.images.length, 0),
    visibleCandidates: visibleImageCandidates,
    provisionalMatches,
    notObserved: rows.filter((row) => row.dispatchState === "not_observed").length,
    rows,
    mediaRecords: records.map(compactRecord)
  };
}

function normalizeExpectedRows(expectedManifest = {}) {
  const rows = Array.isArray(expectedManifest)
    ? expectedManifest
    : Array.isArray(expectedManifest.rows)
      ? expectedManifest.rows
      : [];

  return rows
    .map((row, index) => {
      const tag = normalizeTag(
        row.tag
        || row.videoTag
        || row.finalVideoId
        || row.rowId
        || extractAgentVideoTag(row.videoPrompt || row.line || row.prompt || "")
      );
      if (!tag) return null;
      return {
        tag,
        rowIndex: Number.parseInt(row.rowIndex || row.clipNumber || index + 1, 10),
        title: compactString(row.title),
        sourceVideoMediaId: compactString(row.sourceVideoMediaId || row.sourceMediaId),
        imageTags: expectedImageTags(row, tag),
        imageAuditIds: expectedImageAuditIds(row),
        videoTags: expectedVideoTags(row, tag),
        expectedImages: expectedImageCount(row),
        expectedVideos: expectedVideoCount(row)
      };
    })
    .filter(Boolean);
}

function expectedImageCount(row = {}) {
  if (Number.isFinite(Number(row.expectedImages))) return Math.max(0, Number(row.expectedImages));
  if (Number.isFinite(Number(row.expectedImageCount))) return Math.max(0, Number(row.expectedImageCount));
  if (Array.isArray(row.images)) return row.images.length;
  if (Array.isArray(row.imageSlots)) return row.imageSlots.length;
  if (Array.isArray(row.framePrompts)) return row.framePrompts.length;
  if (Array.isArray(row.frames)) return row.frames.length;
  return 0;
}

function expectedVideoCount(row = {}) {
  if (Number.isFinite(Number(row.expectedVideos))) return Math.max(0, Number(row.expectedVideos));
  if (Number.isFinite(Number(row.expectedVideoCount))) return Math.max(0, Number(row.expectedVideoCount));
  return 1;
}

function expectedImageTags(row = {}, primaryTag = "") {
  return uniqueStrings([
    primaryTag,
    extractAgentVideoTag(row.videoPrompt || ""),
    extractAgentVideoTag(row.imagePrompt || ""),
    extractAgentVideoTag(row.sourceRow || row.line || row.prompt || "")
  ]);
}

function expectedImageAuditIds(row = {}) {
  return uniqueStrings([
    ...imageSlotAuditIds(row.images),
    ...imageSlotAuditIds(row.imageSlots),
    ...imageSlotAuditIds(row.framePrompts),
    ...imageSlotAuditIds(row.frames),
    extractAgentImageAuditId(row.imagePrompt || ""),
    extractAgentImageAuditId(row.sourceRow || row.line || row.prompt || "")
  ]);
}

function imageSlotAuditIds(values = []) {
  if (!Array.isArray(values)) return [];
  return values.flatMap((value) => {
    if (typeof value === "string") return [extractAgentImageAuditId(value)];
    return [
      value?.afid,
      value?.imageAuditId,
      extractAgentImageAuditId(value?.prompt || ""),
      extractAgentImageAuditId(value?.line || "")
    ];
  });
}

function expectedVideoTags(row = {}, primaryTag = "") {
  return uniqueStrings([
    primaryTag,
    extractAgentVideoTag(row.finalVideoId || ""),
    extractAgentVideoTag(row.videoPrompt || ""),
    extractAgentVideoTag(row.sourceRow || row.line || row.prompt || "")
  ]);
}

function groupImagesByTag(records = []) {
  const groups = new Map();
  for (const record of records) {
    if (record.kind !== "image") continue;
    const tag = agentVideoTagFromImageAuditId(record.imageAuditId) || record.videoTag;
    if (!tag) continue;
    if (!groups.has(tag)) groups.set(tag, []);
    groups.get(tag).push(record);
  }
  return groups;
}

function filterExpectedImageAuditIds(records = [], expectedImageAuditIds = []) {
  if (!expectedImageAuditIds.length) return records;
  const expected = new Set(expectedImageAuditIds);
  return records.filter((record) => !record.imageAuditId || expected.has(record.imageAuditId));
}

function latestImageVersions(records = []) {
  const latestByAuditId = new Map();
  const unversioned = [];
  for (const record of records) {
    const auditId = compactString(record.imageAuditId);
    if (!auditId) {
      unversioned.push(record);
      continue;
    }
    const versions = latestByAuditId.get(auditId) || [];
    versions.push(record);
    latestByAuditId.set(auditId, versions);
  }
  const latestVersioned = [...latestByAuditId.values()].map((versions) => {
    const sorted = versions.slice().sort(compareRecords);
    const latest = sorted.at(-1);
    return {
      ...latest,
      version: sorted.length,
      versionsCount: sorted.length,
      isLatest: true,
      previousMediaIds: sorted.slice(0, -1).map((record) => record.mediaId).filter(Boolean)
    };
  });
  return [
    ...unversioned.map((record) => ({
      ...record,
      version: 1,
      versionsCount: 1,
      isLatest: true,
      previousMediaIds: []
    })),
    ...latestVersioned
  ];
}

function inferImagesFromVideoInputs(videoVersions = [], imagesById = new Map()) {
  const imageIds = uniqueStrings(videoVersions.flatMap((video) => video.inputMediaIds));
  return imageIds.map((mediaId) => imagesById.get(mediaId)).filter(Boolean).sort(compareRecords);
}

function provisionalImageForExpected(expected = {}, visibleImageCandidates = [], options = {}) {
  if (options.allow !== true) return null;
  if (visibleImageCandidates.length !== 1) return null;
  if (Number(expected.expectedImages || 0) !== 1) return null;
  if (Number(expected.expectedVideos || 0) !== 0) return null;
  const candidate = visibleImageCandidates[0];
  return {
    ...candidate,
    mapping: "provisional_single_visible_image",
    evidence: {
      reason: "single_pending_image_slot_single_visible_image_candidate"
    }
  };
}

function inferVideosFromImages(images = [], videos = [], expected = {}) {
  const imageIds = new Set(uniqueStrings(images.map((image) => image.mediaId)));
  if (!imageIds.size || imageIds.size < Number(expected.expectedImages || 0)) return [];
  return videos
    .filter((video) => hasExactInputMediaSet(video.inputMediaIds, imageIds))
    .sort(compareRecords);
}

function hasExactInputMediaSet(inputMediaIds = [], expectedImageIds = new Set()) {
  const inputIds = uniqueStrings(inputMediaIds);
  if (inputIds.length !== expectedImageIds.size) return false;
  return inputIds.every((mediaId) => expectedImageIds.has(mediaId));
}

function buildExpectedVideoSlots(videoVersions = [], expectedVideos = 0, rowTag = "") {
  const expected = Math.max(0, Number(expectedVideos || 0) || 0);
  if (!expected || !videoVersions.length) return [];
  if (expected === 1) {
    const versions = videoVersions.map((video, index) => ({
      ...video,
      version: index + 1,
      isLatest: index === videoVersions.length - 1
    }));
    return [{
      slotId: `${normalizeSlotTag(rowTag)}-VID1`,
      slotIndex: 0,
      slotLabel: "A",
      versions,
      latestVideo: versions.at(-1) || null
    }];
  }
  if (videoVersions.length !== expected) return [];
  return videoVersions.map((video, slotIndex) => {
    const latestVideo = { ...video, version: 1, isLatest: true };
    return {
      slotId: `${normalizeSlotTag(rowTag)}-VID${slotIndex + 1}`,
      slotIndex,
      slotLabel: variationLabel(slotIndex),
      versions: [latestVideo],
      latestVideo
    };
  });
}

function normalizeSlotTag(value = "") {
  return compactString(value).replace(/^\[/, "").replace(/\]$/, "") || "ROW";
}

function variationLabel(index = 0) {
  const value = Math.max(0, Number(index || 0) || 0);
  return value < 26 ? String.fromCharCode(65 + value) : String(value + 1);
}

function withLatestFlags(records = []) {
  const sorted = records.slice().sort(compareRecords);
  const latestIndex = sorted.length - 1;
  return sorted.map((record, index) => ({
    ...record,
    version: index + 1,
    isLatest: index === latestIndex
  }));
}

function sortImages(records = []) {
  return records.slice().sort((left, right) => {
    const leftIndex = agentImageIndexFromAuditId(left.imageAuditId) || 0;
    const rightIndex = agentImageIndexFromAuditId(right.imageAuditId) || 0;
    if (leftIndex !== rightIndex) return leftIndex - rightIndex;
    return compareRecords(left, right);
  });
}

function compactRecord(record = {}) {
  return {
    mediaId: record.mediaId,
    workflowId: record.workflowId,
    workflowStepId: record.workflowStepId,
    createTime: record.createTime,
    kind: record.kind,
    prompt: record.prompt,
    title: record.title,
    videoTag: record.videoTag,
    imageAuditId: record.imageAuditId,
    inputMediaIds: record.inputMediaIds || [],
    imageInputMediaIds: record.imageInputMediaIds || record.inputMediaIds || [],
    videoInputMediaIds: record.videoInputMediaIds || [],
    version: record.version,
    versionsCount: record.versionsCount,
    isLatest: record.isLatest === true,
    previousMediaIds: Array.isArray(record.previousMediaIds) ? record.previousMediaIds : []
  };
}

function imageMappingStrength(deterministicImages = [], images = []) {
  if (deterministicImages.some((image) => image.mapping === "deterministic")) return "deterministic";
  if (deterministicImages.some((image) => image.mapping === "prompt_tag")) return "prompt_tag";
  if (images.some((image) => image.mapping === "provisional_single_visible_image")) return "provisional_match";
  return images.length ? "inferential" : "missing";
}

function groupBy(values = [], key) {
  const groups = new Map();
  for (const value of values) {
    const groupKey = value[key];
    if (!groupKey) continue;
    if (!groups.has(groupKey)) groups.set(groupKey, []);
    groups.get(groupKey).push(value);
  }
  return groups;
}

function indexBy(values = [], key) {
  const index = new Map();
  for (const value of values) {
    if (value[key]) index.set(value[key], value);
  }
  return index;
}

function normalizeTag(value = "") {
  const text = compactString(value);
  return extractAgentVideoTag(text) || extractAgentVideoTag(`[${text}]`);
}

function uniqueRecordsByMediaId(records = []) {
  const seen = new Set();
  const unique = [];
  for (const record of records) {
    const mediaId = compactString(record.mediaId);
    if (!mediaId || seen.has(mediaId)) continue;
    seen.add(mediaId);
    unique.push(record);
  }
  return unique;
}

function compareRecords(left = {}, right = {}) {
  const timeCompare = toTime(left.createTime) - toTime(right.createTime);
  if (timeCompare) return timeCompare;
  return String(left.mediaId || "").localeCompare(String(right.mediaId || ""));
}

function unwrapProjectInitialData(input) {
  const parsed = typeof input === "string" ? JSON.parse(input) : input;
  return parsed?.result?.data?.json || parsed?.data?.json || parsed?.json || parsed;
}

function toTime(value = "") {
  const millis = Date.parse(value);
  return Number.isFinite(millis) ? millis : 0;
}

function uniqueStrings(values = []) {
  return [...new Set(values.map(compactString).filter(Boolean))];
}

function compactString(value = "") {
  return String(value || "").trim();
}
