import {
  buildAgentAutoApprovePolicy,
  buildAgentSelfHealPolicy,
  normalizeAgentAutonomy
} from "./agent-autonomy.js";

const DEFAULT_IMAGE_MODEL = "Nano Banana 2";
const DEFAULT_VIDEO_MODEL = "Veo 3.1 - Lite [Lower Priority]";

export function normalizeAgentRunOptions(options = {}) {
  const outputCount = firstFiniteInteger(
    options.outputs,
    options.outputCount,
    options.repeat,
    options.repeatCount
  );
  const videoOutputCount = clampInt(firstFiniteInteger(
    options.videoOutputs,
    options.videoOutputCount,
    options.videoOutputsPerRow,
    outputCount
  ), 1, 100, undefined);
  const imageOutputCount = clampInt(firstFiniteInteger(
    options.imageOutputs,
    options.imageOutputCount,
    options.imageOutputsPerPrompt,
    outputCount
  ), 1, 100, undefined);
  const repeatCount = firstFiniteInteger(videoOutputCount, imageOutputCount, outputCount, options.repeatCount, 1);
  const model = firstNonEmptyString(options.model, options.videoModel, options.imageModel);
  const autonomy = normalizeAgentAutonomy(options.autonomy);
  return {
    ...options,
    repeatCount,
    videoLength: firstNonEmptyString(options.videoLength, options.length, options.duration, "8"),
    aspectRatio: firstNonEmptyString(options.aspectRatio, options.ratio, "portrait"),
    model,
    videoModel: firstNonEmptyString(options.videoModel, isVideoMode(options.mode) ? model : "", DEFAULT_VIDEO_MODEL),
    imageModel: firstNonEmptyString(options.imageModel, isImageMode(options.mode) ? model : "", DEFAULT_IMAGE_MODEL),
    videoOutputsPerRow: videoOutputCount ?? repeatCount,
    imageOutputsPerPrompt: imageOutputCount ?? repeatCount,
    autonomy,
    selfHeal: buildAgentSelfHealPolicy({ ...options, autonomy }),
    autoApprove: buildAgentAutoApprovePolicy({ ...options, autonomy })
  };
}

export function buildAgentRunProfile(bundle = {}, options = {}) {
  const matrix = bundle.matrix || {};
  const settings = matrix.settings || {};
  const mode = String(matrix.mode || options.mode || "agent");
  const normalized = normalizeAgentRunOptions({
    ...settings,
    ...options,
    mode
  });
  const autonomy = normalizeAgentAutonomy(normalized.autonomy || options.autonomy || settings.autonomy || matrix.autonomy);
  const isImageOnly = mode === "text-to-image";
  const videoOutputsPerRow = isImageOnly
    ? 0
    : clampInt(firstFiniteInteger(
        options.videoOutputs,
        options.videoOutputCount,
        options.videoOutputsPerRow,
        matrix.repeatCount,
        normalized.repeatCount
      ), 1, 100, 1);
  const imageOutputsPerPrompt = isImageOnly
    ? clampInt(firstFiniteInteger(
        options.imageOutputs,
        options.imageOutputCount,
        options.imageOutputsPerPrompt,
        matrix.repeatCount,
        normalized.repeatCount
      ), 1, 100, 1)
    : 1;

  return {
    source: "requested",
    confirmedInFlowUi: false,
    note: "Requested run profile. Flow UI/model dropdown remains the source of truth until settings automation confirms it.",
    mode,
    imageModel: firstNonEmptyString(options.imageModel, isImageOnly ? options.model : "", DEFAULT_IMAGE_MODEL),
    videoModel: isImageOnly ? "" : firstNonEmptyString(options.videoModel, options.model, settings.model, DEFAULT_VIDEO_MODEL),
    model: isImageOnly
      ? firstNonEmptyString(options.imageModel, options.model, settings.model, DEFAULT_IMAGE_MODEL)
      : firstNonEmptyString(options.videoModel, options.model, settings.model, DEFAULT_VIDEO_MODEL),
    aspectRatio: firstNonEmptyString(options.aspectRatio, options.ratio, settings.aspectRatio, normalized.aspectRatio),
    videoLength: isImageOnly ? "" : firstNonEmptyString(options.videoLength, options.length, options.duration, settings.videoLength, normalized.videoLength),
    videoOutputsPerRow,
    imageOutputsPerPrompt,
    autonomy,
    selfHeal: buildAgentSelfHealPolicy({ ...settings, ...options, autonomy }),
    autoApprove: buildAgentAutoApprovePolicy({ ...settings, ...options, autonomy }),
    expectedImages: bundle.expectedImages ?? bundle.manifestExpectedImages ?? matrix.expectedImages ?? 0,
    expectedVideos: bundle.expectedVideos ?? bundle.manifestExpectedVideos ?? matrix.expectedVideos ?? 0,
    returnSilentVideos: normalizeOptionalBoolean(options.returnSilentVideos ?? options.silentVideos ?? options.silentVideo ?? options.silent),
    autoDownload: {
      images: normalizeOptionalBoolean(options.autoDownloadImages ?? options.downloadImages, true),
      videos: normalizeOptionalBoolean(options.autoDownloadVideos ?? options.downloadVideos, true),
      refs: normalizeOptionalBoolean(options.autoDownloadRefs ?? options.downloadRefs, false),
      manifests: normalizeOptionalBoolean(options.autoDownloadManifests ?? options.downloadManifests, true)
    }
  };
}

export function missingRowsFromWaitProgress(wait = {}) {
  return uniqueStrings([
    ...normalizeStringArray(wait.progress?.missingVideoTags),
    ...normalizeStringArray(wait.progress?.missingImageTags)
  ]).map(normalizeRowId).filter(Boolean);
}

function isImageMode(mode = "") {
  return String(mode || "").toLowerCase() === "text-to-image";
}

function isVideoMode(mode = "") {
  return !isImageMode(mode);
}

function normalizeOptionalBoolean(value, fallback = null) {
  if (value === undefined || value === null || value === "") return fallback;
  if (value === true || value === false) return value;
  const text = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "on", "enabled"].includes(text)) return true;
  if (["0", "false", "no", "off", "disabled"].includes(text)) return false;
  return fallback;
}

function firstNonEmptyString(...values) {
  for (const value of values) {
    if (value === undefined || value === null || value === true || value === false) continue;
    const text = String(value).trim();
    if (text) return text;
  }
  return "";
}

function firstFiniteInteger(...values) {
  for (const value of values) {
    const parsed = Number.parseInt(value, 10);
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  const lower = Math.max(min, parsed);
  return max === undefined ? lower : Math.min(max, lower);
}

function normalizeStringArray(value) {
  return (Array.isArray(value) ? value : [])
    .map((entry) => String(entry || "").trim())
    .filter(Boolean);
}

function uniqueStrings(values = []) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))];
}

function normalizeRowId(value = "") {
  return String(value || "").trim().replace(/^\[/, "").replace(/\]$/, "");
}
