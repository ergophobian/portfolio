import { mkdir, open, readFile, readdir, rename, stat, unlink } from "node:fs/promises";
import crypto from "node:crypto";
import dns from "node:dns/promises";
import net from "node:net";
import path from "node:path";

export const DEFAULT_BROWSER_REF_IMPORT_MAX_BYTES = 32 * 1024 * 1024;
export const DEFAULT_BROWSER_REF_IMPORT_TTL_MS = 24 * 60 * 60 * 1000;
export const DEFAULT_BROWSER_REF_IMPORT_TIMEOUT_MS = 60_000;

// PatchWork's product-owned R2 bucket is an exact, public origin. Additional
// deployments must opt in through AUTOFLOW_REF_IMPORT_ORIGINS.
export const PATCHWORK_REF_IMPORT_ORIGINS = Object.freeze([
  "https://pub-41d1d99ea47d442592b42ae71b588835.r2.dev"
]);

const ALLOWED_MEDIA_MIME = /^(image|video|audio)\/[a-z0-9.+-]+$/i;
const MIME_EXTENSION = Object.freeze({
  "image/jpeg": ".jpeg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
  "audio/mpeg": ".mp3",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
  "audio/ogg": ".ogg"
});

export function parseRefImportOriginAllowlist(value, options = {}) {
  const values = [];
  if (options.includePatchWorkDefault !== false) values.push(...PATCHWORK_REF_IMPORT_ORIGINS);
  if (Array.isArray(value)) values.push(...value);
  else if (value && typeof value === "object" && Array.isArray(value.origins)) values.push(...value.origins);
  else values.push(...String(value ?? "").split(/[,\s]+/));
  return [...new Set(values.map(normalizeHttpsOrigin).filter(Boolean))];
}

export async function importBrowserReferenceFromUrl(payload = {}, options = {}) {
  const sourceUrl = parseSourceUrl(payload.sourceUrl);
  const allowedOrigins = parseRefImportOriginAllowlist(options.allowedOrigins, {
    includePatchWorkDefault: options.includePatchWorkDefault !== false
  });
  assertAllowedOrigin(sourceUrl, allowedOrigins);
  await assertPublicHostname(sourceUrl.hostname, options);

  const maxBytes = positiveInteger(options.maxBytes, DEFAULT_BROWSER_REF_IMPORT_MAX_BYTES);
  const abortController = new AbortController();
  const timeoutMs = positiveInteger(options.timeoutMs, DEFAULT_BROWSER_REF_IMPORT_TIMEOUT_MS);
  const timeout = setTimeout(() => abortController.abort(), timeoutMs);
  let response;
  let bytes;
  try {
    response = await fetchAllowedReference(sourceUrl, {
      ...options,
      signal: abortController.signal,
      allowedOrigins,
      maxRedirects: positiveInteger(options.maxRedirects, 3)
    });
  } catch (error) {
    clearTimeout(timeout);
    if (error?.name === "AbortError") {
      throw refImportError("REF_IMPORT_TIMEOUT", `Reference staging timed out after ${timeoutMs}ms.`, { timeoutMs });
    }
    throw error;
  }
  const contentType = normalizeMime(response.headers?.get?.("content-type") || "");
  const requestedMime = normalizeMime(payload.mimeType || "");
  if (!ALLOWED_MEDIA_MIME.test(contentType)) {
    clearTimeout(timeout);
    throw refImportError("REF_IMPORT_MIME_NOT_ALLOWED", `Reference URL returned unsupported content type ${contentType || "(missing)"}.`);
  }
  if (requestedMime && requestedMime !== contentType) {
    clearTimeout(timeout);
    throw refImportError("REF_IMPORT_MIME_MISMATCH", `Reference MIME mismatch: expected ${requestedMime}, received ${contentType}.`, {
      expected: requestedMime,
      actual: contentType
    });
  }

  const declaredLength = Number(response.headers?.get?.("content-length") || 0);
  if (declaredLength > maxBytes) {
    clearTimeout(timeout);
    throw refImportError("REF_IMPORT_TOO_LARGE", `Reference exceeds the ${maxBytes}-byte staging limit.`, {
      byteLength: declaredLength,
      maxBytes
    });
  }
  try {
    bytes = await readBoundedResponse(response, maxBytes);
  } catch (error) {
    if (error?.name === "AbortError") {
      throw refImportError("REF_IMPORT_TIMEOUT", `Reference staging timed out after ${timeoutMs}ms.`, { timeoutMs });
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
  const expectedLength = positiveInteger(payload.byteLength, 0);
  if (expectedLength && bytes.length !== expectedLength) {
    throw refImportError("REF_IMPORT_LENGTH_MISMATCH", `Reference length mismatch: expected ${expectedLength}, received ${bytes.length}.`, {
      expected: expectedLength,
      actual: bytes.length
    });
  }
  const sha256 = crypto.createHash("sha256").update(bytes).digest("hex");
  const expectedSha256 = normalizeSha256(payload.sha256 || "");
  if (expectedSha256 && sha256 !== expectedSha256) {
    throw refImportError("REF_IMPORT_SHA256_MISMATCH", "Reference SHA-256 did not match the PatchWork manifest.", {
      expected: expectedSha256,
      actual: sha256
    });
  }

  const runtimeDir = path.resolve(String(options.runtimeDir || ""));
  if (!runtimeDir || runtimeDir === path.parse(runtimeDir).root) {
    throw refImportError("REF_IMPORT_RUNTIME_DIR_INVALID", "Auto Flow reference staging directory is unavailable.");
  }
  const stagingDir = path.join(runtimeDir, "staged-refs");
  await mkdir(stagingDir, { recursive: true, mode: 0o700 });
  const nowMs = Number(options.now?.() ?? Date.now());
  const ttlMs = positiveInteger(options.ttlMs, DEFAULT_BROWSER_REF_IMPORT_TTL_MS);
  await cleanupExpiredStagedReferences(stagingDir, { nowMs, ttlMs });
  const extension = safeExtension(payload.fileName, contentType);
  const stagedRefId = `afref_${sha256.slice(0, 24)}`;
  const localPath = path.join(stagingDir, `${stagedRefId}${extension}`);
  const existing = await stat(localPath).catch(() => null);
  let deduplicated = Boolean(existing?.isFile() && existing.size === bytes.length);
  if (!deduplicated) {
    const tempPath = path.join(stagingDir, `.${stagedRefId}-${process.pid}-${crypto.randomBytes(6).toString("hex")}.tmp`);
    const handle = await open(tempPath, "wx", 0o600);
    try {
      await handle.writeFile(bytes);
      await handle.sync();
    } finally {
      await handle.close();
    }
    try {
      await rename(tempPath, localPath);
    } catch (error) {
      await unlink(tempPath).catch(() => {});
      const raced = await stat(localPath).catch(() => null);
      if (!raced?.isFile() || raced.size !== bytes.length) throw error;
      deduplicated = true;
    }
  } else if (options.verifyExistingHash !== false) {
    const existingBytes = await readFile(localPath);
    const existingSha = crypto.createHash("sha256").update(existingBytes).digest("hex");
    if (existingSha !== sha256) {
      throw refImportError("REF_IMPORT_STAGED_HASH_MISMATCH", "Existing staged reference failed its SHA-256 integrity check.", {
        stagedRefId
      });
    }
  }

  return {
    ok: true,
    stagedRefId,
    localPath,
    fileName: safeFileName(payload.fileName) || path.basename(localPath),
    mimeType: contentType,
    byteLength: bytes.length,
    sha256,
    sourceOrigin: sourceUrl.origin,
    deduplicated,
    expiresAt: new Date(nowMs + ttlMs).toISOString()
  };
}

export async function cleanupExpiredStagedReferences(stagingDir, options = {}) {
  const nowMs = Number(options.nowMs ?? Date.now());
  const ttlMs = positiveInteger(options.ttlMs, DEFAULT_BROWSER_REF_IMPORT_TTL_MS);
  const names = await readdir(stagingDir).catch(() => []);
  let removed = 0;
  for (const name of names) {
    if (!/^\.?afref_[a-f0-9]{24}(?:-[a-z0-9-]+)?(?:\.[a-z0-9]+|\.tmp)$/i.test(name)) continue;
    const candidate = path.join(stagingDir, name);
    const info = await stat(candidate).catch(() => null);
    if (!info?.isFile() || nowMs - info.mtimeMs < ttlMs) continue;
    await unlink(candidate).then(() => { removed += 1; }).catch(() => {});
  }
  return removed;
}

async function fetchAllowedReference(initialUrl, options) {
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== "function") {
    throw refImportError("REF_IMPORT_FETCH_UNAVAILABLE", "This Auto Flow broker runtime cannot fetch staged references.");
  }
  let current = initialUrl;
  for (let redirectCount = 0; redirectCount <= options.maxRedirects; redirectCount += 1) {
    assertAllowedOrigin(current, options.allowedOrigins);
    await assertPublicHostname(current.hostname, options);
    const response = await fetchImpl(current, {
      method: "GET",
      redirect: "manual",
      signal: options.signal,
      headers: { Accept: "image/*,video/*,audio/*" }
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers?.get?.("location") || "";
      if (!location) throw refImportError("REF_IMPORT_REDIRECT_INVALID", "Reference URL returned a redirect without a location.");
      if (redirectCount >= options.maxRedirects) throw refImportError("REF_IMPORT_REDIRECT_LIMIT", "Reference URL exceeded the redirect limit.");
      current = parseSourceUrl(new URL(location, current).href);
      continue;
    }
    if (!response.ok) {
      throw refImportError("REF_IMPORT_FETCH_FAILED", `Reference URL returned HTTP ${response.status}.`, { status: response.status });
    }
    return response;
  }
  throw refImportError("REF_IMPORT_REDIRECT_LIMIT", "Reference URL exceeded the redirect limit.");
}

async function readBoundedResponse(response, maxBytes) {
  if (!response.body || typeof response.body.getReader !== "function") {
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > maxBytes) throw refImportError("REF_IMPORT_TOO_LARGE", `Reference exceeds the ${maxBytes}-byte staging limit.`);
    return bytes;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = Buffer.from(value);
    total += chunk.length;
    if (total > maxBytes) {
      await reader.cancel().catch(() => {});
      throw refImportError("REF_IMPORT_TOO_LARGE", `Reference exceeds the ${maxBytes}-byte staging limit.`, { maxBytes });
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, total);
}

async function assertPublicHostname(hostname, options = {}) {
  if (options.skipNetworkAddressCheck === true) return;
  if (net.isIP(hostname)) {
    if (isPrivateAddress(hostname)) throw refImportError("REF_IMPORT_PRIVATE_NETWORK_FORBIDDEN", "Reference URL cannot target a private or local network address.");
    return;
  }
  const lookup = options.lookup || dns.lookup;
  let records;
  try {
    records = await lookup(hostname, { all: true, verbatim: true });
  } catch (error) {
    throw refImportError("REF_IMPORT_DNS_FAILED", "Reference hostname did not resolve.", { code: error?.code || "" });
  }
  if (!Array.isArray(records) || !records.length) throw refImportError("REF_IMPORT_DNS_FAILED", "Reference hostname did not resolve.");
  if (records.some((record) => isPrivateAddress(record.address))) {
    throw refImportError("REF_IMPORT_PRIVATE_NETWORK_FORBIDDEN", "Reference hostname resolves to a private or local network address.");
  }
}

export function isPrivateAddress(address = "") {
  const value = String(address).trim().toLowerCase();
  if (net.isIP(value) === 4) {
    const parts = value.split(".").map(Number);
    const [a, b] = parts;
    return a === 0 || a === 10 || a === 127 || a >= 224
      || (a === 100 && b >= 64 && b <= 127)
      || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 0)
      || (a === 192 && b === 168)
      || (a === 198 && (b === 18 || b === 19));
  }
  if (net.isIP(value) === 6) {
    return value === "::" || value === "::1" || value.startsWith("fc") || value.startsWith("fd")
      || /^fe[89ab]/.test(value) || value.startsWith("::ffff:127.") || value.startsWith("::ffff:10.")
      || value.startsWith("::ffff:192.168.");
  }
  return true;
}

function parseSourceUrl(value) {
  let url;
  try { url = new URL(String(value || "")); } catch {
    throw refImportError("REF_IMPORT_URL_INVALID", "agent.refs.importUrl requires a valid HTTPS sourceUrl.");
  }
  if (url.protocol !== "https:" || url.username || url.password) {
    throw refImportError("REF_IMPORT_URL_INVALID", "agent.refs.importUrl accepts HTTPS URLs without embedded credentials only.");
  }
  return url;
}

function normalizeHttpsOrigin(value) {
  try {
    const url = new URL(String(value || ""));
    return url.protocol === "https:" && !url.username && !url.password ? url.origin.toLowerCase() : "";
  } catch {
    return "";
  }
}

function assertAllowedOrigin(url, allowedOrigins) {
  if (!allowedOrigins.includes(url.origin.toLowerCase())) {
    throw refImportError("REF_IMPORT_ORIGIN_NOT_ALLOWED", `Reference origin is not allowlisted: ${url.origin}.`, {
      sourceOrigin: url.origin,
      allowedOriginCount: allowedOrigins.length
    });
  }
}

function normalizeMime(value) {
  return String(value || "").split(";", 1)[0].trim().toLowerCase();
}

function normalizeSha256(value) {
  const normalized = String(value || "").trim().toLowerCase().replace(/^sha256:/, "");
  if (!normalized) return "";
  if (!/^[a-f0-9]{64}$/.test(normalized)) throw refImportError("REF_IMPORT_SHA256_INVALID", "Reference sha256 must contain exactly 64 hexadecimal characters.");
  return normalized;
}

function safeFileName(value) {
  const base = path.basename(String(value || "")).replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^[-.]+/, "");
  return base.slice(0, 160);
}

function safeExtension(fileName, mimeType) {
  const fromMime = MIME_EXTENSION[mimeType];
  if (fromMime) return fromMime;
  const declared = path.extname(safeFileName(fileName)).toLowerCase();
  if (/^\.[a-z0-9]{1,8}$/.test(declared)) return declared;
  return ".bin";
}

function positiveInteger(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback;
}

function refImportError(code, message, details) {
  const error = new Error(message);
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}
