import { isFreeCreditText, extractCreditAmount } from "./agent-credit-text.js";

function resolveConfiguredCreditLimit(options = {}, env = {}, autoApprove = normalizeTokens(options.autoApprove ?? env.AUTOFLOW_AUTO_APPROVE ?? "")) {
  const configured = firstFiniteNumber(
    options.maxCreditsPerRun,
    options.autoApproveMaxCredits,
    options.autoApproveCreditsUpTo,
    options.creditCap,
    options.creditLimit,
    env.AUTOFLOW_AUTO_APPROVE_MAX_CREDITS,
    env.AUTOFLOW_MAX_CREDITS_PER_RUN,
    parseCreditLimitToken(autoApprove)
  );
  if (configured !== undefined && configured < 0) {
    const error = new Error(
      `Invalid credit cap ${configured}: maxCreditsPerRun/AUTOFLOW_MAX_CREDITS_PER_RUN must be a non-negative number (use 0 to block all credit spend).`
    );
    error.code = "INVALID_CREDIT_CAP";
    throw error;
  }
  return configured;
}

export function buildStandingCreditPolicy(options = {}, env = {}) {
  const autoApprove = normalizeTokens(options.autoApprove ?? env.AUTOFLOW_AUTO_APPROVE ?? "");
  const configuredMax = resolveConfiguredCreditLimit(options, env, autoApprove);
  const freeAlways = normalizeBoolean(
    options.autoApproveFree ?? options.autoApproveFreeTiers ?? env.AUTOFLOW_AUTO_APPROVE_FREE,
    autoApprove.size === 0 || autoApprove.has("free") || autoApprove.has("free-tiers") || autoApprove.has("free-tier") || autoApprove.has("free-always")
  );
  return {
    freeAlways,
    maxCreditsPerRun: Number.isFinite(configuredMax)
      ? Math.max(0, Number(configuredMax))
      : 0,
    limitConfigured: configuredMax !== undefined,
    persistentApproval: false,
    raw: [...autoApprove]
  };
}

export function hasStandingCreditLimit(options = {}, env = {}) {
  return resolveConfiguredCreditLimit(options, env) !== undefined;
}

function runtimeEnv() {
  return typeof process !== "undefined" && process && process.env ? process.env : {};
}

function resolveCaptainAuthorization(options = {}, env = options.env || runtimeEnv()) {
  const explicitFlags = [
    options.captainAuthorized,
    options.authorizedBatch
  ].map(explicitBoolean);
  const explicitAuthorized = explicitFlags.some((value) => value === true);
  const explicitDenied = explicitFlags.some((value) => value === false);
  const envAuthorized = normalizeBoolean(env?.AUTOFLOW_CAPTAIN_AUTHORIZED_BATCH, false)
    || normalizeBoolean(env?.AUTOFLOW_CAPTAIN_AUTHORIZED_CREDITS, false);
  return {
    captainAuthorized: !explicitDenied && (explicitAuthorized || envAuthorized),
    explicitAuthorized: explicitAuthorized && !explicitDenied
  };
}

export function isCaptainAuthorized(options = {}, env = options.env || runtimeEnv()) {
  return resolveCaptainAuthorization(options, env).captainAuthorized;
}

export function isConfirmCreditsAuthorized(options = {}, env = options.env || runtimeEnv()) {
  return (normalizeBoolean(options.confirmCredits, false) || normalizeBoolean(options.yesCredits, false))
    && isCaptainAuthorized(options, env);
}

export function isSubmitConfirmCreditsAuthorized(options = {}, env = options.env || runtimeEnv()) {
  return isConfirmCreditsAuthorized(options, env) && !hasStandingCreditLimit(options, env);
}

export function isCaptainExplicitlyAuthorized(options = {}) {
  return resolveCaptainAuthorization(options, {}).explicitAuthorized;
}

export function buildCaptainAuthorizedCreditApproval(options = {}, env = options.env || runtimeEnv()) {
  const { captainAuthorized, explicitAuthorized } = resolveCaptainAuthorization(options, env);
  return {
    approved: captainAuthorized,
    reason: captainAuthorized
      ? "captain_authorized_batch"
      : "captain_authorization_required",
    persistentApproval: explicitAuthorized === true
  };
}

export function resolveCreditApprovalDecision(standingDecision = {}, captainApproval = {}) {
  if (standingDecision.approved === true) {
    return { ...standingDecision, persistentApproval: false };
  }
  if (standingDecision.reason === "credit_amount_unknown") {
    return {
      approved: false,
      reason: "credit_amount_unknown",
      creditAmount: standingDecision.creditAmount,
      remainingCredits: standingDecision.remainingCredits,
      persistentApproval: false
    };
  }
  if (standingDecision.reason === "credit_policy_exceeded" && standingDecision.limitConfigured === true) {
    return {
      approved: false,
      reason: "standing_credit_limit_configured",
      creditAmount: standingDecision.creditAmount,
      remainingCredits: standingDecision.remainingCredits,
      persistentApproval: false
    };
  }
  return {
    ...captainApproval,
    creditAmount: standingDecision.creditAmount,
    remainingCredits: standingDecision.remainingCredits
  };
}

export function resolveCreditPersistentApproval(approvalDecision = {}, options = {}) {
  if (approvalDecision.approved !== true || approvalDecision.reason !== "captain_authorized_batch") {
    return false;
  }
  return approvalDecision.persistentApproval === true
    || options.dontAskAgain === true
    || options.persistentApproval === true;
}

export function createCreditPolicyState(policy = {}) {
  return {
    policy,
    approvedCredits: 0,
    decisions: []
  };
}

export function evaluateStandingCreditPolicy(action = {}, context = {}, state = createCreditPolicyState()) {
  const policy = state.policy || {};
  const text = latestActionText(context);
  const actionAmount = Number(action.creditAmount);
  const textAmount = extractCreditAmount(text);
  const hasActionAmount = action.creditAmount !== undefined
    && action.creditAmount !== null
    && action.creditAmount !== ""
    && Number.isFinite(actionAmount)
    && (action.creditAmountKnown === true || actionAmount > 0);
  const amount = hasActionAmount ? actionAmount : textAmount;
  const amountKnown = action.creditAmountKnown === true || hasActionAmount || textAmount > 0 || isFreeCreditText(text);
  const hasPositiveKnownAmount = amountKnown && amount > 0;
  const freeTier = !hasPositiveKnownAmount && (action.freeTier === true || isFreeCreditText(text));
  if (freeTier && policy.freeAlways !== false) {
    return recordDecision(state, {
      approved: true,
      reason: "free_tier",
      creditAmount: 0,
      remainingCredits: remainingCredits(policy, state)
    });
  }
  if (!amountKnown) {
    return recordDecision(state, {
      approved: false,
      reason: "credit_amount_unknown",
      creditAmount: amount,
      remainingCredits: remainingCredits(policy, state)
    });
  }
  const remaining = remainingCredits(policy, state);
  if (amount > 0 && amount <= remaining) {
    state.approvedCredits += amount;
    return recordDecision(state, {
      approved: true,
      reason: "within_credit_limit",
      creditAmount: amount,
      remainingCredits: remainingCredits(policy, state)
    });
  }
  return recordDecision(state, {
    approved: false,
    reason: "credit_policy_exceeded",
    creditAmount: amount,
    remainingCredits: remaining,
    limitConfigured: policy.limitConfigured === true
  });
}

function recordDecision(state = {}, decision = {}) {
  const normalized = {
    approved: decision.approved === true,
    reason: String(decision.reason || ""),
    creditAmount: Number.isFinite(Number(decision.creditAmount)) ? Number(decision.creditAmount) : 0,
    remainingCredits: Number.isFinite(Number(decision.remainingCredits)) ? Number(decision.remainingCredits) : 0,
    ...(decision.limitConfigured === true ? { limitConfigured: true } : {})
  };
  if (Array.isArray(state.decisions)) state.decisions.push(normalized);
  return normalized;
}

function remainingCredits(policy = {}, state = {}) {
  const max = Number(policy.maxCreditsPerRun);
  if (!Number.isFinite(max)) return 0;
  return Math.max(0, max - Number(state.approvedCredits || 0));
}

function latestActionText(context = {}) {
  const messages = Array.isArray(context.latestMessages) ? context.latestMessages : [];
  const latest = messages.at(-1);
  return [
    context.text,
    context.rawText,
    latest?.text,
    context.actionRequired?.text,
    context.action?.recommendedAction
  ].map((value) => String(value || "")).join(" ");
}

function normalizeTokens(value = "") {
  const raw = Array.isArray(value) ? value : String(value || "").split(",");
  return new Set(raw.map((entry) => String(entry || "").trim().toLowerCase().replace(/_/g, "-")).filter(Boolean));
}

function parseCreditLimitToken(tokens = new Set()) {
  for (const token of tokens) {
    const match = String(token || "").match(/(?:credits?|<=|up-to|max|limit)[^\d]*(\d+)/i)
      || String(token || "").match(/^<=?(\d+)$/);
    if (match) return Number(match[1]);
  }
  return undefined;
}

function explicitBoolean(value) {
  if (value === undefined || value === null || value === "") return undefined;
  if (value === true || value === false) return value;
  const text = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "on", "enabled", "always"].includes(text)) return true;
  if (["0", "false", "no", "off", "disabled", "never"].includes(text)) return false;
  return undefined;
}

export function normalizeBoolean(value, fallback = false) {
  const parsed = explicitBoolean(value);
  return parsed === undefined ? fallback : parsed;
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    if (value === undefined || value === null || value === "" || value === true || value === false) continue;
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}
