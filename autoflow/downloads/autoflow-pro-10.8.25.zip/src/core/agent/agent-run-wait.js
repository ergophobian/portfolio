const DEFAULT_INITIAL_QUIET_MS = 3000;
const DEFAULT_POLL_INTERVAL_MS = 5000;
const DEFAULT_TIMEOUT_MS = 20 * 60 * 1000;
const MAX_TIMEOUT_MS = 24 * 60 * 60 * 1000;
export function buildAgentRunWaitPollingPlan(options = {}) {
  const timeoutMs = clampDurationMs(
    firstFiniteNumber(options.timeoutMs, options.waitTimeoutMs),
    DEFAULT_TIMEOUT_MS,
    1,
    MAX_TIMEOUT_MS
  );
  const initialQuietMs = clampDurationMs(
    firstFiniteNumber(options.initialQuietMs, options.quietDelayMs, options.quietMs),
    DEFAULT_INITIAL_QUIET_MS,
    0,
    timeoutMs
  );
  const pollIntervalMs = clampDurationMs(
    firstFiniteNumber(options.pollIntervalMs, options.tightPollMs, options.tightMs, options.pollMs),
    DEFAULT_POLL_INTERVAL_MS,
    1,
    timeoutMs
  );

  return {
    strategy: "quiet_then_tight",
    initialQuietMs,
    pollIntervalMs,
    timeoutMs,
    stalledNoProgressPolls: nonNegativeInteger(firstFiniteNumber(
      options.stalledNoProgressPolls,
      options.noProgressPolls,
      options.maxUnchangedPolls
    ))
  };
}

export async function waitForAgentRunCompletion(options = {}) {
  if (typeof options.reconcile !== "function") {
    throw new TypeError("waitForAgentRunCompletion requires a reconcile function.");
  }

  const plan = buildAgentRunWaitPollingPlan(options);
  const now = typeof options.now === "function" ? options.now : Date.now;
  const sleep = typeof options.sleep === "function" ? options.sleep : defaultSleep;
  const startedAtMs = timestampMs(now());
  const deadlineMs = startedAtMs + plan.timeoutMs;
  const expected = {
    expectedImages: options.expectedImages ?? options.expectedImageCount,
    expectedVideos: options.expectedVideos ?? options.expectedVideoCount
  };
  const errors = [];
  const history = [];
  let attempts = 0;
  let lastProgress = summarizeAgentRunWaitProgress({}, expected);
  let previousProgressSignature = "";
  let unchangedProgressPolls = 0;

  if (plan.initialQuietMs > 0) {
    await sleep(Math.min(plan.initialQuietMs, Math.max(0, deadlineMs - timestampMs(now()))));
  }

  while (timestampMs(now()) < deadlineMs) {
    attempts += 1;
    const attemptStartedAtMs = timestampMs(now());
    try {
      const snapshot = await options.reconcile({
        attempt: attempts,
        startedAtMs,
        elapsedMs: Math.max(0, attemptStartedAtMs - startedAtMs)
      });
      lastProgress = summarizeAgentRunWaitProgress(snapshot, expected);
      const progressSignature = agentRunWaitProgressSignature(lastProgress);
      if (progressSignature && progressSignature === previousProgressSignature) {
        unchangedProgressPolls += 1;
      } else {
        previousProgressSignature = progressSignature;
        unchangedProgressPolls = 0;
      }
      history.push({
        attempt: attempts,
        atMs: attemptStartedAtMs,
        elapsedMs: Math.max(0, attemptStartedAtMs - startedAtMs),
        progress: lastProgress,
        unchangedProgressPolls
      });
      if (lastProgress.complete) {
        return buildRunWaitResult({
          ok: true,
          status: "complete",
          plan,
          attempts,
          startedAtMs,
          finishedAtMs: timestampMs(now()),
          progress: lastProgress,
          errors,
          history
        });
      }
      if (typeof options.inspect === "function") {
        const inspection = await options.inspect({
          attempt: attempts,
          snapshot,
          progress: lastProgress,
          startedAtMs,
          elapsedMs: Math.max(0, attemptStartedAtMs - startedAtMs)
        });
        if (inspection?.stop === true) {
          history[history.length - 1] = {
            ...history[history.length - 1],
            inspection: serializeRunWaitInspection(inspection)
          };
          return buildRunWaitResult({
            ok: false,
            status: compactString(inspection.status) || "blocked",
            plan,
            attempts,
            startedAtMs,
            finishedAtMs: timestampMs(now()),
            progress: lastProgress,
            errors,
            history,
            inspection
          });
        }
        if (isAgentQueueWaitInspection(inspection)) {
          unchangedProgressPolls = 0;
          history[history.length - 1] = {
            ...history[history.length - 1],
            unchangedProgressPolls
          };
        }
      }
      if (
        plan.stalledNoProgressPolls > 0
        && unchangedProgressPolls >= plan.stalledNoProgressPolls
        && hasIncompleteExpectedProgress(lastProgress)
      ) {
        const inspection = buildStalledNoProgressInspection({
          progress: lastProgress,
          unchangedProgressPolls,
          defaultMode: options.defaultMode || options.retryMode
        });
        history[history.length - 1] = {
          ...history[history.length - 1],
          inspection: serializeRunWaitInspection(inspection)
        };
        return buildRunWaitResult({
          ok: false,
          status: "stalled_no_progress",
          plan,
          attempts,
          startedAtMs,
          finishedAtMs: timestampMs(now()),
          progress: lastProgress,
          errors,
          history,
          inspection
        });
      }
    } catch (error) {
      const serialized = serializeRunWaitError(error);
      errors.push(serialized);
      history.push({
        attempt: attempts,
        atMs: attemptStartedAtMs,
        elapsedMs: Math.max(0, attemptStartedAtMs - startedAtMs),
        error: serialized
      });
    }

    const remainingMs = deadlineMs - timestampMs(now());
    if (remainingMs <= 0) break;
    await sleep(Math.min(plan.pollIntervalMs, remainingMs));
  }

  return buildRunWaitResult({
    ok: false,
    status: "timeout",
    plan,
    attempts,
    startedAtMs,
    finishedAtMs: timestampMs(now()),
    progress: lastProgress,
    errors,
    history
  });
}

export function summarizeAgentRunWaitProgress(reconcileResult = {}, expected = {}) {
  const body = unwrapReconcileResult(reconcileResult);
  const rows = Array.isArray(body.rows) ? body.rows : [];
  const rowExpectedImages = sumRows(rows, ["expectedImages", "expectedImageCount"]);
  const rowExpectedVideos = sumRows(rows, ["expectedVideos", "expectedVideoCount"]);
  const rowPresentImages = sumRows(rows, ["presentImages", "mappedImages"])
    ?? countRowMedia(rows, ["images", "imageVersions"]);
  const rowPresentVideos = sumRows(rows, ["presentVideos"])
    ?? countRowMedia(rows, ["videoVersions", "videos"]);
  const rowMissingImageTags = missingRowsForMedia(
    rows,
    ["expectedImages", "expectedImageCount"],
    ["presentImages", "mappedImages"],
    ["images", "imageVersions"]
  );
  const rowMissingVideoTags = missingRowsForMedia(
    rows,
    ["expectedVideos", "expectedVideoCount"],
    ["presentVideos"],
    ["videoVersions", "videos"]
  );
  const expectedImages = nonNegativeInteger(firstFiniteNumber(
    expected.expectedImages,
    expected.expectedImageCount,
    body.expectedImages,
    body.expectedImageCount,
    reconcileResult.expectedImages,
    reconcileResult.expectedImageCount,
    rowExpectedImages
  ));
  const expectedVideos = nonNegativeInteger(firstFiniteNumber(
    expected.expectedVideos,
    expected.expectedVideoCount,
    body.expectedVideos,
    body.expectedVideoCount,
    reconcileResult.expectedVideos,
    reconcileResult.expectedVideoCount,
    body.rows?.expected,
    rowExpectedVideos
  ));
  const presentImages = nonNegativeInteger(firstFiniteNumber(
    body.presentImages,
    body.mappedImages,
    body.imageCount,
    body.media?.images,
    reconcileResult.presentImages,
    reconcileResult.mappedImages,
    reconcileResult.media?.images,
    rowPresentImages
  ));
  const presentVideos = nonNegativeInteger(firstFiniteNumber(
    body.presentVideos,
    body.videoCount,
    body.media?.videos,
    reconcileResult.presentVideos,
    reconcileResult.media?.videos,
    body.rows?.present,
    rowPresentVideos
  ));
  const missingImages = Math.max(0, expectedImages - presentImages);
  const missingVideos = Math.max(0, expectedVideos - presentVideos);
  const hasExpectation = expectedImages > 0 || expectedVideos > 0;
  const imagesComplete = expectedImages <= 0 || presentImages >= expectedImages;
  const videosComplete = expectedVideos <= 0 || presentVideos >= expectedVideos;
  const complete = hasExpectation && imagesComplete && videosComplete;

  return {
    expectedImages,
    presentImages,
    missingImages,
    imagesComplete,
    expectedVideos,
    presentVideos,
    missingVideos,
    videosComplete,
    complete,
    partial: !complete && (presentImages > 0 || presentVideos > 0),
    missingImageTags: firstNonEmptyStringArray(body.missingImageTags, reconcileResult.missingImageTags, rowMissingImageTags),
    missingVideoTags: firstNonEmptyStringArray(body.missingVideoTags, body.rows?.missingRows, reconcileResult.missingVideoTags, rowMissingVideoTags)
  };
}

function buildRunWaitResult({
  ok,
  status,
  plan,
  attempts,
  startedAtMs,
  finishedAtMs,
  progress,
  errors,
  history,
  inspection = null
}) {
  return {
    ok,
    status,
    complete: status === "complete",
    partial: progress.partial,
    timedOut: status === "timeout",
    stalled: status === "stalled_no_progress",
    waitingForUser: status === "waiting_for_user" || status === "waiting_for_credit_approval",
    blocked: status === "blocked" || status === "retryable_blocker" || status === "waiting_for_user" || status === "waiting_for_credit_approval" || status === "stalled_no_progress",
    blockedReason: compactString(inspection?.reason),
    retryable: status === "retryable_blocker",
    ...(inspection ? { inspection: serializeRunWaitInspection(inspection) } : {}),
    ...(inspection?.retry ? { retry: inspection.retry } : {}),
    ...(inspection?.blocker ? { blocker: inspection.blocker } : {}),
    attempts,
    startedAtMs,
    finishedAtMs,
    elapsedMs: Math.max(0, finishedAtMs - startedAtMs),
    polling: plan,
    progress,
    errors,
    history
  };
}

function buildStalledNoProgressInspection({
  progress = {},
  unchangedProgressPolls = 0,
  defaultMode = ""
} = {}) {
  const missingImageTags = normalizeStringArray(progress.missingImageTags);
  const missingVideoTags = normalizeStringArray(progress.missingVideoTags);
  const missingRows = normalizeStringArray(progress.missingRows);
  const imagesMissing = progress.missingImages > 0 || missingImageTags.length > 0;
  const videosMissing = progress.missingVideos > 0 || missingVideoTags.length > 0;
  let mode = compactString(defaultMode) || "mixed-media";
  let missingTags = firstNonEmptyStringArray(missingRows, missingImageTags, missingVideoTags);

  if (imagesMissing && !videosMissing) {
    mode = "image-only";
    missingTags = firstNonEmptyStringArray(missingImageTags, missingRows);
  } else if (videosMissing && !imagesMissing) {
    mode = "video-only";
    missingTags = firstNonEmptyStringArray(missingVideoTags, missingRows);
  } else if (imagesMissing && videosMissing) {
    missingTags = uniqueStrings([...missingImageTags, ...missingVideoTags, ...missingRows]);
  }

  const rows = normalizeStringArray(missingTags)
    .map((row) => row.replace(/^\[/, "").replace(/\]$/, ""))
    .filter(Boolean);
  return {
    stop: true,
    status: "stalled_no_progress",
    reason: "agent_stalled_no_progress",
    blocker: {
      failureClass: "agent_stalled_no_progress",
      category: "stalled_no_progress",
      retryable: false,
      retryableWithPromptEdit: false,
      unchangedProgressPolls,
      recommendedAction: "Inspect the Flow Agent context or screenshot before retrying; no queued/running signal accompanied repeated unchanged reconcile snapshots."
    },
    retry: {
      rows,
      issue: "stalled no progress",
      mode,
      needsContextInspection: true
    }
  };
}

function hasIncompleteExpectedProgress(progress = {}) {
  return (
    (progress.expectedImages > 0 && progress.presentImages < progress.expectedImages)
    || (progress.expectedVideos > 0 && progress.presentVideos < progress.expectedVideos)
  );
}

function agentRunWaitProgressSignature(progress = {}) {
  return JSON.stringify({
    expectedImages: nonNegativeInteger(progress.expectedImages),
    presentImages: nonNegativeInteger(progress.presentImages),
    expectedVideos: nonNegativeInteger(progress.expectedVideos),
    presentVideos: nonNegativeInteger(progress.presentVideos),
    missingImageTags: normalizeStringArray(progress.missingImageTags),
    missingVideoTags: normalizeStringArray(progress.missingVideoTags)
  });
}

function isAgentQueueWaitInspection(inspection = {}) {
  return inspection?.runningSignal === "queue_wait"
    || inspection?.category === "queue_wait"
    || inspection?.reason === "agent_queue_wait";
}

function unwrapReconcileResult(input = {}) {
  if (input?.result && typeof input.result === "object") return input.result;
  if (input?.reconciliation && typeof input.reconciliation === "object") return input.reconciliation;
  if (input?.payload?.result && typeof input.payload.result === "object") return input.payload.result;
  if (input?.response?.result && typeof input.response.result === "object") return input.response.result;
  if (input?.response?.payload?.result && typeof input.response.payload.result === "object") return input.response.payload.result;
  return input && typeof input === "object" ? input : {};
}

function sumRows(rows = [], fields = []) {
  if (!rows.length) return undefined;
  let sum = 0;
  let found = false;
  for (const row of rows) {
    const value = firstFiniteNumber(...fields.map((field) => row?.[field]));
    if (value === undefined) continue;
    found = true;
    sum += nonNegativeInteger(value);
  }
  return found ? sum : undefined;
}

function countRowMedia(rows = [], fields = []) {
  if (!rows.length) return undefined;
  let sum = 0;
  let found = false;
  for (const row of rows) {
    for (const field of fields) {
      const value = row?.[field];
      if (!Array.isArray(value)) continue;
      found = true;
      sum += value.length;
      break;
    }
  }
  return found ? sum : undefined;
}

function missingRowsForMedia(rows = [], expectedFields = [], presentFields = [], arrayFields = []) {
  if (!rows.length) return [];
  const missing = [];
  for (const row of rows) {
    const expected = firstFiniteNumber(...expectedFields.map((field) => row?.[field]));
    if (expected === undefined || nonNegativeInteger(expected) <= 0) continue;
    const presentValue = firstFiniteNumber(...presentFields.map((field) => row?.[field]));
    const present = presentValue === undefined
      ? countMediaOnRow(row, arrayFields)
      : nonNegativeInteger(presentValue);
    if (present >= nonNegativeInteger(expected)) continue;
    const rowId = compactString(row?.rowId || row?.tag || row?.videoTag || row?.id || row?.sceneId);
    if (rowId) missing.push(rowId);
  }
  return uniqueStrings(missing);
}

function countMediaOnRow(row = {}, fields = []) {
  for (const field of fields) {
    const value = row?.[field];
    if (Array.isArray(value)) return value.length;
  }
  return 0;
}

function serializeRunWaitError(error) {
  return {
    code: String(error?.code || error?.name || "reconcile_error"),
    message: String(error?.message || error || "Reconcile failed."),
    ...(error?.response ? { response: error.response } : {}),
    ...(error?.details ? { details: error.details } : {})
  };
}

function serializeRunWaitInspection(inspection = {}) {
  return {
    stop: inspection.stop === true,
    status: compactString(inspection.status),
    reason: compactString(inspection.reason),
    ...(inspection.actionRequired ? { actionRequired: inspection.actionRequired } : {}),
    ...(inspection.actionResolution ? { actionResolution: inspection.actionResolution } : {}),
    ...(inspection.creditPolicy ? { creditPolicy: inspection.creditPolicy } : {}),
    ...(inspection.retry ? { retry: inspection.retry } : {}),
    ...(inspection.blocker ? { blocker: inspection.blocker } : {})
  };
}

function normalizeStringArray(value) {
  return (Array.isArray(value) ? value : [])
    .map((item) => String(item || "").trim())
    .filter(Boolean);
}

function firstNonEmptyStringArray(...values) {
  for (const value of values) {
    const normalized = normalizeStringArray(value);
    if (normalized.length) return normalized;
  }
  return [];
}

function uniqueStrings(values = []) {
  return [...new Set(values)];
}

function compactString(value = "") {
  return String(value || "").trim();
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    if (value === undefined || value === null || value === "" || value === true || value === false) continue;
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return undefined;
}

function nonNegativeInteger(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  return Math.max(0, Math.floor(number));
}

function clampDurationMs(value, fallback, min, max) {
  const number = Number.isFinite(Number(value)) ? Number(value) : fallback;
  return Math.min(max, Math.max(min, Math.floor(number)));
}

function timestampMs(value) {
  if (value instanceof Date) return value.getTime();
  const number = Number(value);
  return Number.isFinite(number) ? number : Date.now();
}

function defaultSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
