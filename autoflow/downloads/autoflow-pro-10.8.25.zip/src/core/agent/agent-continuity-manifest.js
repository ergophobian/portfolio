const SOURCE_TYPES = new Set(["flow-generated", "local-upload", "external"]);
const MEDIA_KIND_ORDER = { image: 1, video: 2 };

export const AGENT_CONTINUITY_FOLDERS = Object.freeze({
  images: "images/",
  videos: "videos/",
  refs: "refs/",
  manifests: "manifests/",
  transcripts: "transcripts/",
  retryPrompts: "retry-prompts/"
});

export const AGENT_CONTINUITY_SOURCE_TYPES = Object.freeze([...SOURCE_TYPES]);

export function buildAgentContinuityPathTemplates() {
  return {
    images: "images/{rowOrder}_{rowId}_{slotId}_{slug}_{mediaId}.jpeg",
    videos: "videos/{rowOrder}_{rowId}_{slug}_v{version}_{retry?}_{mediaId}.mp4",
    refs: "refs/{rowId}_{refId}.{ext}",
    manifests: "manifests/{manifestName}.json",
    transcripts: "transcripts/{videoStem}.{txt,json}",
    retryPrompts: "retry-prompts/retry-{rowId}.txt"
  };
}

export function buildAgentContinuityManifest(options = {}) {
  const sourceRows = normalizeSourceRows(options.reconciledRows || options.rows || []);
  const artifactEntries = normalizeArtifactEntries(options.artifactPlan || options.artifactEntries || options.downloads || []);
  const rowContexts = buildRowContexts(sourceRows, artifactEntries);
  const entriesByRow = groupEntriesByRow(artifactEntries);
  const mediaById = indexByMediaId(artifactEntries);

  const rows = [...rowContexts.values()]
    .sort(compareRows)
    .map((context) => buildContinuityRow(context, entriesByRow.get(context.rowId) || [], mediaById));
  const promotedRefs = rows.flatMap((row) => row.promotedRefs);
  const refs = rows.flatMap((row) => row.refs);
  const media = rows.flatMap((row) => row.media);
  const manifest = {
    version: 1,
    kind: "agent_continuity_manifest",
    runName: compactString(options.runName || options.name || options.artifactPlan?.runName || ""),
    runSlug: compactString(options.runSlug || options.artifactPlan?.runSlug || ""),
    outputRoot: compactString(options.outputRoot || options.artifactPlan?.outputRoot || ""),
    runFolder: compactString(options.runFolder || options.artifactPlan?.runFolder || ""),
    folders: AGENT_CONTINUITY_FOLDERS,
    templates: buildAgentContinuityPathTemplates(),
    sourceTypes: AGENT_CONTINUITY_SOURCE_TYPES,
    summary: {
      rows: rows.length,
      flowGenerated: media.filter((entry) => entry.sourceType === "flow-generated").length,
      localUploads: refs.filter((entry) => entry.sourceType === "local-upload").length,
      external: refs.filter((entry) => entry.sourceType === "external").length,
      promotedRefs: promotedRefs.length
    },
    rows,
    promotedRefs
  };
  const createdAt = compactString(options.createdAt || "");
  if (createdAt) manifest.createdAt = createdAt;
  return manifest;
}

function buildRowContexts(sourceRows = [], artifactEntries = []) {
  const contexts = new Map();
  for (const row of sourceRows) {
    contexts.set(row.rowId, {
      rowId: row.rowId,
      rowIndex: row.rowIndex,
      title: row.title,
      characterIds: row.characterIds,
      productIds: row.productIds,
      refs: row.refs,
      promotedRefs: row.promotedRefs
    });
  }
  for (const entry of artifactEntries) {
    if (!contexts.has(entry.rowId)) {
      contexts.set(entry.rowId, {
        rowId: entry.rowId,
        rowIndex: entry.rowIndex,
        title: "",
        characterIds: [],
        productIds: [],
        refs: [],
        promotedRefs: []
      });
    }
  }
  return contexts;
}

function buildContinuityRow(context = {}, artifactEntries = [], mediaById = new Map()) {
  const sortedEntries = artifactEntries.slice().sort(compareArtifactEntries);
  const media = sortedEntries.map((entry) => flowGeneratedMediaEntry(entry, context));
  const refs = normalizeRefs(context.refs, context, mediaById);
  const promotedRefs = normalizePromotedRefs(context.promotedRefs, context, mediaById);
  return {
    rowId: context.rowId,
    rowIndex: context.rowIndex,
    title: context.title,
    characterIds: context.characterIds,
    productIds: context.productIds,
    media,
    refs,
    promotedRefs
  };
}

function flowGeneratedMediaEntry(entry = {}, context = {}) {
  return compactObject({
    kind: entry.kind,
    sourceType: "flow-generated",
    rowId: entry.rowId,
    slotId: entry.slotId,
    version: entry.version,
    mediaId: entry.mediaId,
    localPath: entry.localPath,
    relativePath: entry.relativePath,
    prompt: entry.prompt,
    qaStatus: entry.qaStatus,
    isLatest: entry.isLatest,
    isRetry: entry.isRetry,
    characterIds: context.characterIds,
    productIds: context.productIds
  });
}

function normalizeSourceRows(rows = []) {
  return (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeSourceRow(row, index))
    .filter(Boolean);
}

function normalizeSourceRow(row = {}, index = 0) {
  const rowId = rowIdFromRow(row);
  if (!rowId) throw new Error(`Continuity manifest missing row id at row ${index + 1}.`);
  validateRowMediaIds(row, rowId);
  return {
    source: row,
    rowId,
    rowIndex: parsePositiveInt(row.rowIndex || row.clipNumber, index + 1),
    title: compactString(row.title || row.name || ""),
    characterIds: uniqueStrings(row.characterIds || row.characters || row.characterId),
    productIds: uniqueStrings(row.productIds || row.products || row.productId),
    refs: normalizeRefSources(row.refs || row.references || row.localRefs || [], rowId),
    promotedRefs: normalizePromotedRefSources(row.promotedRefs || row.promotedReferences || [], rowId)
  };
}

function validateRowMediaIds(row = {}, rowId = "") {
  for (const image of rowImages(row)) {
    if (!mediaIdFrom(image)) throw new Error(`Continuity manifest missing media id for image in row ${rowId}.`);
  }
  for (const video of rowVideos(row)) {
    if (!mediaIdFrom(video)) throw new Error(`Continuity manifest missing media id for video in row ${rowId}.`);
  }
  for (const ref of normalizePromotedRefSources(row.promotedRefs || row.promotedReferences || [], rowId)) {
    if (!mediaIdFrom(ref)) throw new Error(`Continuity manifest missing media id for promoted ref ${ref.refId || ""} in row ${rowId}.`);
  }
}

function rowImages(row = {}) {
  const images = Array.isArray(row.images) && row.images.length
    ? row.images
    : Array.isArray(row.generatedImages)
      ? row.generatedImages
      : [];
  return images.filter((image) => image && typeof image === "object");
}

function rowVideos(row = {}) {
  const videos = [
    ...(Array.isArray(row.videoVersions) ? row.videoVersions : []),
    ...(Array.isArray(row.videos) ? row.videos : []),
    ...(row.video && typeof row.video === "object" ? [row.video] : []),
    ...(row.latestVideo && typeof row.latestVideo === "object" ? [row.latestVideo] : [])
  ];
  const seen = new Set();
  return videos.filter((video) => {
    if (!video || typeof video !== "object") return false;
    const mediaId = mediaIdFrom(video);
    const key = mediaId || `missing:${seen.size}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizeArtifactEntries(input = []) {
  const entries = [];
  if (Array.isArray(input)) {
    entries.push(...input.map((entry) => normalizeArtifactEntry(entry)).filter(Boolean));
    return dedupeArtifactEntries(entries);
  }
  const plan = input && typeof input === "object" ? input : {};
  const downloads = Array.isArray(plan.downloads)
    ? plan.downloads
    : Array.isArray(plan.mediaDownloads)
      ? plan.mediaDownloads
      : [];
  entries.push(...downloads.map((entry) => normalizeArtifactEntry(entry)).filter(Boolean));
  for (const row of planManifestRows(plan)) {
    for (const image of Array.isArray(row.images) ? row.images : []) {
      entries.push(normalizeArtifactEntry({ ...image, kind: "image", rowId: row.rowId }));
    }
    for (const video of Array.isArray(row.videos) ? row.videos : []) {
      entries.push(normalizeArtifactEntry({ ...video, kind: "video", rowId: row.rowId }));
    }
  }
  return dedupeArtifactEntries(entries);
}

function normalizeArtifactEntry(entry = {}) {
  if (!entry || typeof entry !== "object") return null;
  const kind = normalizeKind(entry.kind || entry.mediaKind);
  if (!kind) return null;
  const rowId = normalizeRowId(entry.rowId || entry.tag || entry.videoTag || "");
  if (!rowId) throw new Error(`Continuity manifest missing row id for ${kind} artifact.`);
  const mediaId = mediaIdFrom(entry);
  if (!mediaId) throw new Error(`Continuity manifest missing media id for ${kind} artifact in row ${rowId}.`);
  const localPath = compactString(entry.localPath || entry.filename || entry.path || entry.sourcePath || "");
  const relativePath = compactString(entry.relativePath || "");
  return compactObject({
    kind,
    rowId,
    rowIndex: parsePositiveInt(entry.rowIndex || entry.clipNumber, 0),
    slotId: compactString(entry.slotId || entry.imageAuditId || entry.afid || ""),
    version: parsePositiveInt(entry.version, 0) || undefined,
    mediaId,
    localPath,
    relativePath,
    prompt: compactString(entry.prompt || entry.sourcePrompt || ""),
    qaStatus: compactString(entry.qaStatus || ""),
    isLatest: entry.isLatest === true ? true : undefined,
    isRetry: entry.isRetry === true ? true : undefined
  });
}

function planManifestRows(plan = {}) {
  const rows = Array.isArray(plan.manifest?.rows) ? plan.manifest.rows : [];
  return rows.filter((row) => row && typeof row === "object");
}

function normalizeRefs(refs = [], context = {}, mediaById = new Map()) {
  return asArray(refs).map((ref, index) => {
    const sourceType = normalizeSourceType(ref.sourceType || inferRefSourceType(ref));
    const refId = compactString(ref.refId || ref.id || ref.name || "");
    if (!refId) throw new Error(`Continuity manifest missing ref id for row ${context.rowId}.`);
    if (sourceType === "flow-generated") {
      const mediaId = mediaIdFrom(ref);
      if (!mediaId) throw new Error(`Continuity manifest missing media id for flow-generated ref ${refId} in row ${context.rowId}.`);
      const artifact = mediaById.get(mediaId);
      if (!artifact) throw new Error(`Continuity manifest cannot promote missing flow artifact ${mediaId} for row ${context.rowId}.`);
      return compactObject({
        refId,
        rowId: context.rowId,
        sourceType,
        kind: artifact.kind,
        mediaId,
        localPath: artifact.localPath,
        relativePath: artifact.relativePath,
        sourceUri: "",
        characterIds: uniqueStrings(ref.characterIds || context.characterIds),
        productIds: uniqueStrings(ref.productIds || context.productIds)
      });
    }
    return {
      refId,
      rowId: context.rowId,
      sourceType,
      localPath: sourceType === "local-upload" ? compactString(ref.localPath || ref.path || "") : "",
      sourceUri: sourceType === "external" ? compactString(ref.sourceUri || ref.url || ref.href || "") : "",
      mediaId: "",
      characterIds: uniqueStrings(ref.characterIds || ref.characters || ref.characterId),
      productIds: uniqueStrings(ref.productIds || ref.products || ref.productId)
    };
  }).map((ref, index) => validateRef(ref, context.rowId, index));
}

function normalizePromotedRefs(refs = [], context = {}, mediaById = new Map()) {
  return asArray(refs).map((ref) => {
    const mediaId = mediaIdFrom(ref);
    if (!mediaId) throw new Error(`Continuity manifest missing media id for promoted ref in row ${context.rowId}.`);
    const artifact = mediaById.get(mediaId);
    if (!artifact) throw new Error(`Continuity manifest cannot promote missing flow artifact ${mediaId} for row ${context.rowId}.`);
    if (artifact.kind !== "image") throw new Error(`Continuity manifest can only promote generated images as refs for row ${context.rowId}.`);
    return {
      refId: compactString(ref.refId || ref.id || artifact.slotId || mediaId),
      rowId: context.rowId,
      sourceType: "flow-generated",
      kind: artifact.kind,
      mediaId,
      localPath: artifact.localPath,
      relativePath: artifact.relativePath,
      characterIds: uniqueStrings(ref.characterIds || ref.characters || ref.characterId || context.characterIds),
      productIds: uniqueStrings(ref.productIds || ref.products || ref.productId || context.productIds)
    };
  });
}

function normalizeRefSources(refs = [], rowId = "") {
  return asArray(refs).map((ref, index) => {
    const sourceType = normalizeSourceType(ref.sourceType || inferRefSourceType(ref));
    const refId = compactString(ref.refId || ref.id || ref.name || "");
    if (!refId) throw new Error(`Continuity manifest missing ref id for row ${rowId}.`);
    if (sourceType === "local-upload" && !compactString(ref.localPath || ref.path || "")) {
      throw new Error(`Continuity manifest missing local path for ref ${refId} in row ${rowId}.`);
    }
    if (sourceType === "external" && !compactString(ref.sourceUri || ref.url || ref.href || "")) {
      throw new Error(`Continuity manifest missing source URI for external ref ${refId} in row ${rowId}.`);
    }
    return ref;
  });
}

function normalizePromotedRefSources(refs = [], rowId = "") {
  return asArray(refs);
}

function validateRef(ref = {}, rowId = "", index = 0) {
  if (!SOURCE_TYPES.has(ref.sourceType)) {
    throw new Error(`Continuity manifest unsupported source type ${ref.sourceType || "(missing)"} for ref ${index + 1} in row ${rowId}.`);
  }
  if (ref.sourceType === "local-upload" && !ref.localPath) {
    throw new Error(`Continuity manifest missing local path for ref ${ref.refId} in row ${rowId}.`);
  }
  if (ref.sourceType === "external" && !ref.sourceUri) {
    throw new Error(`Continuity manifest missing source URI for external ref ${ref.refId} in row ${rowId}.`);
  }
  return ref;
}

function inferRefSourceType(ref = {}) {
  if (mediaIdFrom(ref)) return "flow-generated";
  if (ref.localPath || ref.path) return "local-upload";
  if (ref.sourceUri || ref.url || ref.href) return "external";
  return "";
}

function normalizeSourceType(value = "") {
  const sourceType = compactString(value).toLowerCase();
  if (!SOURCE_TYPES.has(sourceType)) throw new Error(`Continuity manifest unsupported source type ${sourceType || "(missing)"}.`);
  return sourceType;
}

function rowIdFromRow(row = {}) {
  return normalizeRowId(row.rowId || row.tag || row.videoTag || row.finalVideoId || row.id || row.sceneId || "");
}

function mediaIdFrom(value = {}) {
  return compactString(value.mediaId || value.id || value.name || value.mediaName || "");
}

function normalizeKind(value = "") {
  const normalized = compactString(value).toLowerCase();
  if (normalized === "images") return "image";
  if (normalized === "videos") return "video";
  if (normalized === "image" || normalized === "video") return normalized;
  return "";
}

function normalizeRowId(value = "") {
  return compactString(value).replace(/^\[|\]$/g, "");
}

function groupEntriesByRow(entries = []) {
  const groups = new Map();
  for (const entry of entries) {
    if (!groups.has(entry.rowId)) groups.set(entry.rowId, []);
    groups.get(entry.rowId).push(entry);
  }
  return groups;
}

function indexByMediaId(entries = []) {
  const index = new Map();
  for (const entry of entries) {
    if (!index.has(entry.mediaId)) index.set(entry.mediaId, entry);
  }
  return index;
}

function dedupeArtifactEntries(entries = []) {
  const seen = new Set();
  const unique = [];
  for (const entry of entries) {
    if (!entry) continue;
    const key = `${entry.kind}:${entry.mediaId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(entry);
  }
  return unique;
}

function compareRows(left = {}, right = {}) {
  const indexCompare = Number(left.rowIndex || 0) - Number(right.rowIndex || 0);
  if (indexCompare) return indexCompare;
  return left.rowId.localeCompare(right.rowId);
}

function compareArtifactEntries(left = {}, right = {}) {
  const kindCompare = (MEDIA_KIND_ORDER[left.kind] || 99) - (MEDIA_KIND_ORDER[right.kind] || 99);
  if (kindCompare) return kindCompare;
  const versionCompare = Number(left.version || 0) - Number(right.version || 0);
  if (versionCompare) return versionCompare;
  const slotCompare = String(left.slotId || "").localeCompare(String(right.slotId || ""));
  if (slotCompare) return slotCompare;
  return String(left.mediaId || "").localeCompare(String(right.mediaId || ""));
}

function compactObject(value = {}) {
  return Object.fromEntries(
    Object.entries(value).filter(([, entry]) => entry !== undefined)
  );
}

function asArray(value = []) {
  if (Array.isArray(value)) return value.filter((entry) => entry && typeof entry === "object");
  if (value && typeof value === "object") return [value];
  return [];
}

function uniqueStrings(value = []) {
  const values = Array.isArray(value) ? value : [value];
  return [...new Set(values.map(compactString).filter(Boolean))];
}

function parsePositiveInt(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}
