export const FLEET_GEN_DEFAULT_TIMEOUT_MS = 600000;
export const FLEET_GEN_BROKER_TIMEOUT_CAP_MS = 600000;
export const FLEET_GEN_HARVEST_TIMEOUT_CAP_MS = 15000;
export const FLEET_GEN_HARVEST_GRACE_MS = 5000;
export const FLEET_GEN_MIN_ACTIVE_MS = 1000;

function positiveMs(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export function fleetGenHarvestBudget({
  timeoutMs,
  commandTimeoutMs,
  pollMs = 0,
  harvestGraceMs = FLEET_GEN_HARVEST_GRACE_MS,
  setupElapsedMs = 0
} = {}) {
  const requestedMs = Math.max(FLEET_GEN_MIN_ACTIVE_MS, positiveMs(timeoutMs, FLEET_GEN_DEFAULT_TIMEOUT_MS));
  const setupMs = Math.max(0, Number(setupElapsedMs) || 0);
  const brokerRemainingMs = Math.max(FLEET_GEN_MIN_ACTIVE_MS, FLEET_GEN_BROKER_TIMEOUT_CAP_MS - setupMs);
  const totalMs = Math.min(requestedMs, brokerRemainingMs);
  const commandMs = Math.max(FLEET_GEN_MIN_ACTIVE_MS, positiveMs(commandTimeoutMs, 30000));
  const harvestTimeoutMs = Math.min(commandMs, FLEET_GEN_HARVEST_TIMEOUT_CAP_MS);
  const grace = Math.max(0, positiveMs(harvestGraceMs, 0));
  const lastPollMs = Math.max(0, positiveMs(pollMs, 0));
  const rawHarvestReserveMs = harvestTimeoutMs + lastPollMs + grace;
  const harvestReserveMs = Math.min(rawHarvestReserveMs, Math.floor(totalMs / 2));
  const pollDeadlineMs = Math.max(0, totalMs - harvestReserveMs);
  const activeTimeoutMs = Math.max(FLEET_GEN_MIN_ACTIVE_MS, pollDeadlineMs);
  return { totalMs, commandMs, harvestTimeoutMs, harvestReserveMs, pollDeadlineMs, activeTimeoutMs };
}
