function compact(value = "") {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function parseIndexList(value = "") {
  const indices = new Set();
  for (const token of String(value || "").split(",")) {
    const trimmed = token.trim();
    const range = trimmed.match(/^(\d+)\s*[-–—]\s*(\d+)$/);
    if (range) {
      const start = Number(range[1]);
      const end = Number(range[2]);
      if (start > 0 && end >= start && end - start <= 1000) {
        for (let index = start; index <= end; index += 1) indices.add(index);
      }
      continue;
    }
    const index = Number(trimmed);
    if (Number.isInteger(index) && index > 0) indices.add(index);
  }
  return [...indices].sort((left, right) => left - right);
}

export function parseAgentStatusProtocol(text = "") {
  const value = compact(text);
  const completeMatch = value.match(/STATUS:ROW_COMPLETE\s*\[([^\]]*)\]/i);
  const failedMatch = value.match(/STATUS:FAILED\s*\[([^\]]*)\]/i);
  const totalsMatch = value.match(/STATUS:TOTALS\s+images\s*=\s*(\d+)\s*\/\s*(\d+)\s+videos\s*=\s*(\d+)\s*\/\s*(\d+)/i);
  const batchMatch = value.match(/STATUS:BATCH_COMPLETE\s*\[([^\]]+)\]/i);
  const reasonMatch = value.match(/STATUS:FAILED[\s\S]{0,2200}?\breason\s*:\s*([A-Z][A-Z0-9_:-]{3,})/i);
  const completeIndices = parseIndexList(completeMatch?.[1] || "");
  const failedIndices = parseIndexList(failedMatch?.[1] || "");
  const hasProtocol = Boolean(completeMatch || failedMatch || totalsMatch || batchMatch);
  return {
    hasProtocol,
    completeIndices,
    failedIndices,
    expectedImages: totalsMatch ? Number(totalsMatch[2]) : 0,
    completedImages: totalsMatch ? Number(totalsMatch[1]) : completeIndices.length,
    expectedVideos: totalsMatch ? Number(totalsMatch[4]) : 0,
    completedVideos: totalsMatch ? Number(totalsMatch[3]) : 0,
    batchComplete: Boolean(batchMatch),
    batchId: compact(batchMatch?.[1] || ""),
    failureReason: compact(reasonMatch?.[1] || "").toUpperCase()
  };
}

export function buildAgentRunSupportSnapshot(run = {}) {
  const rows = Array.isArray(run.rows) ? run.rows : [];
  const rowStatuses = rows.reduce((counts, row) => {
    const status = compact(row?.status || "unknown");
    counts[status] = (counts[status] || 0) + 1;
    return counts;
  }, {});
  const context = run.agentContext && typeof run.agentContext === "object" ? run.agentContext : {};
  return {
    id: compact(run.id),
    source: compact(run.source),
    status: compact(run.status),
    projectId: compact(run.projectId),
    tabId: run.tabId || null,
    startedAt: compact(run.startedAt),
    submittedAt: compact(run.submittedAt),
    updatedAt: compact(run.updatedAt),
    completedAt: compact(run.completedAt),
    submitted: run.submitted === true || run.promptSubmission?.submitted === true,
    promptSubmission: {
      promptLength: Number(run.promptSubmission?.promptLength || 0),
      promptLineCount: Number(run.promptSubmission?.promptLineCount || 0),
      promptHash: compact(run.promptSubmission?.promptHash)
    },
    rowCount: rows.length,
    rowStatuses,
    expectedImages: Number(run.expectedImages || 0),
    landedImages: Number(run.landedImages || 0),
    failedImages: Number(run.failedImages || 0),
    expectedVideos: Number(run.expectedVideos || 0),
    landedVideos: Number(run.landedVideos || 0),
    failedVideos: Number(run.failedVideos || 0),
    batchPlan: run.batchPlan || run.matrix?.batchPlan || null,
    batchSupervisor: run.batchSupervisor || null,
    pendingAction: run.pendingAction || null,
    blocker: run.blocker || null,
    blockCode: compact(run.blockCode),
    lastError: compact(run.lastError).slice(0, 1200),
    agentStatusProtocol: run.agentStatusProtocol || null,
    latestMessages: (Array.isArray(context.latestMessages) ? context.latestMessages : []).slice(-4).map((message) => ({
      role: compact(message?.role),
      text: compact(message?.text).slice(0, 1600)
    })),
    contextBlockers: (Array.isArray(context.blockers) ? context.blockers : []).slice(0, 8),
    lastContextAt: compact(run.lastContextAt),
    lastReconcileStartedAt: compact(run.lastReconcileStartedAt),
    lastReconcileCompletedAt: compact(run.lastReconcileCompletedAt)
  };
}

export function applyAgentStatusProtocolToRun(run = {}, protocol = {}) {
  if (!protocol?.hasProtocol) return run;
  const complete = new Set(protocol.completeIndices || []);
  const failed = new Set(protocol.failedIndices || []);
  const rows = (Array.isArray(run.rows) ? run.rows : []).map((row, index) => {
    const rowNumber = index + 1;
    if (complete.has(rowNumber)) return { ...row, status: "complete", lastError: "" };
    if (failed.has(rowNumber)) return { ...row, status: "blocked", lastError: protocol.failureReason || "agent_row_failed" };
    return row;
  });
  return {
    ...run,
    rows,
    agentStatusProtocol: protocol,
    expectedImages: protocol.expectedImages || Number(run.expectedImages || 0),
    landedImages: protocol.completedImages,
    failedImages: protocol.failedIndices.length,
    expectedVideos: protocol.expectedVideos || Number(run.expectedVideos || 0),
    landedVideos: protocol.completedVideos,
    failedVideos: 0
  };
}
