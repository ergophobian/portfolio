import { normalizeRetryMode } from "../queue/video-retry-policy.js";

export const SUPPORTED_RETRY_ISSUE_CHIPS = [
  "wrong speaker",
  "wrong dialogue",
  "missing line",
  "ending cut off",
  "identity drift",
  "outfit drift",
  "wrong product",
  "bad vial",
  "bad timing",
  "missing output",
  "generation failed unbilled",
  "policy prompt block",
  "third party content block"
];

const ISSUE_GUIDANCE = {
  "wrong speaker": "Use the manually assigned speaker roles exactly; do not swap interviewer and host dialogue.",
  "wrong dialogue": "Match the quoted dialogue exactly; do not paraphrase, add lines, or change wording.",
  "missing line": "Include every required line before the clip ends.",
  "ending cut off": "Leave enough timing for the final words to finish cleanly before the video ends.",
  "identity drift": "Keep the same character identity, face, age, and reference likeness throughout.",
  "outfit drift": "Keep wardrobe consistent with the source frame and prompt.",
  "wrong product": "Show only the requested product and do not substitute a different item.",
  "bad vial": "Use the correct vial shape, label treatment, and cap style from the prompt/reference.",
  "bad timing": "Follow the requested beat timing and do not rush or stretch dialogue beats.",
  "missing output": "Generate only this missing row output; do not regenerate completed rows or create extra variations.",
  "generation failed unbilled": "Retry this row with the same prompt, model, duration, aspect ratio, and attached inputs; the prior generation failed before charging.",
  "policy prompt block": "Rewrite only this blocked row so it complies with Flow policy while preserving the creative intent, references, model, duration, aspect ratio, and output count. Immediately generate the repaired row after rewriting it. Do not ask me to confirm the rewrite.",
  "third party content block": "Rewrite only this blocked row so it avoids third-party, copyrighted, trademarked, public-figure, or named-provider wording while preserving the creative intent, references, model, duration, aspect ratio, and output count. Immediately generate the repaired row after rewriting it. Do not ask me to confirm the rewrite."
};

const ISSUE_ALIASES = {
  ending_cutoff: "ending cut off",
  "ending cutoff": "ending cut off",
  missing_line: "missing line",
  wrong_dialogue: "wrong dialogue",
  wrong_speaker: "wrong speaker",
  identity_drift: "identity drift",
  outfit_drift: "outfit drift",
  wrong_product: "wrong product",
  bad_vial: "bad vial",
  bad_timing: "bad timing",
  missing_output: "missing output",
  "missing output": "missing output",
  agent_generation_failed_unbilled: "generation failed unbilled",
  "agent generation failed unbilled": "generation failed unbilled",
  generation_failed_unbilled: "generation failed unbilled",
  "generation failed unbilled": "generation failed unbilled",
  agent_policy_prompt_block: "policy prompt block",
  "agent policy prompt block": "policy prompt block",
  policy_prompt_block: "policy prompt block",
  "policy prompt block": "policy prompt block",
  agent_third_party_content_block: "third party content block",
  "agent third party content block": "third party content block",
  third_party_content_block: "third party content block",
  "third party content block": "third party content block"
};

export function buildAgentRetryPrompt({
  sceneId = "scene",
  issues = [],
  details = "",
  expectedDialogue = [],
  notes = [],
  mode = "",
  retryMode = ""
} = {}) {
  const normalizedIssues = normalizeIssues(issues);
  if (!normalizedIssues.length) {
    throw new Error("At least one retry issue chip is required");
  }
  const explicitMode = normalizeRetryMode(retryMode || mode);

  const issueLabel = normalizedIssues.length === 1
    ? `Issue: ${normalizedIssues[0]}`
    : `Issues: ${normalizedIssues.join(", ")}`;
  const parts = [
    `Retry [${compactSceneId(sceneId)}] ${agentRetryTargetLabel(explicitMode)}. ${issueLabel}.`
  ];

  const detailText = compactString(details);
  if (detailText) {
    parts.push(ensureSentence(detailText));
  } else {
    parts.push(...normalizedIssues.map((issue) => ISSUE_GUIDANCE[issue]));
  }

  const dialogue = normalizeDialogue(expectedDialogue);
  if (dialogue.length) {
    parts.push(`Required dialogue: ${dialogue.map((line) => `"${line}"`).join(" ")}.`);
  }

  const guard = explicitMode ? agentRetryModeGuard(explicitMode) : "";
  if (guard) parts.push(guard);

  parts.push(...normalizeNotes(notes).map(ensureSentence));

  return parts.filter(Boolean).join(" ");
}

function agentRetryTargetLabel(mode = "") {
  if (mode === "text-to-image") return "create-image only";
  if (mode === "ingredients-to-video") return "ingredients-to-video only";
  if (mode === "image-to-video") return "frame-to-video only";
  return "video only";
}

function agentRetryModeGuard(mode = "") {
  if (mode === "text-to-video") return "Keep this as text-to-video: edit the prompt only and do not add image references.";
  if (mode === "text-to-image") return "Keep this as create-image: edit the prompt first; image references are optional and must not change the mode.";
  if (mode === "ingredients-to-video") return "Keep this as ingredients-to-video: use no more than 3 ingredient image inputs.";
  if (mode === "image-to-video") return "Keep this as frame-to-video: preserve explicit start and end frame slots instead of generic image refs.";
  return "";
}

function normalizeIssues(issues = []) {
  return (Array.isArray(issues) ? issues : [issues]).map((issue) => {
    const normalized = canonicalIssue(issue);
    if (!SUPPORTED_RETRY_ISSUE_CHIPS.includes(normalized)) {
      throw new Error(`Unsupported retry issue chip: ${issue}`);
    }
    return normalized;
  });
}

function canonicalIssue(issue = "") {
  const value = compactString(issue).toLowerCase().replace(/[-\s]+/g, " ");
  return ISSUE_ALIASES[value] || value;
}

function normalizeDialogue(lines = []) {
  return (Array.isArray(lines) ? lines : [lines]).map(compactString).filter(Boolean);
}

function normalizeNotes(notes = []) {
  return (Array.isArray(notes) ? notes : [notes]).map(compactString).filter(Boolean);
}

function compactSceneId(sceneId = "") {
  return compactString(sceneId || "scene");
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function ensureSentence(value = "") {
  const text = compactString(value);
  if (!text) return "";
  return /[.!?]"?$/.test(text) ? text : `${text}.`;
}
