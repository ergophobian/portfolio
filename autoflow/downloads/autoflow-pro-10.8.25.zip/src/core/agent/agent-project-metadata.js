const VIDEO_TAG_RE = /\[\s*V(\d+)\s*-\s*S(\d+)\s*\]/i;
const GENERIC_VIDEO_TAG_RE = /\[\s*([A-Z][A-Z0-9_-]*\d[A-Z0-9_-]*)\s*\]/i;
const AUTOFLOW_LABEL_TAG_RE = /\[\s*((?:AF|ROW)[A-Z0-9_-]*(?:[-_][A-Z0-9]+)+)\s*\]/i;
const IMAGE_AUDIT_ID_RE = /\bAFID\s*:\s*V(\d+)\s*-\s*S(\d+)\s*-\s*IMG(\d+)\b/i;
const GENERIC_IMAGE_AUDIT_ID_RE = /\bAFID\s*:\s*([A-Z][A-Z0-9_-]*?\d[A-Z0-9_-]*)\s*-\s*IMG(\d+)\b/i;
const GENERIC_ROW_AUDIT_ID_RE = /\bAFID\s*:\s*([A-Z][A-Z0-9_-]*\d[A-Z0-9_-]*)\b/i;

export function parseAgentProjectMetadata(projectInitialData = {}) {
  const project = unwrapProjectInitialData(projectInitialData);
  const contents = project?.projectContents || {};
  const mediaItems = Array.isArray(contents.media) ? contents.media : [];
  const workflowIndexes = indexWorkflows(contents.workflows);

  return mediaItems
    .map((media) => normalizeMediaRecord(media, workflowIndexes))
    .filter((record) => record.mediaId && (record.kind === "image" || record.kind === "video"))
    .sort(compareRecords);
}

export function extractAgentVideoTag(text = "") {
  const match = String(text || "").match(VIDEO_TAG_RE);
  if (match) return `[V${Number.parseInt(match[1], 10)}-S${Number.parseInt(match[2], 10)}]`;
  const genericMatch = String(text || "").match(GENERIC_VIDEO_TAG_RE);
  if (genericMatch) return `[${normalizeGenericAgentRowId(genericMatch[1])}]`;
  const autoflowLabelMatch = String(text || "").match(AUTOFLOW_LABEL_TAG_RE);
  if (!autoflowLabelMatch) return null;
  return `[${normalizeGenericAgentRowId(autoflowLabelMatch[1])}]`;
}

export function extractAgentImageAuditId(text = "") {
  const match = String(text || "").match(IMAGE_AUDIT_ID_RE);
  if (match) return `AFID:V${Number.parseInt(match[1], 10)}-S${Number.parseInt(match[2], 10)}-IMG${Number.parseInt(match[3], 10)}`;
  const genericMatch = String(text || "").match(GENERIC_IMAGE_AUDIT_ID_RE);
  if (!genericMatch) return null;
  return `AFID:${normalizeGenericAgentRowId(genericMatch[1])}-IMG${Number.parseInt(genericMatch[2], 10)}`;
}

export function extractAgentRowAuditTag(text = "") {
  const imageTag = agentVideoTagFromImageAuditId(extractAgentImageAuditId(text));
  if (imageTag) return imageTag;
  const match = String(text || "").match(GENERIC_ROW_AUDIT_ID_RE);
  if (!match) return null;
  return `[${normalizeGenericAgentRowId(match[1])}]`;
}

export function agentVideoTagFromImageAuditId(imageAuditId = "") {
  const match = extractAgentImageAuditId(imageAuditId)?.match(/^AFID:([A-Z][A-Z0-9_-]*\d[A-Z0-9_-]*)-IMG\d+$/i);
  return match ? `[${match[1]}]` : null;
}

export function agentImageIndexFromAuditId(imageAuditId = "") {
  const match = extractAgentImageAuditId(imageAuditId)?.match(/-IMG(\d+)$/);
  return match ? Number.parseInt(match[1], 10) : null;
}

function unwrapProjectInitialData(input) {
  const parsed = typeof input === "string" ? JSON.parse(input) : input;
  return parsed?.result?.data?.json || parsed?.data?.json || parsed?.json || parsed;
}

function normalizeMediaRecord(media = {}, workflowIndexes = {}) {
  const mediaId = compactString(media.name || media.mediaId || media.id);
  const workflow = workflowIndexes.byPrimaryMediaId.get(mediaId) || workflowIndexes.byWorkflowId.get(compactString(media.workflowId));
  const workflowMetadata = workflow?.metadata || {};
  const kind = media.video ? "video" : media.image ? "image" : normalizeKind(media.kind || media.mediaType);
  const title = compactString(media.mediaMetadata?.mediaTitle || workflowMetadata.displayName);
  const prompt = extractPrompt(media);
  const searchText = compactStrings([
    title,
    prompt,
    workflowMetadata.displayName,
    ...extractPromptInputTexts(media)
  ]).join("\n");
  const imageAuditId = extractAgentImageAuditId(searchText);
  const explicitVideoTag = extractAgentVideoTag(searchText);
  const videoTag = explicitVideoTag || agentVideoTagFromImageAuditId(imageAuditId) || extractAgentRowAuditTag(searchText);

  return {
    mediaId,
    workflowId: compactString(media.workflowId || workflow?.name),
    workflowStepId: compactString(media.workflowStepId),
    createTime: compactString(media.mediaMetadata?.createTime || workflowMetadata.createTime),
    updateTime: compactString(media.mediaMetadata?.updateTime || workflowMetadata.updateTime),
    kind,
    prompt,
    title,
    videoTag,
    imageAuditId,
    inputMediaIds: kind === "video" ? extractVideoImageInputMediaIds(media) : [],
    imageInputMediaIds: kind === "video" ? extractVideoImageInputMediaIds(media) : [],
    videoInputMediaIds: kind === "video" ? extractVideoSourceInputMediaIds(media) : [],
    raw: media
  };
}

function indexWorkflows(workflows = []) {
  const byPrimaryMediaId = new Map();
  const byWorkflowId = new Map();
  for (const workflow of Array.isArray(workflows) ? workflows : []) {
    const workflowId = compactString(workflow?.name || workflow?.workflowId || workflow?.id);
    const primaryMediaId = compactString(workflow?.metadata?.primaryMediaId);
    if (workflowId) byWorkflowId.set(workflowId, workflow);
    if (primaryMediaId) byPrimaryMediaId.set(primaryMediaId, workflow);
  }
  return { byPrimaryMediaId, byWorkflowId };
}

function extractPrompt(media = {}) {
  return firstCompactString([
    media.video?.generatedVideo?.prompt,
    media.image?.generatedImage?.prompt,
    ...extractPromptInputTexts(media),
    media.mediaMetadata?.mediaTitle
  ]);
}

function extractPromptInputTexts(media = {}) {
  const promptInputs = media.mediaMetadata?.requestData?.promptInputs;
  if (!Array.isArray(promptInputs)) return [];
  const texts = [];
  for (const input of promptInputs) {
    texts.push(input?.textInput);
    const parts = input?.structuredPrompt?.parts;
    if (Array.isArray(parts)) {
      for (const part of parts) texts.push(part?.text);
    }
  }
  return compactStrings(texts);
}

function extractVideoImageInputMediaIds(media = {}) {
  const requestData = media.mediaMetadata?.requestData || {};
  const imageInputs = requestData.videoGenerationRequestData?.videoGenerationImageInputs || [];
  if (!Array.isArray(imageInputs)) return [];
  return uniqueStrings(imageInputs.flatMap((input) => [input?.mediaId, input?.mediaGenerationId]));
}

function extractVideoSourceInputMediaIds(media = {}) {
  const requestData = media.mediaMetadata?.requestData || {};
  const videoInputs = requestData.videoGenerationRequestData?.videoGenerationVideoInputs || [];
  if (!Array.isArray(videoInputs)) return [];
  return uniqueStrings(videoInputs.flatMap((input) => [input?.mediaId, input?.mediaGenerationId]));
}

function normalizeKind(kind = "") {
  const normalized = compactString(kind).toLowerCase();
  if (normalized.includes("video")) return "video";
  if (normalized.includes("image")) return "image";
  return normalized || "unknown";
}

function compareRecords(left, right) {
  const timeCompare = toTime(left.createTime) - toTime(right.createTime);
  if (timeCompare) return timeCompare;
  return String(left.mediaId).localeCompare(String(right.mediaId));
}

function toTime(value = "") {
  const millis = Date.parse(value);
  return Number.isFinite(millis) ? millis : 0;
}

function compactStrings(values = []) {
  return values.map(compactString).filter(Boolean);
}

function firstCompactString(values = []) {
  return compactStrings(values)[0] || "";
}

function uniqueStrings(values = []) {
  return [...new Set(compactStrings(values))];
}

function normalizeGenericAgentRowId(value = "") {
  const normalized = compactString(value)
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return normalized || "";
}

function compactString(value = "") {
  return String(value || "").trim();
}
