export const BROKER_HEALTH_STATES = Object.freeze({
  READY: "ready",
  EXTENSION_DISCONNECTED: "extension_disconnected",
  BROKER_UNAVAILABLE: "broker_unavailable",
  RECONNECTING: "reconnecting",
  AMBIGUOUS_WRITE: "ambiguous_write",
  DISABLED: "disabled"
});

const VALID_HEALTH_STATES = new Set(Object.values(BROKER_HEALTH_STATES));

export function isBrokerHealthState(value) {
  return VALID_HEALTH_STATES.has(String(value || ""));
}

export function normalizeBrokerHealthState(value, fallback = BROKER_HEALTH_STATES.BROKER_UNAVAILABLE) {
  const state = String(value || "");
  return isBrokerHealthState(state) ? state : fallback;
}

export function classifyBrokerHealth({
  brokerAvailable = false,
  extensionConnected = false,
  reconnecting = false,
  ambiguousWrite = false,
  enabled = true
} = {}) {
  if (!enabled) return BROKER_HEALTH_STATES.DISABLED;
  if (ambiguousWrite) return BROKER_HEALTH_STATES.AMBIGUOUS_WRITE;
  if (reconnecting) return BROKER_HEALTH_STATES.RECONNECTING;
  if (!brokerAvailable) return BROKER_HEALTH_STATES.BROKER_UNAVAILABLE;
  if (!extensionConnected) return BROKER_HEALTH_STATES.EXTENSION_DISCONNECTED;
  return BROKER_HEALTH_STATES.READY;
}

export function buildBrokerHealth(options = {}) {
  const state = classifyBrokerHealth(options);
  return {
    state,
    brokerAvailable: options.brokerAvailable === true,
    extensionConnected: options.extensionConnected === true,
    paired: options.paired === true,
    readyForClient: state === BROKER_HEALTH_STATES.READY && options.paired === true,
    socketPath: String(options.socketPath || ""),
    transport: String(options.transport || "unix_socket")
  };
}
