const UNKNOWN = "unknown";

export function buildFlowStateSnapshot({
  status = {},
  agentContext = {},
  requestedTarget = {},
  checkedAt = new Date().toISOString()
} = {}) {
  const page = summarizePage(status, agentContext);
  const target = summarizeTarget(status, page, requestedTarget);
  const auth = summarizeAuth(status);
  const dialogs = summarizeDialogs(agentContext.dialogs || agentContext.openDialogs);
  const buttons = summarizeButtons(agentContext.actionRows || agentContext.buttons || agentContext.pendingButtons);
  const settings = summarizeSettings(agentContext.settings || {});
  const credits = summarizeCredits(agentContext.credits || {}, agentContext.uiState || {}, dialogs, buttons);
  const pendingChoice = summarizePendingChoice(agentContext.uiState || {}, agentContext);
  const composer = summarizeComposer(agentContext.composer || {}, page, dialogs);
  const pending = summarizePending(status, agentContext, pendingChoice, composer);
  const blockers = summarizeBlockers(agentContext.blockers);
  const precondition = flowStatePreconditionFailure(status, page);
  const state = precondition
    ? precondition.precondition
    : deriveFlowState({ auth, dialogs, credits, pendingChoice, pending, blockers, composer });

  return {
    ok: !precondition,
    readOnly: true,
    state,
    checkedAt: compactString(agentContext.checkedAt || checkedAt) || checkedAt,
    page,
    target,
    mode: settings.mode,
    settings,
    dialogs,
    buttons,
    credits,
    composerReady: composer.ready,
    composer,
    auth,
    pendingChoice,
    pending,
    blockers,
    ...(precondition ? {
      code: precondition.code,
      precondition: precondition.precondition,
      message: precondition.message
    } : {})
  };
}

export function flowStatePreconditionFailure(status = {}, page = null) {
  const bridge = status.bridge || {};
  const extension = status.extension || {};
  if (extension.present === false || bridge.extensionConnected === false) {
    return {
      code: "FLOW_STATE_EXTENSION_ASLEEP",
      precondition: "extension_asleep",
      message: "flow_state precondition missing: Auto Flow extension bridge is not connected or the extension service worker is asleep."
    };
  }
  const resolvedPage = page || summarizePage(status, {});
  const project = status.project || {};
  const projectActive = project.active ?? (project.state === "active" ? true : (project.state === "missing" ? false : null));
  const hasKnownProject = Boolean(resolvedPage.projectId && resolvedPage.projectId !== UNKNOWN);
  if (!hasKnownProject || projectActive === false || project.state === "missing") {
    return {
      code: "FLOW_STATE_PAGE_NOT_FLOW",
      precondition: "page_not_flow",
      message: "flow_state precondition missing: active page is not a Google Flow project tab."
    };
  }
  return null;
}

export function flowStateStatusSummary(status = {}) {
  const page = summarizePage(status, {});
  return {
    bridge: compactString(status.bridge?.state || UNKNOWN) || UNKNOWN,
    extensionConnected: boolOrUnknown(status.bridge?.extensionConnected),
    extensionId: compactString(status.extension?.id || ""),
    projectId: page.projectId,
    tabId: page.tabId,
    auth: summarizeAuth(status)
  };
}

export function compactFlowStateError({ code, precondition, message, status = {}, request = null, details = {} } = {}) {
  return {
    ok: false,
    readOnly: true,
    code: code || "FLOW_STATE_UNAVAILABLE",
    precondition: precondition || "unknown",
    message: message || "flow_state precondition missing: Flow state is unavailable.",
    status: flowStateStatusSummary(status),
    ...(request ? { request } : {}),
    ...(Object.keys(details || {}).length ? { details } : {})
  };
}

function summarizePage(status = {}, agentContext = {}) {
  const page = agentContext.page || {};
  const project = status.project || {};
  const runtime = status.runtime || {};
  const raw = status.raw || {};
  const href = compactString(page.href || page.url || project.url || runtime.pageUrl || raw.pageUrl || "");
  const projectId = compactString(
    page.projectId
    || agentContext.projectId
    || project.id
    || project.projectId
    || runtime.projectId
    || status.projectId
    || raw.projectId
  );
  const tabId = compactString(
    page.tabId
    || page.activeTabId
    || project.activeTabId
    || runtime.activeTabId
    || status.activeTabId
    || raw.activeTabId
  );
  return {
    projectId: projectId || UNKNOWN,
    tabId: tabId || UNKNOWN,
    href: href || UNKNOWN,
    title: compactString(page.title || project.name || raw.pageTitle || "") || UNKNOWN,
    kind: isFlowProjectHref(href) || projectId ? "flow_project" : UNKNOWN
  };
}

function summarizeTarget(status = {}, page = {}, requestedTarget = {}) {
  return {
    projectId: compactString(requestedTarget.projectId || page.projectId || status.project?.id || "") || UNKNOWN,
    tabId: compactString(requestedTarget.tabId || page.tabId || status.activeTabId || "") || UNKNOWN,
    laneId: compactString(requestedTarget.laneId || "") || UNKNOWN,
    requestedProjectId: compactString(requestedTarget.projectId || "") || UNKNOWN,
    requestedTabId: compactString(requestedTarget.tabId || "") || UNKNOWN
  };
}

function summarizeAuth(status = {}) {
  const auth = status.auth || {};
  const authenticated = firstBoolean(
    auth.authenticated,
    auth.signedIn,
    auth.valid,
    auth.ok
  );
  const paired = firstBoolean(auth.paired, status.bridge?.paired);
  const state = compactString(auth.state || auth.status || "") || (
    authenticated === false ? "invalid" : (authenticated === true ? "valid" : UNKNOWN)
  );
  const valid = authenticated === false || paired === false || /missing|expired|invalid|signed_out|pairing_required/i.test(state)
    ? false
    : authenticated === true || /paired|authenticated|valid/i.test(state)
      ? true
      : UNKNOWN;
  return {
    valid,
    state,
    paired: boolOrUnknown(paired),
    signedIn: boolOrUnknown(authenticated),
    plan: compactString(auth.plan || auth.tier || "") || UNKNOWN,
    usageRemaining: numberOrUnknown(auth.usage?.remaining)
  };
}

function summarizeDialogs(dialogs = []) {
  return array(dialogs).slice(0, 8).map((dialog, index) => {
    const text = compactText(dialog?.text || dialog?.label || dialog?.message || "");
    return {
      id: compactString(dialog?.id || `dialog-${index + 1}`),
      kind: classifyDialogKind(text),
      text: truncate(text, 220) || UNKNOWN,
      rect: dialog?.rect || null
    };
  });
}

function summarizeButtons(buttons = []) {
  return array(buttons).slice(0, 10).map((button, index) => {
    const text = compactText(button?.text || button?.label || button?.ariaLabel || button?.title || "");
    return {
      id: compactString(button?.id || `button-${index + 1}`),
      kind: classifyButtonKind(text),
      text: truncate(text, 120) || UNKNOWN,
      persistent: button?.persistent === true,
      rect: button?.rect || null
    };
  });
}

function summarizeSettings(settings = {}) {
  const store = settings.store || settings.promptStore || settings;
  const modelKeys = store.currentModelKeys || settings.modelKeys || {};
  const visible = settings.visible || {};
  const mode = compactString(settings.activeMode || settings.mode || store.mode || store.storeMode || visible.mode || "");
  return {
    mode: mode || UNKNOWN,
    aspectRatio: compactString(settings.aspectRatio || store.aspectRatio || visible.selectedAspect || "") || UNKNOWN,
    outputsPerPrompt: numberOrUnknown(settings.outputsPerPrompt ?? store.outputsPerPrompt),
    videoDuration: numberOrUnknown(settings.videoDuration ?? settings.selectedVideoDuration ?? store.selectedVideoDuration),
    imageModelKey: compactString(modelKeys.imageModelKey || store.imageModelFamilyId || settings.imageModelKey || "") || UNKNOWN,
    videoModelKey: compactString(modelKeys.videoModelKey || modelKeys.videoApi || store.videoModelFamilyId || settings.videoModelKey || "") || UNKNOWN,
    visibleModel: compactString(settings.visibleModel || visible.modelButtonText || visible.visibleModelText || "") || UNKNOWN,
    settingsPanelOpen: boolOrUnknown(settings.panelOpen ?? settings.settingsPanelOpen),
    returnSilentVideos: settings.returnSilentVideos === true || settings.returnSilentVideos === false
      ? settings.returnSilentVideos
      : UNKNOWN
  };
}

function summarizeCredits(credits = {}, uiState = {}, dialogs = [], buttons = []) {
  const action = uiState.actionRequired || {};
  const creditDialog = action.kind === "credit_confirmation"
    || dialogs.some((dialog) => dialog.kind === "credit")
    || buttons.some((button) => button.kind === "credit_confirm");
  return {
    state: creditDialog ? "dialog_open" : (credits.state || UNKNOWN),
    balance: numberOrUnknown(credits.balance),
    amount: numberOrUnknown(action.creditAmount ?? credits.amount),
    currency: compactString(action.currency || credits.currency || "credits") || "credits"
  };
}

function summarizePendingChoice(uiState = {}, agentContext = {}) {
  const action = uiState.actionRequired || {};
  const explicitWaitingOn = compactString(uiState.waitingOn || "");
  const agentState = compactString(agentContext.state || "");
  const waitingOn = explicitWaitingOn || userChoiceState(agentState);
  if ((!waitingOn || waitingOn === UNKNOWN) && !action.kind) {
    return {
      state: "none",
      kind: "none",
      latestMessage: UNKNOWN,
      autoResolvable: UNKNOWN
    };
  }
  const latestMessage = uiState.latestMessage?.text
    || agentContext.latestMessage
    || array(agentContext.latestMessages).at(-1)?.text
    || "";
  return {
    state: waitingOn || compactString(action.kind || UNKNOWN),
    kind: compactString(action.kind || waitingOn || UNKNOWN),
    latestMessage: truncate(compactText(latestMessage), 220) || UNKNOWN,
    autoResolvable: boolOrUnknown(action.autoResolvable),
    defaultChoice: compactString(action.defaultChoice || "") || UNKNOWN
  };
}

function summarizeComposer(composer = {}, page = {}, dialogs = []) {
  const visible = composer.visible === true;
  const sendEnabled = composer.sendEnabled === true;
  const sendControlVisible = composer.sendControlVisible === true;
  const generationActive = composer.generationActive === true;
  const blockingDialog = dialogs.length > 0;
  const ready = Boolean(visible && sendEnabled && sendControlVisible && !generationActive && !blockingDialog);
  return {
    ready,
    visible,
    sendEnabled,
    sendControlVisible,
    generationActive,
    target: {
      projectId: page.projectId || UNKNOWN,
      tabId: page.tabId || UNKNOWN,
      source: compactString(composer.source || "") || UNKNOWN,
      rect: composer.sendControlRect || null
    },
    draftHash: compactString(composer.normalizedTextHash || "") || UNKNOWN,
    textPreview: truncate(compactText(composer.text || ""), 160) || UNKNOWN
  };
}

function summarizePending(status = {}, agentContext = {}, pendingChoice = {}, composer = {}) {
  const queue = summarizeQueue(status);
  return {
    generationActive: composer.generationActive === true || agentContext.generationActive === true,
    agentState: compactString(agentContext.state || "") || UNKNOWN,
    waitingOn: pendingChoice.state || "none",
    queueRunning: boolOrUnknown(queue.running ?? queue.queueRunning),
    queueActive: numberOrUnknown(queue.active),
    queuePending: numberOrUnknown(queue.pending),
    blockers: array(agentContext.blockers).length,
    retryPrompts: array(agentContext.retryPrompts).length
  };
}

function summarizeQueue(status = {}) {
  const raw = status.raw || {};
  const runtime = status.runtime || raw.runtime || {};
  const queue = nonEmptyObject(status.queue) || nonEmptyObject(raw.queue) || nonEmptyObject(runtime.queue) || {};
  const tasks = array(queue.tasks || queue.items || raw.tasks);
  return {
    running: firstBoolean(
      queue.running,
      queue.queueRunning,
      status.queueRunning,
      raw.queueRunning,
      runtime.queueRunning,
      runtime.running
    ),
    active: firstNumber(
      queue.active,
      queue.activeCount,
      queue.activeTasks,
      runtime.queueActive,
      runtime.activeQueueCount,
      countTasks(tasks, ["starting", "submitting", "generating", "downloading", "retrying", "active", "running"])
    ),
    pending: firstNumber(
      queue.pending,
      queue.pendingCount,
      queue.pendingTasks,
      runtime.queuePending,
      runtime.pendingQueueCount,
      countTasks(tasks, ["pending", "waiting", "queued"])
    )
  };
}

function summarizeBlockers(blockers = []) {
  return array(blockers).slice(0, 8).map((blocker) => ({
    rowId: compactString(blocker?.rowId || "") || UNKNOWN,
    failureClass: compactString(blocker?.failureClass || blocker?.code || "") || UNKNOWN,
    retryable: boolOrUnknown(blocker?.retryable ?? blocker?.retryableWithPromptEdit),
    text: truncate(compactText(blocker?.text || blocker?.message || ""), 180) || UNKNOWN
  }));
}

function deriveFlowState({ auth, dialogs, credits, pendingChoice, pending, blockers, composer }) {
  if (auth.valid === false) return "auth_invalid";
  if (credits.state === "dialog_open") return "credits_dialog_open";
  if (dialogs.length) return "dialog_open";
  if (blockers.length) return "blocked";
  if (pendingChoice.state && pendingChoice.state !== "none") return "waiting_for_user";
  if (pending.generationActive === true || pending.agentState === "running") return "running";
  if (composer.ready) return "ready";
  return UNKNOWN;
}

function classifyDialogKind(text = "") {
  const value = compactText(text);
  if (/credits?|cost|use credits|spend/i.test(value)) return "credit";
  if (/add to prompt|recent|uploads?|all media|search/i.test(value)) return "asset_picker";
  if (/upload media|uploads?/i.test(value)) return "upload";
  if (/continue/i.test(value)) return "continue";
  if (/confirm|approve|yes|cancel|reject/i.test(value)) return "confirm";
  return UNKNOWN;
}

function classifyButtonKind(text = "") {
  const value = compactText(text);
  if (/use credits|approve|confirm|yes/i.test(value) && /credits?|cost|ask again|don't ask|dont ask/i.test(value)) return "credit_confirm";
  if (/continue/i.test(value)) return "continue";
  if (/approve|confirm|yes/i.test(value)) return "confirm";
  if (/cancel|reject|no/i.test(value)) return "cancel";
  return UNKNOWN;
}

function isFlowProjectHref(href = "") {
  return /\/tools\/flow\/project\//i.test(String(href || ""));
}

function firstBoolean(...values) {
  for (const value of values) {
    if (value === true || value === false) return value;
  }
  return null;
}

function firstNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === "" || value === UNKNOWN) continue;
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return null;
}

function countTasks(tasks = [], statuses = []) {
  if (!Array.isArray(tasks) || !tasks.length) return null;
  const allowed = new Set(statuses);
  return tasks.filter((task) => allowed.has(compactString(task?.status || task?.state || "").toLowerCase())).length;
}

function userChoiceState(state = "") {
  const value = compactString(state);
  if (!value || ["unknown", "none", "ready", "running", "blocked"].includes(value)) return "";
  return value;
}

function boolOrUnknown(value) {
  return value === true || value === false ? value : UNKNOWN;
}

function numberOrUnknown(value) {
  if (value === null || value === undefined || value === "" || value === UNKNOWN) return UNKNOWN;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : UNKNOWN;
}

function array(value) {
  return Array.isArray(value) ? value : [];
}

function nonEmptyObject(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return Object.keys(value).length ? value : null;
}

function truncate(value = "", limit = 220) {
  const text = compactText(value);
  return text.length > limit ? `${text.slice(0, Math.max(0, limit - 3))}...` : text;
}

function compactText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function compactString(value = "") {
  return String(value || "").trim();
}
