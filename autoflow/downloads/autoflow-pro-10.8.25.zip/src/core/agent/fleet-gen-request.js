export const FLEET_GEN_ALLOWED_DURATION_SECONDS = [4, 6, 8];

function compactString(value = "") {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

export function fleetGenMediaTypeFromValue(value = "") {
  const text = compactString(value).toLowerCase().replace(/_/g, "-");
  if (["image", "text-to-image", "t2i"].includes(text)) return "image";
  if (["video", "text-to-video", "t2v", "image-to-video", "i2v", "video-to-video", "v2v"].includes(text)) return "video";
  return "";
}

export function fleetGenInvalidMediaType(input = {}) {
  for (const value of [input.type, input.mediaType]) {
    const text = compactString(value);
    if (text && !fleetGenMediaTypeFromValue(text)) return text;
  }
  return "";
}

export function fleetGenSourceRoleError(input = {}) {
  const mode = compactString(input.type || input.mediaType).toLowerCase().replace(/_/g, "-");
  const firstFrame = compactString(input.firstFrameImageMediaId || input.firstFrameMediaId || input.startFrameImageMediaId || input.startFrameMediaId || input.settings?.firstFrameImageMediaId || input.settings?.firstFrameMediaId || input.settings?.startFrameImageMediaId || input.settings?.startFrameMediaId);
  const sourceVideo = compactString(input.sourceVideoMediaId || input.settings?.sourceVideoMediaId);
  if (["i2v", "image-to-video"].includes(mode) && !firstFrame) {
    return { code: "FLEETGEN_I2V_FIRST_FRAME_REQUIRED", message: "Fleet Gen I2V requires firstFrameImageMediaId." };
  }
  if (["v2v", "video-to-video"].includes(mode) && !sourceVideo) {
    return { code: "FLEETGEN_V2V_SOURCE_VIDEO_REQUIRED", message: "Fleet Gen V2V requires sourceVideoMediaId." };
  }
  return null;
}

export function fleetGenDurationSecondsFromValue(value) {
  if (value === undefined || value === null || value === "" || value === true || value === false) return null;
  const match = String(value).trim().match(/^(\d+)(?:\s*s(?:ec(?:onds?)?)?)?$/i);
  if (!match) return null;
  const seconds = Number(match[1]);
  return FLEET_GEN_ALLOWED_DURATION_SECONDS.includes(seconds) ? seconds : null;
}

function rawDurationValue(input = {}) {
  return input.durationSeconds ?? input.videoDurationSeconds ?? input.duration ?? input.videoLength;
}

export function fleetGenDurationSecondsFromInput(input = {}) {
  return fleetGenDurationSecondsFromValue(rawDurationValue(input));
}

export function fleetGenPromptRecordsFromInput(input = {}) {
  const defaultDurationSeconds = fleetGenDurationSecondsFromInput(input);
  const record = (prompt = "", durationSeconds = null) => ({
    prompt: compactString(prompt),
    durationSeconds: durationSeconds || defaultDurationSeconds || null
  });
  const direct = String(input.promptsText || input.promptText || input.prompt || "");
  if (direct.trim()) return direct.split(/\r?\n/).map((line) => record(line)).filter((entry) => entry.prompt);
  if (Array.isArray(input.prompts)) {
    return input.prompts
      .map((entry) => typeof entry === "string"
        ? record(entry)
        : record(entry?.prompt || entry?.text, fleetGenDurationSecondsFromValue(rawDurationValue(entry || {}))))
      .filter((entry) => entry.prompt);
  }
  return [];
}

export function fleetGenPerRowDurationPresent(input = {}) {
  if (fleetGenPromptRecordsFromInput(input).some((entry) => entry.durationSeconds)) return true;
  if (Array.isArray(input.promptSettings)) {
    return input.promptSettings.some((entry) => entry && typeof entry === "object" && fleetGenDurationSecondsFromValue(rawDurationValue(entry)));
  }
  return false;
}

export function fleetGenInvalidDurationValue(input = {}) {
  const values = [];
  const add = (value) => {
    if (value !== undefined && value !== null && value !== "") values.push(value);
  };
  add(rawDurationValue(input));
  for (const list of [input.prompts, input.promptSettings]) {
    if (!Array.isArray(list)) continue;
    for (const entry of list) {
      if (entry && typeof entry === "object") add(rawDurationValue(entry));
    }
  }
  const invalid = values.find((value) => !fleetGenDurationSecondsFromValue(value));
  return invalid === undefined ? null : String(invalid);
}
