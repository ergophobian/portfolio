import {
  agentSelfHealPromptLines,
  buildAgentSelfHealPolicy,
  normalizeAgentAutonomy
} from "./agent-autonomy.js";

export const AFID_PROMPT_GUIDANCE = [
  "Preserve AFID in generation prompt metadata for tracking.",
  "Do not render AFID, labels, captions, or text in the image/video."
];

const DEFAULT_TITLE = "Auto Flow AFID Prompt Rows";
const DEFAULT_VIDEO_MODEL_PREFLIGHT = "Use the active Flow UI video model confirmed in preflight";

export function buildAgentManifestFromPromptText(promptText = {}, options = {}) {
  const rows = extractPromptRows(promptText).map((sourceRow) => buildManifestRowFromPromptRow(sourceRow, options));
  return finalizeManifest({
    kind: "agent_afid_manifest",
    title: cleanInlineText(options.title || DEFAULT_TITLE),
    source: "prompt_rows",
    rows
  });
}

export function buildAgentManifestFromMatrix(matrix = {}) {
  const rows = Array.isArray(matrix.rows) ? matrix.rows.map((row) => buildManifestRowFromMatrixRow(row)) : [];
  return finalizeManifest({
    kind: "agent_afid_manifest",
    title: cleanInlineText(matrix.title || DEFAULT_TITLE),
    source: matrix.kind || "agent_matrix",
    rows
  });
}

export function buildAgentMatrixFromManifest(manifest = {}, options = {}) {
  const rows = Array.isArray(manifest.rows) ? manifest.rows : [];
  const repeatCount = clampInt(options.repeatCount, 1, 100, 1);
  const requestedMode = String(options.mode || "").trim().toLowerCase();
  const explicitMode = ["create-image", "image", "t2i"].includes(requestedMode) ? "text-to-image" : requestedMode;
  const matrixMode = explicitMode && !["agent", "auto"].includes(explicitMode)
    ? explicitMode
    : (Number(manifest.expectedVideoCount ?? 0) > 0 ? "image-to-video" : "text-to-image");
  const settings = {
    aspectRatio: String(options.aspectRatio || "portrait"),
    videoLength: String(options.videoLength || "8"),
    model: String(options.model || DEFAULT_VIDEO_MODEL_PREFLIGHT),
    autonomy: normalizeAgentAutonomy(options.autonomy),
    maxSelfHealRetries: options.maxSelfHealRetries,
    suppressOnScreenText: options.suppressOnScreenText
  };
  const selfHeal = buildAgentSelfHealPolicy(options);
  return {
    kind: "agent_prompt_row_manifest",
    submitPath: "agent_first",
    title: cleanInlineText(manifest.title || DEFAULT_TITLE),
    mode: matrixMode,
    rowsRequested: rows.length,
    rowsBuilt: rows.length,
    repeatCount,
    expectedImages: Number(manifest.expectedImageCount ?? 0),
    expectedVideos: Number(manifest.expectedVideoCount ?? 0),
    settings,
    autonomy: settings.autonomy,
    selfHeal,
    manifest,
    rows: rows.map((row, index) => ({
      id: row.rowId,
      rowId: row.rowId,
      finalVideoId: row.finalVideoId,
      rowIndex: index + 1,
      title: `[${row.rowId}]`,
      imageSlots: row.imageSlots,
      imagePrompt: row.imageSlots.map((slot) => slot.prompt).join(" ;; "),
      videoPrompt: row.videoPrompt,
      expectedImages: row.expectedImageCount,
      expectedVideos: row.expectedVideoCount,
      agentPrompt: buildManifestRowPrompt(row, settings)
    }))
  };
}

export function buildAgentAfidPromptContract(manifest = {}) {
  const rows = Array.isArray(manifest.rows) ? manifest.rows : [];
  return [
    "AFID TRACKING CONTRACT",
    ...AFID_PROMPT_GUIDANCE,
    "",
    "Expected manifest:",
    ...rows.flatMap((row) => [
      `- Row [${row.rowId}]: ${row.expectedImageCount} image${row.expectedImageCount === 1 ? "" : "s"}, ${row.expectedVideoCount} video${row.expectedVideoCount === 1 ? "" : "s"}, final video ${row.finalVideoId}`,
      ...row.imageSlots.map((slot) => `  - Image ${slot.index}: ${slot.afid}`)
    ])
  ].join("\n").trim();
}

export function appendAgentAfidPromptContract(promptText = "", manifest = {}) {
  const contract = buildAgentAfidPromptContract(manifest);
  return [String(promptText || "").trim(), contract].filter(Boolean).join("\n\n");
}

export function buildAgentManifestPromptText(manifest = {}, options = {}) {
  const rows = Array.isArray(manifest.rows) ? manifest.rows : [];
  const settings = options.settings || {};
  return [
    "AUTO FLOW AGENT CONTRACT",
    "",
    `Project: ${cleanInlineText(options.title || manifest.title || DEFAULT_TITLE)}`,
    "",
    "Global settings:",
    "- Mode: Agent Mode image-slot manifest",
    `- Aspect ratio: ${settings.aspectRatio || options.aspectRatio || "portrait"}`,
    `- Video length: ${settings.videoLength || options.videoLength || "8"} seconds`,
    `- Preferred video model: ${settings.model || options.model || DEFAULT_VIDEO_MODEL_PREFLIGHT}`,
    `- Expected final count: ${manifest.expectedImageCount ?? 0} image${manifest.expectedImageCount === 1 ? "" : "s"} and ${manifest.expectedVideoCount ?? 0} video${manifest.expectedVideoCount === 1 ? "" : "s"}`,
    ...agentSelfHealPromptLines({
      autonomy: options.autonomy || settings.autonomy,
      maxSelfHealRetries: options.maxSelfHealRetries ?? settings.maxSelfHealRetries,
      suppressOnScreenText: options.suppressOnScreenText ?? settings.suppressOnScreenText
    }),
    Number(manifest.expectedVideoCount ?? 0) > 0 ? "- Return silent videos: use the setting confirmed before submit; do not pause to re-check UI settings." : "",
    "- Use one row per final video.",
    "- Do not create hidden stacks or extra variations beyond the expected manifest.",
    "",
    buildAgentAfidPromptContract(manifest),
    "",
    "Rows:",
    ...rows.flatMap((row) => [
      "",
      `## Row [${row.rowId}]`,
      buildManifestRowPrompt(row, settings)
    ])
  ].filter((line) => line !== "").join("\n");
}

export function buildImageAfid(rowId = "", index = 1) {
  return `AFID:${normalizeManifestRowId(rowId)}-IMG${clampInt(index, 1, 100, 1)}`;
}

function buildManifestRowFromPromptRow(sourceRow = "", options = {}) {
  const tagMatch = String(sourceRow || "").match(/^\s*\[([^\]]+)\]\s*/);
  const rowId = normalizeManifestRowId(tagMatch?.[1] || options.rowId || "ROW-1");
  const rowText = String(sourceRow || "").trim();
  const [createSide, videoSide = ""] = splitFirst(rowText, "|||");
  const imagePrompts = splitImagePrompts(stripLeadingSceneTag(createSide));
  const expectedVideoCount = videoSide.trim() ? clampInt(options.videosPerRow ?? options.repeatCount, 1, 100, 1) : 0;
  return {
    rowId,
    sourceRow: rowText,
    finalVideoId: `[${rowId}]`,
    imageSlots: imagePrompts.map((prompt, index) => ({
      index: index + 1,
      afid: buildImageAfid(rowId, index + 1),
      prompt
    })),
    videoPrompt: stripLeadingSceneTag(videoSide),
    expectedImageCount: imagePrompts.length,
    expectedVideoCount
  };
}

function buildManifestRowFromMatrixRow(row = {}) {
  const rowId = normalizeManifestRowId(row.rowId || row.sceneId || row.id || (row.clipNumber ? `CLIP-${row.clipNumber}` : `ROW-${row.rowIndex || 1}`));
  const imageSlots = matrixImagePrompts(row).map((prompt, index) => ({
    index: index + 1,
    afid: buildImageAfid(rowId, index + 1),
    prompt
  }));
  return {
    rowId,
    finalVideoId: row.finalVideoId || `[${rowId}]`,
    imageSlots,
    videoPrompt: cleanBlockText(row.videoPrompt || row.prompt || ""),
    sourceVideoMediaId: cleanInlineText(row.sourceVideoMediaId || ""),
    sourceVideoHandle: cleanInlineText(row.sourceVideoHandle || ""),
    sourceVideoFileName: cleanInlineText(row.sourceVideoFileName || ""),
    expectedImageCount: Number(row.expectedImages ?? imageSlots.length) || 0,
    expectedVideoCount: Number(row.expectedVideos ?? 0) || 0
  };
}

function buildManifestRowPrompt(row = {}, settings = {}) {
  const expectedImages = Number(row.expectedImageCount || row.imageSlots?.length || 0);
  const expectedVideos = Number(row.expectedVideoCount ?? 1);
  const videoLines = expectedVideos > 0
    ? [
        `After all ${expectedImages} still image${expectedImages === 1 ? "" : "s"} for [${row.rowId}] are complete, use those exact generated stills as inputs and generate exactly ${expectedVideos} final video ${expectedVideos === 1 ? "output" : "outputs"} for ${row.finalVideoId}.`,
        "Use the preflight-confirmed Return silent videos setting.",
        `Video settings: ${settings.aspectRatio || "portrait"} aspect ratio, ${settings.videoLength || "8"} seconds, ${settings.model || DEFAULT_VIDEO_MODEL_PREFLIGHT}.`,
        `Video prompt: ${row.videoPrompt}`
      ]
    : [
        `After all ${expectedImages} still image${expectedImages === 1 ? "" : "s"} for [${row.rowId}] are complete, stop. No final video is expected for this row.`
      ];
  return [
    `Generate exactly ${expectedImages} still image${expectedImages === 1 ? "" : "s"} for [${row.rowId}].`,
    "Create-side image slots:",
    ...row.imageSlots.map((slot) => `- ${slot.afid}: ${slot.prompt}`),
    "",
    ...videoLines,
    "",
    ...AFID_PROMPT_GUIDANCE
  ].filter((line) => line !== "").join("\n");
}

function finalizeManifest(manifest = {}) {
  const rows = Array.isArray(manifest.rows) ? manifest.rows.filter((row) => row.rowId) : [];
  const expectedImageCount = rows.reduce((sum, row) => sum + Number(row.expectedImageCount || 0), 0);
  const expectedVideoCount = rows.reduce((sum, row) => sum + Number(row.expectedVideoCount || 0), 0);
  return {
    version: 1,
    kind: manifest.kind || "agent_afid_manifest",
    title: cleanInlineText(manifest.title || DEFAULT_TITLE),
    source: cleanInlineText(manifest.source || "agent_matrix"),
    guidance: AFID_PROMPT_GUIDANCE,
    expectedImageCount,
    expectedVideoCount,
    expectedImages: expectedImageCount,
    expectedVideos: expectedVideoCount,
    rows
  };
}

function extractPromptRows(promptText = "") {
  return normalizeNewlines(promptText)
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => /^\[[^\]]+\]\s+/.test(line) && line.includes("|||"));
}

function matrixImagePrompts(row = {}) {
  if (Array.isArray(row.frames) && row.frames.length) {
    return row.frames.map((frame) => cleanBlockText(frame.prompt || frame.text || "")).filter(Boolean);
  }
  if (Array.isArray(row.imageSlots) && row.imageSlots.length) {
    return row.imageSlots.map((slot) => cleanBlockText(slot.prompt || "")).filter(Boolean);
  }
  if (row.imagePrompt) return [cleanBlockText(row.imagePrompt)];
  const expected = Number(row.expectedImages || 0) || 0;
  return Array.from({ length: expected }, (_, index) => `Image slot ${index + 1}`);
}

function splitImagePrompts(createSide = "") {
  const cleaned = cleanBlockText(createSide);
  if (!cleaned) return [];
  if (cleaned.includes(";;")) return cleaned.split(/\s*;;\s*/).map(cleanBlockText).filter(Boolean);
  if (/^@img\d+\b/i.test(cleaned) && /;\s*@img\d+\b/i.test(cleaned)) {
    return cleaned.split(/\s*;\s*/).map(cleanBlockText).filter(Boolean);
  }
  return [cleaned];
}

function stripLeadingSceneTag(value = "") {
  return cleanBlockText(String(value || "").replace(/^\s*\[[^\]]+\]\s*/, ""));
}

function splitFirst(value = "", separator = "|||") {
  const text = String(value || "");
  const index = text.indexOf(separator);
  if (index === -1) return [text];
  return [text.slice(0, index), text.slice(index + separator.length)];
}

function normalizeManifestRowId(value = "") {
  const raw = String(value || "").trim().replace(/^\[|\]$/g, "");
  const sceneMatch = raw.match(/^(V\d+-S\d+)$/i);
  if (sceneMatch) return sceneMatch[1].toUpperCase();
  return cleanInlineText(raw)
    .toUpperCase()
    .replace(/[^A-Z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "") || "ROW-1";
}

function normalizeNewlines(value = "") {
  return String(value || "").replace(/\r\n?/g, "\n");
}

function cleanInlineText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function cleanBlockText(value = "") {
  return normalizeNewlines(value)
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function clampInt(value, min, max, fallback) {
  const next = Number.parseInt(value, 10);
  if (!Number.isFinite(next)) return fallback;
  return Math.max(min, Math.min(max, next));
}
