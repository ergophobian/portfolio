export const AGENT_BATCH_SUPERVISOR_VERSION = 1;
export const MAX_AGENT_SUPERVISED_BATCHES = 250;

export function createAgentBatchSupervisorState(input = {}) {
  const batches = Array.isArray(input.batches) ? input.batches : [];
  if (!batches.length) throw codedError("AGENT_BATCH_PLAN_EMPTY", "Agent batch supervisor requires at least one batch.");
  if (batches.length > MAX_AGENT_SUPERVISED_BATCHES) throw codedError("AGENT_BATCH_PLAN_TOO_LARGE", "Agent batch supervisor batch count exceeds the safety ceiling.");
  const ids = new Set();
  const normalized = batches.map((batch, index) => {
    const batchId = compact(batch.batchId || batch.matrix?.batch?.batchId || `BATCH-${String(index + 1).padStart(3, "0")}`);
    if (ids.has(batchId)) throw codedError("AGENT_BATCH_ID_DUPLICATE", `Duplicate Agent batch id: ${batchId}`);
    ids.add(batchId);
    const rowCount = Math.max(0, Number(batch.rowCount ?? batch.matrix?.rows?.length ?? 0) || 0);
    if (rowCount > 100) throw codedError("AGENT_BATCH_ROW_LIMIT_EXCEEDED", `${batchId} exceeds the 100-row batch ceiling.`);
    return {
      batchId,
      batchIndex: index + 1,
      rowCount,
      status: "pending",
      submitMarker: "none",
      submittedAt: "",
      reconciledAt: "",
      error: ""
    };
  });
  return {
    version: AGENT_BATCH_SUPERVISOR_VERSION,
    runId: compact(input.runId),
    projectId: compact(input.projectId),
    tabId: Number(input.tabId || 0) || 0,
    status: "ready",
    createdAt: input.now || new Date().toISOString(),
    updatedAt: input.now || new Date().toISOString(),
    batches: normalized
  };
}

export function nextAgentBatchAction(state = {}) {
  const batches = Array.isArray(state.batches) ? state.batches : [];
  const uncertain = batches.find((batch) => batch.submitMarker === "pending" || batch.status === "submit_uncertain");
  if (uncertain) return { action: "blocked", code: "AGENT_BATCH_SUBMIT_UNCERTAIN", batchId: uncertain.batchId };
  const awaiting = batches.find((batch) => batch.status === "submitted" || batch.status === "reconciling");
  if (awaiting) return { action: "reconcile", batchId: awaiting.batchId, batchIndex: awaiting.batchIndex };
  const pending = batches.find((batch) => batch.status === "pending");
  if (pending) {
    const priorIncomplete = batches.slice(0, pending.batchIndex - 1).find((batch) => batch.status !== "reconciled");
    if (priorIncomplete) return { action: "blocked", code: "AGENT_BATCH_ORDER_BLOCKED", batchId: pending.batchId };
    return { action: "submit", batchId: pending.batchId, batchIndex: pending.batchIndex };
  }
  if (batches.every((batch) => batch.status === "reconciled")) return { action: "complete" };
  const failed = batches.find((batch) => batch.status === "blocked" || batch.status === "failed");
  return { action: "blocked", code: failed?.error || "AGENT_BATCH_SUPERVISOR_BLOCKED", batchId: failed?.batchId || "" };
}

export function updateAgentBatchSupervisorState(state = {}, batchId = "", patch = {}, now = new Date().toISOString()) {
  const batches = (Array.isArray(state.batches) ? state.batches : []).map((batch) => batch.batchId === batchId ? { ...batch, ...patch } : batch);
  if (!batches.some((batch) => batch.batchId === batchId)) throw codedError("AGENT_BATCH_NOT_FOUND", `Unknown Agent batch id: ${batchId}`);
  const status = batches.every((batch) => batch.status === "reconciled")
    ? "complete"
    : batches.some((batch) => batch.status === "blocked" || batch.status === "failed" || batch.status === "submit_uncertain")
      ? "blocked"
      : "running";
  return { ...state, status, updatedAt: now, batches };
}

export function agentBatchFreshReconciliationComplete(reconciliation = {}, baselineMediaIds = []) {
  const baseline = new Set((Array.isArray(baselineMediaIds) ? baselineMediaIds : []).map(compact).filter(Boolean));
  const rows = Array.isArray(reconciliation.rows) ? reconciliation.rows : [];
  if (!rows.length) return false;
  return rows.every((row) => {
    const images = (Array.isArray(row.images) ? row.images : []).filter((item) => !baseline.has(compact(item.mediaId || item.id)));
    const videos = (Array.isArray(row.videoVersions) ? row.videoVersions : []).filter((item) => !baseline.has(compact(item.mediaId || item.id)));
    return images.length >= Math.max(0, Number(row.expectedImages || 0) || 0)
      && videos.length >= Math.max(0, Number(row.expectedVideos || 0) || 0);
  });
}

function compact(value = "") {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function codedError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}
