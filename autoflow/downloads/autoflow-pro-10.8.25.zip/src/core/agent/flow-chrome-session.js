export const FLOW_CHROME_SESSION_URL = "https://labs.google/fx/api/auth/session";

export function createFlowChromeSession(options = {}) {
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  const now = options.now || (() => Date.now());
  const sessionUrl = String(options.sessionUrl || FLOW_CHROME_SESSION_URL);
  if (typeof fetchImpl !== "function") throw new Error("Flow Chrome session requires fetchImpl");
  let cached = null;
  let pending = null;

  async function getAccessToken(input = {}) {
    const nowMs = Number(now());
    if (input.forceFresh !== true && cached?.token && cached.expiresAt > nowMs + 30_000) {
      return cached.token;
    }
    if (pending) return pending;
    pending = (async () => {
      const response = await fetchImpl(sessionUrl, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        headers: { accept: "application/json" }
      });
      const text = await response.text().catch(() => "");
      if (!response.ok) {
        throw flowChromeAuthError("FLOW_CHROME_AUTH_UNAVAILABLE", `Chrome Flow login returned HTTP ${Number(response.status || 0)}.`, {
          status: Number(response.status || 0)
        });
      }
      let session;
      try { session = text ? JSON.parse(text) : {}; } catch {
        throw flowChromeAuthError("FLOW_CHROME_AUTH_INVALID", "Chrome Flow login returned invalid session JSON.");
      }
      const token = String(session?.access_token || session?.accessToken || "").trim();
      if (!token) {
        throw flowChromeAuthError("FLOW_CHROME_LOGIN_REQUIRED", "Sign in to Google Flow in this Chrome profile before running Auto Flow.");
      }
      const parsedExpiry = Date.parse(String(session?.expires || ""));
      // Never persist this credential. Keep it only in service-worker memory and
      // force a refresh within five minutes even when the web session is longer.
      const expiresAt = Number.isFinite(parsedExpiry)
        ? Math.min(parsedExpiry, nowMs + 5 * 60_000)
        : nowMs + 60_000;
      cached = { token, expiresAt };
      return token;
    })();
    try {
      return await pending;
    } finally {
      pending = null;
    }
  }

  async function authorizedFetch(url, init = {}) {
    const token = await getAccessToken();
    const headers = new Headers(init.headers || {});
    headers.set("authorization", `Bearer ${token}`);
    return fetchImpl(url, {
      ...init,
      mode: init.mode || "cors",
      credentials: init.credentials || "include",
      headers
    });
  }

  function clear() {
    cached = null;
  }

  return { getAccessToken, authorizedFetch, clear };
}

function flowChromeAuthError(code, message, details = undefined) {
  const error = new Error(message);
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}
