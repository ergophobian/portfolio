// Agent live-submit safety primitives.
//
// These are the security-critical guards for Agent Mode live submission:
//  - evaluateAgentTarget() fails closed when an explicit target (projectId/tabId)
//    does not match the Flow tab the service worker actually resolved, so a newer
//    or different Flow tab cannot silently steal a submit (P0-1 target safety).
//  - createAgentSubmitLock() is an in-memory mutex keyed by projectId||tabId
//    so two concurrent live submits to the same target cannot race the debugger
//    into the same composer (P0-2 live-submit lock).
//
// Kept as a small, pure, dependency-free module so the logic is unit-testable in
// isolation and easy to audit. The service worker owns the real tab/project state
// and wires these in; dry-runs and reconcile never acquire the lock.

function trimmed(value) {
  return String(value ?? "").trim();
}

/**
 * Canonical lock key for a live submit target. The browser tab is the real
 * independent composer; caller-controlled lane labels are not part of the
 * mutex because two labels can still drive the same tab.
 * @param {string} projectId resolved Flow project id ("" when unknown)
 * @param {number|string} tabId resolved Chrome tab id
 * @returns {string} `${projectId}||${tabId}`
 */
export function agentSubmitLockKey(projectId, tabId) {
  return `${trimmed(projectId)}||${trimmed(tabId)}`;
}

/**
 * Fail-closed check that the resolved Flow tab matches the requested target.
 * Returns { ok: true } when no explicit target was requested or it matches.
 * Returns { ok: false, code: "AGENT_TARGET_MISMATCH", message, details } otherwise.
 */
export function evaluateAgentTarget({
  requestedProjectId,
  requestedTabId,
  resolvedProjectId,
  resolvedTabId
} = {}) {
  const wantProject = trimmed(requestedProjectId);
  if (wantProject && wantProject !== trimmed(resolvedProjectId)) {
    return {
      ok: false,
      code: "AGENT_TARGET_MISMATCH",
      message: `Requested projectId ${wantProject} does not match the active Flow tab projectId ${trimmed(resolvedProjectId) || "(none)"}.`,
      details: {
        requestedProjectId: wantProject,
        resolvedProjectId: trimmed(resolvedProjectId)
      }
    };
  }

  const wantTab = trimmed(requestedTabId);
  if (wantTab && Number(wantTab) !== Number(resolvedTabId)) {
    return {
      ok: false,
      code: "AGENT_TARGET_MISMATCH",
      message: `Requested tabId ${wantTab} does not match the resolved Flow tab ${resolvedTabId}.`,
      details: {
        requestedTabId: wantTab,
        resolvedTabId
      }
    };
  }

  return { ok: true };
}

/**
 * Pick the explicit targeting fields (projectId/tabId/laneId) from a CLI/MCP
 * args object, keeping only present, trimmed, non-empty values. Used to forward
 * targeting into the bridge payload without leaking unrelated option keys.
 * @returns {{projectId?: string, tabId?: string, laneId?: string}}
 */
export function agentTargetPayloadFields(source = {}) {
  const fields = {};
  for (const key of ["projectId", "tabId", "laneId"]) {
    const value = trimmed(source[key]);
    if (value) fields[key] = value;
  }
  return fields;
}

function normalizeComposerText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

/**
 * True only when one of the composer's text fields exactly matches the prompt
 * (whitespace-normalized). Deliberately strict: the CDP composer insertion can
 * intermittently drop characters, and a strict round-trip check fails closed so
 * a character-mangled prompt is never submitted — the caller retries instead.
 */
export function agentPromptInserted(composerTexts = [], prompt = "") {
  const want = normalizeComposerText(prompt);
  if (!want) return false;
  return (Array.isArray(composerTexts) ? composerTexts : [])
    .some((value) => normalizeComposerText(value) === want);
}

/**
 * Classified error the composer-target resolver returns when it cannot POSITIVELY
 * identify the Agent prompt composer. Distinct from the bridge-layer
 * AGENT_COMPOSER_NOT_FOUND probe so the two fail-closed paths stay independent.
 */
export const AGENT_COMPOSER_TARGET_UNRESOLVED = "AGENT_COMPOSER_TARGET_UNRESOLVED";

function normalizeTargetRect(rect = {}) {
  const source = rect && typeof rect === "object" ? rect : {};
  const x = Number(source.x ?? source.left ?? 0) || 0;
  const y = Number(source.y ?? source.top ?? 0) || 0;
  const width = Number(source.width ?? 0) || 0;
  const height = Number(source.height ?? 0) || 0;
  const right = Number(source.right ?? (x + width)) || (x + width);
  const bottom = Number(source.bottom ?? (y + height)) || (y + height);
  return { x, y, width, height, right, bottom };
}

function targetLabelTokens(candidate = {}) {
  return [
    candidate.label,
    candidate.placeholder,
    candidate.ariaLabel,
    candidate.name,
    candidate.title
  ].map((value) => String(value ?? "")).join(" ").toLowerCase();
}

function targetIconTokens(candidate = {}) {
  const tokens = candidate.iconTokens;
  if (Array.isArray(tokens)) return tokens.map((token) => String(token ?? "").toLowerCase());
  return String(tokens ?? "").toLowerCase().split(/\s+/).filter(Boolean);
}

// Bottom-right quadrant composer (the classic docked Agent panel corner).
function isBottomRightZone(rect, vw, vh) {
  return rect.right > vw * 0.55 && rect.bottom > vh * 0.55;
}

// Centered Agent layouts: horizontally centered panel sitting in the lower
// portion of the viewport rather than pinned to a corner. Keep this in sync
// with the isCenteredComposer computation in service-worker.js
// (executeAgentPromptWithDebugger) — both must agree on the same shape.
// The upper width bound (<= 60% vw) exists specifically to keep Flow's
// ordinary non-Agent main prompt bar (also editable, non-search, centered,
// and low but typically near full-width) out of THIS zone. It only narrows
// the centered shape, so its protection covers the band the centered zone
// alone would accept (bottom <= 0.55 * vh): a bottom-anchored full-width bar
// whose rect also satisfies the separate, pre-existing isBottomRightZone
// (right > 0.55 * vw && bottom > 0.55 * vh) is still accepted via that zone
// — a pre-existing tradeoff this bound does not change. The realistic
// defense against that shape lives in the service-worker probe's stricter
// zone computation (base zone requires rect.x > 0.55 * vw;
// isBottomRightComposer requires height > 80), not in this guard's geometry.
// The height floor (>= 60px) exists specifically to distinguish a real
// Agent composer box (multi-line-capable, taller) from a short single-line
// modal dialog input (rename/save dialog) or scrubber-style control that
// happens to be centered in the lower viewport. The height ceiling
// (<= 35% vh) plus the y-origin lower bound (>= 25% vh) exist to keep a
// TALL centered overlay (e.g. a fullscreen description/edit textarea that
// starts near the top of the viewport) out of this zone — without them, a
// tall enough editable overlay would otherwise satisfy every other check
// here purely by also being wide/centered/low.
function isCenteredZone(rect, vw, vh) {
  const centerX = rect.x + rect.width / 2;
  return centerX >= vw * 0.3
    && centerX <= vw * 0.7
    && rect.width >= vw * 0.25
    && rect.width <= vw * 0.6
    && rect.y >= vh * 0.25
    && rect.height >= 60
    && rect.height <= vh * 0.35
    && rect.bottom > vh * 0.45;
}

// Full-height right-docked panel (spans most of the viewport height, not
// just the bottom-right corner). Keep in sync with isRightPanelComposer in
// service-worker.js. Best-effort geometric heuristic pending live-layout
// verification: real right-docked panel composers may be short inputs at the
// panel bottom (already covered by the bottom-right zone) rather than
// elements this tall. It stays gated behind the editable + non-search-like
// requirements in classifyAgentComposerCandidate, so on its own it cannot
// cause a false composer identification without the element also being an
// editable non-search input.
// The upper width bound (<= 40% vw) exists specifically to distinguish a
// narrow right-docked panel composer column from a wide editable
// overlay/modal (e.g. a fullscreen description textarea) that happens to be
// right-anchored and tall enough to satisfy the right-edge and height-share
// checks alone.
function isRightPanelZone(rect, vw, vh) {
  return rect.right >= vw * 0.85
    && rect.width <= vw * 0.4
    && rect.height >= vh * 0.35;
}

/**
 * Structural, language-agnostic classification of one candidate editor element
 * as the real Agent prompt composer, the Flow top search bar, or neither.
 *
 * Pure and unit-testable: callers pass plain descriptors read from the page
 * (tag, editable flag, rect, label/icon tokens, and — when available — the
 * structural flags the page already computed: isAgentComposerZone,
 * isBottomRightComposer, isSearchLikeInput). Focus state is deliberately NOT a
 * positive signal: a focused search bar must still be rejected.
 */
export function classifyAgentComposerCandidate(candidate = {}, viewport = {}) {
  const rect = normalizeTargetRect(candidate.rect);
  const vw = Math.max(1, Number(viewport.width) || 0);
  const vh = Math.max(1, Number(viewport.height) || 0);
  const tag = String(candidate.tag || candidate.tagName || "").toLowerCase();
  const role = String(candidate.role || candidate.ariaRole || "").toLowerCase();
  const type = String(candidate.type || candidate.inputType || "").toLowerCase();
  const labels = targetLabelTokens(candidate);
  const icons = targetIconTokens(candidate);

  const editable = candidate.isEditable === true
    || candidate.editable === true
    || candidate.contentEditable === true
    || candidate.contentEditable === "true"
    || candidate.contentEditable === "plaintext-only"
    || candidate.dataSlateEditor === true
    || tag === "textarea"
    || role === "textbox"
    || (tag === "input" && (type === "" || /^(text|search)$/.test(type)));

  // Search-bar signals are structural first (input type, aria role, magnifier
  // icon token), label text second. Any one is enough to disqualify a candidate
  // from being the prompt composer.
  const searchType = type === "search" || role === "search" || role === "searchbox";
  const searchIcon = icons.includes("search");
  const searchLabel = /\b(search|find|filter)\b/.test(labels) || /\bassets?\b/.test(labels);
  const isSearchLikeInput = candidate.isSearchLikeInput === true
    || searchType
    || searchIcon
    || searchLabel;

  // A subframe candidate's rect is relative to ITS OWN frame's viewport, not
  // the top-level viewport passed in here, so the geometric zone fallbacks
  // below are meaningless for it. A subframe candidate is only ever accepted
  // when the page positively self-identifies its zone (explicitZoneFlag) —
  // otherwise it fails closed instead of being geometrically guessed against
  // the wrong viewport.
  const inSubframe = candidate.inSubframe === true
    || (candidate.frameId !== undefined && candidate.frameId !== null && Number(candidate.frameId) !== 0);

  // The prompt composer can be bottom-right, horizontally centered, or a
  // full-height right-docked panel; the top search bar sits in the upper
  // band. Prefer the page's precomputed zone flags when present. A tall
  // composer can extend into the top band, so top-band position rejects
  // search-like inputs only, not structurally-identified composers.
  const explicitZoneFlag = candidate.isAgentComposerZone === true
    || candidate.isBottomRightComposer === true
    || candidate.isCenteredComposer === true
    || candidate.isRightPanelComposer === true;
  const geometricZone = !inSubframe && (
    isBottomRightZone(rect, vw, vh)
    || isCenteredZone(rect, vw, vh)
    || isRightPanelZone(rect, vw, vh)
  );
  const composerZone = explicitZoneFlag || geometricZone;
  const topBand = rect.bottom <= vh * 0.25 || rect.y <= vh * 0.12;
  const isTopSearchBar = isSearchLikeInput && (topBand || !composerZone);

  const isComposer = editable && composerZone && !isSearchLikeInput;
  const score = (isComposer ? 10000 : 0)
    + (editable ? 2500 : 0)
    + (candidate.dataSlateEditor === true ? 1500 : 0)
    + Math.max(0, Math.min(rect.y, vh))
    + rect.x
    - (tag === "input" ? 4000 : 0);

  return {
    tag,
    editable,
    composerZone,
    topBand,
    isSearchLikeInput,
    isTopSearchBar,
    isComposer,
    inSubframe,
    rect,
    score
  };
}

/**
 * Fail-closed resolution of the Agent prompt composer from a list of candidate
 * descriptors. Returns { ok:true, target } ONLY when a candidate is positively
 * identified as the composer. Otherwise returns
 * { ok:false, code: AGENT_COMPOSER_TARGET_UNRESOLVED } — it never falls back to
 * the top search bar and never picks "whatever element has focus". The caller
 * must abort the type/submit when ok is false.
 *
 * The resolver is AUTHORITATIVE over the element actually typed into: when the
 * page marks the candidate it will drive (`isChosen: true` — the descriptor
 * whose rect becomes prepared.editorRect), the resolver re-validates THAT exact
 * element and fails closed if it is not itself the composer or is a rejected
 * search bar. This closes the gap where a composer merely EXISTS in the
 * population while the page typed into a different, unvalidated element.
 */
export function resolveAgentComposerTarget(candidates = [], viewport = {}) {
  const list = Array.isArray(candidates) ? candidates : (candidates ? [candidates] : []);
  const classified = list
    .filter((candidate) => candidate && typeof candidate === "object")
    .map((candidate) => ({ candidate, ...classifyAgentComposerCandidate(candidate, viewport) }));
  const composers = classified
    .filter((entry) => entry.isComposer)
    .sort((left, right) => right.score - left.score);
  const rejectedSearchBars = classified
    .filter((entry) => entry.isSearchLikeInput || entry.isTopSearchBar)
    .map((entry) => ({ rect: entry.rect, isTopSearchBar: entry.isTopSearchBar }));

  if (!composers.length) {
    return {
      ok: false,
      code: AGENT_COMPOSER_TARGET_UNRESOLVED,
      message: "Agent prompt composer could not be positively identified; refusing to type to avoid the Flow search bar.",
      candidatesConsidered: classified.length,
      rejectedSearchBars
    };
  }

  // When the page flagged which element it will actually type into, validate
  // THAT element — not merely that some composer exists in the population. A
  // chosen element that classifies as a search bar or is not a composer fails
  // closed, so a wrong-box submit is impossible even when a real composer is
  // also present elsewhere on the page.
  const chosen = classified.find((entry) => entry.candidate?.isChosen === true);
  if (chosen) {
    if (!chosen.isComposer || chosen.isSearchLikeInput || chosen.isTopSearchBar) {
      return {
        ok: false,
        code: AGENT_COMPOSER_TARGET_UNRESOLVED,
        message: "The page's chosen editor is not the identified Agent prompt composer; refusing to type to avoid a wrong-box submit.",
        candidatesConsidered: classified.length,
        chosenRejected: true,
        rejectedSearchBars
      };
    }
    return {
      ok: true,
      target: chosen.candidate,
      rect: chosen.rect,
      score: chosen.score,
      chosenValidated: true,
      rejectedSearchBars
    };
  }

  const best = composers[0];
  return {
    ok: true,
    target: best.candidate,
    rect: best.rect,
    score: best.score,
    rejectedSearchBars
  };
}

/**
 * In-memory mutex for live submits. acquire() returns false when the key is
 * already held (caller should surface AGENT_TARGET_BUSY); release() frees it.
 */
export function createAgentSubmitLock() {
  const held = new Set();
  return {
    isLocked(key) {
      return held.has(key);
    },
    acquire(key) {
      if (held.has(key)) return false;
      held.add(key);
      return true;
    },
    release(key) {
      held.delete(key);
    },
    size() {
      return held.size;
    }
  };
}
