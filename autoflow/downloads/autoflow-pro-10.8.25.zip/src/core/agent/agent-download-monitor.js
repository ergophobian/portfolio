import {
  detectArtifactMediaKind,
  resolveDownloadMediaKind
} from "../media/download-media-kind.js";

export function agentMediaKey(item = {}) {
  return compactString(item.mediaId || item.name || item.mediaName || item.id);
}

export function baselineAgentMediaKeys(items = []) {
  return uniqueStrings((items || []).map((item) => agentMediaKey(item)));
}

/**
 * Classify a gallery/reconcile item's media kind. URL/MIME/filename evidence
 * wins when present so a mis-declared kind (or a reference image scraped as
 * "videos") can never be selected as the opposite output type.
 */
export function classifyAgentMediaItemKind(item = {}) {
  const evidence = detectArtifactMediaKind({
    filename: item.filename || item.name || item.title || "",
    mime: item.mime || item.mimeType || item.contentType || "",
    finalUrl: item.finalUrl || item.url || item.mediaUrl || item.redirectUrl || ""
  });
  if (evidence) return evidence;
  return resolveDownloadMediaKind(item.kind || item.mediaKind || item.type || "", item.filename || item.title || "");
}

export function selectFreshAgentOutputs(items = [], run = {}, options = {}) {
  const kind = resolveDownloadMediaKind(options.kind || "videos", "") || compactString(options.kind || "videos");
  const runExpected = kind === "images" ? run.expectedImages : run.expectedVideos;
  const expected = Math.max(0, Number.parseInt(options.expected ?? runExpected ?? 0, 10) || 0);
  const baseline = new Set(uniqueStrings(run.baselineMediaIds || run.baselineMediaKeys || []));
  const seen = new Set();
  const fresh = [];
  for (const item of items || []) {
    const mediaKey = agentMediaKey(item);
    if (!mediaKey || baseline.has(mediaKey) || seen.has(mediaKey)) continue;
    if (kind && !agentItemMatchesExpectedKind(item, kind)) continue;
    if (!matchesAgentRunProject(item, run)) continue;
    if (isBlockedAgentOutput(item)) continue;
    seen.add(mediaKey);
    fresh.push(item);
  }
  return expected > 0 ? fresh.slice(0, expected) : fresh;
}

/**
 * Select novel media IDs for an expected kind. Never falls back to the opposite
 * kind (the r3 JPEG-as-MP4 failure: any novel id was claimed as video).
 *
 * Returns { selectedIds, selectedItems, rejectedWrongKind, novelIds }.
 */
export function selectNovelAgentMediaForExpectedKind(items = [], options = {}) {
  const expectedKind = resolveDownloadMediaKind(options.kind || options.expectedKind || "videos", "") || "videos";
  const baseline = new Set(uniqueStrings(options.baselineMediaIds || options.baseline || []));
  const expected = Math.max(0, Number.parseInt(options.expected ?? 1, 10) || 0);
  const projectId = compactString(options.projectId || options.run?.projectId || "");

  const novelIds = [];
  const rejectedWrongKind = [];
  const selectedItems = [];
  const seen = new Set();

  for (const item of items || []) {
    const mediaKey = agentMediaKey(item);
    if (!mediaKey || baseline.has(mediaKey) || seen.has(mediaKey)) continue;
    // Novel selection only rejects positive project mismatches. Unstamped
    // reconcile ids (mediaIds-only lists) remain eligible; download readiness
    // still fails closed on unstamped gallery items when a run project is known.
    if (projectId) {
      const itemProjectId = compactString(item.projectId || item.flowProjectId || item.project?.id);
      if (itemProjectId && itemProjectId !== projectId) continue;
    }
    if (isBlockedAgentOutput(item)) continue;
    seen.add(mediaKey);
    novelIds.push(mediaKey);

    if (!agentItemMatchesExpectedKind(item, expectedKind)) {
      rejectedWrongKind.push({
        mediaId: mediaKey,
        expectedKind,
        actualKind: classifyAgentMediaItemKind(item) || compactString(item.kind || item.mediaKind || item.type) || "unknown"
      });
      continue;
    }
    selectedItems.push(item);
  }

  const limited = expected > 0 ? selectedItems.slice(0, expected) : selectedItems;
  return {
    selectedIds: limited.map((item) => agentMediaKey(item)).filter(Boolean),
    selectedItems: limited,
    rejectedWrongKind,
    novelIds,
    expectedKind,
    ready: expected > 0 ? limited.length >= expected : limited.length > 0
  };
}

export function buildAgentDownloadNamingSnapshot(presets = {}, options = {}) {
  return {
    folder: compactString(options.folder || presets.downloadFolder || "Auto-Flow"),
    imageResolution: compactString(options.imageResolution || presets.imageAutoDownloadResolution || "1k"),
    videoResolution: compactString(options.videoResolution || presets.videoDownloadResolution || "720p"),
    filenameStyle: compactString(presets.filenameStyle || "detailed"),
    filenameTemplatePrefix: compactString(presets.filenameTemplatePrefix || ""),
    filenameTemplateIndex: compactString(presets.filenameTemplateIndex || ""),
    filenameTemplatePromptPart: compactString(presets.filenameTemplatePromptPart || ""),
    filenameTemplateDate: compactString(presets.filenameTemplateDate || ""),
    filenameTemplateSuffix: compactString(presets.filenameTemplateSuffix || ""),
    filenameTemplateSeparator: compactString(presets.filenameTemplateSeparator || "")
  };
}

export function applyAgentOwnedDownloadMetadata(items = [], ownedOutputs = [], runId = "") {
  const byMediaId = new Map((Array.isArray(ownedOutputs) ? ownedOutputs : [])
    .map((output) => [agentMediaKey(output), output])
    .filter(([mediaId]) => mediaId));
  return (Array.isArray(items) ? items : []).map((item) => {
    const mediaId = agentMediaKey(item);
    const ownership = byMediaId.get(mediaId);
    if (!ownership) return item;
    const rowId = compactString(ownership.rowId || "ROW");
    return {
      ...item,
      rowId,
      taskId: `agent:${compactString(runId) || "run"}:${rowId}`,
      taskNumber: Math.max(1, Number(ownership.rowIndex || 1) || 1),
      mediaIndex: Math.max(0, Number(ownership.slotIndex || 0) || 0),
      prompt: compactString(ownership.sourcePrompt || item.prompt || item.title || `[${rowId}]`),
      agentOutputSlot: compactString(ownership.slotLabel || "")
    };
  });
}

export function agentReconciledDownloadReadiness(items = [], run = {}) {
  const reconciliation = run.reconciliation && typeof run.reconciliation === "object"
    ? run.reconciliation
    : null;
  const rows = Array.isArray(reconciliation?.rows) ? reconciliation.rows : [];
  const expectedImages = Math.max(0, Number.parseInt(reconciliation?.expectedImages ?? run.expectedImages ?? 0, 10) || 0);
  const expectedVideos = Math.max(0, Number.parseInt(reconciliation?.expectedVideos ?? run.expectedVideos ?? 0, 10) || 0);
  const selectedKind = expectedVideos > 0 ? "videos" : "images";
  const expectedDownloads = selectedKind === "videos" ? expectedVideos : expectedImages;
  const base = {
    ready: false,
    selectedKind,
    expectedImages,
    expectedVideos,
    expectedDownloads,
    selectedIds: [],
    mediaIds: [],
    ownedOutputs: []
  };
  if (!reconciliation || !rows.length) return { ...base, reason: "reconciliation_required" };
  if (!compactString(run.projectId)) return { ...base, reason: "project_required" };
  if (expectedDownloads < 1) return { ...base, reason: "no_expected_downloads" };

  const ownedOutputs = [];
  const baselineMediaIds = new Set((Array.isArray(run.baselineMediaIds) ? run.baselineMediaIds : []).map(compactString).filter(Boolean));
  for (const [rowIndex, row] of rows.entries()) {
    const rowId = compactString(row.tag || row.rowId || `ROW-${rowIndex + 1}`);
    const expected = Math.max(0, Number.parseInt(
      selectedKind === "videos" ? row.expectedVideos : row.expectedImages,
      10
    ) || 0);
    if (!expected) continue;
    const candidates = (selectedKind === "videos"
      ? latestOwnedVideoCandidates(row, expected)
      : uniqueMediaRecords(row.images || []))
      .filter((candidate) => !baselineMediaIds.has(agentMediaKey(candidate)));
    if (candidates.length !== expected) {
      return {
        ...base,
        reason: candidates.length < expected ? "owned_outputs_incomplete" : "owned_outputs_ambiguous",
        rowId,
        expectedForRow: expected,
        foundForRow: candidates.length
      };
    }
    for (const [slotIndex, candidate] of candidates.entries()) {
      ownedOutputs.push({
        rowId,
        rowIndex: Number(row.rowIndex ?? rowIndex + 1),
        kind: selectedKind,
        slotIndex,
        slotLabel: variationLabel(slotIndex),
        mediaId: agentMediaKey(candidate),
        sourcePrompt: compactString(candidate.prompt || candidate.videoPrompt || row.videoPrompt || row.prompt || row.title || `[${rowId}]`)
      });
    }
  }

  const mediaIds = ownedOutputs.map((entry) => entry.mediaId).filter(Boolean);
  if (mediaIds.length !== expectedDownloads || new Set(mediaIds).size !== mediaIds.length) {
    return { ...base, reason: "owned_output_count_mismatch", ownedOutputs };
  }
  const galleryByMediaId = new Map();
  for (const item of items || []) {
    const mediaId = agentMediaKey(item);
    if (!mediaId || galleryByMediaId.has(mediaId)) continue;
    if (!matchesAgentRunProject(item, run)) continue;
    if (!agentItemMatchesExpectedKind(item, selectedKind) || isBlockedAgentOutput(item)) continue;
    galleryByMediaId.set(mediaId, item);
  }
  const missingGalleryMediaIds = mediaIds.filter((mediaId) => !galleryByMediaId.has(mediaId));
  if (missingGalleryMediaIds.length) {
    return { ...base, reason: "owned_outputs_not_in_gallery", ownedOutputs, mediaIds, missingGalleryMediaIds };
  }
  return {
    ...base,
    ready: true,
    reason: "reconciled_row_ownership_complete",
    selectedIds: mediaIds,
    mediaIds,
    ownedOutputs
  };
}

export function agentDownloadReadiness(items = [], run = {}, options = {}) {
  const expectedImages = Math.max(0, Number.parseInt(run.expectedImages ?? options.expectedImages ?? 0, 10) || 0);
  const expectedVideos = Math.max(0, Number.parseInt(run.expectedVideos ?? options.expectedVideos ?? 0, 10) || 0);
  const freshImages = selectFreshAgentOutputs(items, run, { kind: "images", expected: expectedImages });
  const freshVideos = selectFreshAgentOutputs(items, run, { kind: "videos", expected: expectedVideos });
  const selectedKind = expectedVideos > 0 ? "videos" : "images";
  const freshDownloads = selectedKind === "videos" ? freshVideos : freshImages;
  const expectedDownloads = selectedKind === "videos" ? expectedVideos : expectedImages;
  return {
    ready: expectedDownloads > 0 && freshDownloads.length >= expectedDownloads,
    selectedKind,
    expectedImages,
    expectedVideos,
    expectedDownloads,
    freshImages,
    freshVideos,
    freshDownloads,
    selectedIds: freshDownloads.map((item) => item.mediaId || item.id).filter(Boolean),
    mediaIds: freshDownloads.map((item) => item.mediaId || item.id).filter(Boolean)
  };
}

function latestOwnedVideoCandidates(row = {}, expected = 1) {
  const slots = Array.isArray(row.videoSlots) ? row.videoSlots : [];
  if (slots.length) {
    return slots.map((slot) => slot.latestVideo || (Array.isArray(slot.versions) ? slot.versions.find((entry) => entry?.isLatest === true) || slot.versions.at(-1) : null)).filter(Boolean);
  }
  const versions = uniqueMediaRecords(row.videoVersions || []);
  if (expected > 1) {
    if (versions.length === expected) return versions;
    const markedLatest = versions.filter((entry) => entry?.isLatest === true);
    return markedLatest.length === expected ? markedLatest : versions;
  }
  const explicitLatest = row.latestVideo && agentMediaKey(row.latestVideo) ? [row.latestVideo] : [];
  if (explicitLatest.length) return explicitLatest;
  const markedLatest = versions.filter((entry) => entry?.isLatest === true);
  return markedLatest.length ? markedLatest : (versions.length === 1 ? versions : []);
}

function variationLabel(index = 0) {
  const value = Math.max(0, Number(index || 0) || 0);
  return value < 26 ? String.fromCharCode(65 + value) : String(value + 1);
}

function uniqueMediaRecords(values = []) {
  const seen = new Set();
  return (Array.isArray(values) ? values : []).filter((value) => {
    const mediaId = agentMediaKey(value);
    if (!mediaId || seen.has(mediaId)) return false;
    seen.add(mediaId);
    return true;
  });
}

function agentItemMatchesExpectedKind(item = {}, expectedKind = "") {
  const expected = resolveDownloadMediaKind(expectedKind, "") || compactString(expectedKind);
  if (!expected) return true;
  const actual = classifyAgentMediaItemKind(item);
  if (actual) return actual === expected;
  // No evidence either way: only accept when declared kind (after singular/plural
  // normalize) already matched expected. Bare/unknown kinds fail closed.
  const declared = resolveDownloadMediaKind(item.kind || item.mediaKind || item.type || "", item.filename || "");
  return declared === expected;
}

function isBlockedAgentOutput(item = {}) {
  const status = compactString(item.status || item.rawStatus || item.failureClass || item.error).toLowerCase();
  if (/\bfailed\b|failure|policy|violate|blocked|unsafe/.test(status)) return true;
  return Boolean(item.referenceOnly || item.isReference || item.inputAsset || item.isInputAsset);
}

function matchesAgentRunProject(item = {}, run = {}) {
  const runProjectId = compactString(run.projectId);
  if (!runProjectId) return false;
  const itemProjectId = compactString(item.projectId || item.flowProjectId || item.project?.id);
  return itemProjectId === runProjectId;
}

function uniqueStrings(values = []) {
  return [...new Set((values || []).map(compactString).filter(Boolean))];
}

function compactString(value = "") {
  return String(value || "").trim();
}
