export function buildAgentRenderFallbackInspection({
  context = {},
  progress = {},
  defaultMode = "video-only"
} = {}) {
  const blockers = Array.isArray(context.blockers) ? context.blockers : [];
  const hardBlocker = blockers.find((entry) => entry && entry.retryable !== true && entry.retryableWithPromptEdit !== true);
  if (hardBlocker) {
    const rows = rowsForBlocker(hardBlocker, progress);
    const retryPrompts = retryPromptsForRows(context.retryPrompts, rows);
    return {
      stop: true,
      status: "blocked",
      reason: hardBlocker.failureClass || "agent_blocked",
      blocker: compactBlocker(hardBlocker),
      retry: {
        rows: [],
        issue: issueForBlocker(hardBlocker),
        mode: defaultMode,
        retryPrompts
      }
    };
  }

  const actionRequired = context?.uiState?.actionRequired || null;
  if (actionRequired?.kind) {
    return {
      stop: true,
      status: "waiting_for_user",
      reason: `agent_${compactString(actionRequired.kind)}_required`,
      actionRequired: compactActionRequired(actionRequired)
    };
  }

  const blocker = blockers.find((entry) => entry?.retryable === true || entry?.retryableWithPromptEdit === true)
    || blockers[0];
  if (!blocker) {
    const runningSignal = runningSignalFromContext(context);
    if (runningSignal) {
      return {
        stop: false,
        status: "running",
        reason: `agent_${runningSignal}`,
        category: runningSignal,
        runningSignal
      };
    }
    return null;
  }

  const rows = rowsForBlocker(blocker, progress);
  const retryPrompts = retryPromptsForRows(context.retryPrompts, rows);

  if (!rows.length) {
    return {
      stop: true,
      status: "blocked",
      reason: "agent_blocker_needs_row_disambiguation",
      blocker: compactBlocker(blocker),
      retry: {
        rows: [],
        issue: issueForBlocker(blocker),
        mode: defaultMode,
        retryPrompts,
        needsRowDisambiguation: true,
        rowIdCandidates: normalizeRows(blocker.rowIdCandidates)
      }
    };
  }

  if (blocker.retryable === true && String(blocker.retryStrategy || "") === "retry_same_prompt") {
    return {
      stop: true,
      status: "retryable_blocker",
      reason: blocker.failureClass || "agent_retryable_blocker",
      blocker: compactBlocker(blocker),
      retry: {
        rows,
        issue: issueForBlocker(blocker),
        mode: defaultMode,
        notes: "Retry the affected row only with the same prompt, model, aspect ratio, duration, and attached inputs. Do not regenerate completed rows.",
        retryPrompts
      }
    };
  }

  if (blocker.retryableWithPromptEdit === true) {
    const hasConcreteRetryPrompt = retryPrompts.some((entry) => entry.prompt);
    return {
      stop: true,
      status: hasConcreteRetryPrompt ? "retryable_blocker" : "blocked",
      reason: hasConcreteRetryPrompt ? "agent_prompt_edit_retry_ready" : "agent_prompt_edit_required",
      blocker: compactBlocker(blocker),
      retry: {
        rows,
        issue: issueForBlocker(blocker),
        mode: defaultMode,
        notes: hasConcreteRetryPrompt
          ? "Flow requires a prompt edit before retry. Submit the provided repair prompt for the affected row only, then wait/reconcile again."
          : "Flow requires a prompt edit before retry. Use the provided retryPrompts, then retry only the affected rows.",
        retryPrompts
      }
    };
  }

  return {
    stop: true,
    status: "blocked",
    reason: blocker.failureClass || "agent_blocked",
    blocker: compactBlocker(blocker),
    retry: {
      rows,
      issue: issueForBlocker(blocker),
      mode: defaultMode,
      retryPrompts
    }
  };
}

function compactActionRequired(actionRequired = {}) {
  return {
    kind: compactString(actionRequired.kind),
    autoResolvable: actionRequired.autoResolvable === true,
    recommendedResponse: compactString(actionRequired.recommendedResponse),
    recommendedAction: compactString(actionRequired.recommendedAction),
    defaultChoice: compactString(actionRequired.defaultChoice),
    ...(meaningfulNumber(actionRequired.creditAmount) !== undefined ? { creditAmount: meaningfulNumber(actionRequired.creditAmount) } : {}),
    ...(actionRequired.creditAmountKnown === true ? { creditAmountKnown: true } : {}),
    ...(actionRequired.currency ? { currency: compactString(actionRequired.currency) } : {}),
    choices: Array.isArray(actionRequired.choices)
      ? actionRequired.choices.map(compactString).filter(Boolean).slice(0, 6)
      : []
  };
}

function runningSignalFromContext(context = {}) {
  const blocks = Array.isArray(context.blocks) ? context.blocks : [];
  const hasQueueWait = context?.category === "queue_wait"
    || context?.state === "running"
    || blocks.some((block) => block?.classification?.category === "queue_wait");
  return hasQueueWait ? "queue_wait" : "";
}

function meaningfulNumber(value) {
  if (value === null || value === undefined) return undefined;
  if (typeof value === "string" && value.trim() === "") return undefined;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : undefined;
}

function rowsForBlocker(blocker = {}, progress = {}) {
  const direct = normalizeRows([blocker.rowId]);
  if (direct.length) return direct;
  const missing = normalizeRows(progress.missingVideoTags || progress.missingRows);
  if (missing.length === 1) return missing;
  const candidates = normalizeRows(blocker.rowIdCandidates);
  return candidates.length === 1 ? candidates : [];
}

function retryPromptsForRows(retryPrompts = [], rows = []) {
  const rowSet = new Set(normalizeRows(rows));
  return (Array.isArray(retryPrompts) ? retryPrompts : [])
    .filter((entry) => rowSet.size === 0 || rowSet.has(normalizeRow(entry?.rowId)))
    .map((entry) => ({
      rowId: normalizeRow(entry?.rowId),
      prompt: compactString(entry?.prompt || entry?.text)
    }))
    .filter((entry) => entry.rowId && entry.prompt);
}

function issueForBlocker(blocker = {}) {
  if (blocker.failureClass === "agent_flow_auth_required") return "flow auth required";
  if (blocker.failureClass === "agent_flow_quota_exhausted") return "flow quota exhausted";
  if (blocker.failureClass === "agent_flow_credits_exhausted") return "flow credits exhausted";
  if (blocker.failureClass === "agent_flow_rate_limited") return "flow rate limited";
  if (blocker.failureClass === "agent_stalled_no_progress") return "stalled no progress";
  if (blocker.failureClass === "agent_generation_failed_unbilled") return "generation failed unbilled";
  if (blocker.failureClass === "agent_third_party_content_block") return "third party content block";
  if (blocker.failureClass === "agent_policy_prompt_block") return "policy prompt block";
  return compactString(blocker.failureClass || "missing output").replace(/[_-]+/g, " ");
}

function compactBlocker(blocker = {}) {
  return {
    rowId: normalizeRow(blocker.rowId),
    rowIdCandidates: normalizeRows(blocker.rowIdCandidates),
    needsRowDisambiguation: blocker.needsRowDisambiguation === true,
    text: compactString(blocker.text).slice(0, 500),
    failureClass: compactString(blocker.failureClass),
    category: compactString(blocker.category),
    retryable: blocker.retryable === true,
    retryableWithPromptEdit: blocker.retryableWithPromptEdit === true,
    retryStrategy: compactString(blocker.retryStrategy),
    recommendedAction: compactString(blocker.recommendedAction),
    ...(meaningfulNumber(blocker.unchangedProgressPolls) !== undefined ? { unchangedProgressPolls: meaningfulNumber(blocker.unchangedProgressPolls) } : {})
  };
}

function normalizeRows(values = []) {
  return uniqueStrings((Array.isArray(values) ? values : [values]).map(normalizeRow).filter(Boolean));
}

function normalizeRow(value = "") {
  return compactString(value).replace(/^\[/, "").replace(/\]$/, "");
}

function uniqueStrings(values = []) {
  return [...new Set(values)];
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}
