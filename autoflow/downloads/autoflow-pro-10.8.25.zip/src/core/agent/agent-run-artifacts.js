import { buildMediaRedirectUrl } from "../contracts/api.js";
import { buildDownloadFilename, isPortraitVideoAspect, sanitizeFolderName } from "../gallery/media-ledger.js";

const DEFAULT_OUTPUT_ROOT = "Auto Flow";
const READABLE_SLUG_WORDS = 7;
const LOW_SIGNAL_FILENAME_WORDS = new Set([
  "a",
  "an",
  "and",
  "as",
  "at",
  "cinematic",
  "clean",
  "close",
  "create",
  "created",
  "editorial",
  "exactly",
  "for",
  "from",
  "generate",
  "generated",
  "image",
  "in",
  "into",
  "macro",
  "no",
  "of",
  "on",
  "output",
  "photo",
  "photorealistic",
  "prompt",
  "product",
  "row",
  "shot",
  "still",
  "the",
  "to",
  "up",
  "use",
  "using",
  "vertical",
  "video",
  "with"
]);
const FAILURE_QA_STATUSES = new Set(["fail", "warn", "needs_human_review"]);
const QA_STATUS_ALIASES = {
  passed: "pass",
  success: "pass",
  failed: "fail",
  needs_review: "needs_human_review",
  human_review: "needs_human_review",
  needs_human: "needs_human_review"
};

export function planAgentRunArtifacts(options = {}) {
  const runName = compactString(options.runName || options.name || "Agent Run");
  const outputRoot = cleanPathPrefix(options.outputRoot || options.rootFolder || DEFAULT_OUTPUT_ROOT);
  const runSlug = safePathSegment(options.runSlug || runName, "agent-run");
  const runFolder = joinPath(outputRoot, runSlug);
  const latestOnly = resolveLatestOnlyOption(options);
  const qaFilter = normalizeQaFilter(options);
  const reservedTargetPaths = new Set((options.reservedTargetPaths || []).map(normalizeTargetPathKey).filter(Boolean));
  const seenMedia = new Set((options.reservedArtifactKeys || []).map((key) => String(key || "")).filter(Boolean));
  const seenTargets = new Set(reservedTargetPaths);
  const skipped = [];
  const downloads = [];
  const filenameOptions = {
    filenameStyle: compactString(options.filenameStyle || ""),
    filenameTemplatePrefix: compactString(options.filenameTemplatePrefix || ""),
    filenameTemplateIndex: compactString(options.filenameTemplateIndex || ""),
    filenameTemplatePromptPart: compactString(options.filenameTemplatePromptPart || ""),
    filenameTemplateDate: compactString(options.filenameTemplateDate || ""),
    filenameTemplateSuffix: compactString(options.filenameTemplateSuffix || ""),
    filenameTemplateSeparator: compactString(options.filenameTemplateSeparator || ""),
    imageResolution: compactString(options.imageResolution || "1k"),
    videoResolution: compactString(options.videoResolution || "720p")
  };

  const sourceRows = normalizeRows(options.rows || options.reconciledRows || []);
  const qaFailures = buildQaFailures(sourceRows, { runName });
  const manifestRows = [];
  const transcriptFiles = [];
  const retryFiles = [];

  for (const row of sourceRows) {
    const selectedVideos = selectVideosForDownload(row.videos, { latestOnly, qaFilter, skipped });
    const rowHasVideos = row.videos.length > 0;
    const includeRowMedia = selectedVideos.length > 0 || (!rowHasVideos && row.images.length > 0) || (!rowHasVideos && qaFilter.size === 0);
    if (!includeRowMedia) continue;

    const rowManifest = {
      rowId: row.rowId,
      displayTag: `[${row.rowId}]`,
      title: row.title,
      images: [],
      videos: []
    };

    if (options.includeImages !== false) {
      for (const image of row.images) {
        const download = buildImageDownload(row, image, runFolder, filenameOptions);
        if (reserveDownload(download, { seenMedia, seenTargets, skipped })) {
          downloads.push(download);
          rowManifest.images.push(imageManifestEntry(image, download));
        }
      }
    }

    if (options.includeVideos !== false) {
      for (const video of selectedVideos) {
        const download = buildVideoDownload(row, video, runFolder, filenameOptions);
        if (!reserveDownload(download, { seenMedia, seenTargets, skipped })) continue;
        downloads.push(download);
        const transcriptRefs = transcriptPathsForVideo(row, video);
        const videoEntry = videoManifestEntry(video, download, transcriptRefs);
        rowManifest.videos.push(videoEntry);
        transcriptFiles.push(...buildTranscriptFiles(row, video, runFolder, transcriptRefs));
      }
    }

    if (rowManifest.images.length || rowManifest.videos.length) {
      manifestRows.push(rowManifest);
      retryFiles.push(...buildRetryFiles(row, options.retryPrompts, runFolder));
    }
  }

  const manifest = buildManifest({
    runName,
    runSlug,
    outputRoot,
    runFolder,
    rows: manifestRows,
    downloads,
    skipped,
    createdAt: compactString(options.createdAt || "")
  });
  const report = buildReport({ runName, runFolder, manifest, qaFailures, skipped });
  const editorHandoff = buildEditorHandoff({ runName, runFolder, manifest, downloads });
  const files = [
    artifactFile("manifest", "manifests/manifest.json", runFolder, manifest),
    ...(options.includeEditorHandoff === true
      ? [artifactFile("editor_handoff", "handoff/editor-handoff.json", runFolder, editorHandoff)]
      : []),
    ...transcriptFiles,
    artifactFile("qa_failures", "qa/failures.json", runFolder, qaFailures),
    artifactFile("qa_report", "qa/report.html", runFolder, report.html, "text/html"),
    ...retryFiles
  ];

  return {
    version: 1,
    runName,
    runSlug,
    outputRoot,
    runFolder,
    downloads,
    mediaDownloads: downloads,
    files,
    manifest,
    report,
    editorHandoff,
    qaFailures,
    skipped
  };
}

function normalizeRows(rows = []) {
  return (Array.isArray(rows) ? rows : [])
    .map((row, index) => normalizeRow(row, index))
    .filter((row) => row.rowId)
    .sort(compareRows);
}

function normalizeRow(row = {}, index = 0) {
  const rowId = normalizeRowId(
    row.rowId || row.tag || row.videoTag || row.finalVideoId || row.id || row.sceneId || `ROW-${index + 1}`
  );
  const images = normalizeImages(row, rowId);
  const videos = normalizeVideos(row, rowId);
  return {
    source: row,
    rowId,
    rowIndex: Number.isFinite(Number(row.rowIndex || row.clipNumber)) ? Number(row.rowIndex || row.clipNumber) : index + 1,
    title: compactString(row.title || row.name || ""),
    qaStatus: normalizeQaStatus(row.qaStatus || row.qa?.status || row.status || ""),
    images,
    videos
  };
}

function normalizeImages(row = {}, rowId = "") {
  const expectedImages = explicitExpectedMediaCount(row, ["expectedImages", "expectedImageCount"]);
  if (expectedImages === 0) return [];
  const sourceImages = Array.isArray(row.images) && row.images.length
    ? row.images
    : Array.isArray(row.imageSlots)
      ? row.imageSlots
      : [];
  return sourceImages.map((image, index) => {
    const slotId = normalizeSlotId(image.slotId || image.imageAuditId || image.afid || "", rowId, index);
    return {
      source: image,
      slotId,
      mediaId: compactString(image.mediaId || image.id || image.name || image.mediaName || ""),
      prompt: compactString(image.prompt || image.sourcePrompt || ""),
      createTime: compactString(image.createTime || image.createdAt || ""),
      mapping: compactString(image.mapping || image.mappingConfidence || ""),
      isLatest: image.isLatest === true,
      qaStatus: normalizeQaStatus(image.qaStatus || image.qa?.status || "")
    };
  }).filter((image) => image.mediaId);
}

function normalizeVideos(row = {}, rowId = "") {
  const expectedVideos = explicitExpectedMediaCount(row, ["expectedVideos", "expectedVideoCount"]);
  if (expectedVideos === 0) return [];
  const slotCandidates = (Array.isArray(row.videoSlots) ? row.videoSlots : []).flatMap((slot, slotIndex) => {
    const versions = Array.isArray(slot?.versions) && slot.versions.length
      ? slot.versions
      : (slot?.latestVideo ? [slot.latestVideo] : []);
    return versions.map((video, versionIndex) => ({
      ...video,
      slotId: slot.slotId || `${rowId}-VID${slotIndex + 1}`,
      slotIndex: Number.isFinite(Number(slot.slotIndex)) ? Number(slot.slotIndex) : slotIndex,
      slotLabel: compactString(slot.slotLabel || variationLabel(slotIndex)),
      version: parsePositiveInt(video.version, versionIndex + 1)
    }));
  });
  const candidates = [
    ...slotCandidates,
    ...(Array.isArray(row.videoVersions) ? row.videoVersions : []),
    ...(Array.isArray(row.videos) ? row.videos : []),
    ...(row.video && typeof row.video === "object" ? [row.video] : []),
    ...(row.latestVideo && typeof row.latestVideo === "object" ? [row.latestVideo] : [])
  ];
  const videosByIdentity = new Map();
  for (const video of candidates) {
    const mediaId = compactString(video.mediaId || video.id || video.name || video.mediaName || "");
    if (!mediaId) continue;
    const version = parsePositiveInt(video.version, 0);
    const key = `${version || "unversioned"}:${mediaId}`;
    if (!videosByIdentity.has(key)) videosByIdentity.set(key, video);
  }
  const sorted = [...videosByIdentity.values()].sort(compareVideoSources);
  const hasExplicitLatest = sorted.some((video) => video.isLatest === true);
  const latestMediaId = compactString(row.latestVideo?.mediaId || "");
  return sorted.map((video, index) => {
    const version = parsePositiveInt(video.version, index + 1);
    const mediaId = compactString(video.mediaId || video.id || video.name || video.mediaName || "");
    const isLatest = hasExplicitLatest
      ? video.isLatest === true
      : latestMediaId
        ? mediaId === latestMediaId
        : index === sorted.length - 1;
    const qaStatus = normalizeQaStatus(video.qaStatus || video.qa?.status || row.qaStatus || row.qa?.status || "");
    return {
      source: video,
      rowId,
      slotId: compactString(video.slotId || ""),
      slotIndex: Number.isFinite(Number(video.slotIndex)) ? Number(video.slotIndex) : null,
      slotLabel: compactString(video.slotLabel || ""),
      version,
      mediaId,
      mediaGenerationId: compactString(video.mediaGenerationId || video.upscaleSourceId || video.generationId || ""),
      aspectRatio: compactString(video.aspectRatio || video.videoAspectRatio || row.aspectRatio || row.videoAspectRatio || ""),
      createTime: compactString(video.createTime || video.createdAt || ""),
      prompt: compactString(video.prompt || video.videoPrompt || row.videoPrompt || row.prompt || ""),
      title: compactString(video.title || ""),
      qaStatus,
      isLatest,
      isRetry: video.isRetry === true || video.retry === true || Boolean(video.retryOf) || version > 1,
      transcriptText: video.transcriptText ?? video.transcript?.text ?? null,
      transcriptJson: video.transcriptJson ?? video.transcript?.json ?? video.transcriptData ?? null
    };
  });
}

function explicitExpectedMediaCount(row = {}, fields = []) {
  for (const field of fields) {
    if (row[field] === undefined || row[field] === null || row[field] === "") continue;
    const count = Number(row[field]);
    if (Number.isFinite(count)) return Math.max(0, Math.floor(count));
  }
  return null;
}

function selectVideosForDownload(videos = [], { latestOnly = false, qaFilter = new Set(), skipped = [] } = {}) {
  return videos.filter((video) => {
    if (latestOnly && !video.isLatest) {
      skipped.push(skippedItem("latest_only_filtered", "video", video));
      return false;
    }
    if (qaFilter.size && !qaFilter.has(video.qaStatus)) {
      skipped.push(skippedItem("qa_status_filtered", "video", video));
      return false;
    }
    return true;
  });
}

function resolveLatestOnlyOption(options = {}) {
  if (Object.hasOwn(options, "latestOnly")) return options.latestOnly !== false;
  if (Object.hasOwn(options, "onlyLatest")) return options.onlyLatest !== false;
  return true;
}

function buildImageDownload(row = {}, image = {}, runFolder = "", filenameOptions = {}) {
  const imageResolution = filenameOptions.imageResolution || "1k";
  const requiresUpscale = imageDownloadRequiresUpscale(imageResolution);
  const relativePath = styledArtifactRelativePath("images", row, image, filenameOptions, {
    kind: "images",
    mediaIndex: imageSlotIndex(image.slotId),
    resolution: imageResolution
  }) || `images/${buildImageStem(row, image)}.${imageFallbackExtension(imageResolution)}`;
  const filename = joinPath(runFolder, relativePath);
  return {
    kind: "image",
    mediaKind: "images",
    rowId: row.rowId,
    slotId: image.slotId,
    mediaId: image.mediaId,
    sourcePrompt: image.prompt,
    mapping: image.mapping,
    relativePath,
    filename,
    targetPathKey: normalizeTargetPathKey(filename),
    artifactKey: `agent:images:${image.mediaId}`,
    url: buildMediaRedirectUrl({ mediaId: image.mediaId }),
    downloadPath: requiresUpscale ? "api_upscale" : "direct_named",
    resolution: imageResolution,
    requiresUpscale
  };
}

function imageFallbackExtension(resolution = "1k") {
  return ["2k", "4k"].includes(compactString(resolution).toLowerCase()) ? "png" : "jpeg";
}

function imageDownloadRequiresUpscale(resolution = "1k") {
  return ["2k", "4k"].includes(compactString(resolution).toLowerCase());
}

function normalizeAgentVideoResolution(value = "720p") {
  const normalized = compactString(value).toLowerCase();
  return normalized === "1080p" || normalized === "4k" ? normalized : "720p";
}

function videoDownloadRequiresUpscale(resolution = "720p") {
  return normalizeAgentVideoResolution(resolution) !== "720p";
}

function buildVideoDownload(row = {}, video = {}, runFolder = "", filenameOptions = {}) {
  const stem = buildVideoStem(row, video);
  const requestedResolution = normalizeAgentVideoResolution(filenameOptions.videoResolution || "720p");
  const videoResolution = isPortraitVideoAspect(video.aspectRatio) ? "720p" : requestedResolution;
  const requiresUpscale = videoDownloadRequiresUpscale(videoResolution);
  const relativePath = styledArtifactRelativePath("videos", row, video, filenameOptions, {
    kind: "videos",
    mediaIndex: video.slotIndex !== null && video.slotIndex !== undefined && Number.isFinite(Number(video.slotIndex))
      ? Math.max(0, Number(video.slotIndex))
      : Math.max(0, parsePositiveInt(video.version, 1) - 1),
    resolution: videoResolution
  }) || `videos/${stem}.mp4`;
  const filename = joinPath(runFolder, relativePath);
  return {
    kind: "video",
    mediaKind: "videos",
    rowId: row.rowId,
    slotId: video.slotId,
    slotIndex: video.slotIndex,
    slotLabel: video.slotLabel,
    version: video.version,
    mediaId: video.mediaId,
    mediaGenerationId: video.mediaGenerationId,
    aspectRatio: video.aspectRatio,
    isLatest: video.isLatest,
    isRetry: video.isRetry,
    qaStatus: video.qaStatus,
    sourcePrompt: video.prompt,
    createTime: video.createTime,
    relativePath,
    filename,
    targetPathKey: normalizeTargetPathKey(filename),
    artifactKey: `agent:videos:${video.mediaId}`,
    url: buildMediaRedirectUrl({ mediaId: video.mediaId }),
    downloadPath: requiresUpscale ? "api_upscale" : "direct_named",
    resolution: videoResolution,
    requiresUpscale
  };
}

function reserveDownload(download = {}, { seenMedia, seenTargets, skipped }) {
  if (!download.mediaId) return false;
  if (seenMedia.has(download.artifactKey)) {
    skipped.push({
      reason: "duplicate_media",
      kind: download.kind,
      rowId: download.rowId,
      mediaId: download.mediaId,
      relativePath: download.relativePath
    });
    return false;
  }
  if (seenTargets.has(download.targetPathKey)) {
    skipped.push({
      reason: "reserved_target_path",
      kind: download.kind,
      rowId: download.rowId,
      mediaId: download.mediaId,
      relativePath: download.relativePath,
      targetPathKey: download.targetPathKey
    });
    return false;
  }
  seenMedia.add(download.artifactKey);
  seenTargets.add(download.targetPathKey);
  return true;
}

function imageManifestEntry(image = {}, download = {}) {
  return {
    slotId: image.slotId,
    mediaId: image.mediaId,
    prompt: image.prompt,
    mapping: image.mapping,
    relativePath: download.relativePath,
    sourcePath: download.filename
  };
}

function videoManifestEntry(video = {}, download = {}, transcriptRefs = {}) {
  return {
    slotId: video.slotId,
    slotIndex: video.slotIndex,
    slotLabel: video.slotLabel,
    version: video.version,
    mediaId: video.mediaId,
    createTime: video.createTime,
    prompt: video.prompt,
    isLatest: video.isLatest,
    isRetry: video.isRetry,
    qaStatus: video.qaStatus,
    relativePath: download.relativePath,
    sourcePath: download.filename,
    transcripts: transcriptRefs
  };
}

function transcriptPathsForVideo(row = {}, video = {}) {
  const stem = buildVideoStem(row, video);
  return {
    text: `transcripts/${stem}.txt`,
    json: `transcripts/${stem}.json`
  };
}

function buildImageStem(row = {}, image = {}) {
  return compactStemParts([
    rowOrderPrefix(row),
    artifactLabel(row, image),
    imageSlotLabel(image.slotId),
    readableArtifactSlug(row, image),
    shortMediaId(image.mediaId)
  ]);
}

function buildVideoStem(row = {}, video = {}) {
  return compactStemParts([
    rowOrderPrefix(row),
    artifactLabel(row, video),
    explicitExpectedMediaCount(row.source || {}, ["expectedVideos", "expectedVideoCount"]) > 1 ? video.slotLabel || "" : "",
    readableArtifactSlug(row, video),
    `v${parsePositiveInt(video.version, 1)}`,
    video.isRetry ? "retry" : "",
    shortMediaId(video.mediaId)
  ]);
}

function styledArtifactRelativePath(folder = "", row = {}, media = {}, filenameOptions = {}, options = {}) {
  if (!compactString(filenameOptions.filenameStyle)) return "";
  return buildDownloadFilename({
    id: media.mediaId,
    mediaId: media.mediaId,
    kind: options.kind,
    mediaIndex: options.mediaIndex,
    prompt: artifactPromptWithRowTag(row, media),
    title: media.title || row.title || ""
  }, {
    folder,
    taskNumber: row.rowIndex || 1,
    resolution: options.resolution,
    filenameStyle: filenameOptions.filenameStyle,
    filenameTemplatePrefix: filenameOptions.filenameTemplatePrefix,
    filenameTemplateIndex: filenameOptions.filenameTemplateIndex,
    filenameTemplatePromptPart: filenameOptions.filenameTemplatePromptPart,
    filenameTemplateDate: filenameOptions.filenameTemplateDate,
    filenameTemplateSuffix: filenameOptions.filenameTemplateSuffix,
    filenameTemplateSeparator: filenameOptions.filenameTemplateSeparator
  });
}

function artifactPromptWithRowTag(row = {}, media = {}) {
  const sourceText = compactString(media.prompt)
    || compactString(media.title)
    || compactString(row.title)
    || compactString(row.source?.videoPrompt)
    || compactString(row.source?.prompt);
  if (extractBracketTag(sourceText)) return sourceText;
  return `[${row.rowId}] ${sourceText || media.mediaId || "media"}`;
}

function variationLabel(index = 0) {
  const value = Math.max(0, Number(index || 0) || 0);
  return value < 26 ? String.fromCharCode(65 + value) : String(value + 1);
}

function imageSlotIndex(slotId = "") {
  const match = compactString(slotId).match(/IMG(\d+)/i);
  return Math.max(0, parsePositiveInt(match?.[1], 1) - 1);
}

function rowOrderPrefix(row = {}) {
  const index = parsePositiveInt(row.rowIndex, 0);
  return index ? String(index).padStart(2, "0") : "";
}

function artifactLabel(row = {}, media = {}) {
  const sourceText = compactStrings([
    media.title,
    media.prompt,
    row.source?.videoPrompt,
    row.source?.prompt
  ]).join(" ");
  const tag = extractBracketTag(sourceText);
  return safePathSegment(stripBrackets(tag) || row.rowId, row.rowId || "row");
}

function imageSlotLabel(slotId = "") {
  const match = compactString(slotId).match(/IMG\d+/i);
  return safeStemSegment(match ? match[0].toUpperCase() : "") || "";
}

function readableArtifactSlug(row = {}, media = {}) {
  const sourceText = compactString(media.title) || compactString(media.prompt) || compactString(row.title);
  if (!sourceText) return "";
  const meaningful = slugWordsForFilename(sourceText, { filterLowSignal: true });
  const words = meaningful.length ? meaningful : slugWordsForFilename(sourceText, { filterLowSignal: false });
  return safeStemSegment(words.slice(0, READABLE_SLUG_WORDS).join("-"));
}

function slugWordsForFilename(value = "", { filterLowSignal = true } = {}) {
  return normalizeFilenameText(value)
    .split(/\s+/)
    .filter(Boolean)
    .filter((word) => !filterLowSignal || !LOW_SIGNAL_FILENAME_WORDS.has(word));
}

function normalizeFilenameText(value = "") {
  return compactString(value)
    .replace(/<[^>]+>/g, " ")
    .replace(/\bAFID\s*:\s*[A-Z0-9_-]+(?:\s*-\s*IMG\d+)?\b/gi, " ")
    .replace(/\[[^\]]+\]/g, " ")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function extractBracketTag(value = "") {
  const match = compactString(value).match(/\[\s*([A-Z0-9][A-Z0-9_-]*(?:[-_][A-Z0-9][A-Z0-9_-]*)*)\s*\]/i);
  return match ? `[${match[1].toUpperCase()}]` : "";
}

function stripBrackets(value = "") {
  return compactString(value).replace(/^\[|\]$/g, "");
}

function shortMediaId(mediaId = "") {
  const safe = safeStemSegment(mediaId);
  if (!safe) return "media";
  const uuidMatch = safe.match(/^([a-f0-9]{8})-[a-f0-9-]{27,}$/i);
  return uuidMatch ? uuidMatch[1].toLowerCase() : safe.slice(0, 24);
}

function compactStemParts(parts = []) {
  return parts
    .map(safeStemSegment)
    .filter(Boolean)
    .join("_");
}

function buildTranscriptFiles(row = {}, video = {}, runFolder = "", transcriptRefs = {}) {
  const files = [];
  if (video.transcriptText !== null && video.transcriptText !== undefined) {
    files.push(artifactFile("transcript_text", transcriptRefs.text, runFolder, String(video.transcriptText), "text/plain"));
  }
  if (video.transcriptJson !== null && video.transcriptJson !== undefined) {
    files.push(artifactFile("transcript_json", transcriptRefs.json, runFolder, video.transcriptJson));
  }
  return files;
}

function buildRetryFiles(row = {}, retryPrompts = {}, runFolder = "") {
  const prompt = retryPromptForRow(row, retryPrompts);
  if (!prompt) return [];
  return [
    artifactFile(
      "retry_prompt",
      `retry-prompts/retry-${safePathSegment(row.rowId, "row")}.txt`,
      runFolder,
      prompt,
      "text/plain"
    )
  ];
}

function retryPromptForRow(row = {}, retryPrompts = {}) {
  const source = row.source || {};
  if (typeof retryPrompts === "function") return compactString(retryPrompts(row));
  if (retryPrompts && typeof retryPrompts === "object") {
    const prompt = retryPrompts[row.rowId] || retryPrompts[`[${row.rowId}]`];
    if (prompt) return compactString(prompt);
  }
  return compactString(source.retryPrompt || source.retry?.prompt || source.retry?.text || "");
}

function buildManifest({ runName, runSlug, outputRoot, runFolder, rows, downloads, skipped, createdAt }) {
  const videos = rows.flatMap((row) => row.videos);
  const images = rows.flatMap((row) => row.images);
  const manifest = {
    version: 1,
    kind: "agent_run_artifact_manifest",
    runName,
    runSlug,
    outputRoot,
    runFolder,
    summary: {
      rows: rows.length,
      images: images.length,
      videos: videos.length,
      latestVideos: videos.filter((video) => video.isLatest).length,
      retryVideos: videos.filter((video) => video.isRetry).length,
      downloads: downloads.length,
      skipped: skipped.length
    },
    rows
  };
  if (createdAt) manifest.createdAt = createdAt;
  return manifest;
}

function buildQaFailures(rows = [], { runName = "" } = {}) {
  const failureRows = [];
  for (const row of rows) {
    const videos = row.videos
      .filter((video) => FAILURE_QA_STATUSES.has(video.qaStatus))
      .map((video) => ({
        version: video.version,
        mediaId: video.mediaId,
        qaStatus: video.qaStatus,
        isLatest: video.isLatest,
        prompt: video.prompt
      }));
    if (videos.length) {
      failureRows.push({
        rowId: row.rowId,
        displayTag: `[${row.rowId}]`,
        videos
      });
    }
  }
  return {
    version: 1,
    kind: "agent_run_qa_failures",
    runName,
    summary: {
      rows: failureRows.length,
      videos: failureRows.reduce((sum, row) => sum + row.videos.length, 0)
    },
    rows: failureRows
  };
}

function buildReport({ runName = "", runFolder = "", manifest = {}, qaFailures = {}, skipped = [] } = {}) {
  const rows = manifest.rows || [];
  const htmlRows = rows.map((row) => {
    const videoCells = row.videos.map((video) => `${escapeHtml(`v${video.version}`)} ${escapeHtml(video.qaStatus || "pending")} ${video.isLatest ? "latest" : ""}`).join("<br>");
    return `<tr><td>${escapeHtml(row.rowId)}</td><td>${row.images.length}</td><td>${row.videos.length}</td><td>${videoCells}</td></tr>`;
  }).join("");
  const html = [
    "<!doctype html>",
    "<meta charset=\"utf-8\">",
    `<title>${escapeHtml(runName)} Artifact Report</title>`,
    `<h1>${escapeHtml(runName)} Artifact Report</h1>`,
    `<p>Run folder: ${escapeHtml(runFolder)}</p>`,
    `<p>Downloads: ${Number(manifest.summary?.downloads || 0)}. QA failure videos: ${Number(qaFailures.summary?.videos || 0)}. Skipped: ${skipped.length}.</p>`,
    "<table>",
    "<thead><tr><th>Row</th><th>Images</th><th>Videos</th><th>QA</th></tr></thead>",
    `<tbody>${htmlRows}</tbody>`,
    "</table>"
  ].join("\n");
  return {
    kind: "agent_run_artifact_report",
    runName,
    runFolder,
    summary: manifest.summary || {},
    qaFailureSummary: qaFailures.summary || {},
    skipped,
    html
  };
}

function buildEditorHandoff({ runName = "", runFolder = "", manifest = {}, downloads = [] } = {}) {
  const rows = (manifest.rows || []).map((row) => {
    const latestVideo = [...(row.videos || [])].reverse().find((video) => video.isLatest) || null;
    const passedLatestVideo = latestVideo && latestVideo.qaStatus === "pass" ? latestVideo : null;
    return {
      rowId: row.rowId,
      displayTag: row.displayTag || `[${row.rowId}]`,
      title: row.title || "",
      imagePaths: (row.images || []).map((image) => image.relativePath).filter(Boolean),
      videoPaths: (row.videos || []).map((video) => video.relativePath).filter(Boolean),
      latestVideoPath: latestVideo?.relativePath || "",
      passedLatestVideoPath: passedLatestVideo?.relativePath || "",
      qaStatus: latestVideo?.qaStatus || "",
      needsReview: latestVideo ? latestVideo.qaStatus !== "pass" : true
    };
  });
  const videos = downloads.filter((download) => download.kind === "video");
  const images = downloads.filter((download) => download.kind === "image");
  return {
    version: 1,
    kind: "agent_editor_handoff",
    runName,
    runFolder,
    summary: {
      rows: rows.length,
      images: images.length,
      videos: videos.length,
      latestVideos: rows.filter((row) => row.latestVideoPath).length,
      passedLatestVideos: rows.filter((row) => row.passedLatestVideoPath).length,
      needsReview: rows.filter((row) => row.needsReview).length
    },
    bundles: {
      images: images.map((download) => download.relativePath),
      videos: videos.map((download) => download.relativePath),
      latestVideos: rows.map((row) => row.latestVideoPath).filter(Boolean),
      passedLatestVideos: rows.map((row) => row.passedLatestVideoPath).filter(Boolean),
      qaReviewRows: rows.filter((row) => row.needsReview).map((row) => row.rowId)
    },
    rows
  };
}

function artifactFile(kind = "", relativePath = "", runFolder = "", data = null, contentType = "application/json") {
  const isJson = contentType === "application/json";
  const text = isJson ? `${JSON.stringify(data, null, 2)}\n` : String(data ?? "");
  return {
    kind,
    relativePath,
    path: joinPath(runFolder, relativePath),
    contentType,
    data,
    text
  };
}

function normalizeQaFilter(options = {}) {
  const values = options.qaStatuses || options.onlyQaStatuses || options.includeQaStatuses || options.qaStatus || options.only || [];
  const list = Array.isArray(values) ? values : [values];
  return new Set(list.map(normalizeQaStatus).filter((status) => status && status !== "all"));
}

function normalizeQaStatus(value = "") {
  const normalized = compactString(value).toLowerCase().replace(/[-\s]+/g, "_");
  return QA_STATUS_ALIASES[normalized] || normalized;
}

function normalizeRowId(value = "") {
  const raw = compactString(value).replace(/^AFID:/i, "").replace(/^\[|\]$/g, "");
  const sceneMatch = raw.match(/^(V\d+-S\d+)$/i);
  if (sceneMatch) return sceneMatch[1].toUpperCase();
  return safePathSegment(raw.toUpperCase(), "ROW-1");
}

function normalizeSlotId(value = "", rowId = "", index = 0) {
  const raw = compactString(value).replace(/^AFID:/i, "");
  const match = raw.match(/(V\d+-S\d+-IMG\d+)/i);
  if (match) return match[1].toUpperCase();
  return `${rowId}-IMG${index + 1}`;
}

function compareRows(left = {}, right = {}) {
  const leftIndex = Number(left.rowIndex || 0);
  const rightIndex = Number(right.rowIndex || 0);
  if (leftIndex !== rightIndex) return leftIndex - rightIndex;
  return left.rowId.localeCompare(right.rowId);
}

function compareVideoSources(left = {}, right = {}) {
  const leftVersion = parsePositiveInt(left.version, 0);
  const rightVersion = parsePositiveInt(right.version, 0);
  if (leftVersion && rightVersion && leftVersion !== rightVersion) return leftVersion - rightVersion;
  const timeCompare = toTime(left.createTime || left.createdAt) - toTime(right.createTime || right.createdAt);
  if (timeCompare) return timeCompare;
  return compactString(left.mediaId || left.id || left.name).localeCompare(compactString(right.mediaId || right.id || right.name));
}

function skippedItem(reason = "", kind = "", item = {}) {
  return {
    reason,
    kind,
    rowId: item.rowId || "",
    version: item.version || null,
    mediaId: item.mediaId || "",
    qaStatus: item.qaStatus || "",
    isLatest: item.isLatest === true
  };
}

function normalizeTargetPathKey(value = "") {
  return compactString(value)
    .replace(/\\/g, "/")
    .replace(/\s+/g, "-")
    .replace(/\/+/g, "/")
    .toLowerCase();
}

function cleanPathPrefix(value = "") {
  return String(value || DEFAULT_OUTPUT_ROOT)
    .replace(/[\\/:*?"<>|]+/g, "-")
    .replace(/\/+/g, "/")
    .replace(/^\/+|\/+$/g, "")
    .trim() || DEFAULT_OUTPUT_ROOT;
}

function safePathSegment(value = "", fallback = "artifact") {
  return sanitizeFolderName(value || fallback) || fallback;
}

function safeStemSegment(value = "") {
  return String(value || "")
    .replace(/[\\/:*?"<>|]+/g, "-")
    .replace(/\s+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function joinPath(...parts) {
  return parts.map((part) => String(part || "").replace(/^\/+|\/+$/g, "")).filter(Boolean).join("/");
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function compactStrings(values = []) {
  return values.map(compactString).filter(Boolean);
}

function parsePositiveInt(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function toTime(value = "") {
  const millis = Date.parse(value);
  return Number.isFinite(millis) ? millis : 0;
}

function escapeHtml(value = "") {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
