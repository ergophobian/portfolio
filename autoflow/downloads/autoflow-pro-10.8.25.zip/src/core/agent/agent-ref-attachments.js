export const AGENT_REF_SOURCE_TYPES = Object.freeze({
  LOCAL_UPLOAD: "local-upload",
  EXTENSION_BLOB: "extension-blob",
  FLOW_GENERATED: "flow-generated"
});

export const T2I_REF_UPLOAD_BATCH_SIZE = 3;
export const T2I_REF_UPLOAD_BATCH_DELAY_MS = 2000;

const AGENT_COMPOSER_ADD_CONTROL_MISSING_CODES = new Set([
  "AGENT_COMPOSER_ADD_CONTROL_MISSING",
  "AGENT_REF_ADD_BUTTON_NOT_FOUND"
]);

const AGENT_COMPOSER_NOT_READY_CODES = new Set([
  "AGENT_FLOW_COMPOSER_NOT_READY",
  "AGENT_REF_COMPOSER_NOT_READY",
  "AGENT_REF_ASSET_PICKER_NOT_OPEN"
]);

const AGENT_REF_ATTACH_UNAVAILABLE_CODES = new Set([
  "AGENT_REF_ATTACH_UNAVAILABLE",
  "AGENT_REF_ATTACH_FAILED",
  "AGENT_REF_ATTACH_TIMEOUT",
  "AGENT_REF_CHIPS_UNVERIFIED",
  "AGENT_REF_PICKER_FILE_NOT_FOUND",
  "AGENT_REF_PICKER_UPLOAD_NOT_FOUND",
  "AGENT_REF_ADD_TO_PROMPT_NOT_FOUND",
  "AGENT_REF_PICKER_STILL_OPEN",
  "AGENT_REF_FILE_INPUT_NOT_FOUND",
  "AGENT_REF_FILE_INPUT_HANDLE_MISSING",
  "AGENT_REF_FILE_CHOOSER_INTERCEPTION_FAILED",
  "AGENT_REF_FILE_INPUT_DELIVERY_FAILED",
  "AGENT_REF_EXTENSION_BLOB_MISSING",
  "AGENT_REF_EXTENSION_BLOB_TOO_LARGE",
  "AGENT_REF_FLOW_MEDIA_NOT_FOUND",
  "AGENT_REF_FLOW_MEDIA_SELECTION_UNVERIFIED",
  "AGENT_REF_STALE_CHIPS_NOT_CLEARED",
  "AGENT_REF_ATTACH_FLOW_REUSE_NOT_IMPLEMENTED"
]);

// Ordered, programmatic-only teardown steps for an aborted/completed CLI/MCP ref
// attach. None of these depend on the native OS file picker: the attach path
// delivers files through DOM.setFileInputFiles and intercepts the file-chooser
// dialog, so cleanup is always driven from code, never a human clicking Cancel.
export const AGENT_REF_ATTACH_TEARDOWN_STEPS = Object.freeze({
  CANCEL_INTERCEPTED_FILE_CHOOSER: "cancel_intercepted_file_chooser",
  CLOSE_ASSET_PICKER: "close_asset_picker",
  DISABLE_FILE_CHOOSER_INTERCEPTION: "disable_file_chooser_interception"
});

// The contract the CLI/MCP attach path must honor: files are delivered
// programmatically and the native picker is intercepted, never relied upon.
export const AGENT_REF_UPLOAD_CONTRACT = Object.freeze({
  usesNativePicker: false,
  fileDelivery: "DOM.setFileInputFiles",
  interceptFileChooserDialog: true,
  cancelPendingChooserOnAbort: true
});

export async function ensureT2IBatchRefMediaIds(batchTasks = [], options = {}) {
  const entries = normalizeList(batchTasks)
    .map((entry) => normalizeT2IBatchTaskEntry(entry))
    .filter((entry) => entry.task);
  const batchNum = Number(options.batchNum || 1) || 1;
  const projectId = cleanString(options.projectId);
  const uploadBatchSize = positiveInteger(options.batchSize, T2I_REF_UPLOAD_BATCH_SIZE);
  const uploadBatchDelayMs = positiveInteger(options.batchDelayMs, T2I_REF_UPLOAD_BATCH_DELAY_MS);
  const cache = mapLike(options.cache) ? options.cache : new Map();
  const logger = typeof options.logger === "function" ? options.logger : () => {};
  const wait = typeof options.wait === "function" ? options.wait : async () => {};
  const uploadRef = typeof options.uploadRef === "function" ? options.uploadRef : null;
  const onTaskPrepared = typeof options.onTaskPrepared === "function" ? options.onTaskPrepared : null;
  const shouldAbort = typeof options.shouldAbort === "function" ? options.shouldAbort : () => false;

  const refsToUpload = [];
  const uploadGroups = new Map();
  let cached = 0;
  let missing = 0;
  let failed = 0;
  let uploaded = 0;
  let authFailed = false;
  let rateLimited = false;

  for (const entry of entries) {
    const refs = await resolveT2IBatchRefs(entry, options);
    entry.refs = refs;
    entry.task._t2iBatchRefsPrepared = true;
    if (!refs.length) continue;

    for (const [index, ref] of refs.entries()) {
      const key = t2iBatchRefCacheKey(ref, entry.task, index, options);
      const cachedMediaId = cachedT2IBatchRefMediaId(cache, key);
      const existingMediaId = cachedMediaId || t2iBatchRefMediaId(ref, options);
      if (existingMediaId) {
        applyT2IBatchRefMediaId(ref, existingMediaId, entry.task, index, options);
        if (key) cache.set(key, existingMediaId);
        cached += 1;
        continue;
      }

      if (!await canUploadT2IBatchRef(ref, entry.task, index, options)) {
        missing += 1;
        traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload_missing", {
          batchNum,
          taskId: entry.task.id || "",
          ref: t2iBatchRefLabel(ref, index)
        }, "warn");
        continue;
      }

      const uploadKey = key || `${t2iBatchRefLabel(ref, index)}:${refsToUpload.length}`;
      const uploadEntry = { ...entry, ref, refIndex: index, uploadKey };
      if (uploadGroups.has(uploadKey)) {
        uploadGroups.get(uploadKey).refs.push(uploadEntry);
        continue;
      }
      uploadGroups.set(uploadKey, { uploadEntry, refs: [uploadEntry] });
      refsToUpload.push(uploadEntry);
    }
  }

  if (refsToUpload.length === 0) {
    await commitT2IBatchPreparedTasks(entries, onTaskPrepared);
    if (cached > 0 || missing > 0) {
      traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload", {
        batchNum,
        attempted: 0,
        cached,
        uploaded: 0,
        failed: missing
      }, missing > 0 ? "warn" : "info");
    }
    return {
      ok: missing === 0,
      attempted: 0,
      cached,
      uploaded: 0,
      failed: missing,
      authFailed: false,
      rateLimited: false,
      aborted: false
    };
  }

  if (!projectId && options.requireProjectId !== false) {
    await commitT2IBatchPreparedTasks(entries, onTaskPrepared);
    traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload", {
      batchNum,
      skipped: true,
      reason: "missing_project_id",
      attempted: refsToUpload.length,
      cached,
      uploaded: 0,
      failed: refsToUpload.length + missing
    }, "error");
    return {
      ok: false,
      attempted: refsToUpload.length,
      cached,
      uploaded: 0,
      failed: refsToUpload.length + missing,
      authFailed: false,
      rateLimited: false,
      aborted: false
    };
  }

  if (!uploadRef) {
    await commitT2IBatchPreparedTasks(entries, onTaskPrepared);
    traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload", {
      batchNum,
      skipped: true,
      reason: "missing_upload_ref",
      attempted: refsToUpload.length,
      cached,
      uploaded: 0,
      failed: refsToUpload.length + missing
    }, "error");
    return {
      ok: false,
      attempted: refsToUpload.length,
      cached,
      uploaded: 0,
      failed: refsToUpload.length + missing,
      authFailed: false,
      rateLimited: false,
      aborted: false
    };
  }

  let uploadedSoFar = 0;
  for (let start = 0; start < refsToUpload.length; start += uploadBatchSize) {
    if (shouldAbort()) {
      await commitT2IBatchPreparedTasks(entries, onTaskPrepared);
      return {
        ok: false,
        attempted: refsToUpload.length,
        cached,
        uploaded,
        failed: refsToUpload.length - uploadedSoFar + failed + missing,
        authFailed,
        rateLimited,
        aborted: true
      };
    }

    const chunk = refsToUpload.slice(start, start + uploadBatchSize);
    const results = await Promise.all(chunk.map(async (entry) => {
      const refLabel = t2iBatchRefLabel(entry.ref, entry.refIndex);
      traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload_start", {
        batchNum,
        taskId: entry.task.id || "",
        ref: refLabel,
        uploadedSoFar: uploadedSoFar + 1,
        total: refsToUpload.length
      });
      uploadedSoFar += 1;
      try {
        const result = await uploadRef({
          task: entry.task,
          ref: entry.ref,
          index: entry.refIndex,
          refLabel,
          projectId
        });
        return { entry, refLabel, result };
      } catch (error) {
        return {
          entry,
          refLabel,
          result: {
            ok: false,
            error: String(error?.message || error || "upload_exception")
          }
        };
      }
    }));

    for (const { entry, refLabel, result } of results) {
      const mediaId = t2iBatchUploadResultMediaId(result);
      if (result?.ok && mediaId) {
        const group = uploadGroups.get(entry.uploadKey);
        if (entry.uploadKey) cache.set(entry.uploadKey, mediaId);
        for (const grouped of group?.refs || [entry]) {
          applyT2IBatchRefMediaId(grouped.ref, mediaId, grouped.task, grouped.refIndex, options);
        }
        uploaded += 1;
        traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload_resolved", {
          batchNum,
          taskId: entry.task.id || "",
          ref: refLabel,
          mediaId
        });
        continue;
      }

      failed += 1;
      const errText = t2iBatchUploadErrorText(result);
      if (isT2IBatchAuthFailure(errText)) authFailed = true;
      if (isT2IBatchRateLimit(errText)) rateLimited = true;
      traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload_failed", {
        batchNum,
        taskId: entry.task.id || "",
        ref: refLabel,
        status: Number(result?.status || 0) || 0,
        statusText: cleanString(result?.statusText || ""),
        error: errText
      }, "warn");
    }

    if (start + uploadBatchSize < refsToUpload.length) {
      await wait(uploadBatchDelayMs);
    }
  }

  await commitT2IBatchPreparedTasks(entries, onTaskPrepared);
  const totalFailed = failed + missing;
  traceT2IBatchRefUpload(logger, "t2i_batch_ref_upload", {
    batchNum,
    attempted: refsToUpload.length,
    cached,
    uploaded,
    failed: totalFailed
  }, totalFailed > 0 ? "warn" : "info");

  return {
    ok: totalFailed === 0,
    attempted: refsToUpload.length,
    cached,
    uploaded,
    failed: totalFailed,
    authFailed,
    rateLimited,
    aborted: false
  };
}

/**
 * Plan the teardown for a ref-attach session. Given the live session state
 * (whether Flow's in-page asset picker is open, whether a native file-chooser
 * interception was armed, whether a chooser is currently pending), return the
 * ordered set of programmatic cleanup steps that MUST run before the debugger
 * detaches. The plan is always programmatic-only and never leaves the OS file
 * picker waiting on a human.
 */
export function planAgentRefAttachTeardown(state = {}) {
  const steps = [];
  if (state.pendingFileChooser === true) {
    steps.push({
      step: AGENT_REF_ATTACH_TEARDOWN_STEPS.CANCEL_INTERCEPTED_FILE_CHOOSER,
      method: "Page.handleFileChooser",
      programmatic: true
    });
  }
  if (state.assetPickerOpen !== false) {
    steps.push({
      step: AGENT_REF_ATTACH_TEARDOWN_STEPS.CLOSE_ASSET_PICKER,
      method: "escape_key",
      programmatic: true
    });
  }
  if (state.fileChooserInterceptionEnabled === true) {
    steps.push({
      step: AGENT_REF_ATTACH_TEARDOWN_STEPS.DISABLE_FILE_CHOOSER_INTERCEPTION,
      method: "Page.setInterceptFileChooserDialog",
      programmatic: true
    });
  }
  return {
    ok: true,
    dependsOnNativePicker: false,
    programmaticOnly: steps.every((entry) => entry.programmatic === true),
    steps
  };
}

/**
 * Decide which existing prompt ref chips must be removed before a fresh attach
 * so a new attach never inherits leftovers from a previous prompt. Returns the
 * removable stale ref chips (each carries the remove control the caller clicks),
 * plus any ref chips that expose no remover (surfaced as blocked, not silently
 * ignored). Non-ref chips are never removed, and fresh Flow welcome/suggestion
 * cards (clickable thumbnail cards without prompt-chip structure or a remover)
 * are structurally excluded so they never block a first submit.
 */
export function planAgentRefChipCleanup(existingChips = []) {
  const chips = normalizeList(existingChips)
    .map((chip, index) => normalizeExistingRefChip(chip, index))
    .filter((chip) => chip.isRefChip && chip.visible !== false);
  const removeChips = chips.filter((chip) => chip.removable);
  const blockedChips = chips.filter((chip) => !chip.removable);
  return {
    ok: true,
    cleanBeforeAttach: true,
    removeChips,
    removeCount: removeChips.length,
    blockedChips,
    blockedCount: blockedChips.length,
    hasStaleRefChips: chips.length > 0
  };
}

function normalizeExistingRefChip(chip, index = 0) {
  if (typeof chip === "string") {
    const label = cleanString(chip);
    return {
      index,
      label,
      visible: true,
      isRefChip: isRefLikeChipLabel(label),
      removable: false,
      removeRect: null
    };
  }
  if (!isPlainObject(chip)) {
    return { index, label: "", visible: false, isRefChip: false, removable: false, removeRect: null };
  }
  const label = [chip.label, chip.text, chip.name, chip.fileName, chip.mediaId]
    .map(cleanString)
    .find(Boolean) || "";
  const removeRect = isPlainObject(chip.removeRect)
    ? chip.removeRect
    : (isPlainObject(chip.removeControl) ? chip.removeControl : null);
  if (isFlowSuggestionCard(chip, label, removeRect)) {
    return {
      index,
      label,
      visible: chip.visible !== false,
      isRefChip: false,
      removable: false,
      removeRect: null
    };
  }
  const isRefChip = chip.isRefChip === true
    || chip.ref === true
    || cleanString(chip.kind).toLowerCase() === "ref"
    || cleanString(chip.type).toLowerCase() === "prompt-media"
    || isRefLikeChipLabel(label);
  const removable = chip.removable === true || Boolean(removeRect);
  return {
    index,
    label,
    visible: chip.visible !== false,
    isRefChip,
    removable,
    removeRect
  };
}

function isFlowSuggestionCard(chip = {}, label = "", removeRect = null) {
  if (!isPlainObject(chip)) return false;
  if (isRefLikeChipLabel(label) || removeRect) return false;
  const role = cleanString(chip.role).toLowerCase();
  const kind = cleanString(chip.kind).toLowerCase();
  const type = cleanString(chip.type).toLowerCase();
  const hasPromptChipStructure = chip.hasChipShell === true
    || chip.hasDataCardOpen === true
    || chip.promptChip === true
    || chip.ref === true
    || kind === "ref"
    || kind === "chip"
    || type === "prompt-media"
    || type === "chip";
  if (hasPromptChipStructure) return false;
  const clickableCard = chip.isSuggestionCard === true
    || chip.isClickableCard === true
    || role === "button"
    || role === "link";
  return clickableCard && chip.hasImageThumbnail === true;
}

export function planAgentRefAttachments(input = {}, options = {}) {
  const refs = normalizeList(input.refs || input.references || input.attachments || options.refs || []);
  const parsed = refs.map((ref, index) => normalizeRefDescriptor(ref, index));
  const errors = [];
  const handleMap = new Map();

  for (const attachment of parsed) {
    errors.push(...validateAttachment(attachment));
    if (!attachment.handle) continue;
    const existing = handleMap.get(attachment.handle) || [];
    existing.push(attachment);
    handleMap.set(attachment.handle, existing);
  }

  for (const [handle, matches] of handleMap.entries()) {
    if (matches.length > 1) {
      errors.push(planError(
        "AMBIGUOUS_REF_HANDLE",
        `Reference handle ${handle} matches ${matches.length} attachment sources.`,
        { handle, count: matches.length }
      ));
    }
  }

  const targetRefs = normalizeTargetRefs(input.targetRefs || input.targetReferences || options.targetRefs);
  const requiredHandles = targetRefs.length ? targetRefs : uniqueStrings(parsed.map((ref) => ref.handle));
  const seenTargetRefs = new Set();
  for (const handle of requiredHandles) {
    if (!handle) {
      errors.push(planError("MISSING_TARGET_REF_HANDLE", "Target reference handle is required."));
      continue;
    }
    if (seenTargetRefs.has(handle)) {
      errors.push(planError("AMBIGUOUS_TARGET_REF", `Target reference ${handle} is listed more than once.`, { handle }));
      continue;
    }
    seenTargetRefs.add(handle);
    if (!handleMap.has(handle)) {
      errors.push(planError("TARGET_REF_NOT_FOUND", `Target reference ${handle} does not match a planned attachment.`, { handle }));
    }
  }

  const liveAttach = input.liveAttach === true || options.liveAttach === true || normalizeMode(input.attachMode || input.mode) === "live_attach";
  const projectId = cleanString(input.projectId || options.projectId);
  const tabId = cleanString(input.tabId || options.tabId);
  if (liveAttach) {
    const missing = [];
    if (!projectId) missing.push("projectId");
    if (!tabId) missing.push("tabId");
    if (missing.length) {
      errors.push(planError(
        "MISSING_AGENT_TARGET",
        `Live Agent ref attach requires ${missing.join(" and ")}.`,
        { missing }
      ));
    }
  }

  const attachments = requiredHandles
    .flatMap((handle) => handleMap.get(handle) || [])
    .map(planAttachment);
  const base = {
    version: 1,
    kind: "agent_ref_attachment_plan",
    liveAttach,
    targetRefs: requiredHandles,
    requiredChipHandles: requiredHandles,
    attachments,
    readyForSubmit: false,
    safety: refSafetyContract()
  };
  if (projectId && tabId) base.flowProjectTarget = { projectId, tabId };

  if (errors.length) {
    return {
      ...base,
      ok: false,
      code: "AGENT_REF_PLAN_INVALID",
      message: "Agent ref attachment plan is invalid.",
      errors
    };
  }

  return {
    ...base,
    ok: true,
    errors: []
  };
}

export function verifyAgentRefAttachmentChips(plan = {}, visibleChips = []) {
  if (!plan || plan.ok !== true) {
    return {
      ok: false,
      code: "AGENT_REF_PLAN_INVALID",
      message: "Agent ref attachment chips cannot be verified for an invalid plan.",
      readyForSubmit: false,
      errors: Array.isArray(plan?.errors) ? plan.errors : []
    };
  }

  const chipHandles = visibleChipHandleSet(visibleChips);
  const requiredHandles = normalizeTargetRefs(plan.requiredChipHandles || plan.targetRefs || []);
  const attachments = Array.isArray(plan.attachments) ? plan.attachments : [];
  const missingChipHandles = requiredHandles.filter((handle) => {
    const aliases = attachmentChipAliases(handle, attachments);
    return !aliases.some((alias) => chipHandles.has(alias));
  });
  if (missingChipHandles.length) {
    return {
      ...plan,
      ok: false,
      code: "AGENT_REF_CHIPS_UNVERIFIED",
      message: `Flow Agent visible prompt chips are missing for ${missingChipHandles.join(", ")}.`,
      missingChipHandles,
      readyForSubmit: false,
      attachments: attachments.map((attachment) => ({ ...attachment, usable: false }))
    };
  }

  return {
    ...plan,
    ok: true,
    readyForSubmit: true,
    missingChipHandles: [],
    chipProof: {
      verifiedHandles: requiredHandles,
      visibleChipCount: Array.isArray(visibleChips) ? visibleChips.length : 0
    },
    attachments: attachments.map((attachment) => ({ ...attachment, usable: true, chipVerified: true }))
  };
}

export function verifyAgentRefAttachmentChipGrowth(plan = {}, beforeChips = [], afterChips = []) {
  if (!plan || plan.ok !== true) {
    return {
      ok: false,
      code: "AGENT_REF_PLAN_INVALID",
      message: "Agent ref attachment chip growth cannot be verified for an invalid plan.",
      readyForSubmit: false,
      errors: Array.isArray(plan?.errors) ? plan.errors : []
    };
  }
  const attachments = Array.isArray(plan.attachments) ? plan.attachments : [];
  const requiredAttachmentCount = attachments.length;
  if (!requiredAttachmentCount) {
    return {
      ...plan,
      ok: false,
      code: "AGENT_REF_CHIPS_UNVERIFIED",
      message: "Visible chip growth proof requires at least one planned Agent ref.",
      readyForSubmit: false
    };
  }
  const beforeCount = visibleRefChipCount(beforeChips);
  const afterCount = visibleRefChipCount(afterChips);
  const beforeUploadCandidateCount = visibleUploadCandidateChipCount(beforeChips);
  const afterUploadCandidateCount = visibleUploadCandidateChipCount(afterChips);
  const addedCount = Math.max(
    0,
    afterCount - beforeCount,
    afterUploadCandidateCount - beforeUploadCandidateCount
  );
  if (addedCount < requiredAttachmentCount) {
    return {
      ...plan,
      ok: false,
      code: "AGENT_REF_CHIPS_UNVERIFIED",
      message: `Flow Agent visible prompt chips did not increase by ${requiredAttachmentCount} after attachment.`,
      readyForSubmit: false,
      chipProof: {
        signal: "visible_ref_chip_count_not_increased",
        beforeCount,
        afterCount,
        beforeUploadCandidateCount,
        afterUploadCandidateCount,
        addedCount,
        requiredAddedCount: requiredAttachmentCount
      },
      attachments: attachments.map((attachment) => ({ ...attachment, usable: false }))
    };
  }
  return {
    ...plan,
    ok: true,
    readyForSubmit: true,
    missingChipHandles: [],
    chipProof: {
      signal: "visible_ref_chip_count_increased",
      beforeCount,
      afterCount,
      beforeUploadCandidateCount,
      afterUploadCandidateCount,
      addedCount,
      requiredAddedCount: requiredAttachmentCount
    },
    attachments: attachments.map((attachment) => ({ ...attachment, usable: true, chipVerified: true }))
  };
}

export function verifyAgentRefAttachmentVisibleMediaChips(plan = {}, visibleChips = []) {
  if (!plan || plan.ok !== true) {
    return {
      ok: false,
      code: "AGENT_REF_PLAN_INVALID",
      message: "Agent ref attachment visible media chips cannot be verified for an invalid plan.",
      readyForSubmit: false,
      errors: Array.isArray(plan?.errors) ? plan.errors : []
    };
  }
  const attachments = Array.isArray(plan.attachments) ? plan.attachments : [];
  const requiredAttachmentCount = attachments.length;
  if (!requiredAttachmentCount) {
    return {
      ...plan,
      ok: false,
      code: "AGENT_REF_CHIPS_UNVERIFIED",
      message: "Visible media chip proof requires at least one planned Agent ref.",
      readyForSubmit: false
    };
  }
  const visibleMediaChipCount = visibleRefChipCount(visibleChips);
  if (visibleMediaChipCount < requiredAttachmentCount) {
    return {
      ...plan,
      ok: false,
      code: "AGENT_REF_CHIPS_UNVERIFIED",
      message: `Flow Agent visible prompt media chips are below the required ${requiredAttachmentCount}.`,
      readyForSubmit: false,
      chipProof: {
        signal: "visible_ref_media_chip_missing",
        visibleMediaChipCount,
        requiredMediaChipCount: requiredAttachmentCount
      },
      attachments: attachments.map((attachment) => ({ ...attachment, usable: false }))
    };
  }
  return {
    ...plan,
    ok: true,
    readyForSubmit: true,
    missingChipHandles: [],
    chipProof: {
      signal: "visible_ref_media_chip_present",
      visibleMediaChipCount,
      requiredMediaChipCount: requiredAttachmentCount
    },
    attachments: attachments.map((attachment) => ({ ...attachment, usable: true, chipVerified: true }))
  };
}

export function normalizeAgentRefAttachError(error = {}) {
  const code = cleanString(error?.code || error?.error || "");
  const message = cleanString(error?.message || error?.error || code || "Agent reference attachment failed.");
  if (AGENT_COMPOSER_ADD_CONTROL_MISSING_CODES.has(code)) {
    return {
      ok: false,
      code: "AGENT_COMPOSER_ADD_CONTROL_MISSING",
      status: "setup_blocked",
      message: message || "Flow Agent composer add/reference control was not found.",
      originalCode: code,
      submitAttempted: false
    };
  }
  if (AGENT_COMPOSER_NOT_READY_CODES.has(code)) {
    return {
      ok: false,
      code: "AGENT_FLOW_COMPOSER_NOT_READY",
      status: "setup_blocked",
      message: message || "Flow Agent composer was not ready for submit.",
      originalCode: code,
      submitAttempted: false
    };
  }
  if (AGENT_REF_ATTACH_UNAVAILABLE_CODES.has(code)) {
    return {
      ok: false,
      code: "AGENT_REF_ATTACH_UNAVAILABLE",
      status: "pre_submit_blocked",
      message: message || "Flow Agent references could not be attached as visible prompt chips.",
      originalCode: code,
      submitAttempted: false
    };
  }
  return {
    ok: false,
    code: code || "AGENT_REF_ATTACH_FAILED",
    status: "",
    message,
    originalCode: code,
    submitAttempted: false
  };
}

export function summarizeAgentComposerAddControlCandidate(candidate = {}, viewport = {}) {
  const rect = candidate.rect && typeof candidate.rect === "object" ? candidate.rect : {};
  const width = Number(rect.width || 0);
  const height = Number(rect.height || 0);
  const right = Number(rect.right ?? (Number(rect.x || 0) + width));
  const bottom = Number(rect.bottom ?? (Number(rect.y || 0) + height));
  const viewportWidth = Math.max(1, Number(viewport.width || 0) || 1);
  const viewportHeight = Math.max(1, Number(viewport.height || 0) || 1);
  const rawText = cleanString(candidate.rawText || candidate.text || "");
  const text = cleanString(candidate.text || "");
  const tokens = new Set([
    ...normalizeList(candidate.iconTokens),
    ...rawText.split(/\s+/)
  ].map((token) => cleanString(token)).filter(Boolean));
  const tagName = cleanString(candidate.tagName || "button").toLowerCase();
  const compactControl = width >= 20 && width <= 72 && height >= 20 && height <= 72;
  const composerAddIcon = tokens.has("add_2")
    || /add_2/i.test(rawText)
    || (tokens.has("add") && !/arrow_forward|article_spark|tune|settings/i.test(rawText));
  const addLike = composerAddIcon
    || tokens.has("add_photo_alternate")
    || /add_photo_alternate|\b(add|attach|upload)\b/i.test(text);
  const blockedAction = tokens.has("arrow_forward")
    || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(rawText)
    || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(text);
  const className = cleanString(candidate.className || "");
  const iconOnlySubmit = /submit-button|(?:^|\s)submit(?:-|$|\s)/i.test(className)
    || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
  const sendLike = blockedAction
    || iconOnlySubmit
    || /\b(send|submit|generate)\b/i.test(text)
    || (!composerAddIcon && /\bcreate\b/i.test(text));
  const composerZone = right > viewportWidth * 0.65 && bottom > viewportHeight * 0.72;
  const score = (composerAddIcon ? 20000 : 0)
    + (addLike ? 5000 : -5000)
    + (composerZone ? 5000 : -5000)
    + (tagName === "button" ? 3000 : 0)
    + (compactControl ? 3000 : -8000)
    + (viewportWidth - Number(rect.x || 0))
    - Math.abs(width - 32);
  return {
    ...candidate,
    tagName,
    composerAddIcon,
    compactControl,
    addLike,
    sendLike,
    composerZone,
    score,
    ok: Boolean(composerAddIcon && addLike && !sendLike && composerZone && compactControl)
  };
}

export function selectAgentComposerAddControlCandidate(candidates = [], viewport = {}) {
  return normalizeList(candidates)
    .map((candidate) => summarizeAgentComposerAddControlCandidate(candidate, viewport))
    .filter((candidate) => candidate.ok)
    .sort((left, right) => right.score - left.score)[0] || null;
}

function normalizeRefDescriptor(ref, index = 0) {
  if (typeof ref === "string") return normalizeStringRef(ref, index);
  if (!isPlainObject(ref)) {
    return {
      index,
      handle: "",
      sourceType: "",
      raw: ref
    };
  }

  const from = cleanString(ref.from || ref.source || ref.ref || "");
  const fromSource = from ? parseFlowSource(from) : {};
  const sourceType = normalizeSourceType(ref.sourceType || ref.type || ref.kind || fromSource.sourceType || inferSourceType(ref));
  const handle = normalizeHandle(ref.handle || ref.refHandle || ref.targetRef || "");
  const attachment = {
    index,
    handle,
    sourceType,
    rowId: cleanString(ref.rowId || ref.row || ref.sourceRowId || fromSource.rowId),
    role: cleanString(ref.role || ""),
    order: positiveInteger(ref.order, index + 1),
    raw: ref
  };
  if (sourceType === AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD) {
    attachment.path = cleanString(ref.path || ref.filePath || ref.localPath || ref.file || from);
  }
  if (sourceType === AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB) {
    attachment.blobStoreId = cleanString(ref.blobStoreId || ref.blobId || ref.id || from);
    attachment.fileName = cleanString(ref.fileName || ref.name || "reference.png");
    attachment.mimeType = cleanString(ref.mimeType || "image/png");
  }
  if (sourceType === AGENT_REF_SOURCE_TYPES.FLOW_GENERATED) {
    attachment.mediaId = cleanString(ref.mediaId || ref.mediaName || ref.flowMediaId || fromSource.mediaId);
    attachment.fileName = cleanString(ref.fileName || ref.name || "");
    attachment.mimeType = cleanString(ref.mimeType || ref.contentType || "");
  }
  return attachment;
}

function normalizeStringRef(value = "", index = 0) {
  const text = cleanString(value);
  const owner = parseOwnedRefSpec(text);
  const spec = owner.spec;
  const fromMatch = spec.match(/^([^\s=]+)\s+from\s+(.+)$/i);
  if (fromMatch) {
    const source = parseFlowSource(fromMatch[2]);
    return {
      index,
      handle: normalizeHandle(fromMatch[1]),
      sourceType: AGENT_REF_SOURCE_TYPES.FLOW_GENERATED,
      rowId: owner.rowId || source.rowId,
      role: owner.role,
      mediaId: source.mediaId,
      raw: value
    };
  }

  const [left, right] = splitFirst(spec, "=");
  const handle = normalizeHandle(left);
  const sourceText = cleanString(right);
  const flowSource = parseFlowSource(sourceText);
  if (flowSource.sourceType === AGENT_REF_SOURCE_TYPES.FLOW_GENERATED) {
    return {
      index,
      handle,
      sourceType: AGENT_REF_SOURCE_TYPES.FLOW_GENERATED,
      rowId: owner.rowId || flowSource.rowId,
      role: owner.role,
      mediaId: flowSource.mediaId,
      raw: value
    };
  }
  return {
    index,
    handle,
    sourceType: AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD,
    rowId: owner.rowId,
    role: owner.role,
    path: sourceText,
    raw: value
  };
}

function parseOwnedRefSpec(value = "") {
  const text = cleanString(value);
  const match = text.match(/^\[?([A-Za-z0-9][A-Za-z0-9._-]{0,127})\]?::(.+)$/s);
  if (!match) return { rowId: "", role: "", spec: text };
  const remainder = cleanString(match[2]);
  const roleMatch = remainder.match(/^([^:=]{1,64})::(.+)$/s);
  return {
    rowId: cleanString(match[1]),
    role: cleanString(roleMatch?.[1] || ""),
    spec: cleanString(roleMatch?.[2] || remainder)
  };
}

function parseFlowSource(value = "") {
  const raw = cleanString(value).replace(/^flow:\/\//i, "flow:");
  const match = raw.match(/^flow:(.+)$/i);
  const sourceText = match ? match[1] : raw;
  if (!match && !/^[^/\s]+\/[^/\s]+$/.test(sourceText)) return {};
  const [rowId, mediaId] = splitFirst(sourceText, "/");
  return {
    sourceType: AGENT_REF_SOURCE_TYPES.FLOW_GENERATED,
    rowId: cleanString(rowId),
    mediaId: cleanString(mediaId)
  };
}

function validateAttachment(attachment = {}) {
  const errors = [];
  if (!attachment.handle) {
    errors.push(planError("MISSING_REF_HANDLE", "Reference attachment requires a handle.", { index: attachment.index }));
  }
  if (!attachment.sourceType) {
    errors.push(planError("MISSING_REF_SOURCE_TYPE", "Reference attachment requires a source type.", { handle: attachment.handle }));
    return errors;
  }
  if (!Object.values(AGENT_REF_SOURCE_TYPES).includes(attachment.sourceType)) {
    errors.push(planError("UNKNOWN_REF_SOURCE_TYPE", `Unsupported reference source type ${attachment.sourceType}.`, { handle: attachment.handle }));
    return errors;
  }
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD && !attachment.path) {
    errors.push(planError("MISSING_LOCAL_REF_PATH", `Local upload reference ${attachment.handle || "(missing handle)"} requires a file path.`, { handle: attachment.handle }));
  }
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB && !attachment.blobStoreId) {
    errors.push(planError("MISSING_EXTENSION_BLOB_ID", `Extension reference ${attachment.handle || "(missing handle)"} requires a blob store id.`, { handle: attachment.handle }));
  }
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.FLOW_GENERATED) {
    if (!attachment.rowId) {
      errors.push(planError("MISSING_FLOW_ROW_ID", `Flow-generated reference ${attachment.handle || "(missing handle)"} requires a row id.`, { handle: attachment.handle }));
    }
    if (!attachment.mediaId) {
      errors.push(planError("MISSING_FLOW_MEDIA_ID", `Flow-generated reference ${attachment.handle || "(missing handle)"} requires a media id.`, { handle: attachment.handle }));
    }
  }
  return errors;
}

function planAttachment(attachment = {}) {
  const actions = {
    [AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD]: "upload_local_file",
    [AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB]: "upload_extension_blob",
    [AGENT_REF_SOURCE_TYPES.FLOW_GENERATED]: "reuse_flow_media"
  };
  const planned = {
    handle: attachment.handle,
    sourceType: attachment.sourceType,
    action: actions[attachment.sourceType] || ""
  };
  if (attachment.role) planned.role = attachment.role;
  if (Number.isFinite(attachment.order)) planned.order = attachment.order;
  if (attachment.rowId) planned.rowId = attachment.rowId;
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD) planned.path = attachment.path;
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB) {
    planned.blobStoreId = attachment.blobStoreId;
    planned.fileName = attachment.fileName;
    planned.mimeType = attachment.mimeType;
  }
  if (attachment.sourceType === AGENT_REF_SOURCE_TYPES.FLOW_GENERATED) {
    planned.rowId = attachment.rowId;
    planned.mediaId = attachment.mediaId;
    if (attachment.fileName) planned.fileName = attachment.fileName;
  }
  planned.usable = false;
  return planned;
}

function refSafetyContract() {
  return {
    requiresVisiblePromptChips: true,
    usableAfter: "flow_agent_visible_prompt_chips_verified",
    submitWithoutChipProof: "fail_closed"
  };
}

function visibleChipHandleSet(chips = []) {
  const values = new Set();
  for (const chip of normalizeList(chips)) {
    if (typeof chip === "string") {
      const handle = normalizeHandle(chip);
      if (handle) values.add(handle);
      continue;
    }
    if (!isPlainObject(chip) || chip.visible === false) continue;
    for (const key of ["handle", "refHandle", "targetRef", "label", "text", "name", "mediaId"]) {
      const handle = normalizeHandle(chip[key]);
      if (handle) values.add(handle);
    }
  }
  return values;
}

function visibleRefChipCount(chips = []) {
  return normalizeList(chips)
    .filter((chip) => {
      if (isPlainObject(chip) && chip.visible === false) return false;
      const label = typeof chip === "string"
        ? chip
        : [
            chip?.label,
            chip?.text,
            chip?.name,
            chip?.fileName,
            chip?.mediaId
          ].map(cleanString).find(Boolean) || "";
      return isRefLikeChipLabel(label);
    }).length;
}

function visibleUploadCandidateChipCount(chips = []) {
  return normalizeList(chips)
    .filter((chip) => {
      if (isPlainObject(chip) && chip.visible === false) return false;
      const label = typeof chip === "string"
        ? chip
        : [
            chip?.label,
            chip?.text,
            chip?.name,
            chip?.fileName,
            chip?.mediaId
          ].map(cleanString).find(Boolean) || "";
      return isRefLikeChipLabel(label) || /^generated image$/i.test(cleanString(label));
    }).length;
}

function isRefLikeChipLabel(value = "") {
  const label = cleanString(value);
  return /\.(png|jpe?g|webp|gif|heic|avif)(?:\b|$)/i.test(label)
    || /\b(generated or uploaded by you|uploaded image|reference image|attached image|prompt image|prompt media)\b/i.test(label);
}

function attachmentChipAliases(handle = "", attachments = []) {
  const aliases = new Set([normalizeHandle(handle)].filter(Boolean));
  for (const attachment of attachments) {
    if (normalizeHandle(attachment?.handle) !== normalizeHandle(handle)) continue;
    [
      attachment.fileName,
      fileNameFromPath(attachment.path),
      attachment.mediaId,
      attachment.rowId ? `${attachment.rowId}/${attachment.mediaId || ""}` : ""
    ].map(normalizeHandle).filter(Boolean).forEach((alias) => aliases.add(alias));
  }
  return [...aliases];
}

function fileNameFromPath(value = "") {
  const text = cleanString(value);
  if (!text) return "";
  return text.split(/[\\/]/).filter(Boolean).pop() || text;
}

function inferSourceType(ref = {}) {
  if (ref.path || ref.filePath || ref.localPath || ref.file) return AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD;
  if (ref.mediaId || ref.mediaName || ref.flowMediaId || ref.rowId || ref.row || ref.sourceRowId) return AGENT_REF_SOURCE_TYPES.FLOW_GENERATED;
  if (ref.blobStoreId || ref.blobId) return AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB;
  return AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD;
}

function normalizeSourceType(value = "") {
  const normalized = cleanString(value).toLowerCase().replace(/[_\s]+/g, "-");
  if (["local", "local-file", "local-upload", "upload", "file-upload"].includes(normalized)) {
    return AGENT_REF_SOURCE_TYPES.LOCAL_UPLOAD;
  }
  if (["flow", "flow-generated", "flow-native", "flow-media", "generated", "reuse-flow-media"].includes(normalized)) {
    return AGENT_REF_SOURCE_TYPES.FLOW_GENERATED;
  }
  if (["extension-blob", "browser-blob", "blob-store", "indexeddb"].includes(normalized)) {
    return AGENT_REF_SOURCE_TYPES.EXTENSION_BLOB;
  }
  return cleanString(value);
}

function normalizeMode(value = "") {
  return cleanString(value).toLowerCase().replace(/[-\s]+/g, "_");
}

function normalizeTargetRefs(value) {
  return normalizeList(value)
    .flatMap((item) => String(item || "").split(","))
    .map(normalizeHandle);
}

function normalizeList(value) {
  if (value == null || value === false || value === true) return [];
  return Array.isArray(value) ? value : [value];
}

function uniqueStrings(values = []) {
  return [...new Set(values.map(cleanString).filter(Boolean))];
}

function normalizeHandle(value = "") {
  return cleanString(value);
}

function cleanString(value = "") {
  return String(value ?? "").trim();
}

function splitFirst(value = "", separator = "=") {
  const text = String(value || "");
  const index = text.indexOf(separator);
  if (index === -1) return [text, ""];
  return [text.slice(0, index), text.slice(index + separator.length)];
}

function normalizeT2IBatchTaskEntry(entry = {}) {
  const task = entry && typeof entry === "object" && entry.task && typeof entry.task === "object"
    ? entry.task
    : entry;
  return {
    task: task && typeof task === "object" ? task : null,
    refs: []
  };
}

async function resolveT2IBatchRefs(entry = {}, options = {}) {
  if (typeof options.resolveRefsForTask === "function") {
    const resolved = await options.resolveRefsForTask(entry.task);
    if (Array.isArray(resolved?.missing) && resolved.missing.length) {
      const logger = typeof options.logger === "function" ? options.logger : () => {};
      traceT2IBatchRefUpload(logger, "t2i_batch_ref_resolve_missing", {
        batchNum: Number(options.batchNum || 1) || 1,
        taskId: entry.task?.id || "",
        count: resolved.missing.length
      }, "warn");
    }
    return normalizeList(resolved?.refs || resolved).filter(isPlainObject);
  }
  return normalizeList(entry.task?.refInputs || entry.task?.refImages || entry.task?.references || []).filter(isPlainObject);
}

function t2iBatchRefMediaId(ref = {}, options = {}) {
  if (typeof options.getMediaId === "function") return cleanString(options.getMediaId(ref));
  return [
    ref.mediaId,
    ref.assetImageId,
    ref.mediaName,
    ref.flowMediaId,
    extractMediaIdFromString(ref.sourceUrl),
    extractMediaIdFromString(ref.url),
    extractMediaIdFromString(ref.src)
  ].map(cleanString).find(Boolean) || "";
}

function extractMediaIdFromString(value = "") {
  const text = cleanString(value);
  if (!text) return "";
  const nameParam = text.match(/[?&]name=([^&#]+)/i)?.[1];
  if (nameParam) return cleanString(decodeURIComponentSafe(nameParam));
  const mediaMatch = text.match(/\bmedia\/([A-Za-z0-9_-]{6,})\b/i)?.[1];
  if (mediaMatch) return cleanString(mediaMatch);
  return /^[A-Za-z0-9_-]{12,}$/.test(text) ? text : "";
}

function decodeURIComponentSafe(value = "") {
  try {
    return decodeURIComponent(String(value || ""));
  } catch {
    return String(value || "");
  }
}

function t2iBatchRefCacheKey(ref = {}, task = {}, index = 0, options = {}) {
  if (typeof options.cacheKeyForRef === "function") {
    return cleanString(options.cacheKeyForRef(ref, task, index));
  }
  return [
    ref.id,
    ref.refId,
    ref.blobStoreId,
    ref.sha256,
    ref.digest,
    ref.fileHash,
    ref.sourceUrl,
    ref.url,
    ref.src,
    task?.id && index >= 0 ? `${task.id}:${index}` : ""
  ].map(cleanString).find(Boolean) || "";
}

function cachedT2IBatchRefMediaId(cache, key = "") {
  if (!key || !mapLike(cache) || !cache.has(key)) return "";
  return cleanString(cache.get(key));
}

async function canUploadT2IBatchRef(ref = {}, task = {}, index = 0, options = {}) {
  if (typeof options.canUploadRef === "function") {
    return Boolean(await options.canUploadRef(ref, task, index));
  }
  return Boolean(cleanString(ref.dataUrl || ref.imageUrl || ref.mediaUrl || ref.imageBytes || ref.bytesBase64));
}

function applyT2IBatchRefMediaId(ref = {}, mediaId = "", task = {}, index = 0, options = {}) {
  const normalized = cleanString(mediaId);
  if (!normalized) return false;
  if (typeof options.applyMediaId === "function") {
    return options.applyMediaId(ref, normalized, task, index) !== false;
  }
  ref.mediaId = normalized;
  return true;
}

function t2iBatchUploadResultMediaId(result = {}) {
  return [
    result?.mediaId,
    result?.mediaName,
    result?.flowMediaId,
    Array.isArray(result?.mediaIds) ? result.mediaIds[0] : "",
    Array.isArray(result?.data?.mediaIds) ? result.data.mediaIds[0] : ""
  ].map(cleanString).find(Boolean) || "";
}

function t2iBatchUploadErrorText(result = {}) {
  if (result instanceof Error) return result.message || String(result);
  return [
    result?.error,
    result?.statusText,
    result?.data?.error,
    result?.data?.message,
    result?.code,
    result?.reason
  ].map((value) => {
    if (value instanceof Error) return value.message || String(value);
    if (value && typeof value === "object") {
      try {
        return JSON.stringify(value);
      } catch {
        return String(value);
      }
    }
    return cleanString(value);
  }).find(Boolean) || "unknown";
}

function isT2IBatchAuthFailure(text = "") {
  return /http_?40[13]|401|403|permission_denied|unauthenticated|not_signed_in/i.test(String(text || ""));
}

function isT2IBatchRateLimit(text = "") {
  return /http_?429|429|rate_limit|resource_exhausted|too many requests/i.test(String(text || ""));
}

function t2iBatchRefLabel(ref = {}, index = 0) {
  return cleanString(ref.fileName || ref.name || ref.title || ref.id || ref.blobStoreId) || `reference-${index + 1}.png`;
}

async function commitT2IBatchPreparedTasks(entries = [], onTaskPrepared = null) {
  if (!onTaskPrepared) return;
  const committed = new Set();
  for (const entry of entries) {
    const taskId = cleanString(entry.task?.id);
    const key = taskId || String(committed.size);
    if (committed.has(key)) continue;
    committed.add(key);
    await onTaskPrepared(entry.task, entry.refs || []);
  }
}

function traceT2IBatchRefUpload(logger, type = "", payload = {}, level = "info") {
  logger({
    type,
    level,
    ...payload
  });
}

function positiveInteger(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? Math.floor(number) : fallback;
}

function mapLike(value) {
  return Boolean(value)
    && typeof value.get === "function"
    && typeof value.set === "function"
    && typeof value.has === "function";
}

function planError(code, message, details = undefined) {
  const error = { code, message };
  if (details !== undefined) error.details = details;
  return error;
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
