// Same-window Flow tab connect + page-bridge recovery contracts.
//
// "Connect this Flow tab" must bind the Flow project tab in the same Chrome
// window/profile, recover the page bridge, then prove agent.context.get works.
// It must never fall back to another window, profile, or most-recent target.

function trimmed(value) {
  return String(value ?? "").trim();
}

function numberOrNull(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
}

export function normalizeConnectFlowTab(tab = {}) {
  const tabId = numberOrNull(tab.tabId ?? tab.id);
  const windowId = numberOrNull(tab.windowId);
  return {
    tabId,
    projectId: trimmed(tab.projectId),
    windowId,
    title: trimmed(tab.title),
    url: trimmed(tab.url),
    active: tab.active === true,
    discarded: tab.discarded === true,
    status: trimmed(tab.status),
    lastAccessed: numberOrNull(tab.lastAccessed)
  };
}

export function selectSameWindowFlowTab({
  tabs = [],
  windowId,
  requestedProjectId,
  requestedTabId,
  runtimeProjectId,
  runtimeTabId
} = {}) {
  const all = (Array.isArray(tabs) ? tabs : [])
    .map((tab) => normalizeConnectFlowTab(tab))
    .filter((tab) => tab.tabId && tab.projectId);
  const wantWindow = numberOrNull(windowId);
  const wantProject = trimmed(requestedProjectId);
  const wantTab = trimmed(requestedTabId);
  const runtimeTab = trimmed(runtimeTabId);
  const runtimeProject = trimmed(runtimeProjectId);

  if (wantTab) {
    const exact = all.find((tab) => String(tab.tabId) === wantTab);
    if (!exact) {
      return fail("FLOW_TAB_NOT_FOUND", `Requested Flow tab ${wantTab} was not found in this Chrome profile.`, {
        requestedTabId: wantTab,
        requestedProjectId: wantProject,
        windowId: wantWindow
      });
    }
    if (wantProject && exact.projectId !== wantProject) {
      return fail("AGENT_TARGET_MISMATCH", `Requested projectId ${wantProject} does not match Flow tab ${exact.tabId} project ${exact.projectId}.`, {
        requestedProjectId: wantProject,
        resolvedProjectId: exact.projectId,
        requestedTabId: wantTab,
        resolvedTabId: exact.tabId
      });
    }
    if (wantWindow != null && exact.windowId != null && exact.windowId !== wantWindow) {
      return fail("FLOW_TAB_WINDOW_MISMATCH", `Requested Flow tab ${exact.tabId} is in window ${exact.windowId}, not this window ${wantWindow}.`, {
        requestedWindowId: wantWindow,
        resolvedWindowId: exact.windowId,
        requestedTabId: wantTab,
        resolvedTabId: exact.tabId
      });
    }
    return { ok: true, tab: exact, reason: "requested_tab" };
  }

  let candidates = wantWindow == null
    ? all
    : all.filter((tab) => tab.windowId == null || tab.windowId === wantWindow);
  if (wantWindow != null && !candidates.length && all.length) {
    return fail("FLOW_TAB_WINDOW_MISMATCH", `No Flow project tab is open in this window (${wantWindow}).`, {
      windowId: wantWindow,
      otherWindowCount: all.length
    });
  }
  if (wantProject) {
    candidates = candidates.filter((tab) => tab.projectId === wantProject);
  }

  if (!candidates.length) {
    return fail("FLOW_TAB_NOT_FOUND", wantProject
      ? `No open Google Flow tab was found for project ${wantProject}.`
      : "No open Google Flow project tab was found in this window.", {
      requestedProjectId: wantProject,
      windowId: wantWindow
    });
  }

  if (candidates.length === 1) {
    return { ok: true, tab: candidates[0], reason: wantProject ? "requested_project" : "unique_window_tab" };
  }

  if (runtimeTab) {
    const runtimeExact = candidates.filter((tab) => String(tab.tabId) === runtimeTab);
    if (runtimeExact.length === 1 && (!runtimeProject || runtimeExact[0].projectId === runtimeProject)) {
      return { ok: true, tab: runtimeExact[0], reason: "runtime_tab" };
    }
  }

  return fail("FLOW_TAB_AMBIGUOUS", "Multiple Flow project tabs are open. Pass the exact projectId and tabId instead of guessing.", {
    windowId: wantWindow,
    requestedProjectId: wantProject,
    tabIds: candidates.map((tab) => String(tab.tabId)),
    projectIds: [...new Set(candidates.map((tab) => tab.projectId))]
  });
}

export function isFreshFlowBridgeProbe(probe = {}, expected = {}) {
  const ok = probe?.ok === true || probe?.ok === "true" || probe?.pageHookHealth?.ok === true || probe?.pageHookHealth?.ok === "true";
  const pageHookInstalled = probe?.pageHookInstalled === true || probe?.pageHookInstalled === "true";
  const expectedBridgeVersion = trimmed(expected.bridgeVersion || expected.expectedBridgeVersion);
  const expectedPageHookVersion = trimmed(expected.pageHookVersion || expected.expectedPageHookVersion);
  return Boolean(
    ok
    && pageHookInstalled
    && (!expectedBridgeVersion || trimmed(probe.bridgeVersion) === expectedBridgeVersion)
    && (!expectedPageHookVersion || trimmed(probe.pageHookVersion) === expectedPageHookVersion)
  );
}

export function shouldForceRecoverFlowBridge({ probe = {}, forceRecover = false, alreadyReloaded = false } = {}, expected = {}) {
  if (forceRecover !== true) return false;
  if (isFreshFlowBridgeProbe(probe, expected)) return false;
  if (alreadyReloaded === true && !probe) return false;
  return true;
}

export function classifyFlowPageConnectResult({
  tabSelection,
  probe,
  proofError,
  expectedBridgeVersion,
  expectedPageHookVersion
} = {}) {
  if (tabSelection && tabSelection.ok === false) {
    return {
      ...tabSelection,
      nextAction: nextActionForCode(tabSelection.code)
    };
  }

  const expected = { expectedBridgeVersion, expectedPageHookVersion };
  const flowPageIssue = probe?.pageHookHealth?.flowPageIssue || probe?.flowPageIssue || null;
  if (flowPageIssue?.blocked === true) {
    return fail(
      "FLOW_PAGE_RATE_LIMITED",
      trimmed(flowPageIssue.message || flowPageIssue.textPreview || "Flow page is temporarily rate limited."),
      { flowPageIssue },
      "Wait for Flow to recover, then connect this exact tab again. Do not switch projects."
    );
  }

  if (isFreshFlowBridgeProbe(probe, expected) && !proofError) {
    return {
      ok: true,
      code: "FLOW_PAGE_CONNECTED",
      message: "This Flow tab is attached and ready for commands.",
      nextAction: ""
    };
  }

  if (proofError) {
    return fail(
      "FLOW_PAGE_CONTEXT_UNAVAILABLE",
      trimmed(proofError.message || proofError || "Flow page snapshot is still unavailable after connect."),
      { proofError: proofError.code || "AGENT_CONTEXT_UNAVAILABLE" },
      "Stay on this Flow project tab and run autoflow connect again. If it still fails, reload only this tab and retry."
    );
  }

  if (!probe || (probe.ok !== true && !probe.pageHookInstalled && isMissingReceiver(probe.error))) {
    return fail(
      "FLOW_PAGE_HOOK_MISSING",
      trimmed(probe?.error || "The Flow page bridge is not installed in this tab."),
      { error: probe?.error || "missing_receiver" },
      "Stay on this Flow project tab and click Connect this Flow tab again so Auto Flow can inject the page bridge."
    );
  }

  const bridgeVersion = trimmed(probe?.bridgeVersion);
  const pageHookVersion = trimmed(probe?.pageHookVersion);
  if (
    (expectedBridgeVersion && bridgeVersion && bridgeVersion !== trimmed(expectedBridgeVersion))
    || (expectedPageHookVersion && pageHookVersion && pageHookVersion !== trimmed(expectedPageHookVersion))
  ) {
    return fail(
      "FLOW_PAGE_HOOK_STALE",
      `Flow page bridge versions are stale (bridge ${bridgeVersion || "missing"}, hook ${pageHookVersion || "missing"}).`,
      {
        bridgeVersion,
        pageHookVersion,
        expectedBridgeVersion: trimmed(expectedBridgeVersion),
        expectedPageHookVersion: trimmed(expectedPageHookVersion)
      },
      "Reload this Flow tab, then connect it again so the current Auto Flow page bridge can install."
    );
  }

  return fail(
    "FLOW_PAGE_BRIDGE_DEGRADED",
    trimmed(probe?.degradedReason || probe?.error || "flow_bridge_degraded"),
    {
      degradedReason: probe?.degradedReason || "",
      error: probe?.error || "flow_bridge_degraded",
      pageHookInstalled: probe?.pageHookInstalled === true
    },
    "Stay on this exact Flow tab and connect again. Auto Flow will wake and reinject the page bridge before asking you to refresh."
  );
}

function isMissingReceiver(error = "") {
  return /receiving end does not exist|could not establish connection|message port closed/i.test(String(error || ""));
}

function nextActionForCode(code = "") {
  if (code === "FLOW_TAB_AMBIGUOUS") return "Pass the exact projectId and tabId for the Flow tab in this window.";
  if (code === "FLOW_TAB_WINDOW_MISMATCH") return "Use the Flow tab in this same Chrome window, not another profile or window.";
  if (code === "AGENT_TARGET_MISMATCH") return "Reconnect the exact project and tab shown in this Auto Flow panel.";
  if (code === "FLOW_TAB_NOT_FOUND") return "Open the Google Flow project in this Chrome window, then connect again.";
  return "Stay on this Flow tab and connect again.";
}

function fail(code, message, details, nextAction = nextActionForCode(code)) {
  return {
    ok: false,
    code,
    message,
    details,
    nextAction
  };
}
