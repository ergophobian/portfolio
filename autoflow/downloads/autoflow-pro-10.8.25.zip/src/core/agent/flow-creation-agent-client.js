import { parseAgentSseTelemetry } from "./agent-tool-telemetry.js";

export const FLOW_CREATION_AGENT_ORIGIN = "https://aisandbox-pa.googleapis.com";
export const FLOW_CREATION_AGENT_RECAPTCHA_ACTION = "CHAT_GENERATION";
export const FLOW_CREATION_AGENT_SSE_LIMIT_BYTES = 2 * 1024 * 1024;

export function buildFlowCreationAgentSessionCreateBody(projectId = "") {
  return { projectId: flowProjectResourceName(projectId) };
}

export function buildFlowCreationAgentStreamBody(input = {}) {
  const projectId = normalizeFlowProjectId(input.projectId);
  const agentSessionId = compact(input.agentSessionId || input.sessionId);
  const clientSessionId = compact(input.clientSessionId);
  const recaptchaToken = compact(input.recaptchaToken);
  const turnNumber = positiveInteger(input.turnNumber);
  if (!projectId) throw agentApiError("AGENT_API_PROJECT_REQUIRED", "Flow Agent API requires an exact projectId.");
  if (!agentSessionId) throw agentApiError("AGENT_API_SESSION_REQUIRED", "Flow Agent API requires an agentSessionId.");
  if (!clientSessionId) throw agentApiError("AGENT_API_CLIENT_SESSION_REQUIRED", "Flow Agent API requires a clientSessionId.");
  if (!recaptchaToken) throw agentApiError("AGENT_API_RECAPTCHA_REQUIRED", "Flow Agent API requires a fresh recaptcha token.");
  if (!turnNumber) throw agentApiError("AGENT_API_TURN_REQUIRED", "Flow Agent API requires a positive turnNumber.");

  const prompt = compact(input.prompt);
  const mediaIds = orderedUniqueStrings(input.mediaIds || input.mediaReferences);
  const userMessage = input.userMessage && typeof input.userMessage === "object"
    ? structuredCloneSafe(input.userMessage)
    : {
        userPrompt: { parts: [{ text: prompt }] },
        ...(mediaIds.length ? { mediaReferences: mediaIds.map((mediaId) => ({ mediaId })) } : {})
      };
  if (!prompt && !input.permissionAction && !input.directActionRequest && !input.userMessage) {
    throw agentApiError("AGENT_API_PROMPT_REQUIRED", "Flow Agent API requires a prompt or an explicit continuation action.");
  }

  return {
    agentSessionId,
    agentClientContext: {
      ...(compact(input.collectionId) ? { collectionId: compact(input.collectionId) } : {}),
      projectId: `projects/${projectId}`,
      clientSessionId,
      recaptchaContext: {
        token: recaptchaToken,
        applicationType: "RECAPTCHA_APPLICATION_TYPE_WEB"
      },
      turnNumber
    },
    ...(input.directActionRequest ? { directActionRequest: structuredCloneSafe(input.directActionRequest) } : {}),
    ...(input.permissionAction ? { permissionAction: structuredCloneSafe(input.permissionAction) } : {}),
    userMessage
  };
}

export function parseFlowCreationAgentSse(input = "", options = {}) {
  const text = String(input || "");
  const limit = Math.max(1024, Number(options.limitBytes || FLOW_CREATION_AGENT_SSE_LIMIT_BYTES));
  if (utf8Bytes(text) > limit) {
    throw agentApiError("AGENT_API_SSE_TOO_LARGE", "Flow Agent SSE response exceeded the bounded parser limit.", {
      responseBytes: utf8Bytes(text),
      limitBytes: limit
    });
  }
  const events = parseSseDataValues(text);
  const fields = [];
  events.forEach((event, eventIndex) => collectFields(event, "$", fields, eventIndex));
  const values = (key) => fields.filter((field) => field.key === key).map((field) => field.value);
  const responseTexts = fields
    .filter((field) => field.key === "text" && /(?:agentMessage|response)/i.test(field.path))
    .map((field) => compact(field.value))
    .filter(Boolean);
  const finalEventIndexes = new Set(events.flatMap((event, eventIndex) => {
    const scoped = fields.filter((field) => field.eventIndex === eventIndex);
    const explicitFinal = event?.isFinalResponse === true
      || scoped.some((field) => field.key === "isFinalResponse" && field.value === true);
    const completedAgentResponse = (event?.partial === false && event?.agentMessage)
      || scoped.some((field) => field.key === "partial" && field.value === false && /agentMessage|response/i.test(field.path));
    return explicitFinal || completedAgentResponse ? [eventIndex] : [];
  }));
  const finalTexts = fields
    .filter((field) => finalEventIndexes.has(field.eventIndex))
    .filter((field) => field.key === "text" && /(?:agentMessage|response)/i.test(field.path))
    .map((field) => compact(field.value))
    .filter(Boolean);
  const creditAmounts = uniqueNumbers([
    ...values("total_cost"),
    ...values("totalCost"),
    ...values("credit_amount"),
    ...values("creditAmount")
  ]);
  const permissionActions = fields
    .filter((field) => field.key === "permissionAction")
    .map((field) => structuredCloneSafe(field.value));
  const directActionRequests = fields
    .filter((field) => field.key === "directActionRequest")
    .map((field) => structuredCloneSafe(field.value));
  const errorCodes = orderedUniqueStrings([
    ...values("errorCode"),
    ...values("error_code"),
    ...values("publicError")
  ]);
  const toolNames = orderedUniqueStrings([...values("toolName"), ...values("tool_name")]);
  const telemetry = parseAgentSseTelemetry(text);
  return {
    ok: events.length > 0,
    eventCount: events.length,
    events,
    finalObserved: finalEventIndexes.size > 0,
    responseTexts,
    finalText: finalTexts.at(-1) || responseTexts.at(-1) || "",
    permissionRequired: permissionActions.length > 0,
    permissionActions,
    directActionRequests,
    creditAmounts,
    creditAmountKnown: creditAmounts.length === 1,
    toolNames,
    errorCodes,
    telemetry
  };
}

export function resolveFlowCreationAgentCreditEstimate(input = {}) {
  const root = findFlowMetadataRoot(input.projectInitialData || input.metadata || input);
  const serviceTier = compact(root?.userData?.serviceTier || root?.userData?.tier);
  const kind = compact(input.kind || input.mediaKind || "image").toLowerCase();
  const model = normalizeModelLabel(input.modelDisplayName || input.model);
  const outputCount = positiveInteger(input.outputCount) || 1;
  const families = kind === "image"
    ? root?.modelConfig?.imageModelFamilies
    : root?.modelConfig?.videoModelFamilies;
  if (!serviceTier || !model || !Array.isArray(families)) {
    return { ok: false, known: false, code: "AGENT_API_CREDIT_MAPPING_UNAVAILABLE", serviceTier, kind, model, outputCount };
  }
  const family = families.find((entry) => {
    const labels = [entry?.displayName, entry?.id, entry?.name].map(normalizeModelLabel).filter(Boolean);
    return labels.includes(model) || labels.some((label) => label.includes(model) || model.includes(label));
  });
  if (!family) {
    return { ok: false, known: false, code: "AGENT_API_MODEL_CREDIT_MAPPING_MISSING", serviceTier, kind, model, outputCount };
  }
  const usages = Array.isArray(family.usages) ? family.usages : [];
  if (kind !== "image" && usages.length !== 1) {
    return { ok: false, known: false, code: "AGENT_API_VIDEO_CREDIT_MAPPING_AMBIGUOUS", serviceTier, kind, model, outputCount };
  }
  const costs = usages.map((usage) => usage?.creditMapping?.[serviceTier]?.cost);
  const numericCosts = costs.map(Number).filter((cost) => Number.isFinite(cost) && cost >= 0);
  if (numericCosts.length !== 1 || numericCosts.length !== costs.length) {
    return { ok: false, known: false, code: "AGENT_API_CREDIT_COST_UNKNOWN", serviceTier, kind, model, outputCount, costs };
  }
  const costPerOutput = numericCosts[0];
  return {
    ok: true,
    known: true,
    serviceTier,
    kind,
    modelDisplayName: compact(family.displayName || family.name || family.id),
    modelId: compact(family.id),
    outputCount,
    costPerOutput,
    totalCost: costPerOutput * outputCount
  };
}

export function createFlowCreationAgentClient(options = {}) {
  const fetchImpl = options.fetchImpl;
  const recaptchaProvider = options.recaptchaProvider;
  const tokenProvider = options.tokenProvider;
  const clientSessionIdProvider = options.clientSessionIdProvider || defaultClientSessionId;
  if (typeof fetchImpl !== "function") throw new Error("Flow Creation Agent client requires fetchImpl");
  if (typeof recaptchaProvider !== "function") throw new Error("Flow Creation Agent client requires recaptchaProvider");

  async function authorizedInit(init = {}) {
    const token = typeof tokenProvider === "function" ? compact(await tokenProvider()) : "";
    return {
      ...init,
      headers: {
        ...(init.headers || {}),
        ...(token ? { authorization: `Bearer ${token}` } : {})
      }
    };
  }

  async function requestJson(path, init = {}, code = "AGENT_API_REQUEST_FAILED") {
    const response = await fetchImpl(`${FLOW_CREATION_AGENT_ORIGIN}${path}`, await authorizedInit(init));
    const text = await response.text();
    if (!response.ok) {
      throw agentApiError(code, `Flow Agent API request failed with HTTP ${Number(response.status || 0)}.`, {
        status: Number(response.status || 0),
        bodyPreview: safeBodyPreview(text)
      });
    }
    try {
      return text ? JSON.parse(text) : {};
    } catch {
      throw agentApiError("AGENT_API_INVALID_JSON", "Flow Agent API returned invalid JSON.", {
        status: Number(response.status || 0),
        bodyBytes: utf8Bytes(text)
      });
    }
  }

  async function listSessions(projectId) {
    const normalizedProjectId = requiredProjectId(projectId);
    const result = await requestJson(`/v1/flowCreationAgent/sessions?projectId=${encodeURIComponent(normalizedProjectId)}`, {
      method: "GET"
    }, "AGENT_API_SESSION_LIST_FAILED");
    return Array.isArray(result.sessions) ? result.sessions : [];
  }

  async function getSession(agentSessionId) {
    const sessionId = compact(agentSessionId);
    if (!sessionId) throw agentApiError("AGENT_API_SESSION_REQUIRED", "Flow Agent API requires an agentSessionId.");
    return requestJson(`/v1/flowCreationAgent/sessions/${encodeURIComponent(sessionId)}`, {
      method: "GET"
    }, "AGENT_API_SESSION_GET_FAILED");
  }

  async function createSession(projectId) {
    const result = await requestJson("/v1/flowCreationAgent/sessions", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(buildFlowCreationAgentSessionCreateBody(projectId))
    }, "AGENT_API_SESSION_CREATE_FAILED");
    if (!compact(result?.sessionInfo?.agentSessionId)) {
      throw agentApiError("AGENT_API_SESSION_CREATE_INVALID", "Flow Agent session creation returned no agentSessionId.");
    }
    return result;
  }

  async function resolveSession(input = {}) {
    const projectId = requiredProjectId(input.projectId);
    if (compact(input.agentSessionId || input.sessionId)) {
      return getSession(compact(input.agentSessionId || input.sessionId));
    }
    if (input.startNewSession !== true) {
      const sessions = await listSessions(projectId);
      const latest = [...sessions].sort((left, right) => sessionTimestamp(right).localeCompare(sessionTimestamp(left)))[0];
      if (compact(latest?.agentSessionId)) return getSession(latest.agentSessionId);
    }
    return createSession(projectId);
  }

  async function sendMessage(input = {}) {
    const projectId = requiredProjectId(input.projectId);
    const session = await resolveSession(input);
    const agentSessionId = compact(session?.sessionInfo?.agentSessionId || input.agentSessionId || input.sessionId);
    const turns = Array.isArray(session?.turns) ? session.turns : [];
    const turnNumber = positiveInteger(input.turnNumber) || turns.length + 1;
    const recaptchaToken = await recaptchaProvider(FLOW_CREATION_AGENT_RECAPTCHA_ACTION, {
      preferDirect: true,
      forceFresh: true
    });
    const clientSessionId = compact(input.clientSessionId || await clientSessionIdProvider({ projectId, agentSessionId }));
    const body = buildFlowCreationAgentStreamBody({
      ...input,
      projectId,
      agentSessionId,
      clientSessionId,
      recaptchaToken,
      turnNumber
    });
    const response = await fetchImpl(`${FLOW_CREATION_AGENT_ORIGIN}/v1/flowCreationAgent:streamChat?alt=sse`, await authorizedInit({
      method: "POST",
      headers: {
        accept: "text/event-stream",
        "content-type": "application/json"
      },
      body: JSON.stringify(body)
    }));
    const text = await response.text();
    if (!response.ok) {
      throw agentApiError("AGENT_API_STREAM_FAILED", `Flow Agent stream failed with HTTP ${Number(response.status || 0)}.`, {
        status: Number(response.status || 0),
        bodyPreview: safeBodyPreview(text)
      });
    }
    const stream = parseFlowCreationAgentSse(text, { limitBytes: options.sseLimitBytes });
    if (!stream.ok) {
      throw agentApiError("AGENT_API_SSE_INVALID", "Flow Agent stream contained no parseable SSE data events.", {
        status: Number(response.status || 0),
        bodyBytes: utf8Bytes(text)
      });
    }
    return {
      ok: true,
      status: Number(response.status || 0),
      projectId,
      agentSessionId,
      clientSessionId,
      turnNumber,
      request: {
        mediaIds: orderedUniqueStrings(input.mediaIds || input.mediaReferences),
        hasPermissionAction: Boolean(input.permissionAction),
        hasDirectActionRequest: Boolean(input.directActionRequest)
      },
      stream
    };
  }

  return { listSessions, getSession, createSession, resolveSession, sendMessage };
}

function parseSseDataValues(text = "") {
  const events = [];
  const lines = String(text || "").split(/\r?\n/);
  let buffered = [];
  const flush = () => {
    if (!buffered.length) return;
    const value = buffered.join("\n").trim();
    buffered = [];
    if (!value || value === "[DONE]") return;
    try { events.push(JSON.parse(value)); } catch {}
  };
  for (const line of lines) {
    if (!line.trim()) {
      flush();
      continue;
    }
    if (line.startsWith("data:")) buffered.push(line.slice(5).trimStart());
  }
  flush();
  if (!events.length) {
    for (const line of lines) {
      const value = line.trim().replace(/^data:\s*/, "");
      if (!value || value === "[DONE]") continue;
      try { events.push(JSON.parse(value)); } catch {}
    }
  }
  return events;
}

function collectFields(value, path, fields, eventIndex) {
  if (Array.isArray(value)) {
    value.forEach((entry, index) => collectFields(entry, `${path}[${index}]`, fields, eventIndex));
    return;
  }
  if (!value || typeof value !== "object") return;
  for (const [key, entry] of Object.entries(value)) {
    const nextPath = `${path}.${key}`;
    fields.push({ eventIndex, key, path: nextPath, value: entry });
    collectFields(entry, nextPath, fields, eventIndex);
  }
}

function requiredProjectId(value) {
  const projectId = normalizeFlowProjectId(value);
  if (!projectId) throw agentApiError("AGENT_API_PROJECT_REQUIRED", "Flow Agent API requires an exact projectId.");
  return projectId;
}
function normalizeFlowProjectId(value = "") { return compact(value).replace(/^projects\//, ""); }
function flowProjectResourceName(value = "") { return `projects/${requiredProjectId(value)}`; }
function sessionTimestamp(session = {}) { return compact(session?.sessionContext?.lastUpdatedTime || session?.sessionContext?.creationTime); }
function findFlowMetadataRoot(value) {
  const candidates = [
    value?.result?.data?.json,
    value?.data?.json,
    value?.json,
    value
  ];
  return candidates.find((entry) => entry?.modelConfig && entry?.userData) || {};
}
function normalizeModelLabel(value = "") {
  return compact(value).toLowerCase().replace(/[^a-z0-9]+/g, "");
}
function compact(value = "") { return String(value ?? "").trim(); }
function orderedUniqueStrings(values = []) {
  const entries = Array.isArray(values) ? values : [];
  return [...new Set(entries.map((value) => compact(value?.mediaId || value)).filter(Boolean))];
}
function uniqueNumbers(values = []) {
  return [...new Set(values.map((value) => Number(value)).filter((value) => Number.isFinite(value) && value >= 0))];
}
function positiveInteger(value) { const number = Number(value); return Number.isInteger(number) && number > 0 ? number : 0; }
function utf8Bytes(value = "") { return new TextEncoder().encode(String(value || "")).byteLength; }
function structuredCloneSafe(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
function safeBodyPreview(value = "") { return compact(String(value || "").replace(/bearer\s+[^\s\"']+/gi, "Bearer <redacted>")).slice(0, 240); }
function defaultClientSessionId() { return globalThis.crypto?.randomUUID?.() || `autoflow-agent-${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function agentApiError(code, message, details = null) {
  const error = new Error(message);
  error.code = code;
  if (details) error.details = details;
  return error;
}
