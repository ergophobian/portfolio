export function isFreeCreditText(text = "") {
  return /\b(?:(?:uses?|using|will\s+use|cost(?:s|ing)?)\s+(?:0|zero|no)\s*credits?|(?:uses?|using|will\s+use|cost(?:s|ing)?)\s+(?:your\s+)?free\s+credits?|free\s*(?:tier|generation)|won['’]?t\s+use\s+credits?|will\s+not\s+use\s+credits?)\b/i.test(String(text || ""));
}

export function extractCreditAmount(text = "") {
  const source = normalizeCreditDigits(text);
  const match = source.match(/(?:cost(?:ing)?|use|uses|using|spend|requires?|will use).{0,40}?(\d+)\s*credits?\b/i);
  if (!match) return 0;
  const parsed = Number.parseInt(match[1], 10);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
}

function normalizeCreditDigits(text = "") {
  return String(text || "").replace(/(\d)[.,    ](?=\d)/g, "$1");
}
