const VIDEO_ASPECTS = Object.freeze(["16:9", "9:16"]);
const IMAGE_ASPECTS = Object.freeze(["16:9", "4:3", "1:1", "3:4", "9:16"]);
const STANDARD_VIDEO_DURATIONS = Object.freeze([4, 6, 8]);
const OMNI_VIDEO_DURATIONS = Object.freeze([4, 6, 8, 10]);

export const AGENT_VIDEO_CAPABILITIES = Object.freeze({
  omni_flash: Object.freeze({
    workflows: Object.freeze(["t2v", "r2v", "i2v_first", "v2v"]),
    durations: OMNI_VIDEO_DURATIONS,
    maxImageRefs: 7,
    maxAudioRefs: 5
  }),
  veo_fast: Object.freeze({
    workflows: Object.freeze(["t2v", "r2v", "i2v_first", "i2v_interpolation"]),
    durations: STANDARD_VIDEO_DURATIONS,
    r2vDurations: Object.freeze([8]),
    maxImageRefs: 3,
    maxAudioRefs: 1
  }),
  veo_lite: Object.freeze({
    workflows: Object.freeze(["t2v", "r2v", "i2v_first", "i2v_interpolation"]),
    durations: STANDARD_VIDEO_DURATIONS,
    r2vDurations: Object.freeze([8]),
    maxImageRefs: 3,
    maxAudioRefs: 1
  }),
  veo_quality: Object.freeze({
    workflows: Object.freeze(["t2v", "i2v_first", "i2v_interpolation"]),
    durations: STANDARD_VIDEO_DURATIONS,
    maxImageRefs: 2,
    maxAudioRefs: 0
  })
});

export function validateAgentCapabilityContract(input = {}) {
  const mode = normalizeAgentMode(input.mode || input.matrix?.mode || input.runProfile?.mode || input.settings?.mode);
  const profile = plainObject(input.runProfile || input.settings || input.matrix?.settings);
  const refs = normalizeReferences(input.references || input.refPlan?.attachments || input.matrix?.references);
  const aspectRatio = normalizeAspectRatio(profile.aspectRatio || input.aspectRatio || input.matrix?.settings?.aspectRatio);

  if (isImageMode(mode)) {
    const errors = [];
    if (aspectRatio && !IMAGE_ASPECTS.includes(aspectRatio)) {
      errors.push(capabilityError("aspectRatio", "IMAGE_ASPECT_RATIO_UNSUPPORTED", aspectRatio, IMAGE_ASPECTS));
    }
    if (refs.maxImageSlotsPerRow > 10) {
      errors.push(capabilityError("imageReferences", "IMAGE_REFERENCE_LIMIT_EXCEEDED", refs.maxImageSlotsPerRow, [10]));
    }
    return capabilityResult({ mode, workflow: refs.imageCount ? "r2i" : "t2i", aspectRatio, references: refs, errors });
  }

  const model = normalizeAgentVideoModel(profile.videoModel || profile.model || input.model || input.matrix?.settings?.model);
  const workflow = inferAgentVideoWorkflow(mode, refs);
  const durationValue = profile.videoLength || profile.duration || input.videoLength || input.duration || input.matrix?.settings?.videoLength;
  const duration = normalizeDuration(durationValue);
  const bulkAgentVideoEdit = String(input.matrix?.kind || "") === "agent_bulk_video_edit";
  const capability = AGENT_VIDEO_CAPABILITIES[model];
  const errors = [];

  if (!capability) {
    errors.push(capabilityError("model", "VIDEO_MODEL_CAPABILITY_UNKNOWN", model || "unknown", Object.keys(AGENT_VIDEO_CAPABILITIES)));
  } else {
    if (!capability.workflows.includes(workflow)) {
      errors.push(capabilityError("workflow", "VIDEO_WORKFLOW_UNSUPPORTED", workflow, capability.workflows));
    }
    const allowedDurations = workflow === "r2v" && Array.isArray(capability.r2vDurations)
      ? capability.r2vDurations
      : capability.durations;
    if ((!duration || !allowedDurations.includes(duration)) && !(bulkAgentVideoEdit && /^source$/i.test(compact(durationValue)))) {
      errors.push(capabilityError("duration", "VIDEO_DURATION_UNSUPPORTED", duration || "unknown", allowedDurations));
    }
    const workflowImageLimit = bulkAgentVideoEdit && workflow === "v2v"
      ? capability.maxImageRefs
      : workflow === "r2v"
        ? capability.maxImageRefs
        : workflow === "i2v_interpolation" ? 2 : workflow === "i2v_first" ? 1 : 0;
    if (refs.maxImageSlotsPerRow > workflowImageLimit) {
      errors.push(capabilityError("imageReferences", "VIDEO_IMAGE_REFERENCE_LIMIT_EXCEEDED", refs.maxImageSlotsPerRow, [workflowImageLimit]));
    }
    if (refs.maxAudioRefsPerRow > capability.maxAudioRefs) {
      errors.push(capabilityError("audioReferences", "VIDEO_AUDIO_REFERENCE_LIMIT_EXCEEDED", refs.maxAudioRefsPerRow, [capability.maxAudioRefs]));
    }
  }
  if (!VIDEO_ASPECTS.includes(aspectRatio)) {
    errors.push(capabilityError("aspectRatio", "VIDEO_ASPECT_RATIO_UNSUPPORTED", aspectRatio || "unknown", VIDEO_ASPECTS));
  }

  return capabilityResult({ mode, workflow, model, duration, aspectRatio, references: refs, capability, errors });
}

export function allowedAgentVideoDurations(input = {}) {
  const model = normalizeAgentVideoModel(input.model || input.videoModel);
  const capability = AGENT_VIDEO_CAPABILITIES[model];
  if (!capability) return [];
  const workflow = String(input.workflow || "t2v");
  return [...(workflow === "r2v" && Array.isArray(capability.r2vDurations) ? capability.r2vDurations : capability.durations)];
}

export function normalizeAgentVideoModel(value = "") {
  const text = compact(value).toLowerCase().replace(/[\[\]()]/g, " ").replace(/[\s-]+/g, "_");
  if (!text) return "";
  if (text.includes("omni") || text.includes("abra")) return "omni_flash";
  if (text.includes("quality")) return "veo_quality";
  if (text.includes("fast")) return "veo_fast";
  if (text.includes("lite") || text === "default" || text === "veo_3_1" || text === "veo3") return "veo_lite";
  return "";
}

export function inferAgentVideoWorkflow(mode = "", references = {}) {
  const normalizedMode = normalizeAgentMode(mode);
  const refs = references && typeof references === "object" && Number.isFinite(Number(references.totalCount))
    ? references
    : normalizeReferences(references);
  if (normalizedMode === "ingredients-to-video") return "r2v";
  if (normalizedMode === "video-to-video") return "v2v";
  if (["frame-to-video", "image-to-video", "image-chain"].includes(normalizedMode)) {
    return refs.hasEndFrame || refs.maxImageRefsPerRow >= 2 ? "i2v_interpolation" : "i2v_first";
  }
  if (refs.videoCount > 0) return "v2v";
  if (refs.imageCount > 0 || refs.audioCount > 0) return "r2v";
  return "t2v";
}

function normalizeReferences(value = []) {
  const entries = Array.isArray(value) ? value : [];
  let imageCount = 0;
  let imageSlotCount = 0;
  let avatarCount = 0;
  let audioCount = 0;
  let videoCount = 0;
  let hasEndFrame = false;
  const shared = { imageRefs: 0, imageSlots: 0, audioRefs: 0, videoRefs: 0 };
  const rowCounts = new Map();
  for (const entry of entries) {
    const role = compact(entry?.role || entry?.kind || entry?.type).toLowerCase();
    const handle = compact(entry?.handle || entry?.referenceHandle || "").toLowerCase();
    const file = compact(entry?.fileName || entry?.name || entry?.path).toLowerCase();
    const rowId = compact(entry?.rowId || entry?.row || entry?.sourceRowId);
    const counts = rowId
      ? (rowCounts.get(rowId) || { imageRefs: 0, imageSlots: 0, audioRefs: 0, videoRefs: 0 })
      : shared;
    if (/audio|voice|sound/.test(role) || /\.(?:mp3|wav|m4a|aac|flac|ogg)$/.test(file)) {
      audioCount += 1;
      counts.audioRefs += 1;
    } else if (/video/.test(role) || /\.(?:mp4|mov|webm|mkv)$/.test(file)) {
      videoCount += 1;
      counts.videoRefs += 1;
    } else {
      const avatar = /avatar/.test(role) || handle === "@me" || handle === "me";
      const slots = avatar ? 3 : 1;
      imageCount += 1;
      imageSlotCount += slots;
      counts.imageRefs += 1;
      counts.imageSlots += slots;
      if (avatar) avatarCount += 1;
    }
    if (rowId) rowCounts.set(rowId, counts);
    if (/end|last/.test(role)) hasEndFrame = true;
  }
  const perRow = rowCounts.size ? [...rowCounts.values()] : [{ imageRefs: 0, imageSlots: 0, audioRefs: 0, videoRefs: 0 }];
  const maxPerRow = (key) => shared[key] + Math.max(0, ...perRow.map((counts) => counts[key]));
  return {
    totalCount: entries.length,
    imageCount,
    imageSlotCount,
    avatarCount,
    audioCount,
    videoCount,
    maxImageRefsPerRow: maxPerRow("imageRefs"),
    maxImageSlotsPerRow: maxPerRow("imageSlots"),
    maxAudioRefsPerRow: maxPerRow("audioRefs"),
    maxVideoRefsPerRow: maxPerRow("videoRefs"),
    hasEndFrame
  };
}

function capabilityResult(details = {}) {
  const errors = Array.isArray(details.errors) ? details.errors : [];
  return {
    ok: errors.length === 0,
    code: errors.length ? "AGENT_CAPABILITY_CONTRACT_INVALID" : "",
    message: errors.length
      ? `Agent run contains an unsupported ${errors[0].field} combination (${errors[0].reason}).`
      : "",
    ...details,
    errors
  };
}

function capabilityError(field, reason, requested, allowed) {
  return { field, reason, requested, allowed: Array.isArray(allowed) ? [...allowed] : [] };
}

function normalizeAgentMode(value = "") {
  const text = compact(value).toLowerCase().replace(/[\s_]+/g, "-");
  if (["create-image", "text-to-image", "image", "t2i"].includes(text)) return "text-to-image";
  if (["ingredients", "ingredients-to-video", "r2v", "reference-to-video"].includes(text)) return "ingredients-to-video";
  if (["frame-to-video", "frames-to-video", "f2v"].includes(text)) return "frame-to-video";
  if (["image-to-video", "i2v"].includes(text)) return "image-to-video";
  if (["video-to-video", "v2v"].includes(text)) return "video-to-video";
  if (text === "image-chain") return "image-chain";
  return "text-to-video";
}

function normalizeDuration(value) {
  const match = compact(value).match(/\d+(?:\.\d+)?/);
  const parsed = match ? Number(match[0]) : 0;
  return Number.isFinite(parsed) ? parsed : 0;
}

function normalizeAspectRatio(value = "") {
  const text = compact(value).toLowerCase();
  if (["landscape", "landscape-16-9", "landscape_16_9"].includes(text)) return "16:9";
  if (["portrait", "portrait-9-16", "portrait_9_16"].includes(text)) return "9:16";
  return text;
}

function isImageMode(mode = "") {
  return normalizeAgentMode(mode) === "text-to-image";
}

function compact(value = "") {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function plainObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
