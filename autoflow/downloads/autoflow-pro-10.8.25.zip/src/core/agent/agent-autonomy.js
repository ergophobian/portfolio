import { isCaptainAuthorized, isConfirmCreditsAuthorized } from "./agent-credit-policy.js";

export const AGENT_AUTONOMY_LEVELS = Object.freeze(["none", "credit-only", "full-self-heal"]);
export const DEFAULT_AGENT_AUTONOMY = "full-self-heal";
export const DEFAULT_SELF_HEAL_RETRIES = 2;

const DEFAULT_HANDLES = Object.freeze([
  "content-blocked rows",
  "policy-blocked rows",
  "third-party/prominent-person prompt blocks",
  "missing outputs",
  "unbilled failed-generation cards",
  "wrong scene or bad render",
  "multi-panel outputs",
  "unwanted on-screen text or subtitles"
]);

export function normalizeAgentAutonomy(value = DEFAULT_AGENT_AUTONOMY) {
  const text = String(value || "").trim().toLowerCase().replace(/_/g, "-");
  if (!text) return DEFAULT_AGENT_AUTONOMY;
  if (["none", "off", "false", "0", "manual"].includes(text)) return "none";
  if (["credit", "credits", "credit-only", "credits-only"].includes(text)) return "credit-only";
  if (["full", "full-self-heal", "self-heal", "selfheal", "autonomous", "hands-off"].includes(text)) return "full-self-heal";
  return AGENT_AUTONOMY_LEVELS.includes(text) ? text : DEFAULT_AGENT_AUTONOMY;
}

export function buildAgentSelfHealPolicy(options = {}) {
  const autonomy = normalizeAgentAutonomy(options.autonomy);
  const maxRetries = clampInt(
    options.maxSelfHealRetries ?? options.selfHealRetries ?? options.maxRetries,
    0,
    5,
    DEFAULT_SELF_HEAL_RETRIES
  );
  return {
    enabled: autonomy === "full-self-heal",
    autonomy,
    maxRetries,
    suppressOnScreenText: normalizeOptionalBoolean(options.suppressOnScreenText ?? options.noOnScreenText, true),
    reportFixes: normalizeOptionalBoolean(options.reportFixes, true),
    escalateHardBlocks: true,
    handles: autonomy === "full-self-heal" ? [...DEFAULT_HANDLES] : []
  };
}

export function buildAgentAutoApprovePolicy(options = {}) {
  const autonomy = normalizeAgentAutonomy(options.autonomy);
  const requested = normalizeApprovalTokens(options.autoApprove ?? options.autoApprovals ?? options.approvals);
  const includesAll = requested.has("all");
  const creditApproved = isConfirmCreditsAuthorized(options);
  const creditsRequested = includesAll || requested.has("credits") || requested.has("credit");
  return {
    credits: (creditsRequested && isCaptainAuthorized(options)) || creditApproved,
    rephrases: autonomy === "full-self-heal" && (includesAll || requested.size === 0 || requested.has("rephrases") || requested.has("safe-rephrases")),
    missingOutputs: autonomy === "full-self-heal" && (includesAll || requested.size === 0 || requested.has("missing") || requested.has("missing-outputs") || requested.has("missing_outputs")),
    hardBlocks: false,
    raw: [...requested]
  };
}

export function agentSelfHealPromptLines(options = {}) {
  const autonomy = normalizeAgentAutonomy(options.autonomy);
  const policy = buildAgentSelfHealPolicy({ ...options, autonomy });
  const maxRetries = policy.maxRetries;
  if (autonomy === "none") {
    return [
      "- Self-heal autonomy: none.",
      "- If a row is content-blocked, policy-blocked, missing, or failed, report the affected row and stop that row instead of rewriting it."
    ];
  }
  if (autonomy === "credit-only") {
    return [
      "- Self-heal autonomy: credit-only.",
      "- Continue normal generation and credit confirmations only when pre-approved; report content, policy, missing-output, or failed-generation blockers without rewriting prompts."
    ];
  }
  return [
    "- Self-heal autonomy: full-self-heal.",
    `- You are the first-line repair agent. If a row is content-blocked, policy-blocked, missing, or failed, rewrite only that affected row at the same creative level and retry up to ${maxRetries} times.`,
    "- Preserve the user's intent, row ids, references, identity, dialogue meaning, model, aspect ratio, duration, and output count while making the smallest safe repair.",
    "- Do not ask before safe at-level rephrases, missing-output retries, or unbilled failed-generation retries; immediately generate the repaired row.",
    "- Report every repair as FIXED [ROW_ID]: reason -> exact change made.",
    "- Escalate only after retries are exhausted or the row is a hard safety block involving minors, explicit sexual content, illegal instructions, billing-plan changes, account changes, or project changes.",
    "- Suppress on-screen text, subtitles, captions, labels, watermarks, and AFID text unless explicitly requested."
  ];
}

export function agentSelfHealContext() {
  return {
    defaultAutonomy: DEFAULT_AGENT_AUTONOMY,
    levels: [...AGENT_AUTONOMY_LEVELS],
    operatorInstruction: "Do not pre-fix prompts when autonomy is full-self-heal. Submit the user's intent, let Flow Agent be the first-line repair agent, approve safe at-level rephrases through the wait/context loop, and collect structured fixes.",
    eventModel: [
      "started",
      "blocked",
      "fixed",
      "needs_approval",
      "rendered",
      "failed"
    ],
    hardEscalations: [
      "minors",
      "explicit sexual content",
      "illegal instructions",
      "billing-plan changes",
      "account changes",
      "project changes",
      "retries exhausted"
    ]
  };
}

function normalizeApprovalTokens(value) {
  const values = Array.isArray(value) ? value : String(value || "").split(",");
  return new Set(values
    .map((entry) => String(entry || "").trim().toLowerCase().replace(/_/g, "-"))
    .filter(Boolean));
}

function normalizeOptionalBoolean(value, fallback = null) {
  if (value === undefined || value === null || value === "") return fallback;
  if (value === true || value === false) return value;
  const text = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "on", "enabled"].includes(text)) return true;
  if (["0", "false", "no", "off", "disabled"].includes(text)) return false;
  return fallback;
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.max(min, Math.min(max, parsed));
}
