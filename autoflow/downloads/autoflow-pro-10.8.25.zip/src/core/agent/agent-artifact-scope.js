export function extractAgentArtifactRows(input = {}) {
  if (!input || typeof input !== "object") return [];
  if (Array.isArray(input)) return input;
  if (Array.isArray(input.rows)) return input.rows;
  if (Array.isArray(input.reconciledRows)) return input.reconciledRows;
  if (Array.isArray(input.result?.rows)) return input.result.rows;
  if (Array.isArray(input.plan?.manifest?.rows)) return input.plan.manifest.rows;
  return [];
}

export function scopeAgentArtifactInput(input = {}, scope = {}) {
  if (!input || typeof input !== "object") input = {};
  const rowIds = normalizeRowSet(scope.rowIds || scope.rows);
  const mediaIds = normalizeMediaSet(scope.mediaIds);
  const rows = extractAgentArtifactRows(input);
  const scopedRows = rows
    .map((row, index) => scopeArtifactRow(row, { rowIds, mediaIds, index }))
    .filter(Boolean);
  return {
    ...input,
    rows: scopedRows,
    result: input?.result && typeof input.result === "object" && !Array.isArray(input.result)
      ? { ...input.result, rows: scopedRows }
      : input?.result
  };
}

export function scopeAgentArtifactPlan(plan = {}, scope = {}) {
  const rowIds = normalizeRowSet(scope.rowIds || scope.rows);
  const mediaIds = normalizeMediaSet(scope.mediaIds);
  if (!rowIds.size && !mediaIds.size) return plan;
  const downloads = scopedDownloads(plan.downloads || plan.mediaDownloads || [], { rowIds, mediaIds });
  const mediaIdAllow = new Set(downloads.map((download) => compactString(download.mediaId)).filter(Boolean));
  const scopedManifestRows = plan.manifest && typeof plan.manifest === "object"
    ? scopeManifestRows(plan.manifest.rows || [], { rowIds, mediaIds: mediaIdAllow.size ? mediaIdAllow : mediaIds })
    : [];
  const manifest = plan.manifest && typeof plan.manifest === "object"
    ? {
        ...plan.manifest,
        rows: scopedManifestRows,
        summary: {
          ...(plan.manifest.summary || {}),
          rows: scopedManifestRows.length,
          images: downloads.filter((download) => String(download.kind || "") === "image").length,
          videos: downloads.filter((download) => String(download.kind || "") === "video").length,
          downloads: downloads.length
        }
      }
    : plan.manifest;
  return {
    ...plan,
    downloads,
    mediaDownloads: downloads,
    manifest
  };
}

export function mediaIdsFromAgentArtifactPlan(plan = {}) {
  return uniqueStrings((plan.downloads || plan.mediaDownloads || []).map((download) => download?.mediaId));
}

export function rowIdsFromAgentArtifactRows(rows = []) {
  return uniqueStrings((rows || []).map(rowIdForArtifactRow)).map(normalizeRowId).filter(Boolean);
}

function scopeArtifactRow(row = {}, scope = {}) {
  const rowId = normalizeRowId(rowIdForArtifactRow(row, scope.index));
  if (scope.rowIds.size && !scope.rowIds.has(rowId)) return null;
  if (!scope.mediaIds.size) return row;

  const scoped = { ...row };
  let matched = false;
  for (const field of ["images", "imageSlots", "imageVersions"]) {
    if (!Array.isArray(row[field])) continue;
    scoped[field] = row[field].filter((item) => mediaItemMatches(item, scope.mediaIds));
    matched ||= scoped[field].length > 0;
  }
  for (const field of ["videoVersions", "videos"]) {
    if (!Array.isArray(row[field])) continue;
    scoped[field] = row[field].filter((item) => mediaItemMatches(item, scope.mediaIds));
    matched ||= scoped[field].length > 0;
  }
  for (const field of ["video", "latestVideo"]) {
    if (!row[field] || typeof row[field] !== "object") continue;
    if (mediaItemMatches(row[field], scope.mediaIds)) {
      scoped[field] = row[field];
      matched = true;
    } else {
      delete scoped[field];
    }
  }
  return matched ? scoped : null;
}

function scopeManifestRows(rows = [], scope = {}) {
  return (rows || [])
    .map((row) => {
      const rowId = normalizeRowId(rowIdForArtifactRow(row));
      if (scope.rowIds.size && !scope.rowIds.has(rowId)) return null;
      const images = Array.isArray(row.images)
        ? row.images.filter((item) => !scope.mediaIds.size || mediaItemMatches(item, scope.mediaIds))
        : [];
      const videos = Array.isArray(row.videos)
        ? row.videos.filter((item) => !scope.mediaIds.size || mediaItemMatches(item, scope.mediaIds))
        : [];
      if (scope.mediaIds.size && !images.length && !videos.length) return null;
      return { ...row, images, videos };
    })
    .filter(Boolean);
}

function scopedDownloads(downloads = [], scope = {}) {
  return (downloads || []).filter((download) => {
    const rowId = normalizeRowId(download?.rowId);
    const mediaId = compactString(download?.mediaId);
    if (scope.rowIds.size && !scope.rowIds.has(rowId)) return false;
    if (scope.mediaIds.size && !scope.mediaIds.has(mediaId)) return false;
    return true;
  });
}

function mediaItemMatches(item = {}, mediaIds = new Set()) {
  if (!mediaIds.size) return true;
  return mediaIdentityValues(item).some((id) => mediaIds.has(id));
}

function mediaIdentityValues(item = {}) {
  return uniqueStrings([
    item?.mediaId,
    item?.id,
    item?.name,
    item?.mediaName
  ]);
}

function rowIdForArtifactRow(row = {}, index = 0) {
  return compactString(
    row.rowId
    || row.tag
    || row.videoTag
    || row.finalVideoId
    || row.id
    || row.sceneId
    || row.displayTag
    || (Number.isFinite(Number(index)) ? `ROW-${index + 1}` : "")
  );
}

function normalizeRowSet(values = []) {
  return new Set(normalizeStringList(values).map(normalizeRowId).filter(Boolean));
}

function normalizeMediaSet(values = []) {
  return new Set(normalizeStringList(values).map(compactString).filter(Boolean));
}

function normalizeStringList(value = []) {
  if (value === undefined || value === null || value === false) return [];
  const list = Array.isArray(value) ? value : String(value).split(",");
  return list.map((entry) => compactString(entry)).filter(Boolean);
}

function normalizeRowId(value = "") {
  return compactString(value).replace(/^\[/, "").replace(/\]$/, "").toUpperCase();
}

function uniqueStrings(values = []) {
  return [...new Set((values || []).map(compactString).filter(Boolean))];
}

function compactString(value = "") {
  return String(value || "").trim();
}
