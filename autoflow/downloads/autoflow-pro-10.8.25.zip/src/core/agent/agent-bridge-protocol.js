export const AGENT_BRIDGE_PROTOCOL = "auto-flow.agent.bridge";
export const AGENT_BRIDGE_VERSION = 1;

export const AGENT_BRIDGE_COMMAND_TYPES = Object.freeze([
  "pair.start",
  "pair.confirm",
  "pair.reset",
  "bridge.targets.list",
  "bridge.target.use",
  "bridge.ws.refresh",
  "lane.use",
  "lane.list",
  "lane.unbind",
  "lane.indicator.set",
  "status.get",
  "flow.tabs.list",
  "agent.tab.connect",
  "agent.context.get",
  "agent.screenshot.get",
  "project.metadata.get",
  "project.media.list",
  "flow.generate",
  "flow.state.get",
  "agent.prompt.submit",
  "agent.retry.submit",
  "agent.refs.importUrl",
  "agent.refs.attach",
  "agent.composer.submit",
  "agent.credits.confirm",
  "fleetgen.setPrompts",
  "fleetgen.updateSettings",
  "fleetgen.launch",
  "fleetgen.executeDirect",
  "fleetgen.getCapabilities",
  "fleetgen.normalizeInputs",
  "fleetgen.getState",
  "fleetgen.getStatus",
  "fleetgen.getResult",
  "fleetgen.getOutbox",
  "fleet.state.get",
  "fleet.generate",
  "downloads.plan",
  "downloads.execute"
]);

const AGENT_BRIDGE_COMMAND_SET = new Set(AGENT_BRIDGE_COMMAND_TYPES);
const OPTIONAL_TARGET_FIELD_COMMANDS = new Set([
  "bridge.targets.list",
  "bridge.target.use",
  "bridge.ws.refresh",
  "lane.use",
  "lane.list",
  "lane.unbind",
  "lane.indicator.set",
  "status.get",
  "flow.tabs.list",
  "agent.tab.connect",
  "agent.context.get",
  "agent.screenshot.get",
  "project.media.list",
  "flow.generate",
  "flow.state.get",
  "agent.prompt.submit",
  "agent.retry.submit",
  "agent.refs.attach",
  "agent.composer.submit",
  "agent.credits.confirm",
  "fleetgen.setPrompts",
  "fleetgen.updateSettings",
  "fleetgen.getCapabilities",
  "fleetgen.normalizeInputs",
  "fleetgen.getState",
  "fleetgen.getStatus",
  "fleetgen.getResult",
  "fleetgen.getOutbox",
  "fleet.state.get",
  "fleet.generate"
]);
const LIVE_SUBMIT_TARGET_COMMANDS = new Set([
  "flow.generate",
  "agent.prompt.submit",
  "agent.retry.submit",
  "agent.refs.attach",
  "agent.composer.submit",
  "agent.credits.confirm",
  "fleetgen.launch",
  "fleetgen.executeDirect",
  "fleet.generate"
]);

export function createAgentBridgeRequest(input = {}) {
  const request = {
    protocol: AGENT_BRIDGE_PROTOCOL,
    version: AGENT_BRIDGE_VERSION,
    id: stringValue(input.id),
    type: stringValue(input.type),
    payload: normalizePlainObject(input.payload)
  };
  if (input.auth !== undefined) request.auth = normalizePlainObject(input.auth);
  if (input.session !== undefined) request.session = normalizePlainObject(input.session);

  const validation = validateAgentBridgeRequest(request);
  if (!validation.ok) {
    throw new TypeError(validation.error.message);
  }
  return validation.request;
}

export function validateAgentBridgeRequest(input = {}) {
  if (!isPlainObject(input)) {
    return invalid("INVALID_REQUEST", "bridge request must be an object");
  }

  const id = stringValue(input.id);
  if (!id) {
    return invalid("INVALID_REQUEST_ID", "request id must be a non-empty string");
  }
  if (id.length > 128) {
    return invalid("INVALID_REQUEST_ID", "request id must be 128 characters or fewer");
  }

  const type = stringValue(input.type);
  if (!type) {
    return invalid("INVALID_COMMAND", "request type must be a non-empty string");
  }
  if (!AGENT_BRIDGE_COMMAND_SET.has(type)) {
    return invalid("UNKNOWN_COMMAND", `unsupported bridge command: ${type}`);
  }

  if (input.payload !== undefined && !isPlainObject(input.payload)) {
    return invalid("INVALID_PAYLOAD", "request payload must be an object");
  }
  if (input.auth !== undefined && !isPlainObject(input.auth)) {
    return invalid("INVALID_AUTH_CONTEXT", "request auth must be an object");
  }
  if (input.session !== undefined && !isPlainObject(input.session)) {
    return invalid("INVALID_SESSION_CONTEXT", "request session must be an object");
  }

  const payload = normalizePlainObject(input.payload);
  const payloadResult = validateCommandPayload(type, payload);
  if (!payloadResult.ok) return payloadResult;

  const request = {
    protocol: stringValue(input.protocol) || AGENT_BRIDGE_PROTOCOL,
    version: normalizeVersion(input.version),
    id,
    type,
    payload
  };
  if (input.auth !== undefined) request.auth = normalizePlainObject(input.auth);
  if (input.session !== undefined) request.session = normalizePlainObject(input.session);
  return { ok: true, request };
}

export function createAgentBridgeSuccessResponse(request = {}, payload = {}) {
  const identity = responseIdentity(request);
  return {
    protocol: AGENT_BRIDGE_PROTOCOL,
    version: AGENT_BRIDGE_VERSION,
    id: identity.id,
    type: identity.type,
    ok: true,
    payload: normalizePlainObject(payload)
  };
}

export function createAgentBridgeErrorResponse(request = {}, error = {}) {
  const identity = responseIdentity(request);
  return {
    protocol: AGENT_BRIDGE_PROTOCOL,
    version: AGENT_BRIDGE_VERSION,
    id: identity.id,
    type: identity.type,
    ok: false,
    error: normalizeBridgeError(error)
  };
}

export function validateAgentBridgeResponse(input = {}) {
  if (!isPlainObject(input)) {
    return invalid("INVALID_RESPONSE", "bridge response must be an object");
  }

  const id = stringValue(input.id);
  if (!id) {
    return invalid("INVALID_RESPONSE_ID", "response id must be a non-empty string");
  }

  const type = stringValue(input.type);
  if (!AGENT_BRIDGE_COMMAND_SET.has(type)) {
    return invalid("UNKNOWN_COMMAND", `unsupported bridge command: ${type}`);
  }

  if (input.protocol !== AGENT_BRIDGE_PROTOCOL) {
    return invalid("INVALID_PROTOCOL", `response protocol must be ${AGENT_BRIDGE_PROTOCOL}`);
  }
  if (Number(input.version) !== AGENT_BRIDGE_VERSION) {
    return invalid("INVALID_PROTOCOL_VERSION", `response version must be ${AGENT_BRIDGE_VERSION}`);
  }
  if (typeof input.ok !== "boolean") {
    return invalid("INVALID_RESPONSE", "response ok must be boolean");
  }
  if (input.ok && input.payload !== undefined && !isPlainObject(input.payload)) {
    return invalid("INVALID_RESPONSE_PAYLOAD", "response payload must be an object");
  }
  if (!input.ok) {
    const error = normalizeBridgeError(input.error);
    if (!error.code || !error.message) {
      return invalid("INVALID_RESPONSE_ERROR", "error response requires error.code and error.message");
    }
  }
  return { ok: true, response: input };
}

export function normalizeBridgeError(error = {}) {
  if (typeof error === "string") {
    return { code: "BRIDGE_ERROR", message: error };
  }
  const code = stringValue(error.code || "BRIDGE_ERROR") || "BRIDGE_ERROR";
  const message = stringValue(error.message || error.error || code) || code;
  const normalized = { code, message };
  if (error.details !== undefined) normalized.details = error.details;
  return normalized;
}

function validateCommandPayload(type, payload) {
  if (type === "pair.confirm" && !nonEmptyString(payload.pairingCode)) {
    return invalid("INVALID_PAYLOAD", "pair.confirm requires payload.pairingCode");
  }
  if (type === "bridge.ws.refresh" && !nonEmptyString(payload.wsUrl)) {
    return invalid("INVALID_PAYLOAD", "bridge.ws.refresh requires payload.wsUrl");
  }
  if (type === "bridge.target.use") {
    const missing = [];
    if (!nonEmptyString(payload.projectId)) missing.push("projectId");
    if (!nonEmptyString(payload.tabId)) missing.push("tabId");
    if (!nonEmptyString(payload.laneId)) missing.push("laneId");
    if (missing.length) {
      return invalid("INVALID_PAYLOAD", `bridge.target.use requires ${missing.join(" and ")}`);
    }
  }
  if (type === "lane.use" && !laneName(payload)) {
    return invalid("INVALID_PAYLOAD", "lane.use requires payload.laneId or payload.name");
  }
  if (type === "lane.unbind" && !laneName(payload)) {
    return invalid("INVALID_PAYLOAD", "lane.unbind requires payload.laneId or payload.name");
  }
  if (type === "lane.indicator.set") {
    const missing = [];
    if (!laneName(payload)) missing.push("laneId");
    if (!nonEmptyString(payload.tabId)) missing.push("tabId");
    if (missing.length) {
      return invalid("INVALID_PAYLOAD", `lane.indicator.set requires ${missing.join(" and ")}`);
    }
  }
  if (type === "flow.generate") {
    const hasPrompts = Array.isArray(payload.prompts)
      && payload.prompts.some((prompt) => nonEmptyString(typeof prompt === "string" ? prompt : prompt?.prompt));
    if (!hasPrompts && !nonEmptyString(payload.prompt)) {
      return invalid("INVALID_PAYLOAD", "flow.generate requires payload.prompt or payload.prompts");
    }
    if (payload.dryRun !== true && !nonEmptyString(payload.idempotencyKey)) {
      return invalid("INVALID_PAYLOAD", "flow.generate requires payload.idempotencyKey for live generation");
    }
  }
  if (type === "flow.state.get" && !nonEmptyString(payload.idempotencyKey) && !nonEmptyString(payload.jobId)) {
    return invalid("INVALID_PAYLOAD", "flow.state.get requires payload.idempotencyKey or payload.jobId");
  }
  if (type === "agent.prompt.submit" && !nonEmptyString(payload.prompt)) {
    return invalid("INVALID_PAYLOAD", "agent.prompt.submit requires payload.prompt");
  }
  if (type === "agent.retry.submit" && !nonEmptyString(payload.taskId) && !nonEmptyString(payload.runId)) {
    return invalid("INVALID_PAYLOAD", "agent.retry.submit requires payload.taskId or payload.runId");
  }
  if (type === "agent.refs.importUrl") {
    if (!nonEmptyString(payload.sourceUrl)) {
      return invalid("INVALID_PAYLOAD", "agent.refs.importUrl requires payload.sourceUrl");
    }
    if (!nonEmptyString(payload.fileName)) {
      return invalid("INVALID_PAYLOAD", "agent.refs.importUrl requires payload.fileName");
    }
  }
  if (type === "agent.refs.attach" && !hasAgentRefAttachmentInput(payload)) {
    return invalid("INVALID_PAYLOAD", "agent.refs.attach requires payload.refs, payload.references, or payload.attachments");
  }
  if (type === "agent.composer.submit") {
    const missing = [];
    if (!nonEmptyString(payload.runId)) missing.push("runId");
    if (!nonEmptyString(payload.expectedDraftHash)) missing.push("expectedDraftHash");
    if (!nonEmptyString(payload.idempotencyKey)) missing.push("idempotencyKey");
    if (missing.length) {
      return invalid("INVALID_PAYLOAD", `agent.composer.submit requires ${missing.join(", ")}`);
    }
  }
  if (type === "fleetgen.setPrompts") {
    if (!Array.isArray(payload.prompts)) return invalid("INVALID_PAYLOAD", "fleetgen.setPrompts requires payload.prompts");
  }
  if (type === "fleetgen.updateSettings") {
    if (!isPlainObject(payload.settings)) return invalid("INVALID_PAYLOAD", "fleetgen.updateSettings requires payload.settings");
  }
  if (type === "fleetgen.executeDirect" && !nonEmptyString(payload.prompt)) {
    return invalid("INVALID_PAYLOAD", "fleetgen.executeDirect requires payload.prompt");
  }
  if (type === "fleet.generate") {
    const missing = [];
    if (payload.dryRun !== true && !nonEmptyString(payload.idempotencyKey)) missing.push("idempotencyKey");
    const hasPromptText = nonEmptyString(payload.promptsText) || nonEmptyString(payload.promptText) || nonEmptyString(payload.prompt);
    const promptStringPresent = (value) => typeof value === "string" && value.trim().length > 0;
    const hasPrompts = Array.isArray(payload.prompts) && payload.prompts.some((prompt) =>
      promptStringPresent(prompt)
      || (isPlainObject(prompt) && (promptStringPresent(prompt.prompt) || promptStringPresent(prompt.text))));
    if (missing.length) {
      return invalid("INVALID_PAYLOAD", `fleet.generate requires ${missing.join(", ")}`);
    }
    if (!hasPromptText && !hasPrompts) {
      return invalid("INVALID_PAYLOAD", "fleet.generate requires payload.promptsText, payload.promptText, payload.prompt, or payload.prompts");
    }
  }
  if (OPTIONAL_TARGET_FIELD_COMMANDS.has(type)) {
    const targetError = validateOptionalTargetFields(payload);
    if (targetError) return targetError;
  }
  if (LIVE_SUBMIT_TARGET_COMMANDS.has(type)) {
    const liveTargetError = validateRequiredLiveSubmitTargetFields(type, payload);
    if (liveTargetError) return liveTargetError;
  }
  if (type === "downloads.plan") {
    const hasMediaIds = Array.isArray(payload.mediaIds)
      && payload.mediaIds.some((mediaId) => nonEmptyString(mediaId));
    if (!hasMediaIds && !nonEmptyString(payload.taskId)) {
      return invalid("INVALID_PAYLOAD", "downloads.plan requires payload.mediaIds or payload.taskId");
    }
  }
  if (type === "downloads.execute") {
    const hasPlan = isPlainObject(payload.plan);
    const hasMediaIds = Array.isArray(payload.mediaIds)
      && payload.mediaIds.some((mediaId) => nonEmptyString(mediaId));
    if (!hasPlan && !hasMediaIds && !nonEmptyString(payload.taskId)) {
      return invalid("INVALID_PAYLOAD", "downloads.execute requires payload.plan, payload.mediaIds, or payload.taskId");
    }
    const targetError = validateOptionalTargetFields(payload);
    if (targetError) return targetError;
    const downloadTargetError = validateRequiredDownloadTargetFields(payload);
    if (downloadTargetError) return downloadTargetError;
  }
  return { ok: true };
}

// Optional explicit targeting fields. They are not required (existing callers and
// dry-runs omit them), but when present they must be non-empty strings so the
// service worker can fail closed on a real target mismatch (P0-1).
function validateOptionalTargetFields(payload) {
  for (const field of ["projectId", "tabId", "laneId"]) {
    if (payload[field] !== undefined && !nonEmptyString(payload[field])) {
      return invalid("INVALID_PAYLOAD", `${field} must be a non-empty string when provided`);
    }
  }
  return null;
}

function hasAgentRefAttachmentInput(payload = {}) {
  for (const field of ["refs", "references", "attachments"]) {
    if (Array.isArray(payload[field]) && payload[field].length > 0) return true;
  }
  return false;
}

function validateRequiredLiveSubmitTargetFields(type, payload) {
  if (payload.dryRun === true) return null;
  const transport = stringValue(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  const chromeSessionApi = type === "agent.prompt.submit"
    && (transport === "api" || transport === "agent_api")
    && payload.chromeSessionAuth === true;
  const missing = [];
  if (!nonEmptyString(payload.projectId)) missing.push("projectId");
  if (!chromeSessionApi && !nonEmptyString(payload.tabId)) missing.push("tabId");
  if (!missing.length) return null;
  return invalid("INVALID_PAYLOAD", `${type} live submit requires ${missing.join(" and ")}`);
}

function validateRequiredDownloadTargetFields(payload) {
  const transport = stringValue(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  const chromeSessionApi = (transport === "api" || transport === "agent_api")
    && payload.chromeSessionAuth === true;
  const missing = [];
  if (!nonEmptyString(payload.projectId)) missing.push("projectId");
  if (!chromeSessionApi && !nonEmptyString(payload.tabId)) missing.push("tabId");
  if (!missing.length) return null;
  return invalid("INVALID_PAYLOAD", `downloads.execute requires ${missing.join(" and ")}`);
}

function responseIdentity(request = {}) {
  return {
    id: stringValue(request.id),
    type: stringValue(request.type)
  };
}

function normalizeVersion(version) {
  const numeric = Number(version);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : AGENT_BRIDGE_VERSION;
}

function normalizePlainObject(value) {
  return isPlainObject(value) ? { ...value } : {};
}

function invalid(code, message, details) {
  const error = { code, message };
  if (details !== undefined) error.details = details;
  return { ok: false, error };
}

function nonEmptyString(value) {
  return stringValue(value).length > 0;
}

function laneName(payload = {}) {
  return stringValue(payload.laneId || payload.name);
}

function stringValue(value) {
  return String(value ?? "").trim();
}

function isPlainObject(value) {
  return Boolean(value)
    && typeof value === "object"
    && !Array.isArray(value);
}
