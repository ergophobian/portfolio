const CONFIRMATION_AUTO_APPROVE = "AUTO_APPROVE";

export function buildAgentNativeSettingsPlan(input = {}) {
  const matrix = plainObject(input.matrix);
  const runProfile = plainObject(input.runProfile || input.settings);
  const mode = compact(input.mode || matrix.mode || runProfile.mode).toLowerCase();
  const expectedImages = nonNegativeNumber(input.expectedImages ?? matrix.expectedImages ?? matrix.expectedImageCount);
  const expectedVideos = nonNegativeNumber(input.expectedVideos ?? matrix.expectedVideos ?? matrix.expectedVideoCount);
  const imageActive = expectedImages > 0 || mode === "text-to-image";
  const videoActive = expectedVideos > 0 || mode.includes("video");
  const requestedAspect = compact(runProfile.aspectRatio || matrix.settings?.aspectRatio || input.aspectRatio).toLowerCase();
  const imageOutputs = boundedOutputs(runProfile.imageOutputs ?? matrix.repeatCount ?? input.imageOutputs);
  const videoOutputs = boundedOutputs(runProfile.videoOutputs ?? matrix.repeatCount ?? input.videoOutputs);
  const desired = {
    // Keep Agent execution direct and deterministic: every managed run uses
    // Flow's "Never" confirmation setting (AUTO_APPROVE) instead of creating
    // variable confirmation branches.
    confirmation: CONFIRMATION_AUTO_APPROVE,
    image: imageActive ? {
      aspectRatio: normalizeImageAspect(requestedAspect),
      outputs: imageOutputs,
      model: normalizeImageModel(runProfile.imageModel || (mode === "text-to-image" ? runProfile.model : "") || matrix.settings?.model)
    } : null,
    video: videoActive ? {
      aspectRatio: normalizeVideoAspect(requestedAspect),
      outputs: videoOutputs,
      model: normalizeVideoModel(runProfile.videoModel || runProfile.model || matrix.settings?.model)
    } : null
  };
  return {
    ok: true,
    desired,
    instructionOnly: {
      videoDuration: videoActive ? compact(runProfile.videoLength || matrix.settings?.videoLength || input.videoLength) : "",
      returnSilentVideos: videoActive && typeof runProfile.returnSilentVideos === "boolean"
        ? runProfile.returnSilentVideos
        : "unknown"
    }
  };
}

export function planAgentNativeSettingsMutations(snapshot = {}, desired = {}) {
  const mutations = [];
  const desiredConfirmation = compact(desired.confirmation) || CONFIRMATION_AUTO_APPROVE;
  if (compact(snapshot.confirmation) !== desiredConfirmation) {
    mutations.push({ section: "confirmation", control: "approval", value: desiredConfirmation });
  }
  for (const section of ["image", "video"]) {
    const target = desired?.[section];
    if (!target) continue;
    const actual = plainObject(snapshot?.[section]);
    for (const control of ["aspectRatio", "outputs", "model"]) {
      const expected = target[control];
      if (expected === "" || expected === null || expected === undefined) continue;
      if (String(actual[control] ?? "") !== String(expected)) {
        mutations.push({ section, control, value: expected });
      }
    }
  }
  return mutations;
}

export function verifyAgentNativeSettings(snapshot = {}, desired = {}) {
  if (snapshot.panelOpen !== true) {
    return { ok: false, code: "AGENT_NATIVE_SETTINGS_PANEL_NOT_OPEN", mismatches: [{ control: "panelOpen", expected: true, actual: snapshot.panelOpen }] };
  }
  const mismatches = planAgentNativeSettingsMutations(snapshot, desired);
  return {
    ok: mismatches.length === 0,
    code: mismatches.length ? "AGENT_NATIVE_SETTINGS_VERIFY_FAILED" : "",
    mismatches,
    snapshot
  };
}

export function normalizeAgentNativeModelText(text = "", section = "") {
  const value = compact(text).toLowerCase();
  if (section === "image") {
    if (/nano\s*banana\s*pro/.test(value)) return "nano_banana_pro";
    if (/nano\s*banana\s*2\s*lite/.test(value)) return "nano_banana_2_lite";
    if (/nano\s*banana\s*2/.test(value)) return "nano_banana_2";
    return "";
  }
  if (/omni\s*fla/.test(value)) return "omni_flash";
  if (/veo\s*3\.1.*lite.*lower\s*priority/.test(value)) return "veo3_lite_low";
  if (/veo\s*3\.1.*fast.*lower\s*priority/.test(value)) return "veo3_fast_low";
  if (/veo\s*3\.1.*quality/.test(value)) return "veo3_quality";
  if (/veo\s*3\.1.*fast/.test(value)) return "veo3_fast";
  if (/veo\s*3\.1.*lite/.test(value)) return "veo3_lite";
  return "";
}

function normalizeImageAspect(value = "") {
  if (value === "landscape_4_3" || value === "4:3") return "4:3";
  if (value === "square" || value === "1:1") return "1:1";
  if (value === "portrait_3_4" || value === "3:4") return "3:4";
  if (value === "portrait" || value === "9:16") return "9:16";
  return "16:9";
}

function normalizeVideoAspect(value = "") {
  return value === "portrait" || value === "9:16" ? "9:16" : "16:9";
}

function normalizeImageModel(value = "") {
  const text = compact(value).toLowerCase().replace(/[\s-]+/g, "_");
  if (text.includes("nano_banana_pro")) return "nano_banana_pro";
  if (text.includes("nano_banana_2_lite")) return "nano_banana_2_lite";
  if (text.includes("nano_banana_2")) return "nano_banana_2";
  return "";
}

function normalizeVideoModel(value = "") {
  const text = compact(value).toLowerCase().replace(/[\s-]+/g, "_");
  if (text.includes("omni")) return "omni_flash";
  if (text === "default" || (text.includes("lite") && text.includes("lower_priority"))) return "veo3_lite_low";
  if (text.includes("fast") && text.includes("lower_priority")) return "veo3_fast_low";
  if (text.includes("quality")) return "veo3_quality";
  if (text.includes("fast")) return "veo3_fast";
  if (text.includes("lite")) return "veo3_lite";
  return "";
}

function boundedOutputs(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(1, Math.min(4, Math.trunc(parsed))) : 1;
}

function nonNegativeNumber(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
}

function compact(value = "") {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function plainObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
