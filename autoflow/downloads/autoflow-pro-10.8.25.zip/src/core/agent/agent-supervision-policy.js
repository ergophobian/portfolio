import { buildAgentAutoApprovePolicy } from "./agent-autonomy.js";

export function buildAgentCreditDecision({
  action = {},
  options = {},
  approvedCredits = 0
} = {}) {
  const amount = nonNegativeNumber(action.creditAmount);
  const amountKnown = action.creditAmountKnown === true || amount > 0;
  const cap = firstFiniteNonNegativeNumber(
    options.creditCap,
    options.maxCredits,
    options.creditBudget,
    options.creditLimit
  );
  const hasCreditCap = cap !== undefined;
  const autoApprove = buildAgentAutoApprovePolicy(options);
  const hasApproval = autoApprove.credits === true || hasCreditCap;
  const nextTotal = nonNegativeNumber(approvedCredits) + amount;

  if (hasCreditCap && !amountKnown) {
    return {
      approved: false,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_amount_unknown",
      creditAmount: amount,
      creditAmountKnown: false,
      approvedCredits: nonNegativeNumber(approvedCredits),
      nextTotal,
      creditCap: cap,
      requiresApproval: true,
      escalated: true
    };
  }

  if (!hasApproval) {
    return {
      approved: false,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_confirmation_required",
      creditAmount: amount,
      creditAmountKnown: amountKnown,
      approvedCredits: nonNegativeNumber(approvedCredits),
      nextTotal,
      creditCap: cap,
      requiresApproval: true
    };
  }

  if (hasCreditCap && nextTotal > cap) {
    return {
      approved: false,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_cap_exceeded",
      creditAmount: amount,
      creditAmountKnown: amountKnown,
      approvedCredits: nonNegativeNumber(approvedCredits),
      nextTotal,
      creditCap: cap,
      requiresApproval: true,
      escalated: true
    };
  }

  return {
    approved: true,
    status: "action_resolved",
    reason: "agent_credit_confirmation_answered",
    creditAmount: amount,
    creditAmountKnown: amountKnown,
    approvedCredits: nonNegativeNumber(approvedCredits),
    nextTotal,
    creditCap: cap,
    persistentApproval: hasCreditCap
      ? false
      : options.dontAskAgain === true || options.persistentApproval === true
  };
}

export function shouldAutoRetryAgentWait({
  wait = {},
  plan = {},
  options = {}
} = {}) {
  if (wait?.retryable !== true) return false;
  const promptEdit = isPromptEditRetry(wait);
  if (promptEdit) {
    return buildAgentAutoApprovePolicy(options).rephrases === true;
  }
  return plan.retryFailedGenerations !== false;
}

export function summarizeAgentCreditPolicy(options = {}, state = {}) {
  const cap = firstFiniteNonNegativeNumber(
    options.creditCap,
    options.maxCredits,
    options.creditBudget,
    options.creditLimit
  );
  const approvedCredits = nonNegativeNumber(state.approvedCredits ?? state.confirmedCredits);
  return {
    creditCap: cap,
    approvedCredits,
    remainingCredits: cap === undefined ? undefined : Math.max(0, cap - approvedCredits)
  };
}

function isPromptEditRetry(wait = {}) {
  const blocker = wait.blocker || {};
  const retry = wait.retry || {};
  const issue = String(retry.issue || blocker.failureClass || "").toLowerCase();
  return blocker.retryableWithPromptEdit === true
    || Array.isArray(retry.retryPrompts) && retry.retryPrompts.some((entry) => entry?.prompt)
    || /policy|third[-\s]?party|prompt edit|content block/.test(issue);
}

function firstFiniteNonNegativeNumber(...values) {
  for (const value of values) {
    if (value === undefined || value === null || value === "") continue;
    const number = Number(value);
    if (Number.isFinite(number) && number >= 0) return number;
  }
  return undefined;
}

function nonNegativeNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) return 0;
  return number;
}
