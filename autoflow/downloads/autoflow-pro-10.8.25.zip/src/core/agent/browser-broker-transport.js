/**
 * Browser-client broker transport contracts.
 *
 * Shared pure helpers for the loopback `/v1/browser` WS endpoint and the
 * reusable browser SDK. Keeps origin allowlisting, capability negotiation,
 * and binary-media rejection fail-closed without redesigning the agent bridge
 * command envelope.
 */

export const BROWSER_BROKER_WS_PATH = "/v1/browser";
export const BROWSER_CLIENT_HELLO_TYPE = "broker.client.hello";
export const BROWSER_TRANSPORT = "browser_ws";

/**
 * Bridge command types the browser path is allowed to negotiate.
 * Everything else is an honest unsupported capability.
 */
export const BROWSER_BRIDGE_CAPABILITIES = Object.freeze([
  "pair.start",
  "pair.confirm",
  "pair.reset",
  "status.get",
  "bridge.targets.list",
  "bridge.target.use",
  "lane.list",
  "lane.use",
  "lane.unbind",
  "flow.tabs.list",
  "agent.tab.connect",
  "agent.context.get",
  "agent.prompt.submit",
  "agent.retry.submit",
  "agent.refs.importUrl",
  "agent.refs.attach",
  "agent.composer.submit",
  "agent.credits.confirm",
  "project.metadata.get",
  "project.media.list",
  "flow.generate",
  "flow.state.get",
  "downloads.plan",
  "downloads.execute"
]);

const BROWSER_CAPABILITY_SET = new Set(BROWSER_BRIDGE_CAPABILITIES);

/** Commands that may run before pairing (handshake + local broker status). */
export const BROWSER_PRE_PAIR_COMMANDS = Object.freeze([
  BROWSER_CLIENT_HELLO_TYPE,
  "pair.start",
  "pair.confirm",
  "status.get"
]);

const BINARY_MEDIA_KEY_PATTERN = /^(dataUrl|dataURL|imageBytes|bytesBase64|base64|fileBytes|rawBytes|binary|blob|buffer)$/i;
const DATA_URL_PATTERN = /^data:(?:image|video|audio|application)\//i;
const BASE64_BLOB_MIN_LENGTH = 4096;

/**
 * Parse origin allowlist from options/env string.
 * Empty allowlist = fail closed (no browser origins accepted).
 */
export function parseBrowserOriginAllowlist(value, options = {}) {
  if (Array.isArray(value)) {
    return normalizeOriginList(value);
  }
  if (value && typeof value === "object" && Array.isArray(value.origins)) {
    return normalizeOriginList(value.origins);
  }
  const text = String(value ?? "").trim();
  if (!text) {
    if (options.allowDefaultLoopback === true) {
      return normalizeOriginList([
        "http://127.0.0.1",
        "http://localhost",
        "https://127.0.0.1",
        "https://localhost"
      ]);
    }
    return [];
  }
  return normalizeOriginList(text.split(/[,\s]+/));
}

function normalizeOriginList(values = []) {
  const out = [];
  const seen = new Set();
  for (const raw of values) {
    const origin = normalizeOrigin(raw);
    if (!origin || seen.has(origin)) continue;
    // Never allow chrome-extension origins on the browser path; extension uses /v1/extension.
    if (origin.startsWith("chrome-extension://")) continue;
    seen.add(origin);
    out.push(origin);
  }
  return out;
}

export function normalizeOrigin(value = "") {
  const text = String(value ?? "").trim();
  if (!text) return "";
  try {
    const url = new URL(text.includes("://") ? text : `http://${text}`);
    if (!url.protocol || !url.host) return "";
    return `${url.protocol}//${url.host}`.toLowerCase();
  } catch {
    return "";
  }
}

/** Loopback page origins: 127.0.0.1 / localhost / [::1] on ANY port. */
const LOOPBACK_ORIGIN_RE = /^https?:\/\/(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$/i;

export function isLoopbackBrowserOrigin(origin = "") {
  return LOOPBACK_ORIGIN_RE.test(normalizeOrigin(origin));
}

/**
 * Origin gate for the browser path.
 *
 * Loopback pages (any port) are allowed BY DEFAULT: a local page can only
 * discover the broker and request pairing — the sidepanel "Pair Bridge"
 * click plus the pairing token remain the consent gate for every command,
 * and write commands additionally require the paired session. This is what
 * makes "connect from any local Chrome tab/port" work without the
 * AUTOFLOW_BROWSER_ORIGINS env dance. Pass options.allowLoopback === false
 * (broker env AUTOFLOW_BROWSER_LOOPBACK=off) to restore strict allowlisting.
 *
 * Remote (non-loopback) origins always require an exact allowlist match.
 * allowMissingOrigin is only for tests that cannot set Origin headers.
 */
export function isAllowedBrowserOrigin(origin, allowlist = [], options = {}) {
  const normalized = normalizeOrigin(origin);
  if (!normalized) {
    return options.allowMissingOrigin === true && Array.isArray(allowlist) && allowlist.length > 0;
  }
  if (options.allowLoopback !== false && isLoopbackBrowserOrigin(normalized)) {
    return true;
  }
  if (!Array.isArray(allowlist) || allowlist.length === 0) return false;
  const allowed = new Set(allowlist.map(normalizeOrigin).filter(Boolean));
  return allowed.has(normalized);
}

export function normalizeRequestedCapabilities(value) {
  if (!Array.isArray(value) || value.length === 0) {
    return [...BROWSER_BRIDGE_CAPABILITIES];
  }
  const requested = [];
  const unsupported = [];
  const seen = new Set();
  for (const entry of value) {
    const capability = String(entry ?? "").trim();
    if (!capability || seen.has(capability)) continue;
    seen.add(capability);
    if (BROWSER_CAPABILITY_SET.has(capability)) requested.push(capability);
    else unsupported.push(capability);
  }
  return { requested, unsupported };
}

export function resolveBrowserCapabilities(requested) {
  const normalized = Array.isArray(requested)
    ? normalizeRequestedCapabilities(requested)
    : { requested: [...BROWSER_BRIDGE_CAPABILITIES], unsupported: [] };
  if (normalized.unsupported?.length) {
    return {
      ok: false,
      code: "BROWSER_CAPABILITY_UNSUPPORTED",
      message: `Browser client requested unsupported capabilities: ${normalized.unsupported.join(", ")}`,
      unsupported: normalized.unsupported,
      capabilities: []
    };
  }
  const capabilities = normalized.requested?.length
    ? normalized.requested
    : [...BROWSER_BRIDGE_CAPABILITIES];
  return {
    ok: true,
    capabilities,
    unsupported: []
  };
}

export function isBrowserCapabilityAllowed(capability, granted = BROWSER_BRIDGE_CAPABILITIES) {
  const name = String(capability ?? "").trim();
  if (!name) return false;
  if (name === BROWSER_CLIENT_HELLO_TYPE) return true;
  if (!BROWSER_CAPABILITY_SET.has(name)) return false;
  return new Set(granted).has(name);
}

/**
 * Reject binary media fields so browser clients never ship media bytes over the bridge.
 * Reference IDs / mediaIds / local file paths are allowed; data URLs and base64 blobs are not.
 */
export function findForbiddenBinaryMedia(value, path = "$") {
  if (value == null) return null;
  if (typeof value === "string") {
    if (DATA_URL_PATTERN.test(value)) {
      return { path, reason: "data_url" };
    }
    if (value.length >= BASE64_BLOB_MIN_LENGTH && isLikelyBase64Blob(value)) {
      return { path, reason: "large_base64_blob" };
    }
    return null;
  }
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length; index += 1) {
      const hit = findForbiddenBinaryMedia(value[index], `${path}[${index}]`);
      if (hit) return hit;
    }
    return null;
  }
  if (typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      const childPath = `${path}.${key}`;
      if (BINARY_MEDIA_KEY_PATTERN.test(key) && child != null && child !== "") {
        return { path: childPath, reason: "binary_media_field", field: key };
      }
      const hit = findForbiddenBinaryMedia(child, childPath);
      if (hit) return hit;
    }
  }
  return null;
}

function isLikelyBase64Blob(value = "") {
  const sample = String(value).slice(0, 512).replace(/\s+/g, "");
  if (sample.length < 64) return false;
  return /^[A-Za-z0-9+/=]+$/.test(sample);
}

export function buildBrowserClientHelloPayload(options = {}) {
  const capabilityResult = resolveBrowserCapabilities(options.requestedCapabilities);
  return {
    transport: BROWSER_TRANSPORT,
    protocolVersion: Number(options.protocolVersion) || 1,
    brokerInstanceId: String(options.brokerInstanceId || ""),
    browserWsPath: String(options.browserWsPath || BROWSER_BROKER_WS_PATH),
    browserWsUrl: String(options.browserWsUrl || ""),
    httpUrl: String(options.httpUrl || ""),
    requiresPairing: options.requiresPairing !== false,
    capabilities: capabilityResult.ok ? capabilityResult.capabilities : [],
    capabilityResult,
    origin: String(options.origin || ""),
    clientId: String(options.clientId || ""),
    neverBinaryMedia: true
  };
}

export function browserPermissionEventFromBridgePayload(payload = {}, source = {}) {
  const confirmation = payload.confirmation && typeof payload.confirmation === "object"
    ? payload.confirmation
    : null;
  const creditDialog = payload.creditDialog && typeof payload.creditDialog === "object"
    ? payload.creditDialog
    : null;
  const waiting = payload.status === "waiting_for_credit_approval"
    || payload.reason === "waiting_for_credit_approval"
    || payload.blockCode === "waiting_for_credit_approval"
    || Boolean(creditDialog);
  if (!waiting && !confirmation && !creditDialog) return null;
  return {
    type: "permission",
    kind: "credit_confirmation",
    status: waiting ? "required" : (confirmation?.confirmed === true ? "confirmed" : "present"),
    confirmOnceSupported: true,
    persistentSupported: true,
    rejectSupported: false,
    rejectCode: "BROWSER_PERMISSION_REJECT_UNSUPPORTED",
    rejectMessage: "Explicit credit reject/cancel is not wired on the Flow credit dialog path; leave the dialog open or dismiss it in the Flow UI.",
    creditDialog,
    confirmation,
    source: {
      requestId: String(source.requestId || ""),
      command: String(source.command || "")
    }
  };
}

export function buildBrowserStreamEventsFromSubmitResult(result = {}, options = {}) {
  const events = [];
  const requestId = String(options.requestId || "");
  const dryRun = result.dryRun === true || options.dryRun === true;
  events.push({
    type: "stream",
    kind: "submit.started",
    requestId,
    dryRun,
    at: options.now || new Date().toISOString()
  });
  const promptPreview = String(result.promptPreview || result.prompt || "").trim();
  if (promptPreview) {
    events.push({
      type: "stream",
      kind: "text",
      requestId,
      text: promptPreview,
      role: "user_prompt_preview"
    });
  }
  if (result.editor || result.submitButton) {
    events.push({
      type: "stream",
      kind: "tool",
      requestId,
      name: dryRun ? "agent.prompt.submit.diagnostic" : "agent.prompt.submit",
      status: result.submitted === true ? "submitted" : (dryRun ? "diagnostic_ready" : "prepared"),
      details: {
        editor: result.editor || null,
        submitButton: result.submitButton || null,
        accepted: result.accepted || null
      }
    });
  }
  if (result.confirmation || result.creditDialog) {
    events.push({
      type: "stream",
      kind: "tool",
      requestId,
      name: "agent.credits.inspect",
      status: "visible",
      details: {
        confirmation: result.confirmation || null,
        creditDialog: result.creditDialog || null
      }
    });
  }
  if (Array.isArray(result.latestMessages)) {
    for (const message of result.latestMessages) {
      const text = String(message?.text || message?.content || message?.message || "").trim();
      if (!text) continue;
      events.push({
        type: "stream",
        kind: "text",
        requestId,
        text,
        role: String(message?.role || message?.author || "agent")
      });
    }
  }
  if (Array.isArray(result.toolEvents)) {
    for (const tool of result.toolEvents) {
      events.push({
        type: "stream",
        kind: "tool",
        requestId,
        name: String(tool?.name || tool?.tool || "tool"),
        status: String(tool?.status || "update"),
        details: tool
      });
    }
  }
  events.push({
    type: "stream",
    kind: "submit.done",
    requestId,
    dryRun,
    submitted: result.submitted === true,
    ok: result.ok !== false
  });
  return events;
}
