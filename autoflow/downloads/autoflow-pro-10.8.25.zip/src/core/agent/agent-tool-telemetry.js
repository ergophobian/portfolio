const TELEMETRY_KEYS = new Set([
  "placeholder_frontend_id",
  "reference_image_media_ids",
  "model_display_name",
  "aspect_ratio",
  "duration",
  "output_count",
  "number_of_outputs",
  "batch_id",
  "workflow_id",
  "media_id",
  "status"
]);

export function parseAgentSseTelemetry(input = "") {
  const events = parseSseJsonValues(input);
  const fields = [];
  for (const event of events) collectTelemetryFields(event.value, "$", fields, event.index);
  const values = indexTelemetryFields(fields);
  return {
    ok: events.length > 0,
    eventCount: events.length,
    fields,
    placeholderFrontendIds: uniqueStrings(values.placeholder_frontend_id),
    referenceImageMediaIds: uniqueStrings(values.reference_image_media_ids.flatMap(arrayValue)),
    modelDisplayNames: uniqueStrings(values.model_display_name),
    aspectRatios: uniqueStrings(values.aspect_ratio),
    durations: uniqueNumbers(values.duration),
    outputCounts: uniqueNumbers([...values.output_count, ...values.number_of_outputs]),
    batchIds: uniqueStrings(values.batch_id),
    workflowIds: uniqueStrings(values.workflow_id),
    mediaIds: uniqueStrings(values.media_id),
    statuses: uniqueStrings(values.status)
  };
}

export function buildAgentPendingToolContract(input = {}) {
  const profile = plainObject(input.runProfile || input.settings);
  const expectedVideos = nonNegativeNumber(input.expectedVideos ?? input.matrix?.expectedVideos ?? input.manifest?.expectedVideos);
  const expectedImages = nonNegativeNumber(input.expectedImages ?? input.matrix?.expectedImages ?? input.manifest?.expectedImages);
  const video = expectedVideos > 0 || String(profile.mode || input.matrix?.mode || "").toLowerCase().includes("video");
  return {
    required: input.requireToolContractValidation !== false,
    kind: video ? "video" : "image",
    modelDisplayName: compact(video ? (profile.videoModel || profile.model) : (profile.imageModel || profile.model)),
    aspectRatio: compact(profile.aspectRatio || input.matrix?.settings?.aspectRatio),
    durationSeconds: video ? positiveNumber(profile.videoLength || input.matrix?.settings?.videoLength) : null,
    outputCount: video ? Math.max(0, expectedVideos) : Math.max(0, expectedImages),
    referenceCount: Array.isArray(input.refPlan?.attachments)
      ? input.refPlan.attachments.length
      : (Array.isArray(input.attachments) ? input.attachments.length : 0)
  };
}

export function validateAgentPendingToolContract(contract = {}, telemetry = {}) {
  if (contract.required !== true) return { ok: true, skipped: true, reason: "validation_not_required" };
  const mismatches = [];
  const unavailable = [];
  const observedOutputCounts = Array.isArray(telemetry.outputCounts) && telemetry.outputCounts.length
    ? telemetry.outputCounts
    : (Array.isArray(telemetry.placeholderFrontendIds) && telemetry.placeholderFrontendIds.length
      ? [telemetry.placeholderFrontendIds.length]
      : []);
  compareText("modelDisplayName", contract.modelDisplayName, telemetry.modelDisplayNames, mismatches, unavailable, normalizeModel);
  compareText("aspectRatio", contract.aspectRatio, telemetry.aspectRatios, mismatches, unavailable, normalizeRatio);
  if (contract.kind === "video" && Number.isFinite(contract.durationSeconds)) {
    compareNumber("durationSeconds", contract.durationSeconds, telemetry.durations, mismatches, unavailable);
  }
  if (Number(contract.outputCount || 0) > 0) {
    compareNumber("outputCount", Number(contract.outputCount), observedOutputCounts, mismatches, unavailable);
  }
  if (Number(contract.referenceCount || 0) > 0) {
    const actualReferenceCount = Array.isArray(telemetry.referenceImageMediaIds) ? telemetry.referenceImageMediaIds.length : 0;
    if (!actualReferenceCount) unavailable.push({ field: "referenceImageMediaIds", expectedCount: contract.referenceCount });
    else if (actualReferenceCount !== Number(contract.referenceCount)) {
      mismatches.push({ field: "referenceCount", expected: Number(contract.referenceCount), actual: actualReferenceCount });
    }
  }
  return {
    ok: mismatches.length === 0 && unavailable.length === 0,
    code: mismatches.length ? "AGENT_TOOL_CONTRACT_MISMATCH" : (unavailable.length ? "AGENT_TOOL_TELEMETRY_UNAVAILABLE" : ""),
    contract,
    observed: {
      placeholderFrontendIds: telemetry.placeholderFrontendIds || [],
      referenceImageMediaIds: telemetry.referenceImageMediaIds || [],
      modelDisplayNames: telemetry.modelDisplayNames || [],
      aspectRatios: telemetry.aspectRatios || [],
      durations: telemetry.durations || [],
      outputCounts: observedOutputCounts,
      batchIds: telemetry.batchIds || [],
      workflowIds: telemetry.workflowIds || [],
      mediaIds: telemetry.mediaIds || [],
      statuses: telemetry.statuses || []
    },
    mismatches,
    unavailable
  };
}

function parseSseJsonValues(input = "") {
  const text = String(input || "");
  const candidates = [];
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(":")) continue;
    const value = trimmed.startsWith("data:") ? trimmed.slice(5).trim() : trimmed;
    if (!value || value === "[DONE]") continue;
    try {
      candidates.push({ index: candidates.length, value: JSON.parse(value) });
    } catch {}
  }
  if (!candidates.length) {
    try { candidates.push({ index: 0, value: JSON.parse(text) }); } catch {}
  }
  return candidates;
}

function collectTelemetryFields(value, path, fields, eventIndex) {
  if (Array.isArray(value)) {
    value.forEach((entry, index) => collectTelemetryFields(entry, `${path}[${index}]`, fields, eventIndex));
    return;
  }
  if (!value || typeof value !== "object") return;
  for (const [key, entry] of Object.entries(value)) {
    const normalizedKey = snakeCase(key);
    const nextPath = `${path}.${key}`;
    if (TELEMETRY_KEYS.has(normalizedKey)) fields.push({ eventIndex, key: normalizedKey, path: nextPath, value: entry });
    collectTelemetryFields(entry, nextPath, fields, eventIndex);
  }
}

function indexTelemetryFields(fields = []) {
  const values = Object.fromEntries([...TELEMETRY_KEYS].map((key) => [key, []]));
  for (const field of fields) values[field.key].push(field.value);
  return values;
}

function compareText(field, expected, values, mismatches, unavailable, normalize) {
  if (!compact(expected)) return;
  const actual = uniqueStrings(values).map(normalize);
  if (!actual.length) unavailable.push({ field, expected });
  else if (actual.some((value) => value !== normalize(expected))) mismatches.push({ field, expected, actual: uniqueStrings(values) });
}

function compareNumber(field, expected, values, mismatches, unavailable) {
  const actual = uniqueNumbers(values);
  if (!actual.length) unavailable.push({ field, expected });
  else if (actual.some((value) => Math.abs(value - expected) >= 0.001)) mismatches.push({ field, expected, actual });
}

function snakeCase(value = "") {
  return String(value).replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
}
function arrayValue(value) { return Array.isArray(value) ? value : [value]; }
function uniqueStrings(values = []) { return [...new Set(values.map(compact).filter(Boolean))]; }
function uniqueNumbers(values = []) { return [...new Set(values.map(positiveNumber).filter(Number.isFinite))]; }
function positiveNumber(value) { const match = String(value ?? "").match(/\d+(?:\.\d+)?/); const number = match ? Number(match[0]) : Number.NaN; return Number.isFinite(number) && number >= 0 ? number : Number.NaN; }
function nonNegativeNumber(value) { const number = Number(value); return Number.isFinite(number) && number >= 0 ? number : 0; }
function normalizeModel(value = "") { return compact(value).toLowerCase().replace(/[^a-z0-9]+/g, ""); }
function normalizeRatio(value = "") { return compact(value).toLowerCase().replace(/landscape/g, "16:9").replace(/portrait/g, "9:16").replace(/\s+/g, ""); }
function compact(value = "") { return String(value ?? "").replace(/\s+/g, " ").trim(); }
function plainObject(value) { return value && typeof value === "object" && !Array.isArray(value) ? value : {}; }
