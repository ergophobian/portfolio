import { AGENT_BRIDGE_VERSION } from "../core/agent/agent-bridge-protocol.js";
import { AGENT_BRIDGE_ENABLED_STORAGE_KEY, readAgentBridgeEnabled } from "./native-bridge.js";

const DEFAULT_WS_BROKER_URLS = Object.freeze([
  // Keep in sync with native-host/broker.js DEFAULT_WS_PORT_RANGE; the broker rejects custom product ports outside this range.
  ...Array.from({ length: 10 }, (_unused, index) => `ws://127.0.0.1:${17677 + index}/v1/extension`)
]);
const WS_BROKER_URL_STORAGE_KEY = "autoflow-ws-broker-url";
const WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY = "autoflow-ws-broker-registration-secret";
const TERMINAL_REGISTER_REJECT_CODES = Object.freeze(new Set([
  "WS_EXTENSION_NOT_ALLOWED",
  "WS_EXTENSION_ORIGIN_MISMATCH",
  "WS_EXTENSION_REGISTRATION_PROOF_INVALID",
  "WS_EXTENSION_REGISTRATION_PROOF_REQUIRED",
  "WS_EXTENSION_REGISTRATION_SECRET_UNAVAILABLE",
  "BRIDGE_PROTOCOL_MISMATCH",
  "PAIRING_TOKEN_INVALID"
]));

export function createWsBrokerBridgeController(options = {}) {
  const bridge = options.bridge;
  const chromeApi = options.chromeApi || globalThis.chrome;
  const WebSocketCtor = options.WebSocketCtor || globalThis.WebSocket;
  const onEvent = typeof options.onEvent === "function" ? options.onEvent : () => {};
  const enabledReader = typeof options.enabledReader === "function"
    ? options.enabledReader
    : () => readAgentBridgeEnabled(chromeApi);
  const setTimer = options.setTimeout || globalThis.setTimeout?.bind(globalThis);
  const clearTimer = options.clearTimeout || globalThis.clearTimeout?.bind(globalThis);
  const reconnectDelayMs = positiveInteger(options.reconnectDelayMs, 1500);
  const maxReconnectDelayMs = positiveInteger(options.reconnectMaxDelayMs, 30000);
  const heartbeatMs = positiveInteger(options.heartbeatMs, 25000);
  let started = false;
  let enabled = false;
  let socket = null;
  let connecting = false;
  let urlIndex = 0;
  let activeUrl = "";
  let lastSuccessfulUrl = "";
  let registered = false;
  let registerRequestId = "";
  let storageListenerInstalled = false;
  let reconnectTimer = null;
  let heartbeatTimer = null;
  let nextReconnectDelayMs = reconnectDelayMs;
  let requestSequence = 0;
  let lastConnectedAt = "";
  let lastRegisteredAt = "";
  let lastDisconnectedAt = "";
  let lastHeartbeatAt = "";
  let lastError = "";
  let lastErrorCode = "";
  let brokerInstanceId = "";
  let brokerProtocolVersion = null;
  let brokerPaired = false;
  let registerBlockedCode = "";
  let registrationSecret = String(options.registrationSecret || "").trim();

  async function start(reason = "startup") {
    started = true;
    installStorageListener();
    return refresh(reason);
  }

  async function refresh(reason = "refresh") {
    registerBlockedCode = "";
    nextReconnectDelayMs = reconnectDelayMs;
    enabled = false;
    try {
      enabled = await enabledReader();
    } catch (error) {
      recordError("WS_BROKER_ENABLED_READ_FAILED", error?.message || String(error || "enabled_read_failed"));
      emit({ type: "agent_bridge.ws_broker.enabled_read_error", reason, error: lastError });
    }
    bridge?.setEnabled?.(enabled === true);
    if (!enabled) {
      disconnect("disabled");
      return false;
    }
    return connect(reason);
  }

  async function connect(reason = "connect") {
    if (socket && (socket.readyState === WebSocketCtor.OPEN || socket.readyState === WebSocketCtor.CONNECTING)) return true;
    if (connecting || typeof WebSocketCtor !== "function") {
      if (typeof WebSocketCtor !== "function") {
        recordError("WS_BROKER_WEBSOCKET_UNAVAILABLE", "WebSocket is unavailable in this extension runtime.");
      }
      return false;
    }
    connecting = true;
    registrationSecret = await resolveRegistrationSecret();
    if (!registrationSecret) {
      connecting = false;
      registerBlockedCode = "WS_EXTENSION_REGISTRATION_SECRET_UNAVAILABLE";
      nextReconnectDelayMs = maxReconnectDelayMs;
      recordError(
        registerBlockedCode,
        "Auto Flow could not provision a WS broker registration secret in extension storage."
      );
      emit({ type: "agent_bridge.ws_broker.registration_secret_unavailable", code: lastErrorCode, error: lastError });
      scheduleReconnect("registration_secret_unavailable");
      return false;
    }
    const urls = await brokerUrls();
    if (!urls.length) {
      connecting = false;
      recordError("WS_BROKER_URL_MISSING", "No Auto Flow WS broker URL is configured.");
      scheduleReconnect("missing_url");
      return false;
    }
    activeUrl = lastSuccessfulUrl && urls.includes(lastSuccessfulUrl)
      ? lastSuccessfulUrl
      : urls[urlIndex % urls.length];
    try {
      const ws = new WebSocketCtor(activeUrl);
      socket = ws;
      ws.onopen = () => {
        if (socket !== ws) {
          try { ws.close?.(); } catch {}
          return;
        }
        connecting = false;
        lastConnectedAt = new Date().toISOString();
        nextReconnectDelayMs = reconnectDelayMs;
        lastSuccessfulUrl = activeUrl;
        lastError = "";
        lastErrorCode = "";
        emit({ type: "agent_bridge.ws_broker.connected", reason, url: activeUrl });
        sendRegister();
        scheduleHeartbeat();
      };
      ws.onmessage = (event) => {
        if (socket !== ws) return;
        handleSocketMessage(String(event?.data || "")).catch((error) => {
          recordError(error?.code || "WS_BROKER_MESSAGE_FAILED", error?.message || String(error || "ws_message_failed"));
          emit({ type: "agent_bridge.ws_broker.message_failed", error: lastError, code: lastErrorCode });
        });
      };
      ws.onerror = () => {
        if (socket !== ws) return;
        recordError("WS_BROKER_UNAVAILABLE", `Auto Flow WS broker unavailable at ${activeUrl}`);
        advanceUrl();
      };
      ws.onclose = () => {
        if (socket !== ws) return;
        socket = null;
        connecting = false;
        registered = false;
        cancelHeartbeat("closed");
        lastDisconnectedAt = new Date().toISOString();
        emit({ type: "agent_bridge.ws_broker.disconnected", reason, url: activeUrl, error: lastError, code: lastErrorCode });
        scheduleReconnect("closed");
      };
      return true;
    } catch (error) {
      connecting = false;
      recordError("WS_BROKER_UNAVAILABLE", error?.message || String(error || "ws_broker_connect_failed"));
      scheduleReconnect("connect_failed");
      return false;
    }
  }

  async function handleSocketMessage(raw) {
    if (!raw) return;
    const message = JSON.parse(raw);
    if (message.type === "broker.extension.register" && message.id === registerRequestId) {
      if (message.ok === true) {
        registered = true;
        registerBlockedCode = "";
        lastRegisteredAt = new Date().toISOString();
        brokerInstanceId = String(message.payload?.brokerInstanceId || "");
        brokerProtocolVersion = Number(message.payload?.protocolVersion || 0) || null;
        brokerPaired = message.payload?.paired === true;
        lastError = "";
        lastErrorCode = "";
        emit({ type: "agent_bridge.ws_broker.registered", brokerInstanceId, protocolVersion: brokerProtocolVersion });
        return;
      }
      handleRegisterRejected(message);
      return;
    }
    if (message.type === "broker.extension.ping" && message.ok === true) {
      lastHeartbeatAt = new Date().toISOString();
      return;
    }
    if (typeof message.ok === "boolean") return;
    const response = await bridge.handleMessage(message, {
      transport: "ws_broker",
      wsBrokerConnected: true,
      brokerUrl: activeUrl,
      extensionId: chromeApi?.runtime?.id || ""
    });
    send(response);
  }

  function handleRegisterRejected(message) {
    registered = false;
    const code = String(message?.error?.code || "WS_BROKER_REGISTER_REJECTED");
    const detail = String(
      message?.error?.message || "Auto Flow WS broker rejected extension registration."
    );
    recordError(code, detail);
    const terminal = TERMINAL_REGISTER_REJECT_CODES.has(code);
    if (terminal) {
      registerBlockedCode = code;
      nextReconnectDelayMs = maxReconnectDelayMs;
    }
    emit({ type: "agent_bridge.ws_broker.register_failed", code, error: detail, terminal });
    const rejected = socket;
    if (rejected) {
      try {
        rejected.close?.();
      } catch {}
    }
  }

  async function resolveRegistrationSecret() {
    const optionSecret = String(options.registrationSecret || "").trim();
    if (optionSecret) return optionSecret;
    const managed = await readRegistrationSecretFrom(chromeApi?.storage?.managed);
    if (managed) return managed;
    const local = await readRegistrationSecretFrom(chromeApi?.storage?.local);
    if (local) return local;
    return ensureLocalRegistrationSecret();
  }

  async function ensureLocalRegistrationSecret() {
    const area = chromeApi?.storage?.local;
    if (typeof area?.set !== "function") return "";
    const generated = generateRegistrationSecret();
    if (!generated) return "";
    try {
      await Promise.resolve(area.set({ [WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY]: generated }));
    } catch {
      return "";
    }
    return generated;
  }

  function sendRegister() {
    registerRequestId = nextRequestId("register");
    send({
      id: registerRequestId,
      type: "broker.extension.register",
      payload: {
        transport: "ws_broker",
        extensionId: chromeApi?.runtime?.id || "",
        ...(registrationSecret ? { registrationSecret } : {}),
        metadata: {
          transport: "ws_broker",
          extensionVersion: chromeApi?.runtime?.getManifest?.()?.version || "",
          bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
          profileHint: "",
          capabilities: typeof bridge?.supportedCommands === "function" ? bridge.supportedCommands() : []
        }
      }
    });
  }

  function sendHeartbeat() {
    if (!isOpen()) return;
    send({
      id: nextRequestId("ping"),
      type: "broker.extension.ping",
      payload: {
        transport: "ws_broker",
        extensionId: chromeApi?.runtime?.id || "",
        at: new Date().toISOString()
      }
    });
  }

  function send(message) {
    if (!isOpen()) return false;
    socket.send(JSON.stringify(message));
    return true;
  }

  function isOpen() {
    return Boolean(socket && socket.readyState === WebSocketCtor.OPEN);
  }

  function scheduleHeartbeat() {
    cancelHeartbeat("reschedule");
    if (!started || !enabled || heartbeatMs <= 0 || typeof setTimer !== "function") return;
    heartbeatTimer = setTimer(() => {
      heartbeatTimer = null;
      sendHeartbeat();
      scheduleHeartbeat();
    }, heartbeatMs);
  }

  function scheduleReconnect(reason = "reconnect") {
    if (!started || !enabled || reconnectTimer || typeof setTimer !== "function") return false;
    const delayMs = nextReconnectDelayMs;
    reconnectTimer = setTimer(() => {
      reconnectTimer = null;
      connect(`reconnect:${reason}`);
    }, delayMs);
    nextReconnectDelayMs = Math.min(maxReconnectDelayMs, Math.max(reconnectDelayMs, delayMs * 2 || reconnectDelayMs));
    emit({ type: "agent_bridge.ws_broker.reconnect_scheduled", reason, delayMs });
    return true;
  }

  function advanceUrl() {
    urlIndex += 1;
    if (activeUrl === lastSuccessfulUrl) lastSuccessfulUrl = "";
  }

  function installStorageListener() {
    if (storageListenerInstalled || !chromeApi?.storage?.onChanged?.addListener) return;
    storageListenerInstalled = true;
    chromeApi.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "managed") {
        if (!changes?.[WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY]) return;
        refresh("managed_secret_changed").catch((error) => {
          recordError("WS_BROKER_REFRESH_FAILED", error?.message || String(error || "ws_broker_refresh_failed"));
          emit({ type: "agent_bridge.ws_broker.refresh_failed", error: lastError, code: lastErrorCode });
        });
        return;
      }
      if (areaName !== "local") return;
      if (!changes?.[AGENT_BRIDGE_ENABLED_STORAGE_KEY]
        && !changes?.[WS_BROKER_URL_STORAGE_KEY]
        && !changes?.[WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY]) return;
      refresh("storage_changed").catch((error) => {
        recordError("WS_BROKER_REFRESH_FAILED", error?.message || String(error || "ws_broker_refresh_failed"));
        emit({ type: "agent_bridge.ws_broker.refresh_failed", error: lastError, code: lastErrorCode });
      });
    });
  }

  function disconnect(reason = "disconnect") {
    cancelReconnect(reason);
    cancelHeartbeat(reason);
    registered = false;
    if (!socket) return;
    const current = socket;
    socket = null;
    connecting = false;
    try {
      current.close?.();
    } catch {}
    lastDisconnectedAt = new Date().toISOString();
  }

  function cancelReconnect() {
    if (!reconnectTimer) return;
    try {
      clearTimer?.(reconnectTimer);
    } catch {}
    reconnectTimer = null;
  }

  function cancelHeartbeat() {
    if (!heartbeatTimer) return;
    try {
      clearTimer?.(heartbeatTimer);
    } catch {}
    heartbeatTimer = null;
  }

  async function useBrokerUrl(value, reason = "broker_available") {
    const wsUrl = String(value || "").trim();
    if (!DEFAULT_WS_BROKER_URLS.includes(wsUrl)) {
      const error = new Error("Auto Flow broker URL must use the fixed loopback WS discovery range.");
      error.code = "WS_BROKER_URL_INVALID";
      throw error;
    }
    disconnect(`preferred_url:${reason}`);
    urlIndex = 0;
    lastSuccessfulUrl = wsUrl;
    if (chromeApi?.storage?.local?.set) {
      await chromeApi.storage.local.set({ [WS_BROKER_URL_STORAGE_KEY]: wsUrl });
    }
    await refresh(reason);
    return diagnostics();
  }

  function diagnostics() {
    const connected = isOpen();
    const state = !enabled
      ? "disabled"
      : (registerBlockedCode
        ? "auth_blocked"
        : (connected && registered ? "connected" : (connected ? "registering" : (lastErrorCode ? "unavailable" : "disconnected"))));
    return {
      transport: "ws_broker",
      preferred: true,
      enabled,
      state,
      connected: connected && registered,
      socketOpen: connected,
      registered,
      authBlocked: Boolean(registerBlockedCode),
      authBlockedCode: registerBlockedCode,
      brokerUrl: activeUrl,
      brokerInstanceId,
      brokerProtocolVersion,
      bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
      paired: connected && registered && brokerPaired,
      lastConnectedAt,
      lastRegisteredAt,
      lastDisconnectedAt,
      lastHeartbeatAt,
      reconnecting: Boolean(reconnectTimer),
      reconnectDelayMs: reconnectTimer ? nextReconnectDelayMs : 0,
      error: lastError,
      errorCode: lastErrorCode,
      brokenLink: brokenLinkForState(state, lastErrorCode),
      nextAction: nextActionForState(state, lastErrorCode)
    };
  }

  async function brokerUrls() {
    const configured = Array.isArray(options.urls) ? options.urls : [];
    const storedUrl = await readStoredBrokerUrl(chromeApi).catch(() => "");
    return [...new Set([
      storedUrl,
      ...configured,
      ...DEFAULT_WS_BROKER_URLS
    ].map((url) => String(url || "").trim()).filter(Boolean))];
  }

  function nextRequestId(kind) {
    requestSequence += 1;
    return `af-ws-${kind}-${Date.now()}-${requestSequence}`;
  }

  function emit(event) {
    onEvent(event);
  }

  function recordError(code, message) {
    lastErrorCode = String(code || "WS_BROKER_ERROR");
    lastError = String(message || lastErrorCode);
  }

  return {
    start,
    refresh,
    useBrokerUrl,
    stop(reason = "stop") {
      started = false;
      disconnect(reason);
    },
    isConnected() {
      return diagnostics().connected === true;
    },
    diagnostics
  };
}

async function readStoredBrokerUrl(chromeApi) {
  if (!chromeApi?.storage?.local?.get) return "";
  const stored = await chromeApi.storage.local.get([WS_BROKER_URL_STORAGE_KEY]);
  return String(stored?.[WS_BROKER_URL_STORAGE_KEY] || "").trim();
}

async function readRegistrationSecretFrom(area) {
  if (typeof area?.get !== "function") return "";
  const stored = await Promise.resolve(area.get([WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY])).catch(() => ({}));
  return String(stored?.[WS_BROKER_REGISTRATION_SECRET_STORAGE_KEY] || "").trim();
}

function brokenLinkForState(state, code) {
  if (state === "connected") return "";
  if (state === "disabled") return "ws_broker.disabled";
  if (code === "BRIDGE_PROTOCOL_MISMATCH") return "ws_broker.protocol_version";
  if (code === "PAIRING_TOKEN_INVALID") return "ws_broker.pairing_token";
  if (code === "WS_EXTENSION_NOT_ALLOWED" || code === "WS_EXTENSION_ORIGIN_MISMATCH") return "ws_broker.extension_not_allowed";
  if (code === "WS_EXTENSION_REGISTRATION_PROOF_INVALID"
    || code === "WS_EXTENSION_REGISTRATION_PROOF_REQUIRED"
    || code === "WS_EXTENSION_REGISTRATION_SECRET_UNAVAILABLE") return "ws_broker.registration_proof";
  if (state === "disconnected" || state === "unavailable") return "ws_broker.package_daemon";
  return "ws_broker.extension_socket";
}

function nextActionForState(state, code) {
  if (state === "connected") return "";
  if (state === "disabled") return "Enable Pair Bridge in Auto Flow, then run autoflow pair.";
  if (code === "BRIDGE_PROTOCOL_MISMATCH") return "Update both the Auto Flow extension and CLI/MCP package.";
  if (code === "PAIRING_TOKEN_INVALID") return "Run autoflow pair --reset, then pair again.";
  if (code === "WS_EXTENSION_NOT_ALLOWED" || code === "WS_EXTENSION_ORIGIN_MISMATCH") return "Run autoflow pair --reset, open Auto Flow and click Pair Bridge, then run autoflow pair again.";
  if (code === "WS_EXTENSION_REGISTRATION_PROOF_INVALID" || code === "WS_EXTENSION_REGISTRATION_PROOF_REQUIRED") return "Run autoflow pair --reset, then pair Auto Flow again over the WS broker to re-pin the registration proof.";
  if (code === "WS_EXTENSION_REGISTRATION_SECRET_UNAVAILABLE") return "Enable extension storage for Auto Flow, then retry Pair Bridge.";
  if (state === "disconnected" || state === "unavailable") return "Run autoflow bridge up, then retry autoflow status.";
  return "Open the Auto Flow sidepanel so the extension can register with the broker.";
}

function generateRegistrationSecret() {
  const cryptoApi = globalThis.crypto || globalThis.self?.crypto;
  if (typeof cryptoApi?.getRandomValues !== "function") return "";
  const bytes = new Uint8Array(32);
  cryptoApi.getRandomValues(bytes);
  let secret = "";
  for (const byte of bytes) secret += byte.toString(16).padStart(2, "0");
  return secret;
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
