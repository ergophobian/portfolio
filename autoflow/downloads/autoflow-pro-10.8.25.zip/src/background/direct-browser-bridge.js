const DIRECT_PROTOCOL = "auto-flow.patchwork.direct";
const DIRECT_VERSION = 1;
const DIRECT_INSTANCE_STORAGE_KEY = "autoflow-direct-extension-instance-id";
const DIRECT_REQUEST_MAX_AGE_MS = 10 * 60 * 1000;
const LOOPBACK_ORIGIN_RE = /^https?:\/\/(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/i;
const DEFAULT_REMOTE_ORIGINS = Object.freeze([
  "https://patchwork-33m.pages.dev",
  "https://patchwork.pages.dev"
]);

export const DIRECT_BROWSER_PROTOCOL = DIRECT_PROTOCOL;
export const DIRECT_BROWSER_VERSION = DIRECT_VERSION;

export function createDirectBrowserBridgeController(options = {}) {
  const chromeApi = options.chromeApi || globalThis.chrome;
  const sidepanelStateKey = String(options.sidepanelStateKey || "autoflow-10767-rebuild-sidepanel-state");
  const listFlowTabs = typeof options.listFlowTabs === "function" ? options.listFlowTabs : async () => ({ tabs: [] });
  const now = typeof options.now === "function" ? options.now : () => Date.now();
  const randomId = typeof options.randomId === "function" ? options.randomId : defaultRandomId;
  const isPrivacyConsentGranted = typeof options.isPrivacyConsentGranted === "function"
    ? options.isPrivacyConsentGranted
    : () => true;
  const allowedRemoteOrigins = new Set((options.allowedRemoteOrigins || DEFAULT_REMOTE_ORIGINS).map(normalizeOrigin).filter(Boolean));

  async function handleMessage(message = {}, sender = {}) {
    if (message?.protocol !== DIRECT_PROTOCOL || Number(message?.version) !== DIRECT_VERSION) return undefined;
    if (!isPrivacyConsentGranted()) {
      return directError("DIRECT_PRIVACY_CONSENT_REQUIRED", "Agree to the AutoFlow Pro privacy notice before connecting PatchWork.");
    }
    if (String(message?.type || "") !== "connect") {
      return directError("DIRECT_COMMAND_UNSUPPORTED", `Unsupported direct browser command: ${String(message?.type || "missing")}`);
    }

    const origin = senderOrigin(sender);
    if (!isAllowedOrigin(origin, allowedRemoteOrigins)) {
      return directError("DIRECT_ORIGIN_FORBIDDEN", "This PatchWork origin is not allowed to connect to Auto Flow.", { origin });
    }

    const clientId = compact(message?.clientId);
    if (!clientId) return directError("DIRECT_CLIENT_ID_REQUIRED", "PatchWork direct connection requires a stable clientId.");
    const clientName = compact(message?.clientName).slice(0, 120) || "PatchWork";
    const tabId = Number(sender?.tab?.id || 0) || null;
    const windowId = Number(sender?.tab?.windowId);
    const normalizedWindowId = Number.isFinite(windowId) ? windowId : null;
    const requestedAt = new Date(now()).toISOString();
    const instanceId = await extensionInstanceId(chromeApi, randomId);
    const stored = await chromeApi.storage.local.get(sidepanelStateKey).catch(() => ({}));
    const sidepanelState = stored?.[sidepanelStateKey] || {};
    const control = objectValue(sidepanelState.control);
    const agentMode = objectValue(control.agentMode);
    const approved = objectValue(agentMode.directApprovedClient);
    const approvedMatch = approved.clientId === clientId && approved.origin === origin;

    if (!approvedMatch) {
      const prior = objectValue(agentMode.directPendingClient);
      const priorAt = Date.parse(prior.requestedAt || "");
      const samePending = prior.clientId === clientId
        && prior.origin === origin
        && Number(prior.windowId) === Number(normalizedWindowId)
        && Number.isFinite(priorAt)
        && now() - priorAt < DIRECT_REQUEST_MAX_AGE_MS;
      const requestId = samePending ? compact(prior.requestId) : randomId("direct-request");
      const pending = {
        requestId,
        clientId,
        clientName,
        origin,
        tabId,
        windowId: normalizedWindowId,
        requestedAt
      };
      await chromeApi.storage.local.set({
        [sidepanelStateKey]: {
          ...sidepanelState,
          control: {
            ...control,
            agentMode: {
              ...agentMode,
              directPendingClient: pending
            }
          }
        }
      });
      return directError(
        "DIRECT_APPROVAL_REQUIRED",
        `Approve ${clientName} in the Auto Flow Connections panel.`,
        { requestId, clientId, clientName, origin, extensionInstanceId: instanceId }
      );
    }

    const inventory = await listFlowTabs({ directWindowId: normalizedWindowId }).catch(() => ({ tabs: [] }));
    const allTabs = Array.isArray(inventory?.tabs) ? inventory.tabs : [];
    const sameWindowTabs = normalizedWindowId == null
      ? []
      : allTabs.filter((tab) => Number(tab?.windowId) === normalizedWindowId);
    const candidates = sameWindowTabs.length ? sameWindowTabs : (allTabs.length === 1 ? allTabs : []);
    const recommendedTarget = chooseCurrentTarget(candidates);
    return {
      ok: true,
      protocol: DIRECT_PROTOCOL,
      version: DIRECT_VERSION,
      approved: true,
      extensionInstanceId: instanceId,
      clientId,
      origin,
      patchworkTabId: tabId,
      patchworkWindowId: normalizedWindowId,
      targetSource: sameWindowTabs.length ? "same_window" : (candidates.length ? "only_profile_flow_tab" : "selection_required"),
      recommendedTarget,
      tabs: candidates,
      allProfileTabCount: allTabs.length
    };
  }

  function install() {
    const event = chromeApi?.runtime?.onMessageExternal;
    if (typeof event?.addListener !== "function") return false;
    event.addListener((message, sender, sendResponse) => {
      if (message?.protocol !== DIRECT_PROTOCOL) return false;
      Promise.resolve(handleMessage(message, sender))
        .then((response) => sendResponse(response))
        .catch((error) => sendResponse(directError(
          error?.code || "DIRECT_CONNECT_FAILED",
          error?.message || String(error || "Direct PatchWork connection failed."),
          error?.details
        )));
      return true;
    });
    return true;
  }

  return Object.freeze({ handleMessage, install });
}

export function chooseCurrentTarget(tabs = []) {
  const candidates = (Array.isArray(tabs) ? tabs : []).filter((tab) => tab?.projectId && (tab?.tabId || tab?.id));
  if (!candidates.length) return null;
  const sorted = [...candidates].sort((a, b) => {
    if (Boolean(a.active) !== Boolean(b.active)) return a.active ? -1 : 1;
    return Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0);
  });
  const tab = sorted[0];
  const tabId = String(tab.tabId || tab.id || "");
  return {
    projectId: compact(tab.projectId),
    tabId,
    laneId: compact(tab?.target?.laneId || tab.laneId) || `flow-tab-${tabId}`,
    title: compact(tab.title),
    windowId: Number.isFinite(Number(tab.windowId)) ? Number(tab.windowId) : null,
    url: compact(tab.url)
  };
}

export function senderOrigin(sender = {}) {
  const explicit = normalizeOrigin(sender.origin || "");
  if (explicit) return explicit;
  return normalizeOrigin(sender.url || sender.tab?.url || "");
}

export function isAllowedDirectBrowserOrigin(origin = "", remoteOrigins = DEFAULT_REMOTE_ORIGINS) {
  const normalized = normalizeOrigin(origin);
  if (!normalized) return false;
  if (LOOPBACK_ORIGIN_RE.test(normalized)) return true;
  const allowed = remoteOrigins instanceof Set ? remoteOrigins : new Set((remoteOrigins || []).map(normalizeOrigin));
  return allowed.has(normalized);
}

function isAllowedOrigin(origin, allowedRemoteOrigins) {
  return isAllowedDirectBrowserOrigin(origin, allowedRemoteOrigins);
}

async function extensionInstanceId(chromeApi, randomId) {
  const stored = await chromeApi.storage.local.get(DIRECT_INSTANCE_STORAGE_KEY).catch(() => ({}));
  const existing = compact(stored?.[DIRECT_INSTANCE_STORAGE_KEY]);
  if (existing) return existing;
  const created = randomId("extension-instance");
  await chromeApi.storage.local.set({ [DIRECT_INSTANCE_STORAGE_KEY]: created });
  return created;
}

function directError(code, message, details) {
  return {
    ok: false,
    protocol: DIRECT_PROTOCOL,
    version: DIRECT_VERSION,
    error: {
      code: compact(code) || "DIRECT_CONNECT_FAILED",
      message: compact(message) || "Direct PatchWork connection failed.",
      ...(details === undefined ? {} : { details })
    }
  };
}

function defaultRandomId(prefix = "direct") {
  const uuid = globalThis.crypto?.randomUUID?.();
  if (uuid) return `${prefix}-${uuid}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(16).slice(2)}`;
}

function normalizeOrigin(value = "") {
  try {
    const url = new URL(String(value || ""));
    return `${url.protocol}//${url.host}`.toLowerCase();
  } catch {
    return "";
  }
}

function objectValue(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function compact(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}
