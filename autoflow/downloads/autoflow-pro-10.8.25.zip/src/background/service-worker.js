import { MessageType, createMessage, isAutoFlowRebuildMessage } from "../core/contracts/messages.js";
import { createChromeStorageAdapter, createLicenseClient } from "../core/auth/license-client.js";
import { agentBridgeAccessFromAuthSummary, queueStartAccessFromAuthSummary, queueStartAccessFromServerAuthority, queueStartAccessNeedsFreshBackend, refreshQueueStartAccessBeforeBlock } from "../core/auth/queue-start-access.js";
import { promptUsageCountForTask, promptUsageIdempotencyKey, shouldRecordPromptUsageForTask } from "../core/auth/prompt-usage.js";
import { createFlowClient, extractMediaIds } from "../core/media/flow-client.js";
import { createPageFlowTransport } from "../core/media/page-flow-transport.js";
import { createTaskLedger, sanitizeTaskForDebugReport, TaskStatus } from "../core/queue/task-ledger.js";
import { createScheduler, detectFlowRendererCrashSnapshot, flowRendererCrashErrorCode } from "../core/queue/scheduler.js";
import { applySideEffectOverride, buildRecoveryReportFields, classifyRecoveryPolicy, isHardQuotaFailure, taskHasObservedOutputs } from "../core/queue/recovery-policy.js";
import { buildBrowserModeRecoveryPlan } from "../core/queue/recovery-actions.js";
import { createQueueExecutor, extractVideoStatusRows } from "../core/queue/executor.js";
import { buildContinuityRefPatch } from "../core/queue/continuity-chain.js";
import { activeVideoTaskBeforeComposerRetry, buildRetryModalTask, retryFailureContextPatch } from "../core/queue/video-retry-policy.js";
import { buildGalleryItemsFromTasks, buildPartialVideoCompletionPatch, canonicalGalleryItems, deriveTaskOutputLedger, filterGalleryItemsForProject, filterUsableGalleryItems, generatedOutputMediaIdsFromTasks, isDownloadResolutionVerified, planMediaDownloads, reconcileTasksWithDownloadResults, reconcileTasksWithGalleryItems, reconcileTasksWithProjectMediaFeed, referenceMediaIdsFromTasks } from "../core/gallery/media-ledger.js";
import {
  detectArtifactMediaKind,
  invalidCompletedDownloadReason,
  minValidDownloadBytes,
  resolveDownloadMediaKind,
  shouldRetryTinyVideoDownload
} from "../core/media/download-media-kind.js";
import { canRetryUpscaleFromFreshMedia, fallbackFilenameForResolution, isExplicitlyFailedMediaRow, isRetryableUpscaleFailure, resolutionUnavailableError } from "../core/gallery/download-recovery.js";
import { DIRECT_DOWNLOAD_CONCURRENCY, mapDownloadPlansWithConcurrency, UPSCALE_DOWNLOAD_CONCURRENCY } from "../core/gallery/download-concurrency.js";
import { buildMediaRedirectUrl, buildMediaThumbnailUrl } from "../core/contracts/api.js";
import { planAgentRunArtifacts } from "../core/agent/agent-run-artifacts.js";
import { applyAgentOwnedDownloadMetadata } from "../core/agent/agent-download-monitor.js";
import { reconcileAgentProject } from "../core/agent/agent-reconciler.js";
import { scopeAgentArtifactPlan } from "../core/agent/agent-artifact-scope.js";
import { hasStandingCreditLimit, isCaptainAuthorized } from "../core/agent/agent-credit-policy.js";
import { fleetGenHarvestBudget } from "../core/agent/fleet-gen-timing.js";
import {
  fleetGenDurationSecondsFromInput,
  fleetGenDurationSecondsFromValue,
  fleetGenInvalidDurationValue,
  fleetGenInvalidMediaType,
  fleetGenMediaTypeFromValue,
  fleetGenPerRowDurationPresent,
  fleetGenPromptRecordsFromInput,
  fleetGenSourceRoleError
} from "../core/agent/fleet-gen-request.js";
import { AGENT_REF_ATTACH_TEARDOWN_STEPS, normalizeAgentRefAttachError, planAgentRefAttachments, planAgentRefAttachTeardown, planAgentRefChipCleanup, verifyAgentRefAttachmentChipGrowth, verifyAgentRefAttachmentChips, verifyAgentRefAttachmentVisibleMediaChips } from "../core/agent/agent-ref-attachments.js";
import { base64FromDataUrl, getReferenceBlob, mimeTypeFromDataUrl } from "../core/storage/reference-blob-store.js";
import { buildAgentScreenContext, formatAgentScreenContextForBridge, summarizeAgentComposerProbeFrames } from "../core/agent/agent-screen-context.js";
import { applyAgentStatusProtocolToRun, parseAgentStatusProtocol } from "../core/agent/agent-status-protocol.js";
import { buildAgentCreditDecision } from "../core/agent/agent-supervision-policy.js";
import { validateAgentCapabilityContract } from "../core/agent/agent-capabilities.js";
import { extractCreditAmount, isFreeCreditText } from "../core/agent/agent-credit-text.js";
import { AGENT_COMPOSER_TARGET_UNRESOLVED, agentSubmitLockKey, evaluateAgentTarget, createAgentSubmitLock, agentPromptInserted, resolveAgentComposerTarget } from "../core/agent/agent-submit-guard.js";
import { classifyFlowPageConnectResult, selectSameWindowFlowTab } from "../core/agent/flow-tab-connect.js";
import { classifyAgentComposerPreflight, hashAgentManagedText, managedAgentProtocol, verifyManagedAgentProtocol } from "../core/agent/agent-run-preflight.js";
import { buildAgentNativeSettingsPlan, normalizeAgentNativeModelText, planAgentNativeSettingsMutations, verifyAgentNativeSettings } from "../core/agent/agent-native-settings.js";
import { buildAgentPendingToolContract, parseAgentSseTelemetry, validateAgentPendingToolContract } from "../core/agent/agent-tool-telemetry.js";
import { createFlowCreationAgentClient, resolveFlowCreationAgentCreditEstimate } from "../core/agent/flow-creation-agent-client.js";
import { createFlowChromeSession } from "../core/agent/flow-chrome-session.js";
import { fetchFlowAgentApiReference, planFlowAgentApiReferences } from "../core/agent/flow-agent-api-refs.js";
import { agentBatchFreshReconciliationComplete, createAgentBatchSupervisorState, nextAgentBatchAction, updateAgentBatchSupervisorState } from "../core/agent/agent-batch-supervisor.js";
import { createDebuggerEngine, releaseDebuggerSessions } from "./debugger-engine.js";
import { createNativeBridge, createNativeBridgeHandlers, createNativeBridgePortController, readAgentBridgeEnabled, SIDEPANEL_STATE_STORAGE_KEY } from "./native-bridge.js";
import { createWsBrokerBridgeController } from "./ws-broker-bridge.js";
import { createDirectBrowserBridgeController } from "./direct-browser-bridge.js";
import { buildOversizedResultSummary, guardMessagePayload, MAX_RUNTIME_MESSAGE_BYTES, MESSAGE_PAYLOAD_TOO_LARGE_CODE } from "../core/media/message-size-guard.js";
import { createPageCommandPoisonGuard } from "../core/media/page-command-poison-guard.js";
import { PRIVACY_CONSENT_KEY, privacyConsentAccepted, privacyConsentRequiredPayload, readPrivacyConsent } from "../core/privacy/consent.js";

let privacyConsentGranted = false;
let privacyConsentRevision = 0;
const initialPrivacyConsentPromise = readPrivacyConsent(chrome.storage.local)
  .then((consent) => {
    if (privacyConsentRevision === 0) privacyConsentGranted = consent.accepted === true;
    return consent;
  })
  .catch(() => ({ accepted: false }));

const runtimeState = {
  bridgeHealthy: false,
  queueRunning: false,
  queueRunToken: 0,
  activeTabId: null,
  projectId: "",
  pageUrl: "",
  pageTitle: "",
  authEnvironment: null,
  auth: null,
  authRefresh: null,
  lastGalleryItems: [],
  lastGalleryProjectId: "",
  events: []
};
const flowSessionRecoveryState = {
  runToken: 0,
  attempts: 0,
  active: false,
  lastTriggerError: "",
  lastFlowErrorCode: "",
  lastStatus: 0,
  lastTaskId: "",
  lastStartedAt: 0,
  recentSessionRejectionAt: 0
};
const flowRendererCrashRecoveryState = {
  runToken: 0,
  attempts: 0,
  active: false,
  lastTriggerError: "",
  lastTaskId: "",
  lastStartedAt: 0
};
const QUEUE_STORAGE_KEY = "autoflow-10767-rebuild-queue-ledger";
const RUNTIME_BINDING_STORAGE_KEY = "autoflow-1080-runtime-binding";
const DOM_DEBUGGER_TRACE_STORAGE_KEY = "autoflow-1081-dom-debugger-trace";
const DOWNLOAD_RESERVATION_TTL_MS = 10 * 60 * 1000;
const AGENT_PAIRING_APPROVAL_WINDOW_MS = 2 * 60 * 1000;
const AGENT_SUBMIT_IDEMPOTENCY_TTL_MS = 15 * 60 * 1000;
const EXPECTED_FLOW_BRIDGE_VERSION = "10.8.24-fleetgen-atomic-v3";
const EXPECTED_PAGE_HOOK_VERSION = "10.8.24-video-feed-reconcile-v27";
const FLOW_BRIDGE_SCRIPT_PATH = "src/content/page-bridge.js";
const FLOW_PAGE_HOOK_SCRIPT_PATH = "src/page/page-hook.js";
const FLEETGEN_PAGE_BRIDGE_SCRIPT_PATH = "src/page/fleetgen-bridge.js";
const REQUIRED_EXTENSION_BRIDGE_FILES = Object.freeze([
  FLOW_BRIDGE_SCRIPT_PATH,
  FLOW_PAGE_HOOK_SCRIPT_PATH,
  FLEETGEN_PAGE_BRIDGE_SCRIPT_PATH,
  "build-fingerprint.json"
]);
const DOM_DEBUGGER_TRANSPORT_ENABLED = true;
const FLOW_ORIGINS = ["https://labs.google", "https://labs.google.com"];
const FLOW_COOKIE_HOSTS = ["labs.google", ".labs.google", "labs.google.com", ".labs.google.com"];
const FLEETGEN_SHARED_TOOL_ID = "a70c9933-5c82-49ae-96d9-82db00fdb229";
const FLEETGEN_SHARED_TOOL_URL = `https://labs.google/fx/tools/flow/shared/tool/${FLEETGEN_SHARED_TOOL_ID}`;
const FLEETGEN_REQUIRED_METHODS = Object.freeze(["executeDirect", "launch", "setPrompts", "updateSettings", "getState", "stitchAll", "getStitchedResult"]);
const PRESERVED_FLOW_COOKIE_RE = /(^|_)(SID|HSID|SSID|APISID|SAPISID|LSID|OSID|ACCOUNT|LOGIN|AUTH|TOKEN|NID|AEC|SOCS)(_|$)/i;
const ledger = createTaskLedger();
const scheduler = createScheduler({ ledger, maxAttempts: 12 });
const downloadReservations = {
  artifacts: new Map(),
  targets: new Map()
};
const pendingNativeDownloadFilenames = [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const RECOVERABLE_GLOBAL_HEAL_ACTIONS = new Set(["cooldown_and_refresh", "reconnect_flow", "wait_for_capacity", "backoff", "recover_flow_session", "recover_flow_page"]);
const MAX_FLOW_SESSION_RECOVERY_ATTEMPTS = 3;
const MAX_FLOW_RENDERER_CRASH_RECOVERY_ATTEMPTS = 2;
const FLOW_SESSION_RECOVERY_RECENT_MS = 5 * 60 * 1000;
const FLOW_SESSION_RECOVERY_LEVELS = Object.freeze(["soft_reload", "cache_clear_reload", "service_worker_bypass_reload"]);
const FLOW_RENDERER_CRASH_RECOVERY_LEVELS = Object.freeze(["soft_reload", "cache_clear_reload"]);
const SESSION_REFRESH_ALARM_NAME = "af-session-refresh";
const AGENT_SUPERVISION_ALARM_NAME = "af-agent-supervision";
const AGENT_SUPERVISION_PERIOD_MINUTES = 1;
const SESSION_REFRESH_PERIOD_MINUTES = 45;
const SESSION_REFRESH_MIN_FRESH_MS = 15 * 60 * 1000;
const licenseClient = createLicenseClient({
  storage: createChromeStorageAdapter(),
  environmentProvider: () => runtimeState.authEnvironment || {
    userAgent: navigator.userAgent || "",
    screen: { width: 0, height: 0 }
  },
  openTab: async (url) => chrome.tabs.create({ url })
});
const agentBridgeHandlers = createNativeBridgeHandlers({
  approvePairing: approveAgentBridgePairing,
  getStatus: getAgentBridgeStatus,
  refreshWsBroker: refreshAgentWsBrokerFromBridge,
  listFlowTabs: listAgentBridgeFlowTabs,
  setLaneIndicator: setAgentBridgeLaneIndicator,
  connectThisFlowTab: connectThisFlowTabFromBridge,
  getAgentContext: getAgentScreenContextFromBridge,
  getAgentScreenshot: getAgentScreenshotFromBridge,
  getProjectMetadata: getAgentProjectMetadata,
  listProjectMedia: listAgentProjectMedia,
  planDownloads: planAgentBridgeDownloads,
  executeDownloads: executeDownloadsForAgent,
  generateFlowApi: generateFlowApiFromBridge,
  getFlowApiState: getFlowApiStateFromBridge,
  submitAgentPrompt: submitAgentPromptFromBridge,
  submitAgentRetry: submitAgentRetryFromBridge,
  attachAgentRefs: attachAgentRefsFromBridge,
  submitAgentComposerDraft: submitAgentComposerDraftFromBridge,
  confirmAgentCredits: confirmAgentCreditsFromBridge,
  executeFleetGenCommand: executeFleetGenCommandFromBridge,
  getFleetGenState: getFleetGenStateFromBridge,
  generateFleetGen: generateFleetGenFromBridge
});
const agentWsBrokerBridge = createNativeBridge({
  handlers: agentBridgeHandlers
});
const agentNativeBridge = createNativeBridge({
  handlers: agentBridgeHandlers
});
const agentNativeBridgeController = createNativeBridgePortController({
  bridge: agentNativeBridge,
  isEnabled: readLegacyNativeMessagingEnabled,
  onEvent: recordEvent
});
const agentWsBrokerBridgeController = createWsBrokerBridgeController({
  bridge: agentWsBrokerBridge,
  onEvent: recordEvent
});
const directBrowserBridgeController = createDirectBrowserBridgeController({
  chromeApi: chrome,
  sidepanelStateKey: SIDEPANEL_STATE_STORAGE_KEY,
  listFlowTabs: listAgentBridgeFlowTabs,
  isPrivacyConsentGranted: () => privacyConsentGranted
});
let directBrowserBridgeInstalled = false;
let privacyBoundRuntimeStarted = false;
let queueReady = Promise.resolve();

function recordEvent(event) {
  runtimeState.events.push({
    at: new Date().toISOString(),
    ...event
  });
  if (runtimeState.events.length > 500) runtimeState.events.shift();
}

async function startPrivacyBoundRuntime(reason = "privacy_consent") {
  if (!privacyConsentGranted || privacyBoundRuntimeStarted) return privacyBoundRuntimeStarted;
  privacyBoundRuntimeStarted = true;
  if (!directBrowserBridgeInstalled) {
    directBrowserBridgeController.install();
    directBrowserBridgeInstalled = true;
  }
  queueReady = restoreQueueFromStorage();
  scheduleSessionRefreshAlarm();
  restoreAgentSupervisionAlarm(reason).catch(() => null);
  refreshAuthSessionForRuntime(reason).catch((error) => {
    recordEvent({ type: "auth.refresh.privacy_runtime_error", reason, error: String(error?.message || error || "refresh_failed") });
  });
  agentWsBrokerBridgeController.start(reason).catch((error) => {
    recordEvent({ type: "agent_bridge.ws_broker.privacy_runtime_error", reason, error: String(error?.message || error || "ws_broker_start_failed") });
  });
  agentNativeBridgeController.start(reason).catch((error) => {
    recordEvent({ type: "agent_bridge.native_host.privacy_runtime_error", reason, error: String(error?.message || error || "native_bridge_start_failed") });
  });
  await queueReady;
  recordEvent({ type: "privacy.consent.runtime_started", reason });
  return true;
}

async function stopPrivacyBoundRuntime(reason = "privacy_consent_revoked") {
  privacyConsentGranted = false;
  privacyBoundRuntimeStarted = false;
  queueReady = Promise.resolve();
  runtimeState.queueRunToken = Number(runtimeState.queueRunToken || 0) + 1;
  runtimeState.queueRunning = false;
  await Promise.all([
    Promise.resolve(chrome.alarms?.clear?.(SESSION_REFRESH_ALARM_NAME)).catch(() => false),
    Promise.resolve(chrome.alarms?.clear?.(AGENT_SUPERVISION_ALARM_NAME)).catch(() => false)
  ]);
  agentWsBrokerBridgeController.stop(reason);
  agentNativeBridgeController.stop(reason);
  recordEvent({ type: "privacy.consent.runtime_stopped", reason });
}

async function readLegacyNativeMessagingEnabled() {
  if (!await readAgentBridgeEnabled(chrome)) return false;
  const stored = await chrome.storage.local.get([
    "autoflow-native-messaging-legacy-enabled",
    "autoflow-agent-bridge-settings"
  ]).catch(() => ({}));
  const settings = stored?.["autoflow-agent-bridge-settings"] || {};
  return stored?.["autoflow-native-messaging-legacy-enabled"] === true
    || settings.nativeMessagingLegacyEnabled === true;
}

function recordDebuggerTrace(task = {}, stage = "", detail = {}) {
  const at = new Date().toISOString();
  const entry = {
    at,
    type: "queue.dom.debugger.trace",
    taskId: task?.id || "",
    stage,
    mode: task?.mode || "",
    prompt: String(task?.prompt || "").slice(0, 120),
    repeatCount: Number(task?.repeatCount || 1) || 1,
    videoLength: String(task?.videoLength || task?.videoDurationSeconds || ""),
    model: task?.model || "",
    aspectRatio: task?.aspectRatio || "",
    ...detail
  };
  recordEvent(entry);
  chrome.storage?.local?.get?.(DOM_DEBUGGER_TRACE_STORAGE_KEY).then((stored = {}) => {
    const prior = Array.isArray(stored[DOM_DEBUGGER_TRACE_STORAGE_KEY]) ? stored[DOM_DEBUGGER_TRACE_STORAGE_KEY] : [];
    return chrome.storage.local.set({
      [DOM_DEBUGGER_TRACE_STORAGE_KEY]: prior.concat(entry).slice(-80)
    });
  }).catch(() => {});
  if (stage === "front_submit_transition_accepted_without_media_ids" && String(task?.mode || "") === "text-to-image" && task?.id) {
    const latest = ledger.getTask(task.id);
    if (latest && latest.status !== TaskStatus.complete && latest.status !== TaskStatus.failed) {
      const imageTask = ledger.updateTask(task.id, {
        status: TaskStatus.generating,
        submittedAt: latest.submittedAt || at,
        expectedImages: Number(task.repeatCount || latest.repeatCount || latest.expectedImages || 1) || 1,
        lastError: "",
        failureClass: "",
        healAction: ""
      });
      recordEvent({
        type: "queue.task.state",
        taskId: task.id,
        reason: "front_submit_observed",
        status: imageTask?.status || TaskStatus.generating,
        attempts: Number(imageTask?.attempts || 0),
        mediaIds: Array.isArray(imageTask?.mediaIds) ? imageTask.mediaIds : [],
        foundImages: Number(imageTask?.foundImages || 0),
        expectedImages: Number(imageTask?.expectedImages || 0),
        foundVideos: Number(imageTask?.foundVideos || 0),
        expectedVideos: Number(imageTask?.expectedVideos || 0)
      });
      persistQueueState().catch(() => {});
    }
  }
}

function compactString(value = "") {
  return String(value || "").trim();
}

function diagnosticString(value = "") {
  if (value === null || value === undefined || value === "") return "";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value).trim();
  if (value instanceof Error) return String(value.message || value).trim();
  const parts = [];
  const collect = (entry) => {
    if (entry === null || entry === undefined || entry === "") return;
    if (typeof entry === "string" || typeof entry === "number" || typeof entry === "boolean") {
      parts.push(String(entry).trim());
      return;
    }
    if (entry instanceof Error) {
      parts.push(String(entry.message || entry).trim());
      return;
    }
    if (Array.isArray(entry)) {
      entry.forEach(collect);
      return;
    }
    if (typeof entry === "object") {
      [
        entry.error,
        entry.code,
        entry.reason,
        entry.status,
        entry.statusText,
        entry.message,
        entry.details
      ].forEach(collect);
    }
  };
  collect(value);
  const text = [...new Set(parts.filter(Boolean))].join(" ");
  if (text) return text;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value || "").trim();
  }
}

function runtimeBindingPayload(tab = {}, extra = {}) {
  const tabUrl = compactString(tab.url || "");
  const tabIsFlow = !tabUrl || isFlowToolUrl(tabUrl);
  const tabId = tabIsFlow ? (tab?.id || null) : null;
  const hintedTabId = Number(extra.tabId || extra.activeTabId || 0) || null;
  const activeTabId = tabId || hintedTabId || null;
  const url = compactString((tabIsFlow ? tabUrl : "") || extra.href || extra.url || tabUrl);
  const projectId = compactString(extra.projectId || projectIdFromUrl(url));
  return {
    activeTabId,
    projectId,
    pageUrl: url,
    pageTitle: compactString((activeTabId ? tab?.title : "") || extra.title || ""),
    connected: Boolean(activeTabId && projectId),
    error: projectId ? null : (tabId || hintedTabId || runtimeState.activeTabId ? "missing_project_id" : "flow_tab_not_found"),
    lastSyncAt: new Date().toISOString()
  };
}

async function persistRuntimeBinding() {
  try {
    await chrome.storage.local.set({
      [RUNTIME_BINDING_STORAGE_KEY]: {
        activeTabId: runtimeState.activeTabId || null,
        projectId: runtimeState.projectId || "",
        pageUrl: runtimeState.pageUrl || "",
        pageTitle: runtimeState.pageTitle || "",
        updatedAt: new Date().toISOString()
      }
    });
  } catch (_error) {}
}

function promoteFlowTabBinding(tab = {}, extra = {}, reason = "unknown") {
  const binding = runtimeBindingPayload(tab, extra);
  if (!binding.activeTabId || !isFlowToolUrl(binding.pageUrl)) return null;
  const changed = runtimeState.activeTabId !== binding.activeTabId
    || runtimeState.projectId !== binding.projectId
    || runtimeState.pageUrl !== binding.pageUrl;
  runtimeState.activeTabId = binding.activeTabId;
  runtimeState.projectId = binding.projectId;
  runtimeState.pageUrl = binding.pageUrl;
  runtimeState.pageTitle = binding.pageTitle;
  if (binding.projectId) runtimeState.lastGalleryProjectId = binding.projectId;
  if (changed) {
    recordEvent({
      type: "runtime.flow_tab.promoted",
      tabId: binding.activeTabId,
      projectId: binding.projectId,
      reason
    });
    persistRuntimeBinding().catch(() => null);
  }
  return binding;
}

function isMaintenanceAction(action = "") {
  return [
    "clear_flow_cache",
    "clearFlowCache",
    "clear_flow_cookies",
    "clearFlowCookies",
    "clear_all_flow_data",
    "clearAllFlowData",
    "reload_flow_tab",
    "reloadFlowTab"
  ].includes(String(action || ""));
}

async function reloadFlowTab(tabId = 0) {
  const tab = await findFlowTab(Number(tabId || 0) || undefined).catch(() => null);
  if (!tab?.id || !chrome.tabs?.reload) return { ok: false, error: "flow_tab_not_found" };
  await chrome.tabs.reload(tab.id);
  return { ok: true, tabId: tab.id };
}

async function reloadFlowTabAndWait(tabId = 0, projectId = "", reason = "") {
  const reload = await reloadFlowTab(tabId);
  const wait = reload?.ok && projectId
    ? await waitForFlowProjectRoot(reload.tabId, projectId).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "flow_project_root_navigation_timeout")
    }))
    : null;
  recordEvent({
    type: "maintenance.reload_flow_tab",
    tabId: reload?.tabId || tabId || null,
    projectId: String(projectId || ""),
    reason: String(reason || ""),
    ok: reload?.ok !== false && (!wait || wait.ok !== false),
    reloadOk: reload?.ok !== false,
    waitOk: wait ? wait.ok !== false : null,
    error: reload?.ok === false ? reload.error || "tab_reload_failed" : wait?.error || ""
  });
  return {
    ok: reload?.ok !== false && (!wait || wait.ok !== false),
    action: "reload_flow_tab",
    source: "background",
    reason: String(reason || ""),
    tabReload: reload,
    wait
  };
}

async function clearFlowCacheInBackground() {
  const result = {
    ok: true,
    action: "clear_flow_cache",
    source: "background",
    origins: FLOW_ORIGINS,
    browsingData: false,
    pageBridge: null
  };
  if (chrome.browsingData?.remove) {
    await chrome.browsingData.remove(
      { origins: FLOW_ORIGINS },
      {
        appcache: true,
        cache: true,
        cacheStorage: true,
        fileSystems: true,
        indexedDB: true,
        localStorage: true,
        serviceWorkers: true,
        webSQL: true
      }
    );
    result.browsingData = true;
  } else {
    result.browsingData = false;
    result.warning = "browsingData_unavailable";
  }
  try {
    const tab = await findFlowTab();
    if (tab?.id) {
      result.pageBridge = await sendPageCommand({ action: "clear_flow_cache", timeoutMs: 15000 }, tab.id);
      await sleep(300);
      result.tabReload = await reloadFlowTab(tab.id);
    }
  } catch (error) {
    result.pageBridge = { ok: false, error: String(error?.message || error || "page_bridge_failed") };
  }
  recordEvent({ type: "maintenance.clear_flow_cache", browsingData: result.browsingData, pageBridgeOk: result.pageBridge?.ok !== false, tabReloaded: result.tabReload?.ok === true });
  return result;
}

async function clearFlowCookiesInBackground() {
  const cookies = [];
  for (const domain of FLOW_COOKIE_HOSTS) {
    const matches = await chrome.cookies.getAll({ domain }).catch(() => []);
    cookies.push(...matches);
  }
  const seen = new Set();
  let deleted = 0;
  let preserved = 0;
  for (const cookie of cookies) {
    const key = `${cookie.domain}|${cookie.path}|${cookie.name}|${cookie.storeId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (PRESERVED_FLOW_COOKIE_RE.test(cookie.name)) {
      preserved += 1;
      continue;
    }
    const host = String(cookie.domain || "").replace(/^\./, "");
    const url = `${cookie.secure ? "https" : "http"}://${host}${cookie.path || "/"}`;
    await chrome.cookies.remove({ url, name: cookie.name, storeId: cookie.storeId }).catch(() => null);
    deleted += 1;
  }
  const result = {
    ok: true,
    action: "clear_flow_cookies",
    source: "background",
    deleted,
    preserved,
    scanned: seen.size,
    hosts: FLOW_COOKIE_HOSTS
  };
  result.tabReload = await reloadFlowTab().catch((error) => ({ ok: false, error: String(error?.message || error || "tab_reload_failed") }));
  recordEvent({ type: "maintenance.clear_flow_cookies", deleted, preserved, scanned: seen.size, tabReloaded: result.tabReload?.ok === true });
  return result;
}

async function clearAllFlowDataInBackground() {
  const result = {
    ok: true,
    action: "clear_all_flow_data",
    source: "background",
    origins: FLOW_ORIGINS,
    browsingData: false,
    deleted: 0,
    scanned: 0
  };
  if (chrome.browsingData?.remove) {
    await chrome.browsingData.remove(
      { origins: FLOW_ORIGINS },
      {
        appcache: true,
        cache: true,
        cacheStorage: true,
        cookies: true,
        fileSystems: true,
        indexedDB: true,
        localStorage: true,
        serviceWorkers: true,
        webSQL: true
      }
    );
    result.browsingData = true;
  }
  const seen = new Set();
  for (const domain of FLOW_COOKIE_HOSTS) {
    const matches = await chrome.cookies.getAll({ domain }).catch(() => []);
    for (const cookie of matches) {
      const key = `${cookie.domain}|${cookie.path}|${cookie.name}|${cookie.storeId}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const host = String(cookie.domain || "").replace(/^\./, "");
      const url = `${cookie.secure ? "https" : "http"}://${host}${cookie.path || "/"}`;
      await chrome.cookies.remove({ url, name: cookie.name, storeId: cookie.storeId }).catch(() => null);
      result.deleted += 1;
    }
  }
  result.scanned = seen.size;
  result.tabReload = await reloadFlowTab().catch((error) => ({ ok: false, error: String(error?.message || error || "tab_reload_failed") }));
  recordEvent({ type: "maintenance.clear_all_flow_data", browsingData: result.browsingData, deleted: result.deleted, scanned: result.scanned, tabReloaded: result.tabReload?.ok === true });
  return result;
}

async function runBackgroundMaintenanceAction(action = "", payload = {}) {
  if (action === "reload_flow_tab" || action === "reloadFlowTab") {
    return reloadFlowTabAndWait(
      Number(payload?.tabId || runtimeState.activeTabId || 0) || 0,
      payload?.projectId || runtimeState.projectId || "",
      payload?.reason || ""
    );
  }
  if (action === "clear_flow_cache" || action === "clearFlowCache") return clearFlowCacheInBackground();
  if (action === "clear_flow_cookies" || action === "clearFlowCookies") return clearFlowCookiesInBackground();
  if (action === "clear_all_flow_data" || action === "clearAllFlowData") return clearAllFlowDataInBackground();
  return { ok: false, action, error: "unknown_maintenance_action" };
}

function scheduleSessionRefreshAlarm() {
  try {
    chrome.alarms?.create?.(SESSION_REFRESH_ALARM_NAME, {
      delayInMinutes: 1,
      periodInMinutes: SESSION_REFRESH_PERIOD_MINUTES
    });
    recordEvent({
      type: "auth.refresh.alarm_scheduled",
      alarm: SESSION_REFRESH_ALARM_NAME,
      periodMinutes: SESSION_REFRESH_PERIOD_MINUTES
    });
  } catch (error) {
    recordEvent({
      type: "auth.refresh.alarm_schedule_error",
      error: String(error?.message || error || "alarm_schedule_failed")
    });
  }
}

async function refreshAuthSessionForRuntime(reason = "service_worker") {
  const result = await licenseClient.resolveAccessToken({
    minFreshMs: SESSION_REFRESH_MIN_FRESH_MS,
    reason
  });
  runtimeState.authRefresh = result.authRefresh || licenseClient.getAuthRefreshDiagnostics?.();
  recordEvent({
    type: "auth.refresh.result",
    reason,
    authState: result.authState || "",
    refreshAttempted: result.refreshAttempted === true,
    refreshSucceeded: result.refreshSucceeded === true,
    refreshErrorClass: result.refreshErrorClass || "",
    refreshResult: result.refreshResult || "",
    expiresInMs: Number(result.expiresInMs || 0)
  });
  if (result.token || result.refreshErrorClass === "auth_rejected") {
    await updateAuthState(null, { allowNetwork: false }).catch((error) => {
      recordEvent({
        type: "auth.refresh.auth_state_error",
        reason,
        error: String(error?.message || error || "auth_state_failed")
      });
      return null;
    });
  }
  return result;
}

let agentSupervisionInFlight = null;

function agentRunNeedsBackgroundSupervision(run = {}) {
  const status = compactString(run.status).toLowerCase();
  if (!run.id || !run.projectId || !run.tabId) return false;
  if (!hasAgentManifestRows(run.expectedManifest || run.manifest || run.matrix?.manifest || {})) return false;
  return ![
    "batch_plan_exported",
    "downloaded",
    "landed",
    "complete",
    "completed",
    "submit_error",
    "download_failed",
    "setup_blocked",
    "pre_submit_blocked"
  ].includes(status);
}

async function storedAgentRunForSupervision() {
  const stored = await chrome.storage.local.get(SIDEPANEL_STATE_STORAGE_KEY).catch(() => ({}));
  const sidepanelState = stored?.[SIDEPANEL_STATE_STORAGE_KEY];
  const run = sidepanelState?.control?.agentRun;
  return run && typeof run === "object" && !Array.isArray(run) ? run : {};
}

function scheduleAgentSupervisionAlarm(reason = "run_active") {
  try {
    chrome.alarms?.create?.(AGENT_SUPERVISION_ALARM_NAME, {
      delayInMinutes: 0.1,
      periodInMinutes: AGENT_SUPERVISION_PERIOD_MINUTES
    });
    recordEvent({
      type: "agent_bridge.supervision.alarm_scheduled",
      reason,
      periodMinutes: AGENT_SUPERVISION_PERIOD_MINUTES
    });
  } catch (error) {
    recordEvent({
      type: "agent_bridge.supervision.alarm_schedule_error",
      reason,
      error: String(error?.message || error || "agent_supervision_alarm_failed")
    });
  }
}

async function stopAgentSupervisionAlarm(reason = "run_inactive") {
  await chrome.alarms?.clear?.(AGENT_SUPERVISION_ALARM_NAME).catch(() => false);
  recordEvent({ type: "agent_bridge.supervision.alarm_stopped", reason });
}

async function agentRunTargetAvailableForSupervision(run = {}) {
  const tab = await chrome.tabs.get(Number(run.tabId)).catch(() => null);
  if (!tab) return false;
  return projectIdFromUrl(tab.url || "") === compactString(run.projectId);
}

async function restoreAgentSupervisionAlarm(reason = "restore") {
  const run = await storedAgentRunForSupervision();
  if (!agentRunNeedsBackgroundSupervision(run)) {
    await stopAgentSupervisionAlarm(`${reason}:no_active_run`);
    return false;
  }
  if (!await agentRunTargetAvailableForSupervision(run)) {
    await stopAgentSupervisionAlarm(`${reason}:target_unavailable`);
    return false;
  }
  scheduleAgentSupervisionAlarm(reason);
  return true;
}

async function runAgentSupervisionCycle(reason = "alarm") {
  if (agentSupervisionInFlight) return agentSupervisionInFlight;
  agentSupervisionInFlight = (async () => {
    const run = await storedAgentRunForSupervision();
    if (!agentRunNeedsBackgroundSupervision(run)) {
      await stopAgentSupervisionAlarm(`${reason}:terminal`);
      return { ok: true, supervised: false, reason: "terminal_or_inactive" };
    }
    const activeProjectId = compactString(runtimeState.projectId);
    if (activeProjectId && compactString(run.projectId) !== activeProjectId) {
      await stopAgentSupervisionAlarm(`${reason}:project_mismatch`);
      return { ok: true, supervised: false, reason: "project_mismatch" };
    }
    if (!await agentRunTargetAvailableForSupervision(run)) {
      await stopAgentSupervisionAlarm(`${reason}:target_unavailable`);
      return { ok: true, supervised: false, reason: "target_unavailable" };
    }
    const payload = {
      project: "current",
      runId: compactString(run.id),
      projectId: compactString(run.projectId),
      tabId: run.tabId,
      expectedManifest: run.expectedManifest || run.manifest || run.matrix?.manifest || {},
      runStartedAt: compactString(run.startedAt),
      includeRaw: false,
      reason: `service_worker_${reason}`
    };
    const metadata = await getAgentProjectMetadata(payload).catch((error) => ({ ok: false, error }));
    const context = await getAgentScreenContextFromBridge(payload).catch((error) => ({ ok: false, error }));
    const progress = metadata?.reconciliation || {};
    const nextRun = await storedAgentRunForSupervision();
    if (!agentRunNeedsBackgroundSupervision(nextRun)) await stopAgentSupervisionAlarm(`${reason}:completed`);
    recordEvent({
      type: "agent_bridge.supervision.cycle",
      reason,
      runId: payload.runId,
      projectId: payload.projectId,
      metadataOk: metadata?.ok !== false,
      contextOk: context?.ok !== false,
      status: compactString(nextRun.status)
    });
    return { ok: true, supervised: true, metadata, context, progress };
  })();
  try {
    return await agentSupervisionInFlight;
  } finally {
    agentSupervisionInFlight = null;
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  if (privacyConsentGranted) startPrivacyBoundRuntime("installed").catch(() => null);
});

chrome.runtime.onStartup?.addListener?.(() => {
  if (privacyConsentGranted) startPrivacyBoundRuntime("startup").catch(() => null);
});

chrome.alarms?.onAlarm?.addListener?.((alarm) => {
  if (!privacyConsentGranted) return;
  if (alarm?.name === SESSION_REFRESH_ALARM_NAME) {
    refreshAuthSessionForRuntime("alarm").catch((error) => {
      recordEvent({ type: "auth.refresh.alarm_error", error: String(error?.message || error || "refresh_failed") });
    });
    return;
  }
  if (alarm?.name === AGENT_SUPERVISION_ALARM_NAME) {
    runAgentSupervisionCycle("alarm").catch((error) => {
      recordEvent({ type: "agent_bridge.supervision.alarm_error", error: String(error?.message || error || "agent_supervision_failed") });
    });
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes?.[PRIVACY_CONSENT_KEY]) return;
  privacyConsentRevision += 1;
  const accepted = privacyConsentAccepted(changes[PRIVACY_CONSENT_KEY].newValue);
  if (accepted) {
    privacyConsentGranted = true;
    startPrivacyBoundRuntime("privacy_consent_accepted").catch((error) => {
      recordEvent({ type: "privacy.consent.runtime_start_error", error: String(error?.message || error || "privacy_runtime_start_failed") });
    });
    return;
  }
  stopPrivacyBoundRuntime("privacy_consent_revoked").catch(() => null);
});

initialPrivacyConsentPromise.then(() => {
  if (privacyConsentGranted) return startPrivacyBoundRuntime("service_worker_startup");
  return false;
}).catch(() => null);

chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
  const match = takePendingNativeDownloadFilename(downloadItem);
  if (!match?.filename) return;
  suggest({
    filename: match.filename,
    conflictAction: "uniquify"
  });
  recordEvent({
    type: "media.download.filename_suggest",
    downloadId: downloadItem?.id || null,
    mediaId: match.mediaId || "",
    fileName: match.filename,
    url: downloadItem?.url || "",
    finalUrl: downloadItem?.finalUrl || ""
  });
});

function queueState() {
  repairQueueDownloadStateFromEvents("queue_state");
  const tasks = ledger.listTasks();
  const taskLedgerSnapshot = typeof ledger.debugSnapshot === "function"
    ? ledger.debugSnapshot()
    : tasks.map((task) => sanitizeTaskForDebugReport(task));
  return {
    tasks,
    taskLedgerSnapshot,
    events: runtimeState.events.slice(-200),
    generatedMediaIds: [...new Set(taskLedgerSnapshot
      .flatMap((task) => Array.isArray(task.generatedMediaIds) ? task.generatedMediaIds : [])
      .map((id) => String(id || "").trim())
      .filter(Boolean))],
    authRefresh: runtimeState.authRefresh || licenseClient.getAuthRefreshDiagnostics?.() || null,
    hasOpenTasks: ledger.hasOpenTasks()
  };
}

async function restoreQueueFromStorage() {
  try {
    const stored = await chrome.storage.local.get(QUEUE_STORAGE_KEY);
    const snapshot = stored?.[QUEUE_STORAGE_KEY];
    const tasks = Array.isArray(snapshot?.tasks) ? snapshot.tasks : [];
    ledger.replaceTasks(tasks.map((task) => {
      const restoredStatus = restoreTaskStatus(task);
      const status = restoredStatus || task.status;
      return { ...task, status };
    }));
    recordEvent({ type: "queue.restore", count: tasks.length });
  } catch (error) {
    recordEvent({ type: "queue.restore.error", error: String(error?.message || error || "restore_failed") });
  }
}

function restoreTaskStatus(task = {}) {
  const status = String(task.status || "").toLowerCase();
  if (!["submitting", "generating", "downloading"].includes(status)) return status || TaskStatus.pending;
  const kind = taskMediaKind(task);
  const hasGeneratedIds = [
    ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []),
    ...(Array.isArray(task.outputs) ? task.outputs.map((output) => output?.mediaId) : []),
    ...(Array.isArray(task.mediaIds) ? task.mediaIds : [])
  ].map((id) => String(id || "").trim()).filter(Boolean).length > 0;
  if (kind === "images" && status === "generating" && hasGeneratedIds) return TaskStatus.generating;
  if (kind === "images" && status === "downloading" && hasGeneratedIds) return TaskStatus.complete;
  return TaskStatus.pending;
}

async function persistQueueState() {
  try {
    repairQueueDownloadStateFromEvents("persist_queue_state");
    await chrome.storage.local.set({
      [QUEUE_STORAGE_KEY]: {
        version: 1,
        updatedAt: new Date().toISOString(),
        tasks: ledger.snapshot()
      }
    });
  } catch (error) {
    recordEvent({ type: "queue.persist.error", error: String(error?.message || error || "persist_failed") });
  }
}

function projectIdFromUrl(url = "") {
  return String(url || "").match(/\/fx\/(?:[^/?#]+\/)?tools\/flow\/project\/([0-9a-f-]{36})/i)?.[1] || "";
}

function isFlowToolUrl(url = "") {
  try {
    const parsed = new URL(String(url || ""));
    return /(^|\.)labs\.google(?:\.com)?$/i.test(parsed.hostname)
      && /^\/fx\/(?:[^/?#]+\/)?tools\/flow(?:\/|$)/i.test(parsed.pathname);
  } catch {
    return /https:\/\/labs\.google(?:\.com)?\/fx\/(?:[^/?#]+\/)?tools\/flow(?:\/|$|\?)/i.test(String(url || ""));
  }
}

function projectRootUrlFromFlowUrl(url = "", projectId = "") {
  const id = String(projectId || projectIdFromUrl(url)).trim();
  if (!id) return "";
  const origin = String(url || "").startsWith("https://labs.google.com/")
    ? "https://labs.google.com"
    : "https://labs.google";
  const localeMatch = String(url || "").match(/\/fx\/([^/?#]+)\/tools\/flow/i);
  const localePath = localeMatch ? `${localeMatch[1]}/` : "";
  return `${origin}/fx/${localePath}tools/flow/project/${id}`;
}

function taskPrefersDom(task = {}) {
  const raw = String(task.submitPathPreference || task.submitPath || "").trim();
  return raw === "dom_first" || raw === "dom_fallback";
}

async function waitForFlowProjectRoot(tabId, projectId = "") {
  const expectedId = String(projectId || "").trim();
  for (let remain = 12000; remain > 0; remain -= 300) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const url = String(tab?.url || "");
    if (
      projectIdFromUrl(url) === expectedId &&
      !/\/edit\//i.test(url)
    ) {
      return { ok: true, tabId, url };
    }
    await sleep(300);
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  return {
    ok: false,
    tabId,
    url: String(tab?.url || ""),
    error: "flow_project_root_navigation_timeout"
  };
}

function galleryState(extraItems = [], source = "queue-ledger", projectId = "") {
  const tasks = ledger.listTasks();
  const referenceMediaIds = referenceMediaIdsFromTasks(tasks);
  const generatedOutputMediaIds = generatedOutputMediaIdsFromTasks(tasks);
  const scopedItems = filterGalleryItemsForProject([
    ...buildGalleryItemsFromTasks(tasks),
    ...(extraItems || [])
  ], projectId);
  const items = canonicalGalleryItems(scopedItems, { projectId, referenceMediaIds, generatedOutputMediaIds });
  return {
    items,
    meta: {
      source,
      fetchedAt: new Date().toISOString(),
      projectId: String(projectId || "")
    }
  };
}

function mergeGalleryItems(previousItems = [], nextItems = [], options = {}) {
  const seen = new Set();
  const merged = [];
  for (const item of filterUsableGalleryItems([...(nextItems || []), ...(previousItems || [])], {
    referenceMediaIds: options.referenceMediaIds || [],
    generatedOutputMediaIds: options.generatedOutputMediaIds || []
  })) {
    const key = String(item?.id || `${item?.kind || ""}:${item?.mediaId || ""}:${item?.mediaUrl || ""}`);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    merged.push(item);
  }
  return merged;
}

function reconcileQueueWithGalleryItems(items = []) {
  const patches = reconcileTasksWithGalleryItems(ledger.listTasks(), items);
  for (const entry of patches) {
    ledger.updateTask(entry.taskId, entry.patch);
    recordEvent({
      type: "queue.gallery_reconcile",
      taskId: entry.taskId,
      matchedCount: entry.matchedCount,
      expectedCount: entry.expectedCount,
      status: entry.patch.status || ""
    });
  }
  return patches;
}

function reconcileQueueWithProjectMediaFeed(rows = [], reason = "project_feed") {
  const patches = reconcileTasksWithProjectMediaFeed(ledger.listTasks(), rows);
  for (const entry of patches) {
    ledger.updateTask(entry.taskId, entry.patch);
    recordEvent({
      type: "queue.project_feed_reconcile",
      reason,
      taskId: entry.taskId,
      matchedCount: entry.matchedCount,
      failedCount: entry.failedCount,
      expectedCount: entry.expectedCount,
      status: entry.patch.status || ""
    });
  }
  return patches;
}

function hasOpenImageTasks() {
  return ledger.listTasks().some((task) => {
    if (!task?.id || taskMediaKind(task) !== "images") return false;
    return !["complete", "done", "failed", "blocked"].includes(String(task.status || "").toLowerCase());
  });
}

function taskMediaKind(task = {}) {
  const mode = String(task.mode || "").trim();
  if (mode === "text-to-image") return "images";
  if (["text-to-video", "image-to-video", "start-end-image-to-video", "ingredients-to-video", "video-to-video"].includes(mode)) return "videos";
  return "";
}

function isTaskActive(task = {}) {
  return ["submitting", "generating", "downloading"].includes(String(task.status || "").toLowerCase());
}

function hasActiveTasks() {
  return ledger.listTasks().some((task) => isTaskActive(task));
}

function normalizedPromptText(value = "") {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function normalizePageStatusRows(rows = []) {
  return (Array.isArray(rows) ? rows : []).map((row, index) => {
    const rawStatus = String(row?.rawStatus || row?.status || "").trim();
    const normalizedStatus = String(row?.status || "").trim().toLowerCase();
    const status = ["complete", "failed", "pending"].includes(normalizedStatus)
      ? normalizedStatus
      : /success|complete/i.test(rawStatus)
        ? "complete"
        : /fail|reject|cancel/i.test(rawStatus)
          ? "failed"
          : /pending|running|processing/i.test(rawStatus)
            ? "pending"
            : "unknown";
    return {
      id: compactString(row?.id),
      workflowId: compactString(row?.workflowId),
      mediaGenerationId: compactString(row?.mediaGenerationId || row?.workflowId),
      rawStatus,
      status,
      failureText: compactString(row?.failureText || row?.failureReason || row?.error || row?.message),
      model: compactString(row?.model),
      aspectRatio: compactString(row?.aspectRatio),
      mediaUrl: compactString(row?.mediaUrl),
      thumbnailUrl: compactString(row?.thumbnailUrl),
      mediaIndex: Number.isFinite(Number(row?.mediaIndex)) ? Number(row.mediaIndex) : index,
      source: "flow_status_feed"
    };
  }).filter((row) => row.id || row.workflowId || row.rawStatus);
}

function failureTextForStatusRows(rows = [], fallback = "MEDIA_GENERATION_STATUS_FAILED") {
  const parts = (Array.isArray(rows) ? rows : []).flatMap((row) => [
    row?.failureText,
    row?.failureReason,
    row?.error,
    row?.message,
    row?.rawStatus
  ]).map(compactString).filter(Boolean);
  return [...new Set(parts)].join(" ") || fallback;
}

function failedOutputMediaIdsFromRows(rows = [], fallbackIds = []) {
  return [...new Set([
    ...(Array.isArray(rows) ? rows : []).flatMap((row) => [row?.id, row?.workflowId]),
    ...(Array.isArray(fallbackIds) ? fallbackIds : [])
  ].map(compactString).filter(Boolean))];
}

function retryGenerationFailurePatch(rows = [], mediaIds = [], task = {}, reason = "") {
  const retryContext = retryFailureContextPatch(
    task,
    reason || failureTextForStatusRows(rows, "MEDIA_GENERATION_STATUS_FAILED")
  );
  return {
    ...retryContext,
    status: TaskStatus.pending,
    mediaIds: [],
    outputMediaIds: [],
    outputs: [],
    statusRows: [],
    foundVideos: 0,
    videoDownloadReadyMediaIds: [],
    failedOutputCount: 0,
    failedOutputMediaIds: [],
    partialFailure: false,
    submittedAt: "",
    flowStatusFeedAt: "",
    generationFailureNeedsFlowReload: true,
    generationFailureRetryAt: new Date().toISOString(),
    previousFailedOutputMediaIds: failedOutputMediaIdsFromRows(rows, mediaIds)
  };
}

function chooseVideoTaskForFlowEvent(event = {}) {
  const endpointKind = compactString(event.endpointKind);
  const eventProjectId = compactString(event.projectId);
  const eventPrompts = (Array.isArray(event.prompts) ? event.prompts : [])
    .map(normalizedPromptText)
    .filter(Boolean);
  const promptSet = new Set(eventPrompts);
  const promptMatchesTask = (task = {}) => {
    const taskPrompt = normalizedPromptText(task.prompt);
    if (!taskPrompt || !eventPrompts.length) return false;
    return eventPrompts.some((prompt) => prompt === taskPrompt || prompt.includes(taskPrompt) || taskPrompt.includes(prompt));
  };
  const statusRows = normalizePageStatusRows(event.statusRows);
  const eventIds = new Set([
    ...(Array.isArray(event.mediaIds) ? event.mediaIds : []),
    ...statusRows.flatMap((row) => [row.id, row.workflowId, row.mediaGenerationId])
  ].map(compactString).filter(Boolean));
  const candidates = ledger.listTasks()
    .filter((task) => taskMediaKind(task) === "videos")
    .filter((task) => {
      const status = String(task.status || "").toLowerCase();
      if (["submitting", "submitted", "generating", "downloading"].includes(status)) return true;
      if (status !== "complete") return false;
      const downloaded = new Set((task.downloadedMediaIds || []).map(compactString).filter(Boolean));
      const skipped = new Set((task.skippedDownloadMediaIds || []).map(compactString).filter(Boolean));
      return generatedDownloadIdsForTask(task).some((id) => id && !downloaded.has(id) && !skipped.has(id));
    })
    .filter((task) => !eventProjectId || !task.projectId || String(task.projectId) === eventProjectId);
  if (!candidates.length) return null;
  const activeCandidates = candidates.filter((task) => ["submitting", "submitted", "generating"].includes(String(task.status || "").toLowerCase()));
  const activePromptMatch = pickBestVideoFlowEventCandidate(activeCandidates.filter(promptMatchesTask))
    || pickBestVideoFlowEventCandidate(activeCandidates.filter((task) => promptSet.has(normalizedPromptText(task.prompt))));
  if (activePromptMatch) return activePromptMatch;
  if (endpointKind === "video" && activeCandidates.length === 1) return activeCandidates[0];
  if (endpointKind === "video_status" && activeCandidates.length === 1) {
    const candidate = activeCandidates[0];
    const expected = Math.max(1, Number(candidate.expectedVideos || candidate.repeatCount || 1) || 1);
    const incomingOutputIds = [...new Set([
      ...(Array.isArray(event.mediaIds) ? event.mediaIds : []),
      ...statusRows.map((row) => row.id)
    ].map(compactString).filter(Boolean))];
    const submittedAtMs = Date.parse(String(candidate.submittedAt || candidate.submitAttemptStartedAt || ""));
    const submitAgeMs = Number.isFinite(submittedAtMs) ? Date.now() - submittedAtMs : Number.POSITIVE_INFINITY;
    const claimedByOtherTask = ledger.listTasks().some((task) => {
      if (task.id === candidate.id) return false;
      const owned = taskOwnedStatusIdentitySet(task);
      return incomingOutputIds.some((id) => owned.has(id));
    });
    const canAdoptFrontSubmit = candidate.submitObservationRecovered === true
      && taskOwnedStatusIdentitySet(candidate).size === 0
      && incomingOutputIds.length > 0
      && incomingOutputIds.length <= expected
      && submitAgeMs >= -30000
      && submitAgeMs <= 12 * 60 * 1000
      && !claimedByOtherTask;
    if (canAdoptFrontSubmit) {
      recordEvent({
        type: "queue.flow_generation_feed.adopted_front_submit_status",
        taskId: candidate.id,
        mediaIds: incomingOutputIds,
        expectedVideos: expected,
        submitAgeMs
      });
      return candidate;
    }
  }
  if (eventIds.size || ["video", "video_workflow", "media_redirect"].includes(endpointKind)) {
    return null;
  }
  const promptMatch = pickBestVideoFlowEventCandidate(candidates.filter(promptMatchesTask))
    || pickBestVideoFlowEventCandidate(candidates.filter((task) => promptSet.has(normalizedPromptText(task.prompt))));
  if (promptMatch) return promptMatch;
  const pendingStatus = activeCandidates.find((task) => ["submitting", "generating"].includes(String(task.status || "").toLowerCase()));
  return pendingStatus || candidates[candidates.length - 1] || null;
}

function pickBestVideoFlowEventCandidate(tasks = []) {
  const statusRank = {
    submitting: 0,
    submitted: 1,
    generating: 2,
    downloading: 3,
    complete: 4
  };
  return [...tasks].sort((a, b) => {
    const aStatus = statusRank[String(a?.status || "").toLowerCase()] ?? 9;
    const bStatus = statusRank[String(b?.status || "").toLowerCase()] ?? 9;
    if (aStatus !== bStatus) return aStatus - bStatus;
    const aMs = Date.parse(String(a?.submitAttemptStartedAt || a?.submittedAt || a?.startedAt || ""));
    const bMs = Date.parse(String(b?.submitAttemptStartedAt || b?.submittedAt || b?.startedAt || ""));
    if (Number.isFinite(aMs) && Number.isFinite(bMs) && aMs !== bMs) return bMs - aMs;
    return Number(b?.jobIndex || 0) - Number(a?.jobIndex || 0);
  })[0] || null;
}

function taskOwnedStatusIdentitySet(task = {}) {
  const inputReferenceIds = new Set([
    ...(Array.isArray(task.refMediaIds) ? task.refMediaIds : []),
    ...(Array.isArray(task.refInputs) ? task.refInputs.map((ref) => ref?.mediaId || ref?.imageId) : []),
    task.startMediaId,
    task.endMediaId,
    task.startRefInput?.mediaId,
    task.endRefInput?.mediaId
  ].map(compactString).filter(Boolean));
  const explicitIds = [
    ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []),
    ...(Array.isArray(task.submitOutputRows) ? task.submitOutputRows.flatMap((row) => [row?.mediaId, row?.workflowId, row?.mediaGenerationId]) : []),
    ...(Array.isArray(task.statusRows) ? task.statusRows.flatMap((row) => [row?.id, row?.workflowId, row?.mediaGenerationId]) : []),
    ...(Array.isArray(task.outputs) ? task.outputs.flatMap((output) => [output?.mediaId, output?.workflowId, output?.mediaGenerationId]) : [])
  ];
  return new Set([
    ...explicitIds,
    ...(explicitIds.map(compactString).filter(Boolean).length ? [] : (Array.isArray(task.mediaIds) ? task.mediaIds : []))
  ].map(compactString).filter((id) => id && !inputReferenceIds.has(id)));
}

function videoTasksForFlowEvent(event = {}) {
  const endpointKind = compactString(event.endpointKind);
  const eventProjectId = compactString(event.projectId);
  const statusRows = normalizePageStatusRows(event.statusRows);
  const eventIds = new Set([
    ...(Array.isArray(event.mediaIds) ? event.mediaIds : []),
    ...statusRows.flatMap((row) => [row.id, row.workflowId, row.mediaGenerationId])
  ].map(compactString).filter(Boolean));
  const candidates = ledger.listTasks()
    .filter((task) => taskMediaKind(task) === "videos")
    .filter((task) => {
      const status = String(task.status || "").toLowerCase();
      if (["submitting", "submitted", "generating", "downloading"].includes(status)) return true;
      if (status !== "complete") return false;
      const downloaded = new Set((task.downloadedMediaIds || []).map(compactString).filter(Boolean));
      const skipped = new Set((task.skippedDownloadMediaIds || []).map(compactString).filter(Boolean));
      return generatedDownloadIdsForTask(task).some((id) => id && !downloaded.has(id) && !skipped.has(id));
    })
    .filter((task) => !eventProjectId || !task.projectId || String(task.projectId) === eventProjectId);
  if (!candidates.length) return [];
  if (endpointKind === "video_status" && eventIds.size) {
    const matched = candidates.filter((task) => {
      const owned = taskOwnedStatusIdentitySet(task);
      return [...eventIds].some((id) => owned.has(id));
    });
    if (matched.length) return matched;
  }
  const fallback = chooseVideoTaskForFlowEvent(event);
  if (fallback) return [fallback];
  if (eventIds.size) return [];
  return [];
}

async function applyFlowGenerationResponseEvent(event = {}) {
  if (event.type !== "flow_generation_response") return null;
  const endpointKind = compactString(event.endpointKind);
  if (!["video", "video_status", "video_workflow", "media_redirect"].includes(endpointKind)) return null;
  const tasks = videoTasksForFlowEvent(event);
  if (tasks.length > 1) {
    const results = [];
    for (const task of tasks) {
      results.push(await applyFlowGenerationResponseEventToTask(task, event));
    }
    return results[0] || null;
  }
  const task = tasks[0] || null;
  if (!task?.id) {
    const activeVideoTasks = ledger.listTasks().filter((candidate) => taskMediaKind(candidate) === "videos" && isTaskActive(candidate));
    recordEvent({
      type: "queue.flow_generation_feed.unmatched",
      endpointKind,
      projectId: compactString(event.projectId),
      mediaIdCount: Array.isArray(event.mediaIds) ? event.mediaIds.length : 0,
      statusRowCount: Array.isArray(event.statusRows) ? event.statusRows.length : 0,
      prompts: Array.isArray(event.prompts) ? event.prompts.slice(0, 3) : [],
      activeVideoTaskCount: activeVideoTasks.length,
      activeVideoTasks: activeVideoTasks.slice(0, 4).map((candidate) => ({
        taskId: candidate.id,
        status: candidate.status || "",
        expectedVideos: Number(candidate.expectedVideos || candidate.repeatCount || 1) || 1,
        ownedIdentityCount: taskOwnedStatusIdentitySet(candidate).size,
        submitObservationRecovered: candidate.submitObservationRecovered === true,
        submitAgeMs: Date.now() - (Date.parse(String(candidate.submittedAt || candidate.submitAttemptStartedAt || "")) || Date.now())
      }))
    });
    return null;
  }
  return applyFlowGenerationResponseEventToTask(task, event);
}

async function applyFlowGenerationResponseEventToTask(task = {}, event = {}) {
  const endpointKind = compactString(event.endpointKind);
  const incomingRows = normalizePageStatusRows(event.statusRows);
  const currentRows = normalizePageStatusRows(task.statusRows);
  const ownedIdentitySet = taskOwnedStatusIdentitySet(task);
  const scopedIncomingRows = endpointKind === "video_status" && ownedIdentitySet.size
    ? incomingRows.filter((row) => ownedIdentitySet.has(row.id) || ownedIdentitySet.has(row.workflowId) || ownedIdentitySet.has(row.mediaGenerationId))
    : incomingRows;
  const scopedEventMediaIds = endpointKind === "video_status" && ownedIdentitySet.size
    ? (Array.isArray(event.mediaIds) ? event.mediaIds : []).map(compactString).filter((id) => ownedIdentitySet.has(id))
    : (Array.isArray(event.mediaIds) ? event.mediaIds : []);
  const rowMap = new Map();
  [...currentRows, ...scopedIncomingRows].forEach((row) => {
    const key = row.id || row.workflowId;
    if (!key) return;
    rowMap.set(key, { ...(rowMap.get(key) || {}), ...row });
  });
  const statusRows = [...rowMap.values()];
  const mediaIds = [...new Set([
    ...(Array.isArray(task.mediaIds) ? task.mediaIds : []),
    ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []),
    ...scopedEventMediaIds,
    ...statusRows.map((row) => row.id)
  ].map(compactString).filter(Boolean))];
  const expected = Math.max(1, Number(task.expectedVideos || task.repeatCount || mediaIds.length || 1) || 1);
  const priorReadyIds = new Set((task.videoDownloadReadyMediaIds || []).map(compactString).filter(Boolean));
  if (endpointKind === "video_workflow" || endpointKind === "media_redirect") {
    (Array.isArray(event.mediaIds) ? event.mediaIds : []).map(compactString).filter(Boolean).forEach((id) => priorReadyIds.add(id));
  }
  statusRows
    .filter((row) => row.status === "complete" && (row.mediaUrl || row.thumbnailUrl))
    .map((row) => compactString(row.id))
    .filter(Boolean)
    .forEach((id) => priorReadyIds.add(id));
  const videoDownloadReadyMediaIds = [...priorReadyIds];
  const completeRows = statusRows.filter((row) => row.status === "complete" && row.id);
  const failedRows = statusRows.filter((row) => row.status === "failed");
  const terminalRows = statusRows.filter((row) => row.status === "complete" || row.status === "failed");

  let patch = {
    mediaIds,
    statusRows,
    expectedVideos: expected,
    foundVideos: completeRows.length,
      videoDownloadReadyMediaIds,
      lastPollAt: new Date().toISOString(),
      flowStatusFeedAt: new Date().toISOString()
  };
  let completed = null;
  if (terminalRows.length >= expected && !completeRows.length) {
    const failureText = failureTextForStatusRows(failedRows, "MEDIA_GENERATION_STATUS_FAILED");
    const latestTask = ledger.getTask(task.id) || task;
    const acceptedDirectV2V = String(latestTask.mode || latestTask.requestedMode || task.mode || "") === "video-to-video"
      && ["accepted", "write_dispatched", "ambiguous_watch_only"].includes(String(latestTask.paidWriteState || task.paidWriteState || ""));
    ledger.updateTask(task.id, {
      ...patch,
      foundVideos: 0,
      failedOutputCount: failedRows.length || expected,
      failedOutputMediaIds: failedRows.map((row) => row.id || row.workflowId).filter(Boolean),
      partialFailure: true
    });
    // A paid V2V write is exactly-once. Once its captured media ID reaches a
    // terminal provider failure, close this task instead of resetting the same
    // write to pending. A retry must use a fresh job/idempotency boundary.
    let failed = null;
    let retryReset = null;
    if (acceptedDirectV2V) {
      failed = ledger.updateTask(task.id, {
        status: TaskStatus.failed,
        completedAt: new Date().toISOString(),
        lastError: failureText,
        failureClass: "media_generation_failed",
        failureScope: "task",
        healAction: "",
        recoveryPolicy: "fresh_job_only",
        sideEffectRetryBlocked: true,
        possibleSideEffect: true
      });
    } else {
      failed = scheduler.markFailure(task.id, failureText);
      if (failed?.status === TaskStatus.pending && failed?.healAction === "retry_generation") {
        retryReset = ledger.updateTask(task.id, retryGenerationFailurePatch(failedRows, mediaIds, failed || task, failureText));
        recordEvent({
          type: "queue.flow_generation_feed.retry_reset",
          taskId: task.id,
          endpointKind,
          previousMediaIds: mediaIds,
          previousFailedOutputMediaIds: retryReset?.previousFailedOutputMediaIds || [],
          tabReloadRequired: Boolean(retryReset?.generationFailureNeedsFlowReload)
        });
      }
    }
    recordEvent({
      type: "queue.flow_generation_feed.failure",
      taskId: task.id,
      endpointKind,
      failureClass: retryReset?.failureClass || failed?.failureClass || "",
      failureScope: retryReset?.failureScope || failed?.failureScope || "",
      healAction: retryReset?.healAction || failed?.healAction || "",
      expectedVideos: expected,
      failedCount: failedRows.length,
      lastError: retryReset?.lastError || failed?.lastError || failureText,
      exactlyOnceTerminal: acceptedDirectV2V
    });
  } else if (terminalRows.length >= expected && completeRows.length) {
    const outputs = completeRows.slice(0, expected).map((row, mediaIndex) => ({
      id: `${task.id}:${row.id || mediaIndex}`,
      mediaId: row.id,
      mediaUrl: row.mediaUrl || buildMediaRedirectUrl({ mediaId: row.id }),
      thumbnailUrl: row.thumbnailUrl || buildMediaThumbnailUrl({ mediaId: row.id }),
      prompt: task.prompt || "",
      kind: "videos",
      status: row.status,
      rawStatus: row.rawStatus,
      workflowId: row.workflowId || "",
      mediaGenerationId: row.mediaGenerationId || row.workflowId || "",
      mediaIndex,
      source: "flow_status_feed"
    }));
    completed = scheduler.markComplete(task.id, {
      ...patch,
      outputs,
      outputMediaIds: outputs.map((output) => output.mediaId),
      foundVideos: outputs.length,
      failedOutputCount: Math.max(0, expected - outputs.length) + failedRows.length,
      failedOutputMediaIds: failedRows.map((row) => row.id).filter(Boolean),
      partialFailure: outputs.length < expected
    });
    if (outputs.every((output) => priorReadyIds.has(output.mediaId))) {
      await autoDownloadCompletedTasks([task.id], "flow_status_feed");
    }
  } else {
    ledger.updateTask(task.id, patch);
  }
  const after = ledger.getTask(task.id);
  if (shouldAttemptAutoDownloadForTask(after)) {
    await autoDownloadCompletedTasks([task.id], endpointKind);
  }
  await persistQueueState();
  recordEvent({
    type: "queue.flow_generation_feed",
    taskId: task.id,
    endpointKind,
    mediaIdCount: mediaIds.length,
    statusRowCount: statusRows.length,
    completeCount: completeRows.length,
    failedCount: failedRows.length,
    expectedVideos: expected,
    completed: completed?.status === TaskStatus.complete
  });
  return ledger.getTask(task.id);
}

function activeTaskSummary() {
  const tasks = ledger.listTasks();
  return {
    pending: tasks.filter((task) => task.status === TaskStatus.pending).length,
    active: tasks.filter((task) => isTaskActive(task)).length,
    complete: tasks.filter((task) => task.status === TaskStatus.complete).length,
    failed: tasks.filter((task) => task.status === TaskStatus.failed).length,
    blocked: tasks.filter((task) => task.status === TaskStatus.blocked).length,
    total: tasks.length
  };
}

function reconcileQueueWithDownloadResults(downloads = []) {
  const patches = reconcileTasksWithDownloadResults(ledger.listTasks(), downloads);
  for (const entry of patches) {
    ledger.updateTask(entry.taskId, entry.patch);
    recordEvent({
      type: "queue.download_reconcile",
      taskId: entry.taskId,
      downloadedCount: entry.downloadedCount,
      skippedDownloadCount: entry.skippedDownloadCount
    });
  }
  return patches;
}

function downloadResultsFromRuntimeEvents(events = runtimeState.events) {
  return (Array.isArray(events) ? events : [])
    .filter((event) => ["media.download", "media.download.error", "media.download.dedupe_blocked"].includes(String(event?.type || "")))
    .map((event) => {
      const type = String(event.type || "");
      return {
        ok: type === "media.download",
        skipped: type === "media.download.dedupe_blocked",
        taskId: compactString(event.taskId),
        mediaId: compactString(event.mediaId),
        filename: compactString(event.filename || event.fileName || event.finalFilepath || event.targetFilepath),
        downloadId: event.downloadId || null,
        error: type === "media.download" ? "" : compactString(event.error || event.reason || "download_failed")
      };
    })
    .filter((download) => download.taskId || download.mediaId);
}

function downloadPatchChangesTask(task = {}, patch = {}) {
  for (const field of ["downloadedMediaIds", "skippedDownloadMediaIds", "downloadErrorMediaIds"]) {
    if (!Array.isArray(patch[field])) continue;
    const current = Array.isArray(task[field]) ? task[field] : [];
    if (JSON.stringify(current) !== JSON.stringify(patch[field])) {
      return true;
    }
  }
  for (const field of ["downloadedCount", "skippedDownloadCount"]) {
    if (!Object.prototype.hasOwnProperty.call(patch, field)) continue;
    if (Number(task[field] || 0) !== Number(patch[field] || 0)) return true;
  }
  const currentById = new Map((Array.isArray(task.outputs) ? task.outputs : [])
    .filter((output) => output?.mediaId)
    .map((output) => [compactString(output.mediaId), output]));
  return (Array.isArray(patch.outputs) ? patch.outputs : []).some((output) => {
    const mediaId = compactString(output?.mediaId);
    if (!mediaId) return false;
    const current = currentById.get(mediaId) || {};
    return compactString(current.downloadStatus) !== compactString(output.downloadStatus)
      || compactString(current.downloadFilename) !== compactString(output.downloadFilename)
      || compactString(current.downloadError) !== compactString(output.downloadError);
  });
}

function repairQueueDownloadStateFromEvents(reason = "runtime_download_events") {
  const downloads = downloadResultsFromRuntimeEvents();
  if (!downloads.length) return [];
  const patches = reconcileTasksWithDownloadResults(ledger.listTasks(), downloads);
  const applied = [];
  for (const entry of patches) {
    const task = ledger.getTask(entry.taskId);
    if (!task || !downloadPatchChangesTask(task, entry.patch)) continue;
    ledger.updateTask(entry.taskId, entry.patch);
    applied.push(entry);
  }
  if (applied.length) {
    recordEvent({
      type: "queue.download_repair",
      reason,
      repaired: applied.length
    });
  }
  return applied;
}

function generatedDownloadIdsForTask(task = {}) {
  const referenceIds = new Set([
    ...(Array.isArray(task.refMediaIds) ? task.refMediaIds : []),
    task.startMediaId,
    task.endMediaId
  ].map((id) => String(id || "").trim()).filter(Boolean));
  return [...new Set([
    ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []),
    ...(Array.isArray(task.outputs) ? task.outputs.map((output) => output?.mediaId) : []),
    ...(Array.isArray(task.mediaIds) ? task.mediaIds : [])
  ].map((id) => String(id || "").trim()).filter((id) => id && !referenceIds.has(id)))];
}

function pendingAutoDownloadIdsForTask(task = {}) {
  if (task?.download?.enabled !== true) return [];
  return deriveTaskOutputLedger(task).pendingDownloadIds;
}

function shouldAttemptAutoDownloadForTask(task = {}) {
  if (!task?.id || task?.download?.enabled !== true || task.status !== TaskStatus.complete) return false;
  const outputLedger = deriveTaskOutputLedger(task);
  const consumed = new Set([
    ...outputLedger.downloadedIds,
    ...outputLedger.skippedDownloadIds,
    ...outputLedger.downloadErrorIds
  ]);
  return outputLedger.successfulIds.some((id) => id && !consumed.has(id));
}

function markUnplannedAutoDownloads(taskIds = [], error = "auto_download_no_plan") {
  const updated = [];
  for (const taskId of taskIds || []) {
    const task = ledger.getTask(taskId);
    if (!task) continue;
    const pendingIds = pendingAutoDownloadIdsForTask(task);
    if (!pendingIds.length) continue;
    const failedIds = new Set([
      ...(Array.isArray(task.downloadErrorMediaIds) ? task.downloadErrorMediaIds : []),
      ...pendingIds
    ].map(compactString).filter(Boolean));
    const outputs = (Array.isArray(task.outputs) ? task.outputs : []).map((output) => {
      const mediaId = compactString(output?.mediaId);
      if (!mediaId || !failedIds.has(mediaId)) return output;
      return {
        ...output,
        downloadStatus: "download_failed",
        downloadError: output.downloadError || error
      };
    });
    const patch = {
      downloadErrorMediaIds: [...failedIds],
      outputs,
      lastDownloadError: error
    };
    ledger.updateTask(task.id, patch);
    updated.push({ taskId: task.id, mediaIds: pendingIds });
    recordEvent({
      type: "media.auto_download.no_plan_marked",
      taskId: task.id,
      mediaIds: pendingIds,
      error
    });
  }
  return updated;
}

function isTransientPageCommandError(error = "") {
  return /message channel closed|receiving end does not exist|extension context invalidated|context invalidated|flow_bridge_not_ready|flow_tab_not_found/i.test(String(error || ""));
}

function successfulVideoOutputIdsForDirectDownload(task = {}) {
  const outputIds = (Array.isArray(task.outputs) ? task.outputs : [])
    .filter((output) => {
      const status = String(output?.status || "").toLowerCase();
      const rawStatus = String(output?.rawStatus || "").toUpperCase();
      return output?.mediaId && (!status || status === "complete" || rawStatus === "MEDIA_GENERATION_STATUS_SUCCESSFUL");
    })
    .map((output) => output.mediaId);
  const rowIds = (Array.isArray(task.statusRows) ? task.statusRows : [])
    .filter((row) => {
      const status = String(row?.status || "").toLowerCase();
      const rawStatus = String(row?.rawStatus || "").toUpperCase();
      return (row?.id || row?.mediaId) && (status === "complete" || rawStatus === "MEDIA_GENERATION_STATUS_SUCCESSFUL");
    })
    .map((row) => row.id || row.mediaId);
  return [...new Set([...outputIds, ...rowIds].map(compactString).filter(Boolean))];
}

async function refreshVideoDownloadReadinessForTask(task = {}) {
  if (!task?.id || taskMediaKind(task) !== "videos") return task;
  const ownedIds = generatedDownloadIdsForTask(task);
  if (!ownedIds.length) return task;
  const existingReady = new Set((task.videoDownloadReadyMediaIds || []).map(compactString).filter(Boolean));
  const missing = ownedIds.filter((id) => !existingReady.has(id));
  if (!missing.length) return task;
  let result = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    result = await sendPageCommand({
      action: "resolveVideoDownloadReadiness",
      mediaIds: missing,
      submitOutputRows: Array.isArray(task.submitOutputRows) ? task.submitOutputRows : [],
      projectId: task.projectId || runtimeState.projectId,
      timeoutMs: 20000
    }).catch((error) => ({ ok: false, error: String(error?.message || error || "readiness_failed") }));
    const attemptPayload = result?.result || result;
    if (attemptPayload?.ok !== false || !isTransientPageCommandError(attemptPayload?.error)) break;
    recordEvent({
      type: "media.download.readiness.retry",
      taskId: task.id,
      requested: missing.length,
      attempt: attempt + 1,
      error: attemptPayload.error || ""
    });
    await sleep(750 * (attempt + 1));
  }
  const payload = result?.result || result;
  const directFallbackIds = payload?.ok === false && isTransientPageCommandError(payload?.error)
    ? missing.filter((id) => successfulVideoOutputIdsForDirectDownload(task).includes(id))
    : [];
  const readyIds = [...new Set([
    ...existingReady,
    ...(Array.isArray(payload?.readyMediaIds) ? payload.readyMediaIds : []),
    ...directFallbackIds
  ].map(compactString).filter(Boolean))];
  recordEvent({
    type: "media.download.readiness",
    taskId: task.id,
    requested: missing.length,
    ready: readyIds.length,
    ok: payload?.ok !== false,
    directFallbackReady: directFallbackIds.length,
    error: payload?.error || "",
    rows: Array.isArray(payload?.rows) ? payload.rows.slice(0, 8) : []
  });
  if (readyIds.length === existingReady.size) return task;
  return ledger.updateTask(task.id, { videoDownloadReadyMediaIds: readyIds });
}

async function refreshVideoUpscaleSource(plan = {}) {
  const response = await sendPageCommand({
    action: "resolveVideoDownloadReadiness",
    mediaIds: [plan.mediaId],
    submitOutputRows: Array.isArray(plan.submitOutputRows) ? plan.submitOutputRows : [],
    projectId: plan.projectId || runtimeState.projectId,
    timeoutMs: 20000
  }).catch((error) => ({ ok: false, error: String(error?.message || error || "video_source_refresh_failed") }));
  const payload = response?.result || response;
  const row = Array.isArray(payload?.rows)
    ? payload.rows.find((candidate) => String(candidate?.mediaId || "").trim() === String(plan.mediaId || "").trim()) || null
    : null;
  return {
    ok: payload?.ok !== false,
    row,
    mediaGenerationId: String(row?.mediaGenerationId || "").trim(),
    error: String(payload?.error || "").trim()
  };
}

async function executeDownloadPlansSequential(plans = [], source = "manual") {
  const downloads = [];
  for (const plan of plans) {
    const reservation = reserveDownloadPlan(plan);
    if (!reservation.ok) {
      const blocked = {
        ...plan,
        ok: false,
        skipped: true,
        error: reservation.reason,
        dedupeDecision: "blocked",
        attemptId: crypto.randomUUID()
      };
      downloads.push(blocked);
      recordEvent({
        type: "media.download.dedupe_blocked",
        mediaId: plan.mediaId,
        taskId: plan.taskId,
        fileName: plan.filename,
        artifactKey: reservation.artifactKey,
        targetPathKey: reservation.targetPathKey,
        downloadPath: plan.downloadPath,
        downloadUrl: summarizeDownloadUrl(plan.url || ""),
        targetFilepath: plan.filename || plan.targetPathKey || "",
        finalFilepath: "",
        fileSize: 0,
        dedupeDecision: "blocked",
        reason: reservation.reason,
        source
      });
      continue;
    }
    let resolvedPlan = await resolveDownloadPlan(plan);
    let result;
    if (resolvedPlan.ok) {
      result = await downloadFileWithReadinessRetries(
        resolvedPlan.url,
        resolvedPlan.filename,
        { ...plan, fallbackDownloadUrl: resolvedPlan.meta?.fallbackDownloadUrl || "" },
        { kind: plan.kind, resolution: resolvedPlan.meta?.outputResolution || plan.resolution || "" }
      );
    } else if (resolvedPlan.meta?.fallbackDirectDownload && plan.mediaId) {
      const fallbackResolution = "720p";
      const fallbackFilename = fallbackFilenameForResolution(plan.filename, fallbackResolution);
      const fallbackResult = await downloadFileWithReadinessRetries(
        buildMediaRedirectUrl({ mediaId: plan.mediaId }),
        fallbackFilename,
        { ...plan, filename: fallbackFilename, requiresUpscale: false, resolution: fallbackResolution, fallbackDownloadUrl: "" },
        { kind: plan.kind, resolution: fallbackResolution }
      );
      const unavailableError = resolutionUnavailableError(plan.resolution, resolvedPlan.error);
      result = {
        ...fallbackResult,
        ok: false,
        error: fallbackResult.ok
          ? unavailableError
          : `${unavailableError}; fallback_720p:${fallbackResult.error || "download_failed"}`,
        preservedArtifact: Boolean(fallbackResult.ok && fallbackResult.filename),
        preservedArtifactFilename: fallbackResult.ok ? fallbackResult.filename || "" : "",
        deliveredResolution: fallbackResult.ok ? fallbackResolution : "",
        fallbackResolution: fallbackResult.ok ? fallbackResolution : "",
        resolutionUnavailable: plan.resolution || ""
      };
      resolvedPlan = {
        ...resolvedPlan,
        meta: {
          ...(resolvedPlan.meta || {}),
          fallbackFilename,
          fallbackResolution
        }
      };
    } else {
      result = {
        ok: false,
        error: resolvedPlan.error || "download_resolution_resolve_failed",
        downloadId: null,
        resolutionUnavailable: resolvedPlan.meta?.resolutionUnavailable || ""
      };
    }
    const resolutionVerified = result.ok && isDownloadResolutionVerified({
      ...plan,
      ...resolvedPlan.meta
    });
    const checkedResult = result.ok && !resolutionVerified
      ? {
        ...result,
        ok: false,
        error: `download_resolution_unverified:${plan.resolution || "unknown"}`,
        preservedArtifact: Boolean(result.filename),
        preservedArtifactFilename: result.filename || "",
        resolutionUnavailable: plan.resolution || ""
      }
      : result;
    if (!checkedResult.ok) {
      releaseDownloadReservation(reservation);
    }
    const attemptId = crypto.randomUUID();
    const plannedFilename = resolvedPlan.filename || plan.filename;
    downloads.push({
      ...plan,
      ...resolvedPlan.meta,
      ...checkedResult,
      resolutionVerified,
      url: summarizeDownloadUrl(resolvedPlan.url || plan.url || ""),
      downloadUrl: summarizeDownloadUrl(resolvedPlan.url || plan.url || ""),
      filename: plannedFilename,
      plannedFilename,
      absolutePath: result.filename || "",
      completedPath: checkedResult.filename || "",
      finalFilepath: checkedResult.filename || "",
      artifactFilename: checkedResult.filename || "",
      attemptId,
      artifactKey: reservation.artifactKey,
      targetPathKey: reservation.targetPathKey,
      dedupeDecision: "allowed"
    });
    recordEvent({
      type: checkedResult.ok ? "media.download" : "media.download.error",
      mediaId: plan.mediaId,
      taskId: plan.taskId,
      fileName: resolvedPlan.filename || plan.filename,
      filename: checkedResult.filename || resolvedPlan.filename || plan.filename,
      artifactKey: reservation.artifactKey,
      targetPathKey: reservation.targetPathKey,
      downloadPath: plan.downloadPath,
      downloadUrl: summarizeDownloadUrl(resolvedPlan.url || plan.url || ""),
      targetFilepath: resolvedPlan.filename || plan.filename || plan.targetPathKey || "",
      finalFilepath: checkedResult.filename || "",
      downloadId: checkedResult.downloadId || null,
      bytesReceived: Number(checkedResult.bytesReceived || 0),
      fileSize: Number(checkedResult.fileSize || 0),
      durationMs: Number(checkedResult.durationMs || 0),
      totalDurationMs: Number(checkedResult.totalDurationMs || checkedResult.durationMs || 0),
      attempts: Number(checkedResult.attempts || 1),
      retryWaitMs: Number(checkedResult.retryWaitMs || 0),
      matchMethod: plan.matchMethod,
      resolution: plan.resolution || "",
      dedupeDecision: "allowed",
      attemptId,
      source,
      resolutionVerified,
      error: checkedResult.error || ""
    });
  }
  return downloads;
}

async function executeDownloadPlans(plans = [], source = "manual") {
  const requested = Array.isArray(plans) ? plans : [];
  if (requested.length <= 1) return executeDownloadPlansSequential(requested, source);
  recordEvent({
    type: "media.download.batch_concurrency",
    source,
    planned: requested.length,
    directConcurrency: DIRECT_DOWNLOAD_CONCURRENCY,
    upscaleConcurrency: UPSCALE_DOWNLOAD_CONCURRENCY
  });
  return mapDownloadPlansWithConcurrency(
    requested,
    async (plan) => (await executeDownloadPlansSequential([plan], source))[0],
    {
      directConcurrency: DIRECT_DOWNLOAD_CONCURRENCY,
      upscaleConcurrency: UPSCALE_DOWNLOAD_CONCURRENCY
    }
  );
}

function summarizeDownloadUrl(url = "") {
  const text = String(url || "");
  if (!text) return "";
  if (/^data:/i.test(text)) return `[data-url:${text.length} chars]`;
  if (text.length > 1200) return `${text.slice(0, 240)}...[truncated:${text.length} chars]`;
  return text;
}

function timeoutAfter(ms, error = "operation_timeout") {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ ok: false, error }), Math.max(1000, Number(ms || 0) || 1000));
  });
}

async function resolveDownloadPlan(plan = {}) {
  if (plan.requiresUpscale !== true) {
    // Non-upscale (720p/native) downloads: let Chrome follow the Flow media
    // redirect URL natively. Per docs/GOTCHAS.md "Media Redirect / Download
    // Poisoning":
    //   - Native Chrome downloads should use the raw Flow redirect URL
    //     (media.getMediaUrlRedirect?name=<mediaId>).
    //   - Do not validate normal 720p video downloads with page fetch probes.
    //     Let Chrome follow the redirect, then validate the completed file size.
    //   - Range probes can fail against Flow redirects.
    //
    // Trigger evidence: autoflow-report-10.8.1-2026-05-02_171146Z.md showed
    // Downloads 3/4 ok, 2 failed because the in-background probe of every
    // candidate URL (operations array, generated_video, redirect_fallback)
    // failed where the redirect itself works fine when Chrome follows it
    // natively. Generation had succeeded with rawStatus
    // MEDIA_GENERATION_STATUS_SUCCESSFUL.
    //
    // Validation happens AFTER download via download_too_small + tiny-MP4
    // checks, not via background probe.
    //
    // Construct the redirect URL fresh from plan.mediaId rather than reusing
    // plan.url (which can carry gallery-scan mutations or cache-bust params).
    // The naked redirect URL is what Chrome's downloader follows cleanly.
    const directUrl = plan.mediaId
      ? buildMediaRedirectUrl({ mediaId: plan.mediaId })
      : plan.url;
    const fallbackUrl = String(plan.url || "").trim() && String(plan.url || "").trim() !== directUrl
      ? String(plan.url || "").trim()
      : "";
    return {
      ok: true,
      url: directUrl,
      filename: plan.filename,
      meta: {
        directDownloadPath: "flow_playback_redirect_native",
        fallbackDownloadUrl: fallbackUrl
      }
    };
  }
  const kind = resolveDownloadMediaKind(plan.kind || plan.mediaKind, plan.filename);
  const resolution = String(plan.resolution || "").trim().toLowerCase();
  try {
    if (kind === "images") {
      const result = await sendPageCommand({
        action: "upscaleImage",
        mediaId: plan.mediaId,
        resolution,
        timeoutMs: 180000
      });
      if (!result?.ok || !result.dataUrl) {
        return { ok: false, error: result?.error || "image_upscale_failed", url: "", filename: plan.filename, meta: { upscaleResult: result || null } };
      }
      return {
        ok: true,
        url: result.dataUrl,
        filename: filenameWithImageMimeExtension(plan.filename, result.mimeType),
        meta: {
          upscaleStatus: "ok",
          upscaleEndpoint: result.endpoint || "",
          outputResolution: resolution,
          byteLength: Number(result.byteLength || 0)
        }
      };
    }
    if (kind === "videos") {
      const videoResolution = resolution === "4k" ? "4k" : "1080p";
      const upscale = (sourcePlan) => sendPageCommand({
        action: "upscaleVideo",
        mediaId: sourcePlan.mediaId,
        mediaGenerationId: sourcePlan.mediaGenerationId || "",
        resolution: videoResolution,
        projectId: sourcePlan.projectId || "",
        aspectRatio: sourcePlan.aspectRatio || "",
        timeoutMs: 360000
      });
      let result = await upscale(plan);
      const recovery = {
        refreshed: false,
        retried: false,
        staleMediaGenerationId: plan.mediaGenerationId || "",
        freshMediaGenerationId: "",
        refreshedStatus: "",
        refreshError: ""
      };
      let refreshed = null;
      if (!result?.mediaUrl && !result?.dataUrl && isRetryableUpscaleFailure(result?.error)) {
        refreshed = await refreshVideoUpscaleSource(plan);
        recovery.refreshed = true;
        recovery.freshMediaGenerationId = refreshed.mediaGenerationId;
        recovery.refreshedStatus = refreshed.row?.rawStatus || refreshed.row?.status || "";
        recovery.refreshError = refreshed.error;
        // Upscale is a paid generation write. A 5xx, timeout, or unreadable
        // response may have crossed Google's acceptance boundary, so refresh
        // identity read-only but never dispatch a second upscale automatically.
        recovery.retryBlockedPossibleSideEffect = canRetryUpscaleFromFreshMedia({
          error: result.error,
          row: refreshed.row,
          refreshedMediaGenerationId: refreshed.mediaGenerationId,
          staleMediaGenerationId: plan.mediaGenerationId,
          recoveryAttempts: 0
        });
      }
      if (!result?.mediaUrl && !result?.dataUrl) {
        const finalError = result?.error || "video_upscale_failed";
        return {
          ok: false,
          error: finalError,
          url: "",
          filename: plan.filename,
          meta: {
            upscaleResult: result || null,
            upscaleRecovery: recovery,
            resolutionUnavailable: videoResolution,
            fallbackDirectDownload: isRetryableUpscaleFailure(finalError)
              && !isExplicitlyFailedMediaRow(refreshed?.row || {})
          }
        };
      }
      return {
        ok: true,
        url: result.dataUrl || result.mediaUrl,
        filename: plan.filename,
        meta: {
          upscaleStatus: "ok",
          upscaleEndpoint: result.endpoint || "",
          resultMediaName: result.resultMediaName || "",
          outputResolution: videoResolution,
          modelKey: result.modelKey || "",
          byteLength: Number(result.byteLength || 0),
          mimeType: result.mimeType || "",
          upscaleRecovery: recovery
        }
      };
    }
    return { ok: false, error: "unsupported_upscale_media_kind", url: "", filename: plan.filename, meta: {} };
  } catch (error) {
    return { ok: false, error: String(error?.message || error || "upscale_exception"), url: "", filename: plan.filename, meta: {} };
  }
}

function filenameWithImageMimeExtension(filename = "", mimeType = "") {
  const base = String(filename || "image").replace(/\.(png|jpe?g|webp|avif)$/i, "");
  const mime = String(mimeType || "").toLowerCase();
  if (mime.includes("jpeg") || mime.includes("jpg")) return `${base}.jpeg`;
  if (mime.includes("webp")) return `${base}.webp`;
  if (mime.includes("avif")) return `${base}.avif`;
  return `${base}.png`;
}

async function autoDownloadCompletedTasks(taskIds = [], reason = "completion") {
  const ids = [...new Set((taskIds || []).map((id) => String(id || "").trim()).filter(Boolean))];
  const selectedIds = [];
  const folders = new Set();
  const projectIds = new Set();
  const resolutionByTaskId = {};
  const filenameOptionsByTaskId = {};
  for (const taskId of ids) {
    let task = ledger.getTask(taskId);
    if (!task || task.status !== TaskStatus.complete) continue;
    if (taskMediaKind(task) === "videos") {
      task = await refreshVideoDownloadReadinessForTask(task);
    }
    const mediaIds = pendingAutoDownloadIdsForTask(task);
    if (!mediaIds.length) {
      const outputLedger = deriveTaskOutputLedger(task);
      recordEvent({
        type: "media.auto_download.no_pending",
        reason,
        taskId: task.id,
        kind: outputLedger.kind,
        resultCount: outputLedger.resultCount,
        expectedDownloadCount: outputLedger.expectedDownloadCount,
        readyVideoIds: outputLedger.readyVideoIds.length,
        downloaded: outputLedger.downloadedIds.length,
        skipped: outputLedger.skippedDownloadIds.length,
        downloadErrors: outputLedger.downloadErrorIds.length,
        generatedIds: generatedDownloadIdsForTask(task).length,
        downloadEnabled: task.download?.enabled === true
      });
      continue;
    }
    folders.add(String(task.download?.folder || "Auto-Flow-01"));
    if (task.projectId) projectIds.add(String(task.projectId));
    resolutionByTaskId[String(task.id)] = String(task.download?.resolution || "").trim();
    filenameOptionsByTaskId[String(task.id)] = {
      folder: task.download?.folder || "",
      filenameStyle: task.download?.filenameStyle || "",
      filenameTemplatePrefix: task.download?.filenameTemplatePrefix || "",
      filenameTemplateIndex: task.download?.filenameTemplateIndex || "",
      filenameTemplatePromptPart: task.download?.filenameTemplatePromptPart || "",
      filenameTemplateDate: task.download?.filenameTemplateDate || "",
      filenameTemplateSuffix: task.download?.filenameTemplateSuffix || "",
      filenameTemplateSeparator: task.download?.filenameTemplateSeparator || ""
    };
    selectedIds.push(...mediaIds.flatMap((mediaId) => [`${task.id}:${mediaId}`, mediaId]));
  }
  if (!selectedIds.length) {
    recordEvent({
      type: "media.auto_download.no_selection",
      reason,
      requestedTasks: ids.length
    });
    return [];
  }
  const folder = folders.size === 1 ? [...folders][0] : "Auto-Flow-01";
  const projectId = projectIds.size === 1 ? [...projectIds][0] : runtimeState.lastGalleryProjectId;
  const gallery = galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", projectId);
  const plans = planMediaDownloads(gallery.items, {
    selectedIds,
    folder,
    resolutionByTaskId,
    filenameOptionsByTaskId,
    allowDuplicateTargetSuffix: true,
    reservedArtifactKeys: [...downloadReservations.artifacts.keys()],
    reservedTargetPaths: [...downloadReservations.targets.keys()]
  });
  if (!plans.length) {
    recordEvent({
      type: "media.auto_download.no_plans",
      reason,
      selected: selectedIds.length,
      galleryItems: gallery.items.length,
      folder,
      projectId: projectId || ""
    });
    markUnplannedAutoDownloads(ids, "auto_download_no_plan");
    return [];
  }
  recordEvent({ type: "media.auto_download.start", reason, planned: plans.length });
  const downloads = await executeDownloadPlans(plans, "auto");
  const reconciledDownloads = reconcileQueueWithDownloadResults(downloads);
  if (reconciledDownloads.length) await persistQueueState();
  recordEvent({
    type: "media.auto_download.done",
    reason,
    planned: plans.length,
    downloaded: downloads.filter((download) => download.ok).length,
    skipped: downloads.filter((download) => download.skipped).length
  });
  return downloads;
}

async function scanFlowGallery(preferredTabId, options = {}) {
  try {
    const auto = Boolean(options.auto || options.lightweight);
    const fullScroll = options.fullScroll ?? !auto;
    const maxSteps = auto ? 1 : 18;
    const settleMs = auto ? 20 : 35;
    const maxMediaNodes = auto ? 120 : 800;
    const maxProjectMedia = auto ? 500 : 800;
    const tab = await findFlowTab(preferredTabId);
    const tabProjectId = projectIdFromUrl(tab?.url || "");
    if (!tab?.id) {
      return {
        ok: false,
        error: "flow_tab_not_found",
        gallery: galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", runtimeState.lastGalleryProjectId)
      };
    }
    const bridge = await ensureFlowBridge(tab.id);
    if (!bridge?.ok) {
      return {
        ok: false,
        error: bridge?.error || "flow_bridge_not_ready",
        gallery: galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", tabProjectId || runtimeState.lastGalleryProjectId)
      };
    }
    const scan = await sendPageCommand({
      action: "projectGeneratedMedia",
      projectId: tabProjectId || runtimeState.projectId || "",
      maxProjectMedia,
      timeoutMs: 20000
    }, tab.id).catch((error) => ({ ok: false, error: String(error?.message || error || "project_feed_failed") }));
    const projectRows = scan?.ok && Array.isArray(scan.rows) ? scan.rows : [];
    const projectItems = scan?.ok && Array.isArray(scan.items) ? scan.items : [];
    const projectReconciled = reconcileQueueWithProjectMediaFeed(projectRows, "gallery_scan_project_feed");
    if (projectReconciled.length) {
      await autoDownloadCompletedTasks(projectReconciled.map((entry) => entry.taskId), "project_feed");
      await persistQueueState();
    }

    const domScan = await sendPageCommand({
      action: "scanGallery",
      options: {
        fullScroll,
        maxSteps,
        settleMs,
        maxMediaNodes,
        maxProjectMedia,
        includeProjectData: false
      },
      timeoutMs: 20000
    }, tab.id);
    const scanProjectId = String(scan?.meta?.projectId || domScan?.meta?.projectId || tabProjectId || "").trim();
    const galleryTasks = ledger.listTasks();
    const referenceMediaIds = referenceMediaIdsFromTasks(galleryTasks);
    const generatedOutputMediaIds = generatedOutputMediaIdsFromTasks(galleryTasks);
    const galleryFilterOptions = { referenceMediaIds, generatedOutputMediaIds };
    const items = domScan?.ok && Array.isArray(domScan.items)
      ? filterGalleryItemsForProject(filterUsableGalleryItems([...projectItems, ...domScan.items], galleryFilterOptions), scanProjectId)
      : filterGalleryItemsForProject(filterUsableGalleryItems(projectItems, galleryFilterOptions), scanProjectId);
    const domRecoveryAllowed = projectRows.length === 0
      || options.domRecovery === true
      || (projectReconciled.length === 0 && hasOpenImageTasks());
    const recoveryItems = domRecoveryAllowed
      ? items
      : [];
    const previousItems = runtimeState.lastGalleryProjectId === scanProjectId
      ? runtimeState.lastGalleryItems || []
      : [];
    const mergedItems = mergeGalleryItems(previousItems, items, galleryFilterOptions);
    runtimeState.lastGalleryItems = filterGalleryItemsForProject(filterUsableGalleryItems(mergedItems, galleryFilterOptions), scanProjectId);
    runtimeState.lastGalleryProjectId = scanProjectId;
    const reconciled = domRecoveryAllowed ? reconcileQueueWithGalleryItems(recoveryItems) : [];
    if (reconciled.length) {
      await autoDownloadCompletedTasks(reconciled.map((entry) => entry.taskId), "gallery_reconcile");
      await persistQueueState();
    }
    recordEvent({
      type: scan?.ok || domScan?.ok ? "gallery.scan.ok" : "gallery.scan.failed",
      count: mergedItems.length,
      projectReconciled: projectReconciled.length,
      domReconciled: reconciled.length,
      domRecoveryAllowed,
      error: scan?.error || domScan?.error || "",
      scanMeta: { ...(scan?.meta || {}), dom: domScan?.meta || null }
    });
    return {
      ok: Boolean(scan?.ok || domScan?.ok),
      error: scan?.error || domScan?.error || "",
      gallery: galleryState(mergedItems, mergedItems.length ? "project-feed+dom+queue-ledger" : "queue-ledger", scanProjectId),
      scan: { ok: Boolean(scan?.ok || domScan?.ok), projectFeed: scan, dom: domScan }
    };
  } catch (error) {
    const message = String(error?.message || error || "gallery_scan_failed");
    recordEvent({ type: "gallery.scan.error", error: message });
    return {
      ok: false,
      error: message,
      gallery: galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", runtimeState.lastGalleryProjectId),
      scan: { ok: false, error: message }
    };
  }
}

async function reconcileTaskFromKnownGallery(taskId, reason = "known_gallery") {
  const before = ledger.getTask(taskId);
  if (!before) return null;
  const items = runtimeState.lastGalleryItems || [];
  const reconciled = reconcileQueueWithGalleryItems(items);
  const entry = reconciled.find((patch) => patch.taskId === taskId) || null;
  if (reconciled.length) await persistQueueState();
  const after = ledger.getTask(taskId);
  if (entry) {
    recordEvent({
      type: "queue.image_reconcile",
      reason,
      taskId,
      status: after?.status || "",
      foundImages: after?.foundImages || 0,
      expectedImages: after?.expectedImages || before?.expectedImages || before?.repeatCount || 1
    });
  }
  return after;
}

function completeVideoTaskFromTerminalCapturedRows(task = {}, reason = "terminal_captured_rows") {
  if (!task?.id || taskMediaKind(task) !== "videos" || task.status !== TaskStatus.generating) return null;
  const rows = Array.isArray(task.statusRows) ? task.statusRows : [];
  const capturedIds = [...new Set((Array.isArray(task.mediaIds) ? task.mediaIds : [])
    .map((id) => String(id || "").trim())
    .filter(Boolean))];
  if (!capturedIds.length || !rows.length) return null;
  const expected = Math.max(1, Number(task.expectedVideos || task.repeatCount || capturedIds.length || 1) || 1);
  const rowById = new Map(rows.map((row) => [String(row?.id || "").trim(), row]));
  const capturedRows = capturedIds.map((id) => rowById.get(id)).filter(Boolean);
  if (capturedRows.length !== capturedIds.length) return null;
  if (!capturedRows.every((row) => row.status === "complete" || row.status === "failed")) return null;
  const completeRows = capturedRows.filter((row) => row.status === "complete");
  const failedRows = capturedRows.filter((row) => row.status === "failed");
  if (capturedIds.length < expected && !failedRows.length) {
    const submittedMs = Date.parse(String(task.submittedAt || ""));
    const ageMs = Number.isFinite(submittedMs) ? Date.now() - submittedMs : 0;
    const minPartialSettleMs = Math.max(90000, Math.min(240000, Number(task.videoPartialSettleMs || 120000) || 120000));
    if (ageMs < minPartialSettleMs) {
      recordEvent({
        type: "queue.video_terminal_partial_wait",
        reason,
        taskId: task.id,
        capturedIds: capturedIds.length,
        completeRows: completeRows.length,
        expectedVideos: expected,
        ageMs,
        minPartialSettleMs
      });
      return null;
    }
  }
  if (!completeRows.length) {
    return scheduler.markFailure(task.id, failureTextForStatusRows(capturedRows, "MEDIA_GENERATION_FAILED"));
  }
  const outputs = completeRows.map((row, mediaIndex) => ({
    id: `${task.id}:${row.id || mediaIndex}`,
    mediaId: row.id,
    mediaUrl: row.mediaUrl || buildMediaRedirectUrl({ mediaId: row.id }),
    thumbnailUrl: row.thumbnailUrl || buildMediaThumbnailUrl({ mediaId: row.id }),
    prompt: task.prompt || "",
    kind: "videos",
    status: row.status,
    rawStatus: row.rawStatus,
    workflowId: row.workflowId || "",
    mediaGenerationId: row.mediaGenerationId || row.workflowId || "",
    mediaIndex
  }));
  const next = scheduler.markComplete(task.id, {
    statusRows: rows,
    outputs,
    outputMediaIds: outputs.map((output) => output.mediaId),
    foundVideos: outputs.length,
    expectedVideos: expected,
    failedOutputCount: Math.max(0, expected - outputs.length) + failedRows.length,
    failedOutputMediaIds: failedRows.map((row) => row.id).filter(Boolean),
    partialFailure: outputs.length < expected,
    lastPollAt: new Date().toISOString()
  });
  recordEvent({
    type: "queue.video_terminal_captured_complete",
    reason,
    taskId: task.id,
    foundVideos: outputs.length,
    expectedVideos: expected,
    capturedIds: capturedIds.length
  });
  return next;
}

function completeVideoTaskFromPartialOutputs(task = {}, reason = "partial_outputs_timeout") {
  const now = new Date().toISOString();
  const patch = buildPartialVideoCompletionPatch(task, now);
  if (!patch) return null;
  const next = ledger.updateTask(task.id, patch);
  recordEvent({
    type: "queue.video_partial_complete",
    reason,
    taskId: task.id,
    foundVideos: patch.foundVideos,
    expectedVideos: patch.expectedVideos,
    missingOutputCount: patch.missingOutputCount,
    ageMs: Date.now() - (Date.parse(String(task.submittedAt || "")) || Date.now()),
    minPartialSettleMs: patch.videoPartialSettleMs
  });
  return next;
}

function blockUnmatchedFrontSubmitAfterTimeout(task = {}, reason = "video_reconcile_timeout") {
  if (!task?.id || task.status !== TaskStatus.generating || task.submitObservationRecovered !== true) return null;
  if (generatedDownloadIdsForTask(task).length || Number(task.foundVideos || 0) > 0 || (Array.isArray(task.statusRows) && task.statusRows.length)) return null;
  const submittedAtMs = Date.parse(String(task.submittedAt || task.submitAttemptStartedAt || ""));
  if (!Number.isFinite(submittedAtMs)) return null;
  const ageMs = Date.now() - submittedAtMs;
  const timeoutMs = Math.max(5 * 60 * 1000, Math.min(20 * 60 * 1000, Number(task.videoReconcileTimeoutMs || 12 * 60 * 1000) || 12 * 60 * 1000));
  if (ageMs < timeoutMs) return null;
  const error = "VIDEO_OUTPUT_RECONCILE_TIMEOUT_POSSIBLE_SIDE_EFFECT";
  const blocked = scheduler.markBlocked(task.id, error);
  ledger.updateTask(task.id, {
    lastError: error,
    failureClass: "output_reconcile_timeout",
    failureScope: "task",
    healAction: "inspect_flow_outputs",
    retryBlockedPossibleSideEffect: true,
    videoReconcileTimedOutAt: new Date().toISOString()
  });
  recordEvent({
    type: "queue.video_reconcile.timeout_blocked",
    reason,
    taskId: task.id,
    ageMs,
    timeoutMs,
    error
  });
  return ledger.getTask(task.id) || blocked;
}

async function waitForVideoTaskOutputs(task = {}, preferredTabId) {
  if (!task?.id || taskMediaKind(task) !== "videos") return task;
  let current = ledger.getTask(task.id) || task;
  if (current.status !== TaskStatus.generating) return current;

  const scanResult = await scanFlowGallery(preferredTabId, { auto: true, lightweight: true });
  current = ledger.getTask(task.id) || current;
  recordEvent({
    type: "queue.video_wait_scan",
    taskId: current.id,
    ok: Boolean(scanResult.ok),
    count: scanResult.gallery?.items?.length || 0,
    foundVideos: current.foundVideos || 0,
    expectedVideos: current.expectedVideos || current.repeatCount || 1,
    status: current.status || "",
    error: scanResult.error || ""
  });
  if (current.status === TaskStatus.complete) {
    await autoDownloadCompletedTasks([current.id], "video_reconcile");
    return current;
  }
  const terminal = completeVideoTaskFromTerminalCapturedRows(current, "queue_resume_or_handoff");
  if (terminal?.status === TaskStatus.complete) {
    await autoDownloadCompletedTasks([terminal.id], "video_terminal_captured");
    await persistQueueState();
    return terminal;
  }
  const partial = completeVideoTaskFromPartialOutputs(current, "queue_resume_or_handoff");
  if (partial?.status === TaskStatus.complete) {
    await autoDownloadCompletedTasks([partial.id], "video_partial_timeout");
    await persistQueueState();
    return partial;
  }
  const reconcileTimeout = blockUnmatchedFrontSubmitAfterTimeout(current, "queue_resume_or_handoff");
  if (reconcileTimeout) {
    await persistQueueState();
    return reconcileTimeout;
  }
  return ledger.getTask(task.id) || current;
}

function taskNeedsReadOnlySideEffectReconcile(task = {}) {
  return [TaskStatus.failed, TaskStatus.blocked].includes(task?.status)
    && (
      task.sideEffectRetryBlocked === true
      || task.possibleSideEffect === true
      || String(task.recoveryPolicy || "") === "reconcile_existing_media"
      || [
        "dom_submit_may_have_reached_google",
        "api_write_ambiguous_possible_side_effect",
        "generation_output_identity_missing_possible_side_effect",
        "video_output_identity_missing_possible_side_effect",
        "media_id_exists_reconcile_instead_of_resubmit"
      ].includes(String(task.failureClass || ""))
    );
}

async function reconcileSideEffectTaskAfterSubmit(task = {}, preferredTabId) {
  if (!taskNeedsReadOnlySideEffectReconcile(task)) return task;
  const initialFailureClass = String(task.failureClass || "");
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    if (attempt > 1) await sleep(1500);
    const scan = await scanFlowGallery(preferredTabId, { auto: true, lightweight: true });
    const current = ledger.getTask(task.id) || task;
    recordEvent({
      type: "queue.side_effect_readonly_reconcile",
      taskId: task.id,
      attempt,
      ok: Boolean(scan.ok),
      status: current.status || "",
      failureClass: initialFailureClass,
      mediaIds: current.outputMediaIds || current.mediaIds || [],
      error: scan.error || ""
    });
    if (current.status === TaskStatus.complete) return current;
  }
  return ledger.getTask(task.id) || task;
}

async function waitForImageTaskOutputs(task = {}, preferredTabId) {
  if (!task?.id || taskMediaKind(task) !== "images") return task;
  let current = ledger.getTask(task.id) || task;
  if (current.status !== TaskStatus.generating) return current;

  current = await reconcileTaskFromKnownGallery(task.id, "returned_ids") || current;
  if (current.status === TaskStatus.complete) {
    await autoDownloadCompletedTasks([current.id], "image_reconcile");
    return current;
  }

  const expected = Number(current.expectedImages || current.repeatCount || 1) || 1;
  const maxScans = Math.max(3, Math.min(18, Number(current.imageSettleScans || 10)));
  const settleMs = Math.max(3500, Math.min(12000, Number(current.imageSettleIntervalMs || 4000)));

  for (let scanIndex = 0; runtimeState.queueRunning && scanIndex < maxScans; scanIndex += 1) {
    recordEvent({
      type: "queue.image_wait",
      taskId: current.id,
      scanIndex: scanIndex + 1,
      maxScans,
      foundImages: current.foundImages || 0,
      expectedImages: expected
    });
    await sleep(scanIndex === 0 ? Math.min(3500, settleMs) : settleMs);
    const scanResult = await scanFlowGallery(preferredTabId);
    current = ledger.getTask(task.id) || current;
    recordEvent({
      type: "queue.image_scan",
      taskId: current.id,
      ok: scanResult.ok,
      count: scanResult.gallery?.items?.length || 0,
      foundImages: current.foundImages || 0,
      expectedImages: current.expectedImages || expected,
      status: current.status || "",
      error: scanResult.error || ""
    });
    if (current.status === TaskStatus.complete) {
      await autoDownloadCompletedTasks([current.id], "image_reconcile");
      return current;
    }
  }

  current = await reconcileTaskFromKnownGallery(task.id, "partial_timeout") || ledger.getTask(task.id) || current;
  const found = Number(current.foundImages || current.outputs?.length || current.outputMediaIds?.length || 0) || 0;
  if (current.status === TaskStatus.generating && found > 0 && found < expected) {
    current = ledger.updateTask(current.id, {
      status: TaskStatus.complete,
      completedAt: new Date().toISOString(),
      foundImages: found,
      expectedImages: expected,
      failedImages: expected - found,
      partialFailure: true,
      lastError: `PARTIAL_IMAGE_OUTPUTS:${found}/${expected}`,
      failureClass: "partial_image_outputs",
      failureScope: "task"
    });
    recordEvent({
      type: "queue.image_partial_complete",
      taskId: current.id,
      foundImages: found,
      expectedImages: expected,
      failedImages: expected - found
    });
    await autoDownloadCompletedTasks([current.id], "image_partial_timeout");
  }

  return ledger.getTask(task.id) || current;
}

function domFrontendSettleTimeoutMs(task = {}) {
  const explicit = Number(task.domFrontendSettleTimeoutMs || 0);
  if (explicit > 0) return Math.max(5000, Math.min(90000, explicit));
  return taskMediaKind(task) === "videos" ? 60000 : 45000;
}

function domFrontendSettleShouldReload(error = "", snapshot = {}) {
  const problems = Array.isArray(snapshot?.problems)
    ? snapshot.problems.map((problem) => String(problem || "").trim()).filter(Boolean)
    : [];
  const text = `${String(error || "")} ${problems.join(" ")}`.toLowerCase();
  return /flow_page_loading|flow_loading|editor_missing|editor_unstable|create_missing|create_unstable|settings_trigger_missing|settings_trigger_unstable/.test(text);
}

async function waitForDomFrontendReadyBeforeTask(task = {}, tabId = 0, reason = "before_submit") {
  if (!task?.id || !taskPrefersDom(task)) return { ok: true, skipped: true, reason: "not_dom_task" };
  const timeoutMs = domFrontendSettleTimeoutMs(task);
  const startedAt = Date.now();
  const deadline = startedAt + timeoutMs;
  let reloadAttempted = false;
  let last = null;
  let loggedWait = false;
  while (Date.now() < deadline && runtimeState.queueRunning) {
    const bridge = await ensureFlowBridge(tabId).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "flow_bridge_not_ready")
    }));
    if (!bridge?.ok) {
      last = { ok: false, error: bridge?.error || "flow_bridge_not_ready", snapshot: null };
    } else {
      last = await sendPageCommand({
        action: "composerReadyState",
        task: {
          id: task.id,
          mode: task.mode || "",
          prompt: task.prompt || ""
        },
        options: {
          allowDisabledCreate: true,
          allowMissingCreate: true
        },
        timeoutMs: 8000
      }, tabId).catch((error) => ({
        ok: false,
        error: String(error?.message || error || "composer_ready_state_failed"),
        snapshot: null
      }));
    }
    if (last?.ok === true) {
      recordEvent({
        type: "queue.dom_frontend_settle.ready",
        reason,
        taskId: task.id,
        mode: task.mode || "",
        elapsedMs: Date.now() - startedAt,
        reloaded: reloadAttempted,
        problems: last.snapshot?.problems || []
      });
      return { ok: true, elapsedMs: Date.now() - startedAt, reloaded: reloadAttempted };
    }
    const elapsedMs = Date.now() - startedAt;
    const problems = Array.isArray(last?.snapshot?.problems) ? last.snapshot.problems : [];
    if (!loggedWait || elapsedMs > 5000) {
      loggedWait = true;
      recordEvent({
        type: "queue.dom_frontend_settle.wait",
        reason,
        taskId: task.id,
        mode: task.mode || "",
        elapsedMs,
        error: last?.error || "",
        problems
      });
    }
    if (!reloadAttempted && elapsedMs >= 5500 && domFrontendSettleShouldReload(last?.error || "", last?.snapshot || {})) {
      const tabReload = await reloadFlowTab(tabId).catch((error) => ({
        ok: false,
        error: String(error?.message || error || "tab_reload_failed")
      }));
      reloadAttempted = true;
      recordEvent({
        type: "queue.dom_frontend_settle.reload",
        reason,
        taskId: task.id,
        mode: task.mode || "",
        elapsedMs,
        error: last?.error || "",
        problems,
        tabReloaded: tabReload?.ok === true,
        reloadError: tabReload?.error || ""
      });
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      const projectId = String(task.projectId || projectIdFromUrl(tab?.url || "") || runtimeState.projectId || "").trim();
      if (projectId) {
        await waitForFlowProjectRoot(tabId, projectId).catch(() => null);
      }
      await sleep(1800);
      continue;
    }
    await sleep(700);
  }
  recordEvent({
    type: "queue.dom_frontend_settle.timeout",
    reason,
    taskId: task.id || "",
    mode: task.mode || "",
    elapsedMs: Date.now() - startedAt,
    error: last?.error || "",
    problems: last?.snapshot?.problems || [],
    reloaded: reloadAttempted
  });
  return {
    ok: false,
    error: last?.error || "DOM_FRONTEND_NOT_READY",
    reloaded: reloadAttempted,
    elapsedMs: Date.now() - startedAt
  };
}

async function recoverImageTaskAfterSubmitFailure(task = {}, preferredTabId, reason = "submit_failure_project_feed") {
  if (!task?.id || taskMediaKind(task) !== "images") return task;
  const current = ledger.getTask(task.id) || task;
  if (!current?.id || current.status === TaskStatus.complete || current.status === TaskStatus.generating) return current;
  const attempts = Number(current.attempts || 0);
  if (attempts <= 0) return current;
  const errorText = String(current.lastError || current.failureClass || "");
  if (!/DOM_DEBUGGER|REF_NOT_SERIALIZED|REQUEST_NOT_OBSERVED|NO_REQUEST|meta is not defined/i.test(errorText)) return current;

  const tab = await findFlowTab(preferredTabId);
  const tabProjectId = projectIdFromUrl(tab?.url || "");
  let scanResult = { ok: false, error: "flow_tab_not_found", rows: [] };
  if (tab?.id) {
    const bridge = await ensureFlowBridge(tab.id);
    if (bridge?.ok) {
      scanResult = await sendPageCommand({
        action: "projectGeneratedMedia",
        projectId: tabProjectId || runtimeState.projectId || current.projectId || "",
        maxProjectMedia: 500,
        timeoutMs: 20000
      }, tab.id).catch((error) => ({ ok: false, error: String(error?.message || error || "project_feed_failed"), rows: [] }));
    } else {
      scanResult = { ok: false, error: bridge?.error || "flow_bridge_not_ready", rows: [] };
    }
  }
  const rows = scanResult?.ok && Array.isArray(scanResult.rows) ? scanResult.rows : [];
  const recoverableTask = {
    ...current,
    status: TaskStatus.generating,
    submittedAt: current.submittedAt || current.submitAttemptStartedAt || new Date().toISOString(),
    expectedImages: Number(current.expectedImages || current.repeatCount || 1) || 1
  };
  const patchEntry = reconcileTasksWithProjectMediaFeed([recoverableTask], rows).find((entry) => entry.taskId === current.id) || null;
  if (patchEntry) {
    ledger.updateTask(current.id, {
      ...patchEntry.patch,
      submitFailureRecoveredFromProjectFeed: true,
      submitFailureRecoveredAt: new Date().toISOString()
    });
  }
  const after = ledger.getTask(current.id) || current;
  recordEvent({
    type: "queue.image_submit_failure_reconcile",
    reason,
    taskId: current.id,
    ok: Boolean(scanResult.ok),
    projectRows: rows.length,
    matchedCount: patchEntry?.matchedCount || 0,
    status: after.status || "",
    foundImages: after.foundImages || 0,
    expectedImages: after.expectedImages || current.expectedImages || current.repeatCount || 1,
    outputMediaIds: Array.isArray(after.outputMediaIds) ? after.outputMediaIds : [],
    error: scanResult.error || ""
  });
  if (after.status === TaskStatus.complete) {
    await autoDownloadCompletedTasks([after.id], "image_submit_failure_reconcile");
    await persistQueueState();
  }
  return after;
}

function pruneDownloadReservations(now = Date.now()) {
  for (const [key, value] of downloadReservations.artifacts.entries()) {
    if (now - Number(value?.at || 0) > DOWNLOAD_RESERVATION_TTL_MS) {
      downloadReservations.artifacts.delete(key);
    }
  }
  for (const [key, value] of downloadReservations.targets.entries()) {
    if (now - Number(value?.at || 0) > DOWNLOAD_RESERVATION_TTL_MS) {
      downloadReservations.targets.delete(key);
    }
  }
}

function extractMediaIdFromDownloadUrl(url = "") {
  const text = String(url || "");
  if (!text) return "";
  try {
    const parsed = new URL(text);
    const name = parsed.searchParams.get("name");
    if (name) return name;
    const mediaPath = parsed.pathname.match(/\/(?:video|image)\/([^/?#]+)/i);
    if (mediaPath?.[1]) return mediaPath[1];
  } catch {}
  return "";
}

function prunePendingNativeDownloadFilenames(now = Date.now()) {
  for (let index = pendingNativeDownloadFilenames.length - 1; index >= 0; index -= 1) {
    if (now - Number(pendingNativeDownloadFilenames[index]?.at || 0) > 30000) {
      pendingNativeDownloadFilenames.splice(index, 1);
    }
  }
}

function registerNativeDownloadFilename(url, filename) {
  prunePendingNativeDownloadFilenames();
  pendingNativeDownloadFilenames.push({
    at: Date.now(),
    url: String(url || ""),
    mediaId: extractMediaIdFromDownloadUrl(url),
    filename: String(filename || "")
  });
}

function takePendingNativeDownloadFilename(downloadItem = {}) {
  prunePendingNativeDownloadFilenames();
  const urls = new Set([
    String(downloadItem.url || ""),
    String(downloadItem.finalUrl || "")
  ].filter(Boolean));
  const mediaIds = new Set([
    extractMediaIdFromDownloadUrl(downloadItem.url),
    extractMediaIdFromDownloadUrl(downloadItem.finalUrl)
  ].filter(Boolean));
  const index = pendingNativeDownloadFilenames.findIndex((entry) => {
    if (entry.url && urls.has(entry.url)) return true;
    return entry.mediaId && mediaIds.has(entry.mediaId);
  });
  if (index < 0) return null;
  const [entry] = pendingNativeDownloadFilenames.splice(index, 1);
  return entry;
}

function reserveDownloadPlan(plan = {}) {
  pruneDownloadReservations();
  const artifactKey = String(plan.artifactKey || `${plan.taskId || plan.itemId || "unknown"}:${plan.mediaId || ""}`);
  const targetPathKey = String(plan.targetPathKey || plan.filename || "");
  if (artifactKey && downloadReservations.artifacts.has(artifactKey)) {
    return { ok: false, reason: "duplicate_artifact", artifactKey, targetPathKey };
  }
  if (targetPathKey && downloadReservations.targets.has(targetPathKey)) {
    return { ok: false, reason: "duplicate_target_path", artifactKey, targetPathKey };
  }
  const record = {
    at: Date.now(),
    itemId: plan.itemId || "",
    taskId: plan.taskId || "",
    mediaId: plan.mediaId || "",
    filename: plan.filename || ""
  };
  if (artifactKey) downloadReservations.artifacts.set(artifactKey, record);
  if (targetPathKey) downloadReservations.targets.set(targetPathKey, record);
  return { ok: true, reason: "allowed", artifactKey, targetPathKey };
}

function releaseDownloadReservation(reservation = {}) {
  const artifactKey = String(reservation.artifactKey || "");
  const targetPathKey = String(reservation.targetPathKey || "");
  if (artifactKey) downloadReservations.artifacts.delete(artifactKey);
  if (targetPathKey) downloadReservations.targets.delete(targetPathKey);
}

function queueBlockers() {
  return ledger.listTasks().filter((task) => [TaskStatus.failed, TaskStatus.blocked].includes(task.status));
}

function resumeBlockedQueueTasks(options = {}) {
  let resumed = 0;
  const browserModeTaskId = compactString(options.browserModeTaskId || options.taskId || "");
  const onlyBrowserModeRecovery = options.onlyBrowserModeRecovery === true;
  for (const task of queueBlockers()) {
    if (onlyBrowserModeRecovery && !taskSignalsApiFirstDomAvailable(task) && browserModeTaskId !== task.id) continue;
    const scopedRetryOriginalMode = browserModeTaskId && browserModeTaskId !== task.id
      ? task.retryOriginalMode || ""
      : options.retryOriginalMode || task.retryOriginalMode || "";
    const retryTask = buildRetryModalTask({
      ...task,
      retryOriginalMode: scopedRetryOriginalMode,
      reason: options.reason || task.reason || task.lastError || task.failureClass || ""
    });
    const patch = {
      status: TaskStatus.pending,
      attempts: 0,
      resumedAt: new Date().toISOString(),
      previousFailureClass: task.failureClass || "",
      previousLastError: task.lastError || "",
      ...(retryTask ? {
        mode: retryTask.mode || task.mode,
        reason: retryTask.reason || task.reason || task.lastError || "",
        retryOriginalMode: retryTask.retryOriginalMode || "",
        retrySurface: retryTask.retrySurface || "",
        retryInputRoles: retryTask.retryInputRoles || [],
        retryFrameSlots: retryTask.retryFrameSlots || [],
        retryMaxInputs: retryTask.retryMaxInputs,
        retryPromptFirst: retryTask.retryPromptFirst === true,
        retryEditSurface: retryTask.retryEditSurface || null,
        refInputs: retryTask.refInputs || [],
        refMediaIds: retryTask.refMediaIds || [],
        startRefInput: retryTask.startRefInput || null,
        endRefInput: retryTask.endRefInput || null,
        startMediaId: retryTask.startMediaId || "",
        endMediaId: retryTask.endMediaId || ""
      } : {})
    };
    if ((browserModeTaskId && browserModeTaskId === task.id) || onlyBrowserModeRecovery) {
      patch.submitPathPreference = "dom_first";
      patch.submitPath = "dom_first";
      patch.browserModeRetryRequestedAt = new Date().toISOString();
    }
    ledger.updateTask(task.id, patch);
    resumed += 1;
  }
  return resumed;
}

function taskSignalsApiFirstDomAvailable(task = {}) {
  return task?.apiFirstQuotaSuspected === true &&
    task?.domVerificationAttempted === true &&
    (
      task?.domVerificationResult === "success" ||
      task?.finalQuotaClassification === "api_first_blocked_dom_available" ||
      task?.failureClass === "api_first_blocked_dom_available"
    );
}

async function switchApiFirstRowsToBrowserMode({ sourceTaskId = "", recoveryUiProbe = {} } = {}) {
  const queueRunnerAliveBeforeSwitch = runtimeState.queueRunning === true;
  const plan = buildBrowserModeRecoveryPlan(ledger.listTasks(), {
    sourceTaskId,
    recoveryUiProbe,
    queueRunnerAliveBeforeSwitch,
    now: Date.now()
  });
  if (plan.skippedBecauseModelAccess === true) {
    if (plan.sourceTaskId && ledger.getTask(plan.sourceTaskId)) {
      ledger.updateTask(plan.sourceTaskId, {
        recoverySkippedBecauseModelAccess: true,
        recoveryActionError: plan.recoveryActionError || "model_access_denied_hard_stop"
      });
    }
    recordEvent({
      type: "queue.api_first_dom_available.continue_browser_mode_blocked",
      sourceTaskId: plan.sourceTaskId || sourceTaskId,
      error: plan.error || "model_access_denied_hard_stop",
      recoverySkippedBecauseModelAccess: true
    });
    return plan;
  }
  if (plan.patches.length && runtimeState.queueRunning) {
    runtimeState.queueRunToken = Number(runtimeState.queueRunToken || 0) + 1;
    runtimeState.queueRunning = false;
    await releaseDebuggerSessions("browser_mode_recovery_switch", recordDebuggerTrace).catch(() => null);
    recordEvent({
      type: "queue.api_first_dom_available.runner_reset_for_browser_mode",
      sourceTaskId: plan.sourceTaskId || sourceTaskId,
      runToken: runtimeState.queueRunToken
    });
  }
  for (const entry of plan.patches) {
    if (!entry.taskId || !ledger.getTask(entry.taskId)) continue;
    ledger.updateTask(entry.taskId, entry.patch || {});
  }
  recordEvent({
    type: "queue.api_first_dom_available.continue_browser_mode",
    sourceTaskId: plan.sourceTaskId || sourceTaskId,
    switched: plan.switched,
    switchedIds: plan.switchedIds,
    requeuedIds: plan.requeuedIds,
    preservedCompletedIds: plan.preservedCompletedIds,
    completedBeforeSwitch: plan.completedBeforeSwitch,
    pendingBeforeSwitch: plan.pendingBeforeSwitch,
    completedAfterSwitch: plan.completedAfterSwitch,
    pendingAfterSwitch: plan.pendingAfterSwitch,
    queueRunnerAliveBeforeSwitch: plan.queueRunnerAliveBeforeSwitch,
    staleSubmittingDetected: plan.staleSubmittingDetected,
    staleSubmittingTaskId: plan.staleSubmittingTaskId,
    staleSubmittingAgeMs: plan.staleSubmittingAgeMs,
    staleSubmittingResolution: plan.staleSubmittingResolution,
    recoveryActionError: plan.recoveryActionError || "",
    recoveryUiProbe
  });
  return plan;
}

function waitForDownloadComplete(downloadId, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 180000);
  return new Promise((resolve) => {
    const startedAt = Date.now();
    let settled = false;
    let pollTimer = null;
    let timeoutTimer = null;
    const cleanup = () => {
      if (pollTimer) clearInterval(pollTimer);
      if (timeoutTimer) clearTimeout(timeoutTimer);
      try { chrome.downloads.onChanged.removeListener(onChanged); } catch {}
    };
    const settle = (payload) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(payload);
    };
    const resolveAfterRemovingInvalidFile = (item = {}, payload = {}) => {
      const done = () => settle(payload);
      if (!downloadId) {
        done();
        return;
      }
      try {
        chrome.downloads.removeFile(downloadId, () => {
          chrome.downloads.erase({ id: downloadId }, () => done());
        });
      } catch {
        done();
      }
    };
    const finish = (item = {}, error = "") => {
      if (settled) return;
      const bytes = Number(item.bytesReceived || item.fileSize || item.totalBytes || 0);
      const durationMs = Date.now() - startedAt;
      const minBytes = minValidDownloadBytes(item.filename || options.filename || "", options);
      const invalidReason = invalidCompletedDownloadReason(item, options);
      if (invalidReason) {
        resolveAfterRemovingInvalidFile(item, {
          ok: false,
          error: invalidReason,
          downloadId,
          bytesReceived: bytes,
          fileSize: Number(item.fileSize || 0),
          filename: item.filename || "",
          durationMs,
          removedInvalidFile: true
        });
        return;
      }
      if (error) {
        settle({ ok: false, error, downloadId, bytesReceived: bytes, fileSize: Number(item.fileSize || 0), filename: item.filename || "", durationMs });
        return;
      }
      if (bytes < minBytes) {
        resolveAfterRemovingInvalidFile(item, {
          ok: false,
          error: `download_too_small:${bytes}<${minBytes}`,
          downloadId,
          bytesReceived: bytes,
          fileSize: Number(item.fileSize || 0),
          filename: item.filename || "",
          durationMs,
          removedInvalidFile: true
        });
        return;
      }
      settle({ ok: true, downloadId, bytesReceived: bytes, fileSize: Number(item.fileSize || 0), filename: item.filename || "", durationMs });
    };
    const inspect = () => {
      if (settled) return;
      chrome.downloads.search({ id: downloadId }, (items) => {
        if (settled) return;
        const item = items?.[0] || {};
        if (item.state === "complete") finish(item);
        else if (item.state === "interrupted") finish(item, item.error || "download_interrupted");
      });
    };
    function onChanged(delta = {}) {
      if (Number(delta.id) !== Number(downloadId)) return;
      const state = String(delta.state?.current || "");
      if (state === "complete" || state === "interrupted") inspect();
    }
    try { chrome.downloads.onChanged.addListener(onChanged); } catch {}
    // Events remove the old 500ms completion floor. A sparse poll remains as
    // a service-worker-safe fallback if Chrome delivered completion before the
    // listener was attached or the worker resumed after suspension.
    pollTimer = setInterval(inspect, 2000);
    timeoutTimer = setTimeout(() => {
      chrome.downloads.search({ id: downloadId }, (items) => {
        const item = items?.[0] || {};
        finish(item, "download_timeout");
      });
    }, timeoutMs);
    inspect();
  });
}

function downloadFile(url, filename, options = {}) {
  return new Promise((resolve) => {
    registerNativeDownloadFilename(url, filename);
    chrome.downloads.download({
      url,
      filename,
      conflictAction: "uniquify"
    }, (downloadId) => {
      const error = chromeCallbackError();
      if (error) {
        resolve({ ok: false, error, downloadId: null });
        return;
      }
      if (!downloadId) {
        resolve({ ok: false, error: "download_not_started", downloadId: null });
        return;
      }
      waitForDownloadComplete(downloadId, { ...options, filename }).then(resolve);
    });
  });
}

async function downloadFileWithReadinessRetries(url, filename, plan = {}, options = {}) {
  const delays = resolveDownloadMediaKind(plan.kind || plan.mediaKind, plan.filename) === "videos" ? [12000, 24000, 45000] : [];
  const startedAt = Date.now();
  let result = await downloadFile(url, filename, options);
  let retryWaitMs = 0;
  let attempts = 1;
  const fallbackUrl = String(plan.fallbackDownloadUrl || "").trim();
  if (shouldRetryTinyVideoDownload(result, plan) && fallbackUrl && fallbackUrl !== url) {
    recordEvent({
      type: "media.download.fallback_url",
      mediaId: plan.mediaId || "",
      taskId: plan.taskId || "",
      filename,
      error: result.error || "",
      fromUrl: summarizeDownloadUrl(url || ""),
      toUrl: summarizeDownloadUrl(fallbackUrl)
    });
    result = await downloadFile(fallbackUrl, filename, options);
    attempts += 1;
  }
  for (let attempt = 0; shouldRetryTinyVideoDownload(result, plan) && attempt < delays.length; attempt += 1) {
    const waitMs = delays[attempt];
    retryWaitMs += waitMs;
    recordEvent({
      type: "media.download.retry_wait",
      mediaId: plan.mediaId || "",
      taskId: plan.taskId || "",
      filename,
      error: result.error || "",
      attempt: attempt + 1,
      waitMs
    });
    await sleep(waitMs);
    result = await downloadFile(url, filename, options);
    attempts += 1;
  }
  return {
    ...result,
    attempts,
    retryWaitMs,
    totalDurationMs: Date.now() - startedAt
  };
}

function captureAuthEnvironment(payload = {}) {
  if (!payload.environment || typeof payload.environment !== "object") return;
  runtimeState.authEnvironment = {
    userAgent: String(payload.environment.userAgent || ""),
    screen: {
      width: Number(payload.environment.screen?.width || 0),
      height: Number(payload.environment.screen?.height || 0)
    }
  };
}

function chromeCallbackError() {
  return chrome.runtime.lastError ? String(chrome.runtime.lastError.message || chrome.runtime.lastError) : "";
}

async function findFlowTab(preferredTabId) {
  let preferredTab = null;
  if (Number.isInteger(preferredTabId)) {
    preferredTab = await chrome.tabs.get(preferredTabId).catch(() => null);
    if (!preferredTab?.id || !isFlowToolUrl(preferredTab.url || "")) preferredTab = null;
  }

  const runtimePreferredId = Number(runtimeState.activeTabId || 0);
  let runtimePreferredTab = null;
  if (Number.isInteger(runtimePreferredId) && runtimePreferredId > 0 && runtimePreferredId !== preferredTabId) {
    runtimePreferredTab = await chrome.tabs.get(runtimePreferredId).catch(() => null);
    if (!runtimePreferredTab?.id || !isFlowToolUrl(runtimePreferredTab.url || "")) runtimePreferredTab = null;
  }

  const tabs = await chrome.tabs.query({
    url: [
      "https://labs.google/fx/tools/flow*",
      "https://labs.google/fx/*/tools/flow*",
      "https://labs.google.com/fx/tools/flow*",
      "https://labs.google.com/fx/*/tools/flow*"
    ]
  });
  const exact = tabs.filter((tab) => tab.id && isFlowToolUrl(tab.url || ""));
  const projectTabs = exact.filter((tab) => projectIdFromUrl(tab.url || ""));
  const newestProject = [...projectTabs].sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0] || null;
  const newestLoadedProject = [...projectTabs]
    .filter((tab) => tab.status !== "unloaded" && tab.discarded !== true)
    .sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0] || null;
  const preferredProject = preferredTab?.id && projectIdFromUrl(preferredTab.url || "")
    ? projectTabs.find((tab) => Number(tab.id || 0) === Number(preferredTab.id || 0)) || preferredTab
    : null;
  const runtimeBound = runtimePreferredId
    ? projectTabs.find((tab) => Number(tab.id || 0) === runtimePreferredId)
      || (runtimePreferredTab?.id && projectIdFromUrl(runtimePreferredTab.url || "") ? runtimePreferredTab : null)
    : null;
  const activeProject = projectTabs.find((tab) => tab.active);
  const matchingProject = runtimeState.projectId
    ? projectTabs.find((tab) => projectIdFromUrl(tab.url || "") === runtimeState.projectId)
    : null;
  const exactProject = projectTabs[0] || null;
  if (preferredProject || activeProject || newestLoadedProject || matchingProject || runtimeBound || newestProject || exactProject) {
    return preferredProject || activeProject || newestLoadedProject || matchingProject || runtimeBound || newestProject || exactProject;
  }
  if (exact[0]) return exact[0];

  const allTabs = await chrome.tabs.query({}).catch(() => []);
  const broad = allTabs.filter((tab) => tab.id && isFlowToolUrl(tab.url || ""));
  return broad.find((tab) => projectIdFromUrl(tab.url || "")) || broad[0] || null;
}

async function listFlowProjectTabs() {
  const patterns = [
    "https://labs.google/fx/tools/flow*",
    "https://labs.google/fx/*/tools/flow*",
    "https://labs.google.com/fx/tools/flow*",
    "https://labs.google.com/fx/*/tools/flow*"
  ];
  const tabs = await chrome.tabs.query({ url: patterns }).catch(() => []);
  const exact = tabs.filter((tab) => tab.id && isFlowToolUrl(tab.url || ""));
  const projectTabs = exact.filter((tab) => projectIdFromUrl(tab.url || ""));
  if (projectTabs.length) return projectTabs;

  const allTabs = await chrome.tabs.query({}).catch(() => []);
  return allTabs.filter((tab) => tab.id && isFlowToolUrl(tab.url || "") && projectIdFromUrl(tab.url || ""));
}

function normalizeAgentBridgeFlowTab(tab = {}, options = {}) {
  const tabId = Number(tab.id || 0) || null;
  const projectId = compactString(projectIdFromUrl(tab.url || ""));
  const laneId = compactString(options.laneId || "") || (tabId ? `flow-tab-${tabId}` : "");
  return {
    tabId,
    projectId,
    title: compactString(tab.title || ""),
    url: compactString(tab.url || ""),
    active: tab.active === true,
    windowId: Number.isFinite(Number(tab.windowId)) ? Number(tab.windowId) : null,
    index: Number.isFinite(Number(tab.index)) ? Number(tab.index) : null,
    status: compactString(tab.status || ""),
    discarded: tab.discarded === true,
    lastAccessed: Number.isFinite(Number(tab.lastAccessed)) ? Number(tab.lastAccessed) : null,
    isRuntimeTarget: Boolean(
      tabId && Number(runtimeState.activeTabId || 0) === tabId
        || (projectId && runtimeState.projectId && projectId === runtimeState.projectId)
    ),
    target: {
      projectId,
      tabId: tabId ? String(tabId) : "",
      laneId
    }
  };
}

async function listAgentBridgeFlowTabs(payload = {}) {
  const requestedProjectId = compactString(payload.projectId || "");
  const allTabs = await listFlowProjectTabs();
  const filtered = requestedProjectId
    ? allTabs.filter((tab) => projectIdFromUrl(tab.url || "") === requestedProjectId)
    : allTabs;
  const tabs = filtered
    .map((tab) => normalizeAgentBridgeFlowTab(tab, { laneId: payload.laneId }))
    .filter((tab) => tab.tabId && tab.projectId)
    .sort((a, b) => {
      if (a.isRuntimeTarget !== b.isRuntimeTarget) return a.isRuntimeTarget ? -1 : 1;
      if (a.active !== b.active) return a.active ? -1 : 1;
      return Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0);
    });
  const active = tabs.find((tab) => tab.isRuntimeTarget) || tabs.find((tab) => tab.active) || tabs[0] || null;
  return {
    ok: true,
    project: compactString(payload.project || "current"),
    requestedProjectId,
    activeTabId: active?.tabId || runtimeState.activeTabId || null,
    activeProjectId: active?.projectId || runtimeState.projectId || "",
    count: tabs.length,
    tabs,
    targets: tabs.map((tab) => tab.target)
  };
}

async function setAgentBridgeLaneIndicator(payload = {}) {
  const laneId = compactString(payload.laneId || payload.name || "");
  const tabId = Number(payload.tabId || payload.activeTabId || 0) || 0;
  if (!laneId) throw agentBridgeError("LANE_NAME_MISSING", "Lane indicator requires a lane name.");
  if (!tabId) throw agentBridgeError("LANE_TAB_MISSING", `Lane ${laneId} indicator requires a Chrome tab id.`);
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab?.id || !isFlowToolUrl(tab.url || "")) {
    throw agentBridgeError(
      "LANE_TARGET_GONE",
      `Lane ${laneId} is bound to tab ${tabId}, but that Flow tab is gone. Re-bind with autoflow lane use ${laneId} --project-id <projectId> --tab-id <tabId>.`,
      { laneId, tabId: String(tabId), projectId: compactString(payload.projectId || "") }
    );
  }
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: String(tabId),
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  const connected = payload.connected !== false;
  const injections = await chrome.scripting.executeScript({
    target: { tabId, allFrames: false },
    args: [laneId, connected],
    func: (name, isConnected) => {
      const clean = (value) => String(value || "").replace(/^\[AF:[^\]]+\]\s*/i, "").trim();
      const safeName = String(name || "").trim().slice(0, 48);
      const state = isConnected ? "connected" : "disconnected";
      const title = clean(document.title || "Google Flow") || "Google Flow";
      document.title = `[AF:${safeName} ${state}] ${title}`;

      const id = "autoflow-lane-indicator";
      let badge = document.getElementById(id);
      if (!badge) {
        badge = document.createElement("div");
        badge.id = id;
        badge.setAttribute("role", "status");
        badge.style.position = "fixed";
        badge.style.top = "10px";
        badge.style.right = "10px";
        badge.style.zIndex = "2147483647";
        badge.style.maxWidth = "260px";
        badge.style.padding = "6px 8px";
        badge.style.borderRadius = "6px";
        badge.style.font = "600 12px/1.25 system-ui, -apple-system, BlinkMacSystemFont, sans-serif";
        badge.style.boxShadow = "0 6px 18px rgba(0, 0, 0, 0.22)";
        badge.style.pointerEvents = "none";
        document.documentElement.appendChild(badge);
      }
      badge.textContent = `Auto Flow lane: ${safeName} (${state})`;
      badge.style.background = isConnected ? "#0f766e" : "#991b1b";
      badge.style.color = "#fff";
      badge.style.border = "1px solid rgba(255, 255, 255, 0.35)";
      return {
        title: document.title,
        badgeText: badge.textContent
      };
    }
  });
  const indicator = injections?.[0]?.result || {};
  recordEvent({
    type: "agent_bridge.lane_indicator.set",
    laneId,
    tabId,
    projectId,
    connected,
    title: compactString(indicator.title || "")
  });
  return {
    ok: true,
    laneId,
    connected,
    projectId,
    page: {
      tabId,
      url: tab.url || "",
      title: tab.title || ""
    },
    indicator
  };
}

function agentBridgeProjectRootUrl(url = "", projectId = "") {
  const id = compactString(projectId || projectIdFromUrl(url));
  if (!id) return "";
  try {
    const parsed = new URL(url || "https://labs.google/fx/tools/flow");
    const match = parsed.pathname.match(/^(.*\/tools\/flow\/project\/)[^/]+/);
    parsed.pathname = match ? `${match[1]}${id}` : `/fx/tools/flow/project/${id}`;
    parsed.search = "";
    parsed.hash = "";
    return parsed.toString();
  } catch {
    return `https://labs.google/fx/tools/flow/project/${id}`;
  }
}

async function ensureAgentBridgeProjectRootTab(tab = {}, projectId = "") {
  const id = compactString(projectId || projectIdFromUrl(tab.url || ""));
  const rootUrl = agentBridgeProjectRootUrl(tab.url || "", id);
  if (!tab?.id || !id || !rootUrl) return tab;
  const currentUrl = compactString(tab.url || "");
  const needsNavigation = currentUrl !== rootUrl || /\/project\/[^/]+\/edit\//i.test(currentUrl) || projectIdFromUrl(currentUrl) !== id;
  const updated = needsNavigation ? await chrome.tabs.update(tab.id, { url: rootUrl, active: true }).catch(() => null) : tab;
  const deadline = Date.now() + 12000;
  let latest = updated || tab;
  while (Date.now() < deadline) {
    await sleep(250);
    latest = await chrome.tabs.get(tab.id).catch(() => latest);
    const href = compactString(latest?.url || "");
    if (href === rootUrl || (projectIdFromUrl(href) === id && !/\/project\/[^/]+\/edit\//i.test(href))) {
      await normalizeAgentProjectSurfaceWithDebugger(tab.id, { stage: "project_root" });
      await waitForAgentBridgeStableProjectComposer(tab.id, id, { timeoutMs: 15000 });
      return latest;
    }
  }
  throw agentBridgeError(
    "AGENT_FLOW_PROJECT_ROOT_NAVIGATION_FAILED",
    "Flow Agent tab could not be returned to the project root before submit.",
    { tabId: tab.id, projectId: id, fromUrl: currentUrl, rootUrl, latestUrl: latest?.url || "" }
  );
}

async function waitForAgentBridgeProjectComposer(tabId, projectId = "", options = {}) {
  const timeoutMs = Number(options.timeoutMs || 15000) || 15000;
  const deadline = Date.now() + timeoutMs;
  let last = null;
  while (Date.now() < deadline) {
    last = await probeAgentBridgeProjectComposer(tabId, projectId).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "agent_project_composer_probe_failed")
    }));
    if (last?.ok === true) return last;
    await sleep(400);
  }
  throw agentBridgeError(
    "AGENT_FLOW_COMPOSER_NOT_READY",
    "Flow Agent project root did not expose a positively identified editable composer before submit.",
    { tabId, projectId: compactString(projectId), last }
  );
}

async function waitForAgentBridgeStableProjectComposer(tabId, projectId = "", options = {}) {
  const timeoutMs = Number(options.timeoutMs || 10000) || 10000;
  const deadline = Date.now() + timeoutMs;
  let last = null;
  let stableSamples = 0;
  let lastKey = "";
  while (Date.now() < deadline) {
    last = await probeAgentBridgeProjectComposer(tabId, projectId).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "agent_stable_composer_probe_failed")
    }));
    const rect = last?.composer?.editorRect || {};
    const fingerprint = last?.composer?.editorFingerprint || {};
    const key = last?.ok === true && last?.composer?.generationActive !== true
      ? [
          Math.round(Number(rect.x || 0)),
          Math.round(Number(rect.y || 0)),
          Math.round(Number(rect.width || 0)),
          Math.round(Number(rect.height || 0)),
          compactString(fingerprint.tag),
          compactString(fingerprint.role),
          compactString(fingerprint.contentEditable),
          fingerprint.dataSlateEditor === true ? "slate" : ""
        ].join(":")
      : "";
    if (key && key === lastKey) stableSamples += 1;
    else stableSamples = key ? 1 : 0;
    lastKey = key;
    if (stableSamples >= 3) return last;
    await sleep(250);
  }
  throw agentBridgeError(
    "AGENT_FLOW_COMPOSER_NOT_STABLE",
    "Flow Agent composer did not reach stable geometry after surface normalization.",
    { tabId, projectId: compactString(projectId), last, stableSamples }
  );
}

async function probeAgentBridgeProjectComposer(tabId, projectId = "") {
  const injections = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    args: [compactString(projectId)],
    func: (expectedProjectId) => {
      const compact = (value = "") => String(value || "").replace(/\s+/g, " ").trim();
      const textOf = (element) => compact(element?.value || element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "");
      const visible = (element) => {
        if (!element || !element.getBoundingClientRect) return false;
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
      };
      const rectOf = (element) => {
        const rect = element.getBoundingClientRect();
        return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
      };
      const materialIconTokens = (element) => new Set(String(element?.textContent || "").split(/\s+/).map((token) => token.trim()).filter(Boolean));
      const allDeep = (selector) => {
        const out = [];
        const roots = [document];
        const seen = new Set();
        for (let index = 0; index < roots.length; index += 1) {
          const root = roots[index];
          if (!root || seen.has(root)) continue;
          seen.add(root);
          try {
            out.push(...Array.from(root.querySelectorAll(selector)));
            Array.from(root.querySelectorAll("*")).forEach((node) => {
              if (node.shadowRoot) roots.push(node.shadowRoot);
            });
          } catch {}
        }
        return out;
      };
      const href = String(location.href || "");
      const projectOk = !expectedProjectId || href.includes(`/project/${expectedProjectId}`);
      const editRoute = /\/project\/[^/]+\/edit\//i.test(href);
      const separator = allDeep("[aria-label*='Resize agent panel' i],[role='separator']")
        .find((element) => visible(element) && /resize agent panel/i.test(textOf(element)));
      const separatorRect = separator?.getBoundingClientRect?.();
      const agentPanelLeft = separatorRect ? Math.max(0, separatorRect.x + separatorRect.width - 24) : window.innerWidth * 0.55;
      const isSearchLikeEditable = (element) => /search|filter|name|title/i.test(compact([
        element?.getAttribute?.("aria-label") || "",
        element?.getAttribute?.("placeholder") || "",
        element?.getAttribute?.("type") || ""
      ].join(" ")));
      const editors = allDeep("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']")
        .filter((element) => visible(element) && !element.disabled && !element.readOnly)
        .map((element) => {
          const rect = element.getBoundingClientRect();
          const text = textOf(element);
          const rightPanel = rect.x >= agentPanelLeft;
          const lowerHalf = rect.y > window.innerHeight * 0.45;
          return {
            element,
            text,
            rect,
            score: (rightPanel ? 10000 : 0) + (lowerHalf ? 5000 : 0) + (text ? 2000 : 0) + rect.x + rect.y + (isSearchLikeEditable(element) ? -3000 : 1000)
          };
        })
        .filter((entry) => entry.text || (entry.rect.x >= agentPanelLeft && entry.rect.y > window.innerHeight * 0.55))
        .sort((left, right) => right.score - left.score);
      const editor = editors[0] || null;
      const editorElement = editor?.element || null;
      const buttons = allDeep("button,[role='button'],label")
        .filter(visible)
        .map((button) => {
          const icons = materialIconTokens(button);
          const text = textOf(button);
          const rect = button.getBoundingClientRect();
          const rawText = String(button?.textContent || "");
          const tagName = String(button?.tagName || "").toLowerCase();
          const ariaDisabled = String(button.getAttribute?.("aria-disabled") || "");
          const disabled = Boolean(button.disabled || ariaDisabled === "true");
          const compactControl = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
          const composerAddIcon = icons.has("add_2") || /add_2/i.test(rawText) || (icons.has("add") && !/arrow_forward|article_spark|tune|settings/i.test(rawText));
          const addLike = composerAddIcon || icons.has("add_photo_alternate") || /add_photo_alternate|\b(add|attach|upload)\b/i.test(text);
          const className = String(button?.className?.baseVal || button?.className || "");
          const iconOnlySubmit = /submit-button|(?:^|\s)submit(?:-|$|\s)/i.test(className)
            || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
          const blockedAction = icons.has("arrow_forward") || iconOnlySubmit || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(rawText) || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(text);
          const sendLike = blockedAction || /\b(send|submit|generate)\b/i.test(text) || (!composerAddIcon && /\bcreate\b/i.test(text));
          const bottomRight = rect.x > window.innerWidth * 0.65 && rect.y > window.innerHeight * 0.55;
          const rightEdge = rect.x > window.innerWidth * 0.85;
          const arrowSubmit = icons.has("arrow_forward") || /arrow_forward/i.test(text) || /arrow_forward/i.test(rawText);
          const submitText = arrowSubmit || iconOnlySubmit || /\b(send|submit|generate)\b/i.test(text) || (rightEdge && /\bcreate\b/i.test(text));
          const rejectedSubmit = /\b(add|add_2|upload|attach|media|instructions|settings|clear prompt|close|cancel|delete|remove|reuse prompt|good response|bad response|copy message|flag)\b/i.test(text);
          const activeGeneration = /(^|\b)stop(\b|$)|stop_circle/i.test(text);
          const composerZone = rect.right > window.innerWidth * 0.65 && rect.bottom > window.innerHeight * 0.72;
          return {
            text,
            tagName,
            disabled,
            ariaDisabled,
            composerAddIcon,
            compactControl,
            addLike,
            sendLike,
            submitText,
            rejectedSubmit,
            activeGeneration,
            composerZone,
            rect: rectOf(button),
            score: (composerAddIcon ? 20000 : 0) + (addLike ? 5000 : -5000) + (composerZone ? 5000 : -5000) + (tagName === "button" ? 3000 : 0) + (compactControl ? 3000 : -8000) + (window.innerWidth - rect.x) - Math.abs(rect.width - 32),
            submitScore: (arrowSubmit ? 20000 : 0) + (bottomRight ? 10000 : 0) + (submitText ? 5000 : 0) + rect.x + rect.y
          };
        })
        .sort((left, right) => right.score - left.score);
      const candidates = buttons
        .filter((entry) => entry.composerAddIcon && entry.addLike && !entry.sendLike && entry.composerZone && entry.compactControl)
        .sort((left, right) => right.score - left.score);
      const submitCandidates = buttons
        .filter((entry) => entry.submitText && !entry.rejectedSubmit)
        .sort((left, right) => right.submitScore - left.submitScore);
      const submitControl = submitCandidates.find((entry) => !entry.disabled) || null;
      const visibleSubmitControl = submitControl || submitCandidates[0] || null;
      const addButton = candidates[0] || null;
      const activeGeneration = buttons.some((entry) => entry.activeGeneration);
      return {
        href,
        projectOk,
        editRoute,
        composer: {
          visible: Boolean(editor),
          text: compact(editor?.text || ""),
          sendEnabled: Boolean(submitControl),
          sendControlVisible: Boolean(visibleSubmitControl),
          sendControlText: visibleSubmitControl?.text || "",
          sendControlRect: visibleSubmitControl ? visibleSubmitControl.rect : null,
          sendControlDisabled: visibleSubmitControl?.disabled === true,
          sendControlAriaDisabled: visibleSubmitControl ? visibleSubmitControl.ariaDisabled : "",
          editorRect: editorElement ? rectOf(editorElement) : null,
          editorFingerprint: editorElement ? {
            tag: String(editorElement.tagName || "").toLowerCase(),
            role: compact(editorElement.getAttribute?.("role") || ""),
            contentEditable: compact(editorElement.getAttribute?.("contenteditable") || ""),
            dataSlateEditor: editorElement.getAttribute?.("data-slate-editor") === "true"
          } : null,
          generationActive: activeGeneration,
          source: editor ? "flow_agent_composer" : ""
        },
        addButton,
        sampleButtons: candidates.slice(0, 3)
      };
    }
  });
  return summarizeAgentComposerProbeFrames(injections, { projectId });
}

function queuePreferredFlowTabId(message = {}, sender = {}) {
  const payloadTabId = Number(message.payload?.tabId || message.payload?.activeTabId || 0) || 0;
  if (payloadTabId > 0) return payloadTabId;
  if (Number(runtimeState.activeTabId || 0) > 0) return Number(runtimeState.activeTabId);
  const senderTabId = Number(sender?.tab?.id || 0) || 0;
  return senderTabId > 0 && isFlowToolUrl(sender?.tab?.url || "") ? senderTabId : undefined;
}

const FLOW_BRIDGE_PROBE_TIMEOUT_MS = 12000;
const FLOW_BRIDGE_INJECTION_COOLDOWN_MS = 5000;
const FLOW_BRIDGE_DEGRADED_TIMEOUT_MS = 12000;
const flowBridgeEnsureState = new Map();
// Must stay above the longest page-side internal deadline (300s upscale poll)
// so healthy long commands never hit the transport ceiling.
const PAGE_COMMAND_TRANSPORT_TIMEOUT_MS = 360000;
const PAGE_COMMAND_TRANSPORT_GRACE_MS = 15000;

async function sendTabMessage(tabId, message, timeoutMs = 0, frameId = 0) {
  const send = new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, { frameId: Number(frameId || 0) }, (response) => {
      const error = chromeCallbackError();
      if (error) {
        resolve({ ok: false, error });
        return;
      }
      resolve(response || { ok: false, error: "empty_tab_response" });
    });
  });
  const ms = Number(timeoutMs || 0);
  if (!(ms > 0)) return send;
  return Promise.race([send, timeoutAfter(ms, "tab_message_timeout")]);
}

function isMissingReceiverError(error = "") {
  return /receiving end does not exist|could not establish connection|message port closed/i.test(String(error || ""));
}

async function probeFlowBridge(tabId) {
  return sendTabMessage(tabId, createMessage(MessageType.BridgeHealthV4, {
    probe: true
  }, {
    source: "background"
  }), FLOW_BRIDGE_PROBE_TIMEOUT_MS);
}

function isUnloadedFlowTab(tab = {}) {
  return Boolean(tab?.id && isFlowToolUrl(tab.url || "") && (tab.status === "unloaded" || tab.discarded === true));
}

async function wakeUnloadedFlowTab(tabId) {
  let tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab?.id) return { ok: false, error: "flow_tab_not_found" };
  if (!isFlowToolUrl(tab.url || "")) return { ok: false, error: "flow_tab_not_flow_url" };
  if (!isUnloadedFlowTab(tab)) return { ok: true, tab };

  recordEvent({
    type: "bridge.tab.wake_unloaded",
    tabId,
    status: tab.status || "",
    discarded: tab.discarded === true
  });
  await chrome.tabs.reload(tabId).catch((error) => {
    recordEvent({
      type: "bridge.tab.wake_error",
      tabId,
      error: String(error?.message || error || "tab_reload_failed")
    });
  });
  for (const delayMs of [250, 500, 1000, 1500, 2500, 4000]) {
    await sleep(delayMs);
    tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab?.id && isFlowToolUrl(tab.url || "") && !isUnloadedFlowTab(tab)) {
      recordEvent({
        type: "bridge.tab.wake_ready",
        tabId,
        status: tab.status || "",
        discarded: tab.discarded === true
      });
      return { ok: true, tab };
    }
  }
  recordEvent({
    type: "bridge.tab.wake_failed",
    tabId,
    status: tab?.status || "",
    discarded: tab?.discarded === true
  });
  return { ok: false, error: "flow_tab_unloaded" };
}

function isFreshFlowBridge(probe = {}) {
  const ok = probe?.ok === true || probe?.ok === "true" || probe?.pageHookHealth?.ok === true || probe?.pageHookHealth?.ok === "true";
  const pageHookInstalled = probe?.pageHookInstalled === true || probe?.pageHookInstalled === "true";
  return Boolean(
    ok &&
    probe.bridgeVersion === EXPECTED_FLOW_BRIDGE_VERSION &&
    probe.pageHookVersion === EXPECTED_PAGE_HOOK_VERSION &&
    pageHookInstalled
  );
}

function pageEpochFromProbe(probe = {}) {
  return compactString(
    probe?.pageEpoch
    || probe?.pageHookHealth?.pageEpoch
    || probe?.href
    || probe?.pageHookHealth?.href
    || ""
  );
}

function bridgeCapabilitiesFromProbe(probe = {}) {
  const pageTransportReady = isFreshFlowBridge(probe);
  const pageHookReady = Boolean(
    probe?.pageHookInstalled === true
    && probe?.pageHookVersion === EXPECTED_PAGE_HOOK_VERSION
    && (probe?.pageHookHealth?.ok === true || probe?.pageHookHealth?.ok === "true")
  );
  const flowPageIssue = probe?.pageHookHealth?.flowPageIssue || probe?.flowPageIssue || null;
  const flowPageBlocked = flowPageIssue?.blocked === true || probe?.pageHookHealth?.pageBlocked === true;
  const agentDomContextReady = pageHookReady && flowPageBlocked !== true;
  const projectMetadataReady = agentDomContextReady && Boolean(
    compactString(probe?.projectId || probe?.pageHookHealth?.projectId || "")
    || compactString(probe?.href || probe?.pageHookHealth?.href || "")
  );
  const networkObserverReady = probe?.pageHookHealth?.hasNativeFetch === true || probe?.hasNativeFetch === true;
  return {
    pageTransportReady,
    agentDomContextReady,
    projectMetadataReady,
    networkObserverReady
  };
}

function bridgeProbeWithCapabilities(probe = {}, extras = {}) {
  return {
    ...probe,
    ...extras,
    pageEpoch: extras.pageEpoch || pageEpochFromProbe(probe),
    capabilities: bridgeCapabilitiesFromProbe(probe)
  };
}

function isSamePageEpochHookPresent(probe = {}, state = {}) {
  return Boolean(
    probe?.ok
    && probe?.bridgeVersion === EXPECTED_FLOW_BRIDGE_VERSION
    && probe?.pageHookVersion === EXPECTED_PAGE_HOOK_VERSION
    && probe?.pageHookInstalled === true
    && pageEpochFromProbe(probe)
    && state.pageEpoch === pageEpochFromProbe(probe)
  );
}

function bridgeRuntimeFields(probe = {}, connected = false) {
  const bridgeHealthy = isFreshFlowBridge(probe);
  const capabilities = probe?.capabilities || bridgeCapabilitiesFromProbe(probe);
  const flowPageIssue = probe?.pageHookHealth?.flowPageIssue || probe?.flowPageIssue || null;
  const flowPageBlocked = flowPageIssue?.blocked === true;
  return {
    bridgeHealthy,
    bridgeDegraded: bridgeHealthy !== true && capabilities.agentDomContextReady === true,
    bridgeCapabilities: capabilities,
    bridgeVersion: compactString(probe?.bridgeVersion || ""),
    pageHookVersion: compactString(probe?.pageHookVersion || ""),
    pageHookInstalled: probe?.pageHookInstalled === true,
    hasNativeFetch: probe?.pageHookHealth?.hasNativeFetch === true || probe?.hasNativeFetch === true,
    flowPageIssue,
    flowPageBlocked,
    flowPageError: flowPageBlocked
      ? compactString(flowPageIssue.message || flowPageIssue.textPreview || "Flow page is temporarily rate limited.")
      : null,
    bridgeError: bridgeHealthy ? null : (connected ? compactString(probe?.error || "flow_bridge_not_ready") : null),
    extensionResourceCheck: probe?.extensionResourceCheck || null
  };
}

async function approveAgentBridgePairing(payload = {}, request = {}) {
  const nowMs = Date.now();
  const stored = await chrome.storage.local.get(SIDEPANEL_STATE_STORAGE_KEY).catch(() => ({}));
  const sidepanelState = stored?.[SIDEPANEL_STATE_STORAGE_KEY] || {};
  const control = sidepanelState.control && typeof sidepanelState.control === "object" ? sidepanelState.control : {};
  const agentMode = control.agentMode && typeof control.agentMode === "object" ? control.agentMode : {};
  const expiresMs = Date.parse(agentMode.bridgePairingApprovalExpiresAt || "");
  const alreadyUsed = compactString(agentMode.bridgePairingApprovalUsedAt);
  const expectedClientId = compactString(agentMode.bridgePairingApprovalClientId);
  const requestingClientId = compactString(request?.session?.clientId || payload.clientId);
  const clientMismatch = Boolean(expectedClientId && requestingClientId !== expectedClientId);
  if (agentMode.bridgeEnabled !== true || !Number.isFinite(expiresMs) || expiresMs <= nowMs || alreadyUsed || clientMismatch) {
    return {
      approved: false,
      code: clientMismatch ? "PAIRING_APPROVAL_CLIENT_MISMATCH" : "PAIRING_APPROVAL_REQUIRED",
      message: clientMismatch
        ? "Pairing approval is reserved for the PatchWork client that requested this connection."
        : "Open Auto Flow and approve the requesting client before starting pairing.",
      ...(clientMismatch ? { details: { expectedClientId, requestingClientId } } : {})
    };
  }

  const usedAt = new Date(nowMs).toISOString();
  await chrome.storage.local.set({
    [SIDEPANEL_STATE_STORAGE_KEY]: {
      ...sidepanelState,
      control: {
        ...control,
        agentMode: {
          ...agentMode,
          bridgePairingApprovalUsedAt: usedAt,
          bridgePairingApprovedClientName: compactString(payload.clientName || ""),
          directPendingClient: {}
        }
      }
    }
  }).catch(() => {});

  recordEvent({
    type: "agent_bridge.pairing.approved",
    clientName: compactString(payload.clientName || ""),
    expiresAt: new Date(expiresMs).toISOString()
  });
  return {
    approved: true,
    expiresAt: new Date(expiresMs).toISOString(),
    source: "sidepanel"
  };
}

async function getAgentBridgeStatus() {
  const tab = await findFlowTab(runtimeState.activeTabId || undefined).catch(() => null);
  const binding = runtimeBindingPayload(tab || {}, {
    projectId: runtimeState.projectId || projectIdFromUrl(tab?.url || ""),
    href: runtimeState.pageUrl || tab?.url || "",
    title: runtimeState.pageTitle || tab?.title || ""
  });
  const projectId = compactString(binding.projectId || runtimeState.projectId || projectIdFromUrl(tab?.url || ""));
  const tabProjectConnected = Boolean(binding.activeTabId && projectId);
  const bridgeProbe = tabProjectConnected
    ? await ensureFlowBridge(binding.activeTabId).catch((error) => ({
        ok: false,
        error: String(error?.message || error || "flow_bridge_not_ready")
      }))
    : { ok: false, error: binding.activeTabId ? "missing_project_id" : "flow_tab_not_found" };
  const bridgeFields = bridgeRuntimeFields(bridgeProbe, tabProjectConnected);
  runtimeState.bridgeHealthy = bridgeFields.bridgeHealthy;
  const projectActive = tabProjectConnected && bridgeFields.flowPageBlocked !== true;
  const transportStatus = buildAgentBridgeTransportStatus();
  return {
    extensionId: chrome.runtime?.id || "",
    runtime: {
      connected: projectActive,
      activeTabId: binding.activeTabId || runtimeState.activeTabId || null,
      projectId,
      pageUrl: binding.pageUrl || runtimeState.pageUrl || tab?.url || "",
      pageTitle: binding.pageTitle || runtimeState.pageTitle || tab?.title || "",
      agentBridge: transportStatus,
      ...bridgeFields,
      error: bridgeFields.flowPageError || (binding.activeTabId ? (projectId ? null : "missing_project_id") : "flow_tab_not_found")
    },
    project: {
      state: projectActive ? "active" : "missing",
      active: projectActive,
      id: projectId,
      name: binding.pageTitle || runtimeState.pageTitle || tab?.title || "",
      activeTabId: binding.activeTabId || runtimeState.activeTabId || null,
      url: binding.pageUrl || runtimeState.pageUrl || tab?.url || ""
    },
    auth: runtimeState.auth || null
  };
}

async function refreshAgentWsBrokerFromBridge(payload = {}) {
  const wsUrl = compactString(payload.wsUrl);
  if (!wsUrl) {
    throw agentBridgeError("WS_BROKER_URL_MISSING", "WS broker refresh requires an exact loopback broker URL.");
  }
  const diagnostics = await agentWsBrokerBridgeController.useBrokerUrl(wsUrl, "broker_available");
  return {
    ok: diagnostics.connected === true,
    wsUrl,
    diagnostics
  };
}

function buildAgentBridgeTransportStatus() {
  const wsBroker = agentWsBrokerBridgeController.diagnostics();
  const nativeLegacy = agentNativeBridgeController.diagnostics();
  const activeTransport = wsBroker.connected
    ? "ws_broker"
    : (nativeLegacy.connected ? "native_messaging_legacy" : null);
  const activeDiagnostics = activeTransport === "native_messaging_legacy" ? nativeLegacy : wsBroker;
  return {
    preferredTransport: "ws_broker",
    activeTransport,
    state: activeTransport ? "connected" : (wsBroker.enabled ? "extension_disconnected" : "disabled"),
    connected: Boolean(activeTransport),
    enabled: wsBroker.enabled === true,
    paired: wsBroker.paired === true || nativeLegacy.paired === true,
    reconnecting: wsBroker.reconnecting === true || nativeLegacy.reconnecting === true,
    error: activeDiagnostics.error || wsBroker.error || nativeLegacy.error || "",
    errorCode: activeDiagnostics.errorCode || wsBroker.errorCode || nativeLegacy.errorCode || "",
    bridgeProtocolVersion: wsBroker.bridgeProtocolVersion || nativeLegacy.bridgeProtocolVersion || "",
    nativeHostVersion: nativeLegacy.nativeHostVersion || "",
    packageVersion: nativeLegacy.packageVersion || "",
    socketPath: nativeLegacy.socketPath || "",
    nativePortConnected: nativeLegacy.nativePortConnected === true,
    nativeHostConnected: nativeLegacy.connected === true,
    lastRoundTripAt: nativeLegacy.lastRoundTripAt || "",
    lastRoundTripOk: nativeLegacy.lastRoundTripOk === true,
    lastConnectedAt: activeDiagnostics.lastConnectedAt || "",
    lastDisconnectedAt: activeDiagnostics.lastDisconnectedAt || "",
    ws_broker: wsBroker,
    cdp_bridge: {
      transport: "cdp_bridge",
      enabled: false,
      state: "dev_discovery_only",
      connected: false,
      brokenLink: "cdp_bridge.discovery_only",
      errorCode: "CDP_DISCOVERY_ONLY",
      nextAction: "Use ws_broker for product bridge health; CDP is dev/discovery tooling only."
    },
    native_messaging_legacy: {
      ...nativeLegacy,
      transport: "native_messaging_legacy",
      preferred: false,
      legacy: true
    }
  };
}

function pendingAgentActionFromScreenContext(context = {}) {
  const uiState = context.uiState && typeof context.uiState === "object" ? context.uiState : {};
  if (uiState.actionRequired && typeof uiState.actionRequired === "object") {
    return {
      ...uiState.actionRequired,
      text: compactString(uiState.actionRequired.text || uiState.latestMessage?.text || context.latestMessages?.at?.(-1)?.text || "")
    };
  }
  if (uiState.waitingOn === "agent_message_response" && uiState.latestMessage?.text) {
    return {
      kind: "agent_question",
      text: compactString(uiState.latestMessage.text),
      choices: [],
      autoResolvable: false
    };
  }
  return null;
}

async function connectThisFlowTabFromBridge(payload = {}) {
  const listed = await listAgentBridgeFlowTabs(payload);
  const selection = selectSameWindowFlowTab({
    tabs: listed.tabs || [],
    windowId: payload.windowId,
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    runtimeProjectId: runtimeState.projectId,
    runtimeTabId: runtimeState.activeTabId
  });
  if (!selection.ok) {
    throw agentBridgeError(selection.code, selection.message, {
      ...selection.details,
      nextAction: selection.nextAction
    });
  }
  const tab = await chrome.tabs.get(selection.tab.tabId).catch(() => null);
  if (!tab?.id || !isFlowToolUrl(tab.url || "")) {
    throw agentBridgeError("FLOW_TAB_NOT_FOUND", "The selected Flow tab is no longer available.", {
      requestedTabId: String(selection.tab.tabId),
      nextAction: "Open the Google Flow project in this Chrome window, then connect again."
    });
  }
  const projectId = compactString(projectIdFromUrl(tab.url || "") || selection.tab.projectId);
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, {
      ...targetCheck.details,
      nextAction: "Reconnect the exact project and tab shown in this Auto Flow panel."
    });
  }
  const bridge = await ensureFlowBridge(tab.id, { forceRecover: true });
  let proofError = null;
  let proof = null;
  if (isFreshFlowBridge(bridge)) {
    try {
      proof = await getAgentScreenContextFromBridge({
        projectId,
        tabId: String(tab.id),
        timeoutMs: Number(payload.timeoutMs || 5000) || 5000
      });
    } catch (error) {
      proofError = {
        code: compactString(error?.code || "AGENT_CONTEXT_UNAVAILABLE"),
        message: compactString(error?.message || error || "agent_screen_context_unavailable")
      };
    }
  }
  const classified = classifyFlowPageConnectResult({
    probe: bridge,
    proofError,
    expectedBridgeVersion: EXPECTED_FLOW_BRIDGE_VERSION,
    expectedPageHookVersion: EXPECTED_PAGE_HOOK_VERSION
  });
  promoteFlowTabBinding(tab, { projectId, href: tab.url }, "connect_this_flow_tab");
  recordEvent({
    type: classified.ok ? "bridge.connect.ready" : "bridge.connect.failed",
    tabId: tab.id,
    projectId,
    windowId: Number.isFinite(Number(tab.windowId)) ? Number(tab.windowId) : null,
    code: classified.code,
    error: classified.ok ? "" : classified.message,
    nextAction: classified.nextAction || "",
    forceRecover: true
  });
  if (!classified.ok) {
    throw agentBridgeError(classified.code, classified.message, {
      ...classified.details,
      nextAction: classified.nextAction,
      projectId,
      tabId: String(tab.id),
      windowId: Number.isFinite(Number(tab.windowId)) ? Number(tab.windowId) : null,
      bridgeError: compactString(bridge?.error || ""),
      degradedReason: compactString(bridge?.degradedReason || "")
    });
  }
  return {
    ok: true,
    connected: true,
    code: classified.code,
    message: classified.message,
    projectId,
    tabId: String(tab.id),
    windowId: Number.isFinite(Number(tab.windowId)) ? Number(tab.windowId) : null,
    laneId: `flow-tab-${tab.id}`,
    reason: selection.reason,
    bridge: {
      healthy: true,
      version: compactString(bridge?.bridgeVersion || EXPECTED_FLOW_BRIDGE_VERSION),
      pageHookVersion: compactString(bridge?.pageHookVersion || EXPECTED_PAGE_HOOK_VERSION),
      pageHookInstalled: bridge?.pageHookInstalled === true
    },
    proof: {
      ok: true,
      projectId: compactString(proof?.projectId || projectId),
      tabId: compactString(proof?.tabId || tab.id),
      composerReady: proof?.composer?.available === true || proof?.page?.composerReady === true
    }
  };
}

async function getAgentScreenContextFromBridge(payload = {}) {
  const requestedTransport = compactString(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  if ((requestedTransport === "api" || requestedTransport === "agent_api") && payload.chromeSessionAuth === true) {
    const projectId = compactString(payload.projectId);
    if (!projectId) throw agentBridgeError("AGENT_API_PROJECT_REQUIRED", "Chrome-session Agent context requires an exact projectId.");
    try {
      await flowChromeSession.getAccessToken();
    } catch (error) {
      throw agentBridgeError(error?.code || "FLOW_CHROME_LOGIN_REQUIRED", error?.message || "Google Flow login is unavailable in this Chrome profile.", error?.details);
    }
    const metadata = await fetchAgentProjectInitialDataInBackground(projectId, agentBridgeProjectRootUrl("", projectId));
    if (!metadata.ok) {
      throw agentBridgeError(metadata.status === 401 ? "FLOW_AUTH_EXPIRED" : "METADATA_UNAVAILABLE", metadata.error || "Flow project metadata is unavailable.", {
        status: Number(metadata.status || 0),
        projectId
      });
    }
    return {
      ok: true,
      transport: "agent_api",
      chromeSessionAuth: true,
      composerRequired: false,
      projectId,
      tabId: compactString(payload.tabId) || null,
      laneId: compactString(payload.laneId),
      auth: { valid: true, state: "chrome_session_ready" },
      authValid: true,
      entitlement: { valid: true, source: "project_initial_data" },
      page: {
        projectId,
        tabId: compactString(payload.tabId) || null,
        laneId: compactString(payload.laneId),
        url: "",
        title: "",
        composerReady: false
      },
      composer: { available: false, required: false },
      blockers: [],
      latestMessages: []
    };
  }
  let tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }

  const expectedManifest = await agentExpectedManifestForContext(payload, { projectId });
  const pageContextResponse = await sendPageCommand({
    action: "agentScreenContext",
    timeoutMs: Number(payload.timeoutMs || 5000) || 5000
  }, tab.id).catch((error) => {
    throw agentBridgeError("AGENT_CONTEXT_UNAVAILABLE", String(error?.message || error || "agent_screen_context_unavailable"));
  });
  const raw = {
    ...unwrapPageCommandPayload(pageContextResponse),
    progress: payload.progress && typeof payload.progress === "object" ? payload.progress : undefined,
    runStartedAt: compactString(payload.runStartedAt || payload.baselineAt || ""),
    runId: compactString(payload.runId || ""),
    submittedDraftHashes: Array.isArray(payload.submittedDraftHashes) ? payload.submittedDraftHashes.map(compactString).filter(Boolean) : [],
    requestedProjectId: compactString(payload.projectId || ""),
    requestedTabId: compactString(payload.tabId || ""),
    tabId: compactString(tab.id),
    projectId
  };
  const context = buildAgentScreenContext({
    raw,
    expectedManifest
  });

  const pendingAction = pendingAgentActionFromScreenContext(context);
  const blocker = context.blockers[0] || null;
  const statusProtocol = parseAgentStatusProtocol((context.latestMessages || []).map((message) => message?.text || "").join("\n"));
  if (context.blockers.length || pendingAction || statusProtocol.hasProtocol) {
    const retryableBlocker = blocker && ["flow_rate_limit", "transient_generation_failure"].includes(compactString(blocker.category));
    await upsertAgentBridgeRunState({
      projectId,
      tabId: tab.id,
      payload,
      status: blocker
        ? (retryableBlocker ? "retryable_blocker" : "blocked")
        : (pendingAction?.kind === "credit_confirmation" ? "waiting_for_credit_approval" : pendingAction ? "waiting_for_user" : "reconciling"),
      expectedManifest,
      pendingAction,
      blocker,
      blockCode: blocker?.failureClass || "",
      statusProtocol,
      error: blocker ? (blocker.text || blocker.failureClass || "agent_blocked") : ""
    }).catch((error) => {
      recordEvent({
        type: "agent_bridge.live_queue.context_state_failed",
        projectId,
        tabId: tab.id,
        error: compactString(error?.message || error || "state_update_failed")
      });
    });
  }

  return formatAgentScreenContextForBridge({
    ...context,
    projectId,
    page: {
      ...(context.page || {}),
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || "",
      projectId
    }
  }, { includeRaw: payload.includeRaw === true });
}

async function getAgentScreenshotFromBridge(payload = {}) {
  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  if (typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_SCREENSHOT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent screenshot capture.");
  }

  const format = compactString(payload.format || "jpeg").toLowerCase() === "png" ? "png" : "jpeg";
  const quality = Math.max(30, Math.min(90, Number(payload.quality || 65) || 65));
  const target = debuggerTarget(tab.id);
  await releaseDebuggerSessions("agent_screenshot", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Page.enable").catch(() => {});
    const screenshot = await debuggerSend(target, "Page.captureScreenshot", {
      format,
      ...(format === "jpeg" ? { quality } : {}),
      fromSurface: true,
      captureBeyondViewport: payload.fullPage === true
    });
    const data = compactString(screenshot?.data || "");
    if (!data) {
      throw agentBridgeError("AGENT_SCREENSHOT_EMPTY", "Flow Agent screenshot capture returned no image data.");
    }
    return {
      ok: true,
      projectId,
      page: {
        tabId: tab.id,
        url: tab.url || "",
        title: tab.title || ""
      },
      screenshot: {
        format,
        mimeType: format === "png" ? "image/png" : "image/jpeg",
        dataBase64: data,
        byteLength: Math.ceil(data.length * 3 / 4),
        capturedAt: new Date().toISOString()
      }
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_SCREENSHOT_FAILED", compactString(error?.message || error || "Agent screenshot capture failed."));
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function agentExpectedManifestForContext(payload = {}, context = {}) {
  if (payload.expectedManifest && typeof payload.expectedManifest === "object" && !Array.isArray(payload.expectedManifest)) {
    return payload.expectedManifest;
  }
  if (payload.manifest && typeof payload.manifest === "object" && !Array.isArray(payload.manifest)) {
    return payload.manifest;
  }
  if (payload.matrix?.manifest && typeof payload.matrix.manifest === "object" && !Array.isArray(payload.matrix.manifest)) {
    return payload.matrix.manifest;
  }
  const stored = await chrome.storage.local.get(SIDEPANEL_STATE_STORAGE_KEY).catch(() => ({}));
  const sidepanelState = stored?.[SIDEPANEL_STATE_STORAGE_KEY] && typeof stored[SIDEPANEL_STATE_STORAGE_KEY] === "object"
    ? stored[SIDEPANEL_STATE_STORAGE_KEY]
    : {};
  const run = sidepanelState?.control?.agentRun && typeof sidepanelState.control.agentRun === "object"
    ? sidepanelState.control.agentRun
    : {};
  const requestedProjectId = compactString(context.projectId || payload.projectId);
  const runProjectId = compactString(run.projectId);
  if (requestedProjectId && runProjectId && requestedProjectId !== runProjectId) return {};
  const requestedRunId = agentBridgePayloadRunId(payload);
  if (requestedRunId && !agentBridgeRunIdentityMatches(run, requestedRunId)) return {};
  return run.expectedManifest && typeof run.expectedManifest === "object" && !Array.isArray(run.expectedManifest)
    ? run.expectedManifest
    : (run.manifest && typeof run.manifest === "object" && !Array.isArray(run.manifest)
      ? run.manifest
      : (run.matrix?.manifest && typeof run.matrix.manifest === "object" && !Array.isArray(run.matrix.manifest)
        ? run.matrix.manifest
        : {}));
}

async function upsertAgentBridgeRunState({
  projectId = "",
  tabId = null,
  payload = {},
  status = "",
  reconciliation = null,
  reconciledRows = null,
  expectedManifest = null,
  submitted = null,
  error = "",
  blockCode = "",
  blocker = null,
  pendingAction = undefined,
  creditDecision = undefined,
  toolLineage = undefined,
  statusProtocol = undefined
} = {}) {
  const now = new Date().toISOString();
  const stored = await chrome.storage.local.get(SIDEPANEL_STATE_STORAGE_KEY).catch(() => ({}));
  const sidepanelState = stored?.[SIDEPANEL_STATE_STORAGE_KEY] && typeof stored[SIDEPANEL_STATE_STORAGE_KEY] === "object"
    ? stored[SIDEPANEL_STATE_STORAGE_KEY]
    : {};
  const control = sidepanelState.control && typeof sidepanelState.control === "object" ? sidepanelState.control : {};
  const priorRun = control.agentRun && typeof control.agentRun === "object" && !Array.isArray(control.agentRun) ? control.agentRun : {};
  const payloadExpectedManifest = agentBridgeObject(payload.expectedManifest || payload.manifest || payload.matrix?.manifest);
  const effectiveExpectedManifest = agentBridgeObject(expectedManifest || payloadExpectedManifest);
  const baseRun = buildAgentBridgeRunFromPayload(payload, {
    projectId,
    tabId,
    status,
    now,
    expectedManifest: effectiveExpectedManifest
  });
  const requestedRunId = agentBridgePayloadRunId(payload);
  const priorProjectId = compactString(priorRun.projectId);
  const nextProjectId = compactString(projectId || baseRun.projectId);
  const sameProject = !priorProjectId || !nextProjectId || priorProjectId === nextProjectId;
  const hasPayloadIdentity = Boolean(
    requestedRunId
    || compactString(payload.prompt)
    || Object.keys(payloadExpectedManifest).length
    || Object.keys(agentBridgeObject(payload.matrix)).length
  );
  const sameRun = !hasPayloadIdentity
    || agentBridgeRunIdentityMatches(priorRun, requestedRunId || baseRun.id);
  const carryPriorRun = sameProject && sameRun;
  const carriedRun = carryPriorRun ? priorRun : {};
  const priorRunWasPreSubmitBlocked = agentRunStatusIsPreSubmitBlocked(carriedRun.status)
    || carriedRun.preSubmitBlocked === true
    || carriedRun.setupBlocked === true;
  const baseRows = Array.isArray(reconciledRows) && reconciledRows.length
    ? reconciledRows
    : Array.isArray(reconciliation?.rows) && reconciliation.rows.length
      ? reconciliation.rows
      : baseRun.rows.length
        ? baseRun.rows
        : (Array.isArray(carriedRun.rows) ? carriedRun.rows : []);
  const nextRows = agentRunStatusIsPreSubmitBlocked(status)
    ? markAgentRowsPreSubmitBlocked(baseRows, {
      status,
      blockCode,
      error
    })
    : baseRows;
  let nextRun = {
    ...carriedRun,
    ...baseRun,
    id: baseRun.id || carriedRun.id || `agent-bridge-${Date.now()}`,
    status: compactString(status || baseRun.status || carriedRun.status || "active"),
    projectId: compactString(projectId || baseRun.projectId || carriedRun.projectId),
    tabId: tabId || baseRun.tabId || carriedRun.tabId || null,
    laneId: compactString(payload.laneId || baseRun.laneId || carriedRun.laneId),
    rows: nextRows,
    updatedAt: now,
    startedAt: compactString(carriedRun.startedAt || baseRun.startedAt || now),
    pendingRetry: carriedRun.pendingRetry || null,
    retryRequests: Array.isArray(carriedRun.retryRequests) ? carriedRun.retryRequests : [],
    autoDownload: payload.autoDownload === true || carriedRun.autoDownload === true,
    downloadFolder: compactString(carriedRun.downloadFolder || payload.downloadFolder || payload.outputRoot || "Auto-Flow"),
    downloadNaming: carriedRun.downloadNaming || agentBridgeObject(payload.downloadNaming)
  };
  if (statusProtocol?.hasProtocol) {
    nextRun = applyAgentStatusProtocolToRun(nextRun, statusProtocol);
  }
  if (toolLineage && typeof toolLineage === "object") {
    nextRun.toolLineage = {
      ...(carriedRun.toolLineage && typeof carriedRun.toolLineage === "object" ? carriedRun.toolLineage : {}),
      ...toolLineage,
      observedAt: now
    };
  }
  if (reconciliation && typeof reconciliation === "object") {
    nextRun.reconciliation = reconciliation;
    nextRun.reconciledRows = Array.isArray(reconciliation.rows) ? reconciliation.rows : nextRows;
    nextRun.expectedImages = Number(reconciliation.expectedImages || nextRun.expectedImages || 0);
    nextRun.landedImages = Number(reconciliation.mappedImages || nextRun.landedImages || 0);
    nextRun.expectedVideos = Number(reconciliation.expectedVideos || nextRun.expectedVideos || 0);
    nextRun.landedVideos = Number(reconciliation.presentVideos || nextRun.landedVideos || 0);
    nextRun.missingVideos = Number(reconciliation.missingVideos || 0);
    nextRun.missingVideoTags = Array.isArray(reconciliation.missingVideoTags) ? reconciliation.missingVideoTags : [];
  }
  if (agentRunStatusIsPreSubmitBlocked(nextRun.status)) {
    nextRun.submitted = false;
    nextRun.preSubmitBlocked = nextRun.status === "pre_submit_blocked";
    nextRun.setupBlocked = nextRun.status === "setup_blocked";
    nextRun.blockCode = compactString(blockCode || blocker?.code || carriedRun.blockCode || "");
    nextRun.blocker = blocker && typeof blocker === "object" ? blocker : {
      code: nextRun.blockCode,
      message: compactString(error || carriedRun.lastError || "")
    };
    nextRun.rows = nextRows;
    nextRun.reconciledRows = nextRows;
    nextRun.reconciliation = {
      status: nextRun.status,
      blocked: true,
      blockCode: nextRun.blockCode,
      rows: nextRows,
      expectedImages: Number(nextRun.expectedImages || 0),
      mappedImages: Number(nextRun.landedImages || nextRun.mappedImages || 0),
      expectedVideos: Number(nextRun.expectedVideos || 0),
      presentVideos: Number(nextRun.landedVideos || nextRun.presentVideos || 0),
      missingVideos: 0,
      missingVideoTags: []
    };
    nextRun.missingVideos = 0;
    nextRun.missingVideoTags = [];
  } else {
    delete nextRun.preSubmitBlocked;
    delete nextRun.setupBlocked;
    if (blocker && typeof blocker === "object") {
      nextRun.blockCode = compactString(blockCode || blocker.failureClass || "");
      nextRun.blocker = blocker;
    } else if (!/^(blocked|retryable_blocker|stalled_no_progress)$/i.test(nextRun.status)) {
      delete nextRun.blockCode;
      delete nextRun.blocker;
    }
    if (priorRunWasPreSubmitBlocked && !reconciliation) {
      delete nextRun.reconciliation;
      nextRun.reconciledRows = nextRows;
    }
  }
  if (effectiveExpectedManifest && typeof effectiveExpectedManifest === "object" && Object.keys(effectiveExpectedManifest).length) {
    nextRun.expectedManifest = effectiveExpectedManifest;
  }
  if (submitted !== null) nextRun.submitted = submitted === true;
  if (submitted === true && payload.continuation !== true && !nextRun.submittedAt) nextRun.submittedAt = now;
  if (pendingAction !== undefined) nextRun.pendingAction = pendingAction && typeof pendingAction === "object" ? pendingAction : null;
  if (creditDecision !== undefined) nextRun.creditDecision = creditDecision && typeof creditDecision === "object" ? creditDecision : null;
  if (error) nextRun.lastError = compactString(error);
  else if (!carryPriorRun || submitted === true || /^(preparing|submitting|submitted|prepared|reconciling|landed|complete|completed)$/i.test(nextRun.status)) delete nextRun.lastError;
  if (/^(preparing|submitting|submitted|prepared|reconciling|waiting_for_outputs)$/i.test(nextRun.status)) delete nextRun.completedAt;
  if (/^(landed|complete|completed)$/i.test(nextRun.status)) nextRun.completedAt = now;

  const agentMode = control.agentMode && typeof control.agentMode === "object" ? control.agentMode : {};
  const prompt = payload.continuation === true ? "" : compactString(payload.prompt || "");
  await chrome.storage.local.set({
    [SIDEPANEL_STATE_STORAGE_KEY]: {
      ...sidepanelState,
      ui: {
        ...(sidepanelState.ui || {}),
        activeRoute: "live"
      },
      control: {
        ...control,
        agentMode: {
          ...agentMode,
          ...(prompt ? {
            lastMasterPrompt: prompt,
            lastMasterPromptAt: now
          } : {})
        },
        agentRun: nextRun
      }
    }
  });
  recordEvent({
    type: "agent_bridge.live_queue.state",
    projectId: nextRun.projectId,
    tabId: nextRun.tabId,
    status: nextRun.status,
    rows: nextRun.rows.length,
    hasReconciliation: Boolean(reconciliation)
  });
  return nextRun;
}

function agentRunStatusIsPreSubmitBlocked(status = "") {
  return /^(setup_blocked|pre_submit_blocked)$/i.test(compactString(status));
}

function markAgentRowsPreSubmitBlocked(rows = [], options = {}) {
  const status = compactString(options.status || "pre_submit_blocked");
  const blockCode = compactString(options.blockCode || "");
  const lastError = compactString(options.error || "");
  return (Array.isArray(rows) ? rows : []).map((row) => ({
    ...row,
    status,
    blockCode,
    lastError,
    videos: Array.isArray(row.videos) ? row.videos : [],
    videoVersions: Array.isArray(row.videoVersions) ? row.videoVersions : [],
    imageSlots: Array.isArray(row.imageSlots)
      ? row.imageSlots.map((slot) => slot?.mediaId ? slot : { ...slot, status })
      : row.imageSlots,
    images: Array.isArray(row.images)
      ? row.images.map((slot) => slot?.mediaId ? slot : { ...slot, status })
      : row.images
  }));
}

function agentBridgePayloadRunId(payload = {}) {
  const matrix = agentBridgeObject(payload.matrix);
  const manifest = agentBridgeObject(payload.expectedManifest || payload.manifest || matrix.manifest);
  return compactString(
    payload.runId
    || payload.id
    || matrix.runId
    || matrix.id
    || manifest.runId
    || manifest.id
    || ""
  );
}

function agentBridgeRunIdentityMatches(run = {}, requestedRunId = "") {
  const expected = compactString(requestedRunId);
  if (!expected) return true;
  return [run.id, run.runId, run.clientRunId, run.bridgeRunId]
    .map(compactString)
    .filter(Boolean)
    .includes(expected);
}

function buildAgentBridgeRunFromPayload(payload = {}, context = {}) {
  const matrix = agentBridgeObject(payload.matrix);
  const manifest = agentBridgeObject(payload.expectedManifest || payload.manifest || context.expectedManifest);
  const rows = agentBridgeRowsFromMatrixOrManifest(matrix, manifest);
  const prompt = compactString(payload.prompt || "");
  const runName = compactString(payload.runName || matrix.title || matrix.name || manifest.title || manifest.name || "Agent Bridge Run");
  const explicitRunId = agentBridgePayloadRunId(payload);
  const idSource = compactString(
    explicitRunId
    || payload.idempotencyKey
    || `${runName}:${prompt.slice(0, 400)}:${rows.map((row) => row.rowId).join(",")}`
  );
  return {
    id: explicitRunId || `agent-bridge-${hashCompactString(idSource || String(Date.now()))}`,
    source: "agent_bridge",
    runName,
    name: runName,
    status: compactString(context.status || "preparing"),
    projectId: compactString(context.projectId || payload.projectId),
    tabId: context.tabId || payload.tabId || null,
    laneId: compactString(payload.laneId || ""),
    mode: compactString(payload.mode || payload.agentMode || "agent"),
    startedAt: compactString(context.now || ""),
    promptPreview: prompt.slice(0, 240),
    promptHash: prompt ? hashAgentManagedText(prompt) : "",
    matrix,
    manifest,
    rows,
    creditPolicy: payload.creditPolicy && typeof payload.creditPolicy === "object" ? { ...payload.creditPolicy } : null,
    approvedCredits: Math.max(0, Number(payload.approvedCredits || 0) || 0),
    expectedImages: agentBridgeExpectedCount(matrix, manifest, rows, "images"),
    expectedVideos: agentBridgeExpectedCount(matrix, manifest, rows, "videos")
  };
}

function agentBridgeRowsFromMatrixOrManifest(matrix = {}, manifest = {}) {
  const rows = Array.isArray(matrix.rows) && matrix.rows.length
    ? matrix.rows
    : (Array.isArray(manifest.rows) ? manifest.rows : []);
  return rows.map((row, index) => agentBridgeRowFromSource(row, index)).filter(Boolean);
}

function agentBridgeRowFromSource(row = {}, index = 0) {
  if (!row || typeof row !== "object" || Array.isArray(row)) return null;
  const rawId = compactString(
    row.rowId
    || row.tag
    || row.videoTag
    || row.finalVideoId
    || row.id
    || row.sceneId
    || row.clipId
    || `ROW-${index + 1}`
  ).replace(/^\[|\]$/g, "");
  if (!rawId) return null;
  const expectedImages = agentBridgeExpectedImageCount(row);
  const expectedVideos = agentBridgeExpectedVideoCount(row);
  return {
    rowId: rawId,
    displayTag: compactString(row.displayTag || row.tag || `[${rawId}]`),
    title: compactString(row.title || row.name || row.prompt || row.videoPrompt || rawId).slice(0, 180),
    status: compactString(row.status || "pending"),
    expectedImages,
    expectedVideos,
    imageSlots: agentBridgeImageSlots(row, rawId, expectedImages),
    videos: [],
    qaStatus: "pending",
    issueChips: []
  };
}

function agentBridgeImageSlots(row = {}, rowId = "", expectedImages = 0) {
  const sourceSlots = Array.isArray(row.imageSlots) && row.imageSlots.length
    ? row.imageSlots
    : Array.isArray(row.images)
      ? row.images
      : [];
  if (sourceSlots.length) {
    return sourceSlots.map((slot, index) => ({
      slotId: compactString(slot?.slotId || slot?.imageAuditId || slot?.afid || `${rowId}-IMG${index + 1}`),
      mediaId: compactString(slot?.mediaId || slot?.id || slot?.mediaName || ""),
      status: compactString(slot?.status || (slot?.mediaId ? "landed" : "pending")),
      mappingConfidence: compactString(slot?.mappingConfidence || slot?.mapping || "pending")
    }));
  }
  return Array.from({ length: Math.max(0, expectedImages) }, (_, index) => ({
    slotId: `${rowId}-IMG${index + 1}`,
    mediaId: "",
    status: "pending",
    mappingConfidence: "pending"
  }));
}

function agentBridgeExpectedImageCount(row = {}) {
  const direct = Number(row.expectedImages ?? row.expectedImageCount);
  if (Number.isFinite(direct)) return Math.max(0, direct);
  if (Array.isArray(row.imageSlots)) return row.imageSlots.length;
  if (Array.isArray(row.images)) return row.images.length;
  if (Array.isArray(row.framePrompts)) return row.framePrompts.length;
  if (Array.isArray(row.frames)) return row.frames.length;
  return 0;
}

function agentBridgeExpectedVideoCount(row = {}) {
  const direct = Number(row.expectedVideos ?? row.expectedVideoCount);
  if (Number.isFinite(direct)) return Math.max(0, direct);
  return 1;
}

function agentBridgeExpectedCount(matrix = {}, manifest = {}, rows = [], kind = "") {
  const matrixKey = kind === "images" ? "expectedImages" : "expectedVideos";
  const manifestKey = kind === "images" ? "expectedImages" : "expectedVideos";
  const direct = Number(matrix[matrixKey] ?? manifest[manifestKey]);
  if (Number.isFinite(direct)) return Math.max(0, direct);
  return rows.reduce((sum, row) => sum + Number(kind === "images" ? row.expectedImages : row.expectedVideos || 0), 0);
}

function agentBridgeObject(value = {}) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function hasAgentManifestRows(value = {}) {
  return Boolean(
    value &&
      typeof value === "object" &&
      !Array.isArray(value) &&
      Array.isArray(value.rows) &&
      value.rows.length
  );
}

async function resolveAgentBridgeFlowProject(payload = {}, options = {}) {
  const unavailableCode = options.unavailableCode || "PROJECT_UNAVAILABLE";
  const bindingReason = options.bindingReason || "agent_bridge_project";
  const preferredTabId = Number(payload.tabId || payload.activeTabId || runtimeState.activeTabId || 0) || undefined;
  const tab = await findFlowTab(preferredTabId).catch(() => null);
  if (!tab?.id) {
    throw agentBridgeError("FLOW_TAB_NOT_FOUND", "No open Google Flow project tab was found.");
  }
  const projectStateTimeoutMs = Math.min(
    10000,
    Math.max(3000, Number(options.projectStateTimeoutMs ?? payload.timeoutMs ?? 10000) || 10000)
  );
  const pageStateResponse = await sendPageCommand({
    action: "projectState",
    tabId: tab.id,
    timeoutMs: projectStateTimeoutMs
  }, tab.id).catch((error) => {
    throw agentBridgeError(unavailableCode, String(error?.message || error || "project_state_unavailable"));
  });
  const pageState = unwrapPageCommandPayload(pageStateResponse);
  if (pageState?.ok === false) {
    const code = /flow_tab_not_found/i.test(pageState.error || "") ? "FLOW_TAB_NOT_FOUND" : unavailableCode;
    throw agentBridgeError(code, pageState.error || "Flow project state is unavailable.");
  }
  const requestedProjectId = requestedAgentBridgeProjectId(payload);
  const activeProjectId = compactString(pageState?.projectId || projectIdFromUrl(pageState?.href || tab.url || "") || projectIdFromUrl(tab.url || ""));
  if (requestedProjectId && activeProjectId && requestedProjectId !== activeProjectId) {
    throw agentBridgeError("AGENT_TARGET_MISMATCH", "Requested Flow project does not match the active Flow tab.", {
      requestedProjectId,
      activeProjectId,
      tabId: tab.id
    });
  }
  const projectId = compactString(requestedProjectId || activeProjectId);
  if (!projectId) {
    throw agentBridgeError("FLOW_PROJECT_NOT_FOUND", "The active Flow tab is not bound to a project.");
  }
  promoteFlowTabBinding(tab, {
    projectId,
    href: pageState?.href || tab.url || "",
    title: pageState?.title || tab.title || ""
  }, bindingReason);

  return {
    tab,
    pageState,
    projectId,
    requestedProjectId,
    activeProjectId
  };
}

async function getAgentProjectMetadata(payload = {}) {
  const requestedTransport = compactString(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  const chromeSessionApi = (requestedTransport === "api" || requestedTransport === "agent_api")
    && payload.chromeSessionAuth === true;
  if (chromeSessionApi) {
    const projectId = compactString(payload.projectId);
    if (!projectId) throw agentBridgeError("AGENT_API_PROJECT_REQUIRED", "Chrome-session metadata requires an exact projectId.");
    try {
      await flowChromeSession.getAccessToken();
    } catch (error) {
      throw agentBridgeError(error?.code || "FLOW_CHROME_LOGIN_REQUIRED", error?.message || "Google Flow login is unavailable in this Chrome profile.", error?.details);
    }
    const metadata = await fetchAgentProjectInitialDataInBackground(projectId, agentBridgeProjectRootUrl("", projectId));
    if (!metadata.ok) {
      throw agentBridgeError(metadata.status === 401 ? "FLOW_AUTH_EXPIRED" : "METADATA_UNAVAILABLE", metadata.error || "Flow project metadata is unavailable.", {
        status: Number(metadata.status || 0),
        source: metadata.source || "background_fetch"
      });
    }
    const expectedManifest = await agentExpectedManifestForContext(payload, { projectId });
    const reconciliation = hasAgentManifestRows(expectedManifest)
      ? reconcileAgentProject({ projectInitialData: metadata.projectInitialData, expectedManifest })
      : null;
    if (reconciliation) {
      const status = reconciliation.missingVideos > 0 || reconciliation.mappedImages < reconciliation.expectedImages
        ? "reconciling"
        : "landed";
      await upsertAgentBridgeRunState({
        projectId,
        tabId: null,
        payload,
        status,
        reconciliation,
        reconciledRows: reconciliation.rows,
        expectedManifest
      }).catch(() => null);
    }
    return {
      projectId,
      source: metadata.source || "background_fetch",
      fetchedAt: new Date().toISOString(),
      chromeSessionAuth: true,
      page: { tabId: null, url: "", title: "", projectId },
      projectInitialData: metadata.projectInitialData,
      ...(hasAgentManifestRows(expectedManifest) ? { expectedManifest } : {}),
      ...(reconciliation ? { reconciliation } : {})
    };
  }
  const { tab, pageState, projectId } = await resolveAgentBridgeFlowProject(payload, {
    unavailableCode: "METADATA_UNAVAILABLE",
    bindingReason: "agent_bridge_metadata"
  });

  const metadata = await fetchAgentProjectInitialData({
    projectId,
    tabId: tab.id,
    pageUrl: pageState?.href || tab.url || ""
  });
  if (!metadata.ok) {
    throw agentBridgeError("METADATA_UNAVAILABLE", metadata.error || "Flow project metadata is unavailable.", {
      status: metadata.status || 0,
      source: metadata.source || ""
    });
  }
  const expectedManifest = await agentExpectedManifestForContext(payload, { projectId });
  let reconciliation = null;
  if (hasAgentManifestRows(expectedManifest)) {
    reconciliation = reconcileAgentProject({
      projectInitialData: metadata.projectInitialData,
      expectedManifest
    });
    const status = reconciliation.missingVideos > 0 || reconciliation.mappedImages < reconciliation.expectedImages
      ? "reconciling"
      : "landed";
    await upsertAgentBridgeRunState({
      projectId,
      tabId: tab.id,
      payload,
      status,
      reconciliation,
      reconciledRows: reconciliation.rows,
      expectedManifest
    }).catch((error) => {
      recordEvent({
        type: "agent_bridge.live_queue.reconcile_state_failed",
        projectId,
        tabId: tab.id,
        error: compactString(error?.message || error || "state_update_failed")
      });
    });
  }
  return {
    projectId,
    source: metadata.source,
    fetchedAt: new Date().toISOString(),
    page: {
      tabId: tab.id,
      url: pageState?.href || tab.url || "",
      title: pageState?.title || tab.title || "",
      projectId
    },
    projectInitialData: metadata.projectInitialData,
    ...(hasAgentManifestRows(expectedManifest) ? { expectedManifest } : {}),
    ...(reconciliation ? { reconciliation } : {})
  };
}

async function listAgentProjectMedia(payload = {}) {
  const { tab, pageState, projectId } = await resolveAgentBridgeFlowProject(payload, {
    unavailableCode: "PROJECT_MEDIA_UNAVAILABLE",
    bindingReason: "agent_bridge_media_list"
  });

  const timeoutMs = Math.max(5000, Math.min(120000, Number(payload.timeoutMs || 30000) || 30000));
  const feedTimeoutMs = Math.max(4000, Math.min(15000, Number(payload.feedTimeoutMs || Math.floor(timeoutMs * 0.55)) || 12000));
  const domTimeoutMs = Math.max(4000, Math.min(15000, timeoutMs - feedTimeoutMs - 1000));
  const maxProjectMedia = Math.max(100, Math.min(2000, Number(payload.maxProjectMedia || payload.limit || 1500) || 1500));
  const maxMediaNodes = Math.max(100, Math.min(2500, Number(payload.maxMediaNodes || 1200) || 1200));
  const requestedMediaId = compactString(payload.mediaId);
  const projectFeed = await sendPageCommand({
    action: "projectGeneratedMedia",
    projectId,
    maxProjectMedia,
    timeoutMs: feedTimeoutMs
  }, tab.id).catch((error) => ({ ok: false, error: String(error?.message || error || "project_media_feed_failed") }));
  const rows = Array.isArray(projectFeed?.rows) ? projectFeed.rows : [];
  const projectItems = Array.isArray(projectFeed?.items) ? projectFeed.items : [];
  const feedHasRequestedMedia = requestedMediaId
    ? [...rows, ...projectItems].some((record) => compactString(record?.mediaId || record?.id) === requestedMediaId)
    : true;

  let domScan = null;
  if (!projectFeed?.ok
    || (!rows.length && !projectItems.length)
    || payload.includeDom === true
    || payload.source === "dom"
    || !feedHasRequestedMedia) {
    domScan = await sendPageCommand({
      action: "scanGallery",
      options: {
        fullScroll: payload.fullScroll !== false,
        maxSteps: Math.max(1, Math.min(24, Number(payload.maxSteps || 18) || 18)),
        settleMs: Math.max(20, Math.min(120, Number(payload.settleMs || 35) || 35)),
        maxMediaNodes,
        includeProjectData: false
      },
      timeoutMs: domTimeoutMs
    }, tab.id).catch((error) => ({ ok: false, error: String(error?.message || error || "dom_gallery_scan_failed") }));
  }

  const domItems = Array.isArray(domScan?.items) ? domScan.items : [];
  const referenceMediaIds = domItems.length ? referenceMediaIdsFromTasks(ledger.listTasks()) : [];
  const usableDomItems = domItems.length
    ? filterGalleryItemsForProject(filterUsableGalleryItems(domItems, { referenceMediaIds }), projectId)
    : [];
  const combinedItems = dedupeAgentProjectMediaListItems([...projectItems, ...usableDomItems]);
  const items = filterAgentProjectMediaList(combinedItems, {
    projectId,
    mediaId: payload.mediaId,
    type: payload.type || payload.kind,
    latest: payload.latest
  });
  const filteredRows = filterAgentProjectMediaList(rows, {
    projectId,
    mediaId: payload.mediaId,
    type: payload.type || payload.kind,
    latest: payload.latest
  });

  if (!filteredRows.length && !items.length && !projectFeed?.ok && !domScan?.ok) {
    throw agentBridgeError("PROJECT_MEDIA_UNAVAILABLE", projectFeed?.error || domScan?.error || "No Flow project media matched this request.", {
      projectId,
      projectFeedOk: projectFeed?.ok === true,
      domScanOk: domScan?.ok === true
    });
  }

  return {
    ok: true,
    projectId,
    source: projectFeed?.ok ? "projectGeneratedMedia" : "dom_visible_media",
    fetchedAt: new Date().toISOString(),
    page: {
      tabId: tab.id,
      url: pageState?.href || tab.url || "",
      title: pageState?.title || tab.title || "",
      projectId
    },
    rows: filteredRows,
    items,
    meta: {
      projectId,
      source: projectFeed?.ok ? "projectGeneratedMedia" : "dom_visible_media",
      rowCount: filteredRows.length,
      itemCount: items.length,
      projectFeedOk: projectFeed?.ok === true,
      domScanOk: domScan?.ok === true,
      projectFeedError: projectFeed?.ok ? "" : compactString(projectFeed?.error),
      domScanError: domScan?.ok ? "" : compactString(domScan?.error)
    }
  };
}

function filterAgentProjectMediaList(records = [], options = {}) {
  return filterAgentProjectMediaListRecords(records, {
    ...options,
    kindField: "kind",
    timeField: "createdAt"
  });
}

function dedupeAgentProjectMediaListItems(items = []) {
  const seen = new Set();
  const output = [];
  for (const item of Array.isArray(items) ? items : []) {
    const mediaId = compactString(item?.mediaId || item?.id);
    if (!mediaId) continue;
    const kind = normalizeAgentBridgeMediaKind(item?.kind || item?.type);
    const key = `${kind || "media"}:${mediaId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(item);
  }
  return output;
}

function filterAgentProjectMediaListRecords(records = [], options = {}) {
  const mediaId = compactString(options.mediaId);
  const type = normalizeAgentBridgeMediaKind(options.type);
  const latest = Math.max(0, Number(options.latest || 0) || 0);
  const projectId = compactString(options.projectId);
  let filtered = (Array.isArray(records) ? records : []).filter((record) => {
    const recordMediaId = compactString(record?.mediaId || record?.id);
    if (!recordMediaId) return false;
    if (mediaId && recordMediaId !== mediaId) return false;
    const kind = normalizeAgentBridgeMediaKind(record?.[options.kindField] || record?.kind || record?.type);
    if (type && kind !== type) return false;
    const recordProjectId = compactString(record?.projectId);
    if (projectId && recordProjectId && recordProjectId !== projectId) return false;
    return true;
  });
  filtered.sort((left, right) => {
    const leftTime = Date.parse(left?.[options.timeField] || left?.createTime || left?.createdAt || "") || 0;
    const rightTime = Date.parse(right?.[options.timeField] || right?.createTime || right?.createdAt || "") || 0;
    if (rightTime !== leftTime) return rightTime - leftTime;
    return compactString(right?.mediaId || right?.id).localeCompare(compactString(left?.mediaId || left?.id));
  });
  if (latest > 0) filtered = filtered.slice(0, latest);
  return filtered;
}

async function planAgentBridgeDownloads(payload = {}) {
  await queueReady;
  const rows = Array.isArray(payload.reconciledRows) && payload.reconciledRows.length
    ? payload.reconciledRows
    : (Array.isArray(payload.rows) ? payload.rows : []);
  if (rows.length) {
    const artifactPlan = planAgentRunArtifacts({
      ...payload,
      rows,
      runName: payload.runName || payload.name || "Agent Run",
      reservedArtifactKeys: [...downloadReservations.artifacts.keys()],
      reservedTargetPaths: [...downloadReservations.targets.keys()]
    });
    return {
      execute: false,
      limitation: "Downloads are not executed through the native bridge in this pass; returning the Auto Flow artifact plan only.",
      plan: artifactPlan,
      downloads: artifactPlan.downloads || [],
      mediaDownloads: artifactPlan.mediaDownloads || artifactPlan.downloads || [],
      files: artifactPlan.files || [],
      skipped: artifactPlan.skipped || []
    };
  }

  const projectId = compactString(payload.projectId || runtimeState.lastGalleryProjectId || runtimeState.projectId);
  const mediaIds = agentBridgeRequestedMediaIds(payload);
  const gallery = galleryState(
    runtimeState.lastGalleryItems || [],
    runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger",
    projectId
  );
  const galleryMediaIds = new Set(gallery.items.map((item) => compactString(item.mediaId)).filter(Boolean));
  // Derive each synthetic mediaId's real kind from the task ledger (falling back to an
  // explicit caller hint) instead of blindly defaulting to "videos". A defaulted
  // "videos" kind hid image auth expiry: an image serving text/html after Flow session
  // auth expired read as retryable video readiness lag. Genuinely-unknown ids resolve
  // to "" and fail safe downstream (video-treated/retryable), never over-classified as
  // auth without positive image evidence.
  const requestedKindHint = compactString(payload.kind || payload.mediaKind || payload.type);
  const ledgerKindByMediaId = agentBridgeMediaKindIndex();
  const syntheticItems = mediaIds
    .filter((mediaId) => !galleryMediaIds.has(mediaId))
    .map((mediaId, index) => syntheticAgentBridgeGalleryItem(mediaId, {
      index,
      projectId,
      kind: ledgerKindByMediaId.get(mediaId) || requestedKindHint
    }));
  const selectedIds = [...new Set([
    ...(Array.isArray(payload.selectedIds) ? payload.selectedIds : []),
    ...mediaIds
  ].map(compactString).filter(Boolean))];
  const rawPlans = planMediaDownloads([...gallery.items, ...syntheticItems], {
    selectedIds,
    folder: payload.folder || payload.outputRoot || payload.rootFolder || "Auto Flow",
    imageResolution: payload.imageResolution || "1k",
    videoResolution: payload.videoResolution || "720p",
    filenameStyle: payload.filenameStyle || "",
    filenameTemplatePrefix: payload.filenameTemplatePrefix || "",
    filenameTemplateIndex: payload.filenameTemplateIndex || "",
    filenameTemplatePromptPart: payload.filenameTemplatePromptPart || "",
    filenameTemplateDate: payload.filenameTemplateDate || "",
    filenameTemplateSuffix: payload.filenameTemplateSuffix || "",
    filenameTemplateSeparator: payload.filenameTemplateSeparator || "",
    reservedArtifactKeys: [...downloadReservations.artifacts.keys()],
    reservedTargetPaths: [...downloadReservations.targets.keys()]
  });
  // Raw media-id plans do not naturally carry reconciled row ownership. Browser
  // callers are required to send explicit rowIds + mediaIds, so preserve that
  // positional ownership on every plan before downloads.execute scopes it. A
  // single row id may own several output media ids; otherwise arrays must align.
  const requestedRowIds = (Array.isArray(payload.rowIds) ? payload.rowIds : []).map(compactString).filter(Boolean);
  const requestedMediaIds = (Array.isArray(payload.mediaIds) ? payload.mediaIds : []).map(compactString).filter(Boolean);
  const rowIdByMediaId = new Map();
  if (requestedRowIds.length === 1) {
    requestedMediaIds.forEach((mediaId) => rowIdByMediaId.set(mediaId, requestedRowIds[0]));
  } else if (requestedRowIds.length === requestedMediaIds.length) {
    requestedMediaIds.forEach((mediaId, index) => rowIdByMediaId.set(mediaId, requestedRowIds[index]));
  }
  const plans = rawPlans.map((plan) => ({
    ...plan,
    ...(rowIdByMediaId.get(compactString(plan.mediaId)) ? { rowId: rowIdByMediaId.get(compactString(plan.mediaId)) } : {})
  }));
  return {
    execute: false,
    limitation: "Downloads are not executed through the native bridge in this pass; returning the Auto Flow download plan only.",
    planned: plans.length,
    plan: {
      downloads: plans,
      mediaDownloads: plans,
      files: [],
      skipped: []
    },
    downloads: plans,
    mediaDownloads: plans,
    files: [],
    skipped: []
  };
}

// downloads.execute runtime: actually save the generated media. This is the only
// context with both chrome.downloads and the Flow session cookies, so an external
// CLI/MCP agent calls here to retrieve files. Reuses the proven sidepanel path
// (planAgentBridgeDownloads -> executeDownloadPlans, which reserves artifacts and
// retries video readiness) and returns each saved file's ABSOLUTE OS path so the
// CLI can copy it into the caller's --out directory.
async function executeDownloadsForAgent(payload = {}, request = {}) {
  await queueReady;
  const requestedTransport = compactString(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  const chromeSessionApi = (requestedTransport === "api" || requestedTransport === "agent_api")
    && payload.chromeSessionAuth === true;
  const missingTargetFields = [];
  if (!compactString(payload.projectId)) missingTargetFields.push("projectId");
  if (!chromeSessionApi && !compactString(payload.tabId)) missingTargetFields.push("tabId");
  if (missingTargetFields.length) {
    throw agentBridgeError(
      "INVALID_PAYLOAD",
      `downloads.execute requires ${missingTargetFields.join(" and ")}. Run lane inventory and pass the exact Flow target before executing downloads.`,
      { missing: missingTargetFields }
    );
  }
  // Defense in depth: frontend downloads bind the exact tab; Chrome-session
  // API downloads prove account access to the exact project and stay bound to
  // the broker lane's approved extension instance.
  if (chromeSessionApi) {
    try {
      await flowChromeSession.getAccessToken();
    } catch (error) {
      throw agentBridgeError(error?.code || "FLOW_CHROME_LOGIN_REQUIRED", error?.message || "Google Flow login is unavailable in this Chrome profile.", error?.details);
    }
    const metadata = await fetchAgentProjectInitialDataInBackground(payload.projectId, agentBridgeProjectRootUrl("", payload.projectId));
    if (!metadata.ok) {
      throw agentBridgeError(metadata.status === 401 ? "FLOW_AUTH_EXPIRED" : "METADATA_UNAVAILABLE", metadata.error || "Flow project metadata is unavailable for download scope.", {
        status: Number(metadata.status || 0),
        projectId: compactString(payload.projectId)
      });
    }
  } else {
    const targetCheck = evaluateAgentTarget({
      requestedProjectId: payload.projectId,
      requestedTabId: payload.tabId,
      resolvedProjectId: compactString(runtimeState.projectId),
      resolvedTabId: runtimeState.activeTabId
    });
    if (!targetCheck.ok) {
      throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
    }
  }
  await assertAgentBridgeWriteEntitled(payload);

  const suppliedPlan = payload.plan && typeof payload.plan === "object" ? payload.plan : null;
  const scopedSuppliedPlan = suppliedPlan
    ? scopeAgentArtifactPlan(suppliedPlan, {
        rowIds: payload.rowIds,
        mediaIds: payload.mediaIds
      })
    : null;
  const planResult = suppliedPlan
    ? {
        execute: false,
        plan: scopedSuppliedPlan,
        downloads: Array.isArray(scopedSuppliedPlan.downloads)
          ? scopedSuppliedPlan.downloads
          : (Array.isArray(scopedSuppliedPlan.mediaDownloads) ? scopedSuppliedPlan.mediaDownloads : [])
      }
    : await planAgentBridgeDownloads(payload);
  const planned = Array.isArray(planResult.plan?.downloads)
    ? planResult.plan.downloads
    : (Array.isArray(planResult.downloads) ? planResult.downloads : []);
  if (!planned.length) {
    throw agentBridgeError(
      "AGENT_NO_DOWNLOADS",
      "No downloadable media matched this request. Reconcile the project first, then pass the resulting mediaIds or reconciledRows."
    );
  }

  const results = await executeDownloadPlans(planned, "agent-bridge");
  const downloads = [];
  const paths = {};
  const errors = [];
  for (const result of results) {
    const mediaId = compactString(result.mediaId);
    const absolutePath = compactString(result.absolutePath || result.completedPath || result.finalFilepath || result.filename);
    const ok = result.ok === true && Boolean(absolutePath);
    downloads.push({
      mediaId,
      relativePath: result.relativePath || result.downloadPath || "",
      filename: ok ? absolutePath : "",
      plannedFilename: result.plannedFilename || result.filename || "",
      ok,
      fileSize: Number(result.fileSize || 0)
    });
    if (ok) {
      if (mediaId) paths[mediaId] = absolutePath;
    } else {
      const reason = compactString(result.error || "download_failed");
      const reserved = /reserv|dedupe|blocked/i.test(reason);
      const mediaKind = compactString(result.kind || result.mediaKind);
      const classification = reserved ? null : classifyAgentDownloadError(reason, mediaKind, result.plannedFilename || result.filename || "");
      const retryable = !reserved && (classification?.retryable ?? isRetryableAgentDownloadError(reason));
      errors.push({
        mediaId,
        error: reserved ? "ARTIFACT_RESERVED" : reason,
        ...(mediaKind ? { kind: mediaKind } : {}),
        ...(!reserved && classification?.code ? {
          code: classification.code,
          failureClass: classification.failureClass,
          actionNeeded: classification.actionNeeded,
          nextActions: classification.nextActions
        } : {}),
        retryable,
        ...(reserved ? { retryAfterMs: 5000 } : {}),
        ...(!reserved && retryable ? { retryAfterMs: 30000 } : {})
      });
    }
  }
  const savedCount = downloads.filter((entry) => entry.ok).length;
  return {
    ok: errors.length === 0 && savedCount > 0,
    executed: true,
    saved: savedCount,
    downloads,
    paths,
    errors
  };
}

function isRetryableAgentDownloadError(reason = "") {
  // Wrong media kind (JPEG when MP4 expected) is terminal for this mediaId —
  // do not treat it as readiness lag or a transient network glitch.
  if (/^download_wrong_media_kind:/i.test(String(reason || ""))) return false;
  return /download_too_small|SERVER_FAILED|SERVER_BAD_CONTENT|server failed|site wasn.t available|download_interrupted|download_timeout/i.test(String(reason || ""));
}

function classifyAgentDownloadError(reason = "", kind = "", filename = "") {
  const value = String(reason || "");
  if (/^download_wrong_media_kind:/i.test(value)) {
    return {
      code: "DOWNLOAD_WRONG_MEDIA_KIND",
      failureClass: "download_wrong_media_kind",
      retryable: false,
      actionNeeded: "Reconcile again and download only media whose kind matches the expected output (video vs image). Do not treat reference/image media as a video result.",
      nextActions: [
        "Re-run project reconcile and inspect row.kind / media CDN path (image vs video).",
        "Select only mediaIds with kind videos when the run expected videos.",
        "Do not re-download the same image mediaId as a video output."
      ],
      actualKind: /image_when_video/i.test(value) ? "images" : (/video_when_image/i.test(value) ? "videos" : detectArtifactMediaKind({ filename })),
      expectedKind: resolveDownloadMediaKind(kind, filename)
    };
  }
  if (!/^download_bad_content:html_/i.test(value)) return null;
  // Only positive image evidence (an image kind, or an image filename when kind is
  // missing) marks an HTML download as expired Flow auth. Video and genuinely-unknown
  // media stay retryable so slow-but-valid video readiness lag is never misreported
  // as auth. This keeps the mediaIds-only synthetic path from hiding an image auth
  // expiry behind a defaulted "videos" kind.
  if (resolveDownloadMediaKind(kind, filename) !== "images") {
    return { retryable: true };
  }
  return {
    code: "FLOW_DOWNLOAD_AUTH_EXPIRED",
    failureClass: "download_auth",
    retryable: false,
    actionNeeded: "Refresh or re-authenticate the target Flow lane, then rerun reconcile and downloads. Do not regenerate the media just to fix downloads.",
    nextActions: [
      "Refresh the exact Flow tab/project used for this run and confirm the Google/Flow session is still signed in.",
      "Rerun reconcile against the same projectId/tabId.",
      "Rerun downloads.execute or autoflow_download_outputs with the same reconciled rows."
    ]
  };
}

// In-memory mutex for live Agent submits, keyed by projectId||tabId.
// Prevents two concurrent live submits from racing the debugger into the same
// Flow composer (P0-2). Dry-runs and reconcile never acquire it.
const agentSubmitLock = createAgentSubmitLock();
const agentSubmitIdempotency = new Map();
const agentApiClientSessionIds = new Map();
const agentApiUploadedReferenceIds = new Map();
const flowChromeSession = createFlowChromeSession({ fetchImpl: fetch });

async function assertAgentBridgeWriteEntitled(payload = {}) {
  if (payload.dryRun === true) return true;
  let freshError = "";
  let authSummary = null;
  try {
    const freshLicense = await licenseClient.refreshLicense();
    authSummary = await updateAuthState(freshLicense);
  } catch (error) {
    freshError = compactString(error?.message || error || "agent_bridge_license_refresh_failed");
  }
  if (!authSummary) {
    const staleSummary = runtimeState.auth || await updateAuthState().catch(() => null);
    const staleAccess = staleSummary ? agentBridgeAccessFromAuthSummary(staleSummary) : null;
    authSummary = null;
    if (staleAccess?.reason === "not_signed_in") {
      authSummary = staleSummary;
    }
  }
  let access = authSummary
    ? agentBridgeAccessFromAuthSummary(authSummary)
    : {
        allowed: false,
        reason: freshError ? "license_check_unavailable" : "not_signed_in",
        error: freshError ? "license_check_unavailable" : "not_signed_in"
      };
  if (access.allowed === true) {
    recordEvent({
      type: "license.agent_bridge.pro_check",
      allowed: true,
      reason: access.reason || "",
      tier: access.tier || "",
      subscriptionStatus: access.subscriptionStatus || ""
    });
    return true;
  }
  if (access.reason === "license_check_unavailable") {
    const cachedPro = await cachedActiveProAccess().catch((error) => ({
      ok: false,
      reason: compactString(error?.message || error || "cached_pro_check_failed")
    }));
    if (cachedPro.ok === true) {
      recordEvent({
        type: "license.agent_bridge.cached_pro_allow",
        tier: cachedPro.tier || "pro",
        subscriptionStatus: cachedPro.subscriptionStatus || "",
        cacheAgeMs: cachedPro.ageMs || 0
      });
      return true;
    }
    access = { ...access, cachedProReason: cachedPro.reason || "cached_pro_unavailable" };
  }
  recordEvent({
    type: "license.agent_bridge.pro_check",
    allowed: false,
    reason: access.reason || "",
    tier: access.tier || "",
    subscriptionStatus: access.subscriptionStatus || "",
    billingHealth: access.billingHealth || "",
    refreshError: freshError
  });
  const code = access.reason === "not_signed_in" ? "AUTO_FLOW_AUTH_REQUIRED" : "AUTO_FLOW_PRO_REQUIRED";
  throw agentBridgeError(code, "Auto Flow Pro is required for CLI/MCP live Agent actions.", {
    reason: access.reason || access.error || "not_allowed",
    signedIn: access.signedIn === true,
    tier: access.tier || "",
    subscriptionStatus: access.subscriptionStatus || "",
    billingHealth: access.billingHealth || "",
    usage: access.usage || null,
    // freshError is the license-refresh failure captured above; do not reference an undefined refreshError.
    refreshError: freshError || "",
    cachedProReason: access.cachedProReason || ""
  });
}

function agentSubmitIdempotencyKey(payload = {}, prompt = "", tabId = 0, projectId = "", request = {}) {
  const explicit = compactString(payload.idempotencyKey);
  if (explicit) return `${compactString(projectId)}||${compactString(tabId)}||${explicit}`;
  const stablePayload = {
    prompt: compactString(prompt),
    laneId: compactString(payload.laneId),
    mode: compactString(payload.mode || payload.agentMode),
    rowIds: Array.isArray(payload.rowIds) ? payload.rowIds.map(compactString).filter(Boolean) : [],
    issue: compactString(payload.issue || payload.issueLabel || (Array.isArray(payload.issueChips) ? payload.issueChips.join(",") : "")),
    notes: compactString(payload.notes || payload.guidance || ""),
    refs: Array.isArray(payload.refs) ? payload.refs.map((ref) => typeof ref === "string" ? compactString(ref) : ref).filter(Boolean) : [],
    targetRefs: Array.isArray(payload.targetRefs) ? payload.targetRefs.map(compactString).filter(Boolean) : [],
    dryRun: payload.dryRun === true,
    autoConfirm: payload.autoConfirm === true || payload.confirmCredits === true || payload.autoConfirmCredits === true,
    settings: payload.settings && typeof payload.settings === "object" ? payload.settings : null
  };
  return `${compactString(projectId)}||${compactString(tabId)}||prompt:${hashCompactString(JSON.stringify(stablePayload))}`;
}

function pruneAgentSubmitIdempotency() {
  const cutoff = Date.now() - AGENT_SUBMIT_IDEMPOTENCY_TTL_MS;
  for (const [key, entry] of agentSubmitIdempotency.entries()) {
    const at = Number(entry.completedAt || entry.startedAt || 0);
    if (!at || at < cutoff) agentSubmitIdempotency.delete(key);
  }
}

function hashCompactString(value = "") {
  let hash = 5381;
  const text = String(value || "");
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash + text.charCodeAt(index)) >>> 0;
  }
  return hash.toString(16);
}

const AGENT_BATCH_SUPERVISOR_STORAGE_KEY = "autoflow-agent-batch-supervisor-v1";

function safeBulkVideoEditBatchQuestionAnswer(action = {}, matrix = {}) {
  if (String(matrix?.kind || "") !== "agent_bulk_video_edit" || !action?.kind || action.kind === "credit_confirmation") return "";
  const choices = (Array.isArray(action.choices) ? action.choices : [])
    .map((choice) => compactString(choice?.label || choice?.text || choice))
    .filter(Boolean);
  if (!choices.length) return "";
  if (action.kind === "model_duration_choice") {
    const exact = choices.filter((choice) => /omni\s*flash/i.test(choice) && !/change|switch|shorter|longer|different/i.test(choice));
    return exact.length === 1 ? exact[0] : "";
  }
  if (action.kind === "agent_choice") {
    const exact = choices.filter((choice) => /^(?:continue|proceed|generate|start|yes|apply|edit all)(?:\b|$)/i.test(choice) && !/change|different|skip|cancel/i.test(choice));
    return exact.length === 1 ? exact[0] : "";
  }
  return "";
}

async function submitAgentBatchesFromBridge(payload = {}, request = {}) {
  const batches = Array.isArray(payload.batches) ? payload.batches : [];
  const runId = compactString(payload.runId);
  if (!runId) throw agentBridgeError("AGENT_BATCH_RUN_ID_REQUIRED", "Sequential Agent batches require a stable RUN_ID.");
  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  await assertAgentBridgeWriteEntitled(payload);

  const stored = await chrome.storage.local.get(AGENT_BATCH_SUPERVISOR_STORAGE_KEY).catch(() => ({}));
  const prior = stored?.[AGENT_BATCH_SUPERVISOR_STORAGE_KEY] || null;
  if (prior?.runId === runId) {
    const priorAction = nextAgentBatchAction(prior);
    if (priorAction.action === "blocked" && priorAction.code === "AGENT_BATCH_SUBMIT_UNCERTAIN") {
      throw agentBridgeError(priorAction.code, "A prior batch submit write is uncertain; inspect Flow and reconcile before any retry.", priorAction);
    }
  } else if (prior && ["ready", "running"].includes(prior.status)) {
    throw agentBridgeError("AGENT_BATCH_RUN_ACTIVE", "Another sequential Agent batch run is still active for this extension profile.", {
      activeRunId: prior.runId,
      requestedRunId: runId
    });
  }

  let state = createAgentBatchSupervisorState({
    runId,
    projectId,
    tabId: tab.id,
    batches: batches.map((batch, index) => ({
      batchId: batch.batchId || batch.matrix?.batch?.batchId || `BATCH-${String(index + 1).padStart(3, "0")}`,
      rowCount: batch.rowCount ?? batch.matrix?.rows?.length ?? 0
    }))
  });
  const persist = async () => {
    await chrome.storage.local.set({ [AGENT_BATCH_SUPERVISOR_STORAGE_KEY]: state });
  };
  await persist();

  const baselineMetadata = await getAgentProjectMetadata({
    projectId,
    tabId: tab.id,
    expectedManifest: batches[0]?.expectedManifest || batches[0]?.manifest || null,
    runId
  });
  const baselineMediaIds = new Set(
    (baselineMetadata.reconciliation?.mediaRecords || [])
      .map((record) => compactString(record.mediaId || record.id))
      .filter(Boolean)
  );
  const results = [];
  let supervisedApprovedCredits = 0;
  while (true) {
    const action = nextAgentBatchAction(state);
    if (action.action === "complete") break;
    if (action.action !== "submit") {
      throw agentBridgeError(action.code || "AGENT_BATCH_SUPERVISOR_BLOCKED", "Sequential Agent batch supervisor cannot safely continue.", { action, state });
    }
    const index = action.batchIndex - 1;
    const batch = batches[index] || {};
    const batchId = action.batchId;
    const prompt = compactString(batch.prompt);
    if (!prompt) throw agentBridgeError("AGENT_BATCH_PROMPT_EMPTY", `${batchId} has no prompt.`);
    const expectedManifest = batch.expectedManifest || batch.manifest || null;
    const batchBaselineMediaIds = [...baselineMediaIds];

    state = updateAgentBatchSupervisorState(state, batchId, {
      status: "submitting",
      submitMarker: "pending",
      submitStartedAt: new Date().toISOString()
    });
    await persist();

    let submitResult;
    try {
      submitResult = await submitAgentPromptFromBridge({
        ...payload,
        ...batch,
        prompt,
        expectedManifest,
        manifest: expectedManifest,
        runId: `${runId}:${batchId}`,
        parentRunId: runId,
        batchId,
        projectId,
        tabId: tab.id,
        clearExistingRefs: true,
        ensureNativeSettings: index === 0 && payload.ensureNativeSettings !== false,
        ensureManagedAgentInstructions: index === 0 && payload.ensureManagedAgentInstructions !== false,
        idempotencyKey: `${runId}:${batchId}:${hashCompactString(prompt)}`
      }, { ...request, type: MessageType.AgentBatchSubmit, id: `${compactString(request.id || runId)}:${batchId}` });
    } catch (error) {
      const errorCode = compactString(error?.code || error?.message || "agent_batch_submit_failed");
      const uncertainWrite = /NATIVE_BROKER_WRITE_AMBIGUOUS|AGENT_SUBMIT_NOT_ACCEPTED|SUBMIT_UNCERTAIN|POSSIBLE_SIDE_EFFECT/i.test(errorCode);
      state = updateAgentBatchSupervisorState(state, batchId, {
        status: uncertainWrite ? "submit_uncertain" : "blocked",
        submitMarker: uncertainWrite ? "pending" : "not_submitted",
        error: errorCode
      });
      await persist();
      throw error;
    }
    if (submitResult.submitted !== true || submitResult.waitingForCreditApproval === true) {
      state = updateAgentBatchSupervisorState(state, batchId, {
        status: "blocked",
        submitMarker: "not_submitted",
        error: submitResult.waitingForCreditApproval ? "waiting_for_credit_approval" : "agent_batch_not_submitted"
      });
      await persist();
      return { ok: false, runId, projectId, tabId: tab.id, state, results, blocked: submitResult };
    }
    state = updateAgentBatchSupervisorState(state, batchId, {
      status: "submitted",
      submitMarker: "accepted",
      submittedAt: new Date().toISOString()
    });
    await persist();
    try {
      await waitForAgentBatchComposerIdleAndClear(tab.id, prompt, {
        timeoutMs: batch.idleTimeoutMs || payload.batchIdleTimeoutMs || 120000
      });
    } catch (error) {
      state = updateAgentBatchSupervisorState(state, batchId, {
        status: "blocked",
        error: compactString(error?.code || error?.message || "AGENT_BATCH_IDLE_CLEAR_FAILED")
      });
      await persist();
      throw error;
    }

    const timeoutMs = Math.max(10000, Math.min(45 * 60 * 1000, Number(batch.reconcileTimeoutMs || payload.reconcileTimeoutMs || 30 * 60 * 1000) || 30 * 60 * 1000));
    const pollMs = Math.max(1000, Math.min(15000, Number(batch.reconcilePollMs || payload.reconcilePollMs || 5000) || 5000));
    const deadline = Date.now() + timeoutMs;
    let reconciliation = null;
    const answeredQuestionKeys = new Set();
    const batchQuestionAnswers = [];
    while (Date.now() < deadline) {
      const metadata = await getAgentProjectMetadata({ projectId, tabId: tab.id, expectedManifest, runId, batchId });
      reconciliation = metadata.reconciliation || null;
      if (agentBatchFreshReconciliationComplete(reconciliation, batchBaselineMediaIds)) break;
      if (String(batch.matrix?.kind || payload.matrix?.kind || "") === "agent_bulk_video_edit") {
        const context = await getAgentScreenContextFromBridge({
          ...payload,
          projectId,
          tabId: tab.id,
          expectedManifest,
          runId,
          batchId
        }).catch(() => null);
        const actionRequired = context?.uiState?.actionRequired || null;
        if (actionRequired?.kind === "credit_confirmation") {
          const creditDecision = decideAgentCreditDialogApproval(actionRequired, {
            creditPolicy: payload.creditPolicy,
            approvedCredits: supervisedApprovedCredits,
            autoConfirm: false
          });
          const creditQuestionKey = creditDecision.approved === true
            ? hashCompactString(`credit_confirmation:${actionRequired.text || ""}:${creditDecision.creditAmount || 0}`)
            : "";
          if (creditQuestionKey && !answeredQuestionKeys.has(creditQuestionKey)) {
            // Mark before dispatch. Flow can show the same approval card on every
            // Agent batch regardless of its native confirmation preference.
            answeredQuestionKeys.add(creditQuestionKey);
            const confirmationResult = await confirmAgentCreditsFromBridge({
              ...payload,
              projectId,
              tabId: tab.id,
              persistentApproval: false,
              dontAskAgain: false
            });
            if (confirmationResult?.confirmed !== true) {
              throw agentBridgeError("AGENT_BATCH_CREDIT_CONFIRMATION_NOT_ACCEPTED", `${batchId} credit confirmation was not accepted; do not replay it automatically.`, {
                batchId,
                questionKey: creditQuestionKey,
                creditDecision,
                possibleSideEffect: true
              });
            }
            supervisedApprovedCredits = Number(creditDecision.nextTotal || supervisedApprovedCredits) || supervisedApprovedCredits;
            batchQuestionAnswers.push({
              questionKey: creditQuestionKey,
              kind: "credit_confirmation",
              answer: "one_time_approve",
              creditAmount: Number(creditDecision.creditAmount || 0) || 0,
              approvedCredits: supervisedApprovedCredits,
              persistentApproval: false,
              answeredAt: new Date().toISOString()
            });
          }
        }
        const answer = safeBulkVideoEditBatchQuestionAnswer(actionRequired, batch.matrix || payload.matrix || {});
        const questionKey = answer ? hashCompactString(`${actionRequired?.kind || ""}:${actionRequired?.text || ""}:${answer}`) : "";
        if (answer && questionKey && !answeredQuestionKeys.has(questionKey)) {
          // Mark before dispatch. An unreadable reply response is a possible
          // side effect and must never trigger another answer submission.
          answeredQuestionKeys.add(questionKey);
          const answerResult = await submitAgentPromptFromBridge({
            ...payload,
            prompt: answer,
            refs: [],
            targetRefs: [],
            clearExistingRefs: false,
            expectedManifest,
            manifest: expectedManifest,
            runId: `${runId}:${batchId}:answer:${questionKey}`,
            parentRunId: runId,
            batchId,
            projectId,
            tabId: tab.id,
            idempotencyKey: `${runId}:${batchId}:answer:${questionKey}`
          }, { ...request, type: MessageType.AgentPromptSubmit, id: `${compactString(request.id || runId)}:${batchId}:answer:${questionKey}` });
          if (answerResult?.submitted !== true) {
            throw agentBridgeError("AGENT_BATCH_QUESTION_ANSWER_NOT_ACCEPTED", `${batchId} questionnaire answer was not accepted; do not replay it automatically.`, {
              batchId,
              questionKey,
              answer,
              possibleSideEffect: true
            });
          }
          batchQuestionAnswers.push({ questionKey, kind: actionRequired.kind, answer, answeredAt: new Date().toISOString() });
        }
      }
      state = updateAgentBatchSupervisorState(state, batchId, { status: "reconciling" });
      await persist();
      await sleep(pollMs);
    }
    if (!agentBatchFreshReconciliationComplete(reconciliation, batchBaselineMediaIds)) {
      state = updateAgentBatchSupervisorState(state, batchId, { status: "blocked", error: "AGENT_BATCH_RECONCILE_TIMEOUT" });
      await persist();
      throw agentBridgeError("AGENT_BATCH_RECONCILE_TIMEOUT", `${batchId} did not reconcile before the sequential batch deadline.`, { batchId, reconciliation });
    }
    for (const record of reconciliation?.mediaRecords || []) {
      const mediaId = compactString(record.mediaId || record.id);
      if (mediaId) baselineMediaIds.add(mediaId);
    }
    state = updateAgentBatchSupervisorState(state, batchId, {
      status: "reconciled",
      reconciledAt: new Date().toISOString()
    });
    await persist();
    results.push({
      batchId,
      submitted: true,
      reconciled: true,
      submitResult,
      reconciliation,
      questionAnswers: batchQuestionAnswers,
      allMediaIds: [...baselineMediaIds]
    });
  }
  return { ok: true, runId, projectId, tabId: tab.id, state, results };
}

async function waitForAgentBatchComposerIdleAndClear(tabId = 0, prompt = "", options = {}) {
  const target = debuggerTarget(tabId);
  const timeoutMs = Math.max(5000, Math.min(5 * 60 * 1000, Number(options.timeoutMs || 120000) || 120000));
  const deadline = Date.now() + timeoutMs;
  await releaseDebuggerSessions("agent_batch_idle_clear", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});
    while (Date.now() < deadline) {
      const draft = await readAgentDebuggerCurrentComposerDraft(target);
      if (!draft?.ok) {
        const composerState = await debuggerReadComposerState(target).catch(() => null);
        const texts = [compactString(composerState?.activeText || ""), ...(composerState?.editors || []).map((entry) => compactString(entry.text))];
        const activeGeneration = await debuggerEvaluate(target, `(() => Array.from(document.querySelectorAll("button,[role='button']")).some((button) => {
          const rect = button.getBoundingClientRect();
          const tokens = new Set(String(button.innerText || button.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
          return rect.width > 0 && rect.height > 0 && (tokens.has("stop") || tokens.has("stop_circle"));
        }))()`).catch(() => true);
        if (activeGeneration !== true && !agentPromptInserted(texts, prompt)) {
          return { ok: true, cleared: false, reason: "composer_blank" };
        }
      }
      if (draft?.ok && draft.activeGeneration !== true) {
        const text = compactString(draft.text);
        if (!text) return { ok: true, cleared: false, reason: "composer_blank" };
        if (hashAgentManagedText(text) !== hashAgentManagedText(prompt)) {
          throw agentBridgeError("AGENT_BATCH_COMPOSER_CONFLICT", "Flow Agent composer changed after the prior batch; Auto Flow preserved it and stopped sequential continuation.", {
            expectedPromptHash: hashAgentManagedText(prompt),
            actualPromptHash: hashAgentManagedText(text),
            draftPreview: text.slice(0, 160)
          });
        }
        await debuggerReplaceAgentEditorText(target, draft.editorRect, "");
        await sleep(250);
        const after = await debuggerReadComposerState(target);
        const texts = [compactString(after?.activeText || ""), ...(after?.editors || []).map((entry) => compactString(entry.text))];
        if (agentPromptInserted(texts, prompt)) {
          throw agentBridgeError("AGENT_SUBMITTED_PROMPT_CLEAR_FAILED", "Submitted Agent batch prompt remained in the composer after the Agent became idle.", {
            promptHash: hashAgentManagedText(prompt)
          });
        }
        return { ok: true, cleared: true };
      }
      await sleep(750);
    }
    throw agentBridgeError("AGENT_BATCH_IDLE_TIMEOUT", "Flow Agent did not become idle before the next sequential batch deadline.", {
      timeoutMs,
      promptHash: hashAgentManagedText(prompt)
    });
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function findExactFlowProjectTab(projectId = "", preferredTabId = 0) {
  const wantedProjectId = compactString(projectId);
  const preferred = Number(preferredTabId || 0)
    ? await chrome.tabs.get(Number(preferredTabId)).catch(() => null)
    : null;
  if (preferred?.id && projectIdFromUrl(preferred.url || "") === wantedProjectId) return preferred;
  const tabs = await listFlowProjectTabs();
  return tabs.find((tab) => projectIdFromUrl(tab.url || "") === wantedProjectId) || null;
}

async function waitForAgentApiAuthTab(tabId = 0, timeoutMs = 30000) {
  const deadline = Date.now() + Math.max(5000, Number(timeoutMs || 30000));
  let lastError = "";
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(Number(tabId)).catch(() => null);
    if (!tab?.id) throw agentBridgeError("AGENT_API_AUTH_TAB_CLOSED", "The temporary Flow authentication tab closed before reCAPTCHA was ready.");
    if (tab.status === "complete") {
      const bridge = await ensureFlowBridge(tab.id).catch((error) => ({ ok: false, error: String(error?.message || error || "flow_bridge_not_ready") }));
      if (bridge?.ok) return tab;
      lastError = compactString(bridge?.error);
    }
    await sleep(350);
  }
  throw agentBridgeError("AGENT_API_AUTH_TAB_TIMEOUT", "The temporary Flow authentication tab did not become ready for reCAPTCHA.", { tabId, lastError });
}

async function withAgentApiRecaptchaTab(projectId = "", preferredTabId = 0, callback) {
  let tab = await findExactFlowProjectTab(projectId, preferredTabId);
  let temporary = false;
  if (!tab?.id) {
    tab = await chrome.tabs.create({
      url: agentBridgeProjectRootUrl("", projectId),
      active: false
    });
    temporary = true;
  }
  try {
    tab = await waitForAgentApiAuthTab(tab.id);
    return await callback(tab, { temporary });
  } finally {
    if (temporary && tab?.id) await chrome.tabs.remove(tab.id).catch(() => null);
  }
}

async function resolveAgentApiReferenceUploads(payload = {}, projectId = "", flowClient) {
  const plan = planFlowAgentApiReferences(payload);
  if (!plan.ok) throw agentBridgeError(plan.code, plan.message, plan.details);
  if (!plan.attachments.length) return { plan, mediaIds: [], uploads: [] };
  if (!flowClient?.uploadImage) throw agentBridgeError("AGENT_API_REF_UPLOAD_UNAVAILABLE", "Flow reference upload transport is unavailable.");
  const uploads = [];
  for (const attachment of plan.attachments) {
    if (attachment.mediaId) {
      uploads.push({ handle: attachment.handle, sourceIdentity: attachment.sourceIdentity, mediaId: attachment.mediaId, reused: true });
      continue;
    }
    const cacheKey = `${compactString(projectId)}:${attachment.sourceIdentity}`;
    const cachedMediaId = compactString(agentApiUploadedReferenceIds.get(cacheKey));
    if (cachedMediaId) {
      uploads.push({ handle: attachment.handle, sourceIdentity: attachment.sourceIdentity, mediaId: cachedMediaId, reused: true });
      continue;
    }
    const fetched = await fetchFlowAgentApiReference(attachment);
    const response = await flowClient.uploadImage({
      projectId,
      imageBytes: fetched.imageBytes,
      mimeType: fetched.mimeType,
      fileName: fetched.fileName,
      isHidden: false
    });
    const mediaIds = mediaIdsFrom(response?.mediaIds);
    if (!response?.ok || mediaIds.length !== 1) {
      throw agentBridgeError("AGENT_API_REF_UPLOAD_FAILED", "Flow reference upload did not return exactly one media ID.", {
        handle: attachment.handle,
        status: Number(response?.status || 0),
        mediaIdCount: mediaIds.length
      });
    }
    agentApiUploadedReferenceIds.set(cacheKey, mediaIds[0]);
    uploads.push({
      handle: attachment.handle,
      sourceIdentity: attachment.sourceIdentity,
      mediaId: mediaIds[0],
      reused: false,
      byteLength: fetched.byteLength,
      sha256: fetched.sha256,
      mimeType: fetched.mimeType
    });
    recordEvent({
      type: "agent_bridge.reference.uploaded_api",
      projectId,
      handle: attachment.handle,
      mediaId: mediaIds[0],
      byteLength: fetched.byteLength,
      mimeType: fetched.mimeType
    });
  }
  return {
    plan,
    mediaIds: uploads.map((upload) => upload.mediaId),
    uploads
  };
}

async function resolveAgentApiTarget(payload = {}) {
  const projectId = compactString(payload.projectId);
  if (!projectId) throw agentBridgeError("AGENT_API_PROJECT_REQUIRED", "Chrome-session Agent API generation requires an exact projectId.");
  const requestedTabId = Number(payload.tabId || payload.activeTabId || 0) || 0;
  if (requestedTabId) {
    const requestedTab = await chrome.tabs.get(requestedTabId).catch(() => null);
    const requestedTabProjectId = requestedTab?.id ? projectIdFromUrl(requestedTab.url || "") : "";
    if (requestedTabProjectId && requestedTabProjectId !== projectId) {
      throw agentBridgeError("AGENT_TARGET_MISMATCH", "The remembered Flow tab now belongs to a different project.", {
        requestedProjectId: projectId,
        requestedTabId,
        resolvedProjectId: requestedTabProjectId
      });
    }
  }
  const tab = await findExactFlowProjectTab(projectId, requestedTabId);
  return {
    projectId,
    requestedTabId,
    tab: tab || { id: 0, url: agentBridgeProjectRootUrl("", projectId), title: "", windowId: null },
    chromeSessionAuth: true
  };
}

async function submitAgentPromptViaDirectApi(payload = {}, request = {}, target = {}) {
  const prompt = compactString(target.prompt || payload.prompt);
  const projectId = compactString(target.projectId);
  const tab = target.tab || {};
  const chatOnly = payload.chatOnly === true;
  let creditEstimate = null;
  let pendingToolContract = { required: false, kind: "chat" };
  let capabilityValidation = { ok: true, skipped: true, reason: "chat_only" };
  let apiRefPlan = { ok: true, attachments: [], mediaIds: [], targetRefs: [] };

  if (!chatOnly) {
    if (payload.captainAuthorized !== true || payload.authorizedBatch !== true) {
      throw agentBridgeError("AGENT_CREDIT_APPROVAL_REQUIRED", "Direct Agent API generation requires an explicitly captain-authorized batch.");
    }
    const manifestMediaType = compactString(payload.manifest?.mediaType).toLowerCase();
    const manifestExpectedTotal = Number(payload.manifest?.expectedTotal || 0) || 0;
    const expectedImages = Number(payload.expectedImages ?? payload.matrix?.expectedImages ?? payload.manifest?.expectedImages
      ?? (manifestMediaType === "image" ? manifestExpectedTotal : 0)) || 0;
    const expectedVideos = Number(payload.expectedVideos ?? payload.matrix?.expectedVideos ?? payload.manifest?.expectedVideos
      ?? (manifestMediaType === "video" ? manifestExpectedTotal : 0)) || 0;
    if (expectedImages < 1 || expectedVideos > 0) {
      throw agentBridgeError("AGENT_API_GENERATION_NOT_READY", "Direct Agent API generation is currently proven only for image-only batches.", {
        expectedImages,
        expectedVideos
      });
    }
    apiRefPlan = planFlowAgentApiReferences(payload);
    if (!apiRefPlan.ok) {
      throw agentBridgeError(apiRefPlan.code || "AGENT_REF_PLAN_INVALID", apiRefPlan.message || "Agent API reference plan is invalid.", apiRefPlan.details);
    }
    const runProfile = payload.runProfile || payload.settings || payload.matrix?.settings || {};
    const capabilityMode = compactString(payload.mode).toLowerCase() === "agent"
      ? (payload.matrix?.mode || runProfile.mode)
      : (payload.mode || payload.matrix?.mode || runProfile.mode);
    capabilityValidation = validateAgentCapabilityContract({
      mode: capabilityMode,
      runProfile,
      matrix: payload.matrix,
      refPlan: apiRefPlan,
      references: apiRefPlan.attachments
    });
    if (!capabilityValidation.ok) {
      throw agentBridgeError(capabilityValidation.code || "AGENT_CAPABILITY_CONTRACT_INVALID", capabilityValidation.message || "Agent API run is not physically supported.", capabilityValidation);
    }
    const metadata = await fetchAgentProjectInitialData({ projectId, tabId: tab.id, pageUrl: tab.url || "" });
    if (!metadata.ok) {
      throw agentBridgeError("METADATA_UNAVAILABLE", metadata.error || "Flow project metadata is unavailable for credit preflight.", { status: metadata.status || 0 });
    }
    creditEstimate = resolveFlowCreationAgentCreditEstimate({
      projectInitialData: metadata.projectInitialData,
      kind: "image",
      modelDisplayName: runProfile.imageModel || runProfile.model,
      outputCount: expectedImages
    });
    if (!creditEstimate.known) {
      throw agentBridgeError(creditEstimate.code || "AGENT_API_CREDIT_COST_UNKNOWN", "Direct Agent API generation requires a deterministic current-tier credit mapping before submit.", creditEstimate);
    }
    const creditCap = Number(payload.maxCreditsPerRun ?? payload.creditPolicy?.maxCreditsPerRun);
    if (!Number.isFinite(creditCap) || creditCap < 0 || creditEstimate.totalCost > creditCap) {
      throw agentBridgeError("AGENT_CREDIT_CAP_EXCEEDED", "Direct Agent API generation cost is outside the authorized run cap.", { creditCap, creditEstimate });
    }
    pendingToolContract = buildAgentPendingToolContract({ ...payload, expectedImages, expectedVideos, refPlan: apiRefPlan });
  }

  if (payload.dryRun === true) {
    return {
      ok: true,
      submitted: false,
      dryRun: true,
      chatOnly,
      transport: "agent_api",
      projectId,
      page: { tabId: tab.id, url: tab.url || "", title: tab.title || "" },
      promptLength: prompt.length,
      promptPreview: prompt.slice(0, 240),
      creditEstimate,
      capabilityValidation,
      referencePlan: {
        count: apiRefPlan.attachments.length,
        handles: apiRefPlan.attachments.map((attachment) => attachment.handle)
      },
      chromeSessionAuth: true
    };
  }
  const stableApiTargetId = tab.id || "chrome-session";
  const lockKey = agentSubmitLockKey(projectId, stableApiTargetId);
  const idempotencyKey = agentSubmitIdempotencyKey(payload, prompt, stableApiTargetId, projectId, request);
  const priorSubmit = agentSubmitIdempotency.get(idempotencyKey);
  if (priorSubmit?.status === "completed" && priorSubmit.result) return { ...priorSubmit.result, idempotentReplay: true, idempotencyKey };
  if (priorSubmit?.status === "pending") {
    throw agentBridgeError("AGENT_TARGET_BUSY", "An identical direct Agent API submit is already in progress or has an ambiguous result.", { idempotencyKey, transport: "agent_api" });
  }
  if (!agentSubmitLock.acquire(lockKey)) {
    throw agentBridgeError("AGENT_TARGET_BUSY", "Another Agent submit is already in progress for this Flow target.", { lockKey });
  }
  let streamWriteArmed = false;
  try {
    pruneAgentSubmitIdempotency();
    let recaptchaTab = { tabId: null, temporary: false };
    let referenceResolution = { plan: apiRefPlan, mediaIds: [], uploads: [] };
    const apiResult = await withAgentApiRecaptchaTab(projectId, tab.id, async (authTab, authTabState) => {
      recaptchaTab = { tabId: authTab.id, temporary: authTabState.temporary === true };
      if (!chatOnly) {
        referenceResolution = await resolveAgentApiReferenceUploads(payload, projectId, createFlowClientForTab(authTab.id));
      }
      // Retain this tombstone on transport failure: once sendMessage begins,
      // its stream write may be accepted, so an automatic retry must never
      // replay the paid turn. Reference upload failures happen before this.
      agentSubmitIdempotency.set(idempotencyKey, { status: "pending", startedAt: Date.now() });
      streamWriteArmed = true;
      return createFlowCreationAgentClientForTab(authTab.id).sendMessage({
        projectId,
        prompt,
        mediaIds: referenceResolution.mediaIds,
        agentSessionId: payload.agentSessionId,
        startNewSession: payload.startNewAgentSession === true,
        collectionId: payload.collectionId
      });
    });
    const contractValidation = chatOnly
      ? { ok: true, skipped: true, reason: "chat_only" }
      : validateAgentPendingToolContract(pendingToolContract, apiResult.stream.telemetry);
    const unexpectedChatTool = chatOnly && (
      apiResult.stream.permissionRequired
      || apiResult.stream.directActionRequests.length > 0
      || apiResult.stream.toolNames.length > 0
      || apiResult.stream.creditAmounts.length > 0
    );
    const mediaIds = apiResult.stream.telemetry.mediaIds || [];
    const waitingForCreditApproval = !chatOnly && apiResult.stream.permissionRequired;
    const blockCode = unexpectedChatTool
      ? "AGENT_API_CHAT_UNEXPECTED_TOOL_SIGNAL"
      : (!contractValidation.ok ? contractValidation.code : "");
    const actualKnownSpend = !chatOnly && mediaIds.length > 0 ? Number(creditEstimate?.totalCost || 0) : 0;
    const result = {
      ok: true,
      submitted: true,
      dryRun: false,
      chatOnly,
      transport: "agent_api",
      projectId,
      page: { tabId: tab.id || null, url: tab.url || "", title: tab.title || "" },
      chromeSessionAuth: true,
      recaptchaTab,
      referenceUploads: referenceResolution.uploads,
      inputMediaIds: referenceResolution.mediaIds,
      promptLength: prompt.length,
      promptPreview: prompt.slice(0, 240),
      agentSessionId: apiResult.agentSessionId,
      clientSessionId: apiResult.clientSessionId,
      turnNumber: apiResult.turnNumber,
      finalResponseObserved: apiResult.stream.finalObserved,
      reply: apiResult.stream.finalText,
      waitingForCreditApproval,
      blocked: Boolean(blockCode),
      blockCode,
      toolTelemetry: apiResult.stream.telemetry,
      toolContractValidation: contractValidation,
      creditEstimate,
      actualKnownSpend,
      creditAmounts: apiResult.stream.creditAmounts,
      mediaIds,
      workflowIds: apiResult.stream.telemetry.workflowIds || [],
      batchIds: apiResult.stream.telemetry.batchIds || [],
      placeholderFrontendIds: apiResult.stream.telemetry.placeholderFrontendIds || [],
      capabilityValidation
    };
    agentSubmitIdempotency.set(idempotencyKey, { status: "completed", completedAt: Date.now(), result });
    recordEvent({
      type: "agent_bridge.prompt.submitted_api",
      tabId: tab.id,
      projectId,
      chatOnly,
      turnNumber: apiResult.turnNumber,
      finalResponseObserved: apiResult.stream.finalObserved,
      blocked: Boolean(blockCode),
      waitingForCreditApproval,
      actualKnownSpend,
      mediaCount: mediaIds.length
    });
    return result;
  } catch (error) {
    if (!streamWriteArmed) agentSubmitIdempotency.delete(idempotencyKey);
    throw error;
  } finally {
    agentSubmitLock.release(lockKey);
  }
}


async function getFleetGenStateFromBridge(payload = {}, request = {}) {
  const tab = await fleetGenBridgeTab(payload);
  const target = await ensureFleetGenFrameBridge(tab.id, { timeoutMs: payload.timeoutMs, allowProvision: false });
  const promptFilters = fleetGenPromptLines(payload);
  const stateResponse = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "getState", {
    promptFilters
  }, {
    timeoutMs: payload.timeoutMs || 10000,
    includeMediaBytes: true
  });
  return fleetGenBridgeResponsePayload({
    payload,
    request,
    tab,
    target,
    methodResponse: stateResponse,
    launched: false
  });
}

async function generateFleetGenFromBridge(payload = {}, request = {}) {
  const requestReceivedAtMs = Date.now();
  const promptsText = fleetGenPromptsText(payload);
  if (!promptsText) {
    throw agentBridgeError("FLEETGEN_PROMPTS_EMPTY", "Fleet Gen prompts are empty.");
  }
  const durationError = validateFleetGenDurationSecondsPayload(payload);
  if (durationError) {
    throw agentBridgeError("FLEETGEN_DURATION_SECONDS_INVALID", "Fleet Gen durationSeconds must be one of 4, 6, or 8 seconds.", durationError);
  }
  const invalidMediaType = fleetGenInvalidMediaType(payload);
  if (invalidMediaType) {
    throw agentBridgeError("FLEETGEN_MEDIA_TYPE_INVALID", "Fleet Gen type must normalize to image or video.", { type: invalidMediaType });
  }
  const sourceRoleError = fleetGenSourceRoleError(payload);
  if (sourceRoleError) {
    throw agentBridgeError(sourceRoleError.code, sourceRoleError.message);
  }
  const promptLineCount = fleetGenPromptLines(payload).length;
  if ((payload.direct === true || payload.executeDirect === true) && promptLineCount > 1) {
    throw agentBridgeError(
      "FLEETGEN_DIRECT_MULTI_PROMPT_UNSUPPORTED",
      "Fleet Gen direct execute supports exactly one prompt; use the batch launch path for multiple prompts.",
      { promptCount: promptLineCount }
    );
  }
  if (payload.dryRun === true) {
    const dryRunPromptRecords = fleetGenPromptRecords(payload);
    return {
      ok: true,
      dryRun: true,
      launched: false,
      source: "fleetgen_bridge",
      direct: payload.direct === true || payload.executeDirect === true,
      prompts: dryRunPromptRecords.map((record) => record.prompt),
      promptRecords: dryRunPromptRecords,
      settings: fleetGenSettingsFromPayload(payload),
      expectedTotal: dryRunPromptRecords.length,
      mediaIds: [],
      urls: [],
      requestKind: compactString(request.type || "fleet.generate")
    };
  }
  const tab = await fleetGenBridgeTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const lockKey = agentSubmitLockKey(projectId, tab.id);
  const idempotencyKey = fleetGenSubmitIdempotencyKey(payload, promptsText, tab.id, projectId);
  const priorSubmit = idempotencyKey ? agentSubmitIdempotency.get(idempotencyKey) : null;
  if (priorSubmit?.status === "completed" && priorSubmit.result) {
    return {
      ...priorSubmit.result,
      idempotentReplay: true,
      idempotencyKey
    };
  }
  if (priorSubmit?.status === "pending") {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "An identical Fleet Gen launch is already in progress for this Flow target.",
      { idempotencyKey }
    );
  }
  if (!agentSubmitLock.acquire(lockKey)) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Another paid Agent or Fleet Gen submit is already in progress for this Flow target.",
      { lockKey }
    );
  }

  let launchDispatched = false;
  try {
    await assertAgentBridgeWriteEntitled(payload);
    assertFleetGenCreditApproval(payload);
    const fleetReferenceResolution = await resolveFleetGenReferenceUploads(payload, projectId, tab);
    if (fleetReferenceResolution.mediaIds.length) {
      payload = applyFleetGenReferenceUploads(payload, fleetReferenceResolution);
    }
    const target = await ensureFleetGenFrameBridge(tab.id, { timeoutMs: payload.timeoutMs });
    const timeoutMs = Math.max(1000, Number(payload.timeoutMs || 600000));
    const commandTimeoutMs = Math.max(1000, Math.min(timeoutMs, Number(payload.commandTimeoutMs || 30000)));
    const pollMs = Math.max(250, Number(payload.pollMs || payload.pollIntervalMs || 2000));
    const { harvestTimeoutMs, pollDeadlineMs, activeTimeoutMs } = fleetGenHarvestBudget({
      timeoutMs,
      commandTimeoutMs,
      pollMs,
      setupElapsedMs: Date.now() - requestReceivedAtMs
    });
    const startedAtMs = Date.now();
    const settings = fleetGenSettingsFromPayload(payload);
    const activePromptRecords = fleetGenPromptRecords(payload);
    const sequence = [];
    pruneAgentSubmitIdempotency();
    agentSubmitIdempotency.set(idempotencyKey, {
      status: "pending",
      startedAt: Date.now()
    });
    const ping = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "ping", {}, { timeoutMs: 5000 });
    sequence.push({ method: "ping", ok: ping.ok === true, summary: fleetGenMethodSummary(ping) });
    let capabilities = null;
    if (Array.isArray(target.fleetGenKeys) && target.fleetGenKeys.includes("getCapabilities")) {
      const capabilityResponse = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "getCapabilities", {}, { timeoutMs: 5000 });
      capabilities = capabilityResponse.result && typeof capabilityResponse.result === "object" ? capabilityResponse.result : null;
      sequence.push({ method: "getCapabilities", ok: capabilityResponse.ok === true, summary: fleetGenMethodSummary(capabilityResponse) });
      assertFleetGenCapabilities(settings, capabilities);
    }
    if (payload.direct === true || payload.executeDirect === true) {
      const directSetPrompts = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "setPrompts", { text: promptsText }, { timeoutMs: commandTimeoutMs });
      sequence.push({ method: "setPrompts", ok: directSetPrompts.ok === true, summary: fleetGenMethodSummary(directSetPrompts) });
      const directUpdateSettings = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "updateSettings", { config: settings }, { timeoutMs: commandTimeoutMs });
      sequence.push({ method: "updateSettings", ok: directUpdateSettings.ok === true, summary: fleetGenMethodSummary(directUpdateSettings) });
      // executeDirect receives the complete settings object atomically. The
      // preceding updates only keep the visible Tool UI synchronized.
      launchDispatched = true;
      const direct = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "executeDirect", {
        prompt: fleetGenPromptLines(payload)[0] || promptsText,
        config: settings
      }, {
        timeoutMs: activeTimeoutMs,
        includeMediaBytes: true
      });
      sequence.push({ method: "executeDirect", ok: direct.ok === true, summary: fleetGenMethodSummary(direct) });
      const directPrompt = fleetGenPromptLines(payload)[0] || promptsText;
      const directRecords = collectFleetGenRecords(direct.result)
        .map((record) => ({ ...record, prompt: record.prompt || directPrompt }));
      let directMethodResponse = direct;
      try {
        const postDirectState = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "getState", {
          promptFilters: fleetGenPromptLines(payload),
          runStartedAtMs: startedAtMs
        }, {
          timeoutMs: harvestTimeoutMs,
          includeMediaBytes: false
        });
        sequence.push({ method: "getState", ok: postDirectState.ok === true, summary: fleetGenMethodSummary(postDirectState) });
        directMethodResponse = {
          ...postDirectState,
          result: {
            directResult: directRecords.length ? { records: directRecords } : direct.result,
            state: postDirectState.result
          }
        };
      } catch (error) {
        sequence.push({
          method: "getState",
          ok: false,
          error: compactString(error?.message || error || "fleetgen_getstate_failed")
        });
        if (directRecords.length) {
          directMethodResponse = {
            ...direct,
            result: { records: directRecords }
          };
        }
      }
      const finalPayload = fleetGenBridgeResponsePayload({
        payload,
        request,
        tab,
        target,
        methodResponse: directMethodResponse,
        launched: true,
        settings,
        sequence,
        pollTrace: [],
        timedOut: false,
        startedAt: new Date(startedAtMs).toISOString(),
        expectedTotal: 1,
        capabilities
      });
      cacheFleetGenFinalPayload(idempotencyKey, finalPayload);
      recordEvent({
        type: "fleetgen.generate.completed",
        tabId: tab.id,
        frameId: target.frameId,
        projectId: finalPayload.projectId,
        batchId: finalPayload.batchId,
        agentId: finalPayload.agentId,
        direct: true,
        mediaIdCount: finalPayload.mediaIds.length
      });
      return finalPayload;
    }
    const setPrompts = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "setPrompts", { text: promptsText }, { timeoutMs: commandTimeoutMs });
    sequence.push({ method: "setPrompts", ok: setPrompts.ok === true, summary: fleetGenMethodSummary(setPrompts) });
    const updateSettings = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "updateSettings", { config: settings }, { timeoutMs: commandTimeoutMs });
    sequence.push({ method: "updateSettings", ok: updateSettings.ok === true, summary: fleetGenMethodSummary(updateSettings) });
    const launchConfig = {
      ...settings,
      settings,
      prompts: activePromptRecords.map((record) => record.prompt)
    };
    launchDispatched = true;
    let launch = null;
    try {
      launch = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "launch", { config: launchConfig }, { timeoutMs: commandTimeoutMs });
      sequence.push({ method: "launch", ok: launch.ok === true, summary: fleetGenMethodSummary(launch) });
    } catch (error) {
      if (!isFleetGenCommandTimeoutError(error)) throw error;
      sequence.push({
        method: "launch",
        ok: false,
        timedOut: true,
        error: compactString(error?.message || error || "fleetgen_launch_timeout")
      });
      recordEvent({
        type: "fleetgen.launch.timeout_continue_polling",
        tabId: tab.id,
        frameId: target.frameId,
        projectId,
        timeoutMs: commandTimeoutMs
      });
    }

    const expectedTotal = fleetGenExpectedTotal(payload);
    let stateResponse = launch || { ok: false, result: null };
    let stateSummary = summarizeFleetGenState(launch?.result, { expectedTotal, promptRecords: activePromptRecords, runStartedAtMs: startedAtMs });
    const pollTrace = [];
    if (payload.waitUntilDone !== false) {
      while (!stateSummary.terminal && Date.now() - startedAtMs < pollDeadlineMs) {
        const remainingMs = pollDeadlineMs - (Date.now() - startedAtMs);
        if (remainingMs <= 0) break;
        await sleep(Math.min(pollMs, remainingMs));
        let polled;
        try {
          polled = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "getState", {
            promptFilters: fleetGenPromptLines(payload),
            runStartedAtMs: startedAtMs
          }, { timeoutMs: Math.min(commandTimeoutMs, 15000), includeMediaBytes: false });
        } catch (error) {
          pollTrace.push({
            at: new Date().toISOString(),
            status: stateSummary.status,
            terminal: stateSummary.terminal,
            failed: stateSummary.failed,
            running: stateSummary.running,
            total: stateSummary.total,
            done: stateSummary.done,
            failedCount: stateSummary.failedCount,
            mediaIdCount: stateSummary.mediaIds.length,
            error: compactString(error?.message || error || "fleetgen_getstate_failed")
          });
          if (pollTrace.length > 120) pollTrace.shift();
          continue;
        }
        stateResponse = polled;
        stateSummary = summarizeFleetGenState(stateResponse.result, { expectedTotal, promptRecords: activePromptRecords, runStartedAtMs: startedAtMs });
        pollTrace.push({
          at: new Date().toISOString(),
          status: stateSummary.status,
          terminal: stateSummary.terminal,
          failed: stateSummary.failed,
          running: stateSummary.running,
          total: stateSummary.total,
          done: stateSummary.done,
          failedCount: stateSummary.failedCount,
          mediaIdCount: stateSummary.mediaIds.length
        });
        if (pollTrace.length > 120) pollTrace.shift();
      }
      try {
        const harvested = await invokeFleetGenBridgeMethod(tab.id, target.frameId, "getState", {
          promptFilters: fleetGenPromptLines(payload),
          runStartedAtMs: startedAtMs
        }, { timeoutMs: harvestTimeoutMs, includeMediaBytes: true });
        stateResponse = harvested;
        stateSummary = summarizeFleetGenState(stateResponse.result, { expectedTotal, promptRecords: activePromptRecords, runStartedAtMs: startedAtMs });
      } catch (error) {
        pollTrace.push({
          at: new Date().toISOString(),
          status: stateSummary.status,
          terminal: stateSummary.terminal,
          failed: stateSummary.failed,
          running: stateSummary.running,
          total: stateSummary.total,
          done: stateSummary.done,
          failedCount: stateSummary.failedCount,
          mediaIdCount: stateSummary.mediaIds.length,
          error: compactString(error?.message || error || "fleetgen_media_harvest_failed")
        });
        if (pollTrace.length > 120) pollTrace.shift();
      }
    }

    const finalPayload = fleetGenBridgeResponsePayload({
      payload,
      request,
      tab,
      target,
      methodResponse: stateResponse,
      launched: true,
      settings,
      sequence,
      pollTrace,
      timedOut: payload.waitUntilDone !== false && !stateSummary.terminal,
      startedAt: new Date(startedAtMs).toISOString(),
      expectedTotal,
      capabilities
    });
    cacheFleetGenFinalPayload(idempotencyKey, finalPayload);
    recordEvent({
      type: "fleetgen.generate.completed",
      tabId: tab.id,
      frameId: target.frameId,
      projectId: finalPayload.projectId,
      batchId: finalPayload.batchId,
      agentId: finalPayload.agentId,
      terminal: finalPayload.stateSummary.terminal,
      failed: finalPayload.stateSummary.failed,
      timedOut: finalPayload.timedOut === true,
      mediaIdCount: finalPayload.mediaIds.length
    });
    return finalPayload;
  } catch (error) {
    if (idempotencyKey) {
      if (launchDispatched) {
        agentSubmitIdempotency.set(idempotencyKey, {
          status: "pending",
          startedAt: Date.now(),
          ambiguous: true,
          error: compactString(error?.message || error || "fleetgen_generate_failed_after_launch_dispatch")
        });
      } else {
        agentSubmitIdempotency.delete(idempotencyKey);
      }
    }
    throw error;
  } finally {
    agentSubmitLock.release(lockKey);
  }
}

async function resolveFleetGenReferenceUploads(payload = {}, projectId = "", tab = {}) {
  const plan = planFlowAgentApiReferences(payload);
  if (!plan.ok) {
    throw agentBridgeError(plan.code || "FLEETGEN_REF_PLAN_INVALID", plan.message || "Fleet Gen reference plan is invalid.", plan.details);
  }
  if (!plan.attachments.length) return { plan, mediaIds: [], uploads: [] };
  if (!tab?.id) {
    throw agentBridgeError("FLEETGEN_REF_UPLOAD_TARGET_MISSING", "Fleet Gen reference upload requires the exact Flow tab target.");
  }
  return resolveAgentApiReferenceUploads(payload, projectId, createFlowClientForTab(tab.id));
}

function applyFleetGenReferenceUploads(payload = {}, resolution = {}) {
  const attachments = Array.isArray(resolution.plan?.attachments) ? resolution.plan.attachments : [];
  const uploadsBySource = new Map((resolution.uploads || []).map((upload) => [compactString(upload.sourceIdentity), upload]));
  const ordered = attachments.map((attachment) => ({
    ...attachment,
    mediaId: compactString(uploadsBySource.get(compactString(attachment.sourceIdentity))?.mediaId || attachment.mediaId)
  })).filter((attachment) => attachment.mediaId);
  const settings = payload.settings && typeof payload.settings === "object" ? { ...payload.settings } : {};
  const firstFrame = ordered.find((attachment) => /^(?:first|start|firstframe)$/i.test(compactString(attachment.role)));
  const lastFrame = ordered.find((attachment) => /^(?:last|end|lastframe)$/i.test(compactString(attachment.role)));
  const mediaType = fleetGenMediaTypeFromValue(payload.type || payload.mediaType || settings.type || settings.mediaType) || "image";
  const allMediaIds = uniqueFleetGenStrings([
    ...(Array.isArray(payload.referenceImageMediaIds) ? payload.referenceImageMediaIds : []),
    ...ordered.map((attachment) => attachment.mediaId)
  ]);

  if (mediaType === "video" && (firstFrame || ordered[0])) {
    settings.firstFrameImageMediaId = compactString((firstFrame || ordered[0]).mediaId);
  }
  if (mediaType === "video" && lastFrame) {
    settings.lastFrameImageMediaId = compactString(lastFrame.mediaId);
  }
  settings.referenceImageMediaIds = allMediaIds;
  return {
    ...payload,
    settings,
    referenceImageMediaIds: allMediaIds,
    uploadedReferenceMediaIds: allMediaIds
  };
}

function cacheFleetGenFinalPayload(idempotencyKey, finalPayload = {}) {
  if (!idempotencyKey) return;
  if (finalPayload.ok === false || finalPayload.timedOut === true || finalPayload.stateSummary?.terminal !== true) {
    agentSubmitIdempotency.set(idempotencyKey, {
      status: "pending",
      startedAt: Date.now(),
      ambiguous: true,
      error: compactString(finalPayload.stateSummary?.status || finalPayload.message || "fleetgen_non_terminal_result")
    });
    return;
  }
  agentSubmitIdempotency.set(idempotencyKey, {
    status: "completed",
    completedAt: Date.now(),
    result: fleetGenReplayCacheResult(finalPayload)
  });
}

async function fleetGenBridgeTab(payload = {}) {
  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  return tab;
}

function isFleetGenCommandTimeoutError(error) {
  const code = compactString(error?.code || error?.response?.error?.code || error?.details?.response?.error || "");
  const message = compactString(error?.message || error?.response?.error?.message || error?.details?.response?.error || error || "");
  return /FLEETGEN_COMMAND_TIMEOUT|fleetgen_command_timeout|timeout/i.test(`${code} ${message}`);
}

async function ensureFleetGenFrameBridge(tabId, options = {}) {
  const discovery = await discoverFleetGenFrames(tabId);
  const target = selectFleetGenReadyFrame(discovery);
  if (!fleetGenReadyFrameFound(target)) {
    if (options.allowProvision !== false) {
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      const provisioned = await provisionFleetGenSharedTool(tab, discovery, options);
      const ready = await waitForFleetGenReadyFrame(tabId, {
        timeoutMs: Math.max(1000, Number(options.provisionReadyTimeoutMs || 20000)),
        intervalMs: Math.max(100, Number(options.provisionReadyIntervalMs || 500))
      });
      if (!fleetGenReadyFrameFound(ready.target)) {
        throw agentBridgeError("FLEETGEN_FRAME_NOT_FOUND", "Fleet Gen provisioned tool did not expose the required generation API before timeout.", {
          ...ready.discovery,
          provisioned
        });
      }
      return ensureFleetGenFrameBridge(tabId, {
        ...options,
        allowProvision: false,
        provisioned
      });
    }
    throw agentBridgeError("FLEETGEN_FRAME_NOT_FOUND", "Fleet Gen with the required generation API was not found in any Flow Tool iframe.", discovery);
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [target.frameId] },
      files: [FLOW_BRIDGE_SCRIPT_PATH]
    });
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [target.frameId] },
      files: [FLEETGEN_PAGE_BRIDGE_SCRIPT_PATH],
      world: "MAIN"
    });
  } catch (error) {
    throw agentBridgeError("FLEETGEN_FRAME_INJECTION_FAILED", compactString(error?.message || error || "fleetgen_frame_injection_failed"), {
      tabId,
      target,
      discovery
    });
  }
  const ping = await invokeFleetGenBridgeMethod(tabId, target.frameId, "ping", {}, {
    timeoutMs: Math.min(Number(options.timeoutMs || 5000) || 5000, 10000)
  });
  return {
    ...target,
    provisioned: options.provisioned || null,
    ping: fleetGenMethodSummary(ping)
  };
}

function fleetGenFrameHasRequiredMethods(frame = {}) {
  const keys = new Set(Array.isArray(frame.fleetGenKeys) ? frame.fleetGenKeys : []);
  return frame.hasFleetGen === true && FLEETGEN_REQUIRED_METHODS.every((method) => keys.has(method));
}

function selectFleetGenReadyFrame(discovery = {}) {
  return (Array.isArray(discovery.frames) ? discovery.frames : []).find(fleetGenFrameHasRequiredMethods) || null;
}

function fleetGenReadyFrameFound(target) {
  return Boolean(target) && (Boolean(target.frameId) || target.frameId === 0);
}

async function waitForFleetGenReadyFrame(tabId, { timeoutMs = 20000, intervalMs = 500 } = {}) {
  const deadline = Date.now() + Math.max(0, Number(timeoutMs || 0));
  let discovery = await discoverFleetGenFrames(tabId);
  let target = selectFleetGenReadyFrame(discovery);
  while (!fleetGenReadyFrameFound(target) && Date.now() < deadline) {
    await sleep(Math.max(100, Number(intervalMs || 500)));
    discovery = await discoverFleetGenFrames(tabId);
    target = selectFleetGenReadyFrame(discovery);
  }
  return { discovery, target };
}

function fleetGenProvisionedToolUrl(url = "", projectId = "") {
  const id = compactString(projectId || projectIdFromUrl(url));
  if (!id) return "";
  try {
    const parsed = new URL(url || FLEETGEN_SHARED_TOOL_URL);
    const localeMatch = parsed.pathname.match(/^\/fx\/([^/?#]+)\/tools\/flow/i);
    parsed.pathname = localeMatch
      ? `/fx/${localeMatch[1]}/tools/flow/project/${id}/tool-version/${FLEETGEN_SHARED_TOOL_ID}`
      : `/fx/tools/flow/project/${id}/tool-version/${FLEETGEN_SHARED_TOOL_ID}`;
    parsed.search = "";
    parsed.hash = "";
    return parsed.toString();
  } catch {
    return `https://labs.google/fx/tools/flow/project/${id}/tool-version/${FLEETGEN_SHARED_TOOL_ID}`;
  }
}

function fleetGenProjectPickerLabel(tab = {}) {
  return compactString(tab.title || "")
    .replace(/^\[AF:[^\]]+\]\s*/i, "")
    .replace(/^Google Flow\s*-\s*/i, "")
    .trim();
}

function isAuthOrOAuthUrl(url = "") {
  return /\/\/accounts\.google\.com\//i.test(String(url || "")) || /\/signin\/oauth/i.test(String(url || ""));
}

async function provisionFleetGenSharedTool(tab = {}, discovery = {}, options = {}) {
  const tabId = Number(tab?.id || 0);
  const projectId = compactString(projectIdFromUrl(tab?.url || ""));
  const projectLabel = compactString(options.projectLabel || fleetGenProjectPickerLabel(tab));
  if (!tabId || !projectId) {
    throw agentBridgeError("FLEETGEN_PROVISION_TARGET_MISSING", "Fleet Gen provisioning requires an exact Flow project tab target.", {
      tabId,
      projectId,
      url: tab?.url || "",
      discovery
    });
  }
  if (!projectLabel) {
    throw agentBridgeError("FLEETGEN_PROVISION_PROJECT_LABEL_MISSING", "Fleet Gen provisioning could not derive the target project label for the Flow picker.", {
      tabId,
      projectId,
      title: tab?.title || "",
      url: tab?.url || ""
    });
  }

  const expectedUrl = fleetGenProvisionedToolUrl(tab.url || "", projectId);
  recordEvent({
    type: "fleetgen.provision.start",
    tabId,
    projectId,
    projectLabel,
    sharedToolId: FLEETGEN_SHARED_TOOL_ID,
    expectedUrl
  });

  const originalUrl = compactString(tab.url || "");
  await chrome.tabs.update(tabId, { url: FLEETGEN_SHARED_TOOL_URL }).catch((error) => {
    throw agentBridgeError("FLEETGEN_PROVISION_NAVIGATION_FAILED", compactString(error?.message || error || "fleetgen_provision_navigation_failed"), {
      tabId,
      projectId,
      sharedToolUrl: FLEETGEN_SHARED_TOOL_URL
    });
  });
  try {
    const sharedToolPage = await waitForFleetGenSharedToolPage(tabId, { projectId, timeoutMs: options.provisionTimeoutMs || 30000 });
    let picker = null;
    if (sharedToolPage?.alreadyProvisioned !== true) {
      await clickFleetGenSharedToolTry(tabId, { projectId, timeoutMs: options.commandTimeoutMs || 10000 });
      picker = await chooseFleetGenSharedToolProject(tabId, projectLabel, { projectId, timeoutMs: options.commandTimeoutMs || 10000 });
    }
    const provisioned = await waitForProvisionedFleetGenTool(tabId, projectId, { timeoutMs: options.provisionTimeoutMs || 45000 });
    recordEvent({
      type: "fleetgen.provision.ready",
      tabId,
      projectId,
      projectLabel,
      selected: picker?.selected || "",
      url: provisioned.url || "",
      sharedToolId: FLEETGEN_SHARED_TOOL_ID
    });
    return {
      ok: true,
      tabId,
      projectId,
      projectLabel,
      expectedUrl,
      url: provisioned.url || "",
      selected: picker?.selected || "",
      sharedToolId: FLEETGEN_SHARED_TOOL_ID
    };
  } catch (error) {
    if (originalUrl) {
      await chrome.tabs.update(tabId, { url: originalUrl }).catch(() => {});
      recordEvent({
        type: "fleetgen.provision.restored_original_url",
        tabId,
        projectId,
        url: originalUrl
      });
    }
    throw error;
  }
}

async function waitForFleetGenSharedToolPage(tabId, { projectId = "", timeoutMs = 30000 } = {}) {
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 30000));
  let last = null;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const url = compactString(tab?.url || "");
    if (isAuthOrOAuthUrl(url)) {
      throw agentBridgeError("FLEETGEN_PROVISION_AUTH_REQUIRED", "Flow redirected to Google auth while opening the Fleet Gen shared tool.", {
        tabId,
        projectId,
        url
      });
    }
    last = await readFleetGenSharedToolPage(tabId).catch((error) => ({
      ok: false,
      error: compactString(error?.message || error || "fleetgen_shared_tool_probe_failed"),
      url
    }));
    if (last?.alreadyProvisioned === true) return last;
    if (last?.sharedTool === true && last?.tryButton === true) return last;
    await sleep(500);
  }
  throw agentBridgeError("FLEETGEN_PROVISION_SHARED_TOOL_TIMEOUT", "Fleet Gen shared tool page did not expose Try in a project before timeout.", {
    tabId,
    projectId,
    last
  });
}

function fleetGenSharedToolPageProbe(sharedToolId) {
  const compact = (value = "") => String(value || "").replace(/\s+/g, " ").trim();
  const visible = (element) => {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const textOf = (element) => compact(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "");
  const isDisabled = (element) => element?.disabled === true || element?.getAttribute?.("aria-disabled") === "true";
  const inPageChrome = (element) => Boolean(element?.closest?.("header, nav, footer, [role='banner'], [role='navigation'], [role='dialog']"));
  const sharedToolDialogTryButton = () => {
    const dialogs = [...document.querySelectorAll("[role='dialog']")].filter((element) => visible(element));
    for (const dialog of dialogs) {
      const dialogText = textOf(dialog);
      if (!dialogText.includes("AutoFlow Fleet Gen")) continue;
      const dialogRect = dialog.getBoundingClientRect();
      const buttons = [...dialog.querySelectorAll("button, [role='button']")]
        .filter((element) => visible(element) && !isDisabled(element) && textOf(element))
        .filter((element) => {
          const rect = element.getBoundingClientRect();
          return rect.width >= dialogRect.width * 0.6 && rect.top >= dialogRect.top + dialogRect.height * 0.6;
        });
      if (buttons.length === 1) return buttons[0];
      const exact = buttons.find((element) => textOf(element) === "Try in a project");
      if (exact) return exact;
    }
    return null;
  };
  const text = compact(document.body?.innerText || "");
  const href = location.href;
  const primaryActionCandidates = [...document.querySelectorAll("button, [role='button']")]
    .filter((element) => visible(element) && !isDisabled(element) && textOf(element) && !inPageChrome(element));
  const dialogTryButton = sharedToolDialogTryButton();
  const onSharedToolUrl = href.includes("/shared/tool/") && href.includes(sharedToolId);
  const authSurface = /accounts\.google\.com|\/signin\b|\/oauth\b/i.test(href)
    || Boolean(document.querySelector?.("#identifierId, input[type='email'][autocomplete~='username'], form[action*='accounts.google'], [data-identifier], ul[aria-label] [data-email]"))
    || /sign in|oauth|choose an account/i.test(text);
  const authText = authSurface;
  return {
    ok: true,
    href,
    title: document.title || "",
    sharedTool: onSharedToolUrl || text.includes("AutoFlow Fleet Gen"),
    tryButton: primaryActionCandidates.some((element) => textOf(element) === "Try in a project")
      || Boolean(dialogTryButton)
      || (primaryActionCandidates.length === 1 && onSharedToolUrl && !authText && text.includes("AutoFlow Fleet Gen")),
    primaryActionLabels: [...primaryActionCandidates, dialogTryButton].filter(Boolean).map(textOf).slice(0, 20),
    alreadyProvisioned: href.includes(`/tool-version/${sharedToolId}`),
    authText,
    textSample: text.slice(0, 500)
  };
}

async function readFleetGenSharedToolPage(tabId) {
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId, allFrames: false },
    args: [FLEETGEN_SHARED_TOOL_ID],
    func: fleetGenSharedToolPageProbe
  });
  return injection?.result || { ok: false, error: "fleetgen_shared_tool_probe_empty" };
}

function fleetGenTryClickProbe(sharedToolId, allowLoneClick) {
  const compact = (value = "") => String(value || "").replace(/\s+/g, " ").trim();
  const visible = (element) => {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const textOf = (element) => compact(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "");
  const isDisabled = (element) => element?.disabled === true || element?.getAttribute?.("aria-disabled") === "true";
  const projectRowCandidates = (dialog) => {
    const dialogRect = dialog.getBoundingClientRect();
    return [...dialog.querySelectorAll("div, button, [role='option'], [role='listitem']")]
      .filter((element) => visible(element) && textOf(element))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width >= 100 && rect.height >= 24 && rect.height <= 140
          && rect.top < dialogRect.top + dialogRect.height * 0.5;
      });
  };
  const hasListRegion = (dialog) => [...dialog.querySelectorAll("*")].some((element) => {
    if (!visible(element)) return false;
    const role = element.getAttribute?.("role") || "";
    if (["list", "listbox", "grid", "radiogroup"].includes(role)) return true;
    const style = getComputedStyle(element);
    return /(auto|scroll)/.test(style.overflowY) && element.scrollHeight > element.clientHeight;
  });
  const footerControls = (dialog, rows) => {
    const dialogRect = dialog.getBoundingClientRect();
    return [...dialog.querySelectorAll("button, [role='button']")]
      .filter(visible)
      .filter((element) => !rows.some((row) => row === element || row.contains(element) || element.contains(row)))
      .filter((element) => element.getBoundingClientRect().top >= dialogRect.top + dialogRect.height * 0.5);
  };
  const looksLikeProjectPickerDialog = (dialog) => {
    const rows = projectRowCandidates(dialog);
    return rows.length >= 1 && hasListRegion(dialog) && footerControls(dialog, rows).length >= 1;
  };
  const sharedToolDialogButton = (dialog) => {
    const dialogText = textOf(dialog);
    if (!dialogText.includes("AutoFlow Fleet Gen")) return null;
    const dialogRect = dialog.getBoundingClientRect();
    const buttons = [...dialog.querySelectorAll("button, [role='button']")]
      .filter((element) => visible(element) && !isDisabled(element) && textOf(element))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width >= dialogRect.width * 0.6 && rect.top >= dialogRect.top + dialogRect.height * 0.6;
      });
    return buttons.find((element) => textOf(element) === "Try in a project")
      || (buttons.length === 1 ? buttons[0] : null);
  };
  const dialogs = [...document.querySelectorAll("[role='dialog']")].filter((element) => visible(element));
  const pickerDialog = dialogs.find(looksLikeProjectPickerDialog);
  if (pickerDialog) return { ok: true, alreadyOpen: true };
  const sharedToolDialog = dialogs.find((dialog) => sharedToolDialogButton(dialog));
  if (sharedToolDialog) {
    const button = sharedToolDialogButton(sharedToolDialog);
    button.click();
    return { ok: true, clicked: true, loneClick: false, label: textOf(button), sharedToolDialog: true };
  }
  if (dialogs.length) {
    return {
      ok: false,
      error: "FLEETGEN_PROVISION_UNRECOGNIZED_MODAL",
      dialogCount: dialogs.length,
      dialogTextSamples: dialogs.map((element) => textOf(element).slice(0, 160))
    };
  }
  const inPageChrome = (element) => Boolean(element?.closest?.("header, nav, footer, [role='banner'], [role='navigation'], [role='dialog']"));
  const candidates = [...document.querySelectorAll("button, [role='button']")]
    .filter((element) => visible(element) && !isDisabled(element) && textOf(element) && !inPageChrome(element));
  if (!candidates.length) {
    return {
      ok: false,
      error: "FLEETGEN_PROVISION_TRY_BUTTON_NOT_FOUND",
      textSample: compact(document.body?.innerText || "").slice(0, 500)
    };
  }
  let button = candidates.find((element) => textOf(element) === "Try in a project") || null;
  let loneClick = false;
  if (!button && candidates.length === 1) {
    const href = location.href;
    const bodyText = compact(document.body?.innerText || "");
    const onSharedToolUrl = href.includes("/shared/tool/") && href.includes(sharedToolId);
    const authText = /accounts\.google\.com|\/signin\b|\/oauth\b/i.test(href)
      || Boolean(document.querySelector?.("#identifierId, input[type='email'][autocomplete~='username'], form[action*='accounts.google'], [data-identifier], ul[aria-label] [data-email]"))
      || /sign in|oauth|choose an account/i.test(bodyText);
    const sharedToolNameVisible = bodyText.includes("AutoFlow Fleet Gen");
    if (!onSharedToolUrl || authText || !sharedToolNameVisible) {
      return {
        ok: false,
        error: "FLEETGEN_PROVISION_TRY_BUTTON_NOT_FOUND",
        candidateLabels: candidates.map(textOf).slice(0, 20),
        authText,
        sharedToolNameVisible,
        href
      };
    }
    if (!allowLoneClick) {
      return {
        ok: false,
        error: "FLEETGEN_PROVISION_TRY_CLICK_UNCONFIRMED",
        candidateLabels: candidates.map(textOf).slice(0, 20)
      };
    }
    button = candidates[0];
    loneClick = true;
  }
  if (!button) {
    return {
      ok: false,
      error: "FLEETGEN_PROVISION_TRY_BUTTON_AMBIGUOUS",
      candidateLabels: candidates.map(textOf).slice(0, 20)
    };
  }
  button.click();
  return { ok: true, clicked: true, loneClick, label: textOf(button) };
}

async function clickFleetGenSharedToolTry(tabId, { projectId = "", timeoutMs = 10000 } = {}) {
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 10000));
  let last = null;
  let loneClickSpent = false;
  while (Date.now() < deadline) {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      args: [FLEETGEN_SHARED_TOOL_ID, !loneClickSpent],
      func: fleetGenTryClickProbe
    }).catch((error) => [{ result: { ok: false, error: compactString(error?.message || error || "fleetgen_try_click_failed") } }]);
    last = injection?.result || null;
    if (last?.ok && last?.loneClick === true) {
      loneClickSpent = true;
      await sleep(300);
      continue;
    }
    if (last?.ok) return last;
    await sleep(300);
  }
  throw agentBridgeError(last?.error || "FLEETGEN_PROVISION_UNRECOGNIZED_MODAL", "Fleet Gen shared tool page did not expose a recognizable Try in a project control.", {
    tabId,
    projectId,
    last
  });
}

async function fleetGenProjectChooseProbe(targetLabel) {
  const compact = (value = "") => String(value || "").replace(/\s+/g, " ").trim();
  const visible = (element) => {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  };
  const textOf = (element) => compact(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "");
  const projectRowCandidates = (dialog) => {
    const dialogRect = dialog.getBoundingClientRect();
    return [...dialog.querySelectorAll("div, button, [role='option'], [role='listitem']")]
      .filter((element) => visible(element) && textOf(element))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width >= 100 && rect.height >= 24 && rect.height <= 140
          && rect.top < dialogRect.top + dialogRect.height * 0.5;
      });
  };
  const hasListRegion = (dialog) => [...dialog.querySelectorAll("*")].some((element) => {
    if (!visible(element)) return false;
    const role = element.getAttribute?.("role") || "";
    if (["list", "listbox", "grid", "radiogroup"].includes(role)) return true;
    const style = getComputedStyle(element);
    return /(auto|scroll)/.test(style.overflowY) && element.scrollHeight > element.clientHeight;
  });
  const footerControls = (dialog, rows) => {
    const dialogRect = dialog.getBoundingClientRect();
    return [...dialog.querySelectorAll("button, [role='button']")]
      .filter(visible)
      .filter((element) => !rows.some((row) => row === element || row.contains(element) || element.contains(row)))
      .filter((element) => element.getBoundingClientRect().top >= dialogRect.top + dialogRect.height * 0.5);
  };
  const looksLikeProjectPickerDialog = (dialog) => {
    const rows = projectRowCandidates(dialog);
    return rows.length >= 1 && hasListRegion(dialog) && footerControls(dialog, rows).length >= 1;
  };
  const visibleDialogs = [...document.querySelectorAll("[role='dialog']")].filter((element) => visible(element));
  const dialogs = visibleDialogs.filter(looksLikeProjectPickerDialog);
  if (!dialogs.length) {
    return {
      ok: false,
      error: visibleDialogs.length ? "FLEETGEN_PROVISION_UNRECOGNIZED_MODAL" : "FLEETGEN_PROVISION_PROJECT_MODAL_NOT_FOUND",
      dialogCount: visibleDialogs.length,
      textSample: compact(document.body?.innerText || "").slice(0, 500)
    };
  }
  const selectableRows = (dialog) => {
    const footer = footerControls(dialog, projectRowCandidates(dialog));
    return [...dialog.querySelectorAll("div, button, [role='option'], [role='listitem']")]
      .filter((element) => visible(element) && textOf(element))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width >= 100 && rect.height >= 24 && rect.height <= 140;
      })
      .filter((element) => !footer.some((control) => control === element || control.contains(element) || element.contains(control)));
  };
  const rowNodes = dialogs.flatMap(selectableRows);
  const normalizedProjectLabel = (value = "") => compact(value).replace(/^(folder|image|movie|video_library|apps|article)\s+/i, "");
  const targetLabels = [compact(targetLabel)];
  const prefixStrippedLabel = compact(targetLabel).replace(/^[^-–—|]+[-–—|]\s*/, "").trim();
  if (prefixStrippedLabel && prefixStrippedLabel !== compact(targetLabel)) targetLabels.push(prefixStrippedLabel);
  let labelMatches = [];
  for (const candidateLabel of targetLabels) {
    labelMatches = rowNodes.filter((element) => normalizedProjectLabel(textOf(element)) === candidateLabel);
    if (labelMatches.length) break;
  }
  const rowCandidates = labelMatches.filter(
    (element) => !labelMatches.some((other) => other !== element && other.contains(element))
  );
  if (rowCandidates.length !== 1) {
    return {
      ok: false,
      error: rowCandidates.length > 1 ? "FLEETGEN_PROVISION_PROJECT_AMBIGUOUS" : "FLEETGEN_PROVISION_PROJECT_NOT_FOUND",
      targetLabel,
      matchCount: rowCandidates.length,
      visibleProjectLabels: rowNodes
        .map(textOf)
        .filter(Boolean)
        .slice(0, 80)
    };
  }
  const isDisabled = (element) => element?.disabled === true || element?.getAttribute?.("aria-disabled") === "true";
  const dialog = rowCandidates[0].closest("[role='dialog']") || dialogs[0];
  const dialogRows = projectRowCandidates(dialog);
  const disabledBefore = new Set(footerControls(dialog, dialogRows).filter(isDisabled));
  rowCandidates[0].scrollIntoView({ block: "center" });
  rowCandidates[0].click();
  await new Promise((resolve) => setTimeout(resolve, 250));
  const enabledFooterControls = footerControls(dialog, dialogRows)
    .filter((element) => visible(element) && !isDisabled(element));
  if (!enabledFooterControls.length) {
    const stillDisabled = footerControls(dialog, dialogRows).some((element) => visible(element) && isDisabled(element));
    return {
      ok: false,
      error: stillDisabled ? "FLEETGEN_PROVISION_OPEN_BUTTON_DISABLED" : "FLEETGEN_PROVISION_OPEN_BUTTON_NOT_FOUND",
      targetLabel
    };
  }
  const openButton = enabledFooterControls.find((element) => disabledBefore.has(element))
    || enabledFooterControls.find((element) => textOf(element) === "Open")
    || (enabledFooterControls.length === 1 ? enabledFooterControls[0] : null);
  if (!openButton) {
    return {
      ok: false,
      error: "FLEETGEN_PROVISION_OPEN_BUTTON_AMBIGUOUS",
      targetLabel,
      footerControlLabels: enabledFooterControls.map(textOf).slice(0, 20)
    };
  }
  openButton.click();
  return { ok: true, selected: targetLabel, openLabel: textOf(openButton) };
}

async function chooseFleetGenSharedToolProject(tabId, projectLabel = "", { projectId = "", timeoutMs = 10000 } = {}) {
  const label = compactString(projectLabel);
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 10000));
  let last = null;
  while (Date.now() < deadline) {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId, allFrames: false },
      args: [label],
      func: fleetGenProjectChooseProbe
    }).catch((error) => [{ result: { ok: false, error: compactString(error?.message || error || "fleetgen_project_choose_failed") } }]);
    last = injection?.result || null;
    if (last?.ok) return last;
    if (last?.error === "FLEETGEN_PROVISION_PROJECT_AMBIGUOUS") break;
    await sleep(300);
  }
  throw agentBridgeError(last?.error || "FLEETGEN_PROVISION_UNRECOGNIZED_MODAL", "Fleet Gen shared tool project picker did not expose the exact target project.", {
    tabId,
    projectId,
    projectLabel: label,
    last
  });
}

async function waitForProvisionedFleetGenTool(tabId, projectId = "", { timeoutMs = 45000 } = {}) {
  const expectedProjectId = compactString(projectId);
  const deadline = Date.now() + Math.max(1000, Number(timeoutMs || 45000));
  let last = null;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const url = compactString(tab?.url || "");
    if (isAuthOrOAuthUrl(url)) {
      throw agentBridgeError("FLEETGEN_PROVISION_AUTH_REQUIRED", "Flow redirected to Google auth while provisioning Fleet Gen.", {
        tabId,
        projectId: expectedProjectId,
        url
      });
    }
    const actualProjectId = projectIdFromUrl(url);
    last = { tabId, url, actualProjectId };
    if (actualProjectId && actualProjectId !== expectedProjectId) {
      throw agentBridgeError("FLEETGEN_PROVISION_TARGET_MISMATCH", "Fleet Gen shared tool opened a different Flow project than the requested target.", {
        tabId,
        expectedProjectId,
        actualProjectId,
        url
      });
    }
    if (actualProjectId === expectedProjectId && url.includes(`/tool-version/${FLEETGEN_SHARED_TOOL_ID}`)) {
      return { ok: true, tabId, projectId: expectedProjectId, url };
    }
    await sleep(500);
  }
  throw agentBridgeError("FLEETGEN_PROVISION_TIMEOUT", "Fleet Gen shared tool did not finish opening in the target project.", {
    tabId,
    projectId: expectedProjectId,
    last
  });
}

async function discoverFleetGenFrames(tabId) {
  const parentFrames = await chrome.scripting.executeScript({
    target: { tabId, allFrames: false },
    func: () => [...document.querySelectorAll("iframe")].map((frame, index) => {
      const rect = frame.getBoundingClientRect();
      return {
        index,
        src: frame.getAttribute("src") || "",
        title: frame.getAttribute("title") || "",
        sandbox: frame.getAttribute("sandbox") || "",
        allow: frame.getAttribute("allow") || "",
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      };
    })
  }).catch(() => []);
  const iframeAttrs = Array.isArray(parentFrames?.[0]?.result) ? parentFrames[0].result : [];
  let frames;
  try {
    frames = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    world: "MAIN",
    func: () => {
      const compact = (value = "") => String(value || "").replace(/\s+/g, " ").trim();
      let frameElement = null;
      try {
        frameElement = window.frameElement;
      } catch {}
      const rect = frameElement?.getBoundingClientRect ? frameElement.getBoundingClientRect() : null;
      const bodyText = compact(document.body?.innerText || "");
      return {
        href: location.href,
        title: document.title || "",
        top: window.top === window,
        hasFleetGen: Boolean(window.fleetGen && typeof window.fleetGen === "object"),
        fleetGenKeys: window.fleetGen && typeof window.fleetGen === "object" ? Object.keys(window.fleetGen).sort() : [],
        fleetGenVersion: String(window.fleetGen?.version || ""),
        handshakeLinked: /\bAGENT_LINKED\b/.test(bodyText),
        textSample: bodyText.slice(0, 240),
        frameElement: frameElement ? {
          title: frameElement.getAttribute("title") || "",
          sandbox: frameElement.getAttribute("sandbox") || "",
          allow: frameElement.getAttribute("allow") || "",
          width: rect ? Math.round(rect.width) : 0,
          height: rect ? Math.round(rect.height) : 0
        } : null
      };
    }
    });
  } catch (error) {
    throw agentBridgeError("FLEETGEN_FRAME_DISCOVERY_FAILED", compactString(error?.message || error || "fleetgen_frame_discovery_failed"), {
      tabId,
      parentIframes: iframeAttrs
    });
  }
  return {
    parentIframes: iframeAttrs,
    frames: (frames || []).map((entry) => ({
      frameId: entry.frameId,
      documentId: entry.documentId || "",
      ...(entry.result || {}),
      isAppletPreview: /applet preview/i.test(entry.result?.frameElement?.title || "") || /applet preview/i.test(entry.result?.title || "")
    }))
  };
}

async function invokeFleetGenBridgeMethod(tabId, frameId, method, args = {}, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 10000) || 10000;
  const response = await sendTabMessage(tabId, createMessage(MessageType.PageCommandV4, {
    action: "fleetGenInvoke",
    method,
    includeMediaBytes: options.includeMediaBytes === true,
    timeoutMs,
    ...args
  }, {
    source: "background"
  }), timeoutMs + PAGE_COMMAND_TRANSPORT_GRACE_MS, frameId);
  if (response?.ok === false) {
    throw agentBridgeError(
      compactString(response.error || "").toUpperCase() || "FLEETGEN_BRIDGE_COMMAND_FAILED",
      `Fleet Gen ${method} failed: ${compactString(response.error || "unknown")}`,
      { method, tabId, frameId, response }
    );
  }
  return response || {};
}

function fleetGenBridgeResponsePayload({
  payload = {},
  request = {},
  tab = {},
  target = {},
  methodResponse = {},
  launched = false,
  settings = null,
  sequence = [],
  pollTrace = [],
  timedOut = false,
  startedAt = "",
  expectedTotal = 0,
  capabilities = null
} = {}) {
  const projectId = projectIdFromUrl(tab.url || methodResponse.href || runtimeState.pageUrl || "");
  const state = methodResponse.result || null;
  const promptRecords = fleetGenPromptRecords(payload);
  const runStartedAtMs = Date.parse(startedAt || "") || 0;
  const stateSummary = summarizeFleetGenState(state, { expectedTotal, promptRecords, runStartedAtMs });
  const mediaIds = uniqueFleetGenStrings(stateSummary.mediaIds);
  const urls = fleetGenDownloadUrls(mediaIds, stateSummary.urls);
  const batchId = compactString(payload.batchId || payload.sessionId || request.session?.batchId) || `fleet_${Date.now().toString(36)}`;
  const agentId = compactString(payload.agentId || request.session?.agentId || "autoflow-mcp");
  const prompts = promptRecords.map((record) => record.prompt);
  const outbox = buildFleetGenOutbox({ batchId, agentId, prompts, promptRecords, state, records: stateSummary.records, mediaIds, urls });
  const completedAtMs = Date.now();
  const startedAtMs = Date.parse(startedAt || "") || 0;
  const firstMediaPoll = (Array.isArray(pollTrace) ? pollTrace : []).find((entry) => Number(entry?.mediaIdCount || 0) > 0);
  const firstMediaAtMs = Date.parse(firstMediaPoll?.at || "") || 0;
  const response = {
    ok: timedOut ? false : stateSummary.failed !== true,
    source: "fleetgen_bridge",
    launched: launched === true,
    timedOut: timedOut === true,
    projectId,
    tabId: compactString(tab.id),
    frameId: target.frameId,
    page: {
      tabId: tab.id,
      frameId: target.frameId,
      url: tab.url || methodResponse.href || "",
      title: tab.title || ""
    },
    agentId,
    batchId,
    settings,
    iframe: {
      frameId: target.frameId,
      documentId: target.documentId || "",
      href: target.href || "",
      title: target.title || "",
      sandbox: target.frameElement?.sandbox || "",
      allow: target.frameElement?.allow || "",
      hasFleetGen: target.hasFleetGen === true,
      fleetGenKeys: Array.isArray(target.fleetGenKeys) ? target.fleetGenKeys : [],
      fleetGenVersion: target.fleetGenVersion || ""
    },
    handshake: methodResponse.handshake || null,
    directSdk: methodResponse.directSdk || null,
    bridgeDiagnostics: {
      fleetGenBridgeVersion: methodResponse.fleetGenBridgeVersion || "",
      isolatedWorldHasFleetGen: methodResponse.isolatedWorldHasFleetGen === true,
      isolatedWorldFleetGenType: methodResponse.isolatedWorldFleetGenType || "",
      pageHasFleetGen: methodResponse.hasFleetGen === true,
      availableMethods: Array.isArray(methodResponse.availableMethods) ? methodResponse.availableMethods : []
    },
    provisioning: target.provisioned || null,
    capabilities,
    timing: {
      startedAt: startedAt || "",
      completedAt: new Date(completedAtMs).toISOString(),
      elapsedMs: startedAtMs ? Math.max(0, completedAtMs - startedAtMs) : null,
      firstMediaLatencyMs: startedAtMs && firstMediaAtMs ? Math.max(0, firstMediaAtMs - startedAtMs) : null,
      pollCount: Array.isArray(pollTrace) ? pollTrace.length : 0
    },
    sequence,
    pollTrace,
    stateSummary,
    mediaIds,
    urls,
    mediaReturned: mediaIds.length > 0 || urls.length > 0,
    outbox,
    manifest: {
      tool: "AutoFlow Fleet Gen",
      batchId,
      agentId,
      projectId,
      tabId: compactString(tab.id),
      frameId: target.frameId,
      createdAt: startedAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      prompts,
      settings,
      mediaIds,
      urls,
      jobs: outbox
    },
    state: null,
    rawStateOmitted: true
  };
  if (fleetGenInlineByteSize(response) > FLEETGEN_INLINE_MEDIA_BYTE_LIMIT) {
    return { ...fleetGenReplayCacheResult(response), inlineMediaStripped: true };
  }
  return response;
}

const FLEETGEN_INLINE_MEDIA_BYTE_LIMIT = 32 * 1024 * 1024;

function fleetGenInlineByteSize(response = {}) {
  let size = 0;
  const count = (value) => {
    const text = compactString(value);
    if (text.startsWith("data:") || text.length > 4096) size += text.length;
  };
  const countRecord = (record) => {
    if (!record || typeof record !== "object") return;
    count(record.base64);
    count(record.dataUrl);
    count(record.url);
    count(record.downloadableUrl);
  };
  (Array.isArray(response.outbox) ? response.outbox : []).forEach(countRecord);
  (Array.isArray(response.stateSummary?.records) ? response.stateSummary.records : []).forEach(countRecord);
  (Array.isArray(response.urls) ? response.urls : []).forEach(count);
  return size;
}

function stripFleetGenInlineByteUrl(url = "") {
  const text = compactString(url);
  return text.startsWith("data:") ? "" : text;
}

function stripFleetGenOutboxBytes(jobs) {
  if (!Array.isArray(jobs)) return jobs;
  return jobs.map((job) => (job && typeof job === "object")
    ? {
        ...job,
        base64: "",
        dataUrl: "",
        url: stripFleetGenInlineByteUrl(job.url),
        downloadableUrl: stripFleetGenInlineByteUrl(job.downloadableUrl)
      }
    : job);
}

function stripFleetGenInlineByteUrlList(urls) {
  if (!Array.isArray(urls)) return urls;
  return urls.map(stripFleetGenInlineByteUrl).filter(Boolean);
}

function fleetGenReplayCacheResult(payload = {}) {
  if (!payload || typeof payload !== "object") return payload;
  const stripped = { ...payload, state: null };
  if (Array.isArray(payload.urls)) stripped.urls = stripFleetGenInlineByteUrlList(payload.urls);
  if (payload.stateSummary && typeof payload.stateSummary === "object") {
    stripped.stateSummary = {
      ...payload.stateSummary,
      urls: stripFleetGenInlineByteUrlList(payload.stateSummary.urls),
      records: Array.isArray(payload.stateSummary.records)
        ? payload.stateSummary.records.map((record) => (record && typeof record === "object")
          ? {
              ...record,
              base64: "",
              dataUrl: "",
              url: stripFleetGenInlineByteUrl(record.url),
              downloadableUrl: stripFleetGenInlineByteUrl(record.downloadableUrl)
            }
          : record)
        : payload.stateSummary.records
    };
  }
  const strippedOutbox = stripFleetGenOutboxBytes(payload.outbox);
  stripped.outbox = strippedOutbox;
  if (payload.manifest && typeof payload.manifest === "object") {
    stripped.manifest = {
      ...payload.manifest,
      urls: stripFleetGenInlineByteUrlList(payload.manifest.urls),
      jobs: payload.manifest.jobs === payload.outbox
        ? strippedOutbox
        : stripFleetGenOutboxBytes(payload.manifest.jobs)
    };
  }
  return stripped;
}

function fleetGenPromptsText(payload = {}) {
  return fleetGenPromptLines(payload).join("\n");
}

function fleetGenPromptLines(payload = {}) {
  return fleetGenPromptRecords(payload).map((record) => record.prompt);
}

function fleetGenPromptRecords(payload = {}) {
  return fleetGenPromptRecordsFromInput(payload);
}

function fleetGenSettingsFromPayload(payload = {}) {
  const settings = payload.settings && typeof payload.settings === "object" ? { ...payload.settings } : {};
  const referenceImageMediaIds = Array.isArray(payload.referenceImageMediaIds)
    ? payload.referenceImageMediaIds.map(compactString).filter(Boolean)
    : [];
  const durationSeconds = fleetGenDurationSecondsFromPayload(payload);
  const promptRecords = fleetGenPromptRecords(payload);
  const mediaType = fleetGenMediaTypeFromValue(payload.type || payload.mediaType || settings.type || settings.mediaType)
    || (durationSeconds || compactString(payload.videoModel) || fleetGenPerRowDurationPresent(payload) ? "video" : "image");
  if (referenceImageMediaIds.length) settings.referenceImageMediaIds = referenceImageMediaIds;
  if (mediaType) {
    settings.type = mediaType;
    settings.mediaType = mediaType;
  }
  const requestedMode = compactString(payload.type || payload.mediaType).toLowerCase().replace(/_/g, "-");
  if (["t2i", "text-to-image", "t2v", "text-to-video", "i2v", "image-to-video", "v2v", "video-to-video"].includes(requestedMode)) {
    settings.generationMode = requestedMode;
  }
  if (compactString(payload.model)) {
    settings.model = compactString(payload.model);
    settings.modelDisplayName = settings.modelDisplayName || compactString(payload.model);
    settings.imageModel = settings.imageModel || compactString(payload.model);
    if (mediaType === "video") settings.videoModel = settings.videoModel || compactString(payload.model);
  }
  if (compactString(payload.modelDisplayName)) settings.modelDisplayName = compactString(payload.modelDisplayName);
  if (compactString(payload.imageModel)) settings.imageModel = compactString(payload.imageModel);
  if (compactString(payload.videoModel)) settings.videoModel = compactString(payload.videoModel);
  if (compactString(payload.aspectRatio)) settings.aspectRatio = compactString(payload.aspectRatio);
  for (const key of [
    "firstFrameMediaId",
    "firstFrameImageMediaId",
    "startFrameMediaId",
    "startFrameImageMediaId",
    "lastFrameMediaId",
    "lastFrameImageMediaId",
    "sourceVideoMediaId",
    "sourceVideoMode"
  ]) {
    if (compactString(payload[key])) settings[key] = compactString(payload[key]);
  }
  if (durationSeconds) {
    settings.duration = durationSeconds;
    settings.durationSeconds = durationSeconds;
  }
  if (Array.isArray(payload.promptSettings) && payload.promptSettings.length) {
    settings.promptSettings = payload.promptSettings;
    const promptSettingDurations = payload.promptSettings.map((entry) => {
      const rowDuration = entry && typeof entry === "object"
        ? fleetGenDurationSecondsFromValue(entry.durationSeconds ?? entry.videoDurationSeconds ?? entry.duration ?? entry.videoLength)
        : null;
      return rowDuration || durationSeconds || null;
    });
    if (promptSettingDurations.some(Boolean)) settings.promptDurations = promptSettingDurations;
  } else if (promptRecords.some((entry) => entry.durationSeconds)) {
    settings.promptSettings = promptRecords.map((entry, index) => ({
      index,
      prompt: entry.prompt,
      ...(entry.durationSeconds ? { durationSeconds: entry.durationSeconds, duration: entry.durationSeconds } : {})
    }));
    settings.promptDurations = promptRecords.map((entry) => entry.durationSeconds || durationSeconds || null);
  }
  if (Number.isFinite(Number(payload.concurrency))) settings.concurrency = Number(payload.concurrency);
  if (Number.isFinite(Number(payload.countPerPrompt))) settings.countPerPrompt = Number(payload.countPerPrompt);
  if ("concurrency" in settings) {
    if (Number.isFinite(Number(settings.concurrency))) settings.concurrency = Math.min(12, Math.max(1, Math.floor(Number(settings.concurrency))));
    else delete settings.concurrency;
  }
  if ("countPerPrompt" in settings) {
    if (Number.isFinite(Number(settings.countPerPrompt))) settings.countPerPrompt = Math.min(12, Math.max(1, Math.floor(Number(settings.countPerPrompt))));
    else delete settings.countPerPrompt;
  }
  if (compactString(payload.agentId)) settings.agentId = compactString(payload.agentId);
  if (compactString(payload.batchId)) settings.batchId = compactString(payload.batchId);
  if (compactString(payload.sessionId)) settings.sessionId = compactString(payload.sessionId);
  if (payload.metadata && typeof payload.metadata === "object") settings.metadata = payload.metadata;
  return settings;
}

function fleetGenDurationSecondsFromPayload(payload = {}) {
  return fleetGenDurationSecondsFromInput(payload);
}

function validateFleetGenDurationSecondsPayload(payload = {}) {
  const invalid = fleetGenInvalidDurationValue(payload);
  return invalid === null ? null : { durationSeconds: invalid, allowedDurationSeconds: [4, 6, 8] };
}

function fleetGenExpectedTotal(payload = {}) {
  const promptCount = fleetGenPromptRecords(payload).length;
  const countPerPrompt = Math.min(12, Math.max(1, Math.floor(Number(fleetGenSettingsFromPayload(payload).countPerPrompt) || 1)));
  return promptCount * countPerPrompt;
}

function assertFleetGenCapabilities(settings = {}, capabilities = null) {
  if (!capabilities || typeof capabilities !== "object") return true;
  const durationSeconds = Number(settings.durationSeconds || settings.duration || 0) || 0;
  const supportedDurations = Array.isArray(capabilities.supportedDurationSeconds)
    ? capabilities.supportedDurationSeconds.map(Number).filter(Number.isFinite)
    : [];
  if (durationSeconds && supportedDurations.length && !supportedDurations.includes(durationSeconds)) {
    throw agentBridgeError(
      "FLEETGEN_TOOL_DURATION_UNSUPPORTED",
      `The mounted Fleet Gen tool does not support ${durationSeconds}-second video generation.`,
      { durationSeconds, supportedDurationSeconds: supportedDurations, apiVersion: compactString(capabilities.apiVersion) }
    );
  }
  const hasFirstFrame = [settings.firstFrameMediaId, settings.firstFrameImageMediaId, settings.startFrameMediaId, settings.startFrameImageMediaId]
    .some((value) => compactString(value));
  if (hasFirstFrame && capabilities.supportsI2V === false) {
    throw agentBridgeError("FLEETGEN_TOOL_I2V_UNSUPPORTED", "The mounted Fleet Gen tool does not support first-frame video generation.", {
      apiVersion: compactString(capabilities.apiVersion)
    });
  }
  if (compactString(settings.sourceVideoMediaId) && capabilities.supportsV2V === false) {
    throw agentBridgeError("FLEETGEN_TOOL_V2V_UNSUPPORTED", "The mounted Fleet Gen tool does not support source-video editing.", {
      apiVersion: compactString(capabilities.apiVersion)
    });
  }
  return true;
}

function summarizeFleetGenState(state, options) {
  const expectedTotal = Math.max(0, Number(options?.expectedTotal) || 0);
  const promptRecords = Array.isArray(options?.promptRecords) ? options.promptRecords : [];
  const runStartedAtMs = Math.max(0, Number(options?.runStartedAtMs) || 0);
  const directMediaId = fleetGenMediaIdString(state);
  if (directMediaId) {
    return {
      status: "done",
      running: false,
      terminal: true,
      failed: false,
      total: 1,
      done: 1,
      failedCount: 0,
      mediaIds: [directMediaId],
      urls: [],
      records: [{
        id: directMediaId,
        lineNumber: 1,
        prompt: "",
        status: "done",
        mediaId: directMediaId,
        mimeType: "",
        url: "",
        base64: "",
        dataUrl: "",
        error: ""
      }]
    };
  }
  const records = filterFleetGenRecordsForPromptRecords(dedupeFleetGenRecords(collectFleetGenRecords(state)), promptRecords, { runStartedAtMs });
  const mediaIds = [];
  const urls = [];
  for (const record of records) {
    if (record.mediaId) mediaIds.push(record.mediaId);
    if (record.url) urls.push(record.url);
  }
  const recordStatuses = records.map((record) => compactString(record.status).toLowerCase());
  const statuses = recordStatuses.filter(Boolean);
  const explicitStatus = compactString(state?.status || state?.phase || state?.runStatus).toLowerCase();
  const running = state?.isRunning === true || state?.running === true || ["running", "queued", "launching", "generating", "pending"].includes(explicitStatus);
  const failed = ["failed", "error", "blocked"].includes(explicitStatus) || statuses.some((status) => ["failed", "error", "blocked"].includes(status));
  const terminalStatuses = new Set(["done", "complete", "completed", "failed", "error", "skipped", "blocked"]);
  const total = records.length || Number(state?.total || state?.totalCount || 0) || 0;
  const done = statuses.filter((status) => ["done", "complete", "completed"].includes(status)).length || Number(state?.done || state?.completed || state?.completedCount || 0) || 0;
  const failedCount = statuses.filter((status) => ["failed", "error", "blocked"].includes(status)).length || Number(state?.failed || state?.failedCount || 0) || 0;
  const recordsTerminal = records.length > 0 && records.every((record, index) => {
    const status = recordStatuses[index] || "";
    return terminalStatuses.has(status) || Boolean(record.mediaId || record.url);
  });
  const countTerminal = total > 0 && done + failedCount >= total;
  const anyRecordPending = records.some((record, index) => {
    const status = recordStatuses[index] || "";
    if (terminalStatuses.has(status) || record.mediaId || record.url) return false;
    return true;
  });
  const coverageSatisfied = !expectedTotal || total >= expectedTotal;
  const explicitFailureTerminal = ["failed", "error", "blocked"].includes(explicitStatus);
  const explicitSuccessTerminal = ["done", "complete", "completed"].includes(explicitStatus);
  const terminal = explicitFailureTerminal
    || (coverageSatisfied && (
      explicitSuccessTerminal
      || (running !== true && !anyRecordPending && (recordsTerminal || countTerminal || mediaIds.length > 0))
    ));
  return {
    status: explicitStatus || (running ? "running" : terminal ? failed ? "failed" : "done" : "unknown"),
    running,
    terminal,
    failed,
    total,
    done,
    failedCount,
    mediaIds: uniqueFleetGenStrings(mediaIds),
    urls: uniqueFleetGenStrings(urls),
    records
  };
}

function filterFleetGenRecordsForPromptRecords(records = [], promptRecords = [], options = {}) {
  const promptSet = new Set((Array.isArray(promptRecords) ? promptRecords : [])
    .map((record) => compactString(record?.prompt || record?.text || "").toLowerCase())
    .filter(Boolean));
  if (!promptSet.size) return records;
  const runStartedAtMs = Math.max(0, Number(options.runStartedAtMs) || 0);
  const matched = (Array.isArray(records) ? records : []).filter((record) => {
    const prompt = compactString(record?.prompt || "").toLowerCase();
    if (!prompt || !promptSet.has(prompt)) return false;
    const createdAtMs = Math.max(0, Number(record?.createdAtMs) || 0);
    return !runStartedAtMs || !createdAtMs || createdAtMs >= runStartedAtMs;
  });
  return dropFleetGenPromptOnlyDuplicates(matched);
}

function dropFleetGenPromptOnlyDuplicates(records = []) {
  const promptsWithMaterialRecord = new Set();
  for (const record of Array.isArray(records) ? records : []) {
    const prompt = compactString(record?.prompt || "").toLowerCase();
    if (!prompt) continue;
    if (record.mediaId || record.url || record.base64 || record.dataUrl || record.status || record.error) {
      promptsWithMaterialRecord.add(prompt);
    }
  }
  if (!promptsWithMaterialRecord.size) return records;
  return (Array.isArray(records) ? records : []).filter((record) => {
    const prompt = compactString(record?.prompt || "").toLowerCase();
    if (!prompt || !promptsWithMaterialRecord.has(prompt)) return true;
    return Boolean(record.mediaId || record.url || record.base64 || record.dataUrl || record.status || record.error);
  });
}

function dedupeFleetGenRecords(records = []) {
  const scored = (record = {}) =>
    (record.prompt ? 16 : 0)
    + (record.status ? 8 : 0)
    + (record.id && record.id !== record.mediaId ? 4 : 0)
    + (record.mimeType ? 2 : 0)
    + (record.base64 || record.dataUrl || record.url ? 1 : 0);
  const merged = new Map();
  const order = [];
  for (const record of Array.isArray(records) ? records : []) {
    if (!record || typeof record !== "object") continue;
    const key = record.mediaId || record.url || record.dataUrl || record.id || `${order.length}`;
    if (!merged.has(key)) {
      merged.set(key, record);
      order.push(key);
      continue;
    }
    const current = merged.get(key);
    const [primary, secondary] = scored(record) > scored(current) ? [record, current] : [current, record];
    merged.set(key, {
      ...secondary,
      ...primary,
      prompt: primary.prompt || secondary.prompt || "",
      status: primary.status || secondary.status || "",
      mimeType: primary.mimeType || secondary.mimeType || "",
      base64: primary.base64 || secondary.base64 || "",
      dataUrl: primary.dataUrl || secondary.dataUrl || "",
      url: primary.url || secondary.url || "",
      downloadableUrl: primary.downloadableUrl || secondary.downloadableUrl || "",
      createdAtMs: primary.createdAtMs || secondary.createdAtMs || null
    });
  }
  return order.map((key) => merged.get(key)).filter(Boolean);
}

function fleetGenSubmitIdempotencyKey(payload = {}, promptsText = "", tabId = 0, projectId = "") {
  const explicit = compactString(payload.idempotencyKey);
  if (explicit) return `${compactString(projectId)}||${compactString(tabId)}||fleet:${explicit}`;
  const stablePayload = {
    promptsText: compactString(promptsText),
    settings: fleetGenSettingsFromPayload(payload),
    direct: payload.direct === true || payload.executeDirect === true,
    waitUntilDone: payload.waitUntilDone !== false,
    agentId: compactString(payload.agentId),
    batchId: compactString(payload.batchId),
    sessionId: compactString(payload.sessionId)
  };
  return `${compactString(projectId)}||${compactString(tabId)}||fleet:${hashCompactString(JSON.stringify(stablePayload))}`;
}

function assertFleetGenCreditApproval(payload = {}) {
  if (hasStandingCreditLimit(payload)) {
    throw agentBridgeError(
      "FLEETGEN_CREDIT_CAP_UNSUPPORTED",
      "Fleet Gen cannot enforce maxCreditsPerRun because the iframe tool does not expose a stable credit prompt API.",
      { maxCreditsPerRun: payload.maxCreditsPerRun ?? payload.creditCap ?? payload.creditLimit ?? null }
    );
  }
  if (payload.confirmCredits === true && !isCaptainAuthorized(payload)) {
    throw agentBridgeError(
      "AGENT_CREDIT_CONFIRMATION_REQUIRES_CAPTAIN_AUTHORIZATION",
      "Fleet Gen confirmCredits requires a captain-authorized batch.",
      { confirmCredits: true }
    );
  }
  return true;
}

function collectFleetGenRecords(value, records = [], seen = new WeakSet()) {
  const bareMediaId = fleetGenMediaIdString(value);
  if (bareMediaId) {
    records.push({
      id: bareMediaId,
      lineNumber: 0,
      prompt: "",
      status: "done",
      mediaId: bareMediaId,
      mimeType: "",
      url: "",
      base64: "",
      dataUrl: "",
      createdAtMs: null,
      error: ""
    });
    return records;
  }
  if (!value || typeof value !== "object") return records;
  if (seen.has(value)) return records;
  seen.add(value);
  const resultList = Array.isArray(value.results) ? value.results : [];
  if (resultList.length && (value.prompt || value.id || value.status || value.lineNumber)) {
    resultList.forEach((result, index) => {
      const createdAtMs = fleetGenTimestampMs(result) || fleetGenTimestampMs(value) || null;
      const mediaId = compactString(result?.mediaId || result?.mediaID || result?.media?.mediaId || "");
      const mimeType = compactString(result?.mimeType || result?.media?.mimeType || value.mimeType || "");
      const base64 = compactString(result?.base64 || result?.media?.base64 || "");
      const dataUrl = compactString(result?.dataUrl || result?.dataURL || result?.media?.dataUrl || result?.media?.dataURL || fleetGenDataUrl({ base64, mimeType }));
      const url = compactString(result?.url || result?.downloadUrl || result?.downloadableUrl || result?.mediaUrl || result?.media?.url || result?.media?.downloadUrl || result?.media?.downloadableUrl || result?.media?.mediaUrl || dataUrl);
      records.push({
        id: compactString(result?.id || result?.jobId || value.id || value.jobId || value.rowId || ""),
        lineNumber: Number(value.lineNumber || value.index || 0) || 0,
        resultIndex: index + 1,
        prompt: compactString(value.prompt || value.text || ""),
        status: compactString(result?.status || result?.state || value.status || value.state || ""),
        mediaId,
        mimeType,
        url,
        base64,
        dataUrl,
        createdAtMs,
        error: compactString(result?.error || result?.message || value.error || value.message || "")
      });
    });
    for (const [key, entry] of Object.entries(value)) {
      if (key === "results") continue;
      if (Array.isArray(entry)) {
        for (const child of entry) collectFleetGenRecords(child, records, seen);
      } else if (entry && typeof entry === "object") {
        collectFleetGenRecords(entry, records, seen);
      }
    }
    return records;
  }
  const directMediaId = compactString(value.mediaId || value.mediaID || "");
  const nestedMediaId = compactString(value.result?.mediaId || value.output?.mediaId || value.media?.mediaId || fleetGenMediaIdString(value.result) || fleetGenMediaIdString(value.output) || "");
  const mimeType = compactString(value.mimeType || value.result?.mimeType || value.output?.mimeType || value.media?.mimeType || "");
  const base64 = compactString(value.base64 || value.result?.base64 || value.output?.base64 || value.media?.base64 || "");
  const dataUrl = compactString(value.dataUrl || value.dataURL || value.result?.dataUrl || value.result?.dataURL || value.output?.dataUrl || value.output?.dataURL || value.media?.dataUrl || value.media?.dataURL || fleetGenDataUrl({ base64, mimeType }));
  const url = compactString(value.url || value.downloadUrl || value.downloadableUrl || value.mediaUrl || value.result?.url || value.result?.downloadUrl || value.result?.downloadableUrl || value.result?.mediaUrl || value.output?.url || value.output?.downloadUrl || value.output?.downloadableUrl || value.media?.url || value.media?.downloadUrl || value.media?.downloadableUrl || value.media?.mediaUrl || dataUrl);
  if (directMediaId || nestedMediaId || url || value.prompt || value.status || value.error || value.id || value.jobId || value.rowId || value.lineNumber) {
    const createdAtMs = fleetGenTimestampMs(value) || fleetGenTimestampMs(value.result) || fleetGenTimestampMs(value.output) || fleetGenTimestampMs(value.media) || null;
    records.push({
      id: compactString(value.id || value.jobId || value.rowId || ""),
      lineNumber: Number(value.lineNumber || value.index || 0) || 0,
      prompt: compactString(value.prompt || value.text || ""),
      status: compactString(value.status || value.state || ""),
      mediaId: directMediaId || nestedMediaId,
      mimeType,
      url,
      base64,
      dataUrl,
      createdAtMs,
      error: compactString(value.error || value.message || "")
    });
  }
  for (const entry of Object.values(value)) {
    if (Array.isArray(entry)) {
      for (const child of entry) collectFleetGenRecords(child, records, seen);
    } else if (entry && typeof entry === "object") {
      collectFleetGenRecords(entry, records, seen);
    }
  }
  return records;
}

function fleetGenTimestampMs(value = null) {
  if (!value || typeof value !== "object") return 0;
  const candidates = [
    value.createdAt,
    value.created_at,
    value.createTime,
    value.createdTime,
    value.startedAt,
    value.started_at,
    value.submittedAt,
    value.completedAt,
    value.updatedAt,
    value.timestamp,
    value.time
  ];
  for (const candidate of candidates) {
    if (candidate === undefined || candidate === null || candidate === "") continue;
    if (typeof candidate === "number" && Number.isFinite(candidate)) {
      return candidate > 100000000000 ? Math.floor(candidate) : Math.floor(candidate * 1000);
    }
    const parsed = Date.parse(String(candidate));
    if (Number.isFinite(parsed)) return parsed;
  }
  return 0;
}

function fleetGenMediaIdString(value) {
  const text = compactString(value);
  return /^fe_id_[a-z0-9-]+$/i.test(text) ? text : "";
}

function fleetGenDataUrl(input = null) {
  const encoded = compactString(input?.base64 || "");
  if (!encoded) return "";
  return `data:${compactString(input?.mimeType || "") || "application/octet-stream"};base64,${encoded}`;
}

function buildFleetGenOutbox({ batchId = "", agentId = "", prompts = [], promptRecords = [], state = null, records: scopedRecords = null, mediaIds = [], urls = [] } = {}) {
  const promptRecordAt = (index) => (Array.isArray(promptRecords) && promptRecords[index]) || { prompt: prompts[index] || "", durationSeconds: null };
  const records = (Array.isArray(scopedRecords) ? scopedRecords : collectFleetGenRecords(state)).filter((record) => record.mediaId || record.url || record.prompt || record.status || record.error);
  if (records.length) {
    return records.map((record, index) => {
      const promptRecord = promptRecordAt(Math.max(0, Number(record.lineNumber || index + 1) - 1));
      const durationSeconds = Number(record.durationSeconds || record.duration || promptRecord.durationSeconds || 0) || null;
      return {
        batchId,
        agentId,
        rowId: record.resultIndex > 1
          ? `${record.id || `fleet-${index + 1}`}-r${record.resultIndex}`
          : (record.id || `fleet-${index + 1}`),
        lineNumber: record.lineNumber || index + 1,
        resultIndex: record.resultIndex || 1,
        prompt: record.prompt || promptRecord.prompt || prompts[index] || "",
        ...(durationSeconds ? { durationSeconds } : {}),
        status: record.status || (record.mediaId || record.url ? "done" : "unknown"),
        mediaId: record.mediaId || "",
        mimeType: record.mimeType || "",
        url: record.url || record.dataUrl || (record.mediaId && !record.base64 ? buildMediaRedirectUrl({ mediaId: record.mediaId }) : ""),
        downloadableUrl: record.url || record.dataUrl || "",
        base64: record.base64 || "",
        dataUrl: record.dataUrl || "",
        error: record.error || "",
        downloadState: record.mediaId || record.url || record.base64 ? "ready" : "pending"
      };
    });
  }
  const max = Math.max(prompts.length, mediaIds.length, urls.length);
  return Array.from({ length: max }, (_unused, index) => {
    const promptRecord = promptRecordAt(index);
    return {
      batchId,
      agentId,
      rowId: `fleet-${index + 1}`,
      lineNumber: index + 1,
      prompt: promptRecord.prompt || prompts[index] || "",
      ...(promptRecord.durationSeconds ? { durationSeconds: promptRecord.durationSeconds } : {}),
      status: mediaIds[index] || urls[index] ? "done" : "unknown",
      mediaId: mediaIds[index] || "",
      mimeType: "",
      url: urls[index] || (mediaIds[index] ? buildMediaRedirectUrl({ mediaId: mediaIds[index] }) : ""),
      error: "",
      downloadState: mediaIds[index] || urls[index] ? "ready" : "pending"
    };
  });
}

function fleetGenDownloadUrls(mediaIds = [], urls = []) {
  return uniqueFleetGenStrings([
    ...uniqueFleetGenStrings(urls),
    ...uniqueFleetGenStrings(mediaIds).map((mediaId) => buildMediaRedirectUrl({ mediaId }))
  ]);
}

function uniqueFleetGenStrings(values = []) {
  return [...new Set((Array.isArray(values) ? values : [values]).map(compactString).filter(Boolean))];
}

function fleetGenMethodSummary(response = {}) {
  return {
    pageHasFleetGen: response.hasFleetGen === true,
    isolatedWorldHasFleetGen: response.isolatedWorldHasFleetGen === true,
    availableMethods: Array.isArray(response.availableMethods) ? response.availableMethods : [],
    handshakeLinked: response.handshake?.linked === true,
    directSdkWindowFlowType: response.directSdk?.windowFlowType || "",
    mediaIds: summarizeFleetGenState(response.result).mediaIds
  };
}


async function submitAgentPromptFromBridge(payload = {}, request = {}) {
  const prompt = compactString(payload.prompt);
  if (!prompt) {
    throw agentBridgeError("AGENT_PROMPT_EMPTY", "Agent prompt is empty.");
  }
  const requestedAgentTransport = compactString(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  if (requestedAgentTransport === "api" || requestedAgentTransport === "agent_api") {
    const apiTarget = await resolveAgentApiTarget(payload);
    await assertAgentBridgeWriteEntitled(payload);
    return submitAgentPromptViaDirectApi(payload, request, { ...apiTarget, prompt });
  }
  let tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  // P0-1: fail closed if the caller asked for a specific project/tab and the
  // resolved Flow tab is not it (a newer tab must not steal the submit).
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  await assertAgentBridgeWriteEntitled(payload);
  const chatOnly = payload.chatOnly === true;
  const composerPreflightHistory = await agentComposerPreflightHistory(projectId, tab.id, payload);
  // P0-2: hold a per-target lock for live submits only; dry-runs skip it.
  const isLiveSubmit = payload.dryRun !== true;
  let pageResult;
  let refAttachResult = null;
  let managedProtocolResult = null;
  let nativeSettingsResult = null;
  let projectSettingsResult = null;
  let refPlan = agentRefAttachmentPlanFromPayload(payload, { liveAttach: isLiveSubmit });
  const pendingToolContract = chatOnly
    ? { required: false, kind: "chat" }
    : buildAgentPendingToolContract({ ...payload, refPlan });
  let capabilityValidation = { ok: true, skipped: true, reason: "not_a_new_generation_contract" };
  if (refPlan?.ok === false) {
    throw agentBridgeError(
      refPlan.code || "AGENT_REF_PLAN_INVALID",
      refPlan.message || "Agent reference attachment plan is invalid.",
      { errors: Array.isArray(refPlan.errors) ? refPlan.errors : [], plan: refPlan }
    );
  }
  const requestKind = compactString(request.type || payload.requestKind || "agent.prompt.submit");
  if (!chatOnly && payload.continuation !== true && requestKind !== "agent.retry.submit") {
    const capabilityMode = compactString(payload.mode).toLowerCase() === "agent"
      ? (payload.matrix?.mode || payload.runProfile?.mode || payload.settings?.mode)
      : (payload.mode || payload.matrix?.mode || payload.runProfile?.mode || payload.settings?.mode);
    capabilityValidation = validateAgentCapabilityContract({
      mode: capabilityMode,
      runProfile: payload.runProfile || payload.settings || payload.matrix?.settings,
      matrix: payload.matrix,
      refPlan,
      references: refPlan?.attachments || []
    });
    if (!capabilityValidation.ok) {
      throw agentBridgeError(
        capabilityValidation.code || "AGENT_CAPABILITY_CONTRACT_INVALID",
        capabilityValidation.message || "Agent run contains a physically unsupported model/workflow/settings combination.",
        capabilityValidation
      );
    }
  }
  if (isLiveSubmit) {
    try {
      // CDP mouse events against a background duplicate Flow tab can report a
      // click without the page accepting it. Activate the exact bound tab (not
      // merely a matching project URL) before any trusted settings/ref/submit
      // input so duplicate project tabs cannot steal the live write.
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => null);
      tab = await chrome.tabs.get(tab.id).catch(() => tab);
      if (chatOnly) {
        await normalizeAgentProjectSurfaceWithDebugger(tab.id, {
          stage: "chat_only",
          allowManagedInstructionsClose: false
        });
      } else {
        const currentZoom = await chrome.tabs.getZoom(tab.id).catch(() => 1);
        if (Number(tab.width || 0) > 0 && Number(tab.width || 0) < 1700 && currentZoom > 0.8) {
          await chrome.tabs.setZoom(tab.id, 0.8);
          await sleep(500);
          recordEvent({ type: "agent_bridge.viewport.compact_zoom", tabId: tab.id, from: currentZoom, to: 0.8, width: tab.width });
        }
        tab = await ensureAgentBridgeProjectRootTab(tab, projectId);
        if (payload.startNewAgentSession === true && payload.continuation !== true && request.type !== "agent.retry.submit") {
          await startFreshAgentConversationSessionWithDebugger(tab.id, { stage: "new_run" });
        }
      }
    } catch (error) {
      const publicError = refPlan
        ? agentBridgeRefAttachError(
          error?.code || "AGENT_FLOW_COMPOSER_NOT_READY",
          error?.message || "Flow Agent project root did not expose a ready composer send control before submit.",
          error?.details || null
        )
        : error;
      const submitFailure = agentSubmitFailureStateFromError(publicError, {
        refPlan,
        submitted: false
      });
      if (!chatOnly) await upsertAgentBridgeRunState({
        projectId,
        tabId: tab.id,
        payload,
        status: submitFailure.status,
        submitted: submitFailure.submitted,
        error: submitFailure.message,
        blockCode: submitFailure.code,
        blocker: submitFailure.blocker
      }).catch((stateError) => {
        recordEvent({
          type: "agent_bridge.live_queue.blocked_state_failed",
          projectId,
          tabId: tab.id,
          status: submitFailure.status,
          blockCode: submitFailure.code,
          originalError: compactString(publicError?.message || publicError || "agent_setup_blocked"),
          error: compactString(stateError?.message || stateError || "state_update_failed")
        });
      });
      throw publicError;
    }
  }
  const lockKey = agentSubmitLockKey(projectId, tab.id);
  const idempotencyKey = isLiveSubmit ? agentSubmitIdempotencyKey(payload, prompt, tab.id, projectId, request) : "";
  const priorSubmit = idempotencyKey ? agentSubmitIdempotency.get(idempotencyKey) : null;
  if (priorSubmit?.status === "completed" && priorSubmit.result) {
    return {
      ...priorSubmit.result,
      idempotentReplay: true,
      idempotencyKey
    };
  }
  if (priorSubmit?.status === "pending") {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "An identical Agent submit is already in progress for this Flow target.",
      { idempotencyKey }
    );
  }
  if (isLiveSubmit && !agentSubmitLock.acquire(lockKey)) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Another agent submit is already in progress for this Flow target.",
      { lockKey }
    );
  }
  if (isLiveSubmit && !chatOnly) {
    await upsertAgentBridgeRunState({
      projectId,
      tabId: tab.id,
      payload,
      status: "submitting"
    }).catch((error) => {
      recordEvent({
        type: "agent_bridge.live_queue.submit_state_failed",
        projectId,
        tabId: tab.id,
        error: compactString(error?.message || error || "state_update_failed")
      });
    });
  }
  try {
    if (idempotencyKey) {
      pruneAgentSubmitIdempotency();
      agentSubmitIdempotency.set(idempotencyKey, {
        status: "pending",
        startedAt: Date.now()
      });
    }
    if (isLiveSubmit && !chatOnly && payload.ensureManagedAgentInstructions !== false && payload.continuation !== true && request.type !== "agent.retry.submit") {
      managedProtocolResult = await ensureManagedAgentInstructionsWithDebugger(tab.id, {
        requestKind: compactString(request.type || "agent.prompt.submit")
      });
      await normalizeAgentProjectSurfaceWithDebugger(tab.id, {
        stage: "after_managed_instructions",
        allowManagedInstructionsClose: true
      });
      await waitForAgentBridgeStableProjectComposer(tab.id, projectId, { timeoutMs: 10000 });
    }
    if (isLiveSubmit && !chatOnly && payload.ensureNativeSettings !== false && payload.continuation !== true && request.type !== "agent.retry.submit") {
      const nativeSettingsPlan = buildAgentNativeSettingsPlan({
        mode: payload.mode,
        matrix: payload.matrix,
        runProfile: payload.runProfile || payload.settings,
        settings: payload.settings,
        expectedImages: payload.expectedImages ?? payload.matrix?.expectedImages,
        expectedVideos: payload.expectedVideos ?? payload.matrix?.expectedVideos,
        creditPolicy: payload.creditPolicy
      });
      nativeSettingsResult = await ensureAgentNativeSettingsWithDebugger(tab.id, nativeSettingsPlan, {
        requestKind: compactString(request.type || "agent.prompt.submit")
      });
      await normalizeAgentProjectSurfaceWithDebugger(tab.id, { stage: "after_native_settings" });
      await waitForAgentBridgeStableProjectComposer(tab.id, projectId, { timeoutMs: 10000 });
    }
    if (isLiveSubmit && !chatOnly && payload.continuation !== true && request.type !== "agent.retry.submit") {
      projectSettingsResult = await ensureAgentProjectClearPromptOnSubmitWithDebugger(tab.id, true, {
        requestKind: compactString(request.type || "agent.prompt.submit")
      });
    }
    if (isLiveSubmit && (refPlan?.attachments?.length || payload.clearExistingRefs === true)) {
      refAttachResult = await attachAgentRefsWithDebugger(tab.id, refPlan || { attachments: [] }, {
        timeoutMs: payload.attachTimeoutMs || payload.timeoutMs,
        forceAttach: payload.forceAttach === true || payload.forceAttachRefs === true,
        clearExisting: payload.clearExistingRefs === true,
        requestKind: compactString(request.type || "agent.prompt.submit")
      });
    }
    pageResult = await executeAgentPromptInPage(tab.id, {
        prompt,
        dryRun: payload.dryRun === true,
        autoConfirm: payload.autoConfirm === true || payload.confirmCredits === true || payload.autoConfirmCredits === true,
        creditPolicy: payload.creditPolicy && typeof payload.creditPolicy === "object" ? payload.creditPolicy : {},
        approvedCredits: Number(payload.approvedCredits || 0) || 0,
        knownAutoFlowDraftHashes: composerPreflightHistory.knownAutoFlowDraftHashes,
        submittedPromptHashes: composerPreflightHistory.submittedPromptHashes,
        currentPromptSubmitted: composerPreflightHistory.currentPromptSubmitted,
        toolContract: pendingToolContract,
        requestKind: chatOnly ? "agent.chat.submit" : "agent.prompt.submit"
      });
  } catch (error) {
    if (isLiveSubmit && !chatOnly) {
      const submitFailure = agentSubmitFailureStateFromError(error, {
        refPlan,
        submitted: pageResult?.submitted === true
      });
      await upsertAgentBridgeRunState({
        projectId,
        tabId: tab.id,
        payload,
        status: submitFailure.status,
        submitted: submitFailure.submitted,
        error: submitFailure.message,
        blockCode: submitFailure.code,
        blocker: submitFailure.blocker
      }).catch((stateError) => {
        recordEvent({
          type: "agent_bridge.live_queue.submit_failure_state_failed",
          projectId,
          tabId: tab.id,
          status: submitFailure.status,
          blockCode: submitFailure.code,
          originalError: compactString(error?.message || error || "agent_submit_failed"),
          error: compactString(stateError?.message || stateError || "state_update_failed")
        });
      });
    }
    if (idempotencyKey) agentSubmitIdempotency.delete(idempotencyKey);
    throw error;
  } finally {
    if (isLiveSubmit) agentSubmitLock.release(lockKey);
  }
  if (projectId) {
    promoteFlowTabBinding(tab, {
      projectId,
      href: tab.url || runtimeState.pageUrl || "",
      title: tab.title || runtimeState.pageTitle || ""
    }, "agent_bridge_prompt_submit");
  }
  recordEvent({
    type: pageResult.submitted ? "agent_bridge.prompt.submitted" : "agent_bridge.prompt.prepared",
    tabId: tab.id,
    projectId,
    dryRun: payload.dryRun === true,
    promptLength: prompt.length,
    editorRect: pageResult.editor?.rect || null,
    submitButtonRect: pageResult.submitButton?.rect || null
  });
  const result = {
    ok: true,
    submitted: pageResult.submitted === true,
    dryRun: payload.dryRun === true,
    projectId,
    page: {
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || ""
    },
    promptLength: prompt.length,
    promptPreview: prompt.slice(0, 240),
    editor: pageResult.editor || null,
    submitButton: pageResult.submitButton || null,
    accepted: pageResult.accepted || null,
    confirmation: pageResult.confirmation || null,
    chatOnly,
    waitingForCreditApproval: pageResult.waitingForCreditApproval === true,
    creditAction: pageResult.creditAction || null,
    creditDecision: pageResult.creditDecision || null,
    creditDialog: pageResult.creditDialog || null,
    toolTelemetry: pageResult.toolTelemetry || null,
    toolContractValidation: pageResult.toolContractValidation || null,
    refs: refAttachResult ? {
      attached: Number(refAttachResult.attached || 0),
      plan: refAttachResult.plan || null,
      chips: refAttachResult.chips || [],
      timing: refAttachResult.timing || null
    } : null,
    restored: pageResult.restored === true,
    preflight: {
      ...(pageResult.preflight || {}),
      nativeSettings: nativeSettingsResult,
      projectSettings: projectSettingsResult,
      managedProtocol: managedProtocolResult,
      capabilityValidation
    }
  };
  if (isLiveSubmit && !chatOnly) {
    await upsertAgentBridgeRunState({
      projectId,
      tabId: tab.id,
      payload,
      status: pageResult.waitingForCreditApproval === true ? "waiting_for_credit_approval" : (pageResult.submitted ? "submitted" : "prepared"),
      submitted: pageResult.submitted === true,
      pendingAction: pageResult.waitingForCreditApproval === true ? pageResult.creditAction : null,
      creditDecision: pageResult.creditDecision || null,
      toolLineage: pageResult.toolContractValidation?.observed || null
    }).catch((error) => {
      recordEvent({
        type: "agent_bridge.live_queue.submit_result_state_failed",
        projectId,
        tabId: tab.id,
        error: compactString(error?.message || error || "state_update_failed")
      });
    });
    if (pageResult.submitted === true) scheduleAgentSupervisionAlarm("agent_submit");
  }
  if (idempotencyKey) {
    agentSubmitIdempotency.set(idempotencyKey, {
      status: "completed",
      completedAt: Date.now(),
      result
    });
  }
  return result;
}

async function agentComposerPreflightHistory(projectId = "", tabId = 0, payload = {}) {
  const submittedPromptHashes = new Set(
    (Array.isArray(payload.submittedPromptHashes) ? payload.submittedPromptHashes : [])
      .map(compactString)
      .filter(Boolean)
  );
  const knownAutoFlowDraftHashes = new Set(
    (Array.isArray(payload.knownAutoFlowDraftHashes) ? payload.knownAutoFlowDraftHashes : [])
      .map(compactString)
      .filter(Boolean)
  );
  let currentPromptSubmitted = payload.currentPromptSubmitted === true;
  const stored = await chrome.storage.local.get(SIDEPANEL_STATE_STORAGE_KEY).catch(() => ({}));
  const priorRun = stored?.[SIDEPANEL_STATE_STORAGE_KEY]?.control?.agentRun;
  const sameTarget = priorRun && typeof priorRun === "object"
    && (!compactString(priorRun.projectId) || compactString(priorRun.projectId) === compactString(projectId))
    && (!Number(priorRun.tabId) || Number(priorRun.tabId) === Number(tabId));
  if (sameTarget) {
    const priorHash = compactString(priorRun.promptHash);
    if (priorHash) knownAutoFlowDraftHashes.add(priorHash);
    if (priorHash && priorRun.submitted === true) submittedPromptHashes.add(priorHash);
    const requestedRunId = agentBridgePayloadRunId(payload);
    currentPromptSubmitted = currentPromptSubmitted || Boolean(
      requestedRunId
      && agentBridgeRunIdentityMatches(priorRun, requestedRunId)
      && priorRun.submitted === true
    );
  }
  return {
    knownAutoFlowDraftHashes: [...knownAutoFlowDraftHashes],
    submittedPromptHashes: [...submittedPromptHashes],
    currentPromptSubmitted
  };
}

function agentSubmitFailureStateFromError(error = {}, context = {}) {
  const message = compactString(error?.message || error || "agent_submit_failed");
  const code = compactString(error?.code || "");
  if (context.submitted === true) {
    return {
      status: "submit_error",
      submitted: true,
      code,
      message,
      blocker: null
    };
  }
  if (code === AGENT_COMPOSER_TARGET_UNRESOLVED || /^(AGENT_(?:COMPOSER_DRAFT_CONFLICT|PROMPT_ALREADY_SUBMITTED|GENERATION_ACTIVE|INSTRUCTIONS_|MANAGED_PROTOCOL_))/.test(code)) {
    return {
      status: "setup_blocked",
      submitted: false,
      code,
      message,
      blocker: {
        code,
        originalCode: code,
        message,
        submitAttempted: false
      }
    };
  }
  if (context.refPlan) {
    const refFailure = normalizeAgentRefAttachError(error);
    if (agentRunStatusIsPreSubmitBlocked(refFailure.status)) {
      return {
        status: refFailure.status,
        submitted: false,
        code: refFailure.code,
        message: refFailure.message || message,
        blocker: {
          code: refFailure.code,
          originalCode: refFailure.originalCode || code,
          message: refFailure.message || message,
          submitAttempted: false
        }
      };
    }
  }
  return {
    status: "submit_error",
    submitted: false,
    code,
    message,
    blocker: null
  };
}

async function submitAgentRetryFromBridge(payload = {}) {
  const retryPrompt = agentRetryPromptFromPayload(payload);
  if (!retryPrompt) {
    throw agentBridgeError("AGENT_RETRY_PROMPT_EMPTY", "Agent retry payload did not include a retry prompt.");
  }
  const result = await submitAgentPromptFromBridge({
    ...payload,
    prompt: retryPrompt,
    requestKind: "agent.retry.submit"
  });
  return {
    ...result,
    retry: true,
    rows: Array.isArray(payload.rowIds) ? payload.rowIds : (Array.isArray(payload.rows) ? payload.rows : [])
  };
}

async function attachAgentRefsFromBridge(payload = {}, request = {}) {
  const plan = planAgentRefAttachments({
    refs: agentRefAttachmentRefsFromPayload(payload),
    targetRefs: payload.targetRefs || payload.targetReferences || [],
    projectId: payload.projectId,
    tabId: payload.tabId
  }, {
    liveAttach: payload.dryRun !== true,
    projectId: payload.projectId,
    tabId: payload.tabId
  });
  if (plan?.ok !== true) {
    throw agentBridgeError(
      plan?.code || "AGENT_REF_PLAN_INVALID",
      plan?.message || "Agent reference attachment plan is invalid.",
      { errors: Array.isArray(plan?.errors) ? plan.errors : [], plan }
    );
  }
  if (payload.dryRun === true) {
    return {
      ok: true,
      dryRun: true,
      attached: 0,
      plan,
      callerPlanIgnored: Boolean(payload.plan && typeof payload.plan === "object"),
      requestKind: compactString(request.type || "agent.refs.attach")
    };
  }

  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  await assertAgentBridgeWriteEntitled(payload);
  const attachmentCount = Array.isArray(plan.attachments) ? plan.attachments.length : 0;
  const defaultAttachTimeoutMs = Math.min(120000, 15000 + (attachmentCount * 12000));
  const requestedAttachTimeoutMs = Number(payload.timeoutMs || payload.attachTimeoutMs || defaultAttachTimeoutMs) || defaultAttachTimeoutMs;
  const attachTimeoutMs = Math.max(3000, requestedAttachTimeoutMs - Math.min(3000, Math.floor(requestedAttachTimeoutMs * 0.25)));
  const attachOperation = attachAgentRefsWithDebugger(tab.id, plan, {
    timeoutMs: attachTimeoutMs,
    forceAttach: payload.forceAttach === true || payload.forceAttachRefs === true,
    requestKind: compactString(request.type || "agent.refs.attach")
  }).catch((error) => ({ ok: false, attachError: error }));
  const result = await Promise.race([
    attachOperation,
    timeoutAfter(attachTimeoutMs, "AGENT_REF_ATTACH_TIMEOUT")
  ]);
  if (result?.ok === false && result.error === "AGENT_REF_ATTACH_TIMEOUT") {
    await releaseDebuggerSessions("agent_bridge_refs_attach_timeout", recordDebuggerTrace).catch(() => null);
    throw agentBridgeRefAttachError(
      "AGENT_REF_ATTACH_TIMEOUT",
      "Agent reference attachment timed out while driving the Flow asset picker.",
      {
        timeoutMs: attachTimeoutMs,
        requestedTimeoutMs: requestedAttachTimeoutMs,
        tabId: tab.id,
        projectId,
        attachmentCount: Array.isArray(plan.attachments) ? plan.attachments.length : 0
      }
    );
  }
  if (result?.attachError) {
    throw agentBridgeRefAttachError(
      result.attachError.code || "AGENT_REF_ATTACH_FAILED",
      result.attachError.message || result.attachError,
      result.attachError.details || null
    );
  }
  const normalizedResult = result || {};
  recordEvent({
    type: "agent_bridge.refs.attached",
    tabId: tab.id,
    projectId,
    attachmentCount: Array.isArray(plan.attachments) ? plan.attachments.length : 0,
    attached: Number(normalizedResult.attached || 0),
    readyForSubmit: normalizedResult.plan?.readyForSubmit === true
  });
  return {
    ok: true,
    attached: Number(normalizedResult.attached || 0),
    plan: normalizedResult.plan,
    chips: normalizedResult.chips || [],
    projectId,
    page: {
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || ""
    }
  };
}

function agentRefAttachmentRefsFromPayload(payload = {}) {
  const refs = [];
  for (const field of ["refs", "references", "attachments"]) {
    if (Array.isArray(payload[field])) refs.push(...payload[field]);
  }
  return refs;
}

function agentBridgeRefAttachError(code = "AGENT_REF_ATTACH_FAILED", message = "", details = undefined) {
  const normalized = normalizeAgentRefAttachError({ code, message });
  if (agentRunStatusIsPreSubmitBlocked(normalized.status)) {
    return agentBridgeError(normalized.code, normalized.message || message, {
      ...(details && typeof details === "object" ? details : {}),
      originalCode: normalized.originalCode || code,
      submitAttempted: false,
      status: normalized.status
    });
  }
  return agentBridgeError(code, message || code, details);
}

function agentRefAttachmentPlanFromPayload(payload = {}, options = {}) {
  const refs = agentRefAttachmentRefsFromPayload(payload);
  const targetRefs = payload.targetRefs || payload.targetReferences || [];
  if (!refs.length && !(Array.isArray(targetRefs) && targetRefs.length)) return null;
  return planAgentRefAttachments({
    refs,
    targetRefs,
    projectId: payload.projectId,
    tabId: payload.tabId
  }, {
    liveAttach: options.liveAttach === true,
    projectId: payload.projectId,
    tabId: payload.tabId
  });
}

async function attachAgentRefsWithDebugger(tabId = 0, plan = {}, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent reference attachment.");
  }
  const attachments = Array.isArray(plan.attachments) ? plan.attachments : [];
  const supportedActions = new Set(["upload_local_file", "upload_extension_blob", "reuse_flow_media"]);
  const unsupported = attachments.filter((attachment) => !supportedActions.has(attachment.action));
  if (unsupported.length) {
    throw agentBridgeError(
      "AGENT_REF_ATTACH_UNAVAILABLE",
      "Auto Flow cannot attach one or more planned Agent reference source types.",
      { unsupported, plan }
    );
  }
  const localPaths = attachments.filter((attachment) => attachment.action === "upload_local_file").map((attachment) => compactString(attachment.path)).filter(Boolean);
  const relativePath = localPaths.find((filePath) => !isAbsoluteAgentRefPath(filePath));
  if (relativePath) {
    throw agentBridgeError(
      "AGENT_REF_LOCAL_PATH_NOT_ABSOLUTE",
      "Agent reference local paths must be absolute before they reach the extension.",
      { path: relativePath }
    );
  }
  if (!attachments.length && options.clearExisting !== true) {
    return { ok: true, attached: 0, plan, chips: [] };
  }
  const resolvedAttachments = [];
  for (const attachment of attachments) {
    if (attachment.action !== "upload_extension_blob") {
      resolvedAttachments.push(attachment);
      continue;
    }
    const blob = await getReferenceBlob(attachment.blobStoreId).catch(() => null);
    if (!blob?.dataUrl) {
      throw agentBridgeError(
        "AGENT_REF_EXTENSION_BLOB_MISSING",
        `Auto Flow could not load extension reference ${attachment.handle || attachment.blobStoreId}.`,
        { handle: attachment.handle, blobStoreId: attachment.blobStoreId }
      );
    }
    resolvedAttachments.push({
      ...attachment,
      blob: {
        dataUrl: blob.dataUrl,
        fileName: compactString(attachment.fileName || blob.fileName || "reference.png"),
        mimeType: compactString(attachment.mimeType || blob.mimeType || mimeTypeFromDataUrl(blob.dataUrl) || "image/png"),
        size: Number(blob.size || 0)
      }
    });
  }

  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_bridge_refs_attach", recordDebuggerTrace).catch(() => null);
  let attached = false;
  // P0-1 (file picker): the CLI/MCP attach path must never depend on the native
  // OS file picker. We arm file-chooser interception + a cancel guard so any
  // chooser Flow tries to open is dismissed programmatically, and the file is
  // delivered through DOM.setFileInputFiles instead. teardownAgentRefAttach()
  // in the finally guarantees the picker/interception are torn down on abort.
  let fileChooserInterceptionEnabled = false;
  // Tracks whether Flow's in-page asset picker may still be open. It only opens
  // while a local file is being driven into the prompt; a successful
  // addAgentLocalFileRefToPrompt confirms it closed. Threading this into
  // teardown keeps the CLOSE_ASSET_PICKER Escape from firing on the successful
  // path (which would clear the freshly-attached chips) while still fail-safe
  // closing it on any abort where the picker may be left open.
  let assetPickerOpen = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "DOM.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});
    await debuggerSend(target, "Page.enable").catch(() => {});
    await debuggerSend(target, "Page.setInterceptFileChooserDialog", { enabled: true }).catch((error) => {
      throw agentBridgeError(
        "AGENT_REF_FILE_CHOOSER_INTERCEPTION_FAILED",
        "Agent reference attachment could not arm file-chooser interception; refusing to risk the native OS picker.",
        { error: compactString(error?.message || error || "interception failed") }
      );
    });
    fileChooserInterceptionEnabled = true;
    installAgentRefFileChooserGuard(target);

    // P0-2 (stale chips): clean existing prompt ref chips before adding new ones
    // or trusting existing visible media, so a fresh attach never inherits
    // leftovers from a previous prompt.
    const chipCleanup = await clearExistingAgentRefChips(target);
    if (chipCleanup?.cleared === false) {
      throw agentBridgeError(
        "AGENT_REF_STALE_CHIPS_NOT_CLEARED",
        "Agent reference attachment found stale prompt ref chips that could not be cleared; refusing to attach new refs.",
        { chipCleanup }
      );
    }
    const postCleanupBaselineChips = await readAgentRefVisibleChips(target);
    if (!resolvedAttachments.length) {
      return {
        ok: true,
        attached: 0,
        plan,
        chips: postCleanupBaselineChips,
        chipCleanup,
        verifiedEmpty: postCleanupBaselineChips.length === 0
      };
    }
    const attachmentResults = [];
    const attachmentTimingStartedAt = Date.now();
    const pickerTimeoutMs = Math.min(Number(options.timeoutMs || 15000) || 15000, 30000);
    const chipProofTimeoutMs = Math.min(Number(options.timeoutMs || 15000) || 15000, 15000);
    const orderedAttachments = resolvedAttachments.sort((left, right) => Number(left.order || 0) - Number(right.order || 0));
    const bulkLocalAttachments = orderedAttachments.length > 1
      && orderedAttachments.every((attachment) => attachment.action === "upload_local_file");
    if (bulkLocalAttachments) {
      const bulkStartedAt = Date.now();
      recordEvent({
        type: "agent_bridge.refs.bulk_attachment_started",
        attachmentCount: orderedAttachments.length,
        handles: orderedAttachments.map((attachment) => compactString(attachment.handle))
      });
      assetPickerOpen = true;
      const bulkResult = await addAgentLocalFileRefsToPrompt(target, orderedAttachments, {
        timeoutMs: pickerTimeoutMs
      });
      assetPickerOpen = false;
      const cumulativeProof = await waitForAgentRefCumulativeChipCount(target, orderedAttachments.length, {
        timeoutMs: Math.min(pickerTimeoutMs, 15000)
      });
      const completedAt = Date.now();
      for (const [attachmentIndex, attachment] of orderedAttachments.entries()) {
        attachmentResults.push({
          bulk: true,
          bulkIndex: attachmentIndex + 1,
          filename: bulkResult.filenames[attachmentIndex],
          timing: {
            startedAt: new Date(bulkStartedAt).toISOString(),
            completedAt: new Date(completedAt).toISOString(),
            durationMs: completedAt - bulkStartedAt,
            expectedChipCount: orderedAttachments.length,
            visibleChipCount: Number(cumulativeProof?.visibleCount || 0)
          }
        });
      }
      recordEvent({
        type: "agent_bridge.refs.bulk_attachment_completed",
        attachmentCount: orderedAttachments.length,
        handles: orderedAttachments.map((attachment) => compactString(attachment.handle)),
        durationMs: completedAt - bulkStartedAt,
        visibleChipCount: Number(cumulativeProof?.visibleCount || 0),
        bulkResult
      });
    } else {
      for (const [attachmentIndex, attachment] of orderedAttachments.entries()) {
        const itemStartedAt = Date.now();
        recordEvent({
          type: "agent_bridge.refs.attachment_started",
          attachmentIndex: attachmentIndex + 1,
          attachmentCount: orderedAttachments.length,
          action: compactString(attachment.action),
          handle: compactString(attachment.handle)
        });
        assetPickerOpen = true;
        let attachmentResult;
        if (attachment.action === "upload_local_file") {
          attachmentResult = await addAgentLocalFileRefToPrompt(target, attachment.path, {
            timeoutMs: pickerTimeoutMs
          });
        } else if (attachment.action === "upload_extension_blob") {
          attachmentResult = await addAgentExtensionBlobRefToPrompt(target, attachment, {
            timeoutMs: pickerTimeoutMs
          });
        } else {
          attachmentResult = await addAgentFlowMediaRefToPrompt(target, attachment, {
            timeoutMs: pickerTimeoutMs
          });
        }
        assetPickerOpen = false;
        const mediaOwnershipProof = attachment.action === "reuse_flow_media"
          ? await waitForAgentRefExactMediaChip(target, attachment.mediaId, {
            timeoutMs: Math.min(pickerTimeoutMs, 12000),
            expectedCount: attachmentIndex + 1
          })
          : null;
        const cumulativeProof = await waitForAgentRefCumulativeChipCount(target, attachmentIndex + 1, {
          timeoutMs: Math.min(pickerTimeoutMs, 12000)
        });
        const completedAt = Date.now();
        const timing = {
          startedAt: new Date(itemStartedAt).toISOString(),
          completedAt: new Date(completedAt).toISOString(),
          durationMs: completedAt - itemStartedAt,
          expectedChipCount: attachmentIndex + 1,
          visibleChipCount: Number(cumulativeProof?.visibleCount || 0)
        };
        attachmentResults.push({ ...attachmentResult, timing, mediaOwnershipProof });
        recordEvent({
          type: "agent_bridge.refs.attachment_completed",
          attachmentIndex: attachmentIndex + 1,
          attachmentCount: orderedAttachments.length,
          action: compactString(attachment.action),
          handle: compactString(attachment.handle),
          durationMs: timing.durationMs,
          visibleChipCount: timing.visibleChipCount
        });
      }
    }
    const proof = await waitForAgentRefVisibleChipProof(target, plan, {
      timeoutMs: chipProofTimeoutMs,
      baselineChips: postCleanupBaselineChips
    });
    return {
      ok: true,
      attached: resolvedAttachments.length,
      plan: proof.plan,
      chips: proof.chips,
      chipCleanup,
      input: attachmentResults,
      timing: {
        startedAt: new Date(attachmentTimingStartedAt).toISOString(),
        completedAt: new Date().toISOString(),
        durationMs: Date.now() - attachmentTimingStartedAt,
        attachmentCount: attachmentResults.length,
        attachments: attachmentResults.map((entry, index) => ({
          index: index + 1,
          handle: compactString(orderedAttachments[index]?.handle),
          action: compactString(orderedAttachments[index]?.action),
          ...entry.timing
        }))
      }
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_REF_ATTACH_FAILED", String(error?.message || error || "Agent reference attachment failed."));
  } finally {
    if (attached) {
      await teardownAgentRefAttach(target, { fileChooserInterceptionEnabled, assetPickerOpen }).catch(() => null);
      await chrome.debugger.detach(target).catch(() => {});
    }
  }
}

// Cancel any native file-chooser dialog Flow opens on this tab so the OS picker
// is never left waiting on a human. The file is delivered programmatically via
// DOM.setFileInputFiles; this guard just dismisses the chooser if it appears.
const agentRefFileChooserGuards = new Map();

function installAgentRefFileChooserGuard(target) {
  const tabId = target?.tabId;
  if (!tabId || typeof chrome.debugger?.onEvent?.addListener !== "function") return;
  if (agentRefFileChooserGuards.has(tabId)) return;
  const listener = async (source, method) => {
    if (source?.tabId !== tabId) return;
    if (method !== "Page.fileChooserOpened") return;
    await debuggerSend(target, "Page.handleFileChooser", { action: "cancel" }).catch(() => null);
  };
  chrome.debugger.onEvent.addListener(listener);
  agentRefFileChooserGuards.set(tabId, listener);
}

function removeAgentRefFileChooserGuard(target) {
  const tabId = target?.tabId;
  if (!tabId) return;
  const listener = agentRefFileChooserGuards.get(tabId);
  if (listener && typeof chrome.debugger?.onEvent?.removeListener === "function") {
    chrome.debugger.onEvent.removeListener(listener);
  }
  agentRefFileChooserGuards.delete(tabId);
}

// Programmatic teardown for an aborted/completed ref attach. Closes Flow's
// in-page asset picker (Escape), cancels a pending intercepted chooser, and
// disarms file-chooser interception — all without any native picker dependency.
async function teardownAgentRefAttach(target, state = {}) {
  const teardown = planAgentRefAttachTeardown({
    assetPickerOpen: state.assetPickerOpen,
    fileChooserInterceptionEnabled: state.fileChooserInterceptionEnabled === true,
    pendingFileChooser: state.pendingFileChooser === true
  });
  for (const entry of teardown.steps) {
    if (entry.step === AGENT_REF_ATTACH_TEARDOWN_STEPS.CANCEL_INTERCEPTED_FILE_CHOOSER) {
      await debuggerSend(target, "Page.handleFileChooser", { action: "cancel" }).catch(() => null);
    } else if (entry.step === AGENT_REF_ATTACH_TEARDOWN_STEPS.CLOSE_ASSET_PICKER) {
      await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 25 }).catch(() => null);
      await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 25 }).catch(() => null);
    } else if (entry.step === AGENT_REF_ATTACH_TEARDOWN_STEPS.DISABLE_FILE_CHOOSER_INTERCEPTION) {
      await debuggerSend(target, "Page.setInterceptFileChooserDialog", { enabled: false }).catch(() => null);
    }
  }
  removeAgentRefFileChooserGuard(target);
  return teardown;
}

// Remove existing prompt ref chips before a fresh attach (P0-2). Clicking a
// chip's remover reflows the composer, so a single pre-scan's later removeRects
// become stale on-screen coordinates. Remove ONE chip per pass and re-read the
// composer between removals so every click targets a fresh, correct rect. A
// no-progress guard stops re-clicking a chip that will not clear. Removals are
// counted only once the re-scan confirms the removable population shrank (never
// on an unverified click), and any leftover stale chip — one with no remover
// (blocked) OR one whose remover click never lands (unresolved) — is surfaced
// (recordEvent + returned chipCleanup) rather than silently inherited by the
// fresh attach.
async function readAgentRefChipPopulation(target) {
  const chips = (await readAgentRefChipsWithRemovers(target).catch(() => []))
    .filter((chip) => chip?.visible !== false && chip?.isRefChip === true && chip?.isSuggestionCard !== true);
  const overflowCount = await readAgentRefCollapsedOverflowCount(target).catch(() => 0);
  return {
    chips,
    overflowCount,
    total: chips.length + overflowCount
  };
}

async function waitForAgentRefChipPopulationBelow(target, previousTotal = 0, options = {}) {
  const timeoutMs = Math.max(100, Math.min(Number(options.timeoutMs || 1200) || 1200, 3000));
  const deadline = Date.now() + timeoutMs;
  let population = await readAgentRefChipPopulation(target);
  while (population.total >= previousTotal && Date.now() < deadline) {
    await sleep(50);
    population = await readAgentRefChipPopulation(target);
  }
  return {
    ...population,
    progressed: population.total < previousTotal,
    timeoutMs
  };
}

async function clearExistingAgentRefChips(target) {
  const MAX_REMOVAL_PASSES = 24;
  const initialPopulation = await readAgentRefChipPopulation(target);
  const hadStaleRefChips = initialPopulation.total > 0;
  let population = initialPopulation;
  let clearAll = null;
  let noProgressPasses = 0;

  // Fast path: Flow's structural composer clear control removes the whole stale
  // set in one action. Observe the chip census instead of sleeping for a fixed
  // interval; if Flow ignores it, fall back to guarded one-at-a-time removal.
  if (population.total > 1) {
    clearAll = await clearAgentRefComposerChipsTogether(target).catch(() => null);
    if (clearAll?.ok) {
      population = await waitForAgentRefChipPopulationBelow(target, population.total);
    }
  }

  for (let pass = 0; pass < MAX_REMOVAL_PASSES && population.total > 0; pass += 1) {
    population = await readAgentRefChipPopulation(target);
    if (population.total === 0) break;
    const cleanup = planAgentRefChipCleanup(population.chips);
    const removable = cleanup.removeChips.filter((entry) => entry.removeRect);
    if (!removable.length) break;

    const previousTotal = population.total;
    const chip = removable[0];
    await clickAgentRefChipRemoverInPage(target, chip.removeRect).catch(() => null);
    population = await waitForAgentRefChipPopulationBelow(target, previousTotal);
    if (population.progressed) {
      noProgressPasses = 0;
    } else {
      noProgressPasses += 1;
      if (noProgressPasses >= 2) break;
    }
  }

  population = await readAgentRefChipPopulation(target);
  const finalCleanup = planAgentRefChipCleanup(population.chips);
  const blocked = finalCleanup.blockedCount;
  const blockedChips = Array.isArray(finalCleanup.blockedChips)
    ? finalCleanup.blockedChips.map((entry) => compactString(entry?.label)).filter(Boolean)
    : [];
  const remainingRemovable = finalCleanup.removeChips.filter((entry) => entry.removeRect);
  const leftoverRemovable = remainingRemovable.length;
  const leftoverRemovableChips = remainingRemovable
    .map((entry) => compactString(entry?.label))
    .filter(Boolean);
  // Count only the population drop proven by the final structural re-scan,
  // never a click attempt. This includes collapsed +N references.
  const removed = Math.max(0, initialPopulation.total - population.total);

  if (blocked > 0) {
    recordEvent({
      type: "agent_bridge.refs.stale_chip_unremovable",
      level: "warning",
      blocked,
      removed,
      blockedChips: blockedChips.slice(0, 8)
    });
  }
  if (leftoverRemovable > 0) {
    recordEvent({
      type: "agent_bridge.refs.stale_chip_click_unresolved",
      level: "warning",
      leftoverRemovable,
      removed,
      leftoverRemovableChips: leftoverRemovableChips.slice(0, 8)
    });
  }
  return {
    removed,
    blocked,
    blockedChips,
    leftoverRemovable,
    leftoverRemovableChips,
    hadStaleRefChips,
    clearAll,
    remainingTotal: population.total,
    cleared: population.total === 0 && blocked === 0 && leftoverRemovable === 0
  };
}

async function clearAgentRefComposerChipsTogether(target) {
  return await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom > window.innerHeight * 0.45;
    };
    const tokens = (element) => new Set(String(element?.innerText || element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const editors = Array.from(document.querySelectorAll("[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true'],textarea"))
      .filter(visible)
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.right > innerWidth * 0.5 && rect.bottom > innerHeight * 0.7;
      });
    let composerShell = null;
    for (const editor of editors) {
      for (let shell = editor.parentElement, depth = 0; shell && depth < 8; shell = shell.parentElement, depth += 1) {
        const rect = shell.getBoundingClientRect();
        const hasAdd = Array.from(shell.querySelectorAll("button,[role='button']")).some((control) => tokens(control).has("add_2"));
        if (hasAdd && rect.width <= 680 && rect.height <= 450) {
          composerShell = shell;
          break;
        }
      }
      if (composerShell) break;
    }
    if (!composerShell) return { ok: false, code: "AGENT_REF_CLEAR_ALL_COMPOSER_NOT_FOUND" };
    const thumbnailCount = composerShell.querySelectorAll("img,[data-card-open]").length;
    const promptChipSignals = Array.from(composerShell.querySelectorAll("button,[role='button'],span,div"))
      .filter((node) => {
        const text = String(node.textContent || "").replace(/\\s+/g, " ").trim();
        return text === "cancel" || /^\\+\\d{1,2}$/.test(text);
      }).length;
    const candidates = Array.from(composerShell.querySelectorAll("button,[role='button']"))
      .filter(visible)
      .filter((element) => {
        const iconTokens = tokens(element);
        return (iconTokens.has("close") || iconTokens.has("clear")) && !element.querySelector("img");
      })
      .map((element) => ({ element, rect: element.getBoundingClientRect(), thumbnailCount, promptChipSignals }))
      .filter((entry) => (entry.thumbnailCount > 0 || entry.promptChipSignals > 0) && entry.rect.width <= 180 && entry.rect.height <= 64)
      .sort((left, right) => right.rect.x - left.rect.x || right.rect.y - left.rect.y);
    const chosen = candidates[0];
    if (!chosen) return { ok: false, code: "AGENT_REF_CLEAR_ALL_CONTROL_NOT_FOUND" };
    chosen.element.click();
    return {
      ok: true,
      method: "composer_clear_all",
      thumbnailCount: chosen.thumbnailCount,
      promptChipSignals: chosen.promptChipSignals,
      rect: { x: Math.round(chosen.rect.x), y: Math.round(chosen.rect.y), width: Math.round(chosen.rect.width), height: Math.round(chosen.rect.height) }
    };
  })()`);
}

async function clickAgentRefChipRemoverInPage(target, expectedRect = {}) {
  return await debuggerEvaluate(target, `(() => {
    const expectedRect = ${JSON.stringify(expectedRect)};
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const tokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const remover = Array.from(document.querySelectorAll("button,[role='button'],[aria-label]"))
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const iconTokens = tokens(element);
        const removeIcon = iconTokens.has("close") || iconTokens.has("cancel") || iconTokens.has("clear");
        const sameRect = Math.abs(rect.x - Number(expectedRect.x || 0)) <= 4
          && Math.abs(rect.y - Number(expectedRect.y || 0)) <= 4
          && Math.abs(rect.width - Number(expectedRect.width || 0)) <= 4
          && Math.abs(rect.height - Number(expectedRect.height || 0)) <= 4;
        return { element, removeIcon, sameRect };
      })
      .find((entry) => entry.removeIcon && entry.sameRect);
    if (!remover) return { ok: false, code: "AGENT_REF_CHIP_REMOVER_CHANGED" };
    remover.element.click();
    return { ok: true, method: "guarded_element_click" };
  })()`);
}

async function readAgentRefChipsWithRemovers(target) {
  // Detection is structural and language-agnostic (repo rule: DOM selectors must
  // not depend on English visible text). A ref chip is identified by a file-name
  // extension OR an actual thumbnail node/style, never by localizable nouns.
  // Removers are found by Material Symbols ligature tokens (close/cancel/clear)
  // whose glyph text is the same in every locale, not by action labels.
  const result = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim();
    const iconTokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const composerEditor = allDeep("[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true'],textarea,input")
      .filter(visible)
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        const type = normalize(element.getAttribute?.("type")).toLowerCase();
        return rect.right > window.innerWidth * 0.5
          && rect.bottom > window.innerHeight * 0.7
          && type !== "search"
          && element.getAttribute?.("role") !== "searchbox";
      })
      .sort((left, right) => right.getBoundingClientRect().bottom - left.getBoundingClientRect().bottom)[0] || null;
    let composerShell = null;
    for (let shell = composerEditor?.parentElement, depth = 0; shell && depth < 7; shell = shell.parentElement, depth += 1) {
      const rect = shell.getBoundingClientRect();
      let hasAddControl = false;
      try {
        hasAddControl = Array.from(shell.querySelectorAll("button,[role='button']"))
          .some((control) => iconTokens(control).has("add_2"));
      } catch {}
      if (hasAddControl && rect.width <= 520 && rect.height <= 420 && rect.bottom > window.innerHeight * 0.75) {
        composerShell = shell;
        break;
      }
    }
    const isComposerZone = (rect, element) => composerShell
      ? composerShell.contains(element)
      : rect.right > window.innerWidth * 0.5 && rect.bottom > window.innerHeight * 0.72;
    const removeIcon = (element) => {
      const tokens = new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
      return tokens.has("close") || tokens.has("cancel") || tokens.has("clear");
    };
    const hasImageThumbnail = (element) => {
      if (!element) return false;
      const asImg = (node) => {
        if (!node || String(node.tagName || "").toLowerCase() !== "img") return false;
        const src = String(node.getAttribute?.("src") || node.currentSrc || "");
        const box = node.getBoundingClientRect?.();
        return Boolean(src) && box && box.width >= 20 && box.height >= 20;
      };
      if (asImg(element)) return true;
      let innerImg = null;
      try { innerImg = element.querySelector?.("img"); } catch {}
      if (asImg(innerImg)) return true;
      try {
        const bg = getComputedStyle(element).backgroundImage || "";
        const box = element.getBoundingClientRect();
        if (/url\\(/i.test(bg) && box.width >= 24 && box.height >= 24) return true;
      } catch {}
      return false;
    };
    const containerSelector = "[data-testid*='chip' i],[class*='chip' i],[class*='pill' i]";
    const cardSelector = "[data-card-open],button,[role='button']";
    const chipSelectors = [containerSelector, "[data-card-open]", "img"].join(",");
    const rows = [];
    const seenContainers = new Set();
    for (const element of allDeep(chipSelectors)) {
      if (!visible(element)) continue;
      let container = element;
      try { container = element.closest("[data-card-open]") || element.closest(containerSelector) || element.closest(cardSelector) || element.parentElement || element; } catch {}
      if (!container || seenContainers.has(container) || !visible(container)) continue;
      // Project gallery tiles are generated outputs, never composer input
      // chips. Compact layouts can place the rightmost gallery tile inside the
      // broad geometric composer zone, so exclude it by stable tile/edit-route
      // structure before filename or thumbnail classification.
      let projectGalleryTile = false;
      try {
        projectGalleryTile = Boolean(container.closest?.("[data-tile-id]") || container.closest?.("a[href*='/edit/']"));
      } catch {}
      if (projectGalleryTile) continue;
      seenContainers.add(container);
      const rect = rectOf(container);
      if (!isComposerZone(rect, container)) continue;
      const label = normalize(container.getAttribute?.("aria-label") || container.getAttribute?.("title") || container.getAttribute?.("alt") || container.innerText || container.textContent);
      if (label.length > 180) continue;
      const hasChipShell = (() => {
        try { return Boolean(container.matches?.(containerSelector) || element.closest?.(containerSelector)); } catch { return false; }
      })();
      const hasDataCardOpen = (() => {
        try { return Boolean(container.matches?.("[data-card-open]") || element.closest?.("[data-card-open]")); } catch { return false; }
      })();
      const tag = String(container.tagName || "").toLowerCase();
      const role = normalize(container.getAttribute?.("role") || (tag === "button" ? "button" : ""));
      const thumbnail = hasImageThumbnail(container);
      const fileLike = /\\.(png|jpe?g|webp|gif|heic|avif)(?:\\b|$)/i.test(label);
      const removerCandidates = [
        ...(container.matches?.("button,[role='button'],[aria-label]") ? [container] : []),
        ...Array.from(container.querySelectorAll("button,[role='button'],[aria-label]"))
      ];
      const remover = removerCandidates.filter(visible).filter(removeIcon)[0] || null;
      const isSuggestionCard = thumbnail && !fileLike && !hasChipShell && !hasDataCardOpen && !remover && (tag === "button" || role === "button");
      const refLike = fileLike || hasDataCardOpen || (thumbnail && !isSuggestionCard);
      if (!refLike && !isSuggestionCard) continue;
      const mediaIds = Array.from(container.querySelectorAll("img,[src],[href]"))
        .flatMap((node) => {
          const values = [node.currentSrc, node.src, node.href];
          try { values.push(...Array.from(node.attributes || []).map((attribute) => attribute.value)); } catch {}
          return values;
        })
        .flatMap((value) => String(value || "").match(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/ig) || [])
        .filter((value, index, values) => values.indexOf(value) === index);
      rows.push({
        label,
        text: label,
        visible: true,
        isRefChip: !isSuggestionCard,
        hasChipShell,
        hasDataCardOpen,
        hasImageThumbnail: thumbnail,
        mediaIds,
        isSuggestionCard,
        role,
        removeRect: remover ? rectOf(remover) : null
      });
    }
    return rows.slice(0, 24);
  })()`).catch(() => []);
  return Array.isArray(result) ? result : [];
}

function isAbsoluteAgentRefPath(filePath = "") {
  const value = compactString(filePath);
  return value.startsWith("/") || /^[a-zA-Z]:[\\/]/.test(value);
}

function agentRefFileBasename(filePath = "") {
  return compactString(filePath).split(/[\\/]/).filter(Boolean).pop() || compactString(filePath);
}

async function readAgentRefAssetPickerBulkUploadState(target, filenames = []) {
  const expected = filenames.map((filename) => compactString(filename).toLowerCase()).filter(Boolean);
  return debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(expected)};
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim().toLowerCase();
    const dialogs = Array.from(document.querySelectorAll("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container"))
      .filter(visible);
    const dialog = dialogs.find((element) => element.querySelector("[role='tablist']") && element.querySelector("input,[role='textbox']")) || null;
    if (!dialog) return { ok: true, open: false, expected, found: [], missing: expected };
    const evidence = new Set();
    const imageRows = [];
    for (const image of Array.from(dialog.querySelectorAll("img"))) {
      const label = normalize(image.getAttribute("alt") || image.getAttribute("title"));
      if (!label) continue;
      evidence.add(label);
      const rect = image.getBoundingClientRect();
      imageRows.push({ label, area: Math.round(rect.width * rect.height) });
    }
    for (const option of Array.from(dialog.querySelectorAll("[role='option']"))) {
      const label = normalize(option.innerText || option.textContent || option.getAttribute("aria-label") || option.getAttribute("title"));
      if (label) evidence.add(label);
    }
    const found = expected.filter((filename) => evidence.has(filename));
    const missing = expected.filter((filename) => !evidence.has(filename));
    const selectedFilename = imageRows
      .filter((entry) => expected.includes(entry.label) && entry.area >= 10000)
      .sort((left, right) => right.area - left.area)[0]?.label || "";
    const dialogRect = dialog.getBoundingClientRect();
    const action = Array.from(dialog.querySelectorAll("button"))
      .filter(visible)
      .find((button) => {
        const rect = button.getBoundingClientRect();
        return !button.disabled && button.getAttribute("aria-disabled") !== "true"
          && rect.width >= dialogRect.width * 0.25
          && rect.x >= dialogRect.x + dialogRect.width * 0.45
          && rect.y >= dialogRect.y + dialogRect.height * 0.72
          && rect.bottom <= dialogRect.bottom + 80;
      }) || null;
    const actionRect = action ? action.getBoundingClientRect() : null;
    return {
      ok: true,
      open: true,
      expected,
      found,
      missing,
      exactCount: found.length,
      selectedFilename,
      action: actionRect ? {
        rect: { x: Math.round(actionRect.x), y: Math.round(actionRect.y), width: Math.round(actionRect.width), height: Math.round(actionRect.height) },
        disabled: Boolean(action.disabled || action.getAttribute("aria-disabled") === "true")
      } : null
    };
  })()`);
}

async function addAgentLocalFileRefsToPrompt(target, attachments = [], options = {}) {
  const ordered = attachments
    .map((attachment) => ({
      path: compactString(attachment?.path),
      filename: agentRefFileBasename(attachment?.path || "")
    }))
    .filter((attachment) => attachment.path && attachment.filename);
  if (ordered.length !== attachments.length || ordered.length < 2) {
    throw agentBridgeError("AGENT_REF_BULK_INPUT_INVALID", "Bulk Agent reference upload requires at least two exact local files.", {
      requestedCount: attachments.length,
      resolvedCount: ordered.length
    });
  }
  const filenames = ordered.map((attachment) => attachment.filename);
  const paths = ordered.map((attachment) => attachment.path);
  await openAgentRefAssetPicker(target, { filename: filenames[0] });
  const upload = await clickAgentRefAssetPickerUpload(target);
  const input = await markAgentRefFileInput(target, "asset_picker_bulk_upload");
  if (input?.summary?.multiple !== true) {
    throw agentBridgeError("AGENT_REF_BULK_INPUT_UNSUPPORTED", "Flow Agent did not expose a multi-file reference input.", {
      filenames,
      input: input?.summary || null
    });
  }
  await debuggerSend(target, "DOM.setFileInputFiles", {
    objectId: input.objectId,
    files: paths
  });

  const timeoutMs = Math.min(Number(options.timeoutMs || 30000) || 30000, 45000);
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    await sleep(state ? 300 : 900);
    state = await readAgentRefAssetPickerBulkUploadState(target, filenames);
    if (state?.open && state.missing?.length === 0 && state.selectedFilename && state?.action?.rect && state.action.disabled !== true) {
      await debuggerClick(target, pointFromRect(state.action.rect));
      const pickerClose = await waitForAgentRefAssetPickerClosed(target, state.selectedFilename, {
        timeoutMs: Math.min(8000, timeoutMs)
      });
      if (!pickerClose.closed) {
        throw agentBridgeError("AGENT_REF_PICKER_STILL_OPEN", "Flow Agent stayed open after adding the first bulk-uploaded reference.", {
          filenames,
          state,
          pickerClose
        });
      }
      const attachmentSteps = [{ filename: state.selectedFilename, autoSelectedAfterBulkUpload: true, pickerClose }];
      let attachedCount = 1;
      for (const filename of filenames.filter((candidate) => candidate.toLowerCase() !== state.selectedFilename)) {
        const attachedExisting = await addAgentExistingUploadedLocalFileRefToPrompt(target, filename, {
          timeoutMs: Math.min(10000, timeoutMs)
        });
        attachedCount += 1;
        const cumulativeProof = await waitForAgentRefCumulativeChipCount(target, attachedCount, {
          timeoutMs: Math.min(10000, timeoutMs)
        });
        attachmentSteps.push({ ...attachedExisting, cumulativeProof });
      }
      return {
        ok: true,
        bulk: true,
        filenames,
        fileCount: paths.length,
        upload,
        input: input.summary || null,
        selection: state,
        pickerClose,
        attachmentSteps
      };
    }
  }
  throw agentBridgeError("AGENT_REF_BULK_UPLOAD_NOT_READY", "Flow Agent did not expose the complete uploaded reference set for one-click attachment.", {
    filenames,
    input: input?.summary || null,
    state,
    timeoutMs
  });
}

async function addAgentExistingUploadedLocalFileRefToPrompt(target, filename = "", options = {}) {
  await openAgentRefAssetPicker(target, { filename });
  await searchAgentRefAssetPicker(target, filename).catch(() => null);
  const selected = await selectAgentRefAssetPickerFile(target, filename, {
    timeoutMs: Math.min(Number(options.timeoutMs || 10000) || 10000, 15000)
  });
  if (!selected?.ok) {
    throw agentBridgeError(
      selected?.code || "AGENT_REF_EXISTING_UPLOAD_NOT_FOUND",
      `Flow Agent did not expose already-uploaded reference ${filename}; refusing to upload it twice.`,
      { filename, selected, state: selected?.state || null }
    );
  }
  const { addToPrompt, pickerClose } = await finalizeAgentRefAssetPickerSelection(target, filename, selected, {
    filename,
    existingBulkUpload: true
  });
  return { filename, reusedBulkUpload: true, selected, addToPrompt, pickerClose };
}

async function addAgentLocalFileRefToPrompt(target, filePath = "", options = {}) {
  const filename = agentRefFileBasename(filePath);
  await openAgentRefAssetPicker(target, { filename });
  await searchAgentRefAssetPicker(target, filename).catch(() => null);
  let selected = await selectAgentRefAssetPickerFile(target, filename, { timeoutMs: 1200 });
  let uploaded = false;
  let input = null;
  if (!selected.ok) {
    const upload = await clickAgentRefAssetPickerUpload(target);
    input = await markAgentRefFileInput(target, "asset_picker_upload");
    await debuggerSend(target, "DOM.setFileInputFiles", {
      objectId: input.objectId,
      files: [filePath]
    });
    uploaded = true;
    const uploadSelectTimeoutMs = Math.min(Number(options.timeoutMs || 15000) || 15000, 10000);
    selected = await selectAgentRefAssetPickerFileAfterUpload(target, filename, {
      timeoutMs: uploadSelectTimeoutMs
    });
    if (!selected.ok) {
      throw agentBridgeError(
        selected.code || "AGENT_REF_PICKER_FILE_NOT_FOUND",
        selected.message || `Flow Agent asset picker did not show uploaded file ${filename}.`,
        { filename, filePath, upload, input: input?.summary || null, lastState: selected.state || null }
      );
    }
  }
  const { addToPrompt, pickerClose } = await finalizeAgentRefAssetPickerSelection(target, filename, selected, {
    filename,
    filePath
  });
  await sleep(700);
  return { filename, uploaded, selected, addToPrompt, pickerClose, input: input?.summary || null };
}

async function addAgentExtensionBlobRefToPrompt(target, attachment = {}, options = {}) {
  const blob = attachment.blob || {};
  const filename = agentRefUniqueExtensionFileName(blob.fileName || attachment.fileName || "reference.png", attachment.blobStoreId);
  await openAgentRefAssetPicker(target, { filename });
  const upload = await clickAgentRefAssetPickerUpload(target);
  const input = await markAgentRefFileInput(target, "asset_picker_extension_blob");
  const delivered = await setAgentRefFileInputFromExtensionBlob(target, input, { ...blob, fileName: filename });
  const uploadSelectTimeoutMs = Math.min(Number(options.timeoutMs || 15000) || 15000, 12000);
  const selected = await selectAgentRefAssetPickerFileAfterUpload(target, filename, {
    timeoutMs: uploadSelectTimeoutMs
  });
  if (!selected.ok) {
    throw agentBridgeError(
      selected.code || "AGENT_REF_PICKER_FILE_NOT_FOUND",
      selected.message || `Flow Agent asset picker did not show extension reference ${filename}.`,
      { handle: attachment.handle, filename, upload, delivered, lastState: selected.state || null }
    );
  }
  const { addToPrompt, pickerClose } = await finalizeAgentRefAssetPickerSelection(target, filename, selected, {
    handle: attachment.handle,
    filename
  });
  await sleep(700);
  return { handle: attachment.handle, role: attachment.role, order: attachment.order, filename, uploaded: true, selected, addToPrompt, pickerClose, delivered };
}

function agentRefUniqueExtensionFileName(fileName = "reference.png", blobStoreId = "") {
  const original = agentRefFileBasename(fileName) || "reference.png";
  const dot = original.lastIndexOf(".");
  const stem = (dot > 0 ? original.slice(0, dot) : original).replace(/[^a-zA-Z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 72) || "reference";
  const extension = dot > 0 ? original.slice(dot).replace(/[^a-zA-Z0-9.]+/g, "") : ".png";
  const sourceToken = compactString(blobStoreId).replace(/[^a-zA-Z0-9]+/g, "").slice(-10) || hashCompactString(original).slice(0, 10);
  return `${stem}-af-${sourceToken}${extension || ".png"}`;
}

async function setAgentRefFileInputFromExtensionBlob(target, input = {}, blob = {}) {
  const base64 = base64FromDataUrl(blob.dataUrl || "");
  const estimatedBytes = Math.floor(base64.length * 0.75);
  if (!base64 || estimatedBytes > 16 * 1024 * 1024) {
    throw agentBridgeError(
      estimatedBytes > 16 * 1024 * 1024 ? "AGENT_REF_EXTENSION_BLOB_TOO_LARGE" : "AGENT_REF_EXTENSION_BLOB_MISSING",
      estimatedBytes > 16 * 1024 * 1024
        ? "Extension Agent references must be 16 MiB or smaller for programmatic attachment."
        : "Extension Agent reference bytes were unavailable.",
      { estimatedBytes, fileName: compactString(blob.fileName) }
    );
  }
  const result = await debuggerSend(target, "Runtime.callFunctionOn", {
    objectId: input.objectId,
    functionDeclaration: `function(base64, mimeType, fileName) {
      try {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
        const file = new File([bytes], fileName || "reference.png", { type: mimeType || "image/png" });
        const transfer = new DataTransfer();
        transfer.items.add(file);
        this.files = transfer.files;
        this.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        this.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
        return { ok: true, name: file.name, type: file.type, size: file.size, fileCount: this.files.length };
      } catch (error) {
        return { ok: false, error: String(error && error.message || error || "extension_blob_file_delivery_failed") };
      }
    }`,
    arguments: [
      { value: base64 },
      { value: compactString(blob.mimeType || mimeTypeFromDataUrl(blob.dataUrl) || "image/png") },
      { value: compactString(blob.fileName || "reference.png") }
    ],
    returnByValue: true,
    awaitPromise: false
  });
  const delivered = result?.result?.value || null;
  if (!delivered?.ok || delivered.fileCount !== 1) {
    throw agentBridgeError("AGENT_REF_FILE_INPUT_DELIVERY_FAILED", "Flow Agent reference bytes could not be delivered to the intercepted file input.", {
      delivered,
      input: input.summary || null
    });
  }
  return delivered;
}

async function addAgentFlowMediaRefToPrompt(target, attachment = {}, options = {}) {
  const mediaId = compactString(attachment.mediaId);
  const filename = compactString(attachment.fileName);
  if (!mediaId) throw agentBridgeError("MISSING_FLOW_MEDIA_ID", "Flow-generated Agent reference requires an exact media id.", { attachment });
  await openAgentRefAssetPicker(target, { filename: filename || mediaId });
  const videoReference = /^video\//i.test(compactString(attachment.mimeType))
    || /source video|video input/i.test(compactString(attachment.role))
    || /\.(?:mp4|mov|webm|mkv)$/i.test(filename);
  await switchAgentRefAssetPickerMediaCategory(target, videoReference
    ? ["Videos", "All Media", "All"]
    : ["Images", "All Media", "All"]).catch(() => null);
  const filenameStem = filename.replace(/\.[^.]+$/, "");
  const searchTerms = [filename, filenameStem, mediaId].filter((value, index, values) => value && values.indexOf(value) === index);
  let selected = await selectAgentRefAssetPickerMediaId(target, mediaId, {
    timeoutMs: Math.min(Number(options.timeoutMs || 15000) || 15000, 5000)
  });
  for (const searchTerm of selected.ok ? [] : searchTerms) {
    await searchAgentRefAssetPicker(target, searchTerm).catch(() => null);
    selected = await selectAgentRefAssetPickerMediaId(target, mediaId, { timeoutMs: Math.min(Number(options.timeoutMs || 15000) || 15000, 5000) });
    if (selected.ok) break;
  }
  if (!selected?.ok) {
    throw agentBridgeError(
      selected?.code || "AGENT_REF_FLOW_MEDIA_NOT_FOUND",
      `Flow Agent asset picker did not expose the exact requested media id ${mediaId}.`,
      { handle: attachment.handle, role: attachment.role, mediaId, fileName: filename, lastState: selected?.state || null }
    );
  }
  const addToPrompt = await clickAgentRefAssetPickerAddToPrompt(target, filename || mediaId, { exactSelectionVerified: true });
  if (!addToPrompt.ok) {
    throw agentBridgeError(
      addToPrompt.code || "AGENT_REF_ADD_TO_PROMPT_NOT_FOUND",
      addToPrompt.message || `Flow Agent asset picker could not add exact media ${mediaId} to the prompt.`,
      { handle: attachment.handle, role: attachment.role, mediaId, selected, state: addToPrompt.state || null }
    );
  }
  const pickerClose = await waitForAgentRefAssetPickerClosed(target, filename || mediaId);
  if (!pickerClose.closed) {
    throw agentBridgeError("AGENT_REF_PICKER_STILL_OPEN", "Flow Agent asset picker stayed open after adding exact Flow media.", {
      handle: attachment.handle,
      role: attachment.role,
      mediaId,
      selected,
      addToPrompt,
      state: pickerClose.state || null
    });
  }
  await sleep(700);
  return { handle: attachment.handle, role: attachment.role, order: attachment.order, mediaId, reusedFlowMedia: true, selected, addToPrompt, pickerClose };
}

async function selectAgentRefAssetPickerMediaId(target, mediaId = "", options = {}) {
  const timeoutMs = Math.min(Number(options.timeoutMs || 5000) || 5000, 15000);
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentRefAssetPickerMediaIdState(target, mediaId);
    if (state?.matchingOption?.rect) {
      if (state.matchingOption.selected === true) {
        return { ok: true, mediaId, option: state.matchingOption, skippedAlreadySelected: true, exactMediaIdMatch: true };
      }
      const optionClick = await clickAgentRefAssetPickerMediaIdOptionInPage(target, mediaId);
      if (!optionClick?.ok) {
        return {
          ok: false,
          code: optionClick?.code || "AGENT_REF_FLOW_MEDIA_SELECTION_UNVERIFIED",
          message: `Flow Agent could not activate exact media ${mediaId}.`,
          state,
          optionClick
        };
      }
      await sleep(450);
      const confirmed = await readAgentRefAssetPickerMediaIdState(target, mediaId);
      if (confirmed?.matchingOption?.selected !== true) {
        return {
          ok: false,
          code: "AGENT_REF_FLOW_MEDIA_SELECTION_UNVERIFIED",
          message: `Flow Agent did not confirm selection of exact media ${mediaId}.`,
          state: confirmed
        };
      }
      return { ok: true, mediaId, option: confirmed.matchingOption, exactMediaIdMatch: true };
    }
    await sleep(300);
  }
  return {
    ok: false,
    code: "AGENT_REF_FLOW_MEDIA_NOT_FOUND",
    message: `Flow Agent asset picker did not show exact media ${mediaId}.`,
    state
  };
}

async function clickAgentRefAssetPickerMediaIdOptionInPage(target, mediaId = "") {
  const expected = compactString(mediaId);
  return debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(expected)};
    const visible = (element) => {
      const rect = element?.getBoundingClientRect?.();
      const style = element ? getComputedStyle(element) : null;
      return Boolean(rect && rect.width > 0 && rect.height > 0 && style?.display !== "none" && style?.visibility !== "hidden");
    };
    const dialog = Array.from(document.querySelectorAll("[role='dialog'],[aria-modal='true']")).filter(visible)[0] || null;
    if (!dialog || !expected) return { ok: false, code: "AGENT_REF_PICKER_NOT_OPEN" };
    const evidence = (option) => Array.from(option.querySelectorAll("img,[src],[href]"))
      .flatMap((node) => {
        const values = [node.currentSrc, node.src, node.href];
        try { values.push(...Array.from(node.attributes || []).map((attribute) => attribute.value)); } catch {}
        return values;
      })
      .some((raw) => {
        const value = String(raw || "");
        let decoded = value;
        try { decoded = decodeURIComponent(value); } catch {}
        return value.includes(expected) || decoded.includes(expected);
      });
    const matches = Array.from(dialog.querySelectorAll("[role='option']")).filter(visible).filter(evidence);
    if (matches.length !== 1) return { ok: false, code: "AGENT_REF_FLOW_MEDIA_OPTION_NOT_UNIQUE", matchCount: matches.length };
    const option = matches[0];
    const beforeSelected = option.getAttribute("aria-selected") === "true";
    option.click();
    const rect = option.getBoundingClientRect();
    return {
      ok: true,
      method: "exact_media_id_guarded_dom_click",
      beforeSelected,
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
  })()`);
}

async function readAgentRefAssetPickerMediaIdState(target, mediaId = "") {
  const expected = compactString(mediaId);
  return await debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(expected)};
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom), area: Math.round(rect.width * rect.height) };
    };
    const allDeep = (selector, root = document) => {
      const out = [];
      const roots = [root];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const current = roots[index];
        if (!current || seen.has(current)) continue;
        seen.add(current);
        try {
          out.push(...Array.from(current.querySelectorAll(selector)));
          Array.from(current.querySelectorAll("*")).forEach((node) => { if (node.shadowRoot) roots.push(node.shadowRoot); });
        } catch {}
      }
      return out;
    };
    const exactEvidence = (element) => {
      const evidence = [];
      const nodes = [element, ...allDeep("*", element)].slice(0, 180);
      for (const node of nodes) {
        const tagName = String(node?.tagName || "").toLowerCase();
        const role = String(node?.getAttribute?.("role") || "").toLowerCase();
        if (tagName === "input" || tagName === "textarea" || tagName === "option" || role === "searchbox" || node?.isContentEditable === true) continue;
        const values = [];
        try { values.push(node.currentSrc, node.src, node.href); } catch {}
        try { for (const attribute of Array.from(node.attributes || [])) values.push(attribute.value); } catch {}
        for (const raw of values) {
          const value = String(raw || "");
          if (!value) continue;
          let decoded = value;
          try { decoded = decodeURIComponent(value); } catch {}
          if (value.includes(expected) || decoded.includes(expected)) evidence.push(value.slice(0, 240));
        }
      }
      return evidence;
    };
    const dialogs = allDeep("[role='dialog'],[aria-modal='true']").filter(visible).sort((left, right) => rectOf(right).area - rectOf(left).area);
    const dialog = dialogs[0] || null;
    if (!dialog || !expected) return { ok: true, open: Boolean(dialog), matchingOption: null };
    const dialogRect = rectOf(dialog);
    const matchedNodes = allDeep("img,[data-card-open],[role='option'],button,[role='button'],div", dialog)
      .filter(visible)
      .map((element) => ({ element, evidence: exactEvidence(element) }))
      .filter((entry) => entry.evidence.length > 0);
    const candidates = [];
    for (const match of matchedNodes) {
      let element = match.element;
      for (let depth = 0; element && element !== dialog && depth < 7; depth += 1, element = element.parentElement) {
        if (!visible(element)) continue;
        const rect = rectOf(element);
        const inside = rect.x >= dialogRect.x - 4 && rect.right <= dialogRect.right + 4 && rect.y >= dialogRect.y - 4 && rect.bottom <= dialogRect.bottom + 4;
        if (!inside || rect.area < 2500 || rect.area > 140000) continue;
        const role = String(element.getAttribute?.("role") || "");
        const selected = element.getAttribute?.("aria-selected") === "true" || element.getAttribute?.("aria-pressed") === "true" || /selected/i.test(String(element.className || ""));
        const imageCount = (() => { try { return element.querySelectorAll("img").length; } catch { return 0; } })();
        const interactive = role === "option" || role === "button" || String(element.tagName || "").toLowerCase() === "button" || element.hasAttribute?.("data-card-open");
        candidates.push({
          element,
          rect,
          role,
          selected,
          exactMediaIdMatch: true,
          evidenceCount: match.evidence.length,
          score: (interactive ? 100000 : 0) + (role === "option" ? 50000 : 0) + (imageCount ? 30000 : 0) + (selected ? 20000 : 0) - Math.abs(rect.area - 18000) - (depth * 1000)
        });
      }
    }
    candidates.sort((left, right) => right.score - left.score);
    const chosen = candidates[0] || null;
    return {
      ok: true,
      open: true,
      matchingOption: chosen ? {
        rect: chosen.rect,
        role: chosen.role,
        selected: chosen.selected,
        exactMediaIdMatch: true,
        evidenceCount: chosen.evidenceCount
      } : null,
      candidateCount: candidates.length,
      selectionSignal: chosen?.selected ? "exact_card_selected" : "none"
    };
  })()`);
}

async function selectAgentRefAssetPickerFileAfterUpload(target, filename = "", options = {}) {
  const timeoutMs = Math.min(Number(options.timeoutMs || 10000) || 10000, 15000);
  const deadline = Date.now() + timeoutMs;
  let last = null;
  let attempt = 0;
  while (Date.now() < deadline) {
    attempt += 1;
    await sleep(attempt === 1 ? 1800 : 650);
    await switchAgentRefAssetPickerSource(target, ["Uploads", "All", "Recent"]).catch(() => null);
    await switchAgentRefAssetPickerMediaCategory(target, ["Images", "All Media", "All"]).catch(() => null);
    await searchAgentRefAssetPicker(target, filename).catch(() => null);
    const remaining = Math.max(600, Math.min(1800, deadline - Date.now()));
    last = await selectAgentRefAssetPickerFile(target, filename, {
      timeoutMs: remaining
    });
    if (last?.ok) {
      return {
        ...last,
        postUploadSelection: {
          attempt,
          refreshedPicker: attempt > 1
        }
      };
    }
    await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 25 }).catch(() => null);
    await waitForAgentRefAssetPickerClosed(target, filename, { timeoutMs: 1200 }).catch(() => null);
    await openAgentRefAssetPicker(target, { filename }).catch((error) => {
      last = {
        ok: false,
        code: "AGENT_REF_PICKER_REOPEN_FAILED",
        message: String(error?.message || error || "Flow Agent asset picker could not reopen after upload."),
        previous: last
      };
    });
  }
  return last || {
    ok: false,
    code: "AGENT_REF_PICKER_FILE_NOT_FOUND",
    message: `Flow Agent asset picker did not show ${filename} after upload refresh.`
  };
}

async function readAgentModalSurfaceCensus(target) {
  const result = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const surfaces = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        return {
          role: element.getAttribute?.("role") || "",
          ariaModal: element.getAttribute?.("aria-modal") === "true",
          tag: String(element.tagName || "").toLowerCase(),
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
        };
      });
    return { ok: true, count: surfaces.length, surfaces: surfaces.slice(0, 8) };
  })()`).catch(() => null);
  if (result && result.ok === true) return result;
  return { ok: false, count: 0, surfaces: [] };
}

async function openAgentRefAssetPicker(target, options = {}) {
  const existing = await readAgentRefAssetPickerState(target, options.filename || "");
  if (existing.open) return { ok: true, opened: false, state: existing };

  const startedAt = Date.now();
  const timeoutMs = Math.min(Number(options.openTimeoutMs || 12000) || 12000, 25000);
  const maxAttempts = Math.max(1, Math.min(Number(options.openAttempts || 3) || 3, 5));
  const attempts = [];
  let recoveredComposer = null;
  let addButton = null;
  let addButtonLookupFailure = null;
  let baselineModalCensus = null;
  let state = existing;
  for (let attempt = 1; attempt <= maxAttempts && Date.now() - startedAt < timeoutMs; attempt += 1) {
    state = await readAgentRefAssetPickerState(target, options.filename || "").catch(() => state);
    if (state?.open) {
      return { ok: true, opened: attempt > 1, state, addButton, attempts };
    }
    recoveredComposer = await ensureAgentRefProjectComposerWithDebugger(target).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "agent_ref_project_composer_recovery_failed")
    }));
    const lookup = await findAgentRefComposerAddButton(target);
    if (!lookup?.ok || !lookup.rect) {
      addButtonLookupFailure = lookup;
      break;
    }
    addButton = lookup;
    if (attempts.length === 0) {
      baselineModalCensus = await readAgentModalSurfaceCensus(target);
    } else if (baselineModalCensus?.ok) {
      const modalCensus = await readAgentModalSurfaceCensus(target);
      if (modalCensus.ok && modalCensus.count > baselineModalCensus.count) {
        throw agentBridgeError(
          "AGENT_REF_ASSET_PICKER_NOT_OPEN",
          "A dialog appeared after the composer add click but was not recognized as the asset picker; refusing to click again.",
          {
            addButton,
            state,
            attempts,
            timeoutMs,
            maxAttempts,
            unrecognizedDialogAppeared: true,
            baselineModalCensus,
            modalCensus
          }
        );
      }
    }
    attempts.push({
      attempt,
      addButton: {
        text: compactString(addButton.text).slice(0, 80),
        rect: addButton.rect
      },
      state: {
        open: Boolean(state?.open),
        dialog: state?.dialog ? { text: compactString(state.dialog.text).slice(0, 120), rect: state.dialog.rect, role: state.dialog.role || "" } : null
      }
    });
    let addClick;
    try {
      addClick = await clickAgentRefComposerAddButtonInPage(target, addButton);
      if (addClick.method !== "guarded_dom_click") await debuggerClick(target, pointFromRect(addClick.rect));
      if (addClick.pickerOpen === true) {
        state = await readAgentRefAssetPickerState(target, options.filename || "").catch(() => ({ ok: true, open: true }));
        return { ok: true, opened: true, state: state?.open ? state : { ok: true, open: true, proof: "guarded_dom_click_dialog" }, addButton, attempts };
      }
    } catch (error) {
      addClick = {
        ok: false,
        code: compactString(error?.code || "AGENT_REF_ADD_BUTTON_CHANGED"),
        message: compactString(error?.message || error || "agent_ref_add_click_failed")
      };
      attempts[attempts.length - 1].addClick = addClick;
      addButtonLookupFailure = addClick;
      await sleep(300);
      continue;
    }
    attempts[attempts.length - 1].addClick = addClick;
    const attemptsLeft = maxAttempts - attempt + 1;
    const remainingMs = Math.max(0, startedAt + timeoutMs - Date.now());
    const attemptWindowMs = Math.max(1500, Math.floor(remainingMs / attemptsLeft));
    const perAttemptDeadline = Math.min(startedAt + timeoutMs, Date.now() + attemptWindowMs);
    while (Date.now() < perAttemptDeadline) {
      await sleep(attempt === 1 ? 220 : 360);
      state = await readAgentRefAssetPickerState(target, options.filename || "").catch(() => state);
      if (state?.open) return { ok: true, opened: true, state, addButton, attempts };
    }
  }
  if (!addButton && attempts.length === 0) {
    throw agentBridgeError(
      "AGENT_COMPOSER_ADD_CONTROL_MISSING",
      addButtonLookupFailure?.message || "Flow Agent composer add button was not found.",
      {
        ...(addButtonLookupFailure || {}),
        originalCode: addButtonLookupFailure?.code || "AGENT_REF_ADD_BUTTON_NOT_FOUND",
        composerDetected: recoveredComposer?.ok === true,
        addRefCandidates: Array.isArray(addButtonLookupFailure?.candidates) ? addButtonLookupFailure.candidates : [],
        recoveredComposer,
        attempts,
        state
      }
    );
  }
  throw agentBridgeError(
    "AGENT_REF_ASSET_PICKER_NOT_OPEN",
    "Flow Agent asset picker did not open after clicking the composer add button.",
    { addButton, addButtonLookupFailure, state, attempts, timeoutMs, maxAttempts }
  );
}

async function ensureAgentRefProjectComposerWithDebugger(target, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 16000) || 16000;
  let state = await readAgentRefProjectComposerState(target).catch((error) => ({
    ok: false,
    error: String(error?.message || error || "agent_ref_project_composer_state_failed")
  }));
  if (state?.ok === true) return state;

  // Settings can return Flow to the centered compact composer after the
  // earlier surface normalization opened the conversation drawer. Reopen the
  // drawer before considering a project navigation: the exact centered
  // `expand_content` control is safe navigation evidence, while reloading here
  // would needlessly discard transient composer state.
  const conversationPanel = await readAgentConversationPanelState(target).catch(() => null);
  if (conversationPanel?.panelOpen !== true && conversationPanel?.triggerRect) {
    const reopenedPanel = await ensureAgentConversationPanelOpen(target, {
      stage: "reference_attach_recovery"
    }).catch((error) => ({
      panelOpen: false,
      error: String(error?.message || error || "agent_conversation_panel_reopen_failed")
    }));
    if (reopenedPanel?.panelOpen === true) {
      state = await readAgentRefProjectComposerState(target).catch((error) => ({
        ok: false,
        error: String(error?.message || error || "agent_ref_project_composer_state_failed")
      }));
      if (state?.ok === true) {
        return { ...state, recovered: true, conversationPanelReopened: true };
      }
    }
  }

  const projectId = compactString(state?.projectId || projectIdFromUrl(state?.href || ""));
  if (projectId) {
    await debuggerSend(target, "Page.enable").catch(() => {});
    await debuggerSend(target, "Page.navigate", {
      url: agentBridgeProjectRootUrl(state?.href || "", projectId)
    }).catch((error) => {
      state = {
        ...state,
        navigationError: String(error?.message || error || "page_navigate_failed")
      };
    });
  }
  const deadline = Date.now() + timeoutMs;
  let last = state;
  while (Date.now() < deadline) {
    await sleep(400);
    last = await readAgentRefProjectComposerState(target).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "agent_ref_project_composer_state_failed")
    }));
    if (last?.ok === true) return { ...last, recovered: true };
  }
  return {
    ok: false,
    code: "AGENT_REF_COMPOSER_NOT_READY",
    message: "Flow Agent project composer was not ready for reference attachment.",
    last
  };
}

async function readAgentRefProjectComposerState(target) {
  return await debuggerEvaluate(target, `(() => {
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const materialIconTokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const href = String(location.href || "");
    const projectMatch = href.match(/\\/project\\/([^/?#]+)/);
    const editRoute = /\\/project\\/[^/]+\\/edit\\//i.test(href);
    const scoredCandidates = allDeep("button,[role='button'],label")
      .filter(visible)
      .map((button) => {
        const icons = materialIconTokens(button);
        const text = textOf(button);
        const rect = button.getBoundingClientRect();
        const rawText = String(button?.textContent || "");
        const tagName = String(button?.tagName || "").toLowerCase();
        const compactControl = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
        const composerAddIcon = icons.has("add_2") || /add_2/i.test(rawText) || (icons.has("add") && !/arrow_forward|article_spark|tune|settings/i.test(rawText));
        const addLike = composerAddIcon || icons.has("add_photo_alternate") || /add_photo_alternate|\\b(add|attach|upload)\\b/i.test(text);
        const blockedAction = icons.has("arrow_forward") || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(rawText) || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(text);
        const className = String(button?.className?.baseVal || button?.className || "");
        const iconOnlySubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
          || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
        const sendLike = blockedAction || iconOnlySubmit || /\\b(send|submit|generate)\\b/i.test(text) || (!composerAddIcon && /\\bcreate\\b/i.test(text));
        const composerZone = rect.right > window.innerWidth * 0.65 && rect.bottom > window.innerHeight * 0.72;
        return {
          text,
          tagName,
          composerAddIcon,
          compactControl,
          addLike,
          sendLike,
          composerZone,
          rect: rectOf(button),
          score: (composerAddIcon ? 20000 : 0) + (addLike ? 5000 : -5000) + (composerZone ? 5000 : -5000) + (tagName === "button" ? 3000 : 0) + (compactControl ? 3000 : -8000) + (window.innerWidth - rect.x) - Math.abs(rect.width - 32)
        };
      })
      .sort((left, right) => right.score - left.score);
    const candidates = scoredCandidates
      .filter((entry) => entry.composerAddIcon && entry.addLike && !entry.sendLike && entry.composerZone && entry.compactControl)
      .sort((left, right) => right.score - left.score);
    const addButton = candidates[0] || null;
    return {
      ok: Boolean(!editRoute && addButton),
      href,
      projectId: projectMatch?.[1] || "",
      editRoute,
      addButton,
      sampleButtons: candidates.slice(0, 3),
      addRefCandidates: scoredCandidates.slice(0, 8)
    };
  })()`);
}

async function findAgentRefComposerAddButton(target) {
  return await debuggerEvaluate(target, `(() => {
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const materialIconTokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const scoredCandidates = allDeep("button,[role='button'],label")
      .filter(visible)
      .map((button) => {
        const icons = materialIconTokens(button);
        const text = textOf(button);
        const rect = button.getBoundingClientRect();
        const rawText = String(button?.textContent || "");
        const tagName = String(button?.tagName || "").toLowerCase();
        const compactControl = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
        const composerAddIcon = icons.has("add_2") || /add_2/i.test(rawText) || (icons.has("add") && !/arrow_forward|article_spark|tune|settings/i.test(rawText));
        const addLike = composerAddIcon || icons.has("add_photo_alternate") || /add_photo_alternate|\\b(add|attach|upload)\\b/i.test(text);
        const blockedAction = icons.has("arrow_forward") || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(rawText) || /arrow_forward|article_spark|tune|settings|agent instructions|clear prompt/i.test(text);
        const className = String(button?.className?.baseVal || button?.className || "");
        const iconOnlySubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
          || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
        const sendLike = blockedAction || iconOnlySubmit || /\\b(send|submit|generate)\\b/i.test(text) || (!composerAddIcon && /\\bcreate\\b/i.test(text));
        const composerZone = (rect.right > window.innerWidth * 0.65 || (
          rect.x >= window.innerWidth * 0.25
          && rect.right <= window.innerWidth * 0.75
        )) && rect.bottom > window.innerHeight * 0.72;
        return {
          ok: true,
          tagName,
          composerAddIcon,
          compactControl,
          addLike,
          sendLike,
          composerZone,
          text,
          rect: rectOf(button),
          score: (composerAddIcon ? 20000 : 0) + (addLike ? 5000 : -5000) + (composerZone ? 5000 : -5000) + (tagName === "button" ? 3000 : 0) + (compactControl ? 3000 : -8000) + (window.innerWidth - rect.x) - Math.abs(rect.width - 32)
        };
      })
      .sort((left, right) => right.score - left.score);
    const candidates = scoredCandidates
      .filter((entry) => entry.composerAddIcon && entry.addLike && !entry.sendLike && entry.composerZone && entry.compactControl)
      .sort((left, right) => right.score - left.score);
    return candidates[0] || {
      ok: false,
      code: "AGENT_REF_ADD_BUTTON_NOT_FOUND",
      message: "Flow Agent composer add button was not found.",
      candidates: scoredCandidates.slice(0, 8)
    };
  })()`);
}

async function clickAgentRefComposerAddButtonInPage(target, expected = {}) {
  const expectedRect = expected?.rect || {};
  const result = await debuggerEvaluate(target, `(() => {
    const expectedRect = ${JSON.stringify(expectedRect)};
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => { if (node.shadowRoot) roots.push(node.shadowRoot); });
        } catch {}
      }
      return out;
    };
    const candidates = allDeep("button,[role='button']")
      .filter(visible)
      .map((element) => {
        const rect = rectOf(element);
        const rawText = String(element.textContent || "");
        const compact = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
        const addIcon = /add_2/i.test(rawText);
        const composerZone = (rect.right > window.innerWidth * 0.65 || (
          rect.x >= window.innerWidth * 0.25
          && rect.right <= window.innerWidth * 0.75
        )) && rect.bottom > window.innerHeight * 0.72;
        const expectedX = Number(expectedRect.x || 0);
        const expectedRight = Number(expectedRect.right || 0) || (expectedX + Number(expectedRect.width || 0));
        const expectedComposerZone = expectedRight > window.innerWidth * 0.65 || (
          expectedX >= window.innerWidth * 0.25
          && expectedRight <= window.innerWidth * 0.75
        );
        const sameShape = Math.abs(rect.width - Number(expectedRect.width || 0)) <= 4
          && Math.abs(rect.height - Number(expectedRect.height || 0)) <= 4;
        const center = document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2);
        const hitTestable = center === element || element.contains(center);
        return {
          element,
          rect,
          addIcon,
          compact,
          composerZone,
          expectedComposerZone,
          sameShape,
          hitTestable,
          distance: Math.abs(rect.x - Number(expectedRect.x || 0))
        };
      })
      .filter((entry) => entry.addIcon && entry.compact && entry.composerZone && entry.expectedComposerZone && entry.sameShape && entry.hitTestable)
      .sort((left, right) => left.distance - right.distance);
    if (candidates.length !== 1 || typeof candidates[0].element?.click !== "function") {
      return { ok: false, code: "AGENT_REF_ADD_BUTTON_CHANGED", candidateCount: candidates.length };
    }
    const candidate = candidates[0];
    candidate.element.click();
    return new Promise((resolve) => setTimeout(() => {
      const pickerOpen = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
        .filter(visible)
        .some((dialog) => /add to prompt|upload media/i.test(String(dialog.innerText || dialog.textContent || "")));
      resolve({ ok: true, rect: candidate.rect, method: "guarded_dom_click", pickerOpen });
    }, 500));
  })()`);
  if (!result?.ok) {
    throw agentBridgeError(
      result?.code || "AGENT_REF_ADD_BUTTON_CHANGED",
      "Flow Agent composer add control changed before it could be clicked.",
      { expected: expectedRect, result }
    );
  }
  return result;
}

async function searchAgentRefAssetPicker(target, filename = "") {
  const value = compactString(filename);
  if (!value) return { ok: false, skipped: true, reason: "empty_filename" };
  const result = await debuggerEvaluate(target, `(() => {
    const value = ${JSON.stringify(value)};
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("placeholder") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom), area: Math.round(rect.width * rect.height) };
    };
    const pickerSurface = (entry) => {
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
      const notWholePage = entry.rect.area > 25000 && entry.rect.area < viewportArea * 0.92;
      const compactText = String(entry.text || "").length < 1400;
      return modalLike || (notWholePage && compactText);
    };
    const inside = (rect, container) => Boolean(container) && (
      rect.x >= container.x - 4
      && rect.right <= container.right + 4
      && rect.y >= container.y - 4
      && rect.bottom <= container.bottom + 4
    );
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const setNativeValue = (element, nextValue) => {
      const tag = String(element?.tagName || "").toLowerCase();
      if (element?.isContentEditable) {
        element.focus();
        element.textContent = nextValue;
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: nextValue }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
      if (tag !== "input" && tag !== "textarea") return false;
      const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      element.focus();
      if (setter) setter.call(element, nextValue);
      else element.value = nextValue;
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: nextValue }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    };
    const dialogs = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
      .filter(visible)
      .map((element) => ({ element, text: textOf(element), rect: rectOf(element), role: element.getAttribute?.("role") || "" }))
      .filter((entry) => {
        const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
        const structuralPicker = Boolean(entry.element?.querySelector?.("[role='tablist']")
          && entry.element?.querySelector?.("input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only']"));
        if (modalLike && structuralPicker) return true;
        if (entry.role === "dialog" && /add to prompt|upload media|recent|uploads|images|search/i.test(entry.text)) return true;
        return pickerSurface(entry) && /add to prompt|upload media|search/i.test(entry.text);
      })
      .sort((left, right) => ((right.role === "dialog" ? 1000000 : 0) + right.rect.area) - ((left.role === "dialog" ? 1000000 : 0) + left.rect.area));
    const dialog = dialogs[0] || null;
    const dialogRect = dialog?.rect || null;
    if (!dialogRect) return { ok: false, code: "AGENT_REF_PICKER_SEARCH_NOT_FOUND", dialog: null };
    const belongsToDialog = (element) => {
      let current = element;
      while (current) {
        if (current === dialog.element) return true;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return false;
    };
    const candidates = allDeep("input[type='search'],input,textarea,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only']")
      .filter(visible)
      .filter(belongsToDialog)
      .map((element) => {
        const rect = rectOf(element);
        const label = textOf(element);
        const type = String(element.getAttribute?.("type") || "").toLowerCase();
        const searchLike = type === "search" || /search|find|asset|media/i.test(label);
        return { element, rect, label, type, score: (searchLike ? 10000 : 0) - rect.area - rect.y };
      })
      .filter((entry) => inside(entry.rect, dialogRect))
      .sort((left, right) => right.score - left.score);
    const target = candidates[0]?.element || null;
    if (!target) return { ok: false, code: "AGENT_REF_PICKER_SEARCH_NOT_FOUND", dialog: dialog ? { text: dialog.text.slice(0, 220), rect: dialog.rect, role: dialog.role } : null };
    const changed = setNativeValue(target, value);
    return {
      ok: changed,
      code: changed ? undefined : "AGENT_REF_PICKER_SEARCH_NOT_WRITABLE",
      search: candidates[0] ? { label: candidates[0].label, type: candidates[0].type, rect: candidates[0].rect } : null
    };
  })()`);
  if (result?.ok) await sleep(450);
  return result;
}

async function switchAgentRefAssetPickerSource(target, preferredSources = []) {
  const sources = preferredSources.map(compactString).filter(Boolean);
  const result = await debuggerEvaluate(target, `(() => new Promise((resolve) => {
    const preferredSources = ${JSON.stringify(sources.length ? sources : ["Uploads", "All"])};
    const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom), area: Math.round(rect.width * rect.height) };
    };
    const pickerSurface = (entry) => {
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
      const notWholePage = entry.rect.area > 25000 && entry.rect.area < viewportArea * 0.92;
      const compactText = String(entry.text || "").length < 1400;
      return modalLike || (notWholePage && compactText);
    };
    const inside = (rect, container) => !container || (
      rect.x >= container.x - 4
      && rect.right <= container.right + 4
      && rect.y >= container.y - 4
      && rect.bottom <= container.bottom + 4
    );
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const click = (element) => {
      if (!element) return false;
      try { element.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch {}
      try { element.click(); return true; } catch {}
      return false;
    };
    const dialog = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
      .filter(visible)
      .map((element) => ({ element, text: textOf(element), rect: rectOf(element), role: element.getAttribute?.("role") || "" }))
      .filter((entry) => {
        const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
        const structuralPicker = Boolean(entry.element?.querySelector?.("[role='tablist']")
          && entry.element?.querySelector?.("input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only']"));
        if (modalLike && structuralPicker) return true;
        if (entry.role === "dialog" && /add to prompt|recent|uploads|images|upload media/i.test(entry.text)) return true;
        return pickerSurface(entry) && /add to prompt|upload media/i.test(entry.text);
      })
      .sort((left, right) => ((right.role === "dialog" ? 1000000 : 0) + right.rect.area) - ((left.role === "dialog" ? 1000000 : 0) + left.rect.area))[0] || null;
    const dialogRect = dialog?.rect || null;
    if (!dialogRect) return resolve({ ok: false, code: "AGENT_REF_PICKER_SOURCE_BUTTON_NOT_FOUND", dialog: null });
    const sourceButton = allDeep("button,[role='button']")
      .filter(visible)
      .map((element) => {
        const rect = rectOf(element);
        const text = textOf(element);
        const sourceLike = /\\b(recent|uploads?|all)\\b/i.test(text) || /arrow_drop_down/i.test(text);
        const topHalf = dialogRect ? rect.y <= dialogRect.y + (dialogRect.height * 0.45) : true;
        const rightSide = dialogRect ? rect.x >= dialogRect.x + (dialogRect.width * 0.45) : true;
        const categoryLike = /^\\s*(all media|all|images?|videos?|voices?|characters?)\\s*$/i.test(text);
        return {
          element,
          text,
          rect,
          score: (sourceLike ? 10000 : -10000) + (topHalf ? 2000 : -2000) + (rightSide ? 6000 : -6000) + (categoryLike ? -8000 : 0) - rect.area
        };
      })
      .filter((entry) => inside(entry.rect, dialogRect) && entry.score > 0)
      .sort((left, right) => right.score - left.score)[0] || null;
    if (!sourceButton || !click(sourceButton.element)) {
      return resolve({ ok: false, code: "AGENT_REF_PICKER_SOURCE_BUTTON_NOT_FOUND", dialog: dialog ? { text: dialog.text.slice(0, 220), rect: dialog.rect, role: dialog.role } : null });
    }
    (async () => {
      await sleep(300);
      const normalizedSources = preferredSources.map((source) => String(source || "").toLowerCase().trim()).filter(Boolean);
      const sourceMatches = (text) => {
        const value = String(text || "").toLowerCase().trim();
        return normalizedSources.some((source) => value.includes(source));
      };
      const sourceExact = (text) => {
        const value = String(text || "").toLowerCase().trim();
        return normalizedSources.some((source) => value === source);
      };
      const option = allDeep("[role='option'],[role='menuitem'],button,[role='button'],mat-option,div")
        .filter(visible)
        .map((element) => ({ element, text: textOf(element), rect: rectOf(element), role: element.getAttribute?.("role") || "" }))
        .filter((entry) => sourceMatches(entry.text))
        .sort((left, right) => {
          const leftExact = sourceExact(left.text) ? 100000 : 0;
          const rightExact = sourceExact(right.text) ? 100000 : 0;
          return (rightExact - right.rect.area - right.rect.y) - (leftExact - left.rect.area - left.rect.y);
        })[0] || null;
      if (!option || !click(option.element)) {
        return resolve({ ok: false, code: "AGENT_REF_PICKER_SOURCE_OPTION_NOT_FOUND", sourceButton: { text: sourceButton.text, rect: sourceButton.rect } });
      }
      await sleep(450);
      resolve({ ok: true, sourceButton: { text: sourceButton.text, rect: sourceButton.rect }, option: { text: option.text, rect: option.rect, role: option.role } });
    })();
  }))()`);
  if (result?.ok) await sleep(450);
  return result;
}

async function switchAgentRefAssetPickerMediaCategory(target, preferredCategories = []) {
  const categories = preferredCategories.map(compactString).filter(Boolean);
  const result = await debuggerEvaluate(target, `(() => {
    const preferredCategories = ${JSON.stringify(categories.length ? categories : ["Images", "All Media", "All"])};
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim().toLowerCase();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom), area: Math.round(rect.width * rect.height) };
    };
    const pickerSurface = (entry) => {
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
      const notWholePage = entry.rect.area > 25000 && entry.rect.area < viewportArea * 0.92;
      const compactText = String(entry.text || "").length < 1400;
      return modalLike || (notWholePage && compactText);
    };
    const inside = (rect, container) => !container || (
      rect.x >= container.x - 4
      && rect.right <= container.right + 4
      && rect.y >= container.y - 4
      && rect.bottom <= container.bottom + 4
    );
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const click = (element) => {
      if (!element) return false;
      try { element.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch {}
      try { element.click(); return true; } catch {}
      return false;
    };
    const dialog = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
      .filter(visible)
      .map((element) => ({ element, text: textOf(element), rect: rectOf(element), role: element.getAttribute?.("role") || "" }))
      .filter((entry) => {
        const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
        const structuralPicker = Boolean(entry.element?.querySelector?.("[role='tablist']")
          && entry.element?.querySelector?.("input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only']"));
        if (modalLike && structuralPicker) return true;
        if (entry.role === "dialog" && /add to prompt|upload media|recent|uploads|images|videos|characters/i.test(entry.text)) return true;
        return pickerSurface(entry) && /add to prompt|upload media/i.test(entry.text);
      })
      .sort((left, right) => ((right.role === "dialog" ? 1000000 : 0) + right.rect.area) - ((left.role === "dialog" ? 1000000 : 0) + left.rect.area))[0] || null;
    const dialogRect = dialog?.rect || null;
    if (!dialogRect) return { ok: false, code: "AGENT_REF_PICKER_MEDIA_CATEGORY_NOT_FOUND", dialog: null };
    const normalizedCategories = preferredCategories.map(normalize).filter(Boolean);
    const categoryIndex = (text) => {
      const value = normalize(text);
      return normalizedCategories.findIndex((category) => {
        if (value === category || value === category + " selected") return true;
        if (/^images?$/.test(category)) return /(^|\\s)(view\\s+)?images?(\\s|$)/.test(value);
        if (category === "all media") return /(^|\\s)(view\\s+)?all\\s+media(\\s|$)/.test(value);
        if (category === "all") return /^all$/.test(value) || /(^|\\s)view\\s+all(\\s|$)/.test(value);
        return false;
      });
    };
    const categoryCandidates = allDeep("button,[role='button'],[role='tab'],label,div,span")
      .filter(visible)
      .map((element) => {
        const rect = rectOf(element);
        const text = textOf(element);
        const index = categoryIndex(text);
        const selected = element.getAttribute?.("aria-selected") === "true"
          || element.getAttribute?.("aria-pressed") === "true"
          || element.className?.toString?.().includes("selected");
        const leftRail = dialogRect ? rect.x <= dialogRect.x + (dialogRect.width * 0.42) : true;
        const categoryTab = /tab/i.test(element.getAttribute?.("role") || "");
        const compact = rect.area <= 70000;
        const interactive = /^(button|label)$/i.test(String(element.tagName || "")) || /button|tab/i.test(element.getAttribute?.("role") || "");
        return {
          element,
          text,
          rect,
          selected,
          leftRail,
          score: (index >= 0 ? 200000 - (index * 10000) : -200000)
            + (leftRail ? 50000 : -50000)
            + (categoryTab ? 45000 : 0)
            + (compact ? 12000 : -12000)
            + (interactive ? 8000 : 0)
            + (selected ? 4000 : 0)
            - rect.area
            - rect.y
        };
      })
      .filter((entry) => inside(entry.rect, dialogRect) && categoryIndex(entry.text) >= 0 && (entry.leftRail || /tab/i.test(entry.element?.getAttribute?.("role") || "")))
      .sort((left, right) => right.score - left.score);
    const category = categoryCandidates[0] || null;
    if (!category) {
      return { ok: false, code: "AGENT_REF_PICKER_MEDIA_CATEGORY_NOT_FOUND", dialog: dialog ? { text: dialog.text.slice(0, 220), rect: dialog.rect, role: dialog.role } : null };
    }
    if (category.selected) {
      return { ok: true, alreadySelected: true, category: { text: category.text, rect: category.rect, selected: true } };
    }
    if (!click(category.element)) {
      return { ok: false, code: "AGENT_REF_PICKER_MEDIA_CATEGORY_CLICK_FAILED", category: { text: category.text, rect: category.rect } };
    }
    return { ok: true, category: { text: category.text, rect: category.rect, selected: category.selected } };
  })()`);
  if (result?.ok) await sleep(450);
  return result;
}

async function readAgentRefAssetPickerState(target, filename = "") {
  const expected = JSON.stringify(compactString(filename).toLowerCase());
  return await debuggerEvaluate(target, `(() => {
    const expected = ${expected};
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom), area: Math.round(rect.width * rect.height) };
    };
    const pickerSurface = (entry) => {
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
      const notWholePage = entry.rect.area > 25000 && entry.rect.area < viewportArea * 0.92;
      const compactText = String(entry.text || "").length < 1400;
      return modalLike || (notWholePage && compactText);
    };
    const inside = (rect, container) => !container || (
      rect.x >= container.x - 4
      && rect.right <= container.right + 4
      && rect.y >= container.y - 4
      && rect.bottom <= container.bottom + 4
    );
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const dialogs = allDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container")
      .filter(visible)
      .map((element) => ({ element, text: textOf(element), rect: rectOf(element), role: element.getAttribute?.("role") || "" }))
      .filter((entry) => {
        const strongToken = /add to prompt|upload media/i.test(entry.text);
        const categoryHits = new Set(
          (entry.text.match(/\\b(recent|uploads|images|all media|search)\\b/gi) || []).map((token) => token.toLowerCase())
        ).size;
        const modalLike = entry.role === "dialog" || entry.element?.getAttribute?.("aria-modal") === "true";
        const structuralPicker = Boolean(entry.element?.querySelector?.("[role='tablist']")
          && entry.element?.querySelector?.("input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only']"));
        if (modalLike) return structuralPicker || strongToken || categoryHits >= 2;
        return pickerSurface(entry) && (strongToken || categoryHits >= 2);
      })
      .sort((left, right) => {
        const leftScore = (left.role === "dialog" ? 1000000 : 0) + left.rect.area;
        const rightScore = (right.role === "dialog" ? 1000000 : 0) + right.rect.area;
        return rightScore - leftScore;
      });
    const dialog = dialogs[0] || null;
    const dialogRect = dialog?.rect || null;
    const insidePickerColumn = (rect) => inside(rect, dialogRect) || (dialogRect && (
      rect.x >= dialogRect.x - 4
      && rect.right <= dialogRect.right + 4
      && rect.y >= dialogRect.y - 4
      && rect.y <= dialogRect.bottom + 260
    ));
    const controls = allDeep("button,[role='button'],label,[role='menuitem'],[role='option'],[role='tab'],div,span")
      .filter(visible)
      .map((element) => ({
        text: textOf(element),
        rect: rectOf(element),
        role: element.getAttribute?.("role") || "",
        tag: String(element.tagName || "").toLowerCase(),
        selected: element.getAttribute?.("aria-selected") === "true"
          || element.getAttribute?.("aria-pressed") === "true"
          || element.className?.toString?.().includes("selected"),
        disabled: Boolean(element.disabled || element.getAttribute?.("aria-disabled") === "true")
      }))
      .filter((entry) => insidePickerColumn(entry.rect));
    const buttonLike = controls.filter((entry) => /^(button|label)$/i.test(entry.tag) || /button|menuitem|option|tab/i.test(entry.role));
    const mediaCategory = controls
      .filter((entry) => /^\\s*(all media|all|images?|videos?|voices?|characters?)\\s*$/i.test(entry.text))
      .map((entry) => {
        const leftRail = dialogRect ? entry.rect.x <= dialogRect.x + (dialogRect.width * 0.42) : true;
        const selected = entry.role === "tab" && entry.selected === true;
        const categoryRank = /images?/i.test(entry.text) ? 50000 : /all media|^\\s*all\\s*$/i.test(entry.text) ? 30000 : /videos?/i.test(entry.text) ? 10000 : 0;
        return {
          ...entry,
          leftRail,
          selected,
          score: categoryRank + (leftRail ? 20000 : -20000) + (selected ? 100000 : 0) - entry.rect.area - entry.rect.y
        };
      })
      .filter((entry) => entry.leftRail)
      .sort((left, right) => right.score - left.score)[0] || null;
    const uploadMedia = controls
      .filter((entry) => /\\bupload media\\b/i.test(entry.text) || /(^|\\s)upload(\\s|$)/i.test(entry.text))
      .filter((entry) => !/^uploads?$/i.test(entry.text))
      .map((entry) => {
        const exact = /^upload media$/i.test(entry.text);
        const iconLabel = /^upload\\s+upload media$/i.test(entry.text);
        const phrase = /\\bupload media\\b/i.test(entry.text);
        const compact = entry.rect.area <= 30000;
        const rowLike = entry.rect.area <= 90000 && dialogRect && entry.rect.x <= dialogRect.x + (dialogRect.width * 0.42);
        const interactive = /^(button|label)$/i.test(entry.tag) || /button|menuitem|option|tab/i.test(entry.role);
        const aggregatePickerText = /dashboard\\s+all|image\\s+images|videocam\\s+videos|voice_selection\\s+voices|drive_folder_upload\\s+uploads/i.test(entry.text);
        return {
          ...entry,
          aggregatePickerText,
          score: (exact ? 100000 : 0)
            + (iconLabel ? 90000 : 0)
            + (phrase ? 50000 : 0)
            + (interactive ? 50000 : -50000)
            + (rowLike ? 30000 : 0)
            + (compact ? 5000 : -5000)
            + (aggregatePickerText ? -150000 : 0)
            - entry.rect.area
            - entry.rect.y
        };
      })
      .filter((entry) => !entry.aggregatePickerText && (/^(button|label)$/i.test(entry.tag) || /button|menuitem|option|tab/i.test(entry.role) || entry.rect.area <= 12000 || /^upload\\s+upload media$/i.test(entry.text)))
      .sort((left, right) => right.score - left.score)[0] || null;
    const options = allDeep("[role='option'],button,[role='button'],div")
      .filter(visible)
      .map((element) => ({
        text: textOf(element),
        rect: rectOf(element),
        role: element.getAttribute?.("role") || "",
        selected: element.getAttribute?.("aria-selected") === "true" || element.className?.toString?.().includes("selected")
      }))
      .filter((entry) => inside(entry.rect, dialogRect))
      .filter((entry) => expected && entry.text.toLowerCase().includes(expected))
      .filter((entry) => /image|jpg|jpeg|png|webp/i.test(entry.text))
      .sort((left, right) => {
        const score = (entry) => {
          const area = Number(entry.rect.area || 0);
          const cardLike = area >= 6000 && area <= 80000;
          const tooTiny = area < 4000;
          const expectedMedia = /image|jpg|jpeg|png|webp/i.test(entry.text);
          return (entry.role === "option" ? 100000 : 0)
            + (entry.selected ? 200000 : 0)
            + (cardLike ? 50000 : 0)
            + (expectedMedia ? 20000 : 0)
            + (tooTiny ? -50000 : 0)
            - Math.round(Math.abs(area - 12000) / 10)
            - entry.rect.y;
        };
        return score(right) - score(left);
      });
    const matchingImage = allDeep("img")
      .filter(visible)
      .map((element) => ({
        text: textOf(element),
        alt: String(element.getAttribute?.("alt") || "").trim(),
        rect: rectOf(element)
      }))
      .filter((entry) => inside(entry.rect, dialogRect))
      .find((entry) => expected && entry.alt.toLowerCase() === expected) || null;
    const hasSelectedOption = options.some((entry) => entry.selected);
    const structuralFooterAction = hasSelectedOption && dialogRect
      ? buttonLike.find((entry) => !entry.disabled
        && entry.tag === "button"
        && entry.rect.width >= dialogRect.width * 0.25
        && entry.rect.x >= dialogRect.x + dialogRect.width * 0.45
        && entry.rect.y >= dialogRect.y + dialogRect.height * 0.72
        && entry.rect.bottom <= dialogRect.bottom + 80
        && !/\\bupload\\b/i.test(entry.text))
      : null;
    const addToPrompt = buttonLike.find((entry) => !entry.disabled && /\\badd to prompt\\b/i.test(entry.text))
      || (hasSelectedOption ? buttonLike.find((entry) => !entry.disabled && /\\badd media\\b/i.test(entry.text) && !/\\bupload\\b/i.test(entry.text)) : null)
      || structuralFooterAction
      || null;
    return {
      ok: true,
      open: Boolean(dialog || addToPrompt || uploadMedia),
      dialog: dialog ? { text: dialog.text.slice(0, 220), rect: dialog.rect, role: dialog.role } : null,
      mediaCategory,
      addToPrompt,
      uploadMedia,
      selectedOption: options.find((entry) => entry.selected) || null,
      matchingOption: options[0] || null,
      matchingOptions: options.slice(0, 5),
      matchingImage
    };
  })()`);
}

async function clickAgentRefAssetPickerOptionInPage(target, filename = "") {
  return debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(compactString(filename).toLowerCase())};
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const dialog = Array.from(document.querySelectorAll("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container"))
      .filter(visible)
      .find((element) => element.querySelector("[role='tablist']") && element.querySelector("input,[role='textbox']"));
    if (!dialog) return { ok: false, code: "AGENT_REF_PICKER_NOT_OPEN" };
    const options = Array.from(dialog.querySelectorAll("[role='option']"))
      .filter(visible)
      .filter((element) => String(element.innerText || element.textContent || "").replace(/\\s+/g, " ").trim().toLowerCase() === expected)
      .sort((left, right) => Number(right.getAttribute("aria-selected") === "true") - Number(left.getAttribute("aria-selected") === "true"));
    const option = options[0] || null;
    if (!option) return { ok: false, code: "AGENT_REF_PICKER_FILE_NOT_FOUND" };
    const rect = option.getBoundingClientRect();
    return {
      ok: true,
      selectedBeforeClick: option.getAttribute("aria-selected") === "true",
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
  })()`);
}

async function finalizeAgentRefAssetPickerSelection(target, filename = "", selected = {}, details = {}) {
  if (selected?.autoAddedToPrompt === true) {
    return {
      addToPrompt: { ok: true, clicked: false, method: "option_auto_added" },
      pickerClose: { closed: true, state: selected.confirmedState || null }
    };
  }
  const addToPrompt = await clickAgentRefAssetPickerAddToPrompt(target, filename);
  if (!addToPrompt.ok) {
    throw agentBridgeError(
      addToPrompt.code || "AGENT_REF_ADD_TO_PROMPT_NOT_FOUND",
      addToPrompt.message || `Flow Agent asset picker could not add ${filename} to the prompt.`,
      { ...details, filename, selected, state: addToPrompt.state || null }
    );
  }
  const pickerClose = await waitForAgentRefAssetPickerClosed(target, filename);
  if (!pickerClose.closed) {
    throw agentBridgeError("AGENT_REF_PICKER_STILL_OPEN", "Flow Agent asset picker stayed open after adding a reference.", {
      ...details,
      filename,
      selected,
      addToPrompt,
      state: pickerClose.state || null
    });
  }
  return { addToPrompt, pickerClose };
}

async function selectAgentRefAssetPickerFile(target, filename = "", options = {}) {
  const timeoutMs = Number(options.timeoutMs || 15000) || 15000;
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentRefAssetPickerState(target, filename);
    if (state?.matchingImage?.rect && state?.addToPrompt?.rect) {
      return { ok: true, filename, option: state.matchingImage, skippedUploadAutoSelected: true, exactFilenameMatch: true };
    }
    if (state?.matchingImage?.rect && !state?.matchingOption?.rect) {
      await debuggerClick(target, pointFromRect(state.matchingImage.rect));
      await sleep(450);
      const confirmed = await readAgentRefAssetPickerState(target, filename);
      if (confirmed?.addToPrompt?.rect) {
        return { ok: true, filename, option: confirmed.matchingImage || state.matchingImage, exactFilenameMatch: true };
      }
    }
    if (state?.matchingOption?.rect) {
      if (state.matchingOption.selected === true && state?.addToPrompt?.rect) {
        return { ok: true, filename, option: state.matchingOption, skippedAlreadySelected: true };
      }
      const optionClick = await clickAgentRefAssetPickerOptionInPage(target, filename);
      if (!optionClick?.ok || !optionClick.rect) {
        return { ok: false, filename, code: optionClick?.code || "AGENT_REF_PICKER_FILE_NOT_FOUND", state };
      }
      await debuggerClick(target, pointFromRect(optionClick.rect));
      await sleep(450);
      const confirmedState = await readAgentRefAssetPickerState(target, filename);
      return {
        ok: true,
        filename,
        option: state.matchingOption,
        optionClick,
        autoAddedToPrompt: confirmedState?.open !== true,
        confirmedState
      };
    }
    await sleep(300);
  }
  return {
    ok: false,
    code: "AGENT_REF_PICKER_FILE_NOT_FOUND",
    message: `Flow Agent asset picker did not show ${filename}.`,
    state
  };
}

async function clickAgentRefAssetPickerUpload(target) {
  let state = await readAgentRefAssetPickerState(target, "");
  let sourceSwitch = null;
  let categorySwitch = await switchAgentRefAssetPickerMediaCategory(target, ["Images", "All Media", "All"]).catch((error) => ({
    ok: false,
    error: String(error?.message || error || "media category switch failed")
  }));
  await sleep(250);
  state = await readAgentRefAssetPickerState(target, "");
  if (!state?.uploadMedia?.rect) {
    sourceSwitch = await switchAgentRefAssetPickerSource(target, ["Uploads", "All"]).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "source switch failed")
    }));
    await sleep(350);
    categorySwitch = await switchAgentRefAssetPickerMediaCategory(target, ["Images", "All Media", "All"]).catch((error) => ({
      ok: false,
      error: String(error?.message || error || "media category switch failed")
    }));
    await sleep(250);
    state = await readAgentRefAssetPickerState(target, "");
  }
  if (!state?.uploadMedia?.rect) {
    throw agentBridgeError(
      "AGENT_REF_PICKER_UPLOAD_NOT_FOUND",
      "Flow Agent asset picker upload button was not found.",
      { state, sourceSwitch, categorySwitch }
    );
  }
  await debuggerClick(target, agentRefUploadMediaClickPoint(state.uploadMedia));
  await sleep(350);
  return { ok: true, button: state.uploadMedia, sourceSwitch, categorySwitch };
}

function agentRefUploadMediaClickPoint(uploadMedia = {}) {
  const rect = uploadMedia.rect || {};
  const text = compactString(uploadMedia.text || "");
  if (/\\bupload media\\b/i.test(text) && Number(rect.height || 0) > 90 && Number(rect.width || 0) <= 180) {
    return {
      x: Math.round(Number(rect.x || 0) + Number(rect.width || 0) / 2),
      y: Math.round(Number(rect.bottom || 0) - Math.min(24, Math.max(12, Number(rect.height || 0) * 0.12)))
    };
  }
  return pointFromRect(rect);
}

async function findAgentRefAssetPickerFooterActionAtClickTime(target, filename = "", options = {}) {
  return debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(compactString(filename).toLowerCase())};
    const exactSelectionVerified = ${options.exactSelectionVerified === true};
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const dialog = Array.from(document.querySelectorAll("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container"))
      .filter(visible)
      .find((element) => element.querySelector("[role='tablist']") && element.querySelector("input,[role='textbox']"));
    if (!dialog) return { ok: false, code: "AGENT_REF_PICKER_NOT_OPEN" };
    const selectedOptions = Array.from(dialog.querySelectorAll("[role='option'][aria-selected='true']")).filter(visible);
    const exactSelected = exactSelectionVerified
      ? selectedOptions.length === 1
      : selectedOptions.some((element) => String(element.innerText || element.textContent || "").replace(/\\s+/g, " ").trim().toLowerCase() === expected);
    // The current Uploads picker auto-selects a newly uploaded image without
    // wrapping it in role=option. In that surface, an exact visible filename
    // on the image plus the enabled footer action is the selection proof.
    const exactAutoSelectedImage = Array.from(dialog.querySelectorAll("img"))
      .filter(visible)
      .some((image) => String(image.getAttribute("alt") || image.getAttribute("title") || "").replace(/\\s+/g, " ").trim().toLowerCase() === expected);
    if (!exactSelected && !exactAutoSelectedImage) {
      return { ok: false, code: "AGENT_REF_PICKER_SELECTION_UNVERIFIED" };
    }
    const dialogRect = dialog.getBoundingClientRect();
    const action = Array.from(dialog.querySelectorAll("button"))
      .filter(visible)
      .find((button) => {
        const rect = button.getBoundingClientRect();
        return !button.disabled && button.getAttribute("aria-disabled") !== "true"
          && rect.width >= dialogRect.width * 0.25
          && rect.x >= dialogRect.x + dialogRect.width * 0.45
          && rect.y >= dialogRect.y + dialogRect.height * 0.72
          && rect.bottom <= dialogRect.bottom + 80;
      });
    if (!action) return { ok: false, code: "AGENT_REF_ADD_TO_PROMPT_NOT_FOUND" };
    const rect = action.getBoundingClientRect();
    action.click();
    return {
      ok: true,
      selectionSignal: exactSelected ? "exact_selected_option" : "exact_auto_selected_image",
      method: "guarded_dom_click",
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
  })()`);
}

async function clickAgentRefAssetPickerAddToPrompt(target, filename = "", options = {}) {
  const deadline = Date.now() + 4200;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentRefAssetPickerState(target, filename);
    if (state?.open === false) {
      return { ok: true, pickerClosed: true, signal: "picker_closed_after_selection" };
    }
    if (state?.addToPrompt?.rect) {
      const action = await findAgentRefAssetPickerFooterActionAtClickTime(target, filename, options);
      if (!action?.ok || !action.rect) {
        await sleep(250);
        continue;
      }
      if (action.method !== "guarded_dom_click") await debuggerClick(target, pointFromRect(action.rect));
      await sleep(500);
      return { ok: true, button: { ...state.addToPrompt, rect: action.rect }, revalidated: true };
    }
    await sleep(250);
  }
  return {
    ok: false,
    code: "AGENT_REF_ADD_TO_PROMPT_NOT_FOUND",
    message: "Flow Agent asset picker Add to Prompt button was not found.",
    state
  };
}

async function waitForAgentRefAssetPickerClosed(target, filename = "", options = {}) {
  const timeoutMs = Number(options.timeoutMs || 4500) || 4500;
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentRefAssetPickerState(target, filename);
    if (!state?.open) return { closed: true, after: "add_to_prompt" };
    await sleep(250);
  }
  await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 25 }).catch(() => null);
  const escapeDeadline = Date.now() + 1800;
  while (Date.now() < escapeDeadline) {
    state = await readAgentRefAssetPickerState(target, filename);
    if (!state?.open) return { closed: true, after: "escape" };
    await sleep(250);
  }
  return { closed: false, state };
}

async function markAgentRefFileInput(target, phase = "agent_ref_upload") {
  const marker = `active-${Date.now()}`;
  const summary = await debuggerEvaluate(target, `(() => {
    const marker = ${JSON.stringify(marker)};
    const input = Array.from(document.querySelectorAll("input[type='file']")).find((candidate) => !candidate.disabled);
    if (!input) return { ok: false, error: "AGENT_REF_FILE_INPUT_NOT_FOUND", phase: ${JSON.stringify(phase)} };
    input.setAttribute("data-autoflow-agent-ref-input", marker);
    return {
      ok: true,
      marker,
      phase: ${JSON.stringify(phase)},
      accept: String(input.getAttribute("accept") || ""),
      multiple: input.multiple === true,
      disabled: input.disabled === true
    };
  })()`);
  if (!summary?.ok) {
    throw agentBridgeError(summary?.error || "AGENT_REF_FILE_INPUT_NOT_FOUND", "Flow Agent reference file input was not found.", summary || {});
  }
  const handle = await debuggerSend(target, "Runtime.evaluate", {
    expression: `document.querySelector("input[type='file'][data-autoflow-agent-ref-input='${marker}']")`,
    returnByValue: false,
    awaitPromise: false
  });
  const objectId = handle?.result?.objectId || "";
  if (!objectId) {
    throw agentBridgeError("AGENT_REF_FILE_INPUT_HANDLE_MISSING", "Flow Agent reference file input was found but could not be addressed by Chrome Debugger.", summary || {});
  }
  return { objectId, summary };
}

async function prepareAgentRefFileInput(target) {
  const summary = await debuggerEvaluate(target, `(() => new Promise((resolve) => {
    const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || element?.getAttribute?.("title") || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const materialIconTokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const markInput = (input, phase) => {
      if (!input) return null;
      input.setAttribute("data-autoflow-agent-ref-input", "1");
      return {
        ok: true,
        phase,
        accept: String(input.getAttribute("accept") || ""),
        multiple: input.multiple === true,
        disabled: input.disabled === true
      };
    };
    const findFileInput = () => allDeep("input[type='file']").find((input) => !input.disabled) || null;
    const click = (element) => {
      try { element.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch {}
      try { element.click(); return true; } catch {}
      return false;
    };
    const findAgentComposerEditor = () => allDeep("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']")
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const tag = String(element.tagName || "").toLowerCase();
        const label = [
          element.getAttribute?.("placeholder") || "",
          element.getAttribute?.("aria-label") || "",
          element.getAttribute?.("type") || ""
        ].join(" ");
        const searchLike = tag === "input" && /search|assets/i.test(label);
        const rightComposer = rect.right > window.innerWidth * 0.72 && rect.bottom > window.innerHeight * 0.55;
        return { element, score: (rightComposer ? 10000 : 0) + rect.x + rect.y - (searchLike ? 8000 : 0) };
      })
      .sort((left, right) => right.score - left.score)[0]?.element || null;
    const findAddButton = () => {
      const editor = findAgentComposerEditor();
      const editorRect = editor?.getBoundingClientRect?.() || null;
      return allDeep("button,[role='button'],label")
        .filter(visible)
        .map((button) => {
          const icons = materialIconTokens(button);
          const text = textOf(button);
          const rect = button.getBoundingClientRect();
          const addLike = icons.has("add_2") || icons.has("add") || icons.has("add_photo_alternate") || /add_2|add_photo_alternate|\\b(add|attach|upload)\\b/i.test(text);
          const className = String(button?.className?.baseVal || button?.className || "");
          const iconOnlySubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
            || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
          const sendLike = icons.has("arrow_forward") || iconOnlySubmit || /\\b(send|submit|generate)\\b/i.test(text) || (!addLike && /\\bcreate\\b/i.test(text));
          let score = addLike && !sendLike ? 5000 : -5000;
          if (rect.right > window.innerWidth * 0.65 && rect.bottom > window.innerHeight * 0.45) score += 4000;
          if (editorRect) score -= Math.hypot(rect.x - editorRect.x, rect.y - editorRect.bottom) * 0.2;
          return { button, addLike, sendLike, score, text, rect };
        })
        .filter((entry) => entry.addLike && !entry.sendLike && entry.score > 0)
        .sort((left, right) => right.score - left.score)[0]?.button || null;
    };
    const findUploadControl = (addRect = null) => allDeep("button,[role='button'],[role='tab'],label")
      .filter(visible)
      .map((element) => {
        const icons = materialIconTokens(element);
        const text = textOf(element);
        const rect = element.getBoundingClientRect();
        const uploadLike = icons.has("drive_folder_upload") || /\\bupload\\b/i.test(text);
        const nearComposer = rect.x > window.innerWidth * 0.55
          || (addRect && Math.abs(rect.x - addRect.x) < 360 && Math.abs(rect.y - addRect.y) < 360);
        return {
          element,
          uploadLike,
          nearComposer,
          score: (uploadLike ? 5000 : -5000) + (nearComposer ? 4000 : -4000) + rect.x
        };
      })
      .filter((entry) => entry.uploadLike && entry.nearComposer)
      .sort((left, right) => right.score - left.score)[0]?.element || null;

    (async () => {
      const addButton = findAddButton();
      if (!addButton) return resolve({ ok: false, error: "AGENT_REF_ADD_BUTTON_NOT_FOUND" });
      click(addButton);
      const addRect = addButton.getBoundingClientRect();
      for (let elapsed = 0; elapsed <= 4200; elapsed += 200) {
        await sleep(200);
        const input = findFileInput();
        const marked = markInput(input, "after_add");
        if (marked) return resolve(marked);
        const upload = findUploadControl(addRect);
        if (upload) click(upload);
      }
      const finalInput = findFileInput();
      const final = markInput(finalInput, "final");
      if (final) return resolve(final);
      resolve({
        ok: false,
        error: "AGENT_REF_FILE_INPUT_NOT_FOUND",
        addButtonText: textOf(addButton),
        addButtonRect: rectOf(addButton)
      });
    })();
  }))()`);
  if (!summary?.ok) {
    throw agentBridgeError(summary?.error || "AGENT_REF_FILE_INPUT_NOT_FOUND", "Flow Agent reference file input was not found.", summary || {});
  }
  const handle = await debuggerSend(target, "Runtime.evaluate", {
    expression: `document.querySelector("input[type='file'][data-autoflow-agent-ref-input='1']")`,
    returnByValue: false,
    awaitPromise: false
  });
  const objectId = handle?.result?.objectId || "";
  if (!objectId) {
    throw agentBridgeError("AGENT_REF_FILE_INPUT_HANDLE_MISSING", "Flow Agent reference file input was found but could not be addressed by Chrome Debugger.", summary || {});
  }
  return { objectId, summary };
}

async function waitForAgentRefVisibleChipProof(target, plan = {}, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 15000) || 15000;
  const baselineChips = Array.isArray(options.baselineChips) ? options.baselineChips : [];
  const deadline = Date.now() + timeoutMs;
  let last = null;
  while (Date.now() < deadline) {
    let chips = await readAgentRefVisibleChips(target);
    const composerState = await readAgentComposerPromptMediaState(target).catch(() => null);
    if (Number(composerState?.chipCount || 0) > chips.length) {
      chips = Array.from({ length: Number(composerState.chipCount || 0) }, (_, index) => ({
        label: "Prompt media",
        text: "Prompt media",
        visible: true,
        structural: true,
        instance: index + 1,
        mediaIds: index === 0 && Array.isArray(composerState.mediaIds) ? composerState.mediaIds : []
      }));
    }
    const proof = verifyAgentRefAttachmentChips(plan, chips);
    const growthProof = proof.ok === true ? proof : verifyAgentRefAttachmentChipGrowth(plan, baselineChips, chips);
    const mediaChipProof = growthProof.ok === true ? growthProof : verifyAgentRefAttachmentVisibleMediaChips(plan, chips);
    last = { chips, proof: mediaChipProof.ok === true ? mediaChipProof : proof };
    if (mediaChipProof.ok === true && mediaChipProof.readyForSubmit === true) {
      return { plan: mediaChipProof, chips };
    }
    await sleep(350);
  }
  throw agentBridgeError(
    last?.proof?.code || "AGENT_REF_CHIPS_UNVERIFIED",
    last?.proof?.message || "Flow Agent reference chips were not visible after upload.",
    {
      missingChipHandles: last?.proof?.missingChipHandles || [],
      chips: last?.chips || [],
      plan
    }
  );
}

async function waitForAgentRefCumulativeChipCount(target, expectedCount = 1, options = {}) {
  const required = Math.max(1, Number(expectedCount || 1) || 1);
  const timeoutMs = Math.max(1000, Number(options.timeoutMs || 8000) || 8000);
  const deadline = Date.now() + timeoutMs;
  let lastCount = 0;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentComposerPromptMediaState(target).catch(() => null);
    lastCount = Number(state?.chipCount || 0);
    if (lastCount >= required) return { ok: true, expectedCount: required, visibleCount: lastCount, state };
    await sleep(250);
  }
  throw agentBridgeError(
    "AGENT_REF_CHIPS_UNVERIFIED",
    `Flow Agent retained ${lastCount}/${required} prompt-media chips while attaching references.`,
    { expectedCount: required, visibleCount: lastCount, state, submitAttempted: false }
  );
}

async function readAgentComposerPromptMediaState(target, mediaId = "") {
  const expected = compactString(mediaId).toLowerCase();
  return debuggerEvaluate(target, `(() => {
    const expected = ${JSON.stringify(expected)};
    const visible = (element) => {
      const rect = element?.getBoundingClientRect?.();
      const style = element ? getComputedStyle(element) : null;
      return Boolean(rect && rect.width > 0 && rect.height > 0 && style?.display !== "none" && style?.visibility !== "hidden");
    };
    const tokens = (element) => new Set(String(element?.innerText || element?.textContent || "")
      .toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
    const editors = Array.from(document.querySelectorAll("textarea,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
      .filter(visible)
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.right > innerWidth * 0.5 && rect.bottom > innerHeight * 0.7;
      });
    let shell = null;
    for (const editor of editors) {
      for (let candidate = editor.parentElement, depth = 0; candidate && depth < 8; candidate = candidate.parentElement, depth += 1) {
        const rect = candidate.getBoundingClientRect();
        const hasAdd = Array.from(candidate.querySelectorAll("button,[role='button']")).some((control) => tokens(control).has("add_2"));
        if (hasAdd && rect.width <= 680 && rect.height <= 450 && rect.bottom > innerHeight * 0.72) {
          shell = candidate;
          break;
        }
      }
      if (shell) break;
    }
    if (!shell) return { ok: false, code: "AGENT_COMPOSER_SHELL_NOT_FOUND", mediaIds: [], chipCount: 0, overflowCount: 0 };
    const mediaIds = Array.from(shell.querySelectorAll("img,[src],[href]"))
      .flatMap((node) => {
        const values = [node.currentSrc, node.src, node.href];
        try { values.push(...Array.from(node.attributes || []).map((attribute) => attribute.value)); } catch {}
        return values;
      })
      .flatMap((value) => String(value || "").match(/[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/ig) || [])
      .map((value) => value.toLowerCase())
      .filter((value, index, values) => values.indexOf(value) === index);
    const chipButtons = Array.from(shell.querySelectorAll("button,[role='button']"))
      .filter((control) => {
        const iconTokens = tokens(control);
        return (iconTokens.has("cancel") || iconTokens.has("close")) && Boolean(control.querySelector("img"));
      });
    const overflowCount = Array.from(shell.querySelectorAll("button,[role='button'],span,div"))
      .map((element) => String(element.innerText || element.textContent || "").replace(/\\s+/g, " ").trim().match(/^\\+(\\d{1,2})$/))
      .filter(Boolean)
      .reduce((best, match) => Math.max(best, Number(match[1] || 0)), 0);
    return {
      ok: true,
      mediaIds,
      exactMatchCount: expected ? mediaIds.filter((value) => value === expected).length : 0,
      visibleChipCount: chipButtons.length,
      overflowCount,
      chipCount: Math.max(chipButtons.length, chipButtons.length + overflowCount)
    };
  })()`);
}

async function waitForAgentRefExactMediaChip(target, mediaId = "", options = {}) {
  const expected = compactString(mediaId).toLowerCase();
  const timeoutMs = Math.max(1000, Number(options.timeoutMs || 8000) || 8000);
  const expectedCount = Math.max(0, Number(options.expectedCount || 0) || 0);
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    state = await readAgentComposerPromptMediaState(target, expected).catch(() => null);
    if (state?.exactMatchCount === 1) return { ok: true, mediaId: expected, matchCount: 1, state };
    if (expectedCount > 0 && Number(state?.chipCount || 0) >= expectedCount && Number(state?.overflowCount || 0) > 0) {
      return {
        ok: true,
        mediaId: expected,
        matchCount: 0,
        exactPickerSelectionConfirmed: true,
        hiddenInCollapsedOverflow: true,
        state
      };
    }
    await sleep(250);
  }
  throw agentBridgeError(
    "AGENT_REF_EXACT_MEDIA_CHIP_UNVERIFIED",
    `Flow Agent did not retain the exact requested media ${expected} in the prompt.`,
    { mediaId: expected, state, submitAttempted: false }
  );
}

async function readAgentRefCollapsedOverflowCount(target) {
  const result = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden"
        && rect.right > window.innerWidth * 0.5 && rect.top > window.innerHeight * 0.55;
    };
    let best = 0;
    for (const element of Array.from(document.querySelectorAll("button,[role='button'],span,div"))) {
      if (!visible(element)) continue;
      const ownText = String(element.innerText || element.textContent || "").replace(/\\s+/g, " ").trim();
      const match = ownText.match(/^\\+(\\d{1,2})$/);
      if (!match) continue;
      const count = Number(match[1] || 0);
      if (count > 0 && count <= 10) best = Math.max(best, count);
    }
    return best;
  })()`).catch(() => 0);
  return Math.max(0, Number(result || 0) || 0);
}

async function readAgentRefVisibleChips(target) {
  const structuralChips = await readAgentRefChipsWithRemovers(target).catch(() => []);
  const structuralRefs = structuralChips
    .filter((chip) => chip?.visible !== false && chip?.isRefChip === true && chip?.isSuggestionCard !== true)
    .map((chip, index) => ({
      label: "Prompt media",
      text: "Prompt media",
      sourceLabel: compactString(chip.label || chip.text || ""),
      visible: true,
      structural: true,
      instance: index + 1,
      mediaIds: Array.isArray(chip.mediaIds) ? chip.mediaIds : []
    }));
  if (structuralRefs.length) {
    const overflowCount = await readAgentRefCollapsedOverflowCount(target).catch(() => 0);
    const total = Math.max(structuralRefs.length, structuralRefs.length + overflowCount);
    return [
      ...structuralRefs,
      ...Array.from({ length: Math.max(0, total - structuralRefs.length) }, (_, index) => ({
        label: "Prompt media",
        text: "Prompt media",
        sourceLabel: `collapsed +${overflowCount}`,
        visible: true,
        structural: true,
        collapsed: true,
        instance: structuralRefs.length + index + 1
      }))
    ];
  }
  const result = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const allDeep = (selector) => {
      const out = [];
      const roots = [document];
      const seen = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seen.has(root)) continue;
        seen.add(root);
        try {
          out.push(...Array.from(root.querySelectorAll(selector)));
          Array.from(root.querySelectorAll("*")).forEach((node) => {
            if (node.shadowRoot) roots.push(node.shadowRoot);
          });
        } catch {}
      }
      return out;
    };
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim();
    const chipSelectors = [
      "[role='button']",
      "[data-testid*='chip' i]",
      "[class*='chip' i]",
      "[class*='pill' i]",
      "[aria-label]",
      "img"
    ].join(",");
    const rows = [];
    const seen = new Set();
    for (const element of allDeep(chipSelectors)) {
      if (!visible(element)) continue;
      const label = normalize(
        element.getAttribute?.("aria-label")
        || element.getAttribute?.("title")
        || element.getAttribute?.("alt")
        || element.innerText
        || element.textContent
      );
      if (!label || label.length > 180) continue;
      const fileLike = /\\.(png|jpe?g|webp|gif|heic|avif)(?:\\b|$)/i.test(label);
      const refLike = fileLike || /\\b(upload|image|photo|reference|media)\\b/i.test(label);
      if (!refLike) continue;
      const key = label.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({ label, text: label, visible: true });
    }
  return rows.slice(0, 24);
  })()`).catch(() => []);
  return Array.isArray(result) ? result : [];
}

async function submitAgentComposerDraftFromBridge(payload = {}, request = {}) {
  const expectedDraftHash = compactString(payload.expectedDraftHash);
  const idempotencyKeyRaw = compactString(payload.idempotencyKey);
  const runId = compactString(payload.runId);
  if (!expectedDraftHash || !idempotencyKeyRaw || !runId) {
    throw agentBridgeError("AGENT_COMPOSER_SUBMIT_INVALID", "Composer draft submit requires runId, expectedDraftHash, and idempotencyKey.");
  }
  let tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  await assertAgentBridgeWriteEntitled(payload);
  tab = await ensureAgentBridgeProjectRootTab(tab, projectId);
  const lockKey = agentSubmitLockKey(projectId, tab.id);
  const idempotencyKey = `${compactString(projectId)}||${compactString(tab.id)}||composer:${idempotencyKeyRaw}`;
  const priorSubmit = agentSubmitIdempotency.get(idempotencyKey);
  if (priorSubmit?.status === "completed" && priorSubmit.result) {
    return {
      ...priorSubmit.result,
      idempotentReplay: true,
      idempotencyKey
    };
  }
  if (priorSubmit?.status === "pending") {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "An identical Agent composer submit is already in progress for this Flow target.",
      { idempotencyKey }
    );
  }
  if (!agentSubmitLock.acquire(lockKey)) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Another agent submit is already in progress for this Flow target.",
      { lockKey }
    );
  }
  try {
    pruneAgentSubmitIdempotency();
    agentSubmitIdempotency.set(idempotencyKey, {
      status: "pending",
      startedAt: Date.now()
    });
    const result = await executeAgentCurrentComposerSubmitInPage(tab.id, {
      expectedDraftHash,
      requestKind: "agent.composer.submit"
    });
    const response = {
      ok: true,
      state: "draft_submitted",
      draftHash: expectedDraftHash,
      idempotencyKey,
      runId,
      projectId,
      page: {
        tabId: tab.id,
        url: tab.url || "",
        title: tab.title || ""
      },
      acceptanceEvidence: result.acceptanceEvidence || [],
      accepted: result.accepted || null,
      composer: result.composer || null,
      submitButton: result.submitButton || null
    };
    agentSubmitIdempotency.set(idempotencyKey, {
      status: "completed",
      completedAt: Date.now(),
      result: response
    });
    recordEvent({
      type: "agent_bridge.composer.draft_submitted",
      tabId: tab.id,
      projectId,
      runId,
      draftHash: expectedDraftHash,
      requestId: compactString(request?.id || "")
    });
    return response;
  } catch (error) {
    agentSubmitIdempotency.delete(idempotencyKey);
    throw error;
  } finally {
    agentSubmitLock.release(lockKey);
  }
}

async function confirmAgentCreditsFromBridge(payload = {}) {
  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  await assertAgentBridgeWriteEntitled(payload);
  const result = await executeAgentCreditConfirmationInPage(tab.id, {
    allowPersistent: payload.persistentApproval === true || payload.dontAskAgain === true,
    requestKind: "agent.credits.confirm"
  });
  recordEvent({
    type: result.confirmed ? "agent_bridge.credits.confirmed" : "agent_bridge.credits.no_dialog",
    tabId: tab.id,
    projectId,
    confirmed: result.confirmed === true,
    persistent: result.confirmation?.persistent === true
  });
  return {
    ok: true,
    confirmed: result.confirmed === true,
    creditDialog: result.creditDialog || null,
    confirmation: result.confirmation || null,
    projectId,
    page: {
      tabId: tab.id,
      url: tab.url || "",
      title: tab.title || ""
    }
  };
}

function agentRetryPromptFromPayload(payload = {}) {
  const directPrompt = compactString(payload.prompt || payload.retryPrompt);
  if (directPrompt) return directPrompt;
  const prompts = [];
  for (const row of Array.isArray(payload.retryPrompts) ? payload.retryPrompts : []) {
    const rowPrompt = compactString(row?.prompt || row?.text);
    if (rowPrompt) prompts.push(rowPrompt);
  }
  if (prompts.length) return prompts.join("\n\n");
  const rows = Array.isArray(payload.rowIds) ? payload.rowIds : (Array.isArray(payload.rows) ? payload.rows : []);
  const issue = compactString(payload.issue || payload.issueLabel || (Array.isArray(payload.issueChips) ? payload.issueChips.join(", ") : ""));
  if (!rows.length || !issue) return "";
  return rows.map((rowId) => `Retry [${compactString(rowId)}] video only. Issue: ${issue}. ${compactString(payload.notes)}`).join("\n\n");
}

async function agentBridgeFlowTab(payload = {}) {
  const preferredTabId = Number(payload.tabId || payload.activeTabId || runtimeState.activeTabId || 0) || undefined;
  const tab = await findFlowTab(preferredTabId).catch(() => null);
  if (!tab?.id) {
    throw agentBridgeError("FLOW_TAB_NOT_FOUND", "No open Google Flow project tab was found.");
  }
  return tab;
}

async function executeFleetGenCommandFromBridge(payload = {}) {
  const tab = await agentBridgeFlowTab(payload);
  const projectId = projectIdFromUrl(tab.url || runtimeState.pageUrl || "");
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: payload.projectId,
    requestedTabId: payload.tabId,
    resolvedProjectId: projectId,
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) {
    throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);
  }
  const command = compactString(payload.command);
  if (command === "launch" || command === "executeDirect") {
    await assertAgentBridgeWriteEntitled(payload);
  }
  const target = await ensureFleetGenFrameBridge(tab.id, {
    timeoutMs: Number(payload.timeoutMs || 0) || undefined,
    allowProvision: command === "launch" || command === "executeDirect"
  });
  let args = {};
  if (command === "setPrompts") args = { text: (Array.isArray(payload.prompts) ? payload.prompts : []).join("\n") };
  else if (command === "updateSettings") args = { config: payload.settings && typeof payload.settings === "object" ? payload.settings : {} };
  else if (command === "executeDirect") args = {
    prompt: compactString(payload.prompt),
    config: payload.options && typeof payload.options === "object" ? payload.options : {}
  };
  else if (command === "launch" || command === "normalizeInputs") args = {
    config: payload.options && typeof payload.options === "object"
      ? payload.options
      : payload.settings && typeof payload.settings === "object" ? payload.settings : {}
  };
  else if (command === "getResult") args = { commandId: compactString(payload.commandId) };
  const response = await invokeFleetGenBridgeMethod(tab.id, target.frameId, command, args, {
    timeoutMs: Number(payload.timeoutMs || 0) || 30000,
    includeMediaBytes: command === "getState" || command === "getResult" || command === "getOutbox"
  });
  return {
    ok: true,
    command,
    projectId,
    tabId: tab.id,
    frameId: target.frameId,
    result: response.result,
    bridgeDiagnostics: {
      fleetGenBridgeVersion: response.fleetGenBridgeVersion || "",
      availableMethods: Array.isArray(response.availableMethods) ? response.availableMethods : []
    }
  };
}

async function executeAgentCurrentComposerSubmitInPage(tabId = 0, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent composer submission.");
  }
  if (runtimeState.queueRunning && options.allowQueueInterrupt !== true) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Auto Flow is already running a queue in this profile. Stop the queue before submitting Agent Mode composer drafts from the bridge.",
      { queueRunning: true, tabId }
    );
  }
  const expectedDraftHash = compactString(options.expectedDraftHash || "");
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_bridge_composer_submit", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    const creditDialog = await findAgentDebuggerCreditDialog(target);
    if (creditDialog?.ok) {
      throw agentBridgeError("AGENT_CREDIT_DIALOG_OPEN", "Flow credit confirmation is open; resolve credits before submitting the composer draft.", {
        text: compactString(creditDialog.text).slice(0, 240)
      });
    }

    const composer = await readAgentDebuggerCurrentComposerDraft(target);
    if (!composer?.ok) {
      throw agentBridgeError(composer?.error || "AGENT_COMPOSER_NOT_FOUND", "Agent composer draft was not found.", composer || {});
    }
    if (composer.activeGeneration === true) {
      throw agentBridgeError("AGENT_GENERATION_ACTIVE", "Flow Agent is already generating; Auto Flow refused to submit another composer draft.", composer);
    }
    if (!composer.text || !composer.normalizedTextHash) {
      throw agentBridgeError("AGENT_DRAFT_EMPTY", "Agent composer draft is empty.", composer);
    }
    if (composer.normalizedTextHash !== expectedDraftHash) {
      throw agentBridgeError("AGENT_DRAFT_CHANGED", "Agent composer draft changed before submit.", {
        expectedDraftHash,
        actualDraftHash: composer.normalizedTextHash,
        textPreview: compactString(composer.text).slice(0, 240)
      });
    }
    if (composer.sendEnabled !== true || !composer.sendControlRect) {
      throw agentBridgeError("AGENT_SUBMIT_BUTTON_NOT_FOUND", "Agent composer send control was not visible and enabled.", composer);
    }

    await debuggerClick(target, pointFromRect(composer.sendControlRect));
    const accepted = await waitForAgentDebuggerSubmitAccepted(target, composer.text, {
      submitButtonRect: composer.sendControlRect,
      submitButtonText: composer.sendControlText,
      timeoutMs: 3000
    });
    if (!accepted?.ok) {
      throw agentBridgeError("AGENT_SUBMIT_NOT_ACCEPTED", "Flow did not accept the current Agent composer draft submit click.", accepted || {});
    }
    return {
      ok: true,
      composer: {
        textPreview: compactString(composer.text).slice(0, 240),
        normalizedTextHash: composer.normalizedTextHash,
        rect: composer.editorRect || null
      },
      submitButton: {
        text: compactString(composer.sendControlText).slice(0, 160),
        rect: composer.sendControlRect
      },
      accepted,
      acceptanceEvidence: [
        accepted.signal || "submit_accepted"
      ].filter(Boolean)
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_COMPOSER_SUBMIT_FAILED", String(error?.message || error || "Agent composer submit failed."));
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function readAgentDebuggerCurrentComposerDraft(target) {
  return debuggerEvaluate(target, `(() => {
    const compact = (value = "") => String(value || "").replace(/\\s+/g, " ").trim();
    const hashCompact = (value = "") => {
      let hash = 2166136261;
      const text = compact(value);
      for (let index = 0; index < text.length; index += 1) {
        hash ^= text.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
      }
      return (hash >>> 0).toString(16);
    };
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const textOf = (element) => {
      if (!element) return "";
      if ("value" in element && typeof element.value === "string") return compact(element.value);
      const clone = element.cloneNode?.(true);
      clone?.querySelectorAll?.("[data-slate-placeholder='true'],[data-slate-zero-width]").forEach((node) => node.remove());
      return compact(clone?.innerText || clone?.textContent || element.getAttribute?.("aria-label") || "");
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const editors = Array.from(document.querySelectorAll("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const text = textOf(element);
        const rightPanel = rect.x > window.innerWidth * 0.55;
        const lowerHalf = rect.y > window.innerHeight * 0.45;
        const notSearch = !/search|filter|name|title/i.test(compact(element.getAttribute?.("aria-label") || element.getAttribute?.("placeholder") || ""));
        return {
          element,
          text,
          rect,
          score: (rightPanel ? 10000 : 0) + (lowerHalf ? 5000 : 0) + (text ? 2000 : 0) + rect.x + rect.y + (notSearch ? 1000 : -2000)
        };
      })
      .filter((entry) => entry.text)
      .filter((entry) => entry.rect.y > window.innerHeight * 0.45 || entry.rect.x > window.innerWidth * 0.55)
      .sort((left, right) => right.score - left.score);
    const editor = editors[0];
    if (!editor?.element) return { ok: false, error: "AGENT_COMPOSER_NOT_FOUND" };
    const rejectControl = (text = "") => /\\b(add|add_2|upload|attach|media|instructions|settings|clear prompt|close|cancel)\\b/i.test(text)
      || /\\b(warning|failed|reuse prompt|delete|send feedback|bad response|good response|flag)\\b/i.test(text);
    const classNameOf = (element) => String(element?.className?.baseVal || element?.className || "");
    const isIconOnlySubmitControl = (button, box, label) => {
      const className = classNameOf(button);
      if (/\\b(add|add_2|upload|attach)\\b/i.test(label) || /add_2|add-button|attach/i.test(className)) return false;
      const classSubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
        || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
      const bottomRightSend = box.x > window.innerWidth * 0.65 && box.y > window.innerHeight * 0.55;
      return Boolean(classSubmit || (box.width >= 28 && box.width <= 56 && Math.abs(box.width - box.height) <= 8 && bottomRightSend && !String(label || "").trim()));
    };
    const buttons = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(visible)
      .map((button) => {
        const rect = button.getBoundingClientRect();
        const text = textOf(button);
        const disabled = Boolean(button.disabled || button.getAttribute("aria-disabled") === "true");
        const bottomRight = rect.x > window.innerWidth * 0.65 && rect.y > window.innerHeight * 0.55;
        const rightEdge = rect.x > window.innerWidth * 0.85;
        const arrowSubmit = /arrow_forward/i.test(text);
        const iconOnlySubmit = isIconOnlySubmitControl(button, rect, text);
        const submitText = arrowSubmit || iconOnlySubmit || /\\b(send|submit|generate)\\b/i.test(text) || (rightEdge && /\\bcreate\\b/i.test(text));
        const activeGeneration = /(^|\\b)stop(\\b|$)|stop_circle/i.test(text);
        return {
          button,
          rect,
          text,
          disabled,
          submitText,
          activeGeneration,
          rejected: rejectControl(text),
          score: (arrowSubmit || iconOnlySubmit ? 20000 : 0) + (bottomRight ? 10000 : 0) + (submitText ? 5000 : 0) + rect.x + rect.y
        };
      })
      .filter((entry) => !entry.rejected)
      .sort((left, right) => right.score - left.score);
    const activeGeneration = buttons.some((entry) => entry.activeGeneration);
    const submit = buttons.find((entry) => entry.submitText && !entry.disabled);
    return {
      ok: true,
      text: editor.text,
      normalizedTextHash: hashCompact(editor.text),
      editorRect: rectOf(editor.element),
      sendEnabled: Boolean(submit),
      sendControlVisible: Boolean(submit),
      sendControlText: submit?.text || "",
      sendControlRect: submit ? rectOf(submit.button) : null,
      activeGeneration
    };
  })()`).catch((error) => ({ ok: false, error: String(error?.message || error || "composer_draft_probe_failed") }));
}

async function executeAgentCreditConfirmationInPage(tabId = 0, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent credit confirmation.");
  }
  if (runtimeState.queueRunning && options.allowQueueInterrupt !== true) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Auto Flow is already running a queue in this profile. Stop the queue before confirming Agent Mode credits from the bridge.",
      { queueRunning: true, tabId }
    );
  }
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_bridge_credit_confirm", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    const creditDialog = await findAgentDebuggerCreditDialog(target);
    if (!creditDialog?.ok) {
      return {
        ok: true,
        confirmed: false,
        creditDialog: {
          state: "none",
          probe: creditDialog || null
        }
      };
    }

    const confirmation = await findAgentDebuggerConfirmationButton(target, {
      allowPersistent: options.allowPersistent === true
    });
    if (!confirmation?.ok || !confirmation.rect) {
      throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_NOT_CLICKED", "Flow asked for credit confirmation, but Auto Flow could not find an allowed confirmation button.", {
        text: compactString(creditDialog.text).slice(0, 240),
        allowPersistent: options.allowPersistent === true,
        probe: confirmation || null
      });
    }
    assertAgentCreditConfirmationChoiceIsAffirmative(confirmation, {
      text: compactString(creditDialog.text).slice(0, 240),
      allowPersistent: options.allowPersistent === true
    });

    const confirmationClick = await clickAgentDebuggerConfirmationAtClickTime(target, confirmation, {
      allowPersistent: options.allowPersistent === true
    });
    if (!confirmationClick?.ok) {
      throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_CHANGED", "Flow credit confirmation changed before activation; Auto Flow did not click it.", {
        confirmation,
        confirmationClick,
        allowPersistent: options.allowPersistent === true
      });
    }
    const remaining = await waitForAgentCreditDialogDismissed(target, { timeoutMs: 3000 });
    if (remaining?.ok) {
      throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_STILL_VISIBLE", "Flow credit confirmation was clicked, but the dialog remained visible.", {
        text: compactString(remaining.text || creditDialog.text).slice(0, 240),
        confirmation: {
          text: compactString(confirmation.text).slice(0, 160),
          rect: confirmation.rect,
          persistent: confirmation.persistent === true
        }
      });
    }
    return {
      ok: true,
      confirmed: true,
      creditDialog: {
        state: remaining?.ok ? "still_visible" : "dismissed",
        text: compactString(creditDialog.text).slice(0, 240),
        rect: creditDialog.rect || null
      },
      confirmation: {
        clicked: true,
        text: compactString(confirmation.text).slice(0, 160),
        rect: confirmation.rect,
        persistent: confirmation.persistent === true
      }
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_CREDIT_CONFIRM_FAILED", String(error?.message || error || "Agent credit confirmation failed."));
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

function agentCreditActionFromDialog(creditDialog = {}) {
  const text = compactString(creditDialog.text || "");
  const amount = extractCreditAmount(text);
  const freeTier = isFreeCreditText(text);
  const creditAmountKnown = freeTier || /\b(?:uses?|using|will\s+use|cost(?:s|ing)?|spend(?:s|ing)?|requires?)\s+(?:\d+|zero|no)\s*credits?\b/i.test(text);
  return {
    kind: "credit_confirmation",
    text: text.slice(0, 240),
    creditAmount: amount,
    creditAmountKnown,
    freeTier
  };
}

function decideAgentCreditDialogApproval(action = {}, options = {}) {
  const policy = options.creditPolicy && typeof options.creditPolicy === "object" ? options.creditPolicy : {};
  if (action.creditAmountKnown !== true) {
    return {
      approved: false,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_amount_unknown",
      creditAmount: Number(action.creditAmount || 0) || 0,
      creditAmountKnown: false,
      requiresApproval: true
    };
  }
  if (action.freeTier === true && policy.autoApproveFree !== false) {
    return {
      approved: true,
      status: "action_resolved",
      reason: "agent_free_credit_approved",
      creditAmount: 0,
      creditAmountKnown: true,
      persistentApproval: false
    };
  }
  const mode = compactString(policy.mode || policy.paidApproval || "ask_each_time").toLowerCase();
  const cap = Number(policy.maxCreditsPerRun ?? policy.creditCap);
  if (mode === "within_cap" && Number.isFinite(cap) && cap >= 0) {
    return buildAgentCreditDecision({
      action,
      options: { creditCap: cap },
      approvedCredits: Number(options.approvedCredits || policy.approvedCredits || 0) || 0
    });
  }
  if (options.autoConfirm === true) {
    return {
      approved: true,
      status: "action_resolved",
      reason: "explicit_submit_credit_approval",
      creditAmount: Number(action.creditAmount || 0) || 0,
      creditAmountKnown: true,
      persistentApproval: false
    };
  }
  return {
    approved: false,
    status: "waiting_for_credit_approval",
    reason: "agent_credit_confirmation_required",
    creditAmount: Number(action.creditAmount || 0) || 0,
    creditAmountKnown: true,
    creditCap: Number.isFinite(cap) && cap >= 0 ? cap : undefined,
    requiresApproval: true
  };
}

async function waitForAgentCreditDialogDismissed(target, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 3000) || 3000;
  const started = Date.now();
  let remaining = null;
  while (Date.now() - started <= timeoutMs) {
    remaining = await findAgentDebuggerCreditDialog(target);
    if (!remaining?.ok) return remaining || { ok: false };
    await sleep(250);
  }
  return remaining || { ok: false };
}

function assertAgentCreditConfirmationChoiceIsAffirmative(confirmation = {}, details = {}) {
  const text = compactString(confirmation.text || "");
  if (!text || /^(?:close\s+)?(?:no|cancel|reject|back)$/i.test(text) || /(?:^|\s)(?:no|cancel|reject|back)(?:\s|$)/i.test(text)) {
    throw agentBridgeError(
      "AGENT_CREDIT_CONFIRMATION_NEGATIVE_CHOICE",
      "Auto Flow refused to click a non-affirmative Flow credit confirmation choice.",
      {
        ...details,
        choiceText: text,
        rect: confirmation.rect || null
      }
    );
  }
  if (!/(?:yes|approve|confirm|continue|use credits|don['’]?t ask|dont ask|ask again)/i.test(text)) {
    throw agentBridgeError(
      "AGENT_CREDIT_CONFIRMATION_AMBIGUOUS_CHOICE",
      "Auto Flow refused to click an ambiguous Flow credit confirmation choice.",
      {
        ...details,
        choiceText: text,
        rect: confirmation.rect || null
      }
    );
  }
}

async function readAgentConversationSessionState(target) {
  return debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && rect.bottom >= 0 && rect.top <= innerHeight
        && style.display !== "none" && style.visibility !== "hidden";
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, right: rect.right, bottom: rect.bottom };
    };
    const buttons = Array.from(document.querySelectorAll("button,[role='button']")).filter(visible);
    const feedbackTokens = new Set(["thumb_up", "thumb_down", "content_copy", "flag"]);
    const feedbackCount = buttons.filter((element) => {
      const rect = element.getBoundingClientRect();
      const tokens = new Set(String(element.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
      return rect.x > innerWidth * 0.55 && Array.from(feedbackTokens).some((token) => tokens.has(token));
    }).length;
    const trigger = buttons.find((element) => {
      const rect = element.getBoundingClientRect();
      const compact = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
      const headerZone = rect.x > innerWidth * 0.75 && rect.y < innerHeight * 0.25;
      const newSessionIcon = Array.from(element.querySelectorAll("*")).some((child) => String(child.textContent || "").trim() === "edit_square");
      return compact && headerZone && newSessionIcon;
    }) || null;
    return { feedbackCount, triggerRect: trigger ? rectOf(trigger) : null };
  })()`);
}

function isExtensionAuthoredAgentRunDraft(text = "") {
  const value = compactString(text);
  return /(?:^|\s)RUN_ID:\s*agent-(?:extension-)?[a-z0-9:-]+/i.test(value)
    && /(?:^|\s)BATCH_ID:\s*BATCH-\d+/i.test(value)
    && /AUTO FLOW AGENT CONTRACT\s*[—-]\s*EXECUTE NOW/i.test(value);
}

async function startFreshAgentConversationSessionWithDebugger(tabId = 0, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent session preflight.");
  }
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_fresh_conversation", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    const draft = await readAgentDebuggerCurrentComposerDraft(target).catch(() => null);
    let clearedStaleAutoFlowDraft = false;
    if (draft?.ok && compactString(draft.text)) {
      const extensionAuthored = isExtensionAuthoredAgentRunDraft(draft.text);
      const submittedMessage = extensionAuthored
        ? await readAgentSubmittedPromptMessageState(target, draft.text).catch(() => null)
        : null;
      if (extensionAuthored && Number(submittedMessage?.matchingMessageCount || 0) > 0) {
        const cleanup = await clearAgentDebuggerSubmittedPromptAfterAcceptance(target, draft.editorRect, draft.text, {
          promptStillPresent: true,
          signal: "stale_extension_draft_exact_message_match"
        });
        if (cleanup?.ok !== true) {
          throw agentBridgeError("AGENT_STALE_AUTOFLOW_DRAFT_CLEAR_FAILED", "Flow Agent retained a previously submitted Auto Flow draft, but it could not be cleared safely before the new run.", {
            draftHash: draft.normalizedTextHash || "",
            submittedMessage,
            cleanup,
            stage: compactString(options.stage)
          });
        }
        clearedStaleAutoFlowDraft = true;
      } else {
        throw agentBridgeError("AGENT_NEW_SESSION_DRAFT_PRESENT", "Flow Agent has an existing unknown composer draft. Auto Flow preserved it instead of starting a new session.", {
          draftHash: draft.normalizedTextHash || "",
          draftPreview: compactString(draft.text).slice(0, 160),
          extensionAuthored,
          exactSubmittedMessageCount: Number(submittedMessage?.matchingMessageCount || 0),
          stage: compactString(options.stage)
        });
      }
    }
    let chips = (await readAgentRefChipsWithRemovers(target).catch(() => []))
      .filter((chip) => chip?.visible !== false && chip?.isRefChip === true && chip?.isSuggestionCard !== true);
    if (chips.length) {
      await clearExistingAgentRefChips(target);
      chips = (await readAgentRefChipsWithRemovers(target).catch(() => []))
        .filter((chip) => chip?.visible !== false && chip?.isRefChip === true && chip?.isSuggestionCard !== true);
      if (chips.length) {
        throw agentBridgeError("AGENT_NEW_SESSION_REFS_PRESENT", "Flow Agent prompt reference chips could not be cleared before starting a new session.", {
          chipCount: chips.length,
          stage: compactString(options.stage)
        });
      }
    }

    let state = await readAgentConversationSessionState(target);
    if (state.feedbackCount === 0) return { ok: true, alreadyFresh: true, started: false, clearedStaleAutoFlowDraft };
    if (!state.triggerRect) {
      throw agentBridgeError("AGENT_NEW_SESSION_CONTROL_NOT_FOUND", "Flow Agent conversation history is present, but the structural new-session control was not found.", {
        state,
        stage: compactString(options.stage)
      });
    }
    await debuggerClick(target, pointFromRect(state.triggerRect));
    let deadline = Date.now() + 5000;
    do {
      await sleep(150);
      state = await readAgentConversationSessionState(target);
    } while (state.feedbackCount > 0 && Date.now() < deadline);
    if (state.feedbackCount > 0) {
      const fallbackClicked = await debuggerEvaluate(target, `(() => {
        const control = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter((element) => {
            const rect = element.getBoundingClientRect();
            return rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72
              && rect.x > innerWidth * 0.75 && rect.y < innerHeight * 0.25;
          })
          .find((element) => Array.from(element.querySelectorAll("*")).some((child) => String(child.textContent || "").trim() === "edit_square"));
        if (!control || typeof control.click !== "function") return false;
        control.click();
        return true;
      })()`).catch(() => false);
      if (fallbackClicked) {
        deadline = Date.now() + 5000;
        do {
          await sleep(150);
          state = await readAgentConversationSessionState(target);
        } while (state.feedbackCount > 0 && Date.now() < deadline);
      }
    }
    if (state.feedbackCount > 0) {
      throw agentBridgeError("AGENT_NEW_SESSION_NOT_STARTED", "Flow Agent did not expose a fresh conversation after the structural new-session action.", {
        state,
        stage: compactString(options.stage)
      });
    }
    return { ok: true, alreadyFresh: false, started: true, clearedStaleAutoFlowDraft };
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function readAgentConversationPanelState(target) {
  return debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0
        && rect.left < innerWidth && rect.top < innerHeight
        && style.display !== "none" && style.visibility !== "hidden";
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: rect.x, y: rect.y, width: rect.width, height: rect.height, right: rect.right, bottom: rect.bottom };
    };
    const tokensOf = (element) => new Set(String(element?.innerText || element?.textContent || "")
      .toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
    const controls = Array.from(document.querySelectorAll("button,[role='button']")).filter(visible);
    const separator = Array.from(document.querySelectorAll("[role='separator']"))
      .filter(visible)
      .find((element) => {
        const rect = element.getBoundingClientRect();
        return rect.x > innerWidth * 0.55 && rect.width <= 40 && rect.height > innerHeight * 0.5;
      }) || null;
    const conversationHeader = controls.find((element) => {
      const rect = element.getBoundingClientRect();
      return rect.x > innerWidth * 0.78 && rect.y < innerHeight * 0.25
        && rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72
        && tokensOf(element).has("edit_square");
    }) || null;
    const editors = Array.from(document.querySelectorAll("textarea,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
      .filter(visible)
      .filter((element) => !element.closest("[data-autoflow-rebuild], #af-bot-panel"));
    const composerShellFor = (editor) => {
      let shell = editor.parentElement;
      for (let depth = 0; shell && depth < 8; depth += 1, shell = shell.parentElement) {
        const shellRect = shell.getBoundingClientRect();
        const shellControls = Array.from(shell.querySelectorAll("button,[role='button']")).filter(visible);
        const shellTokens = new Set(shellControls.flatMap((control) => [...tokensOf(control)]));
        const classicAgentActions = shellTokens.has("article_spark") && shellTokens.has("tune");
        const compactAspectMenu = shellControls.some((control) => control.getAttribute("aria-haspopup") === "menu"
          && [...tokensOf(control)].some((token) => /^crop_(16_9|4_3|square|3_4|9_16)$/.test(token)));
        const compactAgentToggle = shellControls.some((control) => control.hasAttribute("aria-pressed")
          && [...tokensOf(control)].some((token) => token === "agent"));
        const iconOnlySendControl = shellControls.some((control) => {
          const controlRect = control.getBoundingClientRect();
          const compactCircular = controlRect.width >= 28 && controlRect.width <= 56
            && controlRect.height >= 28 && controlRect.height <= 56
            && Math.abs(controlRect.width - controlRect.height) <= 8;
          const className = String(control?.className?.baseVal || control?.className || "");
          return /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
            || (compactCircular && /icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
        });
        const compactComposerActions = (shellTokens.has("arrow_forward") || iconOnlySendControl)
          && (compactAspectMenu || iconOnlySendControl)
          && (shellTokens.has("add_2") || compactAgentToggle || iconOnlySendControl);
        const structuralActions = classicAgentActions || compactComposerActions;
        const shellCenterX = shellRect.x + shellRect.width / 2;
        const centeredBottom = shellCenterX >= innerWidth * 0.3 && shellCenterX <= innerWidth * 0.7
          && shellRect.width >= innerWidth * 0.25 && shellRect.width <= innerWidth * 0.7
          && shellRect.bottom > innerHeight * 0.72;
        const rightDocked = shellRect.right >= innerWidth * 0.88 && shellRect.x > innerWidth * 0.72
          && shellRect.width <= innerWidth * 0.32 && shellRect.bottom > innerHeight * 0.72;
        if (structuralActions && (centeredBottom || rightDocked)) {
          return { shell, shellRect, shellControls, centeredBottom, rightDocked };
        }
      }
      return null;
    };
    const composer = editors.map((editor) => ({ editor, match: composerShellFor(editor) }))
      .find((entry) => entry.match) || null;
    const rightComposer = composer?.match?.rightDocked === true ? composer : null;
    const agentToggle = composer?.match?.shellControls.find((element) => {
      const rect = element.getBoundingClientRect();
      const shellRect = composer.match.shellRect;
      return element.hasAttribute("aria-pressed")
        && element.getAttribute("aria-pressed") === "false"
        && rect.width >= 40 && rect.width <= 160 && rect.height >= 20 && rect.height <= 56
        && rect.y >= shellRect.y + shellRect.height * 0.45
        && rect.right < shellRect.x + shellRect.width * 0.55;
    }) || null;
    const agentTogglePressed = composer?.match?.shellControls.some((element) => element.hasAttribute("aria-pressed")
      && element.getAttribute("aria-pressed") === "true") === true;
    const expandTokens = new Set(["expand_content", "open_in_full", "fullscreen"]);
    const iconTrigger = controls.find((element) => {
      const rect = element.getBoundingClientRect();
      const compact = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
      const centeredComposerControl = rect.x > innerWidth * 0.35 && rect.x < innerWidth * 0.78 && rect.bottom > innerHeight * 0.65;
      return compact && centeredComposerControl && [...tokensOf(element)].some((token) => expandTokens.has(token));
    }) || null;
    let structuralTrigger = null;
    if (!iconTrigger && composer?.match?.centeredBottom) {
      const { shellRect, shellControls } = composer.match;
      const blockedTokens = new Set(["add", "add_2", "arrow_forward", "article_spark", "close", "edit_square", "settings", "settings_2", "tune"]);
      structuralTrigger = shellControls
        .filter((element) => {
          const rect = element.getBoundingClientRect();
          const compact = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72;
          const upperRightCorner = rect.x >= shellRect.right - Math.min(84, shellRect.width * 0.2)
            && rect.y < shellRect.y + shellRect.height * 0.55;
          return compact && upperRightCorner && ![...tokensOf(element)].some((token) => blockedTokens.has(token));
        })
        .sort((left, right) => right.getBoundingClientRect().x - left.getBoundingClientRect().x)[0] || null;
    }
    const trigger = agentToggle || iconTrigger || structuralTrigger;
    return {
      panelOpen: Boolean(separator || conversationHeader || rightComposer),
      panelEvidence: separator ? "separator" : conversationHeader ? "conversation_header" : rightComposer ? "right_composer" : "",
      separatorRect: separator ? rectOf(separator) : null,
      headerRect: conversationHeader ? rectOf(conversationHeader) : null,
      rightComposerRect: rightComposer ? rectOf(rightComposer.editor) : null,
      triggerRect: trigger ? rectOf(trigger) : null,
      triggerEvidence: agentToggle ? "agent_toggle" : iconTrigger ? "expand_icon" : structuralTrigger ? "composer_corner" : ""
    };
  })()`);
}

async function ensureAgentConversationPanelOpen(target, options = {}) {
  let state = await readAgentConversationPanelState(target);
  if (state.panelOpen === true) return { ...state, opened: false };
  if (!state.triggerRect) {
    throw agentBridgeError("AGENT_CONVERSATION_PANEL_TRIGGER_NOT_FOUND", "Flow Agent conversation panel was closed and its structural expand control was not found.", {
      stage: compactString(options.stage), state
    });
  }
  // Opening can take two structural steps: activating the Agent toggle first
  // switches the composer into Agent mode, after which the panel expand icon
  // becomes the trigger. Each attempt activates exactly one trigger; a later
  // attempt runs only when the re-read state exposes a DIFFERENT trigger — a
  // new evidence kind, or the same trigger re-found at a moved rect. The
  // chrome.debugger infobar shrinks the viewport mid-flow and shifts the
  // bottom-anchored composer, so a click at the previously probed rect can
  // land where the control no longer is; the fresh probe rect recovers that.
  let previousTriggerEvidence = "";
  let previousTriggerRect = null;
  for (let attempt = 0; attempt < 3 && state.panelOpen !== true; attempt += 1) {
    if (!state.triggerRect) break;
    const triggerEvidence = state.triggerEvidence || "";
    const sameTriggerAsPrevious = triggerEvidence === previousTriggerEvidence
      && previousTriggerRect
      && Math.abs(state.triggerRect.x - previousTriggerRect.x) <= 12
      && Math.abs(state.triggerRect.y - previousTriggerRect.y) <= 12;
    if (attempt > 0 && sameTriggerAsPrevious) break;
    previousTriggerEvidence = triggerEvidence;
    previousTriggerRect = state.triggerRect;
    const triggerRect = state.triggerRect;
    await debuggerClick(target, pointFromRect(triggerRect));
    const deadline = Date.now() + 5000;
    do {
      await sleep(150);
      state = await readAgentConversationPanelState(target);
    } while (state.panelOpen !== true && Date.now() < deadline);
    if (state.panelOpen !== true) {
      // Flow occasionally ignores trusted CDP coordinates for this compact
      // navigation-only control. Retry only the same center-hit-tested structural
      // control; never use this DOM fallback for prompt insertion or submission.
      const expectedTrigger = triggerRect;
      const fallbackOpened = await debuggerEvaluate(target, `(() => {
        const expected = ${JSON.stringify(expectedTrigger)};
        const expectedEvidence = ${JSON.stringify(triggerEvidence)};
        if (!expected) return false;
        const visible = (element) => {
          const rect = element?.getBoundingClientRect?.();
          const style = element ? getComputedStyle(element) : null;
          return Boolean(rect && rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0
            && rect.left < innerWidth && rect.top < innerHeight && style?.display !== "none" && style?.visibility !== "hidden");
        };
        const tokens = (element) => new Set(String(element?.innerText || element?.textContent || "")
          .toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
        if (expectedEvidence === "agent_toggle") {
          const candidates = Array.from(document.querySelectorAll("button[aria-pressed='false'],[role='button'][aria-pressed='false']"))
            .filter(visible)
            .filter((control) => {
              const rect = control.getBoundingClientRect();
              if (rect.width < 40 || rect.width > 160 || rect.height < 20 || rect.height > 56) return false;
              // Identity anchors to the trusted-click trigger rect plus the
              // composer shell, not to sibling feature tokens (Flow removed the
              // compact crop aspect menu, which a previous gate depended on).
              const nearExpectedTrigger = Math.abs(rect.x - expected.x) <= 48 && Math.abs(rect.y - expected.y) <= 48;
              let shell = control.parentElement;
              for (let depth = 0; shell && depth < 8; depth += 1, shell = shell.parentElement) {
                const shellRect = shell.getBoundingClientRect();
                const shellControls = Array.from(shell.querySelectorAll("button,[role='button']")).filter(visible);
                const shellTokens = new Set(shellControls.flatMap((item) => [...tokens(item)]));
                const hasAspectMenu = shellControls.some((item) => item.getAttribute("aria-haspopup") === "menu"
                  && [...tokens(item)].some((token) => /^crop_(16_9|4_3|square|3_4|9_16)$/.test(token)));
                const classicAgentActions = shellTokens.has("article_spark") && shellTokens.has("tune");
                const centeredBottom = shellRect.width >= innerWidth * 0.25 && shellRect.width <= innerWidth * 0.7
                  && shellRect.bottom > innerHeight * 0.72;
                const composerShell = shellTokens.has("arrow_forward")
                  && (hasAspectMenu || classicAgentActions || nearExpectedTrigger) && centeredBottom;
                if (composerShell) return true;
              }
              return false;
            });
          if (candidates.length !== 1 || typeof candidates[0].click !== "function") return false;
          candidates[0].click();
          return true;
        }
        const x = expected.x + expected.width / 2;
        const y = expected.y + expected.height / 2;
        const control = document.elementFromPoint(x, y)?.closest?.("button,[role='button']") || null;
        if (!control || typeof control.click !== "function") return false;
        const rect = control.getBoundingClientRect();
        const sameStructuralControl = rect.width >= 20 && rect.width <= 72 && rect.height >= 20 && rect.height <= 72
          && Math.abs(rect.x - expected.x) <= 24 && Math.abs(rect.y - expected.y) <= 24;
        if (!sameStructuralControl) return false;
        control.click();
        return true;
      })()`).catch(() => false);
      if (fallbackOpened) {
        const fallbackDeadline = Date.now() + 5000;
        do {
          await sleep(150);
          state = await readAgentConversationPanelState(target);
        } while (state.panelOpen !== true && Date.now() < fallbackDeadline);
      }
    }
  }
  if (state.panelOpen !== true) {
    throw agentBridgeError("AGENT_CONVERSATION_PANEL_NOT_OPEN", "Flow Agent conversation panel did not open after its structural expand control was activated.", {
      stage: compactString(options.stage), state
    });
  }
  return { ...state, opened: true };
}

async function normalizeAgentProjectSurfaceWithDebugger(tabId = 0, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent surface normalization.");
  }
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_surface_normalize", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    const generationActive = await debuggerEvaluate(target, `(() => Array.from(document.querySelectorAll("button,[role='button']")).some((button) => {
      const rect = button.getBoundingClientRect();
      const tokens = new Set(String(button.innerText || button.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
      return rect.width > 0 && rect.height > 0 && (tokens.has("stop") || tokens.has("stop_circle"));
    }))()`).catch(() => true);
    if (generationActive === true) {
      throw agentBridgeError("AGENT_SURFACE_GENERATION_ACTIVE", "Flow Agent is actively generating; Auto Flow preserved the page and stopped normalization.", {
        stage: compactString(options.stage)
      });
    }
    const creditDialog = await findAgentDebuggerCreditDialog(target).catch(() => null);
    if (creditDialog?.ok) {
      throw agentBridgeError("AGENT_SURFACE_CREDIT_DIALOG_OPEN", "Flow Agent has an unresolved credit decision; Auto Flow preserved it and stopped normalization.", {
        stage: compactString(options.stage),
        text: compactString(creditDialog.text).slice(0, 240)
      });
    }

    let settings = await readAgentNativeSettingsSnapshot(target);
    let closedSettings = false;
    if (settings.panelOpen === true) {
      const backRect = settings.controls?.backRect;
      if (!backRect) {
        throw agentBridgeError("AGENT_SURFACE_SETTINGS_DISMISS_NOT_FOUND", "Flow Agent Settings are open, but the non-committing structural back control was not found.", {
          stage: compactString(options.stage), settings
        });
      }
      await debuggerClick(target, pointFromRect(backRect));
      settings = await waitForAgentNativeSettingsClosed(target, 5000);
      if (settings.panelOpen === true) {
        const fallbackClosed = await debuggerEvaluate(target, `(() => {
          const control = Array.from(document.querySelectorAll("button,[role='button']"))
            .filter((element) => {
              const rect = element.getBoundingClientRect();
              return rect.width > 0 && rect.height > 0 && rect.width <= 80 && rect.height <= 80 && rect.x > innerWidth * 0.55;
            })
            .find((element) => Array.from(element.querySelectorAll("*")).some((child) => String(child.textContent || "").trim() === "arrow_back"));
          if (!control || typeof control.click !== "function") return false;
          control.click();
          return true;
        })()`).catch(() => false);
        if (fallbackClosed) settings = await waitForAgentNativeSettingsClosed(target, 5000);
      }
      if (settings.panelOpen === true) {
        throw agentBridgeError("AGENT_SURFACE_SETTINGS_NOT_CLOSED", "Flow Agent Settings remained open after the structural back action.", {
          stage: compactString(options.stage), settings
        });
      }
      closedSettings = true;
    }

    // A closed conversation drawer exposes the centered root composer. Open it
    // before probing Instructions so that the root composer itself cannot be
    // mistaken for an Instructions editor in the compact layout. Real
    // Instructions/unknown overlays do not expose this exact expand control and
    // remain preserved for the guarded classification below.
    let conversationPanel = await readAgentConversationPanelState(target);
    let openedConversationPanel = false;
    if (conversationPanel.panelOpen === true || conversationPanel.triggerRect) {
      conversationPanel = await ensureAgentConversationPanelOpen(target, { stage: options.stage });
      openedConversationPanel = conversationPanel.opened === true;
    }

    let instructions = await readManagedAgentInstructionsPanel(target);
    let closedInstructions = false;
    if (instructions.panelOpen === true) {
      if (options.allowManagedInstructionsClose !== true) {
        throw agentBridgeError("AGENT_SURFACE_INSTRUCTIONS_OPEN", "Flow Agent Instructions were already open. Auto Flow preserved the potentially user-authored edit surface.", {
          stage: compactString(options.stage)
        });
      }
      if (!instructions.doneRect) {
        throw agentBridgeError("AGENT_SURFACE_INSTRUCTIONS_DISMISS_NOT_FOUND", "Managed Agent Instructions remained open without a structural completion control.", {
          stage: compactString(options.stage), instructions
        });
      }
      await clickManagedAgentInstructionControl(target, instructions.doneRect);
      const deadline = Date.now() + 5000;
      do {
        await sleep(150);
        instructions = await readManagedAgentInstructionsPanel(target);
      } while (instructions.panelOpen === true && Date.now() < deadline);
      if (instructions.panelOpen === true) {
        throw agentBridgeError("AGENT_SURFACE_INSTRUCTIONS_NOT_CLOSED", "Managed Agent Instructions remained open after completion.", {
          stage: compactString(options.stage)
        });
      }
      closedInstructions = true;
    }

    conversationPanel = await ensureAgentConversationPanelOpen(target, { stage: options.stage });
    openedConversationPanel = openedConversationPanel || conversationPanel.opened === true;
    recordEvent({
      type: "agent_bridge.surface.normalized",
      tabId,
      stage: compactString(options.stage),
      closedSettings,
      closedInstructions,
      openedConversationPanel
    });
    return {
      ok: true,
      closedSettings,
      closedInstructions,
      conversationPanelOpen: conversationPanel.panelOpen === true,
      openedConversationPanel,
      stage: compactString(options.stage)
    };
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function readAgentProjectSettingsSnapshot(target) {
  return debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0
        && rect.left < innerWidth && rect.top < innerHeight
        && style.display !== "none" && style.visibility !== "hidden";
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const tokens = (element) => new Set(String(element?.textContent || "").split(/\\s+/).map((token) => token.trim()).filter(Boolean));
    const controls = Array.from(document.querySelectorAll("button,[role='button']")).filter(visible);
    const trigger = controls.find((element) => {
      const rect = element.getBoundingClientRect();
      const iconValues = Array.from(element.querySelectorAll("*")).map((child) => String(child.textContent || "").trim());
      return (iconValues.includes("settings") || iconValues.includes("settings_2"))
        && rect.x > innerWidth * 0.75
        && rect.y < innerHeight * 0.2
        && rect.width <= 72
        && rect.height <= 72;
    }) || null;
    const menu = Array.from(document.querySelectorAll("[role='menu']"))
      .filter(visible)
      .find((element) => element.getAttribute("data-state") === "open" || rectOf(element).x > innerWidth * 0.5) || null;
    if (!menu) {
      return { menuOpen: false, triggerRect: trigger ? rectOf(trigger) : null };
    }
    const eraser = Array.from(menu.querySelectorAll("*"))
      .filter((element) => tokens(element).has("ink_eraser"))
      .sort((left, right) => {
        const leftRect = left.getBoundingClientRect();
        const rightRect = right.getBoundingClientRect();
        return (leftRect.width * leftRect.height) - (rightRect.width * rightRect.height);
      })[0] || null;
    const tabs = Array.from(menu.querySelectorAll("[role='tab']"))
      .filter(visible)
      .map((element) => ({
        element,
        rect: rectOf(element),
        active: element.getAttribute("data-state") === "active" || element.getAttribute("aria-selected") === "true"
      }));
    const eraserRect = eraser ? rectOf(eraser) : null;
    const rowTabs = eraserRect
      ? tabs.filter((entry) => Math.abs((entry.rect.y + entry.rect.height / 2) - (eraserRect.y + eraserRect.height / 2)) <= 28)
        .sort((left, right) => left.rect.x - right.rect.x)
      : [];
    const off = rowTabs.length === 2 ? rowTabs[0] : null;
    const on = rowTabs.length === 2 ? rowTabs[1] : null;
    return {
      menuOpen: true,
      triggerRect: trigger ? rectOf(trigger) : null,
      clearPromptOnSubmit: on ? on.active : "unknown",
      clearPromptOnSubmitOffRect: off?.rect || null,
      clearPromptOnSubmitOnRect: on?.rect || null,
      clearPromptRowResolved: rowTabs.length === 2
    };
  })()`);
}

async function waitForAgentProjectSettingsState(target, predicate, timeoutMs = 3000) {
  const deadline = Date.now() + Math.max(500, Number(timeoutMs || 3000) || 3000);
  let snapshot = await readAgentProjectSettingsSnapshot(target);
  while (!predicate(snapshot) && Date.now() < deadline) {
    await sleep(100);
    snapshot = await readAgentProjectSettingsSnapshot(target);
  }
  return snapshot;
}

async function ensureAgentProjectClearPromptOnSubmitWithDebugger(tabId = 0, desired = true, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent project settings verification.");
  }
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_project_settings", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});
    let snapshot = await readAgentProjectSettingsSnapshot(target);
    if (snapshot.menuOpen !== true) {
      if (!snapshot.triggerRect) {
        throw agentBridgeError("AGENT_PROJECT_SETTINGS_TRIGGER_NOT_FOUND", "Flow project settings control was not found structurally.", snapshot);
      }
      await debuggerClick(target, pointFromRect(snapshot.triggerRect));
      snapshot = await waitForAgentProjectSettingsState(target, (state) => state.menuOpen === true, 3000);
    }
    if (snapshot.menuOpen !== true || snapshot.clearPromptRowResolved !== true) {
      throw agentBridgeError("AGENT_CLEAR_PROMPT_SETTING_NOT_FOUND", "Flow project Clear prompt on submit control was not found structurally.", snapshot);
    }
    const expected = desired !== false;
    const changed = snapshot.clearPromptOnSubmit !== expected;
    if (changed) {
      const rect = expected ? snapshot.clearPromptOnSubmitOnRect : snapshot.clearPromptOnSubmitOffRect;
      if (!rect) {
        throw agentBridgeError("AGENT_CLEAR_PROMPT_SETTING_CONTROL_NOT_FOUND", "Flow project Clear prompt on submit target state was unavailable.", snapshot);
      }
      await debuggerClick(target, pointFromRect(rect));
      snapshot = await waitForAgentProjectSettingsState(target, (state) => state.clearPromptOnSubmit === expected, 3000);
    }
    if (snapshot.clearPromptOnSubmit !== expected) {
      throw agentBridgeError("AGENT_CLEAR_PROMPT_SETTING_VERIFY_FAILED", "Flow project Clear prompt on submit setting did not match the managed run.", {
        expected,
        snapshot
      });
    }
    await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyDown", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 }).catch(() => {});
    await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyUp", key: "Escape", code: "Escape", windowsVirtualKeyCode: 27 }).catch(() => {});
    const closed = await waitForAgentProjectSettingsState(target, (state) => state.menuOpen !== true, 2000);
    if (closed.menuOpen === true) {
      throw agentBridgeError("AGENT_PROJECT_SETTINGS_NOT_CLOSED", "Flow project settings stayed open before reference attachment.", closed);
    }
    recordEvent({
      type: "agent_bridge.project_settings.clear_prompt_verified",
      tabId,
      requestKind: compactString(options.requestKind),
      changed,
      clearPromptOnSubmit: expected
    });
    return { ok: true, changed, clearPromptOnSubmit: expected };
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function ensureAgentNativeSettingsWithDebugger(tabId = 0, plan = {}, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent native settings verification.");
  }
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_native_settings", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    let snapshot = await readAgentNativeSettingsSnapshot(target);
    const openAttempts = [];
    for (let attempt = 1; snapshot.panelOpen !== true && attempt <= 3; attempt += 1) {
      if (!snapshot.controls?.triggerRect && snapshot.controls?.blockingPanelCloseRect) {
        await debuggerClick(target, pointFromRect(snapshot.controls.blockingPanelCloseRect));
        await sleep(350);
        snapshot = await readAgentNativeSettingsSnapshot(target);
      }
      if (!snapshot.controls?.triggerRect) {
        await sleep(250);
        snapshot = await readAgentNativeSettingsSnapshot(target);
      }
      if (!snapshot.controls?.triggerRect) {
        openAttempts.push({ attempt, error: "trigger_not_found" });
        continue;
      }
      const triggerRect = snapshot.controls.triggerRect;
      await debuggerClick(target, pointFromRect(triggerRect));
      snapshot = await waitForAgentNativeSettingsPanel(target, 5000);
      openAttempts.push({ attempt, triggerRect, opened: snapshot.panelOpen === true });
    }
    if (snapshot.panelOpen !== true) {
      const fallbackOpen = await debuggerEvaluate(target, `(() => {
        const control = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter((element) => {
            const rect = element.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0 && rect.width <= 48 && rect.height <= 48 && rect.y > innerHeight * 0.55;
          })
          .find((element) => Array.from(element.querySelectorAll("*")).some((child) => String(child.textContent || "").trim() === "tune"));
        if (!control || typeof control.click !== "function") return false;
        control.click();
        return true;
      })()`).catch(() => false);
      if (fallbackOpen) {
        snapshot = await waitForAgentNativeSettingsPanel(target, 6000);
      }
    }
    if (snapshot.panelOpen !== true) {
      const code = openAttempts.every((attempt) => attempt.error === "trigger_not_found")
        ? "AGENT_NATIVE_SETTINGS_TRIGGER_NOT_FOUND"
        : "AGENT_NATIVE_SETTINGS_PANEL_NOT_OPEN";
      throw agentBridgeError(code, "Flow Agent native settings panel did not open after structural trigger retries.", { snapshot, openAttempts });
    }

    const desired = plan?.desired || {};
    const mutations = planAgentNativeSettingsMutations(snapshot, desired);
    const applied = [];
    for (const mutation of mutations) {
      if (mutation.control === "model") {
        const modelRect = snapshot.controls?.[mutation.section]?.modelRect;
        if (!modelRect) {
          throw agentBridgeError("AGENT_NATIVE_SETTINGS_CONTROL_NOT_FOUND", `Flow Agent ${mutation.section} model control was not found structurally.`, { mutation, snapshot });
        }
        await debuggerClick(target, pointFromRect(modelRect));
        await sleep(180);
        const optionsFound = await readAgentNativeModelOptions(target, mutation.section);
        const modelOption = optionsFound.find((entry) => entry.model === mutation.value);
        if (!modelOption?.rect) {
          await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyDown", key: "Escape", code: "Escape" }).catch(() => {});
          await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyUp", key: "Escape", code: "Escape" }).catch(() => {});
          throw agentBridgeError("AGENT_NATIVE_MODEL_UNAVAILABLE", `Requested Flow Agent ${mutation.section} model is not available.`, {
            requestedModel: mutation.value,
            availableModels: optionsFound.map((entry) => entry.model).filter(Boolean)
          });
        }
        await debuggerClick(target, pointFromRect(modelOption.rect));
      } else {
        const rect = agentNativeSettingsMutationRect(snapshot, mutation);
        if (!rect) {
          throw agentBridgeError("AGENT_NATIVE_SETTINGS_CONTROL_NOT_FOUND", `Flow Agent ${mutation.section} ${mutation.control} control was not found structurally.`, { mutation, snapshot });
        }
        await debuggerClick(target, pointFromRect(rect));
      }
      applied.push(mutation);
      await sleep(160);
      snapshot = await readAgentNativeSettingsSnapshot(target);
    }

    if (applied.length) {
      if (!snapshot.controls?.saveRect) {
        throw agentBridgeError("AGENT_NATIVE_SETTINGS_SAVE_NOT_FOUND", "Flow Agent native settings save control was not found structurally.", snapshot);
      }
      await debuggerClick(target, pointFromRect(snapshot.controls.saveRect));
      await sleep(450);
      snapshot = await readAgentNativeSettingsSnapshot(target);
      if (snapshot.panelOpen !== true) {
        if (!snapshot.controls?.triggerRect) {
          throw agentBridgeError("AGENT_NATIVE_SETTINGS_REOPEN_FAILED", "Flow Agent native settings could not be reopened for post-save verification.", snapshot);
        }
        await debuggerClick(target, pointFromRect(snapshot.controls.triggerRect));
        snapshot = await waitForAgentNativeSettingsPanel(target, 5000);
      }
    }

    const verification = verifyAgentNativeSettings(snapshot, desired);
    if (!verification.ok) {
      throw agentBridgeError(verification.code || "AGENT_NATIVE_SETTINGS_VERIFY_FAILED", "Flow Agent native settings did not match the requested run after mutation.", verification);
    }
    const dismissRect = snapshot.controls?.closeRect || snapshot.controls?.saveRect;
    if (!dismissRect) {
      throw agentBridgeError("AGENT_NATIVE_SETTINGS_DISMISS_NOT_FOUND", "Flow Agent native settings were verified, but the panel had no structural close or save control.", snapshot);
    }
    await debuggerClick(target, pointFromRect(dismissRect));
    let closedSnapshot = await waitForAgentNativeSettingsClosed(target, 5000);
    if (closedSnapshot.panelOpen === true) {
      // A transient Flow toast can cover the trusted close coordinate after a
      // settings mutation. This is navigation-only: re-resolve the exact
      // compact close/back icon and invoke it once instead of leaving the
      // verified settings drawer open before composer preflight.
      const fallbackClosed = await debuggerEvaluate(target, `(() => {
        const visible = (element) => {
          if (!element?.getBoundingClientRect) return false;
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);
          return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
        };
        const controls = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter(visible)
          .map((element) => {
            const rect = element.getBoundingClientRect();
            const tokens = Array.from(element.querySelectorAll("*")).map((child) => String(child.textContent || "").trim());
            const close = tokens.includes("close");
            const back = tokens.includes("arrow_back");
            return { element, rect, close, back };
          })
          .filter((entry) => (entry.close || entry.back)
            && entry.rect.width <= 72 && entry.rect.height <= 72
            && entry.rect.x > innerWidth * 0.55 && entry.rect.y < innerHeight * 0.25)
          .sort((left, right) => Number(right.close) - Number(left.close) || right.rect.x - left.rect.x);
        const control = controls[0]?.element || null;
        if (!control || typeof control.click !== "function") return false;
        control.click();
        return true;
      })()`).catch(() => false);
      if (fallbackClosed) closedSnapshot = await waitForAgentNativeSettingsClosed(target, 5000);
    }
    if (closedSnapshot.panelOpen === true) {
      throw agentBridgeError("AGENT_NATIVE_SETTINGS_PANEL_NOT_CLOSED", "Flow Agent native settings were verified, but the panel did not close before composer preflight.", closedSnapshot);
    }
    recordEvent({
      type: "agent_bridge.native_settings.verified",
      tabId,
      requestKind: compactString(options.requestKind),
      changed: applied.length > 0,
      mutationCount: applied.length
    });
    return {
      ok: true,
      changed: applied.length > 0,
      applied,
      verified: true,
      desired,
      actual: agentNativeSettingsPublicSnapshot(snapshot),
      instructionOnly: plan?.instructionOnly || {}
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_NATIVE_SETTINGS_FAILED", String(error?.message || error || "Agent native settings verification failed."));
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function waitForAgentNativeSettingsPanel(target, timeoutMs = 5000) {
  const deadline = Date.now() + Math.max(500, Number(timeoutMs || 5000) || 5000);
  let snapshot = await readAgentNativeSettingsSnapshot(target);
  while (snapshot.panelOpen !== true && Date.now() < deadline) {
    await sleep(150);
    snapshot = await readAgentNativeSettingsSnapshot(target);
  }
  return snapshot;
}

async function waitForAgentNativeSettingsClosed(target, timeoutMs = 5000) {
  const deadline = Date.now() + Math.max(500, Number(timeoutMs || 5000) || 5000);
  let snapshot = await readAgentNativeSettingsSnapshot(target);
  while (snapshot.panelOpen === true && Date.now() < deadline) {
    await sleep(150);
    snapshot = await readAgentNativeSettingsSnapshot(target);
  }
  return snapshot;
}

function agentNativeSettingsMutationRect(snapshot = {}, mutation = {}) {
  if (mutation.section === "confirmation") {
    return snapshot.controls?.confirmation?.[mutation.value] || null;
  }
  const section = snapshot.controls?.[mutation.section] || {};
  if (mutation.control === "aspectRatio") return section.aspectRatios?.[mutation.value] || null;
  if (mutation.control === "outputs") return section.outputs?.[String(mutation.value)] || null;
  return null;
}

function agentNativeSettingsPublicSnapshot(snapshot = {}) {
  return {
    panelOpen: snapshot.panelOpen === true,
    confirmation: snapshot.confirmation || "",
    image: snapshot.image || null,
    video: snapshot.video || null
  };
}

async function readAgentNativeModelOptions(target, section = "") {
  const rows = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0
        && rect.left < innerWidth && rect.top < innerHeight
        && style.display !== "none" && style.visibility !== "hidden";
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    return Array.from(document.querySelectorAll("[role='option'],[role='menuitem'],[role='menuitemradio'],[role='listbox'] button"))
      .filter(visible)
      .map((element) => ({ text: String(element.innerText || element.textContent || "").replace(/\\s+/g, " ").trim(), rect: rectOf(element) }));
  })()`).catch(() => []);
  return (Array.isArray(rows) ? rows : []).map((row) => ({
    ...row,
    model: normalizeAgentNativeModelText(row.text, section)
  }));
}

async function readAgentNativeSettingsSnapshot(target) {
  const probe = await debuggerEvaluate(target, `(() => {
    const compact = (value = "") => String(value || "").replace(/\\s+/g, " ").trim();
    const visible = (element) => {
      if (!element?.getBoundingClientRect) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0
        && rect.left < innerWidth && rect.top < innerHeight
        && style.display !== "none" && style.visibility !== "hidden";
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const textOf = (element) => compact(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "");
    const tokensOf = (element) => new Set(textOf(element).toLowerCase().split(/[^a-z0-9_:.-]+/).filter(Boolean));
    const buttons = Array.from(document.querySelectorAll("button,[role='button'],[role='tab'],[role='radio']")).filter(visible);
    const radios = buttons.filter((element) => element.getAttribute("role") === "radio" && ["ALWAYS_ASK", "AUTO_APPROVE"].includes(String(element.value || element.getAttribute("value") || "")));
    const panelOpen = radios.length === 2;
    const trigger = buttons
      .filter((element) => tokensOf(element).has("tune"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width <= 48 && rect.height <= 48 && rect.y > innerHeight * 0.55;
      })[0] || null;
    if (!panelOpen) {
      const hasInstructionEditor = Array.from(document.querySelectorAll("textarea,[role='switch']")).some(visible);
      const blockingPanelClose = hasInstructionEditor
        ? buttons.map((element) => ({ element, rect: element.getBoundingClientRect() }))
          .filter((entry) => entry.rect.width > 240 && entry.rect.y > innerHeight * 0.8)
          .sort((left, right) => right.rect.y - left.rect.y)[0]?.element || null
        : null;
      return {
        panelOpen: false,
        triggerRect: trigger ? rectOf(trigger) : null,
        blockingPanelCloseRect: blockingPanelClose ? rectOf(blockingPanelClose) : null
      };
    }
    const tabs = buttons.filter((element) => element.getAttribute("role") === "tab").map((element) => ({
      text: textOf(element),
      tokens: [...tokensOf(element)],
      selected: element.getAttribute("aria-selected") === "true" || element.getAttribute("data-state") === "active",
      rect: rectOf(element)
    }));
    const ratioValue = (entry) => {
      if (entry.tokens.includes("16:9")) return "16:9";
      if (entry.tokens.includes("4:3")) return "4:3";
      if (entry.tokens.includes("1:1")) return "1:1";
      if (entry.tokens.includes("3:4")) return "3:4";
      if (entry.tokens.includes("9:16")) return "9:16";
      return "";
    };
    const outputValue = (entry) => {
      const match = entry.text.toLowerCase().match(/(?:^|\\s)(?:x(\\d)|([1-4])x)(?:$|\\s)/);
      return match ? Number(match[1] || match[2]) : 0;
    };
    const groups = (entries) => {
      const result = [];
      for (const entry of entries.sort((a, b) => a.rect.y - b.rect.y || a.rect.x - b.rect.x)) {
        const group = result.find((candidate) => Math.abs(candidate.y - entry.rect.y) <= 4);
        if (group) group.entries.push(entry);
        else result.push({ y: entry.rect.y, entries: [entry] });
      }
      return result;
    };
    const ratioGroups = groups(tabs.filter((entry) => ratioValue(entry)));
    const outputGroups = groups(tabs.filter((entry) => outputValue(entry)));
    const imageRatios = ratioGroups.find((group) => group.entries.length >= 5) || null;
    const videoRatios = ratioGroups.find((group) => group.entries.length === 2 && (!imageRatios || group.y > imageRatios.y)) || null;
    const imageOutputs = outputGroups.find((group) => !imageRatios || group.y > imageRatios.y && (!videoRatios || group.y < videoRatios.y)) || null;
    const videoOutputs = outputGroups.find((group) => videoRatios && group.y > videoRatios.y) || null;
    const modelButtons = buttons.map((element) => ({ element, text: textOf(element), rect: rectOf(element) }))
      .filter((entry) => entry.rect.width > 240 && /arrow_drop_down/i.test(entry.text));
    const imageModel = modelButtons.find((entry) => imageOutputs && entry.rect.y > imageOutputs.y && (!videoRatios || entry.rect.y < videoRatios.y)) || null;
    const videoModel = modelButtons.find((entry) => videoOutputs && entry.rect.y > videoOutputs.y) || null;
    const panelLeft = Math.min(...radios.map((element) => element.getBoundingClientRect().x));
    const close = buttons.find((element) => tokensOf(element).has("close") && element.getBoundingClientRect().x >= panelLeft) || null;
    const back = buttons.find((element) => {
      const rect = element.getBoundingClientRect();
      return tokensOf(element).has("arrow_back") && rect.x >= panelLeft && rect.width <= 48 && rect.height <= 48;
    }) || null;
    const save = buttons.map((element) => ({ element, rect: element.getBoundingClientRect() }))
      .filter((entry) => entry.rect.x >= panelLeft && entry.rect.width > 240 && entry.rect.y > innerHeight * 0.8)
      .sort((left, right) => right.rect.y - left.rect.y)[0]?.element || null;
    const mapGroup = (group, valueOf) => Object.fromEntries((group?.entries || []).map((entry) => [String(valueOf(entry)), entry.rect]).filter(([key]) => key && key !== "0"));
    const selected = (group, valueOf) => valueOf((group?.entries || []).find((entry) => entry.selected) || {});
    return {
      panelOpen: true,
      triggerRect: trigger ? rectOf(trigger) : null,
      closeRect: close ? rectOf(close) : null,
      backRect: back ? rectOf(back) : null,
      saveRect: save ? rectOf(save) : null,
      confirmation: radios.find((element) => element.getAttribute("aria-checked") === "true")?.value || "",
      confirmationRects: Object.fromEntries(radios.map((element) => [String(element.value || ""), rectOf(element)])),
      image: {
        aspectRatio: selected(imageRatios, ratioValue),
        outputs: selected(imageOutputs, outputValue),
        modelText: imageModel?.text || "",
        aspectRatios: mapGroup(imageRatios, ratioValue),
        outputRects: mapGroup(imageOutputs, outputValue),
        modelRect: imageModel?.rect || null
      },
      video: {
        aspectRatio: selected(videoRatios, ratioValue),
        outputs: selected(videoOutputs, outputValue),
        modelText: videoModel?.text || "",
        aspectRatios: mapGroup(videoRatios, ratioValue),
        outputRects: mapGroup(videoOutputs, outputValue),
        modelRect: videoModel?.rect || null
      }
    };
  })()`).catch((error) => ({ panelOpen: false, error: String(error?.message || error || "agent_native_settings_probe_failed") }));
  const imageModel = normalizeAgentNativeModelText(probe?.image?.modelText || "", "image");
  const videoModel = normalizeAgentNativeModelText(probe?.video?.modelText || "", "video");
  return {
    panelOpen: probe?.panelOpen === true,
    confirmation: probe?.confirmation || "",
    image: probe?.panelOpen ? { aspectRatio: probe.image?.aspectRatio || "", outputs: Number(probe.image?.outputs || 0), model: imageModel } : null,
    video: probe?.panelOpen ? { aspectRatio: probe.video?.aspectRatio || "", outputs: Number(probe.video?.outputs || 0), model: videoModel } : null,
    controls: {
      triggerRect: probe?.triggerRect || null,
      blockingPanelCloseRect: probe?.blockingPanelCloseRect || null,
      closeRect: probe?.closeRect || null,
      backRect: probe?.backRect || null,
      saveRect: probe?.saveRect || null,
      confirmation: probe?.confirmationRects || {},
      image: {
        aspectRatios: probe?.image?.aspectRatios || {},
        outputs: probe?.image?.outputRects || {},
        modelRect: probe?.image?.modelRect || null
      },
      video: {
        aspectRatios: probe?.video?.aspectRatios || {},
        outputs: probe?.video?.outputRects || {},
        modelRect: probe?.video?.modelRect || null
      }
    },
    error: probe?.error || ""
  };
}

async function ensureManagedAgentInstructionsWithDebugger(tabId = 0, options = {}) {
  const startedAt = Date.now();
  const timings = {};
  const markTiming = (name) => { timings[name] = Date.now() - startedAt; };
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent Instructions verification.");
  }
  const protocol = managedAgentProtocol();
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_managed_instructions_preflight", recordDebuggerTrace).catch(() => null);
  markTiming("sessionsReleasedMs");
  let attached = false;
  let panelMayBeOpen = false;
  let instructionZoomChanged = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    markTiming("attachedMs");
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});

    let state = await readManagedAgentInstructionsPanel(target);
    if (!state.panelOpen) {
      if (!state.instructionsControlRect) {
        throw agentBridgeError("AGENT_INSTRUCTIONS_CONTROL_NOT_FOUND", "Flow Agent Instructions control was not found structurally.", state);
      }
      await clickManagedAgentInstructionControl(target, state.instructionsControlRect);
      panelMayBeOpen = true;
      state = await waitForManagedAgentInstructionsPanel(target);
    } else {
      panelMayBeOpen = true;
    }
    if (!state.panelOpen) {
      state = await readManagedAgentInstructionsPanel(target);
      if (state.instructionsControlRect) {
        await clickManagedAgentInstructionControlInDom(target, state.instructionsControlRect);
        panelMayBeOpen = true;
        state = await waitForManagedAgentInstructionsPanel(target, 4000);
      }
    }
    if (!state.panelOpen) {
      throw agentBridgeError("AGENT_INSTRUCTIONS_PANEL_NOT_OPEN", "Flow Agent Instructions panel did not open.", state);
    }
    // The panel shell/done control can render before instruction cards and the
    // add control. Wait for one actionable card surface instead of treating
    // that transient shell as an empty instruction list.
    if (!state.managedEditorVisible && !state.managedTitleRect && !state.addInstructionRect) {
      const settleDeadline = Date.now() + 2000;
      while (Date.now() < settleDeadline && !state.managedEditorVisible && !state.managedTitleRect && !state.addInstructionRect) {
        await sleep(150);
        state = await readManagedAgentInstructionsPanel(target);
      }
      // Compact Flow occasionally opens only the Instructions shell after a
      // trusted CDP click. Close that empty shell and retry the non-spending
      // panel opener through the exact page element; all settings, refs, and
      // submit controls remain trusted CDP clicks.
      if (!state.managedEditorVisible && !state.managedTitleRect && !state.addInstructionRect && state.doneRect) {
        await clickManagedAgentInstructionControl(target, state.doneRect);
        panelMayBeOpen = false;
        await sleep(500);
        state = await readManagedAgentInstructionsPanel(target);
        if (state.instructionsControlRect) {
          await clickManagedAgentInstructionControlInDom(target, state.instructionsControlRect);
          panelMayBeOpen = true;
          state = await waitForManagedAgentInstructionsPanel(target, 4000);
          await sleep(350);
          state = await readManagedAgentInstructionsPanel(target);
        }
        if (!state.managedEditorVisible && !state.managedTitleRect && !state.addInstructionRect) {
          const currentZoom = await chrome.tabs.getZoom(tabId).catch(() => 1);
          if (currentZoom < 1) {
            await chrome.tabs.setZoom(tabId, 1);
            instructionZoomChanged = true;
            await sleep(1000);
            state = await readManagedAgentInstructionsPanel(target);
          }
        }
      }
    }
    markTiming("panelOpenedMs");

    if (state.managedTitleRect && !state.managedEditorVisible) {
      await clickManagedAgentInstructionControl(target, state.managedTitleRect);
      await sleep(350);
      state = await readManagedAgentInstructionsPanel(target);
    }
    if (!state.managedEditorVisible) {
      if (!state.addInstructionRect) {
        throw agentBridgeError("AGENT_INSTRUCTIONS_ADD_CONTROL_NOT_FOUND", "Flow Agent Instructions add control was not found structurally.", state);
      }
      await markExistingAgentInstructionEditors(target);
      await clickManagedAgentInstructionControl(target, state.addInstructionRect);
      state = await waitForNewManagedAgentInstructionEditor(target);
    }
    if (!state.managedEditorVisible) {
      throw agentBridgeError("AGENT_INSTRUCTIONS_EDITOR_NOT_FOUND", "Flow Agent Instructions editor did not appear.", state);
    }
    markTiming("editorReadyMs");

    const before = verifyManagedAgentProtocol({
      title: state.managedTitle,
      body: state.managedBody,
      enabled: state.managedEnabled
    }, protocol, { titleRequired: false });
    let managedProtocolChanged = false;
    if (!before.bodyMatches) {
      const updated = await writeManagedAgentInstructionFields(target, protocol);
      if (!updated?.ok) {
        throw agentBridgeError("AGENT_INSTRUCTIONS_WRITE_FAILED", "Managed Agent Instructions could not be written.", updated || {});
      }
      managedProtocolChanged = true;
      await sleep(450);
      state = await readManagedAgentInstructionsPanel(target);
    }
    if (state.managedEnabled !== true) {
      if (!state.managedToggleRect) {
        throw agentBridgeError("AGENT_INSTRUCTIONS_TOGGLE_NOT_FOUND", "Managed Agent Instructions toggle could not be verified.", state);
      }
      await clickManagedAgentInstructionControl(target, state.managedToggleRect);
      managedProtocolChanged = true;
      await sleep(300);
      state = await readManagedAgentInstructionsPanel(target);
    }
    if (!state.doneRect) {
      throw agentBridgeError("AGENT_INSTRUCTIONS_DONE_CONTROL_NOT_FOUND", "Flow Agent Instructions completion control was not found structurally.", state);
    }
    await clickManagedAgentInstructionControl(target, state.doneRect);
    panelMayBeOpen = false;
    await sleep(650);
    markTiming("firstCloseMs");

    let verificationPanel = state;
    if (managedProtocolChanged) {
      verificationPanel = await readManagedAgentInstructionsPanel(target);
    }
    if (managedProtocolChanged && !verificationPanel.panelOpen) {
      if (!verificationPanel.instructionsControlRect) {
        throw agentBridgeError("AGENT_INSTRUCTIONS_CONTROL_NOT_FOUND", "Flow Agent Instructions control disappeared before verification.", verificationPanel);
      }
      await clickManagedAgentInstructionControl(target, verificationPanel.instructionsControlRect);
      panelMayBeOpen = true;
      verificationPanel = await waitForManagedAgentInstructionsPanel(target);
    }
    if (managedProtocolChanged && verificationPanel.managedTitleRect && !verificationPanel.managedEditorVisible) {
      await clickManagedAgentInstructionControl(target, verificationPanel.managedTitleRect);
      await sleep(300);
      verificationPanel = await readManagedAgentInstructionsPanel(target);
    }
    markTiming("verificationPanelReadyMs");
    const verification = verifyManagedAgentProtocol({
      title: verificationPanel.managedTitle,
      body: verificationPanel.managedBody,
      enabled: verificationPanel.managedEnabled
    }, protocol, { titleRequired: false });
    if (!verification.ok) {
      throw agentBridgeError("AGENT_MANAGED_PROTOCOL_UNVERIFIED", "Managed Agent Instructions did not round-trip with the expected title, body hash, and enabled toggle.", {
        ...verification,
        panel: verificationPanel
      });
    }
    if (managedProtocolChanged && verificationPanel.doneRect) {
      await clickManagedAgentInstructionControl(target, verificationPanel.doneRect);
      panelMayBeOpen = false;
      await sleep(250);
    }
    recordEvent({
      type: "agent_bridge.preflight.managed_protocol_verified",
      tabId,
      requestKind: compactString(options.requestKind),
      version: protocol.version,
      hash: protocol.hash
    });
    return {
      ok: true,
      version: protocol.version,
      title: protocol.title,
      hash: protocol.hash,
      enabled: true,
      action: before.action,
      verifiedAt: new Date().toISOString(),
      durationMs: Date.now() - startedAt,
      timings
    };
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_MANAGED_PROTOCOL_PREFLIGHT_FAILED", String(error?.message || error || "Managed Agent Instructions preflight failed."));
  } finally {
    if (attached && panelMayBeOpen) {
      const state = await readManagedAgentInstructionsPanel(target).catch(() => null);
      if (state?.doneRect) await clickManagedAgentInstructionControl(target, state.doneRect).catch(() => {});
    }
    if (attached) await chrome.debugger.detach(target).catch(() => {});
    if (instructionZoomChanged) {
      await chrome.tabs.setZoom(tabId, 0.8).catch(() => {});
      await sleep(300);
    }
  }
}

async function clickManagedAgentInstructionControlInDom(target, rect = {}) {
  const result = await debuggerEvaluate(target, `(() => {
    const control = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && rect.width <= 80 && rect.height <= 80;
      })
      .find((element) => new Set(String(element.innerText || element.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean)).has("article_spark"));
    if (!control || typeof control.click !== "function") return { ok: false };
    control.click();
    return { ok: true };
  })()`).catch(() => ({ ok: false }));
  if (!result?.ok) throw agentBridgeError("AGENT_INSTRUCTIONS_CONTROL_CLICK_FAILED", "Flow Agent Instructions fallback opener was not available.", result || {});
  return result;
}

async function clickManagedAgentInstructionControl(target, rect = {}) {
  if (!rect || !Number(rect.width || 0) || !Number(rect.height || 0)) {
    throw agentBridgeError("AGENT_INSTRUCTIONS_CONTROL_CLICK_FAILED", "Flow Agent Instructions control had no trusted click target.", { rect });
  }
  await debuggerClick(target, pointFromRect(rect));
  return { ok: true, trusted: true, rect };
}

async function waitForManagedAgentInstructionsPanel(target, timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    state = await readManagedAgentInstructionsPanel(target);
    if (state.panelOpen) return state;
    await sleep(150);
  }
  return state || { panelOpen: false };
}

async function markExistingAgentInstructionEditors(target) {
  return debuggerEvaluate(target, `(() => {
    const editors = Array.from(document.querySelectorAll("textarea"))
      .filter((element) => element.getBoundingClientRect().x >= window.innerWidth * 0.75);
    editors.forEach((element) => element.setAttribute("data-autoflow-existing-agent-instruction", "1"));
    return { marked: editors.length };
  })()`).catch(() => ({ marked: 0 }));
}

async function waitForNewManagedAgentInstructionEditor(target, timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  let state = null;
  while (Date.now() < deadline) {
    await debuggerEvaluate(target, `(() => {
      const editor = Array.from(document.querySelectorAll("textarea"))
        .filter((element) => element.getBoundingClientRect().x >= window.innerWidth * 0.75)
        .filter((element) => element.getAttribute("data-autoflow-existing-agent-instruction") !== "1")
        .sort((left, right) => right.getBoundingClientRect().y - left.getBoundingClientRect().y)[0] || null;
      if (!editor) return false;
      editor.setAttribute("data-autoflow-managed-agent-instruction", "1");
      return true;
    })()`).catch(() => false);
    state = await readManagedAgentInstructionsPanel(target);
    if (state.managedEditorVisible) return state;
    await sleep(150);
  }
  return state || { panelOpen: true, managedEditorVisible: false };
}

async function readManagedAgentInstructionsPanel(target) {
  return debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom > 0 && rect.top < window.innerHeight;
    };
    const textOf = (element) => String(element?.value ?? element?.innerText ?? element?.textContent ?? "").trim();
    const rectOf = (element) => {
      if (!element) return null;
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const iconTokens = (element) => new Set(String(element?.innerText || element?.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
    const controls = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(visible)
      .map((element) => ({ element, rect: element.getBoundingClientRect(), tokens: iconTokens(element), text: textOf(element) }));
    const instructionsControl = controls
      .filter((entry) => entry.tokens.has("article_spark") && entry.rect.width <= 80 && entry.rect.height <= 80)
      .sort((left, right) => right.rect.x - left.rect.x)[0] || null;
    const panelLeft = window.innerWidth * 0.75;
    const rightTextareas = Array.from(document.querySelectorAll("textarea"))
      .filter(visible)
      .filter((element) => element.getBoundingClientRect().x >= panelLeft);
    const rightSwitches = Array.from(document.querySelectorAll("[role='switch']"))
      .filter(visible)
      .filter((element) => element.getBoundingClientRect().x >= panelLeft);
    const addInstruction = controls
      .filter((entry) => entry.rect.x >= panelLeft && entry.rect.width >= 150 && entry.rect.y < window.innerHeight * 0.35 && entry.tokens.has("add"))
      .sort((left, right) => right.rect.width - left.rect.width)[0] || null;
    const done = controls
      .filter((entry) => entry.rect.x >= panelLeft && entry.rect.width >= 150 && entry.rect.y >= window.innerHeight * 0.75)
      .sort((left, right) => right.rect.y - left.rect.y)[0] || null;
    // A wide lower-right button is not sufficient panel evidence: the open
    // conversation drawer can place its wide See-all media button in the same
    // geometry as Instructions' completion control. Require an Instructions-
    // specific editor, switch, or add-entry structure before treating the
    // surface as open; the done control is only a dismiss target after that proof.
    const panelOpen = Boolean(rightTextareas.length || rightSwitches.length || addInstruction);
    const managedTextarea = rightTextareas.find((element) => /AUTO FLOW AGENT CONTRACT\\s*[—-]\\s*AUTOMATION PROTOCOL/i.test(textOf(element)))
      || rightTextareas.find((element) => element.getAttribute("data-autoflow-managed-agent-instruction") === "1")
      || null;
    const titleInputs = Array.from(document.querySelectorAll("input,[contenteditable='true']"))
      .filter(visible)
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.x >= panelLeft && rect.y < window.innerHeight * 0.5;
      });
    const namedTitle = titleInputs.find((element) => /^Auto Flow Automation Protocol v\\d+$/i.test(textOf(element))) || null;
    const managedTitleInput = namedTitle || (managedTextarea
      ? titleInputs
        .filter((element) => element.getBoundingClientRect().y <= managedTextarea.getBoundingClientRect().y)
        .sort((left, right) => right.getBoundingClientRect().y - left.getBoundingClientRect().y)[0] || null
      : null);
    const titleNodes = Array.from(document.querySelectorAll("input,[contenteditable='true'],div,span,p"))
      .filter(visible)
      .filter((element) => element.getBoundingClientRect().x >= panelLeft)
      .filter((element) => /^Auto Flow Automation Protocol v\\d+$/i.test(textOf(element)));
    const titleNode = namedTitle || titleNodes.sort((left, right) => left.getBoundingClientRect().width - right.getBoundingClientRect().width)[0] || null;
    let managedSwitch = null;
    if (managedTextarea) {
      const textareaRect = managedTextarea.getBoundingClientRect();
      managedSwitch = rightSwitches
        .map((element) => ({ element, distance: Math.abs(element.getBoundingClientRect().y - textareaRect.y) }))
        .sort((left, right) => left.distance - right.distance)[0]?.element || null;
    } else if (titleNode) {
      const titleRect = titleNode.getBoundingClientRect();
      managedSwitch = rightSwitches
        .map((element) => ({ element, distance: Math.abs(element.getBoundingClientRect().y - titleRect.y) }))
        .sort((left, right) => left.distance - right.distance)[0]?.element || null;
    }
    return {
      panelOpen,
      instructionsControlRect: rectOf(instructionsControl?.element),
      addInstructionRect: rectOf(addInstruction?.element),
      doneRect: rectOf(done?.element),
      managedEditorVisible: Boolean(managedTextarea),
      managedTitle: textOf(managedTitleInput || titleNode),
      managedBody: textOf(managedTextarea),
      managedEnabled: managedSwitch ? (managedSwitch.getAttribute("aria-checked") === "true" || managedSwitch.getAttribute("data-state") === "checked") : false,
      managedToggleRect: rectOf(managedSwitch),
      managedTitleRect: rectOf(titleNode),
      instructionCount: rightSwitches.length,
      textareaCount: rightTextareas.length
    };
  })()`).catch((error) => ({ panelOpen: false, error: String(error?.message || error || "agent_instructions_probe_failed") }));
}

async function writeManagedAgentInstructionFields(target, protocol = {}) {
  const prepared = await debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const panelLeft = window.innerWidth * 0.75;
    const textarea = Array.from(document.querySelectorAll("textarea"))
      .filter(visible)
      .filter((element) => element.getBoundingClientRect().x >= panelLeft)
      .find((element) => /AUTO FLOW AGENT CONTRACT\\s*[—-]\\s*AUTOMATION PROTOCOL/i.test(String(element.value || "")))
      || Array.from(document.querySelectorAll("textarea"))
        .filter(visible)
        .find((element) => element.getBoundingClientRect().x >= panelLeft && element.getAttribute("data-autoflow-managed-agent-instruction") === "1");
    if (!textarea) return { ok: false, error: "managed_textarea_missing" };
    const title = Array.from(document.querySelectorAll("input,[contenteditable='true']"))
      .filter(visible)
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        return rect.x >= panelLeft && rect.y <= textarea.getBoundingClientRect().y;
      })
      .sort((left, right) => right.getBoundingClientRect().y - left.getBoundingClientRect().y)[0] || null;
    if (!title) return { ok: false, error: "managed_title_missing" };
    title.setAttribute("data-autoflow-managed-instruction-title", "1");
    textarea.setAttribute("data-autoflow-managed-instruction-body", "1");
    return { ok: true };
  })()`).catch((error) => ({ ok: false, error: String(error?.message || error || "agent_instructions_prepare_failed") }));
  if (!prepared?.ok) return prepared;

  const titleUpdated = await replaceManagedAgentInstructionField(target, "data-autoflow-managed-instruction-title", protocol.title);
  if (!titleUpdated?.ok) return { ...titleUpdated, field: "title" };
  const bodyUpdated = await replaceManagedAgentInstructionField(target, "data-autoflow-managed-instruction-body", protocol.body);
  if (!bodyUpdated?.ok) return { ...bodyUpdated, field: "body" };
  return {
    ok: true,
    titleUpdated: true,
    bodyUpdated: true,
    title: titleUpdated.value,
    bodyLength: bodyUpdated.valueLength
  };
}

async function replaceManagedAgentInstructionField(target, attribute = "", value = "") {
  const selected = await debuggerEvaluate(target, `((attribute) => {
    const element = document.querySelector("[" + attribute + "='1']");
    if (!element) return { ok: false, error: "managed_field_missing" };
    element.focus?.({ preventScroll: true });
    const tag = String(element.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea") {
      element.select?.();
      return { ok: true, selected: tag };
    }
    const selection = window.getSelection?.();
    const range = document.createRange();
    range.selectNodeContents(element);
    selection?.removeAllRanges?.();
    selection?.addRange?.(range);
    return { ok: true, selected: "contenteditable" };
  })(${JSON.stringify(attribute)})`).catch((error) => ({ ok: false, error: String(error?.message || error || "managed_field_select_failed") }));
  if (!selected?.ok) return selected;
  await debuggerSend(target, "Input.insertText", { text: String(value || "") });
  await sleep(120);
  return debuggerEvaluate(target, `((attribute) => {
    const element = document.querySelector("[" + attribute + "='1']");
    if (!element) return { ok: false, error: "managed_field_missing_after_insert" };
    const value = String(element.value ?? element.innerText ?? element.textContent ?? "");
    return { ok: true, value, valueLength: value.length };
  })(${JSON.stringify(attribute)})`).catch((error) => ({ ok: false, error: String(error?.message || error || "managed_field_verify_failed") }));
}

async function installAgentToolTelemetryCapture(target) {
  const result = await debuggerEvaluate(target, `(() => {
    const STORE_KEY = "__autoflowAgentToolTelemetry";
    const WRAPPED_KEY = "__autoflowAgentFetchWrappedV2";
    const store = window[STORE_KEY] && typeof window[STORE_KEY] === "object"
      ? window[STORE_KEY]
      : { sequence: 0, records: [] };
    window[STORE_KEY] = store;
    if (window[WRAPPED_KEY] === true) return { ok: true, baselineSequence: store.sequence, alreadyInstalled: true };
    const originalFetch = window.fetch;
    if (typeof originalFetch !== "function") return { ok: false, error: "fetch_unavailable", baselineSequence: store.sequence };
    window.fetch = async function autoflowObservedFetch(input, init) {
      const url = String(typeof input === "string" ? input : (input && input.url) || "");
      const response = await originalFetch.apply(this, arguments);
      if (!/flowCreationAgent:streamChat/i.test(url)) return response;
      const record = {
        sequence: ++store.sequence,
        url,
        startedAt: new Date().toISOString(),
        completedAt: "",
        completed: false,
        status: Number(response.status || 0),
        body: "",
        bodyBytes: 0,
        error: ""
      };
      store.records.push(record);
      if (store.records.length > 12) store.records.splice(0, store.records.length - 12);
      try {
        const clone = response.clone();
        const reader = clone.body?.getReader?.();
        if (!reader) throw new Error("stream_clone_reader_unavailable");
        const decoder = new TextDecoder();
        (async () => {
          try {
            while (true) {
              const chunk = await reader.read();
              if (chunk.done) break;
              const text = decoder.decode(chunk.value, { stream: true });
              record.bodyBytes += chunk.value?.byteLength || text.length;
              if (record.body.length < 2 * 1024 * 1024) {
                record.body = (record.body + text).slice(0, 2 * 1024 * 1024);
              }
            }
            const tail = decoder.decode();
            if (tail && record.body.length < 2 * 1024 * 1024) {
              record.body = (record.body + tail).slice(0, 2 * 1024 * 1024);
            }
          } catch (error) {
            record.error = String(error && error.message || error || "stream_clone_read_failed");
          } finally {
            record.completed = true;
            record.completedAt = new Date().toISOString();
          }
        })();
      } catch (error) {
        record.error = String(error && error.message || error || "stream_clone_failed");
        record.completed = true;
        record.completedAt = new Date().toISOString();
      }
      return response;
    };
    window[WRAPPED_KEY] = true;
    return { ok: true, baselineSequence: store.sequence, alreadyInstalled: false };
  })()`);
  return result || { ok: false, error: "telemetry_capture_install_failed", baselineSequence: 0 };
}

async function waitForAgentToolTelemetry(target, baselineSequence = 0, options = {}) {
  const timeoutMs = Math.max(1000, Math.min(Number(options.timeoutMs || 20000) || 20000, 30000));
  const deadline = Date.now() + timeoutMs;
  let latest = null;
  do {
    latest = await debuggerEvaluate(target, `(() => {
      const store = window.__autoflowAgentToolTelemetry;
      if (!store || !Array.isArray(store.records)) return null;
      const baseline = ${JSON.stringify(Number(baselineSequence || 0))};
      const record = store.records.filter((entry) => Number(entry.sequence || 0) > baseline).sort((left, right) => Number(right.sequence || 0) - Number(left.sequence || 0))[0];
      return record ? { ...record } : null;
    })()`).catch(() => latest);
    if (latest?.completed === true) break;
    await sleep(200);
  } while (Date.now() < deadline);
  if (!latest) return { ok: false, code: "AGENT_TOOL_TELEMETRY_UNAVAILABLE", reason: "stream_not_observed", timeoutMs };
  if (latest.completed !== true) return { ok: false, code: "AGENT_TOOL_TELEMETRY_UNAVAILABLE", reason: "stream_not_complete", timeoutMs, record: latest };
  const telemetry = parseAgentSseTelemetry(latest.body || "");
  return {
    ok: telemetry.ok === true,
    code: telemetry.ok === true ? "" : "AGENT_TOOL_TELEMETRY_UNAVAILABLE",
    record: {
      sequence: latest.sequence,
      url: latest.url,
      status: latest.status,
      startedAt: latest.startedAt,
      completedAt: latest.completedAt,
      bodyBytes: latest.bodyBytes,
      error: latest.error
    },
    telemetry
  };
}

async function executeAgentPromptWithDebugger(tabId = 0, options = {}) {
  if (!tabId || typeof chrome.debugger?.attach !== "function") {
    throw agentBridgeError("AGENT_DEBUGGER_UNAVAILABLE", "Chrome debugger is not available for Agent prompt submission.");
  }
  if (runtimeState.queueRunning && options.allowQueueInterrupt !== true) {
    throw agentBridgeError(
      "AGENT_TARGET_BUSY",
      "Auto Flow is already running a queue in this profile. Stop the queue before driving Agent Mode from the bridge.",
      { queueRunning: true, tabId }
    );
  }
  const prompt = String(options.prompt || "");
  const dryRun = options.dryRun === true;
  const target = debuggerTarget(tabId);
  await releaseDebuggerSessions("agent_bridge_prompt_submit", recordDebuggerTrace).catch(() => null);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    await debuggerSend(target, "Input.setIgnoreInputEvents", { ignore: false }).catch(() => {});
    const telemetryCapture = dryRun || options.toolContract?.required !== true
      ? { ok: true, skipped: true, baselineSequence: 0 }
      : await installAgentToolTelemetryCapture(target);

    const prepared = await debuggerEvaluate(target, `(() => {
      const visible = (element) => {
        if (!element || !element.getBoundingClientRect) return false;
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return rect.width > 0
          && rect.height > 0
          && style.display !== "none"
          && style.visibility !== "hidden"
          && rect.bottom >= 0
          && rect.top <= window.innerHeight;
      };
      const textOf = (element) => {
        if (!element) return "";
        if ("value" in element && typeof element.value === "string") return String(element.value).replace(/\\s+/g, " ").trim();
        const clone = element.cloneNode?.(true);
        clone?.querySelectorAll?.("[data-slate-placeholder='true'],[data-slate-zero-width]").forEach((node) => node.remove());
        return String(clone?.innerText || clone?.textContent || "").replace(/\\s+/g, " ").trim();
      };
      const rectOf = (element) => {
        const rect = element.getBoundingClientRect();
        return {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          right: Math.round(rect.right),
          bottom: Math.round(rect.bottom)
        };
      };
      const labelOf = (element) => [
        element?.getAttribute?.("placeholder") || "",
        element?.getAttribute?.("aria-label") || "",
        element?.getAttribute?.("role") || "",
        element?.getAttribute?.("type") || "",
        element?.getAttribute?.("name") || ""
      ].join(" ").replace(/\\s+/g, " ").trim();
      const isSearchLikeInput = (element) => {
        const tag = String(element?.tagName || "").toLowerCase();
        const type = String(element?.getAttribute?.("type") || "").toLowerCase();
        const label = labelOf(element);
        return tag === "input" && (/search|assets/i.test(label) || /search/i.test(type));
      };
      const editorEntries = Array.from(document.querySelectorAll("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
        .filter(visible)
        .filter((element) => !element.closest("[data-autoflow-rebuild], #af-bot-panel"))
        .map((element) => {
          const rect = element.getBoundingClientRect();
          const tag = String(element.tagName || "").toLowerCase();
          const type = String(element.getAttribute?.("type") || "").toLowerCase();
          const centerX = rect.x + rect.width / 2;
          let structuralComposerShell = false;
          let shell = element.parentElement;
          for (let depth = 0; shell && depth < 8; depth += 1, shell = shell.parentElement) {
            const shellRect = shell.getBoundingClientRect();
            const shellCenterX = shellRect.x + shellRect.width / 2;
            const controlTokens = new Set(Array.from(shell.querySelectorAll?.("button,[role='button']") || [])
              .flatMap((control) => String(control.innerText || control.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean)));
            const structuralActions = controlTokens.has("article_spark")
              && controlTokens.has("tune")
              && (controlTokens.has("arrow_forward") || controlTokens.has("add_2"));
            const centeredBottomShell = shellCenterX >= window.innerWidth * 0.3
              && shellCenterX <= window.innerWidth * 0.7
              && shellRect.width >= window.innerWidth * 0.25
              && shellRect.bottom > window.innerHeight * 0.75;
            if (structuralActions && centeredBottomShell) {
              structuralComposerShell = true;
              break;
            }
          }
          const isBottomRightComposer = rect.right > window.innerWidth * 0.75
            && rect.bottom > window.innerHeight * 0.7
            && rect.width > 120
            && rect.height > 80;
          // Centered / right-panel Agent layouts are not confined to the
          // bottom-right quadrant. Keep these shapes in sync with
          // isCenteredZone/isRightPanelZone in agent-submit-guard.js so the
          // submit driver and resolveAgentComposerTarget's re-validation of
          // the chosen element never disagree. The centered upper width
          // bound (<= 60% vw) keeps Flow's ordinary non-Agent main prompt
          // bar (editable, centered, low, but typically near full-width)
          // out of the centered zone only — it protects the band above
          // 0.55 * vh that the centered zone alone would accept. A
          // bottom-anchored full-width bar is instead kept out by this
          // probe's stricter base zone (rect.x > 0.55 * vw) and
          // isBottomRightComposer (height > 80) shapes; the guard's own
          // looser isBottomRightZone would accept it, a pre-existing
          // tradeoff the width bound does not change.
          // The centered height floor (>= 60px) distinguishes a real Agent
          // composer box (multi-line-capable, taller) from a short
          // single-line modal dialog input or scrubber-style control that
          // happens to be centered in the lower viewport. The height
          // ceiling (<= 35% vh) plus y-origin lower bound (>= 25% vh) keep a
          // TALL centered overlay (e.g. a fullscreen description/edit
          // textarea starting near the top of the viewport) out of this
          // zone; without them a tall enough editable overlay would
          // otherwise satisfy every other check here.
          // The right-panel shape is a best-effort geometric heuristic
          // pending live-layout verification, gated behind the same
          // editable + non-search-like requirements as every composer zone.
          // Its upper width bound (<= 40% vw) distinguishes a narrow
          // right-docked panel composer column from a wide editable
          // overlay/modal that happens to be right-anchored and tall.
          const isCenteredComposer = structuralComposerShell || (centerX >= window.innerWidth * 0.3
            && centerX <= window.innerWidth * 0.7
            && rect.width >= window.innerWidth * 0.25
            && rect.width <= window.innerWidth * 0.6
            && rect.y >= window.innerHeight * 0.25
            && rect.height >= 60
            && rect.height <= window.innerHeight * 0.35
            && rect.bottom > window.innerHeight * 0.45);
          const isRightPanelComposer = rect.right >= window.innerWidth * 0.85
            && rect.width <= window.innerWidth * 0.4
            && rect.height >= window.innerHeight * 0.35;
          const isAgentComposerZone = (rect.x > window.innerWidth * 0.55 && rect.bottom > window.innerHeight * 0.55)
            || isBottomRightComposer
            || isCenteredComposer
            || isRightPanelComposer;
          const boundedY = Math.max(0, Math.min(rect.y, window.innerHeight));
          // A zone-matching non-editable input (range/date/number/...) must
          // never become isChosen: it would either get typed into directly
          // or get authoritatively rejected by the guard's re-validation
          // even when a real text composer is also present in the
          // population. Deliberately do NOT extend this to plain <input>
          // elements (including type="text"): debuggerFocusPreparedEditor,
          // debuggerReplaceAgentEditorText, and debuggerReadComposerState
          // all query for textarea/[role=textbox]/contenteditable/
          // data-slate-editor only, never input — a chosen plain input would
          // pass this chooser but fail focus/insert/readback downstream.
          // Every known real Flow Agent composer is contenteditable/slate,
          // never a plain input, so this stays scoped to real shapes.
          const isEditable = element.matches("textarea,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']");
          const score = (isAgentComposerZone ? 10000 : 0)
            + (isEditable ? 2500 : 0)
            + (element.getAttribute("data-slate-editor") ? 1800 : 0)
            + rect.x
            + boundedY
            - (tag === "input" ? 4000 : 0);
          return {
            element,
            score,
            tag,
            type,
            text: textOf(element).slice(0, 160),
            label: labelOf(element).slice(0, 160),
            rect: rectOf(element),
            isAgentComposerZone,
            isBottomRightComposer,
            isCenteredComposer,
            isRightPanelComposer,
            isEditable,
            isSearchLikeInput: isSearchLikeInput(element)
          };
        })
        .sort((left, right) => right.score - left.score);
      const editorEntry = editorEntries
        .filter((entry) => entry.isAgentComposerZone && entry.isEditable && !entry.isSearchLikeInput)
        .sort((left, right) => right.score - left.score)[0] || null;
      // This probe only scans the top document (document.querySelectorAll),
      // so every candidate it emits is top-frame; inSubframe stays false
      // here. resolveAgentComposerTarget's subframe acceptance path is
      // exercised by candidates a multi-frame probe supplies (see
      // summarizeAgentComposerProbeFrames), not by this collector.
      // The chosen entry must survive truncation: it is always the
      // highest-scored composer-zone candidate, but a lower-scored
      // non-composer/search candidate could still occupy one of the top-8
      // slots ahead of it in edge cases, and resolveAgentComposerTarget's
      // isChosen re-validation only works if the chosen candidate is
      // actually present in the summaries it receives.
      const truncatedEntries = editorEntries.slice(0, 8);
      const summarySource = (editorEntry && !truncatedEntries.includes(editorEntry))
        ? [editorEntry, ...truncatedEntries]
        : truncatedEntries;
      const candidateSummaries = summarySource.map((entry) => ({
        tag: entry.tag,
        type: entry.type,
        text: entry.text,
        label: entry.label,
        rect: entry.rect,
        isAgentComposerZone: entry.isAgentComposerZone,
        isBottomRightComposer: entry.isBottomRightComposer,
        isCenteredComposer: entry.isCenteredComposer,
        isRightPanelComposer: entry.isRightPanelComposer,
        isEditable: entry.isEditable,
        isSearchLikeInput: entry.isSearchLikeInput,
        inSubframe: false,
        isChosen: entry === editorEntry
      }));
      const activeGeneration = Array.from(document.querySelectorAll("button,[role='button']"))
        .filter(visible)
        .some((button) => {
          const tokens = new Set(String(button.innerText || button.textContent || "").toLowerCase().split(/[^a-z0-9_]+/).filter(Boolean));
          return tokens.has("stop") || tokens.has("stop_circle");
        });
      const viewport = { width: window.innerWidth, height: window.innerHeight };
      if (!editorEntry?.element) return { ok: false, error: "AGENT_COMPOSER_NOT_FOUND", candidateSummaries, viewport, activeGeneration };
      const editor = editorEntry.element;
      return {
        ok: true,
        editorRect: rectOf(editor),
        editorFingerprint: {
          tag: String(editor.tagName || "").toLowerCase(),
          role: String(editor.getAttribute?.("role") || ""),
          contentEditable: String(editor.getAttribute?.("contenteditable") || ""),
          dataSlateEditor: editor.getAttribute?.("data-slate-editor") === "true"
        },
        originalText: textOf(editor),
        activeGeneration,
        candidateSummaries,
        viewport
      };
    })()`);
    if (!prepared?.ok || !prepared.editorRect) {
      throw agentBridgeError(prepared?.error || "AGENT_COMPOSER_NOT_FOUND", "Agent composer was not found in the Flow page.", prepared || {});
    }

    // P0-3: fail closed on composer targeting. Independently re-validate the
    // page's chosen composer against the candidate summaries so we NEVER type
    // into Flow's top search bar and never fall back to whatever element has
    // focus. If the real composer cannot be positively identified, abort with a
    // classified error instead of risking a wrong-box submit.
    const composerTarget = resolveAgentComposerTarget(prepared.candidateSummaries, prepared.viewport);
    if (!composerTarget.ok) {
      throw agentBridgeError(
        composerTarget.code || AGENT_COMPOSER_TARGET_UNRESOLVED,
        composerTarget.message || "Agent prompt composer could not be positively identified; refusing to type to avoid the Flow search bar.",
        {
          candidateSummaries: prepared.candidateSummaries,
          rejectedSearchBars: composerTarget.rejectedSearchBars || []
        }
      );
    }

    const composerPreflight = classifyAgentComposerPreflight({
      draftText: prepared.originalText,
      prompt,
      generationActive: prepared.activeGeneration === true,
      knownAutoFlowDraftHashes: options.knownAutoFlowDraftHashes,
      submittedPromptHashes: options.submittedPromptHashes,
      currentPromptSubmitted: options.currentPromptSubmitted === true
    });
    if (!composerPreflight.ok) {
      const message = composerPreflight.code === "AGENT_COMPOSER_DRAFT_CONFLICT"
        ? "Flow Agent contains an unknown user-authored draft. Auto Flow preserved it and refused to overwrite or append the new run."
        : composerPreflight.code === "AGENT_PROMPT_ALREADY_SUBMITTED"
          ? "This Auto Flow prompt was already submitted. Reconcile the existing run instead of submitting it again."
          : "Flow Agent is already generating. Reconcile the active run before submitting another prompt.";
      throw agentBridgeError(composerPreflight.code || "AGENT_COMPOSER_PREFLIGHT_BLOCKED", message, {
        state: composerPreflight.state,
        preserveDraft: composerPreflight.preserveDraft === true,
        draftHash: composerPreflight.draftHash,
        promptHash: composerPreflight.promptHash,
        draftPreview: compactString(prepared.originalText).slice(0, 160)
      });
    }

    const focus = await debuggerFocusPreparedEditor(target, {
      taskId: "agent-bridge",
      mode: "agent",
      editorRect: prepared.editorRect
    });
    if (!focus?.ok) {
      throw agentBridgeError("AGENT_COMPOSER_FOCUS_FAILED", "Agent composer could not be focused.", focus || {});
    }

    // The CDP composer insertion intermittently drops characters; re-type and
    // re-verify a few times. Verification stays strict (fail closed via
    // agentPromptInserted) so a character-mangled prompt is never submitted — we
    // only proceed on a clean round-trip, otherwise retry, then fail.
    const AGENT_INSERT_ATTEMPTS = 3;
    let activeText = composerPreflight.reuseDraft === true ? compactString(prepared.originalText) : "";
    let editorTexts = composerPreflight.reuseDraft === true ? [activeText] : [];
    let inserted = composerPreflight.reuseDraft === true;
    for (let insertAttempt = 1; !inserted && insertAttempt <= AGENT_INSERT_ATTEMPTS; insertAttempt += 1) {
      await debuggerReplaceAgentEditorText(target, prepared.editorRect, prompt);
      await sleep(350);
      const promptState = await debuggerReadComposerState(target);
      activeText = compactString(promptState.activeText || "");
      editorTexts = Array.isArray(promptState.editors) ? promptState.editors.map((editor) => compactString(editor.text)) : [];
      inserted = agentPromptInserted([activeText, ...editorTexts], prompt);
      if (inserted) break;
      if (insertAttempt < AGENT_INSERT_ATTEMPTS) {
        recordEvent({ type: "agent_bridge.prompt.insert_retry", attempt: insertAttempt });
        await sleep(250);
      }
    }
    if (!inserted) {
      throw agentBridgeError("AGENT_PROMPT_NOT_INSERTED", `Agent prompt was not inserted into the composer after ${AGENT_INSERT_ATTEMPTS} attempts.`, {
        attempts: AGENT_INSERT_ATTEMPTS,
        activeText: activeText.slice(0, 240),
        editorTexts: editorTexts.map((value) => value.slice(0, 160))
      });
    }

    const submitButton = await waitForAgentDebuggerSubmitButton(target, 10000, {
      editorRect: prepared.editorRect,
      editorFingerprint: prepared.editorFingerprint
    });
    if (!submitButton?.ok || !submitButton.rect) {
      throw agentBridgeError(submitButton?.error || "AGENT_SUBMIT_BUTTON_NOT_FOUND", "Agent submit button was not available after prompt insertion.", submitButton || {});
    }

    const result = {
      ok: true,
      submitted: false,
      dryRun,
      editor: {
        textPreview: prompt.slice(0, 240),
        rect: prepared.editorRect
      },
      submitButton: {
        text: compactString(submitButton.text).slice(0, 160),
        rect: submitButton.rect
      },
      confirmation: null,
      restored: false,
      preflight: {
        composerState: composerPreflight.state,
        draftHash: composerPreflight.draftHash,
        promptHash: composerPreflight.promptHash,
        reusedDraft: composerPreflight.reuseDraft === true,
        clearedKnownDraft: composerPreflight.clearKnownDraft === true
      }
    };

    if (dryRun) {
      const originalText = /what do you want to create/i.test(prepared.originalText || "") ? "" : String(prepared.originalText || "");
      await debuggerReplaceAgentEditorText(target, prepared.editorRect, originalText);
      await sleep(200);
      result.restored = true;
      return result;
    }

    const activeSubmitButton = submitButton;
    const submittedMessageBaseline = await readAgentSubmittedPromptMessageState(target, prompt).catch(() => ({
      matchingMessageCount: 0,
      error: "submitted_message_baseline_unavailable"
    }));
    await debuggerClick(target, pointFromRect(activeSubmitButton.rect));
    result.submitted = true;
    let submitAccepted = null;
      await sleep(900);
      const creditDialog = await findAgentDebuggerCreditDialog(target);
      if (creditDialog?.ok) {
        const creditAction = agentCreditActionFromDialog(creditDialog);
        let creditDecision = decideAgentCreditDialogApproval(creditAction, options);
        result.creditAction = creditAction;
        if (options.toolContract?.required === true) {
          const observedTool = telemetryCapture?.ok === true
            ? await waitForAgentToolTelemetry(target, telemetryCapture.baselineSequence, { timeoutMs: options.toolTelemetryTimeoutMs || 20000 })
            : { ok: false, code: "AGENT_TOOL_TELEMETRY_UNAVAILABLE", reason: telemetryCapture?.error || "capture_install_failed" };
          const telemetry = observedTool?.telemetry || {};
          const validation = observedTool?.ok === true
            ? validateAgentPendingToolContract(options.toolContract, telemetry)
            : {
                ok: false,
                code: "AGENT_TOOL_TELEMETRY_UNAVAILABLE",
                contract: options.toolContract,
                observed: {},
                mismatches: [],
                unavailable: [{ field: "agentToolStream", reason: observedTool?.reason || observedTool?.code || "not_observed" }]
              };
          result.toolTelemetry = observedTool?.record || null;
          result.toolContractValidation = validation;
          if (validation.ok !== true && creditDecision.approved === true) {
            creditDecision = {
              ...creditDecision,
              approved: false,
              reason: validation.code || "agent_tool_contract_validation_failed",
              toolContractValidation: validation
            };
          }
        }
        result.creditDecision = creditDecision;
        if (creditDecision.approved !== true) {
          result.waitingForCreditApproval = true;
          result.creditDialog = {
            state: "dialog_open",
            text: compactString(creditDialog.text).slice(0, 240),
            rect: creditDialog.rect || null
          };
        } else {
        const allowPersistentCreditApproval = options.creditPolicy?.persistentApproval === true;
        const confirmation = await findAgentDebuggerConfirmationButton(target, {
          allowPersistent: allowPersistentCreditApproval
        });
        if (confirmation?.ok && confirmation.rect) {
          assertAgentCreditConfirmationChoiceIsAffirmative(confirmation, {
            text: compactString(creditDialog.text).slice(0, 240),
            allowPersistent: allowPersistentCreditApproval
          });
          const confirmationClick = await clickAgentDebuggerConfirmationAtClickTime(target, confirmation, {
            allowPersistent: allowPersistentCreditApproval
          });
          if (!confirmationClick?.ok) {
            throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_CHANGED", "Flow credit confirmation changed before activation; Auto Flow did not click it.", {
              confirmation,
              confirmationClick,
              allowPersistent: allowPersistentCreditApproval
            });
          }
          result.confirmation = {
            clicked: true,
            text: compactString(confirmation.text).slice(0, 160),
            rect: confirmation.rect,
            persistent: confirmation.persistent === true
          };
          const remaining = await waitForAgentCreditDialogDismissed(target, { timeoutMs: 3000 });
          if (remaining?.ok) {
            throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_STILL_VISIBLE", "Flow credit confirmation was clicked, but the dialog remained visible.", {
              text: compactString(remaining.text || creditDialog.text).slice(0, 240),
              confirmation: result.confirmation
            });
          }
        } else {
          throw agentBridgeError("AGENT_CREDIT_CONFIRMATION_NOT_CLICKED", "Flow asked for credit confirmation, but Auto Flow could not find an allowed affirmative confirmation choice.", {
            text: compactString(creditDialog.text).slice(0, 240),
            probe: confirmation || null
          });
        }
        }
      }
      submitAccepted = result.waitingForCreditApproval === true
        ? {
            ok: true,
            accepted: true,
            signal: "credit_dialog_open_after_submit",
            promptStillPresent: true
          }
        : await waitForAgentDebuggerSubmitAccepted(target, prompt, {
            submitButtonRect: activeSubmitButton.rect,
            submitButtonText: activeSubmitButton.text,
            submittedMessageBaselineCount: Number(submittedMessageBaseline?.matchingMessageCount || 0)
          });
    if (!submitAccepted?.ok) {
      throw agentBridgeError("AGENT_SUBMIT_NOT_ACCEPTED", "Flow did not accept the Agent prompt submit click; refusing to click again.", submitAccepted || {});
    }
    result.accepted = submitAccepted;
    result.submittedPromptCleanup = result.waitingForCreditApproval === true
      ? { ok: true, cleared: false, reason: "credit_dialog_open" }
      : await clearAgentDebuggerSubmittedPromptAfterAcceptance(target, prepared.editorRect, prompt, submitAccepted);
    if (result.submittedPromptCleanup?.ok !== true) {
      // The submit is already durably accepted. Cleanup is post-write hygiene,
      // never a reason to turn an exactly-once accepted write into submit_error
      // (which could invite an unsafe duplicate retry).
      result.submittedPromptCleanupWarning = {
        code: "AGENT_SUBMITTED_PROMPT_CLEAR_FAILED",
        message: "Flow accepted the Agent message but retained the exact extension-authored draft.",
        cleanup: result.submittedPromptCleanup
      };
      recordEvent({
        type: "agent_bridge.composer.accepted_draft_cleanup_failed",
        level: "warning",
        acceptedSignal: compactString(submitAccepted?.signal || ""),
        cleanup: result.submittedPromptCleanup
      });
    }
    return result;
  } catch (error) {
    if (error?.code) throw error;
    throw agentBridgeError("AGENT_DEBUGGER_SUBMIT_FAILED", String(error?.message || error || "Agent debugger submit failed."));
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function clearAgentDebuggerSubmittedPromptAfterAcceptance(target, editorRect = {}, prompt = "", accepted = {}) {
  if (accepted?.promptStillPresent !== true) {
    return {
      ok: true,
      cleared: false,
      reason: "submitted_prompt_not_visible"
    };
  }
  const before = await debuggerReadComposerState(target).catch((error) => ({
    error: String(error?.message || error || "composer_read_failed")
  }));
  const beforeTexts = Array.isArray(before?.editors) ? before.editors.map((editor) => compactString(editor.text)) : [];
  const stillSubmittedPrompt = agentPromptInserted([compactString(before?.activeText || ""), ...beforeTexts], prompt);
  if (!stillSubmittedPrompt) {
    return {
      ok: true,
      cleared: false,
      reason: "composer_no_longer_contains_submitted_prompt",
      composerReadError: compactString(before?.error || "")
    };
  }

  try {
    await debuggerReplaceAgentEditorText(target, editorRect, "");
    await sleep(200);
    const after = await debuggerReadComposerState(target).catch((error) => ({
      error: String(error?.message || error || "composer_read_failed")
    }));
    const afterTexts = Array.isArray(after?.editors) ? after.editors.map((editor) => compactString(editor.text)) : [];
    const promptStillPresent = agentPromptInserted([compactString(after?.activeText || ""), ...afterTexts], prompt);
    if (promptStillPresent) {
      // Flow can retain a Slate draft after Backspace even though the message
      // was accepted. The compact composer exposes a structural close/clear
      // control beside the exact verified draft and its prompt-media chips.
      const clearAll = await clearAgentRefComposerChipsTogether(target).catch(() => null);
      if (clearAll?.ok) {
        await sleep(250);
        const finalState = await debuggerReadComposerState(target).catch((error) => ({
          error: String(error?.message || error || "composer_read_failed")
        }));
        const finalTexts = Array.isArray(finalState?.editors) ? finalState.editors.map((editor) => compactString(editor.text)) : [];
        const exactPromptStillPresent = agentPromptInserted([compactString(finalState?.activeText || ""), ...finalTexts], prompt);
        if (!exactPromptStillPresent) {
          return {
            ok: true,
            cleared: true,
            signal: "submitted_prompt_cleared_with_structural_control",
            clearAll
          };
        }
      }
      return {
        ok: false,
        cleared: false,
        error: "AGENT_SUBMITTED_PROMPT_CLEAR_FAILED",
        composerReadError: compactString(after?.error || ""),
        activeText: compactString(after?.activeText || "").slice(0, 240),
        editorTexts: afterTexts.map((value) => value.slice(0, 160)),
        clearAll: clearAll || null
      };
    }
    return {
      ok: true,
      cleared: true,
      signal: "submitted_prompt_cleared"
    };
  } catch (error) {
    return {
      ok: false,
      cleared: false,
      error: "AGENT_SUBMITTED_PROMPT_CLEAR_FAILED",
      message: String(error?.message || error || "submitted prompt cleanup failed")
    };
  }
}

async function debuggerReplaceAgentEditorText(target, editorRect = {}, text = "") {
  const selected = await debuggerEvaluate(target, `((targetRect) => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const candidates = Array.from(document.querySelectorAll("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const dx = Math.abs((rect.x + rect.width / 2) - (Number(targetRect.x || 0) + Number(targetRect.width || 0) / 2));
        const dy = Math.abs((rect.y + rect.height / 2) - (Number(targetRect.y || 0) + Number(targetRect.height || 0) / 2));
        return { element, score: dx + dy };
      })
      .sort((left, right) => left.score - right.score);
    const editor = candidates[0]?.element || null;
    if (!editor) return { ok: false, error: "editor_not_found" };
    editor.focus?.({ preventScroll: true });
    const tag = String(editor.tagName || "").toLowerCase();
    if (tag === "textarea" || tag === "input") {
      editor.select?.();
      return { ok: true, selected: "input" };
    }
    const selection = window.getSelection?.();
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection?.removeAllRanges?.();
    selection?.addRange?.(range);
    return { ok: true, selected: "contenteditable" };
  })(${JSON.stringify(editorRect)})`).catch((error) => ({ ok: false, error: String(error?.message || error || "select_agent_editor_failed") }));
  if (!selected?.ok) {
    throw agentBridgeError("AGENT_COMPOSER_SELECT_FAILED", "Agent composer text could not be selected before insertion.", selected || {});
  }
  await sleep(60);
  if (String(text || "") === "") {
    await debuggerSend(target, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Backspace",
      code: "Backspace",
      windowsVirtualKeyCode: 8,
      nativeVirtualKeyCode: 51
    });
    await debuggerSend(target, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Backspace",
      code: "Backspace",
      windowsVirtualKeyCode: 8,
      nativeVirtualKeyCode: 51
    });
    return;
  }
  await debuggerSend(target, "Input.insertText", { text: String(text || "") });
}

async function findAgentDebuggerSubmitButton(target, expectedComposer = {}) {
  return debuggerEvaluate(target, `((expectedComposer) => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "").replace(/\\s+/g, " ").trim();
    const classNameOf = (element) => String(element?.className?.baseVal || element?.className || "");
    const isCompactCircular = (box) => {
      const width = Number(box?.width || 0);
      const height = Number(box?.height || 0);
      return width >= 28 && width <= 56 && height >= 28 && height <= 56 && Math.abs(width - height) <= 8;
    };
    const isIconOnlySubmitControl = (button, box, label) => {
      const className = classNameOf(button);
      if (/\\b(add|add_2|upload|attach)\\b/i.test(label) || /add_2|add-button|attach/i.test(className)) return false;
      const classSubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
        || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
      const bottomRightSend = box.x > window.innerWidth * 0.65 && box.y > window.innerHeight * 0.55;
      return Boolean(classSubmit || (isCompactCircular(box) && bottomRightSend && !String(label || "").trim()));
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const closestDialog = (element) => {
      let current = element;
      while (current) {
        if (current.matches?.("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container,.modal,.dialog")) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    };
    const rejectAddOrUploadControl = (text = "") => /\\b(add|add_2|upload|attach|media|instructions|settings|clear prompt|close)\\b/i.test(text)
      || /\\b(warning|failed|reuse prompt|delete|send feedback|bad response|good response|flag)\\b/i.test(text);
    // Match the same composer by fingerprint plus geometry identity while
    // tolerating vertical growth AND modest horizontal reflow: inserting a
    // multi-line prompt legitimately grows the Slate editor's height and can
    // also nudge width a few px as the panel reflows. Anchoring on the exact
    // pre-insertion width (±4) was rejecting the very composer we just typed
    // into (live proof: AGENT_COMPOSER_TARGET_UNRESOLVED sameComposer:false
    // with prompt already present and arrow_forward Create enabled).
    const composerRectMatches = (live = {}, expected = {}) => {
      const expectedTop = Number(expected.y);
      const expectedBottom = Number.isFinite(Number(expected.bottom))
        ? Number(expected.bottom)
        : Number(expected.y) + Number(expected.height);
      const expectedWidth = Number(expected.width) || 0;
      const widthTol = Math.max(24, Math.round(expectedWidth * 0.12) || 24);
      return Math.abs(Number(live.x) - Number(expected.x)) <= 24
        && Math.abs(Number(live.width) - expectedWidth) <= widthTol
        && Number(live.y) <= expectedBottom + 24
        && Number(live.bottom) >= expectedTop - 24;
    };
    const fingerprintMatches = (element) => {
      const fp = expectedComposer.editorFingerprint || {};
      return String(element.tagName || "").toLowerCase() === String(fp.tag || "").toLowerCase()
        && String(element.getAttribute?.("role") || "") === String(fp.role || "")
        && String(element.getAttribute?.("contenteditable") || "") === String(fp.contentEditable || "")
        && Boolean(element.getAttribute?.("data-slate-editor") === "true") === Boolean(fp.dataSlateEditor);
    };
    const inAgentZone = (rect) => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      return (rect.x > vw * 0.55 && rect.bottom > vh * 0.55)
        || (rect.right > vw * 0.75 && rect.bottom > vh * 0.7 && rect.width > 120)
        || (rect.width >= vw * 0.25 && rect.width <= vw * 0.6 && rect.height >= 48 && rect.bottom > vh * 0.45);
    };
    const editors = Array.from(document.querySelectorAll("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
      .filter(visible);
    let editor = editors.find((element) => composerRectMatches(rectOf(element), expectedComposer.editorRect || {})
      && fingerprintMatches(element));
    // Fallback: fingerprint + agent zone + contains prompt text when geometry drifted.
    if (!editor) {
      editor = editors.find((element) => {
        const rect = rectOf(element);
        if (!fingerprintMatches(element) || !inAgentZone(rect)) return false;
        // Prefer the editor that still holds non-empty draft text after insertion.
        const text = textOf(element);
        return text.length > 0;
      }) || null;
    }
    if (!editor) {
      return {
        ok: false,
        error: "AGENT_COMPOSER_TARGET_UNRESOLVED",
        sameComposer: false,
        expectedRect: expectedComposer.editorRect || null,
        expectedFingerprint: expectedComposer.editorFingerprint || null,
        liveEditors: editors.slice(0, 6).map((element) => ({
          tag: String(element.tagName || "").toLowerCase(),
          role: String(element.getAttribute?.("role") || ""),
          contentEditable: String(element.getAttribute?.("contenteditable") || ""),
          dataSlateEditor: element.getAttribute?.("data-slate-editor") === "true",
          rect: rectOf(element),
          text: textOf(element).slice(0, 80)
        }))
      };
    }
    const candidate = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(visible)
      .map((button) => {
        const rect = button.getBoundingClientRect();
        const text = textOf(button);
        const disabled = Boolean(button.disabled || button.getAttribute("aria-disabled") === "true");
        const bottomRight = rect.x > window.innerWidth * 0.65 && rect.y > window.innerHeight * 0.55;
        const rightEdge = rect.x > window.innerWidth * 0.85;
        const arrowSubmit = /arrow_forward/i.test(text);
        const iconOnlySubmit = isIconOnlySubmitControl(button, rect, text);
        const submitText = arrowSubmit || iconOnlySubmit || /\\b(send|submit|generate)\\b/i.test(text) || (rightEdge && /\\bcreate\\b/i.test(text));
        const rejected = rejectAddOrUploadControl(text);
        const score = (arrowSubmit || iconOnlySubmit ? 20000 : 0) + (bottomRight ? 10000 : 0) + (submitText ? 5000 : 0) + rect.x + rect.y;
        const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
        const hitTestable = Boolean(hit && (hit === button || button.contains(hit)));
        return { button, rect, text, disabled, rejected, submitText, hitTestable, score };
      })
      .filter((entry) => !entry.disabled)
      .filter((entry) => entry.hitTestable)
      .filter((entry) => !entry.rejected)
      .filter((entry) => entry.submitText)
      .sort((left, right) => right.score - left.score)[0];
    if (!candidate) return { ok: false, error: "AGENT_SUBMIT_BUTTON_NOT_FOUND", sameComposer: true, editorRect: rectOf(editor) };
    return { ok: true, text: candidate.text, rect: rectOf(candidate.button), sameComposer: true, editorRect: rectOf(editor), hitTestable: true, disabled: false };
  })(${JSON.stringify(expectedComposer)})`).catch((error) => ({ ok: false, error: String(error?.message || error || "submit_button_probe_failed") }));
}

async function waitForAgentDebuggerSubmitButton(target, timeoutMs = 8000, expectedComposer = {}) {
  const started = Date.now();
  let lastProbe = null;
  while (Date.now() - started <= timeoutMs) {
    lastProbe = await findAgentDebuggerSubmitButton(target, expectedComposer);
    if (lastProbe?.ok && lastProbe.rect) return lastProbe;
    await sleep(200);
  }
  return lastProbe || { ok: false, error: "AGENT_SUBMIT_BUTTON_NOT_FOUND" };
}

async function readAgentSubmittedPromptMessageState(target, prompt = "") {
  return debuggerEvaluate(target, `((prompt) => {
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim();
    const expected = normalize(prompt);
    const editableSelector = "textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']";
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    if (!expected) return { matchingMessageCount: 0, matches: [] };
    const matches = Array.from(document.querySelectorAll("p,[data-message-author],[data-message-id]"))
      .filter((element) => !element.closest(editableSelector))
      .filter((element) => !element.querySelector?.(editableSelector))
      .filter((element) => normalize(element.innerText || element.textContent || "") === expected)
      .map((element) => ({
        tag: String(element.tagName || "").toLowerCase(),
        rect: rectOf(element),
        textLength: expected.length
      }))
      .filter((entry) => entry.rect.right > innerWidth * 0.7 && entry.rect.width > 80);
    return { matchingMessageCount: matches.length, matches: matches.slice(-3) };
  })(${JSON.stringify(String(prompt || ""))})`).catch((error) => ({
    matchingMessageCount: 0,
    matches: [],
    error: String(error?.message || error || "submitted_message_probe_failed")
  }));
}

async function waitForAgentDebuggerSubmitAccepted(target, prompt = "", options = {}) {
  const started = Date.now();
  const timeoutMs = Number(options.timeoutMs || 2500);
  let lastState = null;
  let lastSubmitControl = null;
  while (Date.now() - started < timeoutMs) {
    lastState = await debuggerReadComposerState(target);
    const hasComposerSnapshot = !lastState?.error && Array.isArray(lastState?.editors);
    if (!hasComposerSnapshot) {
      await sleep(250);
      continue;
    }
    const activeText = compactString(lastState.activeText || "");
    const editorTexts = Array.isArray(lastState.editors) ? lastState.editors.map((editor) => compactString(editor.text)) : [];
    const promptStillPresent = agentPromptInserted([activeText, ...editorTexts], prompt);
    const submittedMessage = await readAgentSubmittedPromptMessageState(target, prompt);
    const submittedMessageBaselineCount = Number(options.submittedMessageBaselineCount || 0);
    if (Number(submittedMessage?.matchingMessageCount || 0) > submittedMessageBaselineCount) {
      return {
        ok: true,
        signal: "exact_conversation_message_created",
        promptStillPresent,
        submittedMessage
      };
    }
    lastSubmitControl = await findAgentDebuggerSubmitControlState(target, options.submitButtonRect, options.submitButtonText);
    if (lastSubmitControl?.ok && lastSubmitControl.submitControlReplaced && !promptStillPresent) {
      return {
        ok: true,
        signal: "submit_control_replaced",
        promptStillPresent,
        submitControl: lastSubmitControl
      };
    }
    if (lastSubmitControl?.ok && lastSubmitControl.activeGenerationControlVisible && !promptStillPresent) {
      return {
        ok: true,
        signal: "active_generation_control_visible",
        promptStillPresent: false,
        submitControl: lastSubmitControl
      };
    }
    if (lastSubmitControl?.ok && lastSubmitControl.submitControlReplaced && promptStillPresent) {
      await sleep(250);
      continue;
    }
    if (lastSubmitControl?.ok && lastSubmitControl.responseControlVisible && lastSubmitControl.changed && !promptStillPresent) {
      return {
        ok: true,
        signal: "agent_response_control_visible",
        promptStillPresent: false,
        submitControl: lastSubmitControl
      };
    }
    if (!promptStillPresent) {
      return {
        ok: true,
        signal: "composer_changed",
        promptStillPresent: false,
        submitControl: lastSubmitControl
      };
    }
    if (lastSubmitControl?.ok && lastSubmitControl.changed && !lastSubmitControl.submitControlReplaced) {
      await sleep(250);
      continue;
    }
    await sleep(250);
  }
  return {
    ok: false,
    error: "AGENT_SUBMIT_NOT_ACCEPTED",
    promptStillPresent: true,
    submitControl: lastSubmitControl,
    composerReadError: compactString(lastState?.error || ""),
    activeText: compactString(lastState?.activeText || "").slice(0, 240),
    editorTexts: (Array.isArray(lastState?.editors) ? lastState.editors : []).map((editor) => compactString(editor.text).slice(0, 160))
  };
}

async function findAgentDebuggerSubmitControlState(target, targetRect = {}, originalText = "") {
  return debuggerEvaluate(target, `((targetRect, originalText) => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim();
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "").replace(/\\s+/g, " ").trim();
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const centerOf = (rect) => ({
      x: Number(rect?.x || 0) + Number(rect?.width || 0) / 2,
      y: Number(rect?.y || 0) + Number(rect?.height || 0) / 2
    });
    const distance = (left, right) => Math.hypot(left.x - right.x, left.y - right.y);
    const targetCenter = centerOf(targetRect || {});
    const original = normalize(originalText);
    const isAgentSubmitControlText = (value) => {
      const text = normalize(value);
      return /\\barrow_forward\\b/i.test(text)
        || /\\b(send|submit|generate|arrow_upward|submit-button)\\b/i.test(text)
        || (/\\bcreate\\b/i.test(text) && !/\\b(add|add_2|upload|attach|media|instructions|settings|clear prompt|close)\\b/i.test(text));
    };
    const isAgentResponseControlText = (value) => /content_copy|copy\\s+message|good\\s+response|bad\\s+response|thumb_up|thumb_down|flag/i.test(normalize(value));
    const isActiveGenerationControlText = (value) => /(^|\\b)stop(\\b|$)|stop_circle/i.test(normalize(value));
    const candidate = Array.from(document.querySelectorAll("button,[role='button']"))
      .filter(visible)
      .map((button) => {
        const rect = button.getBoundingClientRect();
        const center = centerOf(rect);
        const nearClickedControl = distance(center, targetCenter) <= 120;
        const bottomRight = rect.x > window.innerWidth * 0.65 && rect.y > window.innerHeight * 0.55;
        const text = textOf(button);
        const disabled = Boolean(button.disabled || button.getAttribute("aria-disabled") === "true");
        return {
          button,
          text,
          disabled,
          rect,
          distance: Math.round(distance(center, targetCenter)),
          score: (nearClickedControl ? 10000 : 0) + (bottomRight ? 2500 : 0) - distance(center, targetCenter)
        };
      })
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score)[0];
    if (!candidate) return { ok: false, error: "AGENT_SUBMIT_CONTROL_NOT_FOUND" };
    const current = normalize(candidate.text);
    const changed = Boolean(candidate.disabled || (original && current && current !== original));
    const submitControlReplaced = Boolean(
      candidate.distance <= 120
      && original
      && current
      && current !== original
      && isAgentSubmitControlText(original)
      && !isAgentSubmitControlText(current)
    );
    const responseControlVisible = Boolean(
      candidate.distance <= 120
      && current
      && current !== original
      && isAgentResponseControlText(current)
    );
    const activeGenerationControlVisible = Boolean(
      candidate.distance <= 120
      && current
      && current !== original
      && isActiveGenerationControlText(current)
    );
    return { ok: true, changed, submitControlReplaced, responseControlVisible, activeGenerationControlVisible, text: candidate.text, disabled: candidate.disabled, rect: rectOf(candidate.button), distance: candidate.distance };
  })(${JSON.stringify(targetRect || {})}, ${JSON.stringify(originalText || "")})`).catch((error) => ({ ok: false, error: String(error?.message || error || "submit_control_probe_failed") }));
}

async function clickAgentDebuggerConfirmationAtClickTime(target, confirmation = {}, options = {}) {
  const expectedText = compactString(confirmation.text);
  const allowPersistent = options.allowPersistent === true;
  return debuggerEvaluate(target, `(() => {
    const expectedText = ${JSON.stringify(expectedText)};
    const allowPersistent = ${JSON.stringify(allowPersistent)};
    const visible = (element) => {
      const rect = element?.getBoundingClientRect?.();
      const style = element ? getComputedStyle(element) : null;
      return Boolean(rect && rect.width > 0 && rect.height > 0 && style?.display !== "none" && style?.visibility !== "hidden");
    };
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "").replace(/\\s+/g, " ").trim();
    const persistent = (text) => /ask again|dont ask|don['’]?t ask/i.test(text);
    const oneTime = (text) => /^(?:check\\s+)?(?:yes|approve|confirm|continue|use credits)$/i.test(text) && !persistent(text);
    const interactive = (element) => {
      const tag = String(element?.tagName || "").toLowerCase();
      const role = String(element?.getAttribute?.("role") || "").toLowerCase();
      const style = element ? getComputedStyle(element) : null;
      return tag === "button" || role === "button" || style?.cursor === "pointer";
    };
    const candidates = Array.from(document.querySelectorAll("button,[role='button'],div"))
      .filter(visible)
      .filter(interactive)
      .filter((element) => textOf(element) === expectedText)
      .filter((element) => allowPersistent ? (oneTime(textOf(element)) || persistent(textOf(element))) : oneTime(textOf(element)))
      .filter((element) => {
        if (allowPersistent) return true;
        let current = element.parentElement;
        for (let depth = 0; current && depth < 4; depth += 1, current = current.parentElement) {
          const text = textOf(current);
          if (persistent(text) && current.getBoundingClientRect().height <= 90) return false;
        }
        return true;
      })
      .sort((left, right) => {
        const leftRect = left.getBoundingClientRect();
        const rightRect = right.getBoundingClientRect();
        return (leftRect.width * leftRect.height) - (rightRect.width * rightRect.height);
      });
    if (candidates.length !== 1) return { ok: false, code: "AGENT_CREDIT_CONFIRMATION_NOT_UNIQUE", matchCount: candidates.length };
    const candidate = candidates[0];
    const rect = candidate.getBoundingClientRect();
    candidate.click();
    return {
      ok: true,
      method: "guarded_exact_credit_choice_dom_click",
      text: textOf(candidate),
      persistent: persistent(textOf(candidate)),
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
  })()`);
}

async function findAgentDebuggerConfirmationButton(target, options = {}) {
  const allowPersistentChoice = options.allowPersistent === true;
  return debuggerEvaluate(target, `(() => {
    const allowPersistentChoice = ${JSON.stringify(allowPersistentChoice)};
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "").replace(/\\s+/g, " ").trim();
    const isCreditContainerText = (text = "") => /credit|credits|use .*credit|will use|cost/i.test(text) && /yes|approve|confirm|continue|use credits/i.test(text);
    const isPersistentChoiceText = (text = "") => /ask again|dont ask|don['’]?t ask/i.test(text);
    const isOneTimeChoiceText = (text = "") => /^(?:check\\s+)?(?:yes|approve|confirm|continue|use credits)$/i.test(text) && !isPersistentChoiceText(text);
    const isDismissiveChoiceText = (text = "") => /^(?:close\\s+)?(?:no|cancel|reject|back)$/i.test(text);
    const isChoiceText = (text = "") => text.length <= 160 && (isOneTimeChoiceText(text) || isPersistentChoiceText(text) || isDismissiveChoiceText(text));
    const isAgentCreditChoiceRowLikeElement = (element) => {
      if (!element || element === document.body || !visible(element)) return false;
      const text = textOf(element);
      if (!isChoiceText(text)) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return style.cursor === "pointer" && rect.width >= 80 && rect.height >= 24 && rect.height <= 80;
    };
    const isInteractiveChoiceElement = (element) => {
      if (!element || element === document.body) return false;
      const tagName = String(element.tagName || "").toLowerCase();
      const role = String(element.getAttribute?.("role") || "").toLowerCase();
      if (tagName === "button" || role === "button") return true;
      if (isAgentCreditChoiceRowLikeElement(element)) return true;
      const tabindex = element.getAttribute?.("tabindex");
      if (tabindex !== null && tabindex !== undefined && Number(tabindex) >= 0) return true;
      const style = getComputedStyle(element);
      return style.cursor === "pointer" && (Boolean(element.onclick) || Boolean(element.getAttribute?.("jsaction")));
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const closestDialog = (element) => {
      let current = element;
      while (current) {
        if (current.matches?.("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container,.modal,.dialog")) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    };
    const allElementsDeep = (selector) => {
      const results = [];
      const roots = [document];
      const seenRoots = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seenRoots.has(root)) continue;
        seenRoots.add(root);
        try {
          root.querySelectorAll(selector).forEach((element) => results.push(element));
        } catch {}
        try {
          root.querySelectorAll("*").forEach((element) => {
            if (element.shadowRoot) roots.push(element.shadowRoot);
          });
        } catch {}
      }
      return [...new Set(results)];
    };
    const isInside = (container, element) => {
      if (!container || !element) return false;
      if (container === element || container.contains?.(element)) return true;
      const root = element.getRootNode?.();
      return Boolean(root?.host && (container === root.host || container.contains?.(root.host)));
    };
    let choiceElementsCache = null;
    const getChoiceElements = () => {
      if (!choiceElementsCache) choiceElementsCache = allElementsDeep("button,[role='button'],div").filter(visible);
      return choiceElementsCache;
    };
    const choiceElementsIn = (container) => getChoiceElements()
      .filter((element) => element !== container && isInside(container, element) && isInteractiveChoiceElement(element));
    const isReasonableCreditContainer = (element) => {
      const rect = element.getBoundingClientRect();
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      return textOf(element).length <= 1500 && (rect.width * rect.height) <= viewportArea * 0.75;
    };
    const hasOneTimeConfirmationChoice = (container) => choiceElementsIn(container)
      .some((element) => isOneTimeChoiceText(textOf(element)) && !closestPersistentChoiceAncestor(element, container));
    const hasDismissiveOrPersistentChoice = (container) => choiceElementsIn(container)
      .some((element) => isDismissiveChoiceText(textOf(element)) || isPersistentChoiceText(textOf(element)));
    const isCreditContainerCandidate = (element) => {
      if (!visible(element) || !isReasonableCreditContainer(element) || !isCreditContainerText(textOf(element))) return false;
      return hasOneTimeConfirmationChoice(element) && (hasDismissiveOrPersistentChoice(element) || Boolean(closestDialog(element)));
    };
    const closestCreditContainer = (element) => {
      let current = element;
      while (current && current !== document.body && current.nodeType === Node.ELEMENT_NODE) {
        if (isCreditContainerCandidate(current)) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    };
    function closestPersistentChoiceAncestor(element, boundary) {
      let current = element;
      while (current && current !== boundary && current !== document.body && current.nodeType === Node.ELEMENT_NODE) {
        const text = textOf(current);
        if (isAgentCreditChoiceRowLikeElement(current) && isPersistentChoiceText(text)) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    }
    const closestChoiceEntry = (element, boundary) => {
      let current = element;
      while (current && current !== boundary && current !== document.body && current.nodeType === Node.ELEMENT_NODE) {
        const text = textOf(current);
        if (visible(current) && isInteractiveChoiceElement(current) && isChoiceText(text)) return { element: current, text };
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      const text = textOf(element);
      return isInteractiveChoiceElement(element) && isChoiceText(text) ? { element, text } : null;
    };
    const candidate = getChoiceElements()
      .map((button) => {
        const text = textOf(button);
        const dialog = closestDialog(button);
        const creditContainer = closestCreditContainer(button) || dialog;
        const choice = creditContainer ? closestChoiceEntry(button, creditContainer) : null;
        const choiceElement = choice?.element || button;
        const activationElement = [choiceElement, ...Array.from(choiceElement.querySelectorAll?.("*") || [])]
          .filter(visible)
          .filter((element) => isOneTimeChoiceText(textOf(element)))
          .sort((left, right) => {
            const leftRect = left.getBoundingClientRect();
            const rightRect = right.getBoundingClientRect();
            return (leftRect.width * leftRect.height) - (rightRect.width * rightRect.height);
          })[0] || choiceElement;
        const rect = activationElement.getBoundingClientRect();
        const containerRect = creditContainer?.getBoundingClientRect?.() || rect;
        return {
          button,
          text,
          choiceElement,
          activationElement,
          choiceText: choice?.text || text,
          dialog,
          creditContainer,
          persistentChoice: creditContainer ? closestPersistentChoiceAncestor(button, creditContainer) : null,
          disabled: Boolean(button.disabled || button.getAttribute("aria-disabled") === "true"),
          rect,
          score: (containerRect.y * 1000)
            + rect.x
            + rect.y
            - (rect.width * rect.height / 10000)
            + (allowPersistentChoice && isPersistentChoiceText(choice?.text || text) ? 100000 : 0)
        };
      })
      .filter((entry) => !entry.disabled)
      .filter((entry) => entry.creditContainer && isCreditContainerCandidate(entry.creditContainer))
      .filter((entry) => allowPersistentChoice ? (isOneTimeChoiceText(entry.choiceText) || isPersistentChoiceText(entry.choiceText)) : isOneTimeChoiceText(entry.choiceText))
      .filter((entry) => allowPersistentChoice || !entry.persistentChoice)
      .filter((entry) => !/cancel|back|delete|remove|trash/i.test(entry.choiceText))
      .sort((left, right) => right.score - left.score)[0];
    if (!candidate) return { ok: false, error: "AGENT_CONFIRMATION_BUTTON_NOT_FOUND" };
    return { ok: true, text: candidate.choiceText, rect: rectOf(candidate.activationElement), persistent: isPersistentChoiceText(candidate.choiceText) };
  })()`).catch((error) => ({ ok: false, error: String(error?.message || error || "confirmation_button_probe_failed") }));
}

async function findAgentDebuggerCreditDialog(target) {
  return debuggerEvaluate(target, `(() => {
    const visible = (element) => {
      if (!element || !element.getBoundingClientRect) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && rect.bottom >= 0 && rect.top <= window.innerHeight;
    };
    const textOf = (element) => String(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label") || "").replace(/\\s+/g, " ").trim();
    const isCreditContainerText = (text = "") => /credit|credits|use .*credit|will use|cost/i.test(text) && /yes|approve|confirm|continue|use credits/i.test(text);
    const isPersistentChoiceText = (text = "") => /ask again|dont ask|don['’]?t ask/i.test(text);
    const isOneTimeChoiceText = (text = "") => /^(?:check\\s+)?(?:yes|approve|confirm|continue|use credits)$/i.test(text) && !isPersistentChoiceText(text);
    const isDismissiveChoiceText = (text = "") => /^(?:close\\s+)?(?:no|cancel|reject|back)$/i.test(text);
    const isChoiceText = (text = "") => text.length <= 160 && (isOneTimeChoiceText(text) || isPersistentChoiceText(text) || isDismissiveChoiceText(text));
    const isAgentCreditChoiceRowLikeElement = (element) => {
      if (!element || element === document.body || !visible(element)) return false;
      const text = textOf(element);
      if (!isChoiceText(text)) return false;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return style.cursor === "pointer" && rect.width >= 80 && rect.height >= 24 && rect.height <= 80;
    };
    const isInteractiveChoiceElement = (element) => {
      if (!element || element === document.body) return false;
      const tagName = String(element.tagName || "").toLowerCase();
      const role = String(element.getAttribute?.("role") || "").toLowerCase();
      if (tagName === "button" || role === "button") return true;
      if (isAgentCreditChoiceRowLikeElement(element)) return true;
      const tabindex = element.getAttribute?.("tabindex");
      if (tabindex !== null && tabindex !== undefined && Number(tabindex) >= 0) return true;
      const style = getComputedStyle(element);
      return style.cursor === "pointer" && (Boolean(element.onclick) || Boolean(element.getAttribute?.("jsaction")));
    };
    const rectOf = (element) => {
      const rect = element.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height), right: Math.round(rect.right), bottom: Math.round(rect.bottom) };
    };
    const closestDialog = (element) => {
      let current = element;
      while (current) {
        if (current.matches?.("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container,.modal,.dialog")) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    };
    const allElementsDeep = (selector) => {
      const results = [];
      const roots = [document];
      const seenRoots = new Set();
      for (let index = 0; index < roots.length; index += 1) {
        const root = roots[index];
        if (!root || seenRoots.has(root)) continue;
        seenRoots.add(root);
        try {
          root.querySelectorAll(selector).forEach((element) => results.push(element));
        } catch {}
        try {
          root.querySelectorAll("*").forEach((element) => {
            if (element.shadowRoot) roots.push(element.shadowRoot);
          });
        } catch {}
      }
      return [...new Set(results)];
    };
    const isInside = (container, element) => {
      if (!container || !element) return false;
      if (container === element || container.contains?.(element)) return true;
      const root = element.getRootNode?.();
      return Boolean(root?.host && (container === root.host || container.contains?.(root.host)));
    };
    let choiceElementsCache = null;
    const getChoiceElements = () => {
      if (!choiceElementsCache) choiceElementsCache = allElementsDeep("button,[role='button'],div").filter(visible);
      return choiceElementsCache;
    };
    const choiceElementsIn = (container) => getChoiceElements()
      .filter((element) => element !== container && isInside(container, element) && isInteractiveChoiceElement(element));
    const isReasonableCreditContainer = (element) => {
      const rect = element.getBoundingClientRect();
      const viewportArea = Math.max(1, window.innerWidth * window.innerHeight);
      return textOf(element).length <= 1500 && (rect.width * rect.height) <= viewportArea * 0.75;
    };
    const closestPersistentChoiceAncestor = (element, boundary) => {
      let current = element;
      while (current && current !== boundary && current !== document.body && current.nodeType === Node.ELEMENT_NODE) {
        const text = textOf(current);
        if (isAgentCreditChoiceRowLikeElement(current) && isPersistentChoiceText(text)) return current;
        current = current.parentElement || current.getRootNode?.()?.host || null;
      }
      return null;
    };
    const hasOneTimeConfirmationChoice = (container) => choiceElementsIn(container)
      .some((element) => isOneTimeChoiceText(textOf(element)) && !closestPersistentChoiceAncestor(element, container));
    const hasDismissiveOrPersistentChoice = (container) => choiceElementsIn(container)
      .some((element) => isDismissiveChoiceText(textOf(element)) || isPersistentChoiceText(textOf(element)));
    const isCreditContainerCandidate = (element) => {
      if (!visible(element) || !isReasonableCreditContainer(element) || !isCreditContainerText(textOf(element))) return false;
      return hasOneTimeConfirmationChoice(element) && (hasDismissiveOrPersistentChoice(element) || Boolean(closestDialog(element)));
    };
    const candidate = allElementsDeep("[role='dialog'],[aria-modal='true'],mat-dialog-container,.mat-mdc-dialog-container,.modal,.dialog,div")
      .filter(visible)
      .map((dialog) => {
        const rect = dialog.getBoundingClientRect();
        return {
          dialog,
          text: textOf(dialog),
          rect,
          area: rect.width * rect.height
        };
      })
      .filter((entry) => isCreditContainerCandidate(entry.dialog))
      .sort((left, right) => (left.area - right.area) || (right.rect.y - left.rect.y))[0] || null;
    if (!candidate) return { ok: false, error: "AGENT_CREDIT_DIALOG_NOT_FOUND" };
    return { ok: true, text: candidate.text.slice(0, 500), rect: rectOf(candidate.dialog) };
  })()`).catch((error) => ({ ok: false, error: String(error?.message || error || "credit_dialog_probe_failed") }));
}

async function executeAgentPromptInPage(tabId = 0, options = {}) {
  return executeAgentPromptWithDebugger(tabId, options);
  if (!tabId || typeof chrome.scripting?.executeScript !== "function") {
    throw agentBridgeError("AGENT_PAGE_SCRIPT_UNAVAILABLE", "Chrome scripting is not available for Agent prompt submission.");
  }
  const injections = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async (input) => {
      const prompt = String(input?.prompt || "");
      const dryRun = input?.dryRun === true;
      const autoConfirm = input?.autoConfirm !== false;
      const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
      const visible = (element) => {
        if (!element || typeof element.getBoundingClientRect !== "function") return false;
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return rect.width > 0
          && rect.height > 0
          && style.display !== "none"
          && style.visibility !== "hidden"
          && rect.bottom >= 0
          && rect.top <= window.innerHeight;
      };
      const textOf = (element) => String(element?.value || element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
      const rectOf = (element) => {
        const rect = element.getBoundingClientRect();
        return {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          right: Math.round(rect.right),
          bottom: Math.round(rect.bottom)
        };
      };
      const normalized = (value) => String(value || "").replace(/\s+/g, " ").trim();
      const editor = Array.from(document.querySelectorAll("textarea,input,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']"))
        .filter(visible)
        .filter((element) => !element.closest("[data-autoflow-rebuild], #af-bot-panel"))
        .map((element) => {
          const rect = element.getBoundingClientRect();
          const tag = String(element.tagName || "").toLowerCase();
          const isAgentPanel = rect.x > window.innerWidth * 0.55 && rect.y > window.innerHeight * 0.45;
          const isEditable = element.matches("textarea,[role='textbox'],[contenteditable='true'],[contenteditable='plaintext-only'],[data-slate-editor='true']");
          const score = (isAgentPanel ? 10000 : 0)
            + (isEditable ? 2500 : 0)
            + (element.getAttribute("data-slate-editor") ? 1500 : 0)
            + rect.y
            + rect.x
            - (tag === "input" ? 3000 : 0);
          return { element, score };
        })
        .sort((left, right) => right.score - left.score)[0]?.element || null;
      if (!editor) {
        return { ok: false, error: "AGENT_COMPOSER_NOT_FOUND", editors: 0 };
      }

      const originalEditorText = textOf(editor);
      const setEditorText = (value) => {
        const text = String(value || "");
        editor.focus({ preventScroll: true });
        let ok = false;
        try {
          document.execCommand("selectAll", false, null);
          document.execCommand("delete", false, null);
          ok = document.execCommand("insertText", false, text);
        } catch (_error) {
          ok = false;
        }
        if (ok && normalized(textOf(editor)) === normalized(text)) return true;
        const tag = String(editor.tagName || "").toLowerCase();
        if (tag === "textarea" || tag === "input") {
          const proto = tag === "textarea" ? window.HTMLTextAreaElement?.prototype : window.HTMLInputElement?.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto || {}, "value")?.set;
          if (setter) setter.call(editor, text);
          else editor.value = text;
        } else {
          editor.textContent = text;
        }
        editor.dispatchEvent(new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          inputType: "insertText",
          data: text
        }));
        editor.dispatchEvent(new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: text
        }));
        editor.dispatchEvent(new Event("change", { bubbles: true }));
        return normalized(textOf(editor)) === normalized(text);
      };

      editor.focus({ preventScroll: true });
      await sleep(40);
      setEditorText(prompt);
      await sleep(220);
      const editorText = textOf(editor);
      if (normalized(editorText) !== normalized(prompt)) {
        return {
          ok: false,
          error: "AGENT_PROMPT_NOT_INSERTED",
          editor: {
            textPreview: editorText.slice(0, 240),
            rect: rectOf(editor)
          }
        };
      }

      const submitCandidates = Array.from(document.querySelectorAll("button,[role='button']"))
        .filter(visible)
        .map((button) => {
          const rect = button.getBoundingClientRect();
          const text = textOf(button);
          const className = String(button?.className?.baseVal || button?.className || "");
          const disabled = Boolean(button.disabled || button.getAttribute("aria-disabled") === "true");
          const bottomRight = rect.x > window.innerWidth * 0.65 && rect.y > window.innerHeight * 0.65;
          const iconOnlySubmit = /submit-button|(?:^|\\s)submit(?:-|$|\\s)/i.test(className)
            || (/icon-only/i.test(className) && /circle/i.test(className) && /primary|submit/i.test(className));
          const submitText = /arrow_forward|create|send|submit|generate/i.test(text) || iconOnlySubmit;
          const score = (iconOnlySubmit ? 20000 : 0) + (bottomRight ? 10000 : 0) + (submitText ? 5000 : 0) + rect.x + rect.y;
          return { button, score, disabled, text };
        })
        .filter((entry) => !entry.disabled)
        .filter((entry) => /arrow_forward|create|send|submit|generate/i.test(entry.text) || entry.score >= 10000)
        .sort((left, right) => right.score - left.score);
      const submitButton = submitCandidates[0]?.button || null;
      if (!submitButton) {
        return {
          ok: false,
          error: "AGENT_SUBMIT_BUTTON_NOT_FOUND",
          editor: {
            textPreview: editorText.slice(0, 240),
            rect: rectOf(editor)
          }
        };
      }

      const result = {
        ok: true,
        submitted: false,
        dryRun,
        editor: {
          textPreview: editorText.slice(0, 240),
          rect: rectOf(editor)
        },
        submitButton: {
          text: textOf(submitButton).slice(0, 160),
          rect: rectOf(submitButton)
        },
        confirmation: null,
        restored: false
      };
      if (dryRun) {
        const placeholderLike = /what do you want to create/i.test(originalEditorText);
        setEditorText(placeholderLike ? "" : originalEditorText);
        await sleep(80);
        result.restored = true;
        return result;
      }

      submitButton.click();
      result.submitted = true;
      if (autoConfirm) {
        await sleep(900);
        const confirmButton = Array.from(document.querySelectorAll("button,[role='button']"))
          .filter(visible)
          .map((button) => ({
            button,
            text: textOf(button),
            disabled: Boolean(button.disabled || button.getAttribute("aria-disabled") === "true"),
            rect: button.getBoundingClientRect()
          }))
          .filter((entry) => !entry.disabled)
          .filter((entry) => /yes|confirm|continue|create|use credits|generate/i.test(entry.text))
          .filter((entry) => !/cancel|back|delete|remove|trash/i.test(entry.text))
          .sort((left, right) => (right.rect.x + right.rect.y) - (left.rect.x + left.rect.y))[0]?.button || null;
        if (confirmButton) {
          result.confirmation = {
            clicked: true,
            text: textOf(confirmButton).slice(0, 160),
            rect: rectOf(confirmButton)
          };
          confirmButton.click();
        }
      }
      return result;
    },
    args: [{
      prompt: options.prompt || "",
      dryRun: options.dryRun === true,
      autoConfirm: options.autoConfirm !== false
    }]
  });
  const result = injections?.[0]?.result || {};
  if (!result.ok) {
    throw agentBridgeError(result.error || "AGENT_PROMPT_SUBMIT_FAILED", "Agent prompt could not be submitted in the Flow page.", result);
  }
  return result;
}

function requestedAgentBridgeProjectId(payload = {}) {
  const projectId = compactString(payload.projectId);
  if (projectId) return projectId;
  const project = compactString(payload.project);
  if (project && project !== "current") return project;
  return "";
}

async function fetchAgentProjectInitialData({ projectId = "", tabId = 0, pageUrl = "" } = {}) {
  const backgroundResult = await fetchAgentProjectInitialDataInBackground(projectId, pageUrl).catch((error) => ({
    ok: false,
    error: String(error?.message || error || "background_project_initial_data_failed"),
    source: "background_fetch"
  }));
  if (backgroundResult.ok) return backgroundResult;
  const pageResult = await fetchAgentProjectInitialDataInPage(tabId, projectId).catch((error) => ({
    ok: false,
    error: String(error?.message || error || "page_project_initial_data_failed"),
    source: "page_script"
  }));
  return pageResult.ok ? pageResult : {
    ok: false,
    error: pageResult.error || backgroundResult.error || "project_initial_data_unavailable",
    status: pageResult.status || backgroundResult.status || 0,
    source: pageResult.source || backgroundResult.source || ""
  };
}

async function fetchAgentProjectInitialDataInBackground(projectId = "", pageUrl = "") {
  const endpoint = agentProjectInitialDataUrl(projectId, pageUrl);
  const response = await fetch(endpoint, {
    method: "GET",
    cache: "no-store",
    credentials: "include",
    headers: {
      accept: "application/json, text/plain, */*"
    }
  });
  const text = await response.text().catch(() => "");
  return parseAgentProjectInitialDataResponse(text, {
    ok: response.ok,
    status: Number(response.status || 0),
    source: "background_fetch"
  });
}

async function fetchAgentProjectInitialDataInPage(tabId = 0, projectId = "") {
  if (!tabId || typeof chrome.scripting?.executeScript !== "function") {
    return { ok: false, status: 0, error: "page_script_unavailable", source: "page_script" };
  }
  const injections = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async (targetProjectId) => {
      const input = encodeURIComponent(JSON.stringify({ json: { projectId: String(targetProjectId || "").trim() } }));
      const response = await fetch(`/fx/api/trpc/flow.projectInitialData?input=${input}&af_agent_bridge_ts=${Date.now()}`, {
        method: "GET",
        cache: "no-store",
        credentials: "include",
        headers: { accept: "application/json, text/plain, */*" }
      });
      return {
        ok: response.ok,
        status: Number(response.status || 0),
        text: await response.text().catch(() => "")
      };
    },
    args: [projectId]
  });
  const result = injections?.[0]?.result || {};
  return parseAgentProjectInitialDataResponse(result.text || "", {
    ok: result.ok === true,
    status: Number(result.status || 0),
    source: "page_script"
  });
}

function parseAgentProjectInitialDataResponse(text = "", meta = {}) {
  if (!meta.ok) {
    return {
      ok: false,
      status: meta.status || 0,
      source: meta.source || "",
      error: `http_${meta.status || 0}`
    };
  }
  let parsed = null;
  try {
    parsed = text ? JSON.parse(text) : null;
  } catch {
    return {
      ok: false,
      status: meta.status || 0,
      source: meta.source || "",
      error: "project_initial_data_json_parse_failed"
    };
  }
  const project = unwrapAgentProjectInitialData(parsed);
  if (!project?.projectContents) {
    return {
      ok: false,
      status: meta.status || 0,
      source: meta.source || "",
      error: "project_initial_data_missing_contents"
    };
  }
  return {
    ok: true,
    status: meta.status || 0,
    source: meta.source || "",
    projectInitialData: parsed
  };
}

function agentProjectInitialDataUrl(projectId = "", pageUrl = "") {
  const origin = String(pageUrl || "").startsWith("https://labs.google.com/")
    ? "https://labs.google.com"
    : "https://labs.google";
  const input = encodeURIComponent(JSON.stringify({ json: { projectId: compactString(projectId) } }));
  return `${origin}/fx/api/trpc/flow.projectInitialData?input=${input}&af_agent_bridge_ts=${Date.now()}`;
}

function unwrapAgentProjectInitialData(input = {}) {
  return input?.result?.data?.json || input?.data?.json || input?.json || input;
}

function unwrapPageCommandPayload(value = {}) {
  return value?.payload?.result?.result
    || value?.payload?.result
    || value?.result?.result
    || value?.result
    || value;
}

function agentBridgeRequestedMediaIds(payload = {}) {
  const ids = (Array.isArray(payload.mediaIds) ? payload.mediaIds : []).map(compactString).filter(Boolean);
  const taskId = compactString(payload.taskId);
  if (taskId) {
    const task = ledger.getTask(taskId);
    ids.push(...generatedDownloadIdsForTask(task));
  }
  return [...new Set(ids)];
}

// Map each task-owned output mediaId to its authoritative kind (images/videos) so a
// synthetic mediaIds-only download can recover the real kind instead of guessing. Only
// tasks whose mode resolves to a concrete kind contribute; ambiguous tasks are skipped.
function agentBridgeMediaKindIndex() {
  const index = new Map();
  for (const task of ledger.listTasks()) {
    const kind = taskMediaKind(task);
    if (kind !== "images" && kind !== "videos") continue;
    for (const mediaId of generatedDownloadIdsForTask(task)) {
      if (mediaId && !index.has(mediaId)) index.set(mediaId, kind);
    }
  }
  return index;
}

function syntheticAgentBridgeGalleryItem(mediaId = "", options = {}) {
  const kind = normalizeAgentBridgeMediaKind(options.kind);
  const idKind = kind || "media";
  return {
    id: `agent-bridge:${idKind}:${mediaId}`,
    mediaId,
    kind,
    projectId: compactString(options.projectId),
    taskNumber: Number(options.index || 0) + 1,
    mediaIndex: Number(options.index || 0),
    title: `${kind === "images" ? "Agent image" : kind === "videos" ? "Agent video" : "Agent media"} ${Number(options.index || 0) + 1}`,
    source: "agent-bridge-request",
    matchMethod: "agent_bridge_media_id",
    mediaUrl: buildMediaRedirectUrl({ mediaId }),
    thumbnailUrl: kind === "videos"
      ? buildMediaThumbnailUrl({ mediaId })
      : buildMediaRedirectUrl({ mediaId }),
    createdAt: new Date().toISOString()
  };
}

function normalizeAgentBridgeMediaKind(value = "") {
  const text = compactString(value).toLowerCase();
  if (text === "image" || text === "images" || text.includes("image")) return "images";
  if (text === "video" || text === "videos" || text.includes("video")) return "videos";
  return "";
}

function agentBridgeError(code = "BRIDGE_ERROR", message = "", details = undefined) {
  const error = new Error(message || code);
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}

async function checkExtensionBridgeFiles(paths = REQUIRED_EXTENSION_BRIDGE_FILES) {
  const files = [];
  for (const filePath of paths) {
    const result = { path: filePath, ok: false, status: 0, error: "" };
    try {
      const response = await fetch(chrome.runtime.getURL(filePath), { cache: "no-store" });
      result.status = Number(response.status || 0);
      result.ok = response.ok === true;
      if (!result.ok) result.error = `http_${result.status || "unknown"}`;
    } catch (error) {
      result.error = compactString(error?.message || error || "extension_resource_fetch_failed");
    }
    files.push(result);
  }
  const missing = files.filter((file) => !file.ok);
  return {
    ok: missing.length === 0,
    files,
    missing: missing.map((file) => file.path),
    error: missing.length ? `EXTENSION_PACKAGE_MISSING_FILE:${missing.map((file) => file.path).join(",")}` : ""
  };
}

async function readBuildFingerprint() {
  try {
    const response = await fetch(chrome.runtime.getURL("build-fingerprint.json"), { cache: "no-store" });
    if (!response.ok) {
      return { ok: false, status: Number(response.status || 0), error: `http_${response.status || "unknown"}` };
    }
    const json = await response.json();
    return { ok: true, fingerprint: json };
  } catch (error) {
    return { ok: false, status: 0, error: compactString(error?.message || error || "build_fingerprint_read_failed") };
  }
}

function classifyDomDebuggerFailure(result = {}) {
  const text = [
    result?.error,
    result?.statusText,
    result?.data?.error,
    result?.data?.failureClass,
    result?.data?.classification,
    result?.data?.preflight?.failedPhase
  ].map((value) => String(value || "")).join(" ");
  if (/t2v_duration_control_missing_store_unverified/i.test(text)) return "t2v_duration_control_missing_store_unverified";
  if (/api_repair_masked_dom_failure/i.test(text)) return "api_repair_masked_dom_failure";
  if (/DOM_PREFLIGHT_FAILED:(version_verified|dist_verified)|EXTENSION_PACKAGE_MISSING_FILE|build_fingerprint|version|stale_bridge|stale_rejected/i.test(text)) return "wrong_dist_or_version";
  if (/DOM_PREFLIGHT_FAILED:profile_verified/i.test(text)) return "wrong_profile_or_extension_id";
  if (/DOM_PREFLIGHT_FAILED:(flow_tab_bound|project_bound)/i.test(text)) return "wrong_flow_tab_or_project";
  if (/DOM_PREFLIGHT_FAILED:auth_ok/i.test(text)) return "auth_or_session_stale";
  if (/DOM_PREFLIGHT_FAILED:bridge_ok/i.test(text)) return "bridge_missing_before_click";
  if (/DOM_PREFLIGHT_FAILED:debugger_ok/i.test(text)) return "debugger_detached_before_click";
  if (/wrong_profile|profile/i.test(text)) return "wrong_profile_or_extension_id";
  if (/flow_tab_not_found|missing_project_id|flow_tab|project_bound|project_id/i.test(text)) return "wrong_flow_tab_or_project";
  if (/not_signed_in|daily_limit|auth|session/i.test(text)) return "auth_or_session_stale";
  if (/PROMPT_NOT_PERSISTED|PROMPT_EMPTY|DOM_PROMPT|prompt_uncommitted/i.test(text)) return "prompt_uncommitted_before_click";
  if (/IMAGE_REF_NOT_ATTACHED|REF_NOT_ATTACHED|REF_ATTACH|COMPOSER_UPLOAD_NOT_SETTLED|refs_uploaded_not_attached/i.test(text)) return "refs_uploaded_not_attached";
  if (/omni_store_ingredients_without_chips|store\.ingredients/i.test(text)) return "omni_store_ingredients_without_chips";
  if (/SETTINGS_STATE_INVALID|SETTINGS_FAILED|settings_invalid|videoApi|videoModelKey|duration:/i.test(text)) return "settings_invalid_before_click";
  if (/CREATE_TARGET_UNSAFE|IMAGE_DETAIL_EDITOR_OPEN|modal|overlay/i.test(text)) return "modal_or_overlay_blocking_click";
  if (/debugger.*detach|not attached to the tab|Debugger is not attached/i.test(text)) return "debugger_detached_before_click";
  if (/flow_bridge|bridge_missing|receiving end|Could not establish connection/i.test(text)) return "bridge_missing_before_click";
  if (/FLOW_CREDITS_BLOCK_F2V|flow_credits_block_f2v|Generating will use\s*-{2,}\s*credits/i.test(text)) return "flow_credits_block_f2v";
  if (/FRONTEND_NOT_UPDATED|network_only|REQUEST_SEEN_WITHOUT_VISIBLE/i.test(text)) return "request_seen_without_visible_pending";
  if (isHardQuotaFailure(text)) return "flow_model_daily_quota_reached";
  if (/PUBLIC_ERROR_UNUSUAL_ACTIVITY|reCAPTCHA|DOM_SUBMIT_REJECTED_403|RESOURCE_EXHAUSTED|\b429\b/i.test(text)) return "flow_session_heat";
  if (/PERMISSION_DENIED/i.test(text) && /\b403\b/.test(text)) return "flow_session_heat";
  if (/500|INTERNAL/i.test(text)) return "backend_500_after_visible_submit";
  if (/gallery.*stale/i.test(text)) return "gallery_card_stale";
  if (/download.*current_row|download.*mismatch/i.test(text)) return "downloaded_asset_not_current_row";
  if (/DOM_DEBUGGER|chrome_debugger|transport/i.test(text)) return "transport_failed_before_click";
  return "";
}

function classifyDomPreflightPhase(phase = "") {
  if (phase === "version_verified" || phase === "dist_verified") return "wrong_dist_or_version";
  if (phase === "profile_verified") return "wrong_profile_or_extension_id";
  if (phase === "flow_tab_bound" || phase === "project_bound") return "wrong_flow_tab_or_project";
  if (phase === "auth_ok") return "auth_or_session_stale";
  if (phase === "bridge_ok") return "bridge_missing_before_click";
  if (phase === "debugger_ok") return "debugger_detached_before_click";
  return "";
}

function preflightFailurePhase(checks = {}) {
  const ordered = [
    "version_verified",
    "dist_verified",
    "profile_verified",
    "flow_tab_bound",
    "project_bound",
    "auth_ok",
    "bridge_ok",
    "debugger_ok"
  ];
  return ordered.find((name) => checks[name] === false) || "";
}

async function domDebuggerPreflightForTask(tabId, task = {}) {
  const numericTabId = Number(tabId || 0);
  const tab = numericTabId ? await chrome.tabs.get(numericTabId).catch(() => null) : null;
  const tabProjectId = projectIdFromUrl(tab?.url || "");
  const resourceCheck = await checkExtensionBridgeFiles().catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "extension_resource_check_failed"),
    missing: [],
    files: []
  }));
  const buildFingerprint = await readBuildFingerprint();
  const bridge = tab?.id
    ? await ensureFlowBridge(tab.id).catch((error) => ({ ok: false, error: compactString(error?.message || error || "flow_bridge_not_ready") }))
    : { ok: false, error: "flow_tab_not_found" };
  const authAccess = runtimeState.auth ? queueStartAccessFromAuthSummary(runtimeState.auth) : null;
  const authBlocking = authAccess && authAccess.allowed === false && ["not_signed_in", "daily_limit_reached"].includes(authAccess.reason);
  const checks = {
    version_verified: Boolean(buildFingerprint.ok && (buildFingerprint.fingerprint?.shortCommit || buildFingerprint.fingerprint?.commit || buildFingerprint.fingerprint?.version)),
    dist_verified: resourceCheck.ok === true,
    profile_verified: Boolean(tab?.id),
    flow_tab_bound: Boolean(tab?.id && isFlowToolUrl(tab.url || "")),
    project_bound: Boolean(tabProjectId || task?.projectId || runtimeState.projectId),
    auth_ok: !authBlocking,
    bridge_ok: isFreshFlowBridge(bridge),
    debugger_ok: Boolean(chrome.debugger?.attach)
  };
  const failedPhase = preflightFailurePhase(checks);
  return {
    ok: !failedPhase,
    failedPhase,
    classification: failedPhase ? classifyDomPreflightPhase(failedPhase) : "",
    checks,
    tabId: numericTabId || null,
    runtimeActiveTabId: runtimeState.activeTabId || null,
    runtimeProjectId: runtimeState.projectId || "",
    tabProjectId,
    tabUrl: tab?.url || "",
    tabStatus: tab?.status || "",
    bridgeVersion: bridge?.bridgeVersion || "",
    pageHookVersion: bridge?.pageHookVersion || "",
    pageHookInstalled: bridge?.pageHookInstalled === true,
    bridgeError: bridge?.error || "",
    authReason: authAccess?.reason || "",
    authTier: authAccess?.tier || "",
    extensionResourceCheck: resourceCheck,
    buildFingerprint: buildFingerprint.ok ? {
      version: buildFingerprint.fingerprint?.version || buildFingerprint.fingerprint?.versionName || "",
      shortCommit: buildFingerprint.fingerprint?.shortCommit || "",
      commit: buildFingerprint.fingerprint?.commit || "",
      sourceRoot: buildFingerprint.fingerprint?.sourceRoot || "",
      dirty: buildFingerprint.fingerprint?.dirty === true
    } : { ok: false, error: buildFingerprint.error || "" }
  };
}

async function ensureFlowBridge(tabId, options = {}) {
  const key = String(tabId || "");
  const state = flowBridgeEnsureState.get(key) || {};
  if (state.singleFlight) {
    const inFlight = await state.singleFlight;
    if (options.forceRecover !== true || isFreshFlowBridge(inFlight)) return inFlight;
  }
  const singleFlight = ensureFlowBridgeOnce(tabId, options)
    .finally(() => {
      const current = flowBridgeEnsureState.get(key);
      if (current?.singleFlight === singleFlight) {
        flowBridgeEnsureState.set(key, {
          ...current,
          singleFlight: null
        });
      }
    });
  flowBridgeEnsureState.set(key, {
    ...state,
    singleFlight
  });
  return singleFlight;
}

async function reloadFlowTabForBridgeRecover(tabId) {
  recordEvent({
    type: "bridge.tab.force_reload",
    tabId,
    reason: "connect_this_flow_tab"
  });
  await chrome.tabs.reload(tabId).catch((error) => {
    recordEvent({
      type: "bridge.tab.force_reload_error",
      tabId,
      error: String(error?.message || error || "tab_reload_failed")
    });
  });
  for (const delayMs of [250, 500, 1000, 1500, 2500, 4000]) {
    await sleep(delayMs);
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab?.id && isFlowToolUrl(tab.url || "") && !isUnloadedFlowTab(tab)) {
      recordEvent({
        type: "bridge.tab.force_reload_ready",
        tabId,
        status: tab.status || ""
      });
      return { ok: true, tab };
    }
  }
  return { ok: false, error: "flow_tab_reload_failed" };
}

async function ensureFlowBridgeOnce(tabId, options = {}) {
  const forceRecover = options.forceRecover === true;
  const key = String(tabId || "");
  const state = flowBridgeEnsureState.get(key) || {};
  const wake = await wakeUnloadedFlowTab(tabId);
  if (!wake?.ok) return { ok: false, error: wake?.error || "flow_tab_unavailable" };
  const firstProbe = await probeFlowBridge(tabId);
  const firstPageEpoch = pageEpochFromProbe(firstProbe);
  if (isFreshFlowBridge(firstProbe)) {
    flowBridgeEnsureState.set(key, {
      ...state,
      pageEpoch: firstPageEpoch,
      lastOkAt: Date.now(),
      cooldownUntil: 0,
      singleFlight: state.singleFlight || null
    });
    return bridgeProbeWithCapabilities(firstProbe, { pageEpoch: firstPageEpoch });
  }
  if (!forceRecover && isSamePageEpochHookPresent(firstProbe, state)) {
    recordEvent({
      type: "bridge.inject.cooldown",
      tabId,
      reason: "same_page_epoch_hook_present",
      bridgeVersion: firstProbe.bridgeVersion || "",
      pageHookVersion: firstProbe.pageHookVersion || "",
      pageHookInstalled: Boolean(firstProbe.pageHookInstalled),
      pageEpoch: firstPageEpoch
    });
    return bridgeProbeWithCapabilities(firstProbe, {
      ok: false,
      error: "flow_bridge_degraded",
      degraded: true,
      degradedReason: "same_page_epoch_hook_present",
      pageEpoch: firstPageEpoch
    });
  }
  const nowMs = Date.now();
  if (!forceRecover && Number(state.cooldownUntil || 0) > nowMs) {
    recordEvent({
      type: "bridge.inject.cooldown",
      tabId,
      reason: "cooldown_backoff",
      cooldownUntil: state.cooldownUntil,
      pageEpoch: firstPageEpoch || state.pageEpoch || ""
    });
    return bridgeProbeWithCapabilities(firstProbe, {
      ok: false,
      error: firstProbe?.error || "flow_bridge_degraded",
      degraded: true,
      degradedReason: "cooldown_backoff",
      pageEpoch: firstPageEpoch || state.pageEpoch || ""
    });
  }
  if (firstProbe?.ok && !isFreshFlowBridge(firstProbe)) {
    recordEvent({
      type: "bridge.inject.stale",
      tabId,
      bridgeVersion: firstProbe.bridgeVersion || "",
      pageHookVersion: firstProbe.pageHookVersion || "",
      pageHookInstalled: Boolean(firstProbe.pageHookInstalled)
    });
  } else if (!forceRecover && !isMissingReceiverError(firstProbe?.error)) {
    return bridgeProbeWithCapabilities(firstProbe, { pageEpoch: firstPageEpoch });
  }

  recordEvent({
    type: "bridge.inject.start",
    tabId,
    reason: firstProbe?.ok ? "stale_bridge_or_page_hook" : firstProbe?.error || "missing_receiver"
  });

  try {
    const extensionResourceCheck = await checkExtensionBridgeFiles();
    if (!extensionResourceCheck.ok) {
      recordEvent({
        type: "bridge.inject.package_missing",
        tabId,
        extensionResourceCheck
      });
      return {
        ok: false,
        error: extensionResourceCheck.error,
        extensionResourceCheck
      };
    }
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [FLOW_BRIDGE_SCRIPT_PATH]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [FLOW_PAGE_HOOK_SCRIPT_PATH],
      world: "MAIN"
    });
  } catch (error) {
    const message = String(error?.message || error || "bridge_injection_failed");
    const extensionResourceCheck = await checkExtensionBridgeFiles().catch((resourceError) => ({
      ok: false,
      files: [],
      missing: [],
      error: compactString(resourceError?.message || resourceError || "extension_resource_check_failed")
    }));
    recordEvent({
      type: "bridge.inject.error",
      tabId,
      error: message,
      extensionResourceCheck
    });
    return { ok: false, error: message, extensionResourceCheck };
  }

  let secondProbe = null;
  const startedAt = Date.now();
  for (const delayMs of [150, 300, 600, 1000, 1500]) {
    if (Date.now() - startedAt > FLOW_BRIDGE_DEGRADED_TIMEOUT_MS) break;
    await sleep(delayMs);
    secondProbe = await probeFlowBridge(tabId);
    if (isFreshFlowBridge(secondProbe)) break;
  }
  const secondPageEpoch = pageEpochFromProbe(secondProbe);
  flowBridgeEnsureState.set(key, {
    ...state,
    pageEpoch: secondPageEpoch || firstPageEpoch || state.pageEpoch || "",
    lastAttemptAt: Date.now(),
    cooldownUntil: Date.now() + FLOW_BRIDGE_INJECTION_COOLDOWN_MS,
    singleFlight: state.singleFlight || null
  });
  recordEvent({
    type: isFreshFlowBridge(secondProbe) ? "bridge.inject.ready" : "bridge.inject.missing",
    tabId,
    error: secondProbe?.error || "",
    bridgeVersion: secondProbe?.bridgeVersion || "",
    pageHookVersion: secondProbe?.pageHookVersion || "",
    pageHookInstalled: Boolean(secondProbe?.pageHookInstalled),
    pageEpoch: secondPageEpoch || ""
  });
  if (isFreshFlowBridge(secondProbe)) {
    return bridgeProbeWithCapabilities(secondProbe, { pageEpoch: secondPageEpoch });
  }
  if (secondProbe?.ok) {
    recordEvent({
      type: "bridge.inject.stale_rejected",
      tabId,
      bridgeVersion: secondProbe.bridgeVersion || "",
      pageHookVersion: secondProbe.pageHookVersion || "",
      pageHookInstalled: Boolean(secondProbe.pageHookInstalled)
    });
  }
  if (forceRecover && options.alreadyReloaded !== true) {
    const reloaded = await reloadFlowTabForBridgeRecover(tabId);
    if (reloaded?.ok) {
      return ensureFlowBridgeOnce(tabId, { forceRecover: true, alreadyReloaded: true });
    }
  }
  return bridgeProbeWithCapabilities(secondProbe || {}, {
    ok: false,
    error: secondProbe?.error || "flow_bridge_not_ready",
    degraded: bridgeCapabilitiesFromProbe(secondProbe || {}).agentDomContextReady === true,
    degradedReason: bridgeCapabilitiesFromProbe(secondProbe || {}).agentDomContextReady === true ? "network_observer_or_native_fetch_degraded" : "",
    bridgeVersion: secondProbe?.bridgeVersion || "",
    pageHookVersion: secondProbe?.pageHookVersion || "",
    pageHookInstalled: Boolean(secondProbe?.pageHookInstalled),
    pageEpoch: secondPageEpoch || ""
  });
}

// Poison-message backpressure: a page command whose result keeps tripping
// the message-size guard (e.g. repeated hi-res video-upscale download
// attempts against the same media) must not be retried forever — every
// retry pays for a full media refetch in the page world just to be dropped
// again. See page-command-poison-guard.js for the (tab, action, media) key
// + strike/cooldown algorithm.
const pageCommandPoisonGuard = createPageCommandPoisonGuard();
const pageCommandPoisonKey = pageCommandPoisonGuard.key;
const notePageCommandPoisonStrike = pageCommandPoisonGuard.noteStrike;
const pageCommandPoisonCooldownActive = pageCommandPoisonGuard.isCooldownActive;
const clearPageCommandPoisonStrikes = pageCommandPoisonGuard.clearStrikes;

// Hard size guard immediately before the message actually leaves the
// service worker. Even though page-hook.js refuses to build oversized
// dataUrls at the source (see MAX_INLINE_MEDIA_DATA_URL_BYTES there), this
// is the last line of defense for any other producer that ends up in a
// PageCommandResult — chrome.runtime message size violations throw
// synchronously and are otherwise unrecoverable mid-flight.
function sendGuardedPageCommandResult(sendResponse, envelope, context = {}) {
  const guard = guardMessagePayload(envelope, {
    limit: MAX_RUNTIME_MESSAGE_BYTES,
    context: `page_command_result:${context.action || "unknown"}`
  });
  const respond = (message) => {
    try {
      sendResponse(message);
    } catch (error) {
      recordEvent({
        type: "bridge.page_command.send_response_failed",
        action: context.action || "",
        tabId: context.tabId || null,
        error: String(error?.message || error || "send_response_failed")
      });
    }
  };
  if (guard.ok) {
    if (context.poisonKey) {
      if (envelope?.result?.code === "MEDIA_PAYLOAD_TOO_LARGE") {
        const producerStrike = notePageCommandPoisonStrike(context.poisonKey);
        recordEvent({
          type: "bridge.page_command.producer_payload_too_large",
          action: context.action || "",
          tabId: context.tabId || null,
          byteLength: Number(envelope.result?.byteLength || 0),
          limit: Number(envelope.result?.limit || 0),
          strikes: producerStrike?.strikes || 1
        });
      } else if (envelope?.ok !== false) {
        clearPageCommandPoisonStrikes(context.poisonKey);
      }
    }
    respond(createMessage(MessageType.PageCommandResult, envelope));
    return;
  }
  const strike = context.poisonKey ? notePageCommandPoisonStrike(context.poisonKey) : null;
  recordEvent({
    type: "bridge.page_command.payload_too_large",
    action: context.action || "",
    tabId: context.tabId || null,
    byteLength: guard.byteLength,
    limit: guard.limit,
    strikes: strike?.strikes || 1
  });
  respond(createMessage(MessageType.PageCommandResult, {
    ok: false,
    tabId: context.tabId || null,
    url: envelope.url || "",
    error: MESSAGE_PAYLOAD_TOO_LARGE_CODE,
    result: buildOversizedResultSummary(context.action, guard, envelope.result)
  }));
}

async function sendPageCommand(payload, preferredTabId) {
  const tab = await findFlowTab(preferredTabId);
  if (!tab?.id) throw new Error("flow_tab_not_found");
  const bridge = await ensureFlowBridge(tab.id);
  if (!bridge?.ok) throw new Error(bridge?.error || "flow_bridge_not_ready");
  const explicitTimeoutMs = Number(payload?.timeoutMs || 0);
  const transportTimeoutMs = explicitTimeoutMs > 0
    ? explicitTimeoutMs + PAGE_COMMAND_TRANSPORT_GRACE_MS
    : PAGE_COMMAND_TRANSPORT_TIMEOUT_MS;
  const result = await sendTabMessage(tab.id, createMessage(MessageType.PageCommandV4, payload, {
    source: "background"
  }), transportTimeoutMs);
  if (result?.ok === false && result?.error === "tab_message_timeout") {
    result.error = `page_command_timeout:${payload?.action || "unknown"}`;
    recordEvent({
      type: "bridge.page_command.transport_timeout",
      action: String(payload?.action || ""),
      tabId: tab.id,
      timeoutMs: transportTimeoutMs
    });
  }
  if (result?.ok === false && !Number(result?.status || 0)) {
    // An ok:false result that carries mediaUrl/dataUrl is a typed
    // MEDIA_PAYLOAD_TOO_LARGE fallback (page-hook only attaches those fields
    // on the proven-fetchable-but-oversized path) — it must reach consumers
    // like resolveDownloadPlan and the poison guard as data, not collapse
    // into a bare exception that discards the safe redirect URL.
    if (payload?.action === "domSubmitTask" || result?.mediaUrl || result?.dataUrl) {
      return {
        tabId: tab.id,
        url: tab.url,
        ...result
      };
    }
    throw new Error(result.error || "page_command_failed");
  }
  return {
    tabId: tab.id,
    url: tab.url,
    ...result
  };
}

function createExecutorForTab(tabId) {
  const flowClient = createFlowClientForTab(tabId);
  const pollSnapshots = new Map();
  const taskContext = (taskId) => {
    const task = ledger.getTask(taskId) || {};
    return {
      mode: task.mode || "",
      submitPath: task.submitPath || task.submitPathPreference || "",
      attempt: Number(task.attempts || 0),
      jobIndex: Number.isFinite(Number(task.jobIndex)) ? Number(task.jobIndex) : null,
      jobPromptCount: Number(task.jobPromptCount || 0),
      repeatCount: Number(task.repeatCount || 1) || 1,
      videoLength: String(task.videoLength || task.videoDurationSeconds || ""),
      model: task.model || "",
      aspectRatio: task.aspectRatio || "",
      failureClass: task.failureClass || "",
      healAction: task.healAction || "",
      lastError: task.lastError || ""
    };
  };
  return createQueueExecutor({
    ledger,
    scheduler,
    flowClient,
    domSubmitter: createDomSubmitterForTab(tabId),
    logger(event = {}) {
      if (event.type === "task_start") {
        recordEvent({
          type: "queue.task.start",
          taskId: event.taskId,
          mode: event.mode || "",
          submitPath: event.submitPath || "",
          attempt: event.attempt || 0,
          jobIndex: event.jobIndex,
          jobPromptCount: event.jobPromptCount || 0,
          repeatCount: event.repeatCount || 1,
          videoLength: event.videoLength || "",
          model: event.model || "",
          aspectRatio: event.aspectRatio || "",
          refCount: event.refCount || 0
        });
        return;
      }
      if (event.type === "submit_path_start") {
        recordEvent({
          type: "queue.submit.start",
          taskId: event.taskId,
          mode: event.mode || "",
          path: event.path || "",
          submitPath: event.submitPath || "",
          attempt: event.attempt || 0,
          jobIndex: event.jobIndex,
          jobPromptCount: event.jobPromptCount || 0,
          repeatCount: event.repeatCount || 1,
          videoLength: event.videoLength || "",
          model: event.model || "",
          aspectRatio: event.aspectRatio || "",
          refCount: event.refCount || 0,
          repairFromApi: Boolean(event.repairFromApi)
        });
        return;
      }
      if (event.type === "dom_submit_stage") {
        recordEvent({
          type: "queue.dom.stage",
          taskId: event.taskId || "",
          mode: event.mode || "",
          stage: event.stage || "",
          ok: event.ok,
          error: event.error || "",
          refCount: event.refCount || 0,
          attached: event.attached || 0,
          matchedCount: event.matchedCount || 0,
          selector: event.selector || "",
          mediaIds: Array.isArray(event.mediaIds) ? event.mediaIds : [],
          serializedIds: Array.isArray(event.serializedIds) ? event.serializedIds : [],
          capturedResponseCount: event.capturedResponseCount || 0,
          stableCount: Number(event.stableCount || 0),
          softSettled: event.softSettled === true,
          strategy: event.strategy || "",
          reason: event.reason || "",
          requestedPrompt: event.requestedPrompt || "",
          persisted: event.persisted || "",
          modeOutcome: event.modeOutcome || null,
          settingsOutcome: event.settingsOutcome || null,
          searchTerms: Array.isArray(event.searchTerms) ? event.searchTerms : [],
          lastTerm: event.lastTerm || "",
          rowCount: Number(event.rowCount || 0),
          rowSample: Array.isArray(event.rowSample) ? event.rowSample.slice(0, 12) : [],
          candidateIds: Array.isArray(event.candidateIds) ? event.candidateIds : [],
          targetImageId: event.targetImageId || "",
          ingredientIds: Array.isArray(event.ingredientIds) ? event.ingredientIds : [],
          requestSerializedIds: Array.isArray(event.requestSerializedIds) ? event.requestSerializedIds : [],
          finalIngredients: Array.isArray(event.finalIngredients) ? event.finalIngredients.slice(0, 12) : [],
          composerChipBaseline: Number(event.composerChipBaseline || 0),
          composerChipCount: Number(event.composerChipCount || 0),
          composerChipDelta: Number(event.composerChipDelta || 0),
	          nativeComposerChipProof: event.nativeComposerChipProof === true,
	          nativeFrameSlotProof: event.nativeFrameSlotProof === true,
	          visibleFrameSlotCount: Number(event.visibleFrameSlotCount || 0),
          missing: Array.isArray(event.missing) ? event.missing : [],
          wrongIngredientTypes: Array.isArray(event.wrongIngredientTypes) ? event.wrongIngredientTypes : [],
          uploadedMediaIds: Array.isArray(event.uploadedMediaIds) ? event.uploadedMediaIds : [],
          assetImageIds: Array.isArray(event.assetImageIds) ? event.assetImageIds : [],
          uploadedMediaId: event.uploadedMediaId || "",
          confirmedImageId: event.confirmedImageId || "",
          candidateId: event.candidateId || "",
          rowImageId: event.rowImageId || "",
          fileName: event.fileName || "",
          progress: event.progress || "",
          found: event.found,
          attempt: event.attempt || 0,
          source: event.source || "",
          text: event.text || "",
          rowText: event.rowText || "",
          candidates: Array.isArray(event.candidates) ? event.candidates.slice(0, 8) : [],
          selectedIds: Array.isArray(event.selectedIds) ? event.selectedIds.slice(0, 12) : [],
          targetIds: Array.isArray(event.targetIds) ? event.targetIds.slice(0, 12) : [],
          selectedText: event.selectedText || "",
          selectedHasVideo: event.selectedHasVideo,
          selectedHasImage: event.selectedHasImage,
          selectionOk: event.selectionOk,
          selectionError: event.selectionError || "",
          idMatched: event.idMatched,
          nameMatched: event.nameMatched,
          cardAttachOk: event.cardAttachOk,
          cardAttachError: event.cardAttachError || "",
          typeRepairOk: event.typeRepairOk,
          promptAttachOk: event.promptAttachOk,
          settledIds: Array.isArray(event.settledIds) ? event.settledIds : [],
	          composerSnapshot: event.composerSnapshot && typeof event.composerSnapshot === "object" ? event.composerSnapshot : null,
	          strictAssetRowMatch: event.strictAssetRowMatch === true,
	          nativeVisibleSlotAttached: event.nativeVisibleSlotAttached === true,
	          slotVisible: event.slotVisible,
	          targetMatched: event.targetMatched,
	          slotMediaIds: Array.isArray(event.slotMediaIds) ? event.slotMediaIds.slice(0, 8) : [],
	          retainedSlotVisible: event.retainedSlotVisible,
	          retainedTargetMatched: event.retainedTargetMatched,
	          retainedSlotMediaIds: Array.isArray(event.retainedSlotMediaIds) ? event.retainedSlotMediaIds.slice(0, 8) : [],
	          selectableAssetResolution: event.selectableAssetResolution || null,
	          domTrace: event.domTrace || null
	        });
        return;
      }
      if (event.type === "submit_path_result") {
        const attachOutcome = event.attachOutcome && typeof event.attachOutcome === "object" ? event.attachOutcome : null;
        const attachSteps = Array.isArray(attachOutcome?.steps) ? attachOutcome.steps : [];
        const failedAttachStep = attachSteps.findLast?.((step) => step && step.ok === false) || attachSteps.find((step) => step && step.ok === false) || null;
        const lastAttachStep = failedAttachStep || attachSteps[attachSteps.length - 1] || null;
        recordEvent({
          type: event.ok ? "queue.submit.ok" : "queue.submit.failed",
          taskId: event.taskId,
          mode: event.mode || "",
          path: event.path || "",
          submitPath: event.submitPath || "",
          transport: event.transport || "",
          status: event.status || 0,
          statusText: event.statusText || "",
          mediaIdCount: event.mediaIdCount || 0,
          endpoint: event.endpoint || "",
          error: event.error || "",
          attachError: attachOutcome?.ok === false ? attachOutcome.error || "" : "",
          attachStep: lastAttachStep?.step || "",
          attachStepError: lastAttachStep?.error || "",
          attachMessage: lastAttachStep?.message || "",
          attachRole: lastAttachStep?.role || "",
          attachFileName: lastAttachStep?.fileName || "",
          attachHasDataUrl: Boolean(lastAttachStep?.hasDataUrl),
          attachStepDetails: lastAttachStep || null,
          attachStepCount: attachSteps.length,
          attachedRefs: Number(attachOutcome?.attached || 0),
          serializedRefs: Array.isArray(attachOutcome?.serializedIds) ? attachOutcome.serializedIds.length : 0,
          repairedFromApi: Boolean(event.repairedFromApi)
        });
        return;
      }
      if (event.type === "submit_path_error") {
        recordEvent({
          type: "queue.submit.error",
          taskId: event.taskId,
          mode: event.mode || "",
          path: event.path || "",
          submitPath: event.submitPath || "",
          error: event.error || "submit_failed",
          repairFromApi: Boolean(event.repairFromApi)
        });
        return;
      }
      if (event.type === "api_403_fresh_token_retry" || event.type === "api_403_dom_fallback" || event.type === "api_session_heat_retry" || event.type === "api_session_heat_dom_fallback") {
        recordEvent({
          type: event.type === "api_403_fresh_token_retry" || event.type === "api_session_heat_retry" ? "queue.api_403.retry" : "queue.api_403.dom_fallback",
          taskId: event.taskId || "",
          mode: event.mode || "",
          submitPath: event.submitPath || "",
          attempt: event.attempt || 0,
          status: event.status || 0,
          statusText: event.statusText || "",
          error: event.error || ""
        });
        return;
      }
      if (["api_backend_dom_fallback", "api_backend_dom_fallback_failed", "api_rejected_dom_fallback", "api_rejected_dom_fallback_failed"].includes(event.type)) {
        const rejectedBeforeAcceptance = event.type.startsWith("api_rejected_");
        const failed = event.type.endsWith("_failed");
        recordEvent({
          type: rejectedBeforeAcceptance
            ? (failed ? "queue.api_rejected.dom_fallback_failed" : "queue.api_rejected.dom_fallback")
            : (failed ? "queue.api_backend.dom_fallback_failed" : "queue.api_backend.dom_fallback"),
          taskId: event.taskId || "",
          mode: event.mode || "",
          submitPath: event.submitPath || "",
          attempt: event.attempt || 0,
          status: event.status || 0,
          statusText: event.statusText || "",
          error: diagnosticString(event.error || event.apiError || ""),
          apiError: diagnosticString(event.apiError || ""),
          domError: diagnosticString(event.domError || "")
        });
        return;
      }
      if (event.type === "reference_upload_start" || event.type === "reference_upload_ok" || event.type === "reference_upload_failed") {
        recordEvent({
          type: event.type === "reference_upload_start"
            ? "media.inline_ref_upload.start"
            : event.type === "reference_upload_ok"
              ? "media.inline_ref_upload.ok"
              : "media.inline_ref_upload.failed",
          taskId: event.taskId || "",
          mode: event.mode || "",
          role: event.role || "",
          fileName: event.fileName || "",
          mediaId: event.mediaId || "",
          status: event.status || 0,
          statusText: event.statusText || "",
          error: event.error || "",
          reason: event.reason || ""
        });
        return;
      }
      if (event.type === "api_repair_media_upload_start" || event.type === "api_repair_media_upload_ok") {
        recordEvent({
          type: event.type === "api_repair_media_upload_start" ? "media.api_repair_upload.start" : "media.api_repair_upload.ok",
          taskId: event.taskId || "",
          mode: event.mode || "",
          role: event.role || "",
          fileName: event.fileName || "",
          mediaId: event.mediaId || "",
          hasDataUrl: Boolean(event.hasDataUrl)
        });
        return;
      }
      if (event.type === "submitted") {
        const resultOk = event.result?.ok === true;
        if (!resultOk) {
          recordEvent({
            type: "queue.submit.rejected",
            taskId: event.taskId,
            mediaIds: event.result?.mediaIds || [],
            status: event.result?.status || 0,
            statusText: event.result?.statusText || "",
            error: diagnosticString(event.result?.error || event.result?.data?.error || event.result?.statusText || ""),
            transport: event.result?.data?.transport || event.result?.transport || (event.result?.endpoint ? "extension_api_submit" : ""),
            repairedFromDom: Boolean(event.result?.repairedFromDom),
            fallbackFromApiBackend: Boolean(event.result?.fallbackFromApiBackend),
            fallbackFromExplicitApiRejection: Boolean(event.result?.fallbackFromExplicitApiRejection),
            domError: diagnosticString(event.result?.domError || event.result?.data?.domError || ""),
            ...taskContext(event.taskId)
          });
          return;
        }
        recordEvent({
          type: "queue.submitted",
          taskId: event.taskId,
          mediaIds: event.result?.mediaIds || [],
          status: event.result?.status || 0,
          statusText: event.result?.statusText || "",
          transport: event.result?.data?.transport || event.result?.transport || (event.result?.endpoint ? "extension_api_submit" : ""),
          repairedFromDom: Boolean(event.result?.repairedFromDom),
          domError: event.result?.domError || "",
          ...taskContext(event.taskId)
        });
        return;
      }
      if (event.type === "dom_api_repair") {
        recordEvent({
          type: "queue.dom_api_repair",
          taskId: event.taskId,
          mode: event.mode || "",
          reason: event.reason || "",
          stage: event.stage || ""
        });
        return;
      }
      if (event.type === "poll") {
        const rows = event.rows || [];
        const signature = rows.map((row) => `${row.id || ""}:${row.status || ""}:${row.rawStatus || ""}`).join("|");
        const previous = pollSnapshots.get(event.taskId);
        const shouldRecord = event.poll === 0 || signature !== previous || event.poll % 6 === 5 || rows.some((row) => ["complete", "failed"].includes(row.status));
        pollSnapshots.set(event.taskId, signature);
        if (!shouldRecord) return;
        recordEvent({
          type: "queue.poll",
          taskId: event.taskId,
          poll: event.poll,
          rows,
          complete: rows.filter((row) => row.status === "complete").length,
          failed: rows.filter((row) => row.status === "failed").length,
          pending: rows.filter((row) => row.status === "pending").length,
          unknown: rows.filter((row) => row.status === "unknown").length,
          ...taskContext(event.taskId)
        });
      }
    },
    async onTaskStateChange({ taskId, reason, task } = {}) {
      recordEvent({
        type: "queue.task.state",
        taskId: taskId || task?.id || "",
        reason: reason || "",
        status: task?.status || "",
        attempts: Number(task?.attempts || 0),
        mediaIds: Array.isArray(task?.mediaIds) ? task.mediaIds : [],
        foundImages: Number(task?.foundImages || 0),
        expectedImages: Number(task?.expectedImages || 0),
        foundVideos: Number(task?.foundVideos || 0),
        expectedVideos: Number(task?.expectedVideos || 0)
      });
      if (
        reason === "video_poll" &&
        task?.status === TaskStatus.generating &&
        ["text-to-video", "image-to-video", "start-end-image-to-video", "ingredients-to-video", "video-to-video"].includes(String(task.mode || "")) &&
        !task.videoGalleryReconcileInFlight
      ) {
        const rows = Array.isArray(task.statusRows) ? task.statusRows : [];
        const hasCompleteUrlLessRows = rows.some((row) => String(row?.status || "") === "complete" && !String(row?.mediaUrl || row?.url || "").trim());
        const expectedVideos = Math.max(1, Number(task.expectedVideos || task.repeatCount || 1) || 1);
        const needsVisibleOutputReconcile = hasCompleteUrlLessRows || Number(task.foundVideos || 0) < expectedVideos;
        if (needsVisibleOutputReconcile) {
          ledger.updateTask(task.id, { videoGalleryReconcileInFlight: true });
          await persistQueueState();
          try {
            const scan = await scanFlowGallery(tabId, { auto: true, lightweight: true });
            recordEvent({
              type: "queue.video_gallery_reconcile.poll",
              taskId: task.id,
              ok: Boolean(scan?.ok),
              galleryCount: scan?.gallery?.items?.length || 0,
              error: scan?.error || ""
            });
          } finally {
            const latest = ledger.getTask(task.id);
            if (latest) ledger.updateTask(task.id, { videoGalleryReconcileInFlight: false });
          }
        }
      }
      return persistQueueState();
    }
  });
}

function createDomSubmitterForTab(tabId) {
  const debuggerEngine = createDebuggerEngine({
    sendPageCommand,
    trace: recordDebuggerTrace,
    responseTimeoutMs: 45000
  });
  return {
    async repairStatusFeedOnlySubmitVisibility(task, result = {}) {
      if (typeof debuggerEngine.repairStatusFeedOnlySubmitVisibility !== "function") {
        return { ok: true, skipped: true, reason: "repair_not_supported" };
      }
      return debuggerEngine.repairStatusFeedOnlySubmitVisibility(tabId, task, result);
    },

    async submitTask(task, meta = {}) {
      if (DOM_DEBUGGER_TRANSPORT_ENABLED) {
        const preflight = await domDebuggerPreflightForTask(tabId, task);
        recordDebuggerTrace(task, "preflight_verified", {
          ok: Boolean(preflight.ok),
          failedPhase: preflight.failedPhase || "",
          classification: preflight.classification || "",
          checks: preflight.checks || {},
          tabId: preflight.tabId,
          runtimeActiveTabId: preflight.runtimeActiveTabId,
          runtimeProjectId: preflight.runtimeProjectId || "",
          tabProjectId: preflight.tabProjectId || "",
          tabStatus: preflight.tabStatus || "",
          bridgeVersion: preflight.bridgeVersion || "",
          pageHookVersion: preflight.pageHookVersion || "",
          pageHookInstalled: preflight.pageHookInstalled === true,
          bridgeError: preflight.bridgeError || "",
          authReason: preflight.authReason || "",
          authTier: preflight.authTier || "",
          buildFingerprint: preflight.buildFingerprint || null,
          extensionMissing: preflight.extensionResourceCheck?.missing || []
        });
        if (!preflight.ok) {
          const error = `DOM_PREFLIGHT_FAILED:${preflight.failedPhase || "unknown"}`;
          return {
            ok: false,
            status: 0,
            statusText: error,
            error,
            data: {
              transport: "chrome_debugger",
              preflight,
              classification: preflight.classification || classifyDomDebuggerFailure({ error })
            }
          };
        }
        const debuggerResult = await debuggerEngine.submitTask(tabId, task, meta).catch((error) => {
          const message = String(error?.message || error || "dom_debugger_submit_failed");
          return {
            ok: false,
            status: 0,
            statusText: message,
            error: message,
            data: { transport: "chrome_debugger", error: message }
          };
        });
        if (debuggerResult?.ok) return debuggerResult;
        const debuggerClassification = debuggerResult?.data?.classification
          || debuggerResult?.data?.failureClass
          || classifyDomDebuggerFailure(debuggerResult);
        if (debuggerResult && typeof debuggerResult === "object") {
          debuggerResult.failureClass = debuggerResult.failureClass || debuggerClassification || "";
          debuggerResult.data = {
            ...(debuggerResult.data || {}),
            classification: debuggerClassification || debuggerResult.data?.classification || ""
          };
        }
        recordEvent({
          type: "queue.dom.debugger_transport_failed",
          taskId: task?.id || "",
          error: debuggerResult?.error || debuggerResult?.statusText || "dom_debugger_submit_failed",
          status: Number(debuggerResult?.status || 0),
          classification: debuggerClassification,
          mode: task?.mode || "",
          submitPath: task?.submitPath || task?.submitPathPreference || "",
          attempt: Number(task?.attempts || 0),
          jobIndex: Number.isFinite(Number(task?.jobIndex)) ? Number(task.jobIndex) : null,
          jobPromptCount: Number(task?.jobPromptCount || 0),
          repeatCount: Number(task?.repeatCount || 1) || 1,
          videoLength: String(task?.videoLength || task?.videoDurationSeconds || "")
        });
        return debuggerResult;
      }
      const page = await sendPageCommand({
        action: "domSubmitTask",
        task,
        meta,
        timeoutMs: 180000
      }, tabId);
      const result = page?.result || page;
      const payload = result?.result || result;
      if (!payload?.ok) {
        return {
          ok: false,
          status: Number(payload?.status || 0),
          error: payload?.error || "dom_submit_failed",
          statusText: payload?.error || "dom_submit_failed",
          data: payload || {}
        };
      }
      return {
        ok: true,
        status: Number(payload.status || 200),
        statusText: payload.statusText || "",
        mediaIds: mediaIdsFrom(payload.mediaIds),
        data: payload
      };
    }
  };
}

function pointFromRect(rect = {}) {
  const x = Number(rect.x || 0) + Number(rect.width || 0) / 2;
  const y = Number(rect.y || 0) + Number(rect.height || 0) / 2;
  return { x: Math.max(1, Math.round(x)), y: Math.max(1, Math.round(y)) };
}

function debuggerTarget(tabId) {
  return { tabId: Number(tabId) };
}

function debuggerSend(target, method, params = {}) {
  return chrome.debugger.sendCommand(target, method, params);
}

async function debuggerClick(target, point) {
  await debuggerSend(target, "Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x: point.x,
    y: point.y,
    button: "none",
    pointerType: "mouse"
  }).catch(() => {});
  await sleep(35);
  await debuggerSend(target, "Input.dispatchMouseEvent", {
    type: "mousePressed",
    x: point.x,
    y: point.y,
    button: "left",
    buttons: 1,
    clickCount: 1,
    pointerType: "mouse"
  });
  await sleep(45);
  await debuggerSend(target, "Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x: point.x,
    y: point.y,
    button: "left",
    buttons: 0,
    clickCount: 1,
    pointerType: "mouse"
  });
}

async function debuggerPressKey(target, key, code, windowsVirtualKeyCode, options = {}) {
  const params = {
    key,
    code,
    windowsVirtualKeyCode,
    nativeVirtualKeyCode: options.nativeVirtualKeyCode || windowsVirtualKeyCode,
    modifiers: Number(options.modifiers || 0)
  };
  await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyDown", ...params }).catch(() => {});
  await sleep(Number(options.holdMs || 25));
  await debuggerSend(target, "Input.dispatchKeyEvent", { type: "keyUp", ...params }).catch(() => {});
}

async function debuggerEvaluate(target, expression) {
  const result = await debuggerSend(target, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true
  });
  return result?.result?.value;
}

function uniqueDebuggerPoints(points = []) {
  const seen = new Set();
  return points
    .filter((point) => Number.isFinite(point?.x) && Number.isFinite(point?.y))
    .map((point) => ({ x: Math.max(1, Math.round(point.x)), y: Math.max(1, Math.round(point.y)) }))
    .filter((point) => {
      const key = `${point.x}:${point.y}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function debuggerModelPatternForTask(task = {}) {
  const mode = String(task.mode || "");
  const raw = String(task.model || "default").trim();
  if (mode === "text-to-image") {
    if (raw === "nano_banana_2_lite") return { source: "Nano\\s+Banana\\s+2\\s+Lite", flags: "i" };
    if (raw === "nano_banana_2") return { source: "Nano\\s+Banana\\s+2(?!\\s+Lite)(?:\\s*\\(Default\\))?", flags: "i" };
    if (raw === "imagen_4" || raw.includes("imagen")) return { source: "Imagen\\s+4", flags: "i" };
    return { source: "Nano\\s+Banana\\s+Pro", flags: "i" };
  }
  if (/^(omni_flash|omni|abra)$/i.test(raw)) return { source: "^Omni\\s+Flash$", flags: "i" };
  if (mode === "ingredients-to-video") {
    return raw === "veo3_fast"
      ? { source: "^Veo 3\\.1\\s*-\\s*Fast$", flags: "i" }
      : { source: "Veo 3\\.1\\s*-\\s*Fast\\s*\\[Lower Priority\\]", flags: "i" };
  }
  if (raw === "veo3_lite") return { source: "^Veo 3\\.1\\s*-\\s*Lite$", flags: "i" };
  if (raw === "veo3_fast") return { source: "^Veo 3\\.1\\s*-\\s*Fast$", flags: "i" };
  if (raw === "veo3_fast_low") return { source: "Veo 3\\.1\\s*-\\s*Fast\\s*\\[Lower Priority\\]", flags: "i" };
  if (raw === "veo3_quality") return { source: "^Veo 3\\.1\\s*-\\s*Quality$", flags: "i" };
  return { source: "Veo 3\\.1\\s*-\\s*Lite\\s*\\[Lower Priority\\]", flags: "i" };
}

function debuggerAspectForTask(task = {}) {
  const raw = String(task.aspectRatio || "").trim().toLowerCase();
  if (String(task.mode || "") === "text-to-image") {
    if (raw === "landscape_4_3" || raw === "4:3") return "4:3";
    if (raw === "square" || raw === "1:1") return "1:1";
    if (raw === "portrait_3_4" || raw === "3:4") return "3:4";
    if (raw === "portrait" || raw === "9:16") return "9:16";
    return "16:9";
  }
  return raw === "portrait" || raw === "9:16" ? "PORTRAIT" : "LANDSCAPE";
}

function debuggerImageAspectTabDescriptor(aspect = "16:9") {
  const escaped = String(aspect || "16:9").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return { kind: "tabText", pattern: `(?:^|\\s)${escaped}$`, flags: "i" };
}

function debuggerDurationForTask(task = {}) {
  if (String(task.mode || "") === "ingredients-to-video" && !/^(omni_flash|omni|abra)$/i.test(String(task.model || ""))) return "8";
  const raw = String(task.videoLength || task.videoDurationSeconds || "8").trim();
  return raw === "4" || raw === "6" || raw === "8" || raw === "10" ? raw : "8";
}

function debuggerVisibleModeForTask(task = {}) {
  const mode = String(task.mode || "");
  if (mode === "text-to-video") return "VIDEO";
  if (mode === "image-to-video" || mode === "start-end-image-to-video") return "VIDEO_FRAMES";
  if (mode === "ingredients-to-video") return "VIDEO_REFERENCES";
  if (mode === "text-to-image") return "IMAGE";
  return "";
}

async function debuggerFindControl(target, descriptor = {}) {
  const descriptorJson = JSON.stringify(descriptor || {});
  const expression = `((descriptor) => {
    const visible = (element) => {
      if (!element) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) !== 0;
    };
    const textOf = (node) => String(node?.innerText || node?.textContent || "").replace(/\\s+/g, " ").trim();
    const normalizeModel = (text) => String(text || "")
      .replace(/\\b(arrow_drop_down|volume_up|volume_off)\\b/gi, " ")
      .replace(/\\(leaving\\s+\\d+\\/\\d+\\)/gi, " ")
      .replace(/\\s+/g, " ")
      .trim();
    const rectOf = (node) => {
      if (!node) return null;
      const rect = node.getBoundingClientRect();
      return { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) };
    };
    const hit = (node, strategy = "") => node ? { ok: true, strategy, id: node.id || "", text: textOf(node), rect: rectOf(node), ariaSelected: node.getAttribute?.("aria-selected") || "", disabled: Boolean(node.disabled || node.getAttribute?.("aria-disabled") === "true") } : null;
    const kind = String(descriptor.kind || "");
    if (kind === "settingsTrigger") {
      const nodes = Array.from(document.querySelectorAll("button[aria-haspopup='menu']"))
        .filter(visible)
        .map((node) => ({ node, rect: node.getBoundingClientRect(), text: textOf(node) }))
        .filter((item) => /x[1-4]|crop_(16_9|9_16|square|landscape|portrait)/i.test(item.text))
        .sort((a, b) => b.rect.y - a.rect.y);
      return hit(nodes[0]?.node, "settings_trigger") || { ok: false, error: "settings_trigger_not_found" };
    }
    if (kind === "tabSuffix") {
      const suffix = String(descriptor.suffix || "");
      const node = Array.from(document.querySelectorAll("button[role='tab']")).filter(visible).find((item) => String(item.getAttribute("id") || "").endsWith(suffix));
      return hit(node, "tab_suffix") || { ok: false, error: "tab_suffix_not_found", suffix };
    }
    if (kind === "tabText") {
      const pattern = new RegExp(String(descriptor.pattern || ""), String(descriptor.flags || ""));
      const node = Array.from(document.querySelectorAll("button[role='tab']")).filter(visible).find((item) => pattern.test(textOf(item)));
      return hit(node, "tab_text") || { ok: false, error: "tab_text_not_found", pattern: String(descriptor.pattern || "") };
    }
    if (kind === "durationTab") {
      const value = String(descriptor.value || "").trim();
      const wanted = new Set([value, value ? value + "s" : ""].filter(Boolean));
      const candidates = Array.from(document.querySelectorAll("button[role='tab']"))
        .filter(visible)
        .filter((item) => wanted.has(textOf(item).replace(/\s+/g, "")))
        .filter((item) => /-trigger-(4|6|8|10)$/.test(String(item.id || "")) || wanted.has(textOf(item).replace(/\s+/g, "")))
        .sort((a, b) => a.getBoundingClientRect().y - b.getBoundingClientRect().y);
      return hit(candidates[0], "duration_tab") || {
        ok: false,
        error: "duration_tab_not_found",
        value,
        visibleNumberTabs: Array.from(document.querySelectorAll("button[role='tab']"))
          .filter(visible)
          .map((item) => ({ id: item.id || "", text: textOf(item), ariaSelected: item.getAttribute("aria-selected") || "", rect: rectOf(item) }))
          .filter((item) => /^(4|6|8|10)s?$/.test(item.text.replace(/\s+/g, "")) || /-trigger-(4|6|8|10)$/.test(item.id))
      };
    }
    if (kind === "modelDropdown") {
      const family = String(descriptor.family || "video");
      const modelPattern = family === "image" ? /(Nano\\s+Banana|Imagen)/i : /(Veo\\s+\\d|Omni\\s+Flash)/i;
      const node = Array.from(document.querySelectorAll("button[aria-haspopup='menu']")).filter(visible).find((item) => modelPattern.test(textOf(item)) && /arrow_drop_down/i.test(textOf(item)));
      return hit(node, "model_dropdown") || { ok: false, error: "model_dropdown_not_found" };
    }
    if (kind === "modelItem") {
      const pattern = new RegExp(String(descriptor.pattern || ""), String(descriptor.flags || ""));
      const family = String(descriptor.family || "video");
      const modelPattern = family === "image" ? /(Nano\\s+Banana|Imagen)/i : /(Veo\\s+\\d|Omni\\s+Flash)/i;
      const candidates = Array.from(document.querySelectorAll("[role='menuitem'], button")).filter(visible).filter((item) => modelPattern.test(textOf(item)));
      const node = candidates.find((item) => pattern.test(normalizeModel(textOf(item))));
      return hit(node, "model_item") || { ok: false, error: "model_item_not_found", pattern: String(descriptor.pattern || ""), visibleVideoModelItems: candidates.map((item) => normalizeModel(textOf(item))).slice(0, 20), visibleVeoItems: candidates.map((item) => normalizeModel(textOf(item))).slice(0, 20) };
    }
    return { ok: false, error: "unknown_control_kind", kind };
  })(${descriptorJson})`;
  return await debuggerEvaluate(target, expression);
}

async function debuggerClickControl(target, descriptor = {}, options = {}) {
  const found = await debuggerFindControl(target, descriptor);
  if (!found?.ok || !found.rect) return { ok: false, descriptor, found };
  if (found.disabled) return { ok: false, descriptor, found, error: "control_disabled" };
  if (options.skipIfSelected === true && String(found.ariaSelected || "") === "true") {
    return { ok: true, descriptor, found, skipped: true };
  }
  await debuggerClick(target, pointFromRect(found.rect));
  await sleep(Number(options.waitMs || 260));
  return { ok: true, descriptor, found };
}

async function debuggerEnsureSettingsMenuOpen(target) {
  const attempts = [];
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const existing = await debuggerFindControl(target, { kind: "tabSuffix", suffix: "-trigger-IMAGE" });
    if (existing?.ok) return { ok: true, opened: attempt > 0, existing, attempts };
    const existingVideo = await debuggerFindControl(target, { kind: "tabSuffix", suffix: "-trigger-VIDEO" });
    if (existingVideo?.ok) return { ok: true, opened: attempt > 0, existing: existingVideo, attempts };

    if (attempt > 0) {
      await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 20 }).catch(() => {});
      await sleep(120);
    }
    const clicked = await debuggerClickControl(target, { kind: "settingsTrigger" }, { waitMs: 420 + attempt * 180 });
    attempts.push({ attempt: attempt + 1, clicked });
    if (!clicked.ok) {
      await sleep(180);
      continue;
    }
    const after = await debuggerFindControl(target, { kind: "tabSuffix", suffix: "-trigger-IMAGE" });
    const afterVideo = await debuggerFindControl(target, { kind: "tabSuffix", suffix: "-trigger-VIDEO" });
    if (after?.ok || afterVideo?.ok) {
      return { ok: true, opened: true, clicked, existing: after?.ok ? after : afterVideo, attempts };
    }
    await sleep(220);
  }
  return { ok: false, error: "settings_menu_not_open", attempts };
}

async function debuggerApplyModeAndSettings(target, task = {}) {
  const isImageMode = String(task.mode || "") === "text-to-image";
  const steps = [];
  recordDebuggerTrace(task, "settings_start");
  const menu = await debuggerEnsureSettingsMenuOpen(target);
  steps.push({ step: "open_settings", ...menu });
  recordDebuggerTrace(task, "settings_open", { ok: Boolean(menu.ok), error: menu.error || "", clickedText: menu.clicked?.found?.text || "", clickedRect: menu.clicked?.found?.rect || null });
  if (!menu.ok) return { ok: false, error: menu.error || "settings_menu_not_open", steps };

  const visibleMode = debuggerVisibleModeForTask(task);
  const suffixMap = {
    VIDEO: "-trigger-VIDEO",
    VIDEO_FRAMES: "-trigger-VIDEO_FRAMES",
    VIDEO_REFERENCES: "-trigger-VIDEO_REFERENCES",
    IMAGE: "-trigger-IMAGE"
  };
  const topMode = visibleMode === "IMAGE" ? "IMAGE" : "VIDEO";
  const topClicked = await debuggerClickControl(target, { kind: "tabSuffix", suffix: suffixMap[topMode] }, { waitMs: 360, skipIfSelected: true });
  steps.push({ step: "top_mode", target: topMode, ...topClicked });
  recordDebuggerTrace(task, "settings_top_mode", { target: topMode, ok: Boolean(topClicked.ok), error: topClicked.error || topClicked.found?.error || "", text: topClicked.found?.text || "", rect: topClicked.found?.rect || null });
  if (!topClicked.ok) return { ok: false, error: "mode_tab_not_clicked", steps };
  if (visibleMode === "VIDEO_FRAMES" || visibleMode === "VIDEO_REFERENCES") {
    const subClicked = await debuggerClickControl(target, { kind: "tabSuffix", suffix: suffixMap[visibleMode] }, { waitMs: 360, skipIfSelected: true });
    steps.push({ step: "sub_mode", target: visibleMode, ...subClicked });
    recordDebuggerTrace(task, "settings_sub_mode", { target: visibleMode, ok: Boolean(subClicked.ok), error: subClicked.error || subClicked.found?.error || "", text: subClicked.found?.text || "", rect: subClicked.found?.rect || null });
    if (!subClicked.ok) return { ok: false, error: "sub_mode_tab_not_clicked", steps };
  }

  const aspect = debuggerAspectForTask(task);
  const aspectDescriptor = isImageMode
    ? debuggerImageAspectTabDescriptor(aspect)
    : { kind: "tabSuffix", suffix: `-trigger-${aspect}` };
  const aspectClicked = await debuggerClickControl(target, aspectDescriptor, { waitMs: 260, skipIfSelected: true });
  steps.push({ step: "aspect", target: aspect, ...aspectClicked });
  recordDebuggerTrace(task, "settings_aspect", { target: aspect, ok: Boolean(aspectClicked.ok), error: aspectClicked.error || aspectClicked.found?.error || "", text: aspectClicked.found?.text || "", rect: aspectClicked.found?.rect || null });
  if (!aspectClicked.ok) return { ok: false, error: "aspect_not_clicked", steps };

  const repeat = Math.max(1, Math.min(4, Number.parseInt(task.repeatCount, 10) || 1));
  const repeatPattern = repeat === 1 ? { pattern: "^1x$", flags: "i" } : { pattern: `^x${repeat}$`, flags: "i" };
  const repeatClicked = await debuggerClickControl(target, { kind: "tabText", ...repeatPattern }, { waitMs: 260, skipIfSelected: true });
  steps.push({ step: "repeat", target: repeat, ...repeatClicked });
  recordDebuggerTrace(task, "settings_repeat", { target: repeat, ok: Boolean(repeatClicked.ok), error: repeatClicked.error || repeatClicked.found?.error || "", text: repeatClicked.found?.text || "", rect: repeatClicked.found?.rect || null });
  if (!repeatClicked.ok) return { ok: false, error: "repeat_not_clicked", steps };

  let duration = "";
  if (!isImageMode) {
    duration = debuggerDurationForTask(task);
    const durationClicked = await debuggerClickControl(target, { kind: "durationTab", value: duration }, { waitMs: 260, skipIfSelected: true });
    steps.push({ step: "duration", target: duration, ...durationClicked });
    recordDebuggerTrace(task, "settings_duration", { target: duration, ok: Boolean(durationClicked.ok), error: durationClicked.error || durationClicked.found?.error || "", text: durationClicked.found?.text || "", rect: durationClicked.found?.rect || null });
    if (!durationClicked.ok) {
      if (durationClicked.found?.error === "duration_tab_not_found") {
        steps.push({ step: "duration_unavailable_assumed", target: duration, reason: "duration_tab_missing_visible_option" });
        recordDebuggerTrace(task, "settings_duration_unavailable_assumed", { target: duration, reason: "duration_tab_missing_visible_option" });
      } else {
        return { ok: false, error: "duration_not_clicked", steps };
      }
    }
  }

  const modelPattern = debuggerModelPatternForTask(task);
  const modelFamily = isImageMode ? "image" : "video";
  const currentModel = await debuggerFindControl(target, { kind: "modelDropdown", family: modelFamily });
  steps.push({ step: "model_current", currentModel });
  recordDebuggerTrace(task, "settings_model_current", { ok: Boolean(currentModel?.ok), error: currentModel?.error || "", text: currentModel?.text || "", rect: currentModel?.rect || null });
  const normalizedCurrent = String(currentModel?.text || "").replace(/\b(arrow_drop_down|volume_up|volume_off)\b/gi, " ").replace(/\(leaving\s+\d+\/\d+\)/gi, " ").replace(/\s+/g, " ").trim();
  if (!new RegExp(modelPattern.source, modelPattern.flags).test(normalizedCurrent)) {
    const modelMenu = await debuggerClickControl(target, { kind: "modelDropdown", family: modelFamily }, { waitMs: 360 });
    steps.push({ step: "model_open", ...modelMenu });
    recordDebuggerTrace(task, "settings_model_open", { ok: Boolean(modelMenu.ok), error: modelMenu.error || modelMenu.found?.error || "", text: modelMenu.found?.text || "", rect: modelMenu.found?.rect || null });
    if (!modelMenu.ok) return { ok: false, error: "model_dropdown_not_clicked", steps };
    const modelItem = await debuggerClickControl(target, { kind: "modelItem", family: modelFamily, pattern: modelPattern.source, flags: modelPattern.flags }, { waitMs: 520 });
    steps.push({ step: "model_select", requested: task.model || "default", ...modelItem });
    recordDebuggerTrace(task, "settings_model_select", { requested: task.model || "default", ok: Boolean(modelItem.ok), error: modelItem.error || modelItem.found?.error || "", text: modelItem.found?.text || "", rect: modelItem.found?.rect || null, visibleVeoItems: modelItem.found?.visibleVeoItems || [] });
    if (!modelItem.ok) return { ok: false, error: "model_item_not_clicked", steps };
  }
  await debuggerPressKey(target, "Escape", "Escape", 27, { holdMs: 25 });
  await sleep(120);
  recordDebuggerTrace(task, "settings_done", { aspect, repeat, duration, model: task.model || "default" });
  return { ok: true, steps, aspect, repeat, duration, model: task.model || "default" };
}

function debuggerPromptClickPoints(prepared = {}) {
  const editor = prepared.editorRect || {};
  const create = prepared.createRect || {};
  const editorX = Number(editor.x || 0);
  const editorY = Number(editor.y || 0);
  const editorWidth = Number(editor.width || 0);
  const editorHeight = Number(editor.height || 0);
  const createX = Number(create.x || 0);
  const createY = Number(create.y || 0);
  return uniqueDebuggerPoints([
    pointFromRect(editor),
    { x: editorX + Math.min(80, Math.max(24, editorWidth / 5)), y: editorY + Math.max(10, editorHeight / 2) },
    { x: editorX + Math.min(120, Math.max(40, editorWidth / 4)), y: createY - 20 },
    { x: editorX + Math.min(120, Math.max(40, editorWidth / 4)), y: createY + 16 },
    { x: createX - 320, y: createY - 20 },
    { x: createX - 320, y: createY + 16 },
    { x: createX - 220, y: createY - 20 },
    { x: createX - 220, y: createY + 16 }
  ]);
}

async function debuggerReadComposerState(target) {
  const expression = `(() => {
    const visible = (element) => {
      if (!element) return false;
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const textOf = (element) => String(element?.value || element?.innerText || element?.textContent || "");
    const editors = Array.from(document.querySelectorAll("textarea, [role='textbox'], [contenteditable='true'], [contenteditable='plaintext-only'], [data-slate-editor='true']"))
      .filter(visible)
      .filter((element) => !element.closest("[data-autoflow-rebuild], #af-bot-panel"))
      .map((element) => {
        const rect = element.getBoundingClientRect();
        return {
          text: textOf(element),
          tag: String(element.tagName || "").toLowerCase(),
          role: element.getAttribute("role") || "",
          contenteditable: element.getAttribute("contenteditable") || "",
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
        };
      });
    const active = document.activeElement;
    const activeRect = active?.getBoundingClientRect ? active.getBoundingClientRect() : null;
    return {
      activeTag: String(active?.tagName || "").toLowerCase(),
      activeRole: active?.getAttribute?.("role") || "",
      activeText: textOf(active),
      activeRect: activeRect ? { x: Math.round(activeRect.x), y: Math.round(activeRect.y), width: Math.round(activeRect.width), height: Math.round(activeRect.height) } : null,
      editors
    };
  })()`;
  const result = await debuggerSend(target, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true
  }).catch((error) => ({ result: { value: { error: String(error?.message || error) } } }));
  return result?.result?.value || {};
}

async function debuggerSelectAll(target) {
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "Meta",
    code: "MetaLeft",
    windowsVirtualKeyCode: 91,
    nativeVirtualKeyCode: 91,
    modifiers: 4
  });
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "a",
    code: "KeyA",
    windowsVirtualKeyCode: 65,
    nativeVirtualKeyCode: 65,
    modifiers: 4
  });
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "a",
    code: "KeyA",
    windowsVirtualKeyCode: 65,
    nativeVirtualKeyCode: 65,
    modifiers: 4
  });
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "Meta",
    code: "MetaLeft",
    windowsVirtualKeyCode: 91,
    nativeVirtualKeyCode: 91
  });
}

async function debuggerBackspace(target) {
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "Backspace",
    code: "Backspace",
    windowsVirtualKeyCode: 8,
    nativeVirtualKeyCode: 51
  }).catch(() => {});
  await debuggerSend(target, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "Backspace",
    code: "Backspace",
    windowsVirtualKeyCode: 8,
    nativeVirtualKeyCode: 51
  }).catch(() => {});
}

async function debuggerSelectAllAndInsert(target, text = "") {
  await debuggerSelectAll(target);
  await sleep(40);
  await debuggerBackspace(target);
  await sleep(60);
  await debuggerSelectAll(target);
  await sleep(40);
  await debuggerBackspace(target);
  await sleep(45);
  await debuggerSend(target, "Input.insertText", { text: String(text || "") });
}

async function debuggerFocusPreparedEditor(target, prepared = {}) {
  const rect = prepared?.editorRect || {};
  const expression = `((targetRect) => {
    const visible = (element) => {
      if (!element) return false;
      const style = getComputedStyle(element);
      const box = element.getBoundingClientRect();
      return box.width > 0 && box.height > 0 && style.display !== "none" && style.visibility !== "hidden";
    };
    const textOf = (element) => String(element?.value || element?.innerText || element?.textContent || "");
    const candidates = Array.from(document.querySelectorAll("textarea, [role='textbox'], [contenteditable='true'], [contenteditable='plaintext-only'], [data-slate-editor='true']"))
      .filter(visible)
      .filter((element) => !element.closest("[data-autoflow-rebuild], #af-bot-panel"))
      .map((element) => {
        const box = element.getBoundingClientRect();
        const dx = Math.abs((box.x + box.width / 2) - (Number(targetRect.x || 0) + Number(targetRect.width || 0) / 2));
        const dy = Math.abs((box.y + box.height / 2) - (Number(targetRect.y || 0) + Number(targetRect.height || 0) / 2));
        return { element, box, score: dx + dy, text: textOf(element) };
      })
      .sort((a, b) => a.score - b.score);
    const hit = candidates[0]?.element || null;
    if (!hit) return { ok: false, error: "editor_not_found" };
    hit.focus?.({ preventScroll: true });
    const box = hit.getBoundingClientRect();
    hit.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window, clientX: box.x + Math.min(40, box.width / 2), clientY: box.y + box.height / 2 }));
    hit.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window, clientX: box.x + Math.min(40, box.width / 2), clientY: box.y + box.height / 2 }));
    hit.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window, clientX: box.x + Math.min(40, box.width / 2), clientY: box.y + box.height / 2 }));
    return {
      ok: document.activeElement === hit || hit.contains(document.activeElement),
      tag: String(hit.tagName || "").toLowerCase(),
      role: hit.getAttribute("role") || "",
      text: textOf(hit).slice(0, 160),
      rect: { x: Math.round(box.x), y: Math.round(box.y), width: Math.round(box.width), height: Math.round(box.height) }
    };
  })(${JSON.stringify(rect)})`;
  const value = await debuggerEvaluate(target, expression).catch((error) => ({ ok: false, error: String(error?.message || error) }));
  return value || { ok: false, error: "focus_no_result" };
}

async function debuggerFocusAndInsertPrompt(target, prepared = {}, prompt = "") {
  const text = String(prompt || "");
  const normalizedTarget = text.replace(/\s+/g, " ").trim();
  const points = debuggerPromptClickPoints(prepared);
  const attempts = [];
  const focused = await debuggerFocusPreparedEditor(target, prepared);
  if (focused?.ok) {
    await sleep(120);
    await debuggerSelectAllAndInsert(target, text);
    await sleep(220);
    const state = await debuggerReadComposerState(target);
    const editorTexts = Array.isArray(state.editors) ? state.editors.map((editor) => String(editor.text || "")) : [];
    const values = [String(state.activeText || ""), ...editorTexts];
    const inserted = values.some((value) => value.replace(/\s+/g, " ").trim() === normalizedTarget);
    attempts.push({
      point: focused.rect ? pointFromRect(focused.rect) : null,
      inserted,
      activeTag: state.activeTag || "",
      activeRole: state.activeRole || "",
      activeRect: state.activeRect || null,
      editorCount: editorTexts.length,
      editorTexts: editorTexts.map((value) => value.slice(0, 160)),
      focusMethod: "runtime_focus_editor"
    });
    recordDebuggerTrace({ id: prepared.taskId || "", mode: prepared.mode || "", prompt: text }, "prompt_insert_attempt", {
      point: focused.rect ? pointFromRect(focused.rect) : null,
      inserted,
      activeTag: state.activeTag || "",
      activeRole: state.activeRole || "",
      editorCount: editorTexts.length,
      editorTexts: editorTexts.map((value) => value.slice(0, 160)),
      focusMethod: "runtime_focus_editor",
      focusResult: focused
    });
    if (inserted) {
      return { ok: true, point: focused.rect ? pointFromRect(focused.rect) : null, attempts, state };
    }
  } else {
    recordDebuggerTrace({ id: prepared.taskId || "", mode: prepared.mode || "", prompt: text }, "prompt_focus_result", {
      ok: false,
      error: focused?.error || "runtime_focus_failed"
    });
  }
  for (const point of points) {
    await debuggerClick(target, point);
    await sleep(120);
    await debuggerSelectAllAndInsert(target, text);
    await sleep(220);
    const state = await debuggerReadComposerState(target);
    const editorTexts = Array.isArray(state.editors) ? state.editors.map((editor) => String(editor.text || "")) : [];
    const values = [String(state.activeText || ""), ...editorTexts];
    const inserted = values.some((value) => value.replace(/\s+/g, " ").trim() === normalizedTarget);
    attempts.push({
      point,
      inserted,
      activeTag: state.activeTag || "",
      activeRole: state.activeRole || "",
      activeRect: state.activeRect || null,
      editorCount: editorTexts.length,
      editorTexts: editorTexts.map((value) => value.slice(0, 160))
    });
    recordDebuggerTrace({ id: prepared.taskId || "", mode: prepared.mode || "", prompt: text }, "prompt_insert_attempt", {
      point,
      inserted,
      activeTag: state.activeTag || "",
      activeRole: state.activeRole || "",
      editorCount: editorTexts.length,
      editorTexts: editorTexts.map((value) => value.slice(0, 160))
    });
    if (inserted) {
      return { ok: true, point, attempts, state };
    }
  }
  return {
    ok: false,
    error: "DOM_DEBUGGER_PROMPT_NOT_INSERTED",
    attempts,
    state: await debuggerReadComposerState(target)
  };
}

async function debuggerHitTest(target, point = {}) {
  const expression = `((point) => {
    const textOf = (node) => String(node?.innerText || node?.textContent || node?.value || "").replace(/\\s+/g, " ").trim();
    const node = document.elementFromPoint(Number(point.x || 0), Number(point.y || 0));
    const button = node?.closest?.("button, [role='button']") || node;
    const rect = button?.getBoundingClientRect?.();
    return {
      ok: Boolean(button),
      tag: String(button?.tagName || "").toLowerCase(),
      role: button?.getAttribute?.("role") || "",
      ariaLabel: button?.getAttribute?.("aria-label") || "",
      text: textOf(button),
      disabled: Boolean(button?.disabled || button?.getAttribute?.("aria-disabled") === "true"),
      rect: rect ? { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) } : null
    };
  })(${JSON.stringify(point)})`;
  return debuggerEvaluate(target, expression).catch((error) => ({ ok: false, error: String(error?.message || error) }));
}

function hitLooksLikeCreateButton(hit = {}) {
  const text = `${hit.text || ""} ${hit.ariaLabel || ""}`.toLowerCase();
  if (hit.disabled) return false;
  if (text.includes("delete") || text.includes("remove") || text.includes("trash")) return false;
  return /arrow_forward|create|submit|generate|send/.test(text);
}

async function waitForDebuggerGenerationResponse(target, { projectId = "", expectedCount = 1, timeoutMs = 90000 } = {}) {
  const deadline = Date.now() + Number(timeoutMs || 90000);
  const requiredCount = Math.max(1, Number(expectedCount || 1) || 1);
  const requestIds = new Set();
  const responseBodies = [];
  const isGenerationUrl = (url = "") => /video:batchAsyncGenerateVideoText|image:batchAsyncGenerateImage|image:asyncGenerateImage/i.test(String(url || ""));
  let done;
  const promise = new Promise((resolve) => {
    done = resolve;
  });
  const listener = async (source, method, params = {}) => {
    if (source.tabId !== target.tabId) return;
    if (method === "Network.requestWillBeSent" && isGenerationUrl(params.request?.url || "")) {
      requestIds.add(params.requestId);
    }
    if (method === "Network.responseReceived" && requestIds.has(params.requestId)) {
      try {
        const body = await debuggerSend(target, "Network.getResponseBody", { requestId: params.requestId });
        const text = body?.body || "";
        const data = JSON.parse(String(text || "").replace(/^\)\]\}',?\s*/, "").trim() || "null");
        const mediaIds = extractMediaIds(data, { projectId });
        responseBodies.push({ status: params.response?.status || 0, url: params.response?.url || "", mediaIds, data });
        if (mediaIds.length >= requiredCount) done(responseBodies[responseBodies.length - 1]);
      } catch (error) {
        responseBodies.push({ status: params.response?.status || 0, url: params.response?.url || "", mediaIds: [], error: String(error?.message || error) });
      }
    }
  };
  chrome.debugger.onEvent.addListener(listener);
  try {
    while (Date.now() < deadline) {
      const complete = responseBodies.find((row) => Number(row.mediaIds?.length || 0) >= requiredCount);
      if (complete) return complete;
      const remaining = deadline - Date.now();
      const result = await Promise.race([
        promise,
        sleep(Math.min(500, Math.max(50, remaining))).then(() => null)
      ]);
      if (result && Number(result.mediaIds?.length || 0) >= requiredCount) return result;
    }
    const best = responseBodies
      .filter((row) => row.mediaIds?.length)
      .sort((a, b) => Number(b.mediaIds?.length || 0) - Number(a.mediaIds?.length || 0))[0];
    if (best) {
      return {
        ...best,
        incomplete: true,
        expectedCount: requiredCount,
        error: `DOM_DEBUGGER_INCOMPLETE_MEDIA_IDS:${best.mediaIds.length}/${requiredCount}`
      };
    }
    return { status: 0, mediaIds: [], expectedCount: requiredCount, error: "DOM_DEBUGGER_REQUEST_NOT_OBSERVED" };
  } finally {
    chrome.debugger.onEvent.removeListener(listener);
  }
}

async function submitTaskWithDebuggerTransport(tabId, task = {}, meta = {}) {
  if (!chrome.debugger?.attach) {
    return { ok: false, status: 0, statusText: "DOM_DEBUGGER_PERMISSION_UNAVAILABLE", error: "DOM_DEBUGGER_PERMISSION_UNAVAILABLE" };
  }
  const target = debuggerTarget(tabId);
  let attached = false;
  try {
    recordDebuggerTrace(task, "attach_start", { tabId });
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    recordDebuggerTrace(task, "attach_ok", { tabId });
    await debuggerSend(target, "Network.enable");

    const prep = await sendPageCommand({
      action: "domPrepareTaskForDebugger",
      task,
      meta: {
        ...meta,
        debuggerTransport: true,
        skipDomModeAndSettingsMutation: true
      },
      timeoutMs: 120000
    }, tabId);
    const prepared = prep?.result?.result || prep?.result || prep;
    prepared.taskId = task?.id || "";
    prepared.mode = task?.mode || "";
    recordDebuggerTrace(task, "prep_result", {
      ok: Boolean(prepared?.ok),
      error: prepared?.error || "",
      editorRect: prepared?.editorRect || null,
      createRect: prepared?.createRect || null,
      selector: prepared?.selector || "",
      strategy: prepared?.strategy || ""
    });
    if (!prepared?.ok) {
      const error = prepared?.error || "DOM_DEBUGGER_PREP_FAILED";
      return {
        ok: false,
        status: Number(prepared?.status || 0),
        statusText: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_PREP_FAILED:${error}`,
        error: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_PREP_FAILED:${error}`,
        data: { ...(prepared || {}), transport: "chrome_debugger" }
      };
    }

    const requestedRepeat = Math.max(1, Number(task.repeatCount || task.expectedVideos || task.expectedImages || 1) || 1);
    recordDebuggerTrace(task, "settings_gate", {
      debuggerSettingsEnabled: true,
      requestedRepeat,
      reason: "video_dom_settings_required_per_task"
    });
    const settings = await debuggerApplyModeAndSettings(target, task);
    recordDebuggerTrace(task, "settings_result", {
      ok: Boolean(settings.ok),
      skipped: Boolean(settings.skipped),
      reason: settings.reason || "",
      error: settings.error || "",
      aspect: settings.aspect || "",
      repeat: settings.repeat || "",
      duration: settings.duration || "",
      model: settings.model || "",
      requestedRepeat,
      selectedRepeat: settings.selectedRepeat || "",
      settingsTriggerText: settings.settingsTriggerText || ""
    });
    if (!settings.ok) {
      const error = settings.error || "settings_failed";
      return {
        ok: false,
        status: 0,
        statusText: `DOM_DEBUGGER_SETTINGS_FAILED:${error}`,
        error: `DOM_DEBUGGER_SETTINGS_FAILED:${error}`,
        data: { prepared, settings, transport: "chrome_debugger" }
      };
    }

    const refreshedPrep = await sendPageCommand({
      action: "domPrepareTaskForDebugger",
      task,
      meta: {
        ...meta,
        debuggerTransport: true,
        skipDomModeAndSettingsMutation: true,
        afterDebuggerSettings: true
      },
      timeoutMs: 120000
    }, tabId);
    const refreshedPrepared = refreshedPrep?.result?.result || refreshedPrep?.result || refreshedPrep;
    if (refreshedPrepared?.ok) {
      prepared.editorRect = refreshedPrepared.editorRect || prepared.editorRect;
      prepared.createRect = refreshedPrepared.createRect || prepared.createRect;
      prepared.selector = refreshedPrepared.selector || prepared.selector;
      prepared.strategy = refreshedPrepared.strategy || prepared.strategy;
    }
    recordDebuggerTrace(task, "prep_refreshed", {
      ok: Boolean(refreshedPrepared?.ok),
      error: refreshedPrepared?.error || "",
      editorRect: prepared.editorRect || null,
      createRect: prepared.createRect || null,
      selector: prepared.selector || "",
      strategy: prepared.strategy || ""
    });
    prepared.debuggerSettings = settings;

    const commitPrep = await sendPageCommand({
      action: "domCommitPromptForDebugger",
      task,
      timeoutMs: 120000
    }, tabId);
    const committed = commitPrep?.result?.result || commitPrep?.result || commitPrep;
    recordDebuggerTrace(task, "prompt_commit_page_hook", {
      ok: Boolean(committed?.ok),
      error: committed?.error || "",
      persisted: committed?.commit?.persisted || "",
      storePersisted: committed?.commit?.storePersisted || "",
      slatePersisted: committed?.commit?.slatePersisted || "",
      method: committed?.commit?.method || "",
      createRect: committed?.createRect || null,
      selector: committed?.selector || "",
      strategy: committed?.strategy || ""
    });
    if (!committed?.ok) {
      const error = committed?.error || "DOM_PROMPT_NOT_PERSISTED";
      return {
        ok: false,
        status: 0,
        statusText: error,
        error,
        data: { prepared, committed, transport: "chrome_debugger" }
      };
    }
    prepared.editorRect = committed.editorRect || prepared.editorRect;
    prepared.createRect = committed.createRect || prepared.createRect;
    prepared.selector = committed.selector || prepared.selector;
    prepared.strategy = committed.strategy || prepared.strategy;
    prepared.visible = committed.visible || prepared.visible;
    prepared.store = committed.store || prepared.store;
    prepared.createButton = committed.createButton || prepared.createButton;

    const createPoint = pointFromRect(prepared.createRect);
    const inserted = { ok: true, point: null, skipped: true, reason: "page_hook_prompt_commit" };
    recordDebuggerTrace(task, "prompt_insert_result", { ok: Boolean(inserted.ok), error: inserted.error || "", point: inserted.point || null });
    if (!inserted.ok) {
      const error = inserted.error || "prompt_not_inserted";
      return {
        ok: false,
        status: 0,
        statusText: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_PROMPT_NOT_INSERTED:${error}`,
        error: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_PROMPT_NOT_INSERTED:${error}`,
        data: { prepared, inserted, transport: "chrome_debugger" }
      };
    }
    const refreshedAfterInsert = await sendPageCommand({
      action: "domPrepareTaskForDebugger",
      task,
      meta: {
        ...meta,
        debuggerTransport: true,
        skipDomModeAndSettingsMutation: true,
        afterPromptInsert: true
      },
      timeoutMs: 120000
    }, tabId);
    const afterInsert = refreshedAfterInsert?.result?.result || refreshedAfterInsert?.result || refreshedAfterInsert;
    if (afterInsert?.ok) {
      prepared.editorRect = afterInsert.editorRect || prepared.editorRect;
      prepared.createRect = afterInsert.createRect || prepared.createRect;
      prepared.selector = afterInsert.selector || prepared.selector;
      prepared.strategy = afterInsert.strategy || prepared.strategy;
    }
    const safeCreatePoint = pointFromRect(prepared.createRect);
    const hit = await debuggerHitTest(target, safeCreatePoint);
    recordDebuggerTrace(task, "submit_hit_test", { createPoint: safeCreatePoint, hit });
    if (!hitLooksLikeCreateButton(hit)) {
      return {
        ok: false,
        status: 0,
        statusText: "DOM_DEBUGGER_CREATE_TARGET_UNSAFE",
        error: "DOM_DEBUGGER_CREATE_TARGET_UNSAFE",
        data: { prepared, hit, createPoint: safeCreatePoint, transport: "chrome_debugger" }
      };
    }
    await sleep(350);
    const expectedCount = Number(task.expectedVideos || task.expectedImages || task.repeatCount || 1);
    const responsePromise = waitForDebuggerGenerationResponse(target, {
      projectId: prepared.projectId || "",
      expectedCount,
      timeoutMs: Math.min(12000, Number(meta.responseTimeoutMs || 12000) || 12000)
    });
    recordDebuggerTrace(task, "submit_click", { createPoint: safeCreatePoint, expectedCount });
    await debuggerClick(target, safeCreatePoint);
    const response = await responsePromise;
    const mediaIds = mediaIdsFrom(response?.mediaIds || []);
    recordDebuggerTrace(task, "response_result", {
      status: Number(response?.status || 0),
      error: response?.error || "",
      mediaIdCount: mediaIds.length,
      mediaIds,
      expectedCount,
      incomplete: Boolean(response?.incomplete)
    });
    if (!mediaIds.length) {
      const error = response?.error || "request_not_observed";
      return {
        ok: false,
        status: Number(response?.status || 0),
        statusText: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_REQUEST_NOT_OBSERVED:${error}`,
        error: /^DOM_DEBUGGER_/i.test(error) ? error : `DOM_DEBUGGER_REQUEST_NOT_OBSERVED:${error}`,
        data: { prepared, response, transport: "chrome_debugger" }
      };
    }
    if (mediaIds.length < expectedCount) {
      recordDebuggerTrace(task, "partial_media_ids_allowed", {
        mediaIdCount: mediaIds.length,
        expectedCount,
        mediaIds
      });
    }
    return {
      ok: true,
      status: Number(response.status || 200),
      statusText: mediaIds.length < expectedCount ? `DOM_DEBUGGER_PARTIAL_MEDIA_IDS:${mediaIds.length}/${expectedCount}` : "DOM_DEBUGGER_SUBMIT_OK",
      mediaIds,
      data: {
        ...prepared,
        response,
        mediaIds,
        expectedCount,
        partialMediaIds: mediaIds.length < expectedCount,
        transport: "chrome_debugger"
      }
    };
  } finally {
    if (attached) {
      await chrome.debugger.detach(target).catch(() => {});
      recordDebuggerTrace(task, "detach", { tabId });
    }
  }
}

function createFlowClientForTab(tabId) {
  const transport = createPageFlowTransport({
    sendPageCommand: (payload) => sendPageCommand(payload, tabId)
  });
  return createFlowClient({
    fetchImpl: transport.fetchImpl,
    recaptchaProvider: transport.recaptchaProvider,
    videoUploadProvider: transport.videoUploadProvider
  });
}

function createFlowCreationAgentClientForTab(tabId) {
  const transport = createPageFlowTransport({
    sendPageCommand: (payload) => sendPageCommand(payload, tabId)
  });
  return createFlowCreationAgentClient({
    fetchImpl: transport.fetchImpl,
    recaptchaProvider: transport.recaptchaProvider,
    clientSessionIdProvider: ({ projectId, agentSessionId }) => agentApiClientSessionId(tabId, projectId, agentSessionId)
  });
}

function agentApiClientSessionId(targetId, projectId, agentSessionId) {
  const key = `${compactString(targetId)}:${compactString(projectId)}:${compactString(agentSessionId)}`;
  let clientSessionId = agentApiClientSessionIds.get(key);
  if (!clientSessionId) {
    clientSessionId = globalThis.crypto?.randomUUID?.() || `autoflow-agent-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    agentApiClientSessionIds.set(key, clientSessionId);
  }
  return clientSessionId;
}

function mediaIdsFrom(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map((id) => compactString(id)).filter(Boolean))];
}

function localRefIdsFrom(refs = []) {
  return new Set((Array.isArray(refs) ? refs : [])
    .flatMap((ref) => [ref?.blobStoreId, ref?.id].map(compactString).filter(Boolean)));
}

function mediaIdFromRefInput(ref = {}) {
  const mediaId = compactString(ref?.mediaId || ref?.assetImageId);
  if (!mediaId) return "";
  return localRefIdsFrom([ref]).has(mediaId) ? "" : mediaId;
}

function firstFlowMediaId(values = [], refs = []) {
  const localIds = localRefIdsFrom(refs);
  return (Array.isArray(values) ? values : [])
    .map(compactString)
    .find((mediaId) => mediaId && !localIds.has(mediaId)) || "";
}

function compactDiagnosticPreview(value = "", limit = 240) {
  return compactString(String(value || "").replace(/\s+/g, " ").trim()).slice(0, limit);
}

function diagnosticHash(value = "") {
  let hash = 2166136261;
  for (const char of String(value || "")) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

async function evaluateFlowRendererCrashDom(tabId = 0) {
  if (!chrome.debugger?.attach) return { ok: false, error: "chrome_debugger_unavailable" };
  await releaseDebuggerSessions("flow_renderer_crash_detect", recordDebuggerTrace).catch(() => null);
  const target = debuggerTarget(tabId);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Runtime.enable").catch(() => {});
    const result = await debuggerSend(target, "Runtime.evaluate", {
      expression: `(() => ({
        href: location.href,
        title: document.title || "",
        text: (document.body && (document.body.innerText || document.body.textContent) || "").slice(0, 1000)
      }))()`,
      returnByValue: true,
      awaitPromise: false
    });
    return { ok: true, ...(result?.result?.value || {}) };
  } catch (error) {
    return { ok: false, error: compactString(error?.message || error || "renderer_crash_dom_probe_failed") };
  } finally {
    if (attached) await chrome.debugger.detach(target).catch(() => {});
  }
}

async function detectFlowRendererCrashForTask(task = {}, tabId = 0, phase = "") {
  const tab = Number(tabId || 0) ? await chrome.tabs.get(Number(tabId)).catch(() => null) : null;
  const base = {
    url: tab?.url || "",
    title: tab?.title || "",
    text: "",
    error: "",
    phase
  };
  let crash = detectFlowRendererCrashSnapshot(base);
  if (crash.crashed) {
    return {
      ...crash,
      ...base,
      tabId: Number(tabId || 0) || null,
      projectId: projectIdFromUrl(tab?.url || "") || task?.projectId || runtimeState.projectId || ""
    };
  }
  if (!tab?.id || !isFlowToolUrl(tab.url || "")) {
    return {
      ...crash,
      ...base,
      tabId: Number(tabId || 0) || null,
      projectId: task?.projectId || runtimeState.projectId || ""
    };
  }
  const dom = await evaluateFlowRendererCrashDom(tab.id);
  crash = detectFlowRendererCrashSnapshot({
    url: dom?.href || tab.url || "",
    title: [tab.title || "", dom?.title || ""].filter(Boolean).join(" "),
    text: dom?.text || "",
    error: dom?.error || ""
  });
  return {
    ...crash,
    url: dom?.href || tab.url || "",
    title: dom?.title || tab.title || "",
    text: dom?.text || "",
    error: dom?.error || "",
    tabId: tab.id,
    projectId: projectIdFromUrl(dom?.href || tab.url || "") || task?.projectId || runtimeState.projectId || "",
    phase
  };
}

function flowRendererCrashTriggerText(task = {}, crash = {}) {
  return diagnosticString([
    crash?.textPreview,
    crash?.title,
    crash?.error,
    task?.lastError,
    task?.failureClass,
    task?.healAction
  ]);
}

async function flowRendererCrashEventFields(task = {}, tabId = 0, recoveryLevel = "", detail = {}) {
  const tab = Number(tabId || 0) ? await chrome.tabs.get(Number(tabId)).catch(() => null) : null;
  const buildResult = detail.buildFingerprintResult || await readBuildFingerprint().catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "build_fingerprint_read_failed")
  }));
  const bridgeBefore = detail.bridgeBefore || detail.bridge || {};
  const bridgeAfter = detail.bridgeAfter || {};
  const textPreview = compactDiagnosticPreview(detail.textPreview || detail.text || detail.triggerError || task?.lastError || "");
  const errorCode = compactString(detail.errorCode || flowRendererCrashErrorCode(textPreview || task?.lastError || ""));
  return {
    tabId: Number(tabId || 0) || null,
    projectId: compactString(detail.projectId || task?.projectId || runtimeState.projectId || projectIdFromUrl(tab?.url || "")),
    url: compactString(detail.url || tab?.url || ""),
    title: compactDiagnosticPreview(detail.title || tab?.title || "", 160),
    detectedTextHash: textPreview ? diagnosticHash(textPreview) : "",
    textPreview,
    errorCode,
    taskId: task?.id || "",
    mode: task?.mode || "",
    submitPath: task?.submitPath || task?.submitPathPreference || "",
    attempt: Number(task?.attempts || 0),
    buildFingerprint: summarizeBuildFingerprint(buildResult),
    bridgeVersion: bridgeAfter?.bridgeVersion || bridgeBefore?.bridgeVersion || "",
    pageHookVersion: bridgeAfter?.pageHookVersion || bridgeBefore?.pageHookVersion || "",
    bridgeVersionBefore: bridgeBefore?.bridgeVersion || "",
    pageHookVersionBefore: bridgeBefore?.pageHookVersion || "",
    bridgeVersionAfter: bridgeAfter?.bridgeVersion || "",
    pageHookVersionAfter: bridgeAfter?.pageHookVersion || "",
    recoveryLevel,
    cacheCleared: detail.cacheCleared === true,
    ignoreCacheReload: detail.ignoreCacheReload === true,
    ...detail
  };
}

async function recordFlowRendererCrashEvent(type, task = {}, tabId = 0, recoveryLevel = "", detail = {}) {
  const fields = await flowRendererCrashEventFields(task, tabId, recoveryLevel, detail);
  recordEvent({ type, ...fields });
}

async function markFlowRendererCrashDetected(task = {}, tabId = 0, crash = {}, phase = "detected") {
  const triggerError = `FLOW_RENDERER_CRASHED:${crash.errorCode ? `Error code: ${crash.errorCode}` : (crash.textPreview || "Aw, Snap")}`;
  const blocked = ledger.updateTask(task.id, {
    status: TaskStatus.blocked,
    failureClass: "flow_renderer_crashed",
    failureScope: "global",
    healAction: "recover_flow_page",
    lastError: triggerError,
    flowRendererCrashDetectedAt: new Date().toISOString(),
    flowRendererCrashPhase: phase,
    flowRendererCrashErrorCode: crash.errorCode || ""
  }) || task;
  await recordFlowRendererCrashEvent("flow_renderer_crash.detected", blocked, tabId, "", {
    triggerError,
    phase,
    projectId: crash.projectId || blocked.projectId || "",
    url: crash.url || "",
    title: crash.title || "",
    textPreview: crash.textPreview || crash.text || "",
    errorCode: crash.errorCode || ""
  });
  await persistQueueState();
  return blocked;
}

function taskTriggersFlowRendererCrashRecovery(task = {}) {
  const text = flowRendererCrashTriggerText(task);
  return task?.failureClass === "flow_renderer_crashed" ||
    task?.healAction === "recover_flow_page" ||
    /flow_renderer_crashed|aw,\s*snap|something went wrong while displaying this webpage|error code:\s*[a-z0-9_-]+/i.test(text);
}

async function maybeMarkFlowRendererCrashFromCurrentTab(task = {}, tabId = 0, phase = "global_recovery") {
  if (!task?.id) return task;
  if (taskTriggersFlowRendererCrashRecovery(task)) return task;
  const text = diagnosticString([task.lastError, task.failureClass, task.healAction]);
  const shouldInspect = taskPrefersDom(task) ||
    /flow_connection|bridge|composer_not_ready|dom_frontend|debugger_transport|reconnect_flow/i.test(text);
  if (!shouldInspect) return task;
  const crash = await detectFlowRendererCrashForTask(task, tabId, phase);
  return crash?.crashed ? markFlowRendererCrashDetected(task, tabId, crash, phase) : task;
}

function isRecoverableGlobalTask(task = {}) {
  return [TaskStatus.pending, TaskStatus.blocked].includes(task?.status)
    && task?.failureScope === "global"
    && RECOVERABLE_GLOBAL_HEAL_ACTIONS.has(String(task?.healAction || ""));
}

function taskTriggersHardStop(task = {}) {
  if (!task?.id) return false;
  const text = diagnosticString([
    task.lastError,
    task.failureClass,
    task.flowErrorCode,
    task.healAction,
    task.statusText,
    task.error
  ]);
  const policy = classifyRecoveryPolicy({ ...task, message: text });
  return policy.recoveryPolicy === "hard_stop";
}

function recoveryReportPatch(task = {}, patch = {}) {
  const mergedTask = { ...task, ...patch };
  const tasks = ledger.listTasks().map((item) => item.id === task.id ? { ...item, ...mergedTask } : item);
  return buildRecoveryReportFields(mergedTask, { tasks });
}

function hasPendingQueueTaskAfter(taskId = "") {
  const currentId = compactString(taskId);
  return ledger.listTasks().some((task) => task.id !== currentId && task.status === TaskStatus.pending);
}

function isDomSettingsMenuFailureTask(task = {}) {
  const text = diagnosticString([
    task?.failureClass,
    task?.recoveryFinalOutcome,
    task?.lastError,
    task?.error,
    task?.statusText
  ]);
  return /dom_settings_menu_not_open|settings_menu_not_open/i.test(text);
}

function recoveryActionPatchFor(action = "") {
  const now = new Date().toISOString();
  const normalized = compactString(action);
  if (normalized === "close") return { recoveryUserClickedCloseAt: now };
  if (normalized === "pause") return { recoveryUserClickedPauseAt: now };
  if (normalized === "retryBrowserMode") return { recoveryUserClickedRetryAt: now };
  if (normalized === "skipContinue") return { recoveryUserClickedSkipAt: now };
  if (normalized === "backToEditor") return { recoveryUserClickedBackToEditorAt: now };
  return {};
}

async function recordRecoveryTaskAction(taskId = "", action = "", extra = {}) {
  const id = compactString(taskId);
  if (!id || !ledger.getTask(id)) return null;
  const recoveryModalKind = compactString(extra.recoveryModalKind || "");
  const patch = {
    ...recoveryActionPatchFor(action),
    recoveryModalShown: true,
    recoveryModalInteractive: true,
    recoveryActionAvailable: true
  };
  if (recoveryModalKind) patch.recoveryModalKind = recoveryModalKind;
  const updated = ledger.updateTask(id, patch);
  recordEvent({
    type: "queue.recovery_modal.action",
    taskId: id,
    action: compactString(action),
    failureClass: updated?.failureClass || "",
    failureScope: updated?.failureScope || "",
    recoveryFinalOutcome: updated?.recoveryFinalOutcome || ""
  });
  await persistQueueState();
  return updated;
}

async function skipBlockedQueueTask(taskId = "", options = {}) {
  const id = compactString(taskId);
  const task = id ? ledger.getTask(id) : null;
  if (!task) return { ok: false, error: "task_not_found", skipped: null };
  await recordRecoveryTaskAction(id, "skipContinue", { recoveryModalKind: options.recoveryModalKind || "" });
  const skipped = ledger.updateTask(id, {
    status: TaskStatus.failed,
    userSkippedAt: new Date().toISOString(),
    userSkippedReason: options.reason || "user_skipped_current_row",
    autoRetrySkipped: true,
    autoRetrySkippedAt: new Date().toISOString(),
    autoRetrySkipReason: options.reason || "user_skipped_current_row",
    failureScope: task.failureScope || "task",
    pendingRowsPreserved: true,
    recoveryFinalOutcome: task.recoveryFinalOutcome || "user_skipped_current_row"
  });
  recordEvent({
    type: "queue.task.skip_current",
    taskId: id,
    reason: options.reason || "user_skipped_current_row",
    failureClass: skipped?.failureClass || task.failureClass || "",
    failureScope: skipped?.failureScope || task.failureScope || "",
    pending: ledger.listTasks().filter((candidate) => candidate.status === TaskStatus.pending).length
  });
  await persistQueueState();
  return { ok: true, skipped };
}

async function skipFailedTaskForAutoRetry(task = {}, reason = "auto_retry_skip_failed") {
  if (task?.autoRetryFailedUntilZero !== true) return false;
  if (!["failed", "blocked"].includes(String(task?.status || ""))) return false;
  if (!hasPendingQueueTaskAfter(task.id)) return false;
  const skipped = ledger.updateTask(task.id, {
    status: TaskStatus.failed,
    autoRetrySkipped: true,
    autoRetrySkippedAt: new Date().toISOString(),
    autoRetrySkipReason: reason,
    previousFailureClass: task.failureClass || "",
    previousLastError: task.lastError || ""
  });
  recordEvent({
    type: "queue.auto_retry.skip_failed",
    taskId: task.id,
    reason,
    failureClass: task.failureClass || "",
    failureScope: task.failureScope || "",
    healAction: task.healAction || "",
    lastError: task.lastError || "",
    pending: ledger.listTasks().filter((candidate) => candidate.status === TaskStatus.pending).length
  });
  await persistQueueState();
  return Boolean(skipped);
}

function globalRecoveryDelayMs(task = {}) {
  const attempts = Math.max(1, Number(task?.globalRecoveryAttempts || task?.attempts || 1));
  const action = String(task?.healAction || "");
  const base = action === "reconnect_flow" ? 6000
    : action === "wait_for_capacity" ? 30000
      : action === "backoff" ? 30000
        : 45000;
  return Math.min(120000, base + ((attempts - 1) * 15000));
}

function flowSessionRecoveryTriggerText(task = {}) {
  return diagnosticString([
    task?.lastError,
    task?.failureClass,
    task?.healAction,
    task?.statusText,
    task?.error
  ]);
}

function extractFlowSessionStatus(text = "") {
  const raw = String(text || "");
  if (/\b429\b/.test(raw) || /resource_exhausted/i.test(raw)) return 429;
  if (/\b403\b/.test(raw) || /permission_denied|public_error_unusual_activity|recaptcha/i.test(raw)) return 403;
  return 0;
}

function extractFlowErrorCode(text = "") {
  const raw = String(text || "");
  const codes = raw.match(/PUBLIC_ERROR_[A-Z0-9_]+|PERMISSION_DENIED|RESOURCE_EXHAUSTED|COMPOSER_NOT_READY|DOM_SUBMIT_REJECTED_403/gi) || [];
  if (/recaptcha evaluation failed/i.test(raw)) codes.push("RECAPTCHA_EVALUATION_FAILED");
  return [...new Set(codes.map((code) => String(code || "").toUpperCase()))].join(" ");
}

function isFlowSessionRecoveryTriggerText(text = "") {
  const raw = String(text || "");
  if (isHardQuotaFailure(raw)) return false;
  if (/PUBLIC_ERROR_MODEL_ACCESS_DENIED|model_access_denied|model access denied/i.test(raw)) return false;
  return /PUBLIC_ERROR_UNUSUAL_ACTIVITY/i.test(raw) ||
    /recaptcha evaluation failed|reCAPTCHA/i.test(raw) ||
    (/PERMISSION_DENIED/i.test(raw) && /\b403\b/.test(raw)) ||
    (/RESOURCE_EXHAUSTED/i.test(raw) && /\b429\b/.test(raw)) ||
    /\b429\b/.test(raw);
}

function taskTriggersFlowSessionRecovery(task = {}) {
  const text = flowSessionRecoveryTriggerText(task);
  if (isHardQuotaFailure(text) || task?.failureClass === "flow_model_daily_quota_reached") return false;
  if (task?.failureClass === "flow_model_access_denied" || task?.failureClass === "api_first_model_access_denied") return false;
  if (task?.failureClass === "flow_session_heat" || task?.healAction === "recover_flow_session") return true;
  if (isFlowSessionRecoveryTriggerText(text)) return true;
  const recentSessionRejection = flowSessionRecoveryState.recentSessionRejectionAt > 0
    && Date.now() - flowSessionRecoveryState.recentSessionRejectionAt <= FLOW_SESSION_RECOVERY_RECENT_MS;
  return recentSessionRejection && /COMPOSER_NOT_READY/i.test(text);
}

function resetFlowSessionRecoveryForRun(runToken) {
  flowSessionRecoveryState.runToken = runToken;
  flowSessionRecoveryState.attempts = 0;
  flowSessionRecoveryState.active = false;
  flowSessionRecoveryState.lastTriggerError = "";
  flowSessionRecoveryState.lastFlowErrorCode = "";
  flowSessionRecoveryState.lastStatus = 0;
  flowSessionRecoveryState.lastTaskId = "";
  flowSessionRecoveryState.lastStartedAt = 0;
  flowSessionRecoveryState.recentSessionRejectionAt = 0;
}

function resetFlowRendererCrashRecoveryForRun(runToken) {
  flowRendererCrashRecoveryState.runToken = runToken;
  flowRendererCrashRecoveryState.attempts = 0;
  flowRendererCrashRecoveryState.active = false;
  flowRendererCrashRecoveryState.lastTriggerError = "";
  flowRendererCrashRecoveryState.lastTaskId = "";
  flowRendererCrashRecoveryState.lastStartedAt = 0;
}

function summarizeBuildFingerprint(result = {}) {
  if (!result?.ok) return { ok: false, error: result?.error || "", status: Number(result?.status || 0) };
  const fingerprint = result.fingerprint || {};
  return {
    version: fingerprint.version || fingerprint.versionName || "",
    shortCommit: fingerprint.shortCommit || "",
    commit: fingerprint.commit || "",
    sourceRoot: fingerprint.sourceRoot || "",
    dirty: fingerprint.dirty === true
  };
}

async function flowSessionRecoveryEventFields(task = {}, tabId = 0, recoveryLevel = "", detail = {}) {
  const { bridge, buildFingerprintResult, ...eventDetail } = detail || {};
  const triggerError = compactString(eventDetail.triggerError || flowSessionRecoveryTriggerText(task));
  const buildResult = buildFingerprintResult || await readBuildFingerprint().catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "build_fingerprint_read_failed")
  }));
  const tab = Number(tabId || 0) ? await chrome.tabs.get(Number(tabId)).catch(() => null) : null;
  const bridgeHealth = bridge || (Number(tabId || 0)
    ? await probeFlowBridge(Number(tabId)).catch((error) => ({ ok: false, error: compactString(error?.message || error || "bridge_probe_failed") }))
    : {});
  return {
    triggerError,
    status: Number(eventDetail.status || extractFlowSessionStatus(triggerError) || 0),
    flowErrorCode: compactString(eventDetail.flowErrorCode || extractFlowErrorCode(triggerError)),
    taskId: task?.id || "",
    mode: task?.mode || "",
    submitPath: task?.submitPath || task?.submitPathPreference || "",
    attempt: Number(task?.attempts || 0),
    recoveryLevel,
    projectId: compactString(eventDetail.projectId || bridgeHealth?.projectId || task?.projectId || runtimeState.projectId || projectIdFromUrl(tab?.url || "")),
    tabId: Number(tabId || 0) || null,
    buildFingerprint: summarizeBuildFingerprint(buildResult),
    bridgeVersion: bridgeHealth?.bridgeVersion || "",
    pageHookVersion: bridgeHealth?.pageHookVersion || "",
    cacheCleared: eventDetail.cacheCleared === true,
    ignoreCacheReload: eventDetail.ignoreCacheReload === true,
    serviceWorkerBypassed: eventDetail.serviceWorkerBypassed === true,
    ...eventDetail
  };
}

async function recordFlowSessionRecoveryEvent(type, task = {}, tabId = 0, recoveryLevel = "", detail = {}) {
  const fields = await flowSessionRecoveryEventFields(task, tabId, recoveryLevel, detail);
  recordEvent({ type, ...fields });
}

function flowSessionRecoveryLevelForAttempt(attempt = 1) {
  return FLOW_SESSION_RECOVERY_LEVELS[Math.max(0, Math.min(FLOW_SESSION_RECOVERY_LEVELS.length - 1, Number(attempt || 1) - 1))];
}

async function withFlowSessionRecoveryDebugger(tabId, task = {}, recoveryLevel = "", callback = async () => {}) {
  if (!chrome.debugger?.attach) return { ok: false, error: "chrome_debugger_unavailable" };
  await releaseDebuggerSessions("flow_session_recovery", recordDebuggerTrace).catch(() => null);
  const target = debuggerTarget(tabId);
  let attached = false;
  try {
    await chrome.debugger.attach(target, "1.3");
    attached = true;
    await debuggerSend(target, "Page.enable").catch(() => {});
    await debuggerSend(target, "Network.enable").catch(() => {});
    return await callback(target);
  } catch (error) {
    return {
      ok: false,
      error: compactString(error?.message || error || "flow_session_recovery_debugger_failed"),
      recoveryLevel
    };
  } finally {
    if (attached) {
      await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: false }).catch(() => {});
      await debuggerSend(target, "Network.setBypassServiceWorker", { bypass: false }).catch(() => {});
      await chrome.debugger.detach(target).catch(() => {});
    }
  }
}

async function performFlowSessionRecoveryLevel(task = {}, tabId = 0, recoveryLevel = "") {
  const projectId = compactString(task?.projectId || runtimeState.projectId || "");
  const cacheCleared = recoveryLevel === "cache_clear_reload";
  const serviceWorkerBypassed = recoveryLevel === "service_worker_bypass_reload";
  const result = await withFlowSessionRecoveryDebugger(tabId, task, recoveryLevel, async (target) => {
    if (cacheCleared) {
      await debuggerSend(target, "Network.clearBrowserCache");
      await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: true });
      await recordFlowSessionRecoveryEvent("flow_session_recovery.cache_clear", task, tabId, recoveryLevel, {
        cacheCleared: true,
        ignoreCacheReload: true,
        serviceWorkerBypassed: false
      });
    }
    if (serviceWorkerBypassed) {
      await debuggerSend(target, "Network.setBypassServiceWorker", { bypass: true });
      await recordFlowSessionRecoveryEvent("flow_session_recovery.service_worker_bypass", task, tabId, recoveryLevel, {
        cacheCleared: false,
        ignoreCacheReload: true,
        serviceWorkerBypassed: true
      });
    }
    await recordFlowSessionRecoveryEvent("flow_session_recovery.reload", task, tabId, recoveryLevel, {
      cacheCleared,
      ignoreCacheReload: true,
      serviceWorkerBypassed
    });
    await debuggerSend(target, "Page.reload", { ignoreCache: true });
    await sleep(700);
    const waitResult = projectId ? await waitForFlowProjectRoot(tabId, projectId) : { ok: true, tabId };
    if (cacheCleared) await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: false }).catch(() => {});
    if (serviceWorkerBypassed) await debuggerSend(target, "Network.setBypassServiceWorker", { bypass: false }).catch(() => {});
    return waitResult?.ok === false ? waitResult : { ok: true, tabId, waitResult };
  });
  if (!result?.ok) return result;
  const bridge = await ensureFlowBridge(tabId).catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "flow_bridge_not_ready")
  }));
  await recordFlowSessionRecoveryEvent("flow_session_recovery.bridge_revalidated", task, tabId, recoveryLevel, {
    bridge,
    projectId: bridge?.projectId || projectId,
    cacheCleared,
    ignoreCacheReload: true,
    serviceWorkerBypassed
  });
  if (!isFreshFlowBridge(bridge)) {
    return { ok: false, error: bridge?.error || "flow_bridge_revalidation_failed", bridge };
  }
  return { ok: true, bridge, projectId: bridge?.projectId || projectId };
}

async function pauseFlowSessionRecoveryUnresolved(task = {}, tabId = 0, recoveryLevel = "", reason = "flow_session_heat_unresolved") {
  const reportFields = recoveryReportPatch(task, {
    status: TaskStatus.blocked,
    failureClass: "flow_session_heat_unresolved",
    failureScope: "global",
    healAction: "user_action_required",
    lastError: task.lastError || reason,
    recoveryPolicy: "safe_recovery_ladder",
    recoveryAttempted: true,
    recoverySkippedBecauseHardQuota: false,
    recoveryFinalOutcome: "repair_failed"
  });
  const blocked = ledger.updateTask(task.id, {
    status: TaskStatus.blocked,
    failureClass: "flow_session_heat_unresolved",
    failureScope: "global",
    healAction: "user_action_required",
    lastError: task.lastError || reason,
    ...reportFields,
    recoveryFinalOutcome: "repair_failed",
    flowSessionRecoveryPausedAt: new Date().toISOString(),
    flowSessionRecoveryPauseReason: reason
  });
  await recordFlowSessionRecoveryEvent("flow_session_recovery.pause_unresolved", blocked || task, tabId, recoveryLevel, {
    triggerError: task.lastError || reason,
    status: extractFlowSessionStatus(task.lastError || reason),
    flowErrorCode: extractFlowErrorCode(task.lastError || reason),
    cacheCleared: recoveryLevel === "cache_clear_reload",
    ignoreCacheReload: recoveryLevel !== "",
    serviceWorkerBypassed: recoveryLevel === "service_worker_bypass_reload",
    userMessage: "Flow session is rejecting generation. Cool down, sign in again, or manually refresh Flow before resuming."
  });
  await persistQueueState();
  return { ok: false, blocked };
}

async function pauseHardStopQueueFailure(task = {}, tabId = 0, reason = "") {
  const triggerError = flowSessionRecoveryTriggerText(task) || reason || task.lastError || task.failureClass || "hard_stop";
  const policy = classifyRecoveryPolicy({ ...task, message: triggerError });
  const hardQuotaPatch = policy.recoverySkippedBecauseHardQuota === true
    ? { recoverySkippedBecauseHardQuota: true, recoveryFinalOutcome: "blocked_hard_quota" }
    : { recoverySkippedBecauseHardQuota: false, recoveryFinalOutcome: policy.recoveryFinalOutcome };
  const reportFields = recoveryReportPatch(task, {
    status: TaskStatus.blocked,
    failureClass: policy.failureClass,
    failureScope: policy.scope || "global",
    healAction: policy.healAction || "user_action_required",
    lastError: task.lastError || triggerError,
    flowErrorCode: policy.flowErrorCode || extractFlowErrorCode(triggerError),
    recoveryPolicy: policy.recoveryPolicy,
    recoveryAttempted: false,
    ...hardQuotaPatch,
    recoveryStepsAttempted: [],
    recommendedNextAction: policy.recommendedNextAction,
    sideEffectRetryBlocked: policy.sideEffectRetryBlocked === true
  });
  const blocked = ledger.updateTask(task.id, {
    status: TaskStatus.blocked,
    failureClass: policy.failureClass,
    failureScope: policy.scope || "global",
    healAction: policy.healAction || "user_action_required",
    lastError: task.lastError || triggerError,
    flowErrorCode: policy.flowErrorCode || extractFlowErrorCode(triggerError),
    ...reportFields,
    ...hardQuotaPatch,
    hardStopPausedAt: new Date().toISOString()
  });
  recordEvent({
    type: "queue.hard_stop.blocked",
    taskId: task.id || "",
    tabId: Number(tabId || 0) || null,
    failureClass: blocked?.failureClass || policy.failureClass,
    flowErrorCode: blocked?.flowErrorCode || policy.flowErrorCode || "",
    recoveryPolicy: blocked?.recoveryPolicy || policy.recoveryPolicy,
    recoveryAttempted: false,
    recoverySkippedBecauseHardQuota: blocked?.recoverySkippedBecauseHardQuota === true,
    recoveryFinalOutcome: blocked?.recoveryFinalOutcome || policy.recoveryFinalOutcome,
    recommendedNextAction: blocked?.recommendedNextAction || policy.recommendedNextAction,
    completedTaskCountBeforeStop: Number(blocked?.completedTaskCountBeforeStop || 0),
    downloadedCountBeforeStop: Number(blocked?.downloadedCountBeforeStop || 0),
    pendingTaskCountAfterStop: Number(blocked?.pendingTaskCountAfterStop || 0)
  });
  await persistQueueState();
  return { ok: false, blocked };
}

async function recoverFlowSessionGlobalFailure(task = {}, tabId = 0) {
  const triggerError = flowSessionRecoveryTriggerText(task) || "flow_session_heat";
  const priorAttempts = Math.max(
    Number(flowSessionRecoveryState.attempts || 0),
    Number(task.flowSessionRecoveryAttempts || 0)
  );
  const recoveryAttempts = priorAttempts + 1;
  const recoveryLevel = flowSessionRecoveryLevelForAttempt(recoveryAttempts);
  flowSessionRecoveryState.active = true;
  flowSessionRecoveryState.attempts = recoveryAttempts;
  flowSessionRecoveryState.lastTriggerError = triggerError;
  flowSessionRecoveryState.lastFlowErrorCode = extractFlowErrorCode(triggerError);
  flowSessionRecoveryState.lastStatus = extractFlowSessionStatus(triggerError);
  flowSessionRecoveryState.lastTaskId = task.id || "";
  flowSessionRecoveryState.lastStartedAt = Date.now();
  flowSessionRecoveryState.recentSessionRejectionAt = Date.now();
  const repairingPatch = recoveryReportPatch(task, {
    recoveryPolicy: "safe_recovery_ladder",
    recoveryAttempted: true,
    recoverySkippedBecauseHardQuota: false,
    recoveryStepsAttempted: FLOW_SESSION_RECOVERY_LEVELS,
    recoveryCurrentStep: recoveryLevel,
    recoveryAttemptCount: recoveryAttempts,
    recoveryFinalOutcome: "repairing"
  });
  ledger.updateTask(task.id, {
    ...repairingPatch,
    recoveryPolicy: "safe_recovery_ladder",
    recoveryAttempted: true,
    recoverySkippedBecauseHardQuota: false,
    recoveryStepsAttempted: FLOW_SESSION_RECOVERY_LEVELS,
    recoveryCurrentStep: recoveryLevel,
    recoveryAttemptCount: recoveryAttempts,
    recoveryFinalOutcome: "repairing"
  });

  if (recoveryAttempts > MAX_FLOW_SESSION_RECOVERY_ATTEMPTS) {
    return pauseFlowSessionRecoveryUnresolved(task, tabId, recoveryLevel, "flow_session_recovery_exhausted");
  }

  await recordFlowSessionRecoveryEvent("flow_session_recovery.start", task, tabId, recoveryLevel, {
    triggerError,
    status: flowSessionRecoveryState.lastStatus,
    flowErrorCode: flowSessionRecoveryState.lastFlowErrorCode,
    cacheCleared: false,
    ignoreCacheReload: true,
    serviceWorkerBypassed: false
  });

  const result = await performFlowSessionRecoveryLevel(task, tabId, recoveryLevel);
  if (!result?.ok) {
    return pauseFlowSessionRecoveryUnresolved(task, tabId, recoveryLevel, result?.error || "flow_session_recovery_failed");
  }

  const recovered = ledger.updateTask(task.id, {
    status: TaskStatus.pending,
    flowSessionRecoveryAttempts: recoveryAttempts,
    flowSessionRecoveryLevel: recoveryLevel,
    flowSessionRecoveryRetriedAt: new Date().toISOString(),
    nextRetryAt: new Date().toISOString(),
    lastHealReloadOk: true,
    recoveryPolicy: "safe_recovery_ladder",
    recoveryAttempted: true,
    recoverySkippedBecauseHardQuota: false,
    recoveryStepsAttempted: FLOW_SESSION_RECOVERY_LEVELS,
    recoveryCurrentStep: recoveryLevel,
    recoveryAttemptCount: recoveryAttempts,
    recoveryFinalOutcome: "retry_same_task"
  }) || task;
  await recordFlowSessionRecoveryEvent("flow_session_recovery.retry_same_task", recovered, tabId, recoveryLevel, {
    bridge: result.bridge,
    projectId: result.projectId || recovered.projectId || "",
    triggerError,
    status: flowSessionRecoveryState.lastStatus,
    flowErrorCode: flowSessionRecoveryState.lastFlowErrorCode,
    cacheCleared: recoveryLevel === "cache_clear_reload",
    ignoreCacheReload: true,
    serviceWorkerBypassed: recoveryLevel === "service_worker_bypass_reload"
  });
  await persistQueueState();
  return { ok: true, task: recovered };
}

async function markFlowSessionRecoverySuccessIfNeeded(task = {}, tabId = 0) {
  if (!flowSessionRecoveryState.active || !task?.id) return;
  if (task.id !== flowSessionRecoveryState.lastTaskId) return;
  if (![TaskStatus.generating, TaskStatus.complete, TaskStatus.downloading].includes(task.status)) return;
  const recoveryLevel = flowSessionRecoveryLevelForAttempt(flowSessionRecoveryState.attempts);
  await recordFlowSessionRecoveryEvent("flow_session_recovery.success", task, tabId, recoveryLevel, {
    triggerError: flowSessionRecoveryState.lastTriggerError,
    status: flowSessionRecoveryState.lastStatus,
    flowErrorCode: flowSessionRecoveryState.lastFlowErrorCode,
    cacheCleared: recoveryLevel === "cache_clear_reload",
    ignoreCacheReload: true,
    serviceWorkerBypassed: recoveryLevel === "service_worker_bypass_reload"
  });
  ledger.updateTask(task.id, {
    recoveryPolicy: "safe_recovery_ladder",
    recoveryAttempted: true,
    recoverySkippedBecauseHardQuota: false,
    recoveryStepsAttempted: FLOW_SESSION_RECOVERY_LEVELS,
    recoveryCurrentStep: recoveryLevel,
    recoveryFinalOutcome: "recovered"
  });
  flowSessionRecoveryState.attempts = 0;
  flowSessionRecoveryState.active = false;
  flowSessionRecoveryState.lastTriggerError = "";
  flowSessionRecoveryState.lastFlowErrorCode = "";
  flowSessionRecoveryState.lastStatus = 0;
  flowSessionRecoveryState.lastTaskId = "";
  flowSessionRecoveryState.lastStartedAt = 0;
  flowSessionRecoveryState.recentSessionRejectionAt = 0;
}

function flowRendererCrashRecoveryLevelForAttempt(attempt = 1) {
  return FLOW_RENDERER_CRASH_RECOVERY_LEVELS[Math.max(0, Math.min(FLOW_RENDERER_CRASH_RECOVERY_LEVELS.length - 1, Number(attempt || 1) - 1))];
}

async function debuggerFlowDocumentState(target, tabId = 0) {
  const frameTree = await debuggerSend(target, "Page.getFrameTree").catch((error) => ({
    error: compactString(error?.message || error || "frame_tree_failed")
  }));
  const frame = frameTree?.frameTree?.frame || {};
  const evaluated = await debuggerSend(target, "Runtime.evaluate", {
    expression: `(() => {
      const text = String(document.body?.innerText || document.body?.textContent || "").replace(/\\s+/g, " ").trim();
      return {
        url: location.href,
        title: document.title || "",
        documentReadyState: document.readyState || "",
        textPreview: text.slice(0, 600),
        projectId: String(location.href || "").match(/\\/project\\/([0-9a-f-]{36})/i)?.[1] || "",
        bridgeVersion: window.__afRebuildContentBridgeVersion || "",
        pageHookVersion: window.__afRebuildPageHookVersion || "",
        pageHookInstalled: window.__afRebuildPageHookInstalled === true
      };
    })()`,
    returnByValue: true,
    awaitPromise: false
  }).catch((error) => ({
    error: compactString(error?.message || error || "document_state_failed")
  }));
  const value = evaluated?.result?.value || {};
  const snapshot = {
    ok: Boolean(!evaluated?.error),
    error: evaluated?.error || "",
    tabId: Number(tabId || 0) || null,
    frameId: frame?.id || "",
    frameUrl: frame?.url || "",
    url: value.url || frame?.url || "",
    title: value.title || "",
    documentReadyState: value.documentReadyState || "",
    textPreview: compactDiagnosticPreview(value.textPreview || ""),
    projectId: value.projectId || projectIdFromUrl(value.url || frame?.url || ""),
    bridgeVersion: value.bridgeVersion || "",
    pageHookVersion: value.pageHookVersion || "",
    pageHookInstalled: value.pageHookInstalled === true
  };
  const crash = detectFlowRendererCrashSnapshot({
    url: snapshot.url,
    title: snapshot.title,
    text: snapshot.textPreview,
    error: snapshot.error
  });
  return {
    ...snapshot,
    crashPageStillVisible: crash.crashed === true,
    errorCode: crash.errorCode || ""
  };
}

async function waitForRecoveredFlowDocumentReady(target, tabId = 0, expectedProjectId = "", beforeState = {}) {
  const deadline = Date.now() + 18000;
  let last = null;
  while (Date.now() < deadline) {
    last = await debuggerFlowDocumentState(target, tabId);
    const ready = /^(interactive|complete)$/i.test(String(last.documentReadyState || ""));
    const projectMatches = !expectedProjectId || last.projectId === expectedProjectId || projectIdFromUrl(last.url || "") === expectedProjectId;
    if (ready && projectMatches && last.crashPageStillVisible !== true) {
      return {
        ok: true,
        ...last,
        documentChangedOrRevalidated: Boolean(
          (beforeState.frameId && last.frameId && beforeState.frameId !== last.frameId) ||
          (beforeState.url && last.url && beforeState.url !== last.url) ||
          (ready && projectMatches)
        )
      };
    }
    await sleep(300);
  }
  return {
    ok: false,
    ...(last || {}),
    error: last?.crashPageStillVisible
      ? "flow_renderer_crash_page_still_visible"
      : "flow_recovered_document_not_ready"
  };
}

async function resetFlowRendererCrashSubmitState(task = {}, tabId = 0, recoveryLevel = "") {
  const response = await sendPageCommand({
    action: "domResetDebuggerSubmitCaptures",
    task: { id: task.id || "" },
    meta: { reason: "flow_renderer_crash_recovery" },
    timeoutMs: 10000
  }, tabId).catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "dom_submit_capture_reset_failed")
  }));
  const result = response?.result?.result || response?.result || response;
  return {
    ok: result?.ok !== false,
    error: result?.error || "",
    cleared: Number(result?.cleared || 0),
    recoveryLevel
  };
}

async function waitForPostCrashComposerSettle(task = {}, tabId = 0) {
  const deadline = Date.now() + 16000;
  let last = null;
  const settleTask = {
    id: task.id || "",
    mode: task.mode || "text-to-image",
    prompt: ""
  };
  while (Date.now() < deadline) {
    last = await sendPageCommand({
      action: "composerReadyState",
      task: settleTask,
      options: {
        allowDisabledCreate: true,
        allowMissingCreate: true,
        allowCreateUnavailableBeforePrompt: true
      },
      timeoutMs: 8000
    }, tabId).catch((error) => ({
      ok: false,
      error: compactString(error?.message || error || "composer_ready_state_failed"),
      snapshot: null
    }));
    const snapshot = last?.snapshot || last?.result?.snapshot || null;
    const problems = Array.isArray(snapshot?.problems) ? snapshot.problems : [];
    const stillLoading = problems.includes("flow_loading") ||
      snapshot?.flowLoading === true ||
      snapshot?.skeletonLoading?.visible === true ||
      snapshot?.flowPageIssue?.blocked === true;
    if (last?.ok === true && !stillLoading) {
      return { ok: true, snapshot };
    }
    await sleep(350);
  }
  return {
    ok: false,
    error: last?.error || "post_crash_composer_settle_timeout",
    snapshot: last?.snapshot || last?.result?.snapshot || null
  };
}

async function performFlowRendererCrashRecoveryLevel(task = {}, tabId = 0, recoveryLevel = "") {
  const tabBefore = await chrome.tabs.get(tabId).catch(() => null);
  const projectId = compactString(task?.projectId || runtimeState.projectId || projectIdFromUrl(tabBefore?.url || ""));
  const cacheCleared = recoveryLevel === "cache_clear_reload";
  const bridgeBefore = await probeFlowBridge(tabId).catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "bridge_probe_failed")
  }));
  let reloadResult = { ok: false, error: "reload_not_attempted" };
  let documentBefore = null;
  let documentAfter = null;
  let debuggerAttachedFresh = false;
  let networkEnabledFresh = false;
  if (chrome.debugger?.attach) {
    await releaseDebuggerSessions("flow_renderer_crash_recovery_pre_reload", recordDebuggerTrace).catch(() => null);
    const target = debuggerTarget(tabId);
    let attached = false;
    try {
      await chrome.debugger.detach(target).catch(() => {});
      await chrome.debugger.attach(target, "1.3");
      attached = true;
      await debuggerSend(target, "Page.enable").catch(() => {});
      await debuggerSend(target, "Runtime.enable").catch(() => {});
      await debuggerSend(target, "Network.enable").catch(() => {});
      documentBefore = await debuggerFlowDocumentState(target, tabId).catch((error) => ({
        ok: false,
        error: compactString(error?.message || error || "document_before_failed")
      }));
      if (cacheCleared) {
        await debuggerSend(target, "Network.clearBrowserCache");
        await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: true });
      }
      await recordFlowRendererCrashEvent("flow_renderer_crash.reload", task, tabId, recoveryLevel, {
        bridgeBefore,
        documentBefore,
        cacheCleared,
        ignoreCacheReload: true
      });
      await debuggerSend(target, "Page.reload", { ignoreCache: true });
      await sleep(700);
      if (cacheCleared) await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: false }).catch(() => {});
      if (attached) {
        await chrome.debugger.detach(target).catch(() => {});
        attached = false;
      }
      reloadResult = projectId ? await waitForFlowProjectRoot(tabId, projectId) : { ok: true, tabId };
      if (reloadResult?.ok) {
        await chrome.debugger.attach(target, "1.3");
        attached = true;
        debuggerAttachedFresh = true;
        await debuggerSend(target, "Page.enable").catch(() => {});
        await debuggerSend(target, "Runtime.enable").catch(() => {});
        await debuggerSend(target, "Network.enable");
        networkEnabledFresh = true;
        documentAfter = await waitForRecoveredFlowDocumentReady(target, tabId, projectId, documentBefore || {});
        if (!documentAfter?.ok) {
          reloadResult = documentAfter;
        }
      }
    } catch (error) {
      reloadResult = {
        ok: false,
        error: compactString(error?.message || error || "flow_renderer_crash_reload_failed")
      };
    } finally {
      if (attached) {
        await debuggerSend(target, "Network.setCacheDisabled", { cacheDisabled: false }).catch(() => {});
        await chrome.debugger.detach(target).catch(() => {});
      }
    }
  } else if (!cacheCleared && chrome.tabs?.reload) {
    await recordFlowRendererCrashEvent("flow_renderer_crash.reload", task, tabId, recoveryLevel, {
      bridgeBefore,
      cacheCleared: false,
      ignoreCacheReload: true
    });
    await chrome.tabs.reload(tabId);
    await sleep(700);
    reloadResult = projectId ? await waitForFlowProjectRoot(tabId, projectId) : { ok: true, tabId };
  }
  if (!reloadResult?.ok) return reloadResult;
  const bridgeAfter = await ensureFlowBridge(tabId).catch((error) => ({
    ok: false,
    error: compactString(error?.message || error || "flow_bridge_not_ready")
  }));
  const submitStateReset = isFreshFlowBridge(bridgeAfter)
    ? await resetFlowRendererCrashSubmitState(task, tabId, recoveryLevel)
    : { ok: false, error: "bridge_not_fresh", cleared: 0 };
  const composerSettle = isFreshFlowBridge(bridgeAfter)
    ? await waitForPostCrashComposerSettle(task, tabId)
    : { ok: false, error: "bridge_not_fresh", snapshot: null };
  const expectedProjectMatches = !projectId ||
    bridgeAfter?.projectId === projectId ||
    documentAfter?.projectId === projectId ||
    projectIdFromUrl(documentAfter?.url || "") === projectId;
  await recordFlowRendererCrashEvent("flow_renderer_crash.bridge_revalidated", task, tabId, recoveryLevel, {
    bridgeBefore,
    bridgeAfter,
    documentBefore,
    documentAfter,
    projectId: bridgeAfter?.projectId || documentAfter?.projectId || projectId,
    cacheCleared,
    ignoreCacheReload: true
  });
  if (!isFreshFlowBridge(bridgeAfter)) {
    return { ok: false, error: bridgeAfter?.error || "flow_bridge_revalidation_failed", bridgeAfter };
  }
  await recordFlowRendererCrashEvent("flow_renderer_crash.post_recovery_ready", task, tabId, recoveryLevel, {
    bridgeBefore,
    bridgeAfter,
    documentBefore,
    documentAfter,
    projectId: bridgeAfter?.projectId || documentAfter?.projectId || projectId,
    url: documentAfter?.url || "",
    title: documentAfter?.title || "",
    documentReadyState: documentAfter?.documentReadyState || "",
    debuggerAttachedFresh,
    networkEnabledFresh,
    pageHookFresh: isFreshFlowBridge(bridgeAfter),
    crashPageStillVisible: documentAfter?.crashPageStillVisible === true,
    documentChangedOrRevalidated: documentAfter?.documentChangedOrRevalidated === true,
    submitCaptureStateCleared: submitStateReset?.ok === true,
    submitCaptureStateClearedCount: Number(submitStateReset?.cleared || 0),
    composerSettled: composerSettle?.ok === true,
    composerProblems: composerSettle?.snapshot?.problems || [],
    cacheCleared,
    ignoreCacheReload: true
  });
  if (!expectedProjectMatches) {
    return { ok: false, error: "flow_renderer_crash_project_changed", bridgeAfter, documentAfter };
  }
  if (documentAfter?.crashPageStillVisible === true) {
    return { ok: false, error: "flow_renderer_crash_page_still_visible", bridgeAfter, documentAfter };
  }
  if (submitStateReset?.ok === false) {
    return { ok: false, error: submitStateReset.error || "dom_submit_capture_reset_failed", bridgeAfter, documentAfter, submitStateReset };
  }
  if (composerSettle?.ok === false) {
    return { ok: false, error: composerSettle.error || "post_crash_composer_settle_failed", bridgeAfter, documentAfter, composerSettle };
  }
  return {
    ok: true,
    bridgeBefore,
    bridgeAfter,
    documentBefore,
    documentAfter,
    submitStateReset,
    composerSettle,
    projectId: bridgeAfter?.projectId || documentAfter?.projectId || projectId
  };
}

async function pauseFlowRendererCrashUnresolved(task = {}, tabId = 0, recoveryLevel = "", reason = "flow_renderer_crashed_unresolved") {
  const message = "Flow page crashed. Reload Flow or restart Chrome, then resume.";
  const blocked = ledger.updateTask(task.id, {
    status: TaskStatus.blocked,
    failureClass: "flow_renderer_crashed_unresolved",
    failureScope: "global",
    healAction: "user_action_required",
    lastError: message,
    flowRendererCrashPausedAt: new Date().toISOString(),
    flowRendererCrashPauseReason: reason
  });
  await recordFlowRendererCrashEvent("flow_renderer_crash.pause_unresolved", blocked || task, tabId, recoveryLevel, {
    triggerError: task.lastError || reason,
    errorCode: task.flowRendererCrashErrorCode || flowRendererCrashErrorCode(task.lastError || reason),
    cacheCleared: recoveryLevel === "cache_clear_reload",
    ignoreCacheReload: recoveryLevel !== "",
    userMessage: message
  });
  await persistQueueState();
  return { ok: false, blocked };
}

async function recoverFlowRendererCrashGlobalFailure(task = {}, tabId = 0) {
  const triggerError = flowRendererCrashTriggerText(task) || "flow_renderer_crashed";
  const priorAttempts = Math.max(
    Number(flowRendererCrashRecoveryState.attempts || 0),
    Number(task.flowRendererCrashRecoveryAttempts || 0)
  );
  const recoveryAttempts = priorAttempts + 1;
  const recoveryLevel = flowRendererCrashRecoveryLevelForAttempt(recoveryAttempts);
  flowRendererCrashRecoveryState.active = true;
  flowRendererCrashRecoveryState.attempts = recoveryAttempts;
  flowRendererCrashRecoveryState.lastTriggerError = triggerError;
  flowRendererCrashRecoveryState.lastTaskId = task.id || "";
  flowRendererCrashRecoveryState.lastStartedAt = Date.now();

  if (recoveryAttempts > MAX_FLOW_RENDERER_CRASH_RECOVERY_ATTEMPTS) {
    return pauseFlowRendererCrashUnresolved(task, tabId, recoveryLevel, "flow_renderer_crash_recovery_exhausted");
  }

  await recordFlowRendererCrashEvent("flow_renderer_crash.detected", task, tabId, recoveryLevel, {
    triggerError,
    textPreview: task.lastError || triggerError,
    errorCode: task.flowRendererCrashErrorCode || flowRendererCrashErrorCode(triggerError)
  });

  const result = await performFlowRendererCrashRecoveryLevel(task, tabId, recoveryLevel);
  if (!result?.ok) {
    return pauseFlowRendererCrashUnresolved(task, tabId, recoveryLevel, result?.error || "flow_renderer_crash_recovery_failed");
  }

  const recovered = ledger.updateTask(task.id, {
    status: TaskStatus.pending,
    flowRendererCrashRecoveryAttempts: recoveryAttempts,
    flowRendererCrashRecoveryLevel: recoveryLevel,
    flowRendererCrashRetriedAt: new Date().toISOString(),
    nextRetryAt: new Date().toISOString(),
    lastHealReloadOk: true
  }) || task;
  await recordFlowRendererCrashEvent("flow_renderer_crash.retry_same_task", recovered, tabId, recoveryLevel, {
    bridgeBefore: result.bridgeBefore,
    bridgeAfter: result.bridgeAfter,
    projectId: result.projectId || recovered.projectId || "",
    triggerError,
    cacheCleared: recoveryLevel === "cache_clear_reload",
    ignoreCacheReload: true
  });
  await persistQueueState();
  return { ok: true, task: recovered };
}

async function recoverGlobalQueueFailure(task = {}, tabId = 0) {
  const effectiveTask = await maybeMarkFlowRendererCrashFromCurrentTab(task, tabId, "global_recovery");
  if (taskTriggersHardStop(effectiveTask)) {
    return pauseHardStopQueueFailure(effectiveTask, tabId, "hard_stop_user_action_required");
  }
  // Side-effect guard: every branch below can end in retry_same_task, which
  // re-queues the task as plain pending and re-submits it. If a prior attempt
  // already produced outputs (partial DOM T2V x4 + session heat field bug),
  // block the resubmit and route to reconcile instead of burning duplicates.
  if (taskHasObservedOutputs(effectiveTask)) {
    const triggerError = flowSessionRecoveryTriggerText(effectiveTask) || effectiveTask.lastError || "side_effect_resubmit_blocked";
    const policy = applySideEffectOverride(classifyRecoveryPolicy({ ...effectiveTask, message: triggerError }), effectiveTask);
    if (policy.sideEffectRetryBlocked === true) {
      const reportFields = recoveryReportPatch(effectiveTask, {
        status: TaskStatus.blocked,
        failureClass: policy.failureClass,
        failureScope: policy.scope || "task",
        healAction: policy.healAction,
        lastError: effectiveTask.lastError || triggerError,
        flowErrorCode: policy.flowErrorCode || extractFlowErrorCode(triggerError),
        recoveryPolicy: policy.recoveryPolicy,
        recoveryAttempted: false,
        recoveryStepsAttempted: [],
        recoveryFinalOutcome: policy.recoveryFinalOutcome,
        recommendedNextAction: policy.recommendedNextAction,
        sideEffectRetryBlocked: true
      });
      const blocked = ledger.updateTask(effectiveTask.id, {
        status: TaskStatus.blocked,
        failureClass: policy.failureClass,
        failureScope: policy.scope || "task",
        healAction: policy.healAction,
        lastError: effectiveTask.lastError || triggerError,
        flowErrorCode: policy.flowErrorCode || extractFlowErrorCode(triggerError),
        ...reportFields,
        overriddenFromFailureClass: policy.overriddenFromFailureClass || "",
        sideEffectRetryBlocked: true,
        mediaIdResubmitBlocked: true,
        sideEffectResubmitBlockedAt: new Date().toISOString()
      });
      recordEvent({
        type: "queue.side_effect_resubmit_blocked",
        taskId: effectiveTask.id || "",
        tabId: Number(tabId || 0) || null,
        failureClass: policy.failureClass,
        overriddenFromFailureClass: policy.overriddenFromFailureClass || "",
        observedMediaIds: [
          ...(Array.isArray(effectiveTask.mediaIds) ? effectiveTask.mediaIds : []),
          ...(Array.isArray(effectiveTask.outputMediaIds) ? effectiveTask.outputMediaIds : [])
        ].map((id) => String(id || "").trim()).filter(Boolean).slice(0, 8),
        statusRowCount: Array.isArray(effectiveTask.statusRows) ? effectiveTask.statusRows.length : 0,
        recoveryFinalOutcome: policy.recoveryFinalOutcome,
        error: String(effectiveTask.lastError || triggerError).slice(0, 200)
      });
      await persistQueueState();
      return { ok: false, blocked };
    }
  }
  if (taskTriggersFlowRendererCrashRecovery(effectiveTask)) {
    return recoverFlowRendererCrashGlobalFailure(effectiveTask, tabId);
  }
  if (taskTriggersFlowSessionRecovery(effectiveTask)) {
    return recoverFlowSessionGlobalFailure(effectiveTask, tabId);
  }
  const recoveryAttempts = Number(effectiveTask.globalRecoveryAttempts || 0) + 1;
  if (recoveryAttempts > MAX_FLOW_SESSION_RECOVERY_ATTEMPTS) {
    const blocked = ledger.updateTask(effectiveTask.id, {
      status: TaskStatus.blocked,
      healAction: "user_action_required",
      lastError: effectiveTask.lastError || `${effectiveTask.failureClass || "global_failure"} recovery exhausted`
    });
    recordEvent({
      type: "queue.global_recovery.exhausted",
      taskId: effectiveTask.id,
      failureClass: effectiveTask.failureClass || "",
      previousHealAction: effectiveTask.healAction || "",
      recoveryAttempts
    });
    await persistQueueState();
    return { ok: false, blocked };
  }

  const cooldownMs = globalRecoveryDelayMs({ ...effectiveTask, globalRecoveryAttempts: recoveryAttempts });
  const patch = {
    globalRecoveryAttempts: recoveryAttempts,
    nextRetryAt: new Date(Date.now() + cooldownMs).toISOString()
  };
  let tabReload = null;
  if (effectiveTask.healAction === "cooldown_and_refresh" || effectiveTask.healAction === "reconnect_flow") {
    tabReload = await reloadFlowTab(tabId).catch((error) => ({ ok: false, error: String(error?.message || error || "tab_reload_failed") }));
    patch.lastHealReloadOk = tabReload?.ok === true;
  }
  ledger.updateTask(effectiveTask.id, patch);
  recordEvent({
    type: "queue.global_recovery.cooldown",
    taskId: effectiveTask.id,
    failureClass: effectiveTask.failureClass || "",
    healAction: effectiveTask.healAction || "",
    cooldownMs,
    recoveryAttempts,
    tabReloaded: tabReload?.ok === true
  });
  await persistQueueState();
  await sleep(cooldownMs);
  recordEvent({
    type: "queue.global_recovery.resume",
    taskId: effectiveTask.id,
    failureClass: effectiveTask.failureClass || "",
    healAction: effectiveTask.healAction || "",
    recoveryAttempts
  });
  return { ok: true };
}

async function recoverGenerationFailureRetryTask(task = {}, tabId = 0) {
  const status = String(task?.status || "");
  if (
    ![TaskStatus.pending, TaskStatus.generating].includes(status) ||
    (task?.healAction && task.healAction !== "retry_generation") ||
    task?.generationFailureNeedsFlowReload !== true
  ) {
    return task;
  }
  const recoveryAttempts = Number(task.generationFailureRecoveryAttempts || 0) + 1;
  const tabReload = await reloadFlowTab(tabId).catch((error) => ({
    ok: false,
    error: String(error?.message || error || "tab_reload_failed")
  }));
  const patch = {
    status: TaskStatus.pending,
    healAction: "retry_generation",
    generationFailureNeedsFlowReload: false,
    generationFailureRecoveryAttempts: recoveryAttempts,
    lastHealReloadOk: tabReload?.ok === true,
    lastHealReloadError: tabReload?.ok === true ? "" : (tabReload?.error || "tab_reload_failed")
  };
  const recovered = ledger.updateTask(task.id, patch) || task;
  recordEvent({
    type: "queue.generation_retry.reload",
    taskId: task.id,
    recoveryAttempts,
    tabReloaded: tabReload?.ok === true,
    error: tabReload?.ok === true ? "" : (tabReload?.error || "tab_reload_failed"),
    previousFailedOutputMediaIds: task.previousFailedOutputMediaIds || []
  });
  await persistQueueState();
  await sleep(tabReload?.ok === true ? 3500 : 1200);
  return ledger.getTask(task.id) || recovered;
}

function flowApiModeFromPayload(payload = {}) {
  const raw = compactString(payload.mode || payload.workflow || payload.settings?.mode || payload.settings?.workflow).toLowerCase();
  const aliases = {
    t2i: "text-to-image",
    r2i: "text-to-image",
    "text-to-image": "text-to-image",
    t2v: "text-to-video",
    "text-to-video": "text-to-video",
    i2v: "image-to-video",
    i2v_first: "image-to-video",
    "image-to-video": "image-to-video",
    i2v_interpolation: "start-end-image-to-video",
    "start-end-image-to-video": "start-end-image-to-video",
    r2v: "ingredients-to-video",
    "ingredients-to-video": "ingredients-to-video",
    v2v: "video-to-video",
    "video-to-video": "video-to-video"
  };
  if (aliases[raw]) return aliases[raw];
  return compactString(payload.mediaType || payload.type || payload.settings?.mediaType).toLowerCase() === "video"
    ? "text-to-video"
    : "text-to-image";
}

function flowApiPromptRecords(payload = {}) {
  const source = Array.isArray(payload.prompts) && payload.prompts.length
    ? payload.prompts
    : [payload.prompt];
  return source.map((entry, index) => ({
    prompt: compactString(typeof entry === "string" ? entry : entry?.prompt || entry?.text),
    rowKey: compactString(typeof entry === "object" ? entry?.rowKey || entry?.rowId : "") || String(index + 1)
  })).filter((entry) => entry.prompt);
}

function flowApiJobSummary(tasks = [], payload = {}) {
  const rows = [];
  for (const task of tasks) {
    const outputs = Array.isArray(task.outputs) && task.outputs.length
      ? task.outputs
      : (Array.isArray(task.outputMediaIds) ? task.outputMediaIds : []).map((mediaId, mediaIndex) => ({ mediaId, mediaIndex }));
    for (const [outputIndex, output] of outputs.entries()) {
      const mediaId = compactString(output?.mediaId || output?.id);
      if (!mediaId) continue;
      rows.push({
        rowId: task.id,
        rowKey: compactString(task.bridgeRowKey) || String(Number(task.jobIndex || 0) + 1),
        jobId: compactString(task.jobId),
        prompt: compactString(task.prompt),
        status: "complete",
        mediaId,
        mediaIndex: Number.isFinite(Number(output?.mediaIndex)) ? Number(output.mediaIndex) : outputIndex,
        mediaUrl: compactString(output?.mediaUrl) || buildMediaRedirectUrl({ mediaId }),
        thumbnailUrl: compactString(output?.thumbnailUrl) || buildMediaThumbnailUrl({ mediaId }),
        mimeType: taskMediaKind(task) === "videos" ? "video/mp4" : "image/jpeg",
        kind: taskMediaKind(task),
        workflowId: compactString(output?.workflowId),
        mediaGenerationId: compactString(output?.mediaGenerationId || output?.workflowId)
      });
    }
  }
  const statuses = tasks.map((task) => compactString(task.status).toLowerCase());
  const open = statuses.filter((status) => ["pending", "submitting", "submitted", "generating", "downloading"].includes(status)).length;
  const failed = statuses.filter((status) => ["failed", "blocked"].includes(status)).length;
  const complete = statuses.filter((status) => status === "complete" || status === "done").length;
  const terminal = tasks.length > 0 && open === 0;
  const partial = rows.length > 0 && failed > 0;
  const status = !terminal ? "generating" : rows.length > 0 ? "done" : "failed";
  const errors = tasks.filter((task) => ["failed", "blocked"].includes(compactString(task.status).toLowerCase())).map((task) => ({
    rowId: task.id,
    rowKey: compactString(task.bridgeRowKey),
    code: compactString(task.failureClass || task.flowErrorCode || task.status).toUpperCase(),
    message: compactString(task.lastError || task.error || task.blockReason || "Flow generation failed.")
  }));
  return {
    ok: rows.length > 0 || !terminal,
    code: terminal && !rows.length ? "FLOW_API_GENERATION_FAILED" : "",
    message: terminal && !rows.length ? (errors[0]?.message || "Auto Flow API generation produced no outputs.") : "",
    idempotencyKey: compactString(payload.idempotencyKey || payload.jobId || tasks[0]?.jobId),
    jobId: compactString(payload.idempotencyKey || payload.jobId || tasks[0]?.jobId),
    projectId: compactString(payload.projectId || tasks[0]?.projectId),
    tabId: compactString(payload.tabId),
    laneId: compactString(payload.laneId),
    submitPath: "api_first",
    status,
    terminal,
    partial,
    counts: { total: tasks.length, complete, failed, open, outputs: rows.length },
    mediaIds: [...new Set(rows.map((row) => row.mediaId))],
    rowIds: [...new Set(rows.map((row) => row.rowId))],
    rows,
    errors,
    tasks: tasks.map((task) => ({
      id: task.id,
      rowKey: compactString(task.bridgeRowKey),
      prompt: compactString(task.prompt),
      status: compactString(task.status),
      model: compactString(task.model),
      mode: compactString(task.mode),
      outputMediaIds: Array.isArray(task.outputMediaIds) ? task.outputMediaIds : [],
      failureClass: compactString(task.failureClass),
      lastError: compactString(task.lastError)
    }))
  };
}

async function reconcileFlowApiVideoTasks(tasks = [], payload = {}) {
  const openVideos = tasks.filter((task) => {
    if (taskMediaKind(task) !== "videos") return false;
    if ([TaskStatus.submitting, TaskStatus.generating].includes(task.status)) return true;
    // MV3 restores interrupted active tasks as pending. If a paid write already
    // has captured output identity, pending means reconcile-only—not resubmit.
    return task.status === TaskStatus.pending
      && ["accepted", "write_dispatched", "ambiguous_watch_only"].includes(String(task.paidWriteState || ""))
      && [
        ...(Array.isArray(task.mediaIds) ? task.mediaIds : []),
        ...(Array.isArray(task.submitPrimaryMediaIds) ? task.submitPrimaryMediaIds : [])
      ].some((id) => compactString(id));
  });
  if (!openVideos.length) return tasks;
  const projectId = compactString(payload.projectId || openVideos[0]?.projectId);
  const requestedTabId = Number(payload.tabId || 0) || 0;
  const tab = await findExactFlowProjectTab(projectId, requestedTabId);
  if (!tab?.id) return tasks;
  const flowClient = createFlowClientForTab(tab.id);
  for (const task of openVideos) {
    const mediaIds = [...new Set([
      ...(Array.isArray(task.mediaIds) ? task.mediaIds : []),
      ...(Array.isArray(task.submitPrimaryMediaIds) ? task.submitPrimaryMediaIds : []),
      ...(Array.isArray(task.outputMediaIds) ? task.outputMediaIds : [])
    ].map(compactString).filter(Boolean))];
    if (!mediaIds.length) continue;
    try {
      const statusResult = await flowClient.pollVideoStatus({ projectId, mediaIds });
      const rows = extractVideoStatusRows(statusResult?.data).filter((row) => mediaIds.includes(compactString(row.id)));
      if (!rows.length) continue;
      const expected = Math.max(1, Number(task.expectedVideos || task.repeatCount || mediaIds.length || 1) || 1);
      const completeRows = rows.filter((row) => row.status === "complete" && row.id);
      const failedRows = rows.filter((row) => row.status === "failed");
      const terminalRows = rows.filter((row) => row.status === "complete" || row.status === "failed");
      if (terminalRows.length >= expected && !completeRows.length) {
        const failureText = failureTextForStatusRows(failedRows, "MEDIA_GENERATION_STATUS_FAILED");
        ledger.updateTask(task.id, {
          status: TaskStatus.failed,
          completedAt: new Date().toISOString(),
          mediaIds,
          statusRows: rows,
          foundVideos: 0,
          failedOutputCount: failedRows.length || expected,
          failedOutputMediaIds: failedRows.map((row) => row.id || row.workflowId).filter(Boolean),
          partialFailure: true,
          lastError: failureText,
          failureClass: "media_generation_failed",
          failureScope: "task",
          healAction: "",
          recoveryPolicy: "fresh_job_only",
          sideEffectRetryBlocked: true,
          possibleSideEffect: true,
          lastPollAt: new Date().toISOString()
        });
      } else if (terminalRows.length >= expected && completeRows.length) {
        const outputs = completeRows.slice(0, expected).map((row, mediaIndex) => ({
          id: `${task.id}:${row.id || mediaIndex}`,
          mediaId: row.id,
          mediaUrl: row.mediaUrl || buildMediaRedirectUrl({ mediaId: row.id }),
          thumbnailUrl: row.thumbnailUrl || buildMediaThumbnailUrl({ mediaId: row.id }),
          prompt: task.prompt || "",
          kind: "videos",
          status: row.status,
          rawStatus: row.rawStatus,
          workflowId: row.workflowId || "",
          mediaGenerationId: row.workflowId || "",
          mediaIndex,
          source: "flow_api_state_reconcile"
        }));
        scheduler.markComplete(task.id, {
          mediaIds,
          statusRows: rows,
          outputs,
          outputMediaIds: outputs.map((output) => output.mediaId),
          foundVideos: outputs.length,
          expectedVideos: expected,
          failedOutputCount: Math.max(0, expected - outputs.length) + failedRows.length,
          failedOutputMediaIds: failedRows.map((row) => row.id).filter(Boolean),
          partialFailure: outputs.length < expected,
          lastPollAt: new Date().toISOString()
        });
      } else {
        ledger.updateTask(task.id, {
          mediaIds,
          statusRows: rows,
          lastPollAt: new Date().toISOString()
        });
      }
      recordEvent({
        type: "flow_api_bridge.readonly_status_reconcile",
        jobId: compactString(task.jobId),
        taskId: task.id,
        mediaIds,
        completeRows: completeRows.length,
        failedRows: failedRows.length,
        terminalRows: terminalRows.length
      });
    } catch (error) {
      recordEvent({
        type: "flow_api_bridge.readonly_status_reconcile_failed",
        jobId: compactString(task.jobId),
        taskId: task.id,
        error: String(error?.message || error || "video_status_reconcile_failed")
      });
    }
  }
  await persistQueueState();
  const ids = new Set(tasks.map((task) => task.id));
  return ledger.listTasks().filter((task) => ids.has(task.id));
}

async function getFlowApiStateFromBridge(payload = {}) {
  await queueReady;
  const jobId = compactString(payload.idempotencyKey || payload.jobId);
  let tasks = ledger.listTasks().filter((task) => compactString(task.jobId) === jobId);
  if (!tasks.length) {
    throw agentBridgeError("FLOW_API_JOB_NOT_FOUND", "No Auto Flow API job exists for this idempotency key.", { jobId });
  }
  const projectId = compactString(payload.projectId);
  if (projectId && tasks.some((task) => compactString(task.projectId) !== projectId)) {
    throw agentBridgeError("AGENT_TARGET_MISMATCH", "The requested Auto Flow API job belongs to a different project.", { jobId, projectId });
  }
  tasks = await reconcileFlowApiVideoTasks(tasks, payload);
  return flowApiJobSummary(tasks, payload);
}

async function generateFlowApiFromBridge(payload = {}, request = {}) {
  await queueReady;
  const jobId = compactString(payload.idempotencyKey || payload.jobId);
  let existing = jobId ? ledger.listTasks().filter((task) => compactString(task.jobId) === jobId) : [];
  if (existing.length) {
    existing = await reconcileFlowApiVideoTasks(existing, payload);
    return { ...flowApiJobSummary(existing, payload), reused: true };
  }

  const projectId = compactString(payload.projectId);
  const requestedTabId = Number(payload.tabId || 0) || 0;
  const tab = await findExactFlowProjectTab(projectId, requestedTabId);
  if (!tab?.id) {
    throw agentBridgeError("FLOW_API_TARGET_UNAVAILABLE", "Open the exact Flow project in the paired AutoFlow Chrome profile before using API Path.", { projectId, requestedTabId });
  }
  const targetCheck = evaluateAgentTarget({
    requestedProjectId: projectId,
    requestedTabId,
    resolvedProjectId: projectIdFromUrl(tab.url || ""),
    resolvedTabId: tab.id
  });
  if (!targetCheck.ok) throw agentBridgeError(targetCheck.code, targetCheck.message, targetCheck.details);

  const prompts = flowApiPromptRecords(payload);
  const mode = flowApiModeFromPayload(payload);
  if (payload.dryRun === true) {
    return {
      ok: true,
      dryRun: true,
      submitted: false,
      transport: "autoflow_api",
      submitPath: "api_first",
      projectId,
      tabId: String(tab.id),
      laneId: compactString(payload.laneId),
      mode,
      promptCount: prompts.length,
      supportedModes: ["text-to-image", "text-to-video", "image-to-video", "start-end-image-to-video", "ingredients-to-video", "video-to-video"]
    };
  }
  if (!jobId) throw agentBridgeError("FLOW_API_IDEMPOTENCY_REQUIRED", "Auto Flow API generation requires an idempotencyKey.");
  if (payload.captainAuthorized !== true || payload.authorizedBatch !== true) {
    throw agentBridgeError("FLOW_API_CREDIT_APPROVAL_REQUIRED", "Auto Flow API generation requires explicit one-batch authorization.");
  }
  if (!prompts.length) throw agentBridgeError("FLOW_API_PROMPT_REQUIRED", "Auto Flow API generation requires at least one prompt.");
  const unrelatedOpen = ledger.listTasks().filter((task) => {
    const status = compactString(task.status).toLowerCase();
    return ["pending", "submitting", "submitted", "generating", "downloading"].includes(status);
  });
  if (runtimeState.queueRunning || unrelatedOpen.length) {
    throw agentBridgeError("FLOW_API_QUEUE_BUSY", "Auto Flow already has an active queue. Finish or stop it before starting a PatchWork API batch.", {
      queueRunning: runtimeState.queueRunning,
      openTaskIds: unrelatedOpen.map((task) => task.id)
    });
  }
  await assertAgentBridgeWriteEntitled(payload);

  const flowClient = createFlowClientForTab(tab.id);
  const referenceResolution = await resolveAgentApiReferenceUploads(payload, projectId, flowClient);
  const uploadsBySource = new Map((referenceResolution.uploads || []).map((upload) => [compactString(upload.sourceIdentity), upload]));
  const attachments = (referenceResolution.plan?.attachments || []).map((attachment, index) => ({
    ...attachment,
    mediaId: compactString(attachment.mediaId || uploadsBySource.get(compactString(attachment.sourceIdentity))?.mediaId),
    order: Number(attachment.order || index + 1)
  })).filter((attachment) => attachment.mediaId);
  const roleForAttachment = (attachment, index) => {
    const role = compactString(attachment.role).toLowerCase();
    if (/^(first|start|firstframe|start-frame)$/.test(role)) return "startFrameRef";
    if (/^(last|end|lastframe|end-frame)$/.test(role)) return "endFrameRef";
    if (mode === "ingredients-to-video") return "ingredientsRefs";
    return "imagePromptRefs";
  };
  const refInputs = attachments.map((attachment, index) => ({
    id: compactString(attachment.handle || attachment.refHandle) || `ref-${index + 1}`,
    role: roleForAttachment(attachment, index),
    mediaId: attachment.mediaId,
    fileName: compactString(attachment.fileName) || `reference-${index + 1}.png`,
    title: compactString(attachment.fileName) || `Reference ${index + 1}`,
    mimeType: compactString(attachment.mimeType) || "image/png",
    dataUrl: "",
    imageUrl: "",
    mediaUrl: ""
  }));
  const startRefInput = refInputs.find((ref) => ref.role === "startFrameRef") || refInputs[0] || null;
  const endRefInput = refInputs.find((ref) => ref.role === "endFrameRef") || null;
  if (mode === "image-to-video" && !startRefInput) throw agentBridgeError("FLOW_API_START_FRAME_REQUIRED", "Frame to Video requires one uploaded start frame.");
  if (mode === "start-end-image-to-video" && (!startRefInput || !endRefInput)) throw agentBridgeError("FLOW_API_FRAME_PAIR_REQUIRED", "Start + End Frames requires exactly two ordered frame references.");
  if (mode === "ingredients-to-video" && !refInputs.length) throw agentBridgeError("FLOW_API_INGREDIENT_REFS_REQUIRED", "Ingredients to Video requires at least one reference image.");
  if (mode === "video-to-video" && !compactString(payload.sourceMediaId)) throw agentBridgeError("VIDEO_TO_VIDEO_SOURCE_REQUIRED", "Video to Video API Path requires an existing Flow sourceMediaId.");

  const settings = payload.settings && typeof payload.settings === "object" ? payload.settings : {};
  const repeatCount = Math.max(1, Math.min(8, Number(payload.outputCount || payload.countPerPrompt || settings.countPerPrompt || 1) || 1));
  for (const [index, row] of prompts.entries()) {
    ledger.addTask({
      id: crypto.randomUUID(),
      jobId,
      bridgeRowKey: row.rowKey,
      jobIndex: index,
      jobPromptCount: prompts.length,
      jobTitle: compactString(payload.jobTitle || "PatchWork API Path"),
      mode,
      requestedMode: mode,
      normalizedRuntimeMode: mode,
      buildJobsMode: mode,
      prompt: row.prompt,
      projectId,
      model: compactString(payload.model || settings.model || settings.imageModel || settings.videoModel || "default"),
      aspectRatio: compactString(payload.aspectRatio || settings.aspectRatio || "portrait"),
      repeatCount,
      videoLength: compactString(payload.durationSeconds || settings.durationSeconds || settings.duration || "8"),
      videoDurationSeconds: compactString(payload.durationSeconds || settings.durationSeconds || settings.duration || "8"),
      returnSilentVideos: payload.returnSilentVideos !== false && settings.returnSilentVideos !== false,
      minInitialWaitTime: Number(payload.minInitialWaitTime ?? settings.minInitialWaitTime ?? (mode === "text-to-image" ? 0 : 20)),
      maxInitialWaitTime: Number(payload.maxInitialWaitTime ?? settings.maxInitialWaitTime ?? (mode === "text-to-image" ? 0 : 40)),
      submitPath: "api_first",
      submitPathPreference: "api_first",
      apiOnly: true,
      download: { enabled: false },
      mediaIds: [],
      refMediaIds: refInputs.map((ref) => ref.mediaId),
      refInputs: refInputs.map((ref) => ({ ...ref })),
      startRefInput: startRefInput ? { ...startRefInput } : null,
      endRefInput: endRefInput ? { ...endRefInput } : null,
      startMediaId: compactString(payload.startMediaId || startRefInput?.mediaId),
      endMediaId: compactString(payload.endMediaId || endRefInput?.mediaId),
      sourceMediaId: compactString(payload.sourceMediaId),
      sourceVideoMediaId: compactString(payload.sourceMediaId),
      sourceWorkflowId: compactString(payload.sourceWorkflowId),
      startFrameIndex: Number.isFinite(Number(payload.startFrameIndex)) ? Number(payload.startFrameIndex) : 0,
      endFrameIndex: Number.isFinite(Number(payload.endFrameIndex)) ? Number(payload.endFrameIndex) : 240,
      sourceDurationSeconds: Number.isFinite(Number(payload.sourceDurationSeconds)) ? Number(payload.sourceDurationSeconds) : 10,
      bridgeRequestId: compactString(request.id)
    });
  }
  await persistQueueState();
  recordEvent({ type: "flow_api_bridge.submit", jobId, projectId, tabId: tab.id, mode, prompts: prompts.length, repeatCount });
  await runQueueUntilIdle(tab.id);
  const tasks = ledger.listTasks().filter((task) => compactString(task.jobId) === jobId);
  return { ...flowApiJobSummary(tasks, { ...payload, tabId: String(tab.id) }), reused: false };
}

function normalizeRefInput(ref = {}) {
  if (!ref || typeof ref !== "object") return null;
  const mediaId = mediaIdFromRefInput(ref);
  const fileName = compactString(ref.fileName || ref.title || ref.name);
  if (!mediaId && !fileName) return null;
  return {
    id: compactString(ref.id),
    blobStoreId: compactString(ref.blobStoreId),
    role: compactString(ref.role),
    mediaId,
    fileName,
    title: compactString(ref.title || fileName),
    mimeType: compactString(ref.mimeType || "image/png"),
    imageUrl: compactString(ref.imageUrl || ref.dataUrl || ref.mediaUrl),
    dataUrl: compactString(ref.dataUrl),
    mediaUrl: compactString(ref.mediaUrl || ref.imageUrl || ref.dataUrl)
  };
}

function refInputsFrom(value) {
  if (!Array.isArray(value)) return [];
  return value.map((ref) => normalizeRefInput(ref)).filter(Boolean);
}

async function ensureTaskProjectId(task, tabId) {
  const currentTab = await chrome.tabs.get(tabId).catch(() => null);
  let projectId = String(task.projectId || projectIdFromUrl(currentTab?.url || "") || "").trim();
  const page = await sendPageCommand({
    action: "projectState",
    timeoutMs: 10000
  }, tabId);
  projectId = String(page.projectId || projectId).trim();
  if (!projectId) throw new Error("missing_project_id");
  ledger.updateTask(task.id, { projectId });
  if (taskPrefersDom(task)) {
    const latestTab = await chrome.tabs.get(tabId).catch(() => null);
    const latestUrl = String(latestTab?.url || "");
    if (/\/edit\//i.test(latestUrl)) {
      const targetUrl = projectRootUrlFromFlowUrl(latestUrl, projectId);
      if (targetUrl) {
        recordEvent({
          type: "queue.dom_project_root.navigate",
          taskId: task.id,
          tabId,
          fromUrl: latestUrl,
          toUrl: targetUrl
        });
        await chrome.tabs.update(tabId, { url: targetUrl });
        const ready = await waitForFlowProjectRoot(tabId, projectId);
        recordEvent({
          type: ready.ok ? "queue.dom_project_root.ready" : "queue.dom_project_root.timeout",
          taskId: task.id,
          tabId,
          url: ready.url || "",
          error: ready.error || ""
        });
        await sleep(1200);
      }
    }
  }
  return projectId;
}

async function resolveContinuityChainForTask(task = {}, tabId = null) {
  const result = buildContinuityRefPatch(ledger.listTasks(), task);
  if (result.status === "not_chain" || result.status === "already_resolved") {
    return { ok: true, task: ledger.getTask(task.id) || task, status: result.status };
  }
  if (result.status === "resolved" && result.patch) {
    const resolved = ledger.updateTask(task.id, result.patch);
    recordEvent({
      type: "queue.continuity_ref.resolved",
      taskId: task.id,
      sourceTaskId: result.sourceTask?.id || "",
      mediaId: result.patch.continuitySourceMediaId || "",
      jobIndex: Number(task.jobIndex || 0)
    });
    await persistQueueState();
    return { ok: true, task: resolved, status: result.status };
  }
  if (result.status === "source_not_ready" && result.sourceTask?.id && taskMediaKind(result.sourceTask) === "images") {
    recordEvent({
      type: "queue.continuity_ref.wait_source",
      taskId: task.id,
      sourceTaskId: result.sourceTask.id,
      sourceStatus: result.sourceTask.status || ""
    });
    if (result.sourceTask.status === TaskStatus.generating && tabId) {
      await waitForImageTaskOutputs(result.sourceTask, tabId);
      await persistQueueState();
    } else {
      await sleep(1000);
    }
    return { ok: false, waiting: true, status: result.status, sourceTask: result.sourceTask };
  }
  const errorByStatus = {
    missing_source: "CONTINUITY_SOURCE_TASK_MISSING",
    source_failed: "CONTINUITY_SOURCE_TASK_FAILED",
    source_output_missing: "CONTINUITY_SOURCE_OUTPUT_MISSING"
  };
  const error = errorByStatus[result.status] || "CONTINUITY_REF_NOT_READY";
  const blocked = scheduler.markBlocked(task.id, error);
  recordEvent({
    type: "queue.continuity_ref.blocked",
    taskId: task.id,
    sourceTaskId: result.sourceTask?.id || "",
    status: result.status,
    error
  });
  await persistQueueState();
  return { ok: false, blocked: true, task: blocked, status: result.status, error };
}

async function runQueueUntilIdle(preferredTabId) {
  await queueReady;
  if (runtimeState.queueRunning) return;
  const runToken = Number(runtimeState.queueRunToken || 0) + 1;
  runtimeState.queueRunToken = runToken;
  runtimeState.queueRunning = true;
  resetFlowSessionRecoveryForRun(runToken);
  resetFlowRendererCrashRecoveryForRun(runToken);
  const isActiveRun = () => runtimeState.queueRunning && runtimeState.queueRunToken === runToken;
  recordEvent({ type: "queue.start", runToken });
  try {
    const tab = await findFlowTab(preferredTabId);
    if (!tab?.id) throw new Error("flow_tab_not_found");
    const executor = createExecutorForTab(tab.id);

    while (isActiveRun()) {
      const next = scheduler.nextPendingTask();
      if (!next) {
        const mergedCompletedRepairs = await mergeCompletedVideoRepairTasks("queue_idle_completed_repairs");
        if (mergedCompletedRepairs > 0) {
          await persistQueueState();
          continue;
        }
        const completedTasksNeedingDownload = ledger.listTasks()
          .filter((task) => shouldAttemptAutoDownloadForTask(task))
          .map((task) => task.id);
        if (completedTasksNeedingDownload.length) {
          await autoDownloadCompletedTasks(completedTasksNeedingDownload, "queue_idle_complete");
          await persistQueueState();
          continue;
        }
        const activeVideoTask = ledger.listTasks().find((task) => task.status === TaskStatus.generating && taskMediaKind(task) === "videos");
        if (activeVideoTask) {
          if (activeVideoTask.generationFailureNeedsFlowReload === true) {
            await recoverGenerationFailureRetryTask(activeVideoTask, tab.id);
            await persistQueueState();
            continue;
          }
          const settledVideo = await waitForVideoTaskOutputs(activeVideoTask, tab.id);
          const usageRecord = await recordPromptUsageForTask(settledVideo || activeVideoTask, "after_video_settle");
          if (!usageRecord.ok) {
            await blockPendingQueueAfterUsageRecordingFailure(usageRecord.error || "usage_recording_failed");
            break;
          }
          if (!isActiveRun()) break;
          recordEvent({
            type: "queue.video_settle.done",
            taskId: settledVideo?.id || activeVideoTask.id,
            status: settledVideo?.status || activeVideoTask.status,
            foundVideos: settledVideo?.foundVideos || 0,
            expectedVideos: settledVideo?.expectedVideos || activeVideoTask.expectedVideos || activeVideoTask.repeatCount || 1
          });
          if (settledVideo?.retryOfTaskId) {
            const mergedParent = await mergeVideoRepairTaskIntoParent(settledVideo);
            if (mergedParent?.partialFailure === true) {
              await appendVideoRepairTask(mergedParent, "video_repair_still_partial");
            }
          } else {
            await appendVideoRepairTask(settledVideo, "video_settle_partial");
          }
          await persistQueueState();
          if (settledVideo?.status === TaskStatus.generating) {
            await sleep(3000);
            continue;
          }
          continue;
        }
        const activeImageTask = ledger.listTasks().find((task) => task.status === TaskStatus.generating && taskMediaKind(task) === "images");
        if (!activeImageTask) break;
        const settled = await waitForImageTaskOutputs(activeImageTask, tab.id);
        const usageRecord = await recordPromptUsageForTask(settled || activeImageTask, "after_image_settle");
        if (!usageRecord.ok) {
          await blockPendingQueueAfterUsageRecordingFailure(usageRecord.error || "usage_recording_failed");
          break;
        }
        if (!isActiveRun()) break;
        recordEvent({
          type: "queue.image_settle.done",
          taskId: settled?.id || activeImageTask.id,
          status: settled?.status || activeImageTask.status,
          foundImages: settled?.foundImages || 0,
          expectedImages: settled?.expectedImages || activeImageTask.expectedImages || activeImageTask.repeatCount || 1
        });
        await persistQueueState();
        if (settled?.status === TaskStatus.generating) {
          await sleep(3000);
          continue;
        }
        continue;
      }
      try {
        const activeBeforeComposerRetry = activeVideoTaskBeforeComposerRetry(next, ledger.listTasks());
        if (activeBeforeComposerRetry) {
          if (activeBeforeComposerRetry.generationFailureNeedsFlowReload === true) {
            await recoverGenerationFailureRetryTask(activeBeforeComposerRetry, tab.id);
            await persistQueueState();
            continue;
          }
          const settledVideo = await waitForVideoTaskOutputs(activeBeforeComposerRetry, tab.id);
          if (!isActiveRun()) break;
          const latestNext = ledger.getTask(next.id) || next;
          const composerRetryWaitCount = Math.max(0, Number(latestNext.composerRetryWaitCount || 0) || 0) + 1;
          ledger.updateTask(next.id, {
            composerRetryWaitCount,
            composerRetryWaitedAt: new Date().toISOString()
          });
          recordEvent({
            type: "queue.video_wait_before_composer_retry",
            taskId: next.id,
            activeTaskId: settledVideo?.id || activeBeforeComposerRetry.id,
            status: settledVideo?.status || activeBeforeComposerRetry.status,
            foundVideos: settledVideo?.foundVideos || 0,
            expectedVideos: settledVideo?.expectedVideos || activeBeforeComposerRetry.expectedVideos || activeBeforeComposerRetry.repeatCount || 1,
            lastError: next.lastError || "",
            composerRetryWaitCount
          });
          if (settledVideo?.retryOfTaskId) {
            const mergedParent = await mergeVideoRepairTaskIntoParent(settledVideo);
            if (mergedParent?.partialFailure === true) {
              await appendVideoRepairTask(mergedParent, "composer_retry_wait_repair_still_partial");
            }
          } else {
            await appendVideoRepairTask(settledVideo, "composer_retry_wait_video_settle_partial");
          }
          await persistQueueState();
          if (settledVideo?.status === TaskStatus.generating) {
            await sleep(3000);
          }
          continue;
        }
        const continuity = await resolveContinuityChainForTask(next, tab.id);
        if (continuity.waiting) continue;
        if (continuity.blocked) continue;
        const nextTask = continuity.task || ledger.getTask(next.id) || next;
        await ensureTaskProjectId(nextTask, tab.id);
        await persistQueueState();
        if (!isActiveRun()) break;
        let taskToRun = ledger.getTask(nextTask.id) || nextTask;
        const access = await validateQueueStartAccess(taskToRun);
        if (!access.allowed) {
          const blockReason = access.message || access.reason || access.error || "license_required";
          scheduler.markBlocked(taskToRun.id, blockReason);
          const auth = await updateAuthState();
          recordEvent({
            type: "license.queue_start.task_blocked",
            taskId: taskToRun.id,
            mode: taskToRun.mode || "",
            reason: access.reason || access.error || "license_required",
            message: access.message || "",
            billingHealth: access.billingHealth || "",
            remaining: Number(access.usage?.remaining || auth?.license?.remaining || 0)
          });
          await persistQueueState();
          break;
        }
        taskToRun = await recoverGenerationFailureRetryTask(taskToRun, tab.id);
        if (!isActiveRun()) break;
        const rendererCrash = await detectFlowRendererCrashForTask(taskToRun, tab.id, "before_submit");
        if (rendererCrash?.crashed) {
          const blocked = await markFlowRendererCrashDetected(taskToRun, tab.id, rendererCrash, "before_submit");
          if (isRecoverableGlobalTask(blocked)) {
            const recovery = await recoverGlobalQueueFailure(blocked, tab.id);
            if (recovery.ok) continue;
            const latest = recovery.blocked || ledger.getTask(blocked.id) || blocked;
            if (await skipFailedTaskForAutoRetry(latest, "flow_renderer_crash_unresolved")) continue;
          }
          break;
        }
        const domFrontendReady = await waitForDomFrontendReadyBeforeTask(taskToRun, tab.id, "before_submit");
        if (!isActiveRun()) break;
        if (domFrontendReady?.ok === false) {
          const error = domFrontendReady.error || "DOM_FRONTEND_NOT_READY";
          const blocked = scheduler.markBlocked(taskToRun.id, error);
          recordEvent({
            type: "queue.dom_frontend_settle.blocked",
            taskId: taskToRun.id,
            mode: taskToRun.mode || "",
            error,
            elapsedMs: domFrontendReady.elapsedMs || 0,
            reloaded: Boolean(domFrontendReady.reloaded),
            failureClass: blocked?.failureClass || "",
            failureScope: blocked?.failureScope || ""
          });
          await persistQueueState();
          if (isRecoverableGlobalTask(blocked)) {
            const recovery = await recoverGlobalQueueFailure(blocked, tab.id);
            if (recovery.ok) continue;
            const latest = recovery.blocked || ledger.getTask(blocked.id) || blocked;
            if (await skipFailedTaskForAutoRetry(latest, "global_recovery_exhausted")) continue;
          }
          break;
        }
        const submitOnlyVideos = taskMediaKind(taskToRun) === "videos";
        let task = await executor.runTask(taskToRun.id, {
          submitOnlyVideos,
          allowStatusFeedSubmitObservation: submitOnlyVideos
        });
        if (String(task?.lastError || "").includes("CONTINUITY_DOM_EXACT_ATTACH_UNAVAILABLE")) {
          task = scheduler.markBlocked(task.id, "CONTINUITY_DOM_EXACT_ATTACH_UNAVAILABLE");
          recordEvent({
            type: "queue.continuity_ref.current_flow_unsupported",
            taskId: task.id,
            error: "CONTINUITY_DOM_EXACT_ATTACH_UNAVAILABLE",
            sideEffectRetryBlocked: false
          });
          await persistQueueState();
          break;
        }
        if (submitOnlyVideos && taskNeedsReadOnlySideEffectReconcile(task)) {
          task = await reconcileSideEffectTaskAfterSubmit(task, tab.id);
        }
        let usageRecord = await recordPromptUsageForTask(task, "after_submit");
        if (!usageRecord.ok) {
          await blockPendingQueueAfterUsageRecordingFailure(usageRecord.error || "usage_recording_failed");
          break;
        }
        if (!isActiveRun()) break;
        if (!submitOnlyVideos && taskMediaKind(task) === "images" && task?.status !== TaskStatus.generating && task?.status !== TaskStatus.complete) {
          task = await recoverImageTaskAfterSubmitFailure(task, tab.id, "after_submit_result");
          usageRecord = await recordPromptUsageForTask(task, "after_submit_recovery");
          if (!usageRecord.ok) {
            await blockPendingQueueAfterUsageRecordingFailure(usageRecord.error || "usage_recording_failed");
            break;
          }
        }
        if (!isActiveRun()) break;
        task = submitOnlyVideos ? task : await waitForImageTaskOutputs(task, tab.id);
        if (!isActiveRun()) break;
        usageRecord = await recordPromptUsageForTask(task, "after_settle");
        if (!usageRecord.ok) {
          await blockPendingQueueAfterUsageRecordingFailure(usageRecord.error || "usage_recording_failed");
          break;
        }
        recordEvent({
          type: "queue.task.done",
          taskId: task?.id || next.id,
          status: task?.status || "unknown",
          failureClass: task?.failureClass || "",
          failureScope: task?.failureScope || "",
          mediaIds: task?.mediaIds || []
        });
        await markFlowSessionRecoverySuccessIfNeeded(task, tab.id);
        if (task?.status === TaskStatus.complete) {
          if (task.retryOfTaskId) {
            task = await mergeVideoRepairTaskIntoParent(task) || task;
            if (task?.partialFailure === true) {
              await appendVideoRepairTask(task, "video_repair_still_partial");
            }
          } else {
            await appendVideoRepairTask(task, "queue_task_complete_partial");
          }
          await autoDownloadCompletedTasks([task.id], "queue_complete");
        }
        if (taskSignalsApiFirstDomAvailable(task)) {
          recordEvent({
            type: "queue.api_first_dom_available.pause_for_confirmation",
            taskId: task.id,
            mode: task.mode || "",
            model: task.model || "",
            pending: ledger.listTasks().filter((candidate) => candidate.status === TaskStatus.pending).length,
            refsReusedForDomVerification: task.refsReusedForDomVerification === true
          });
          await persistQueueState();
          break;
        }
        await persistQueueState();
        const pendingAfterSubmit = scheduler.nextPendingTask();
        if (submitOnlyVideos && task?.status === TaskStatus.generating && pendingAfterSubmit) {
          const waitMs = generationSubmitWaitMs(task);
          recordEvent({
            type: "queue.video_inter_submit_wait",
            taskId: task.id,
            waitMs,
            minInitialWaitTime: Number(task.minInitialWaitTime || 0),
            maxInitialWaitTime: Number(task.maxInitialWaitTime || 0)
          });
          if (waitMs > 0) await sleep(waitMs);
        } else if (submitOnlyVideos && task?.status === TaskStatus.generating) {
          recordEvent({
            type: "queue.video_submit_phase_complete",
            taskId: task.id,
            reason: "keep_debugger_until_queue_finish"
          });
        }
        if (isRecoverableGlobalTask(task)) {
          const recovery = await recoverGlobalQueueFailure(task, tab.id);
          if (!recovery.ok) {
            const latest = recovery.blocked || ledger.getTask(task.id) || task;
            if (await skipFailedTaskForAutoRetry(latest, "global_recovery_exhausted")) continue;
            break;
          }
          continue;
        }
        if (["failed", "blocked"].includes(task?.status) && isDomSettingsMenuFailureTask(task)) {
          recordEvent({
            type: "queue.dom_settings_menu_not_open.pause",
            taskId: task.id,
            failureClass: task.failureClass || "",
            failureScope: task.failureScope || "",
            pending: ledger.listTasks().filter((candidate) => candidate.status === TaskStatus.pending).length
          });
          await persistQueueState();
          break;
        }
        if (["failed", "blocked"].includes(task?.status) && task?.failureScope === "global") {
          if (await skipFailedTaskForAutoRetry(task, "global_block")) continue;
          recordEvent({
            type: "queue.global_block",
            taskId: task.id,
            failureClass: task.failureClass || "",
            healAction: task.healAction || "",
            lastError: task.lastError || ""
          });
          break;
        }
        if (task?.status === "pending") {
          await sleep(Math.min(30000, Math.max(3000, Number(task.attempts || 1) * 3000)));
        }
      } catch (error) {
        if (!isActiveRun() || !ledger.getTask(next.id)) {
          recordEvent({
            type: "queue.stale_task_ignored",
            taskId: next.id,
            runToken,
            activeRunToken: runtimeState.queueRunToken,
            error: String(error?.message || error || "stale_queue_task_failed")
          });
          break;
        }
        const task = scheduler.markBlocked(next.id, error);
        await persistQueueState();
        recordEvent({
          type: "queue.task.error",
          taskId: next.id,
          error: String(error?.message || error || "queue_task_failed"),
          failureClass: task?.failureClass || "",
          failureScope: task?.failureScope || "",
          healAction: task?.healAction || ""
        });
        if (isRecoverableGlobalTask(task)) {
          const recovery = await recoverGlobalQueueFailure(task, tab.id);
          if (recovery.ok) continue;
          const latest = recovery.blocked || ledger.getTask(task.id) || task;
          if (await skipFailedTaskForAutoRetry(latest, "global_recovery_exhausted")) continue;
        }
        if (task?.failureScope === "global") break;
      }
    }
  } catch (error) {
    if (runtimeState.queueRunToken === runToken) {
      recordEvent({
        type: "queue.error",
        runToken,
        error: String(error?.message || error || "queue_failed")
      });
    } else {
      recordEvent({
        type: "queue.stale_run_error_ignored",
        runToken,
        activeRunToken: runtimeState.queueRunToken,
        error: String(error?.message || error || "queue_failed")
      });
    }
  } finally {
    if (runtimeState.queueRunToken === runToken) {
      await releaseDebuggerSessions("queue_finished", recordDebuggerTrace);
      runtimeState.queueRunning = false;
      await persistQueueState();
      recordEvent({ type: "queue.stop", runToken });
    } else {
      recordEvent({
        type: "queue.stale_run_exit",
        runToken,
        activeRunToken: runtimeState.queueRunToken,
        debuggerReleaseSkipped: true
      });
    }
  }
}

function generationSubmitWaitMs(task = {}) {
  const min = Math.max(0, Number(task.minInitialWaitTime || task.generationWaitMin || 0) || 0);
  const max = Math.max(min, Number(task.maxInitialWaitTime || task.generationWaitMax || min) || min);
  if (!max) return 0;
  const seconds = min + Math.random() * (max - min);
  return Math.round(seconds * 1000);
}

function videoMissingOutputCount(task = {}) {
  if (taskMediaKind(task) !== "videos") return 0;
  const expected = Math.max(1, Number(task.expectedVideos || task.repeatCount || 1) || 1);
  const found = Math.max(
    Number(task.foundVideos || 0) || 0,
    Array.isArray(task.outputMediaIds) ? task.outputMediaIds.length : 0,
    Array.isArray(task.outputs) ? task.outputs.filter((output) => output?.mediaId).length : 0
  );
  return Math.max(0, expected - found);
}

function shouldAppendVideoRepairTask(task = {}) {
  if (!task?.id || taskMediaKind(task) !== "videos") return false;
  if (task.status !== TaskStatus.complete) return false;
  if (task.retryOfTaskId) return false;
  const missing = videoMissingOutputCount(task);
  if (!missing) return false;
  const maxAttempts = Math.max(0, Math.min(3, Number(task.partialRetryMax ?? task.generationRetryMax ?? 3) || 3));
  const attempts = Number(task.partialRetryAttempts || 0) || 0;
  if (attempts >= maxAttempts) return false;
  return !ledger.listTasks().some((candidate) => (
    candidate?.retryOfTaskId === task.id &&
    candidate?.generationRepair === true &&
    ![TaskStatus.complete, TaskStatus.failed, TaskStatus.blocked].includes(candidate.status)
  ));
}

async function appendVideoRepairTask(task = {}, reason = "partial_video_outputs") {
  if (!shouldAppendVideoRepairTask(task)) return null;
  const missing = videoMissingOutputCount(task);
  if (!missing) return null;
  const attempt = Number(task.partialRetryAttempts || 0) + 1;
  const repairId = crypto.randomUUID();
  const retryTask = buildRetryModalTask({ ...task, reason }) || {};
  const retryContext = retryFailureContextPatch(task, reason);
  ledger.updateTask(task.id, {
    ...retryContext,
    partialRetryAttempts: attempt,
    missingOutputCount: missing,
    retryStatus: "queued"
  });
  ledger.addTask({
    ...task,
    mode: retryTask.mode || task.mode,
    reason: retryTask.reason || reason,
    retryOriginalMode: retryTask.retryOriginalMode || retryContext.retryOriginalMode,
    retrySurface: retryTask.retrySurface || retryContext.retrySurface,
    retryInputRoles: retryTask.retryInputRoles || retryContext.retryInputRoles,
    retryFrameSlots: retryTask.retryFrameSlots || retryContext.retryFrameSlots,
    retryMaxInputs: retryTask.retryMaxInputs ?? retryContext.retryMaxInputs,
    retryPromptFirst: retryTask.retryPromptFirst === true || retryContext.retryPromptFirst === true,
    retryEditSurface: retryTask.retryEditSurface || null,
    id: repairId,
    status: TaskStatus.pending,
    attempts: 0,
    retryOfTaskId: task.id,
    generationRepair: true,
    repairReason: reason,
    repairAttempt: attempt,
    repairMissingCount: missing,
    repeatCount: missing,
    expectedVideos: missing,
    foundVideos: 0,
    mediaIds: [],
    outputMediaIds: [],
    outputs: [],
    refInputs: retryTask.refInputs || [],
    refMediaIds: retryTask.refMediaIds || [],
    startRefInput: retryTask.startRefInput || null,
    endRefInput: retryTask.endRefInput || null,
    startMediaId: retryTask.startMediaId || "",
    endMediaId: retryTask.endMediaId || "",
    statusRows: [],
    submitOutputRows: [],
    events: [],
    downloadedMediaIds: [],
    skippedDownloadMediaIds: [],
    downloadErrorMediaIds: [],
    downloadedCount: 0,
    completedAt: "",
    partialFailure: false,
    failedOutputCount: 0,
    failedOutputMediaIds: [],
    lastError: "",
    failureClass: "",
    healAction: "",
    failureScope: "",
    download: task.download && typeof task.download === "object"
      ? { ...task.download, enabled: false }
      : task.download
  });
  await persistQueueState();
  recordEvent({
    type: "queue.video_repair.queued",
    parentTaskId: task.id,
    repairTaskId: repairId,
    missing,
    attempt,
    reason
  });
  return ledger.getTask(repairId);
}

async function mergeVideoRepairTaskIntoParent(task = {}) {
  if (!task?.retryOfTaskId || taskMediaKind(task) !== "videos" || task.status !== TaskStatus.complete) return null;
  const parent = ledger.getTask(task.retryOfTaskId);
  if (!parent) return null;
  const expected = Math.max(1, Number(parent.expectedVideos || parent.repeatCount || 1) || 1);
  const parentOutputs = Array.isArray(parent.outputs) ? parent.outputs.filter((output) => output?.mediaId) : [];
  const repairOutputs = Array.isArray(task.outputs) ? task.outputs.filter((output) => output?.mediaId) : [];
  const seen = new Set(parentOutputs.map((output) => String(output.mediaId || "").trim()).filter(Boolean));
  const mergedOutputs = [...parentOutputs];
  const duplicateRepairMediaIds = [];
  for (const output of repairOutputs) {
    const mediaId = String(output.mediaId || "").trim();
    if (!mediaId) continue;
    if (seen.has(mediaId)) {
      duplicateRepairMediaIds.push(mediaId);
      continue;
    }
    if (mergedOutputs.length >= expected) continue;
    seen.add(mediaId);
    mergedOutputs.push({
      ...output,
      id: `${parent.id}:${mediaId}`,
      prompt: parent.prompt || output.prompt || "",
      mediaIndex: mergedOutputs.length,
      source: output.source || "generation_repair"
    });
  }
  const parentReady = new Set((parent.videoDownloadReadyMediaIds || []).map(compactString).filter(Boolean));
  (task.videoDownloadReadyMediaIds || []).map(compactString).filter(Boolean).forEach((id) => parentReady.add(id));
  const parentDownloaded = new Set((parent.downloadedMediaIds || []).map(compactString).filter(Boolean));
  (task.downloadedMediaIds || []).map(compactString).filter(Boolean).forEach((id) => {
    parentDownloaded.add(id);
    parentReady.add(id);
  });
  const repairOutputById = new Map(repairOutputs.map((output) => [compactString(output.mediaId), output]));
  for (const mediaId of parentDownloaded) {
    if (!mediaId || seen.has(mediaId) || mergedOutputs.length >= expected) continue;
    const output = repairOutputById.get(mediaId) || {};
    seen.add(mediaId);
    mergedOutputs.push({
      ...output,
      id: `${parent.id}:${mediaId}`,
      mediaId,
      mediaUrl: output.mediaUrl || buildMediaRedirectUrl({ mediaId }),
      thumbnailUrl: output.thumbnailUrl || buildMediaThumbnailUrl({ mediaId }),
      prompt: parent.prompt || output.prompt || "",
      kind: "videos",
      status: output.status || "complete",
      downloadStatus: "downloaded",
      downloadFilename: output.downloadFilename || "",
      mediaIndex: mergedOutputs.length,
      source: output.source || "generation_repair_download"
    });
  }
  const parentSkipped = new Set((parent.skippedDownloadMediaIds || []).map(compactString).filter(Boolean));
  (task.skippedDownloadMediaIds || []).map(compactString).filter(Boolean).forEach((id) => {
    if (!parentDownloaded.has(id)) parentSkipped.add(id);
  });
  const parentDownloadErrors = new Set((parent.downloadErrorMediaIds || []).map(compactString).filter(Boolean));
  (task.downloadErrorMediaIds || []).map(compactString).filter(Boolean).forEach((id) => {
    if (!parentDownloaded.has(id)) parentDownloadErrors.add(id);
  });
  const foundVideos = mergedOutputs.length;
  const stillPartial = foundVideos < expected;
  const patch = {
    outputs: mergedOutputs,
    outputMediaIds: mergedOutputs.map((output) => output.mediaId),
    mediaIds: mergedOutputs.map((output) => output.mediaId).map(compactString).filter(Boolean),
    foundVideos,
    expectedVideos: expected,
    failedOutputCount: Math.max(0, expected - foundVideos),
    missingOutputCount: Math.max(0, expected - foundVideos),
    partialFailure: stillPartial,
    retryStatus: foundVideos >= expected
      ? "repaired"
      : (duplicateRepairMediaIds.length ? "duplicate_repair_output" : "partial_repaired"),
    duplicateRepairMediaIds,
    videoDownloadReadyMediaIds: [...parentReady],
    downloadedMediaIds: [...parentDownloaded],
    skippedDownloadMediaIds: [...parentSkipped],
    downloadErrorMediaIds: [...parentDownloadErrors],
    downloadedCount: parentDownloaded.size,
    skippedDownloadCount: parentSkipped.size,
    lastError: stillPartial ? `PARTIAL_VIDEO_OUTPUTS:${foundVideos}/${expected}` : "",
    failureClass: stillPartial ? "partial_video_outputs" : "",
    healAction: "",
    failureScope: stillPartial ? "task" : ""
  };
  const updated = ledger.updateTask(parent.id, patch);
  ledger.updateTask(task.id, {
    hiddenFromLiveQueue: true,
    hiddenFromGallery: true,
    mergedIntoTaskId: parent.id,
    retryStatus: "merged"
  });
  await persistQueueState();
  recordEvent({
    type: "queue.video_repair.merged",
    parentTaskId: parent.id,
    repairTaskId: task.id,
    foundVideos,
    expectedVideos: expected,
    stillMissing: Math.max(0, expected - foundVideos),
    duplicateRepairMediaIds
  });
  await autoDownloadCompletedTasks([parent.id], "video_repair_merge");
  return updated;
}

async function mergeCompletedVideoRepairTasks(reason = "completed_video_repair_drain") {
  let merged = 0;
  const repairs = ledger.listTasks().filter((task) => (
    task?.retryOfTaskId &&
    task?.generationRepair === true &&
    taskMediaKind(task) === "videos" &&
    task.status === TaskStatus.complete &&
    task.hiddenFromLiveQueue !== true &&
    !task.mergedIntoTaskId
  ));
  for (const repair of repairs) {
    const parent = await mergeVideoRepairTaskIntoParent(repair);
    if (parent) {
      merged += 1;
      recordEvent({
        type: "queue.video_repair.drain_merged",
        reason,
        parentTaskId: parent.id,
        repairTaskId: repair.id,
        stillMissing: videoMissingOutputCount(parent)
      });
      if (parent.partialFailure === true) {
        await appendVideoRepairTask(parent, "video_repair_still_partial");
      }
    }
  }
  return merged;
}

async function updateAuthState(data = null, options = {}) {
  const summary = await licenseClient.authSummary(data, options);
  runtimeState.authRefresh = summary.authRefresh || licenseClient.getAuthRefreshDiagnostics?.() || null;
  runtimeState.auth = summary;
  return summary;
}

function featureContextForTask(task = {}) {
  const download = task.download && typeof task.download === "object" ? task.download : {};
  return {
    task_count: ledger.listTasks().length,
    task_id: String(task.id || ""),
    mode: String(task.mode || ""),
    model: String(task.model || ""),
    aspect_ratio: String(task.aspectRatio || ""),
    repeat_count: Number(task.repeatCount || 1),
    video_length: String(task.videoLength || task.videoDurationSeconds || ""),
    submit_path: String(task.submitPath || ""),
    auto_download: download.enabled === true,
    download_resolution: String(download.resolution || ""),
    download_folder: String(download.folder || "")
  };
}

async function cachedActiveProAccess() {
  return licenseClient.getCachedActiveProLicense({ maxAgeMs: 60 * 60 * 1000 });
}

async function refreshCachedProAccessForQueueStart(reason) {
  let cachedPro = await cachedActiveProAccess();
  if (cachedPro.ok) return cachedPro;
  for (let attempt = 0; attempt < 2 && !cachedPro.ok; attempt += 1) {
    if (attempt > 0 && reason === "server_unavailable") await sleep(750);
    await updateAuthState().catch((error) => {
      recordEvent({
        type: "license.cached_pro_refresh_error",
        reason,
        attempt: attempt + 1,
        error: String(error?.message || error || "auth_refresh_failed")
      });
      return null;
    });
    cachedPro = await cachedActiveProAccess();
  }
  return cachedPro;
}

async function validateQueueStartAccess(task, options = {}) {
  if (options.freshStart === true) {
    // A cached "pro" can outlive the subscription by the cache TTL; a bounded
    // fresh check at queue start (refreshLicense honors the short success
    // cooldown and any active failure backoff) keeps an expired license from
    // burning rows beyond that window.
    try {
      const fresh = await licenseClient.refreshLicense();
      recordEvent({
        type: "license.queue_start.fresh_check",
        taskId: task?.id || "",
        tier: fresh?.tier || "",
        subscriptionStatus: fresh?.subscription_status || fresh?.subscriptionStatus || ""
      });
    } catch (error) {
      recordEvent({
        type: "license.queue_start.fresh_check_error",
        taskId: task?.id || "",
        error: String(error?.message || error || "fresh_license_check_failed")
      });
    }
  }
  let authAccess = {
    allowed: false,
    source: "auth_summary",
    reason: "auth_summary_unavailable"
  };
  try {
    const auth = await updateAuthState();
    authAccess = queueStartAccessFromAuthSummary(auth);
    if (!authAccess.allowed && queueStartAccessNeedsFreshBackend(authAccess)) {
      recordEvent({
        type: "license.queue_start.force_refresh.start",
        taskId: task?.id || "",
        mode: task?.mode || "",
        reason: authAccess.reason || "",
        billingHealth: authAccess.billingHealth || ""
      });
      authAccess = await refreshQueueStartAccessBeforeBlock(authAccess, async () => {
        const data = await licenseClient.refreshLicense();
        return updateAuthState(data);
      });
      recordEvent({
        type: "license.queue_start.force_refresh.result",
        taskId: task?.id || "",
        mode: task?.mode || "",
        allowed: authAccess.allowed,
        reason: authAccess.reason || "",
        billingHealth: authAccess.billingHealth || "",
        subscriptionStatus: authAccess.subscriptionStatus || ""
      });
    }
    recordEvent({
      type: "license.queue_start.auth_summary",
      taskId: task?.id || "",
      mode: task?.mode || "",
      allowed: authAccess.allowed,
      reason: authAccess.reason || "",
      source: authAccess.source || "",
      tier: authAccess.tier || "",
      remaining: Number(authAccess.usage?.remaining || 0),
      billingHealth: authAccess.billingHealth || "",
      subscriptionStatus: authAccess.subscriptionStatus || ""
    });
    if (authAccess.reason === "not_signed_in") {
      return authAccess;
    }
  } catch (error) {
    recordEvent({
      type: "license.queue_start.auth_summary_error",
      taskId: task?.id || "",
      mode: task?.mode || "",
      error: String(error?.message || error || "auth_summary_failed")
    });
  }

  const access = await licenseClient.validateFeatureAccess("queue_start", featureContextForTask(task));
  const reason = String(access?.reason || access?.error || "").trim();
  let cachedPro = { ok: false, reason: "not_checked" };
  if (!access.allowed && reason === "server_unavailable") {
    cachedPro = await refreshCachedProAccessForQueueStart(reason);
  }
  const finalAccess = queueStartAccessFromServerAuthority({
    localAccess: authAccess,
    serverAccess: access,
    cachedPro
  });
  if (finalAccess.source === "cached_pro") {
    recordEvent({
      type: "license.cached_pro_allow",
      reason,
      taskId: task?.id || "",
      mode: task?.mode || "",
      cacheAgeMs: cachedPro.ageMs
    });
  }
  recordEvent({
    type: "license.queue_start.server_authority",
    taskId: task?.id || "",
    mode: task?.mode || "",
    localAllowed: authAccess.allowed === true,
    localReason: authAccess.reason || "",
    serverAllowed: access?.allowed === true,
    serverSource: access?.source || "",
    serverReason: reason,
    finalAllowed: finalAccess.allowed === true,
    finalSource: finalAccess.source || "",
    finalReason: finalAccess.reason || ""
  });
  return finalAccess;
}

async function recordPromptUsageForTask(task = {}, reason = "queue_submit") {
  const current = ledger.getTask(task?.id) || task || {};
  if (!shouldRecordPromptUsageForTask(current)) {
    return { ok: true, skipped: true, reason: "not_recordable" };
  }
  const promptCount = promptUsageCountForTask(current);
  const idempotencyKey = promptUsageIdempotencyKey(current);
  ledger.updateTask(current.id, {
    usageRecordPendingAt: new Date().toISOString(),
    usageRecordReason: reason,
    usageRecordCount: promptCount,
    usageRecordKey: idempotencyKey
  });
  recordEvent({
    type: "license.prompt_usage.record.start",
    taskId: current.id,
    mode: current.mode || "",
    submitPath: current.submitPath || current.submitPathPreference || "",
    promptCount,
    idempotencyKey,
    reason
  });
  const result = await licenseClient.recordPromptUsage({
    promptCount,
    taskId: current.id,
    mode: current.mode || "",
    submitPath: current.submitPath || current.submitPathPreference || "",
    source: reason,
    idempotencyKey
  });
  if (!result.ok) {
    const error = result.error || result.reason || "usage_recording_failed";
    ledger.updateTask(current.id, {
      usageRecordPendingAt: "",
      usageRecordFailedAt: new Date().toISOString(),
      usageRecordError: error
    });
    recordEvent({
      type: "license.prompt_usage.record.failed",
      taskId: current.id,
      mode: current.mode || "",
      promptCount,
      idempotencyKey,
      error
    });
    await persistQueueState();
    return { ok: false, error };
  }

  ledger.updateTask(current.id, {
    usageRecordedAt: new Date().toISOString(),
    usageRecordPendingAt: "",
    usageRecordError: "",
    usageRecordCount: promptCount,
    usageRecordKey: idempotencyKey
  });
  const auth = await updateAuthState(result.license || null);
  recordEvent({
    type: "license.prompt_usage.record.ok",
    taskId: current.id,
    mode: current.mode || "",
    promptCount,
    idempotencyKey,
    tier: auth?.tier || "",
    used: Number(auth?.license?.prompts_today || auth?.license?.promptsToday || 0),
    limit: Number(auth?.license?.prompt_limit || auth?.license?.promptLimit || 0)
  });
  await persistQueueState();
  return { ok: true, auth };
}

async function blockPendingQueueAfterUsageRecordingFailure(error = "usage_recording_failed") {
  const pending = scheduler.nextPendingTask();
  if (!pending) return null;
  const blocked = scheduler.markBlocked(pending.id, error);
  recordEvent({
    type: "license.prompt_usage.queue_blocked",
    taskId: pending.id,
    error,
    failureClass: blocked?.failureClass || "",
    failureScope: blocked?.failureScope || ""
  });
  await persistQueueState();
  return blocked;
}

async function handleAuthCommand(payload = {}) {
  captureAuthEnvironment(payload);
  const action = String(payload.action || "state").trim();
  if (action === "state" || action === "init") {
    const data = await licenseClient.initLicense({ forceFresh: payload.forceFresh === true });
    return updateAuthState(data);
  }
  if (action === "send_code") {
    await licenseClient.signInWithMagicLink(payload.email);
    return { ...(await updateAuthState()), codeSent: true };
  }
  if (action === "verify_code") {
    await licenseClient.verifyOtpToken(payload.email, payload.code);
    const data = await licenseClient.initLicense({ forceFresh: true });
    return { ...(await updateAuthState(data)), verified: true };
  }
  if (action === "sign_out") {
    await licenseClient.signOut();
    return updateAuthState();
  }
  if (action === "refresh") {
    const data = await licenseClient.refreshLicense({ forceNetwork: true });
    return updateAuthState(data);
  }
  if (action === "upgrade") {
    const result = await licenseClient.startUpgradeFlow({ source: "rebuild_sidepanel" });
    return { ...(await updateAuthState()), upgrade: result };
  }
  if (action === "manage_subscription") {
    const result = await licenseClient.openManageSubscription();
    return { ...(await updateAuthState()), portal: result };
  }
  if (action === "runtime_capabilities") {
    const capabilities = await licenseClient.fetchRuntimeCapabilities({
      force: payload.force === true,
      requestedCapabilities: payload.requestedCapabilities || []
    });
    return { ...(await updateAuthState()), capabilities };
  }
  throw new Error(`unknown_auth_action:${action}`);
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!isAutoFlowRebuildMessage(message)) return false;
  if (!privacyConsentGranted) {
    sendResponse(createMessage(message.type, privacyConsentRequiredPayload()));
    return true;
  }

  if (![MessageType.BridgeHealth, MessageType.AuthCommand].includes(message.type)) {
    recordEvent({
      type: message.type,
      tabId: sender?.tab?.id || null
    });
  }

  if (message.type === MessageType.BridgeHealth) {
    (async () => {
      await queueReady;
      const healthPayload = message.payload || {};
      const senderBinding = sender?.tab?.id && isFlowToolUrl(sender.tab.url || "")
        ? promoteFlowTabBinding(sender.tab, healthPayload, "bridge_health")
        : null;
      const includeGallery = healthPayload.lightweight !== true && healthPayload.includeGallery !== false;
      const hintedTabId = Number(healthPayload.tabId || healthPayload.activeTabId || runtimeState.activeTabId || 0) || undefined;
      const tab = senderBinding?.activeTabId
        ? sender.tab
        : await findFlowTab(hintedTabId).catch(() => null);
      const binding = promoteFlowTabBinding(tab || {}, healthPayload, "bridge_health_lookup")
        || senderBinding
        || runtimeBindingPayload(tab || {}, healthPayload);
      const projectId = binding.projectId || projectIdFromUrl(tab?.url || "");
      if (projectId && runtimeState.lastGalleryProjectId && runtimeState.lastGalleryProjectId !== projectId) {
        runtimeState.lastGalleryItems = [];
      }
      if (projectId) runtimeState.lastGalleryProjectId = projectId;
      const tabProjectConnected = Boolean(binding.activeTabId && projectId);
      const bridgeProbe = tabProjectConnected
        ? await ensureFlowBridge(binding.activeTabId).catch((error) => ({
          ok: false,
          error: String(error?.message || error || "flow_bridge_not_ready")
        }))
        : { ok: false, error: binding.activeTabId ? "missing_project_id" : "flow_tab_not_found" };
      const bridgeFields = bridgeRuntimeFields(bridgeProbe, tabProjectConnected);
      const runtimeConnected = tabProjectConnected && bridgeFields.flowPageBlocked !== true;
      runtimeState.bridgeHealthy = bridgeFields.bridgeHealthy;
      const payload = {
        ok: true,
        queue: queueState(),
        runtime: {
          connected: runtimeConnected,
          activeTabId: binding.activeTabId || null,
          projectId,
          pageUrl: binding.pageUrl || tab?.url || "",
          pageTitle: binding.pageTitle || tab?.title || "",
          agentBridge: buildAgentBridgeTransportStatus(),
          ...bridgeFields,
          error: bridgeFields.flowPageError || (binding.activeTabId ? (projectId ? null : "missing_project_id") : "flow_tab_not_found"),
          lastSyncAt: new Date().toISOString()
        },
        queueRunning: runtimeState.queueRunning,
        auth: runtimeState.auth,
        events: runtimeState.events.slice(-20)
      };
      if (includeGallery) {
        payload.gallery = galleryState(
          runtimeState.lastGalleryItems || [],
          runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger",
          projectId || runtimeState.lastGalleryProjectId
        );
      }
      sendResponse(createMessage(MessageType.BridgeHealth, payload));
    })();
    return true;
  }

  if (message.type === MessageType.AuthCommand) {
    (async () => {
      try {
        const auth = await handleAuthCommand(message.payload || {});
        sendResponse(createMessage(MessageType.AuthState, {
          ok: true,
          auth
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AuthState, {
          ok: false,
          error: String(error?.message || error || "auth_command_failed"),
          auth: runtimeState.auth
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.AgentBridgeControl) {
    (async () => {
      try {
        await queueReady;
        const action = compactString(message.payload?.action || "");
        if (action === "connect") {
          const result = await connectThisFlowTabFromBridge(message.payload || {});
          sendResponse(createMessage(MessageType.AgentBridgeControl, {
            ok: true,
            action,
            result,
            runtime: {
              agentBridge: buildAgentBridgeTransportStatus()
            },
            events: runtimeState.events.slice(-20)
          }));
          return;
        }
        if (action !== "restart") {
          throw Object.assign(new Error(`Unsupported agent bridge control action: ${action || "missing"}`), {
            code: "AGENT_BRIDGE_CONTROL_UNSUPPORTED"
          });
        }
        await agentWsBrokerBridgeController.refresh("sidepanel_retry");
        const wsDiagnostics = agentWsBrokerBridgeController.diagnostics();
        const nativeResult = await agentNativeBridgeController.restart("sidepanel_retry");
        const result = {
          ok: wsDiagnostics.connected === true || nativeResult.ok === true,
          action,
          reconnecting: wsDiagnostics.reconnecting === true,
          ws_broker: wsDiagnostics,
          native_messaging_legacy: nativeResult
        };
        recordEvent({
          type: result.ok ? "agent_bridge.restart_ui_ok" : "agent_bridge.restart_ui_failed",
          ok: result.ok === true,
          activeTransport: buildAgentBridgeTransportStatus().activeTransport || "",
          errorCode: compactString(nativeResult.error?.code || ""),
          error: compactString(nativeResult.error?.message || "")
        });
        sendResponse(createMessage(MessageType.AgentBridgeControl, {
          ok: result.ok === true,
          action,
          result,
          runtime: {
            agentBridge: buildAgentBridgeTransportStatus()
          },
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentBridgeControl, {
          ok: false,
          action: compactString(message.payload?.action || ""),
          error: String(error?.message || error || "agent_bridge_control_failed"),
          code: compactString(error?.code || "AGENT_BRIDGE_CONTROL_FAILED"),
          runtime: {
            agentBridge: buildAgentBridgeTransportStatus()
          },
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.PageCommand) {
    (async () => {
      const action = String(message.payload?.action || "");
      try {
        if (isMaintenanceAction(action)) {
          const result = await runBackgroundMaintenanceAction(action, message.payload || {});
          sendGuardedPageCommandResult(sendResponse, {
            ok: result.ok !== false,
            result
          }, { action, tabId: null, poisonKey: null });
          return;
        }
        const tab = await findFlowTab(Number(message.payload?.tabId || sender?.tab?.id || runtimeState.activeTabId || 0) || undefined);
        if (!tab?.id) {
          sendResponse(createMessage(MessageType.PageCommandResult, {
            ok: false,
            error: "flow_tab_not_found"
          }));
          return;
        }
        const bridge = await ensureFlowBridge(tab.id);
        if (!bridge?.ok) {
          sendResponse(createMessage(MessageType.PageCommandResult, {
            ok: false,
            tabId: tab.id,
            url: tab.url,
            error: bridge?.error || "flow_bridge_not_ready"
          }));
          return;
        }
        const poisonKey = pageCommandPoisonKey(tab.id, action, message.payload || {});
        if (pageCommandPoisonCooldownActive(poisonKey)) {
          recordEvent({
            type: "bridge.page_command.poison_cooldown_active",
            action,
            tabId: tab.id
          });
          sendResponse(createMessage(MessageType.PageCommandResult, {
            ok: false,
            tabId: tab.id,
            url: tab.url,
            error: "PAGE_COMMAND_POISON_COOLDOWN",
            result: { ok: false, code: "PAGE_COMMAND_POISON_COOLDOWN", action }
          }));
          return;
        }
        const result = await sendPageCommand(message.payload || {}, tab.id);
        promoteFlowTabBinding(tab, { projectId: result?.projectId, href: result?.href || tab.url }, `page_command:${action || "unknown"}`);
        sendGuardedPageCommandResult(sendResponse, {
          ok: result?.ok !== false,
          tabId: tab.id,
          url: tab.url,
          result
        }, { action, tabId: tab.id, poisonKey });
      } catch (error) {
        recordEvent({
          type: "bridge.page_command.exception",
          action,
          error: String(error?.message || error || "page_command_failed")
        });
        try {
          sendResponse(createMessage(MessageType.PageCommandResult, {
            ok: false,
            error: String(error?.code || error?.message || error || "page_command_failed")
          }));
        } catch (_sendError) {
          // The channel is already gone or still oversized — nothing further
          // to do; the poison-cooldown/guard above prevents this from
          // repeating indefinitely for the same media on the next attempt.
        }
      }
    })();
    return true;
  }

  if (message.type === MessageType.PageEvent) {
    const event = message.payload || {};
    const promoted = sender?.tab?.id
      ? promoteFlowTabBinding(sender.tab, event, event.kind || event.type || "page_event")
      : null;
    if (promoted) {
      recordEvent({
        type: "runtime.flow_tab.event_seen",
        tabId: promoted.activeTabId,
        projectId: promoted.projectId,
        kind: event.kind || event.type || ""
      });
    }
    if (event.type === "flow_recaptcha") {
      recordEvent({
        type: "flow.recaptcha",
        action: event.action || "",
        source: event.source || "",
        ok: event.ok === true,
        preferDirect: event.preferDirect === true,
        forceFresh: event.forceFresh === true,
        durationMs: Number(event.durationMs || 0)
      });
    }
    if (event.type === "flow_generation_response") {
      applyFlowGenerationResponseEvent(event).catch((error) => {
        recordEvent({
          type: "queue.flow_generation_feed.error",
          error: String(error?.message || error || "flow_generation_feed_failed")
        });
      });
    }
    if (event.type === "dom_submit_stage") {
      recordEvent({
        type: "queue.dom.stage",
        taskId: event.taskId || "",
        mode: event.mode || "",
        stage: event.stage || "",
        ok: event.ok,
        error: event.error || "",
        refCount: event.refCount || 0,
        attached: event.attached || 0,
        matchedCount: event.matchedCount || 0,
        selector: event.selector || "",
        mediaIds: Array.isArray(event.mediaIds) ? event.mediaIds : [],
        serializedIds: Array.isArray(event.serializedIds) ? event.serializedIds : [],
          capturedResponseCount: event.capturedResponseCount || 0,
          stableCount: Number(event.stableCount || 0),
          softSettled: event.softSettled === true,
          strategy: event.strategy || "",
        reason: event.reason || "",
        requestedPrompt: event.requestedPrompt || "",
        persisted: event.persisted || "",
        modeOutcome: event.modeOutcome || null,
        settingsOutcome: event.settingsOutcome || null,
        searchTerms: Array.isArray(event.searchTerms) ? event.searchTerms : [],
        lastTerm: event.lastTerm || "",
        rowCount: Number(event.rowCount || 0),
        rowSample: Array.isArray(event.rowSample) ? event.rowSample.slice(0, 12) : [],
        candidateIds: Array.isArray(event.candidateIds) ? event.candidateIds : [],
        targetImageId: event.targetImageId || "",
        ingredientIds: Array.isArray(event.ingredientIds) ? event.ingredientIds : [],
        requestSerializedIds: Array.isArray(event.requestSerializedIds) ? event.requestSerializedIds : [],
        finalIngredients: Array.isArray(event.finalIngredients) ? event.finalIngredients.slice(0, 12) : [],
        composerChipBaseline: Number(event.composerChipBaseline || 0),
        composerChipCount: Number(event.composerChipCount || 0),
        composerChipDelta: Number(event.composerChipDelta || 0),
	        nativeComposerChipProof: event.nativeComposerChipProof === true,
	        nativeFrameSlotProof: event.nativeFrameSlotProof === true,
	        visibleFrameSlotCount: Number(event.visibleFrameSlotCount || 0),
        missing: Array.isArray(event.missing) ? event.missing : [],
        wrongIngredientTypes: Array.isArray(event.wrongIngredientTypes) ? event.wrongIngredientTypes : [],
        uploadedMediaIds: Array.isArray(event.uploadedMediaIds) ? event.uploadedMediaIds : [],
        assetImageIds: Array.isArray(event.assetImageIds) ? event.assetImageIds : [],
        uploadedMediaId: event.uploadedMediaId || "",
        confirmedImageId: event.confirmedImageId || "",
        candidateId: event.candidateId || "",
        rowImageId: event.rowImageId || "",
        fileName: event.fileName || "",
        progress: event.progress || "",
        found: event.found,
        attempt: event.attempt || 0,
        source: event.source || "",
        text: event.text || "",
        rowText: event.rowText || "",
        candidates: Array.isArray(event.candidates) ? event.candidates.slice(0, 8) : [],
        selectedIds: Array.isArray(event.selectedIds) ? event.selectedIds.slice(0, 12) : [],
        targetIds: Array.isArray(event.targetIds) ? event.targetIds.slice(0, 12) : [],
        selectedText: event.selectedText || "",
        selectedHasVideo: event.selectedHasVideo,
        selectedHasImage: event.selectedHasImage,
        selectionOk: event.selectionOk,
        selectionError: event.selectionError || "",
        idMatched: event.idMatched,
        nameMatched: event.nameMatched,
        cardAttachOk: event.cardAttachOk,
        cardAttachError: event.cardAttachError || "",
        typeRepairOk: event.typeRepairOk,
        promptAttachOk: event.promptAttachOk,
        settledIds: Array.isArray(event.settledIds) ? event.settledIds : [],
	        composerSnapshot: event.composerSnapshot && typeof event.composerSnapshot === "object" ? event.composerSnapshot : null,
	        strictAssetRowMatch: event.strictAssetRowMatch === true,
	        nativeVisibleSlotAttached: event.nativeVisibleSlotAttached === true,
	        slotVisible: event.slotVisible,
	        targetMatched: event.targetMatched,
	        slotMediaIds: Array.isArray(event.slotMediaIds) ? event.slotMediaIds.slice(0, 8) : [],
	        retainedSlotVisible: event.retainedSlotVisible,
	        retainedTargetMatched: event.retainedTargetMatched,
	        retainedSlotMediaIds: Array.isArray(event.retainedSlotMediaIds) ? event.retainedSlotMediaIds.slice(0, 8) : [],
	        selectableAssetResolution: event.selectableAssetResolution || null,
	        domTrace: event.domTrace || null
	      });
    }
    sendResponse(createMessage(MessageType.PageEvent, { ok: true }));
    return true;
  }

  if (message.type === MessageType.AgentBatchSubmit) {
    (async () => {
      try {
        await queueReady;
        const payload = message.payload || {};
        const result = await submitAgentBatchesFromBridge(payload, {
          type: "agent.batch.submit",
          payload,
          source: "sidepanel",
          senderTabId: sender?.tab?.id || null
        });
        sendResponse(createMessage(MessageType.AgentBatchSubmit, {
          ok: result.ok === true,
          result,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentBatchSubmit, {
          ok: false,
          code: compactString(error?.code || ""),
          error: String(error?.message || error || "agent_batch_submit_failed"),
          details: error?.details || error?.payload || null,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.AgentPromptSubmit) {
    (async () => {
      try {
        await queueReady;
        const payload = message.payload || {};
        const result = await submitAgentPromptFromBridge(payload, {
          type: "agent.prompt.submit",
          payload,
          source: "sidepanel",
          senderTabId: sender?.tab?.id || null
        });
        sendResponse(createMessage(MessageType.AgentPromptSubmit, {
          ok: true,
          result,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentPromptSubmit, {
          ok: false,
          code: compactString(error?.code || ""),
          error: String(error?.message || error || "agent_prompt_submit_failed"),
          details: error?.details || error?.payload || null,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.AgentContextGet) {
    (async () => {
      try {
        await queueReady;
        const result = await getAgentScreenContextFromBridge(message.payload || {});
        sendResponse(createMessage(MessageType.AgentContextGet, {
          ok: true,
          result,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentContextGet, {
          ok: false,
          code: compactString(error?.code || ""),
          error: String(error?.message || error || "agent_context_failed"),
          details: error?.details || error?.payload || null
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.AgentCreditsConfirm) {
    (async () => {
      try {
        await queueReady;
        const result = await confirmAgentCreditsFromBridge(message.payload || {});
        sendResponse(createMessage(MessageType.AgentCreditsConfirm, {
          ok: true,
          result,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentCreditsConfirm, {
          ok: false,
          code: compactString(error?.code || ""),
          error: String(error?.message || error || "agent_credit_confirmation_failed"),
          details: error?.details || error?.payload || null
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.AgentReconcile) {
    (async () => {
      try {
        await queueReady;
        const payload = message.payload || {};
        const result = await getAgentProjectMetadata(payload);
        sendResponse(createMessage(MessageType.AgentReconcile, {
          ok: true,
          result,
          expectedManifest: result.expectedManifest || null,
          reconciliation: result.reconciliation || null,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.AgentReconcile, {
          ok: false,
          code: compactString(error?.code || ""),
          error: String(error?.message || error || "agent_reconcile_failed"),
          details: error?.details || error?.payload || null,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.MediaUpload) {
    (async () => {
      try {
        const tab = await findFlowTab(Number(message.payload?.tabId || sender?.tab?.id || 0) || undefined);
        if (!tab?.id) throw new Error("flow_tab_not_found");
        let projectId = compactString(message.payload?.projectId);
        if (!projectId) {
          const page = await sendPageCommand({
            action: "projectState",
            timeoutMs: 10000
          }, tab.id);
          projectId = compactString(page.projectId);
        }
        if (!projectId) throw new Error("missing_project_id");

        const files = Array.isArray(message.payload?.files) ? message.payload.files : [];
        const flowClient = createFlowClientForTab(tab.id);
        const uploads = [];
        for (const file of files) {
          const fileName = compactString(file?.fileName) || "reference.png";
          try {
            recordEvent({
              type: "media.upload.start",
              fileName,
              mimeType: compactString(file?.mimeType) || "image/png",
              hidden: file?.isHidden === true
            });
            const mimeType = compactString(file?.mimeType) || "image/png";
            const isVideo = file?.kind === "video" || /^video\//i.test(mimeType);
            const result = isVideo
              ? await flowClient.uploadVideo({
                  projectId,
                  dataUrl: compactString(file?.dataUrl),
                  mimeType,
                  fileName
                })
              : await flowClient.uploadImage({
                  projectId,
                  imageBytes: compactString(file?.imageBytes),
                  mimeType,
                  fileName,
                  isHidden: file?.isHidden === true
                });
            const mediaId = result.mediaId || result.mediaIds?.[0] || "";
            const ok = result.ok === true && Boolean(mediaId);
            uploads.push({
              ok,
              fileName,
              mediaId,
              workflowId: compactString(result.workflowId),
              videoWidth: Number(result.videoWidth || 0),
              videoHeight: Number(result.videoHeight || 0),
              durationSeconds: Number(result.durationSeconds || 0),
              status: result.status,
              error: ok ? "" : result.statusText || result.error || "missing_media_id"
            });
            recordEvent({
              type: ok ? "media.upload" : "media.upload.error",
              fileName,
              mediaId,
              status: result.status
            });
          } catch (error) {
            uploads.push({
              ok: false,
              fileName,
              mediaId: "",
              status: 0,
              error: String(error?.message || error || "upload_failed")
            });
            recordEvent({
              type: "media.upload.error",
              fileName,
              error: String(error?.message || error || "upload_failed")
            });
          }
        }

        sendResponse(createMessage(MessageType.MediaUpload, {
          ok: uploads.every((upload) => upload.ok),
          projectId,
          uploads,
          mediaIds: mediaIdsFrom(uploads.map((upload) => upload.mediaId)),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        sendResponse(createMessage(MessageType.MediaUpload, {
          ok: false,
          error: String(error?.message || error || "media_upload_failed"),
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.GalleryRefresh) {
    (async () => {
      try {
        await queueReady;
        const scanResult = await scanFlowGallery(message.payload?.preferredTabId, {
          auto: Boolean(message.payload?.auto),
          lightweight: Boolean(message.payload?.lightweight),
          fullScroll: message.payload?.fullScroll
        });
        sendResponse(createMessage(MessageType.GalleryRefresh, {
          ok: scanResult.ok,
          error: scanResult.error || "",
          gallery: scanResult.gallery,
          scan: scanResult.scan || null,
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      } catch (error) {
        const messageText = String(error?.message || error || "gallery_refresh_failed");
        recordEvent({ type: "gallery.refresh.error", error: messageText });
        sendResponse(createMessage(MessageType.GalleryRefresh, {
          ok: false,
          error: messageText,
          gallery: galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger"),
          scan: { ok: false, error: messageText },
          queue: queueState(),
          events: runtimeState.events.slice(-20)
        }));
      }
    })();
    return true;
  }

  if (message.type === MessageType.MediaDownload) {
    (async () => {
      await queueReady;
      const projectId = compactString(message.payload?.projectId) || runtimeState.lastGalleryProjectId;
      const gallery = galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", projectId);
      const ownedGalleryItems = applyAgentOwnedDownloadMetadata(
        gallery.items,
        message.payload?.ownedOutputs || [],
        message.payload?.agentRunId || ""
      );
      const plans = planMediaDownloads(ownedGalleryItems, {
        selectedIds: message.payload?.selectedIds || [],
        folder: message.payload?.folder || "Auto-Flow-01",
        imageResolution: message.payload?.imageResolution || "1k",
        videoResolution: message.payload?.videoResolution || "720p",
        filenameStyle: message.payload?.filenameStyle || "",
        filenameTemplatePrefix: message.payload?.filenameTemplatePrefix || "",
        filenameTemplateIndex: message.payload?.filenameTemplateIndex || "",
        filenameTemplatePromptPart: message.payload?.filenameTemplatePromptPart || "",
        filenameTemplateDate: message.payload?.filenameTemplateDate || "",
        filenameTemplateSuffix: message.payload?.filenameTemplateSuffix || "",
        filenameTemplateSeparator: message.payload?.filenameTemplateSeparator || "",
        allowPortraitVideoUpscale: message.payload?.allowPortraitVideoUpscale === true,
        allowDuplicateTargetSuffix: message.payload?.allowDuplicateTargetSuffix === true,
        reservedArtifactKeys: [...downloadReservations.artifacts.keys()],
        reservedTargetPaths: [...downloadReservations.targets.keys()]
      });
      const downloads = await executeDownloadPlans(plans, "manual");
      const reconciledDownloads = reconcileQueueWithDownloadResults(downloads);
      if (reconciledDownloads.length) await persistQueueState();
      const nextGallery = galleryState(runtimeState.lastGalleryItems || [], runtimeState.lastGalleryItems?.length ? "flow-dom+queue-ledger" : "queue-ledger", projectId);
      sendResponse(createMessage(MessageType.MediaDownload, {
        ok: downloads.every((download) => download.ok || download.skipped),
        downloads,
        gallery: nextGallery,
        queue: queueState(),
        reconciledDownloads,
        events: runtimeState.events.slice(-20)
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueAddJob) {
    (async () => {
      await queueReady;
      const jobs = Array.isArray(message.payload?.jobs) && message.payload.jobs.length
        ? message.payload.jobs
        : (Array.isArray(message.payload?.prompts)
            ? message.payload.prompts
            : String(message.payload?.prompts || "").split(/\n+/)
          ).map((prompt) => ({ prompt }));
      const fallbackJobId = compactString(message.payload?.jobId) || crypto.randomUUID();
      const fallbackJobPromptCount = Number(message.payload?.jobPromptCount || jobs.length || 1);
      const fallbackJobTitle = compactString(message.payload?.jobTitle);
      let added = 0;
      for (const job of jobs) {
        const prompt = compactString(job?.prompt);
        if (!prompt) continue;
        const jobIndex = Number.isFinite(Number(job?.jobIndex)) ? Number(job.jobIndex) : added;
        const jobId = compactString(job?.jobId) || fallbackJobId;
        const jobPromptCount = Number(job?.jobPromptCount || fallbackJobPromptCount || jobs.length || 1);
        const jobTitle = compactString(job?.jobTitle) || fallbackJobTitle;
        const refInputs = refInputsFrom(job?.refInputs || message.payload?.refInputs);
        const inputMediaIds = mediaIdsFrom(job?.mediaIds || message.payload?.mediaIds || refInputs.map((ref) => ref.mediaId));
        const startRefInput = normalizeRefInput(job?.startRefInput)
          || refInputs.find((ref) => ref.role === "startFrameRef")
          || null;
        const endRefInput = normalizeRefInput(job?.endRefInput)
          || refInputs.find((ref) => ref.role === "endFrameRef")
          || null;
        const sourceRefInput = normalizeRefInput(job?.sourceRefInput)
          || refInputs.find((ref) => ref.role === "sourceVideo")
          || null;
        const mediaRefScope = [
          ...refInputs,
          startRefInput,
          endRefInput,
          sourceRefInput
        ].filter(Boolean);
        const flowInputMediaIds = inputMediaIds.filter((mediaId) => firstFlowMediaId([mediaId], mediaRefScope));
        const startMediaId = firstFlowMediaId([job?.startMediaId, startRefInput?.mediaId, flowInputMediaIds[0]], mediaRefScope);
        const endMediaId = firstFlowMediaId([job?.endMediaId, endRefInput?.mediaId], mediaRefScope);
        const sourceMediaId = firstFlowMediaId([
          job?.sourceMediaId,
          job?.sourceVideoMediaId,
          sourceRefInput?.mediaId
        ], mediaRefScope);
        const taskMode = compactString(job?.retryOriginalMode || job?.mode) || compactString(message.payload?.mode) || "text-to-image";
        ledger.addTask({
          id: crypto.randomUUID(),
          jobId,
          jobIndex,
          jobPromptCount,
          jobTitle,
          mode: taskMode,
          prompt,
          reason: compactString(job?.reason || message.payload?.reason),
          sourcePrompt: compactString(job?.sourcePrompt),
          imagePrompt: compactString(job?.imagePrompt),
          videoPrompt: compactString(job?.videoPrompt),
          sceneTag: compactString(job?.sceneTag),
          projectId: compactString(job?.projectId) || compactString(message.payload?.projectId),
          model: compactString(job?.model) || compactString(message.payload?.model) || "default",
          aspectRatio: compactString(job?.aspectRatio) || compactString(message.payload?.aspectRatio) || "landscape",
          repeatCount: Number(job?.repeatCount || message.payload?.repeatCount || 1),
          videoLength: compactString(job?.videoLength || message.payload?.videoLength || "8"),
          videoDurationSeconds: compactString(job?.videoDurationSeconds || job?.videoLength || message.payload?.videoLength || "8"),
          requestedVideoLength: compactString(job?.requestedVideoLength || message.payload?.requestedVideoLength || job?.sidepanelVideoLength || message.payload?.sidepanelVideoLength),
          sidepanelVideoLength: compactString(job?.sidepanelVideoLength || message.payload?.sidepanelVideoLength),
          preflightDuration: compactString(job?.preflightDuration || message.payload?.preflightDuration || job?.videoLength || message.payload?.videoLength),
          buildJobsDuration: compactString(job?.buildJobsDuration || message.payload?.buildJobsDuration || job?.videoLength || message.payload?.videoLength),
          payloadDuration: compactString(job?.payloadDuration || message.payload?.payloadDuration || job?.videoLength || message.payload?.videoLength),
          durationFallbackReason: compactString(job?.durationFallbackReason || message.payload?.durationFallbackReason),
          requestedMode: compactString(job?.requestedMode || message.payload?.requestedMode || taskMode || message.payload?.mode),
          normalizedRuntimeMode: compactString(job?.normalizedRuntimeMode || message.payload?.normalizedRuntimeMode || taskMode || message.payload?.mode),
          buildJobsMode: compactString(job?.buildJobsMode || message.payload?.buildJobsMode || taskMode || message.payload?.mode),
          retryOriginalMode: compactString(job?.retryOriginalMode || message.payload?.retryOriginalMode || taskMode),
          retrySurface: compactString(job?.retrySurface || message.payload?.retrySurface),
          retryInputRoles: Array.isArray(job?.retryInputRoles) ? [...job.retryInputRoles] : (Array.isArray(message.payload?.retryInputRoles) ? [...message.payload.retryInputRoles] : []),
          retryFrameSlots: Array.isArray(job?.retryFrameSlots) ? [...job.retryFrameSlots] : (Array.isArray(message.payload?.retryFrameSlots) ? [...message.payload.retryFrameSlots] : []),
          retryMaxInputs: Number.isFinite(Number(job?.retryMaxInputs ?? message.payload?.retryMaxInputs)) ? Number(job?.retryMaxInputs ?? message.payload?.retryMaxInputs) : null,
          retryPromptFirst: job?.retryPromptFirst === true || message.payload?.retryPromptFirst === true,
          attachedFrameRefs: Array.isArray(job?.attachedFrameRefs)
            ? job.attachedFrameRefs.map((ref) => ({
                role: compactString(ref?.role),
                mediaId: compactString(ref?.mediaId),
                blobStoreId: compactString(ref?.blobStoreId),
                hasDataUrl: ref?.hasDataUrl === true
              }))
            : [],
          submitPath: compactString(job?.submitPath) || compactString(message.payload?.submitPath),
          characterPreflight: job?.characterPreflight && typeof job.characterPreflight === "object"
            ? { ...job.characterPreflight }
            : (message.payload?.characterPreflight && typeof message.payload.characterPreflight === "object" ? { ...message.payload.characterPreflight } : null),
          nativeCharacterHandleMap: job?.nativeCharacterHandleMap && typeof job.nativeCharacterHandleMap === "object"
            ? { ...job.nativeCharacterHandleMap }
            : (message.payload?.nativeCharacterHandleMap && typeof message.payload.nativeCharacterHandleMap === "object" ? { ...message.payload.nativeCharacterHandleMap } : null),
          autoRetryFailedUntilZero: job?.autoRetryFailedUntilZero === true || message.payload?.autoRetryFailedUntilZero === true,
          referenceChainMode: compactString(job?.referenceChainMode),
          referenceChainSeed: job?.referenceChainSeed === true,
          referenceChainIndex: Number.isFinite(Number(job?.referenceChainIndex)) ? Number(job.referenceChainIndex) : null,
          download: job?.download && typeof job.download === "object"
            ? { ...job.download }
            : (message.payload?.download && typeof message.payload.download === "object" ? { ...message.payload.download } : null),
          mediaIds: [],
          refMediaIds: flowInputMediaIds,
          refInputs,
          startRefInput,
          endRefInput,
          sourceRefInput,
          startMediaId,
          endMediaId,
          sourceMediaId,
          sourceVideoId: compactString(job?.sourceVideoId || job?.sourceRefInput?.id),
          sourceVideoFileName: compactString(job?.sourceVideoFileName || job?.sourceRefInput?.fileName || job?.sourceRefInput?.name),
          sourceVideoMediaId: sourceMediaId,
          sourceWorkflowId: compactString(job?.sourceWorkflowId),
          startFrameIndex: Number.isFinite(Number(job?.startFrameIndex)) ? Number(job.startFrameIndex) : 0,
          endFrameIndex: Number.isFinite(Number(job?.endFrameIndex)) ? Number(job.endFrameIndex) : 240,
          sourceDurationSeconds: Number.isFinite(Number(job?.sourceDurationSeconds)) ? Number(job.sourceDurationSeconds) : 10
        });
        added += 1;
      }
      await persistQueueState();
      sendResponse(createMessage(MessageType.QueueAddJob, {
        ok: true,
        added,
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState()
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueStart) {
    (async () => {
      await queueReady;
      captureAuthEnvironment(message.payload || {});
      const next = scheduler.nextPendingTask();
      if (!next) {
        const summary = activeTaskSummary();
        if (hasActiveTasks() && !runtimeState.queueRunning) {
          runQueueUntilIdle(queuePreferredFlowTabId(message, sender));
        }
        sendResponse(createMessage(MessageType.QueueStart, {
          ok: true,
          queueRunning: runtimeState.queueRunning,
          startedTaskId: "",
          queue: queueState(),
          activeSummary: summary,
          auth: runtimeState.auth
        }));
        return;
      }
      const access = await validateQueueStartAccess(next, { freshStart: true });
      if (!access.allowed) {
        const blockReason = access.message || access.reason || access.error || "license_required";
        scheduler.markBlocked(next.id, blockReason);
        const auth = await updateAuthState();
        await persistQueueState();
        sendResponse(createMessage(MessageType.QueueStart, {
          ok: false,
          error: blockReason,
          access,
          queueRunning: runtimeState.queueRunning,
          startedTaskId: "",
          queue: queueState(),
          auth
        }));
        return;
      }
      if (!runtimeState.queueRunning) {
        runQueueUntilIdle(queuePreferredFlowTabId(message, sender));
      }
      sendResponse(createMessage(MessageType.QueueStart, {
        ok: true,
        access,
        queueRunning: runtimeState.queueRunning,
        startedTaskId: next?.id || "",
        queue: queueState(),
        auth: runtimeState.auth
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueResume) {
    (async () => {
      await queueReady;
      captureAuthEnvironment(message.payload || {});
      const browserModeSwitch = message.payload?.switchApiFirstQuotaSuspectedToDom === true
        ? await switchApiFirstRowsToBrowserMode({
            sourceTaskId: message.payload?.sourceTaskId || "",
            recoveryUiProbe: message.payload?.recoveryUiProbe || {}
          })
        : { switched: 0, switchedIds: [], requeuedIds: [], preservedCompletedIds: [] };
      if (browserModeSwitch.skippedBecauseModelAccess === true) {
        await persistQueueState();
        sendResponse(createMessage(MessageType.QueueResume, {
          ok: false,
          error: browserModeSwitch.error || "model_access_denied_hard_stop",
          recoverySkippedBecauseModelAccess: true,
          resumed: 0,
          switchedPendingRowsToDom: 0,
          switchedPendingRowIds: [],
          userConfirmedSwitchToDom: false,
          queueRunning: runtimeState.queueRunning,
          queue: queueState(),
          gallery: galleryState(),
          events: runtimeState.events.slice(-20)
        }));
        return;
      }
      const pendingBeforeResume = scheduler.nextPendingTask();
      const next = pendingBeforeResume || ledger.listTasks().find((task) => String(task.status || "").toLowerCase() === "blocked");
      if (next) {
        const access = await validateQueueStartAccess(next);
        if (!access.allowed) {
          const blockReason = access.message || access.reason || access.error || "license_required";
          scheduler.markBlocked(next.id, blockReason);
          const auth = await updateAuthState();
          await persistQueueState();
          sendResponse(createMessage(MessageType.QueueResume, {
            ok: false,
            error: blockReason,
            access,
            resumed: 0,
            switchedPendingRowsToDom: browserModeSwitch.switched,
            switchedPendingRowIds: browserModeSwitch.switchedIds,
            requeuedRowIds: browserModeSwitch.requeuedIds || [],
            preservedCompletedIds: browserModeSwitch.preservedCompletedIds || [],
            userConfirmedSwitchToDom: message.payload?.switchApiFirstQuotaSuspectedToDom === true,
            browserModeResumeStartedAt: browserModeSwitch.patches?.[0]?.patch?.browserModeResumeStartedAt || "",
            queueRunnerAliveBeforeSwitch: browserModeSwitch.queueRunnerAliveBeforeSwitch === true,
            queueRunnerAliveAfterSwitch: runtimeState.queueRunning === true,
            staleSubmittingDetected: browserModeSwitch.staleSubmittingDetected === true,
            staleSubmittingTaskId: browserModeSwitch.staleSubmittingTaskId || "",
            staleSubmittingAgeMs: Number(browserModeSwitch.staleSubmittingAgeMs || 0),
            staleSubmittingResolution: browserModeSwitch.staleSubmittingResolution || "",
            recoveryActionError: blockReason,
            queueRunning: runtimeState.queueRunning,
            queue: queueState(),
            gallery: galleryState(),
            auth,
            events: runtimeState.events.slice(-20)
          }));
          return;
        }
      }
      const resumed = resumeBlockedQueueTasks({
        ...(message.payload || {}),
        browserModeTaskId: message.payload?.sourceTaskId || message.payload?.browserModeTaskId || "",
        onlyBrowserModeRecovery: message.payload?.switchApiFirstQuotaSuspectedToDom === true || message.payload?.onlyBrowserModeRecovery === true
      });
      const pendingAfterResume = scheduler.nextPendingTask();
      const pending = ledger.listTasks().filter((task) => String(task.status || "").toLowerCase() === "pending").length;
      await persistQueueState();
      recordEvent({ type: "queue.resume_blocked", resumed, pending });
      let startedRunner = false;
      if ((resumed > 0 || pendingAfterResume) && !runtimeState.queueRunning) {
        runQueueUntilIdle(queuePreferredFlowTabId(message, sender));
        startedRunner = true;
      }
      if (message.payload?.switchApiFirstQuotaSuspectedToDom === true && Array.isArray(browserModeSwitch.switchedIds)) {
        const completedAt = new Date().toISOString();
        for (const taskId of browserModeSwitch.switchedIds) {
          if (!ledger.getTask(taskId)) continue;
          ledger.updateTask(taskId, {
            recoveryContinueActionCompletedAt: completedAt,
            queueRunnerAliveAfterSwitch: runtimeState.queueRunning === true || startedRunner
          });
        }
        await persistQueueState();
      }
      sendResponse(createMessage(MessageType.QueueResume, {
        ok: true,
        resumed,
        pending,
        switchedPendingRowsToDom: browserModeSwitch.switched,
        switchedPendingRowIds: browserModeSwitch.switchedIds,
        requeuedRowIds: browserModeSwitch.requeuedIds || [],
        preservedCompletedIds: browserModeSwitch.preservedCompletedIds || [],
        userConfirmedSwitchToDom: message.payload?.switchApiFirstQuotaSuspectedToDom === true,
        browserModeResumeStartedAt: browserModeSwitch.patches?.[0]?.patch?.browserModeResumeStartedAt || "",
        completedBeforeSwitch: Number(browserModeSwitch.completedBeforeSwitch || 0),
        pendingBeforeSwitch: Number(browserModeSwitch.pendingBeforeSwitch || 0),
        completedAfterSwitch: Number(browserModeSwitch.completedAfterSwitch || 0),
        pendingAfterSwitch: Number(browserModeSwitch.pendingAfterSwitch || pending),
        queueRunnerAliveBeforeSwitch: browserModeSwitch.queueRunnerAliveBeforeSwitch === true,
        queueRunnerAliveAfterSwitch: runtimeState.queueRunning === true || startedRunner,
        staleSubmittingDetected: browserModeSwitch.staleSubmittingDetected === true,
        staleSubmittingTaskId: browserModeSwitch.staleSubmittingTaskId || "",
        staleSubmittingAgeMs: Number(browserModeSwitch.staleSubmittingAgeMs || 0),
        staleSubmittingResolution: browserModeSwitch.staleSubmittingResolution || "",
        recoveryActionError: browserModeSwitch.recoveryActionError || "",
        startedPending: Boolean(pendingAfterResume),
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState(),
        events: runtimeState.events.slice(-20)
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueRecoveryAction) {
    (async () => {
      await queueReady;
      const task = await recordRecoveryTaskAction(
        message.payload?.taskId || "",
        message.payload?.action || "",
        { recoveryModalKind: message.payload?.recoveryModalKind || "" }
      );
      sendResponse(createMessage(MessageType.QueueRecoveryAction, {
        ok: Boolean(task),
        taskId: task?.id || message.payload?.taskId || "",
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState(),
        events: runtimeState.events.slice(-20)
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueSkipTask) {
    (async () => {
      await queueReady;
      const result = await skipBlockedQueueTask(message.payload?.taskId || "", {
        reason: message.payload?.reason || "user_skipped_current_row",
        recoveryModalKind: message.payload?.recoveryModalKind || ""
      });
      let startedRunner = false;
      if (result.ok && message.payload?.continuePending === true && scheduler.nextPendingTask() && !runtimeState.queueRunning) {
        runQueueUntilIdle(queuePreferredFlowTabId(message, sender));
        startedRunner = true;
      }
      sendResponse(createMessage(MessageType.QueueSkipTask, {
        ok: result.ok,
        error: result.error || "",
        skippedTaskId: result.skipped?.id || "",
        startedPending: startedRunner,
        queueRunning: runtimeState.queueRunning || startedRunner,
        queue: queueState(),
        gallery: galleryState(),
        events: runtimeState.events.slice(-20)
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueStop) {
    runtimeState.queueRunToken = Number(runtimeState.queueRunToken || 0) + 1;
    runtimeState.queueRunning = false;
    recordEvent({ type: "queue.stop.request", runToken: runtimeState.queueRunToken });
    (async () => {
      await queueReady;
      await releaseDebuggerSessions("queue_stop", recordDebuggerTrace);
      await persistQueueState();
      sendResponse(createMessage(MessageType.QueueStop, {
        ok: true,
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState()
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueClear) {
    (async () => {
      await queueReady;
      if (!runtimeState.queueRunning) {
        runtimeState.queueRunToken = Number(runtimeState.queueRunToken || 0) + 1;
        ledger.clearTasks();
        recordEvent({ type: "queue.clear", runToken: runtimeState.queueRunToken });
      }
      await persistQueueState();
      sendResponse(createMessage(MessageType.QueueClear, {
        ok: true,
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState()
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueueRemove) {
    (async () => {
      await queueReady;
      const targetId = compactString(message.payload?.id || message.payload?.jobId);
      const removed = targetId && !runtimeState.queueRunning
        ? ledger.pruneTasks((task) => task.id === targetId || task.jobId === targetId)
        : 0;
      await persistQueueState();
      sendResponse(createMessage(MessageType.QueueRemove, {
        ok: true,
        removed,
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState()
      }));
    })();
    return true;
  }

  if (message.type === MessageType.QueuePrune) {
    (async () => {
      await queueReady;
      const statuses = new Set((message.payload?.statuses || []).map((status) => String(status || "").toLowerCase()));
      const removed = ledger.pruneTasks((task) => statuses.has(String(task.status || "").toLowerCase()));
      await persistQueueState();
      sendResponse(createMessage(MessageType.QueuePrune, {
        ok: true,
        removed,
        queueRunning: runtimeState.queueRunning,
        queue: queueState(),
        gallery: galleryState()
      }));
    })();
    return true;
  }

  sendResponse(createMessage(message.type, { ok: true, accepted: true }));
  return true;
});
