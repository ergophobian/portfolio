import {
  AGENT_BRIDGE_COMMAND_TYPES,
  AGENT_BRIDGE_VERSION,
  createAgentBridgeErrorResponse,
  createAgentBridgeRequest,
  createAgentBridgeSuccessResponse,
  normalizeBridgeError,
  validateAgentBridgeRequest,
  validateAgentBridgeResponse
} from "../core/agent/agent-bridge-protocol.js";
import { planAgentRunArtifacts } from "../core/agent/agent-run-artifacts.js";
import { BROKER_HEALTH_STATES, classifyBrokerHealth, normalizeBrokerHealthState } from "../core/agent/broker-health.js";

export const AGENT_BRIDGE_NATIVE_HOST = "com.autoflow.agent";
export const AGENT_BRIDGE_ENABLED_STORAGE_KEY = "autoflow-agent-bridge-enabled";
export const SIDEPANEL_STATE_STORAGE_KEY = "autoflow-10767-rebuild-sidepanel-state";
export const AGENT_BRIDGE_STORAGE_KEYS = Object.freeze([
  AGENT_BRIDGE_ENABLED_STORAGE_KEY,
  "autoflow-agent-bridge-settings",
  SIDEPANEL_STATE_STORAGE_KEY
]);

export function createNativeBridge(options = {}) {
  let enabled = options.enabled === true;
  const handlers = {
    ...createNativeBridgeHandlers(options.runtime || {}),
    ...(options.handlers || {})
  };

  const bridge = {
    isEnabled() {
      return enabled;
    },
    setEnabled(nextEnabled) {
      enabled = nextEnabled === true;
      return enabled;
    },
    supportedCommands() {
      return [...AGENT_BRIDGE_COMMAND_TYPES];
    },
    async handleMessage(message, context = {}) {
      const validationInput = normalizeBridgeRequestForValidation(message);
      const validation = validateAgentBridgeRequest(validationInput);
      if (!validation.ok) {
        return createAgentBridgeErrorResponse(validationInput || message, validation.error);
      }

      const request = validation.request;
      if (!enabled) {
        return createAgentBridgeErrorResponse(request, {
          code: "BRIDGE_DISABLED",
          message: "native bridge is disabled"
        });
      }

      const handler = handlers[request.type];
      if (typeof handler !== "function") {
        return createAgentBridgeErrorResponse(request, {
          code: "HANDLER_NOT_CONFIGURED",
          message: `native bridge handler not configured for ${request.type}`
        });
      }

      try {
        const result = await handler(request, { bridge, context });
        const responseValidation = validateAgentBridgeResponse(result);
        if (responseValidation.ok) return result;
        return createAgentBridgeSuccessResponse(request, result || {});
      } catch (error) {
        return createAgentBridgeErrorResponse(request, normalizeBridgeError({
          code: error?.code || "BRIDGE_HANDLER_FAILED",
          message: error?.message || String(error || "native bridge handler failed"),
          details: error?.details
        }));
      }
    },
    handleRequest(message, context = {}) {
      return bridge.handleMessage(message, context);
    }
  };

  return bridge;
}

export function createNativeBridgeHandlers(runtime = {}) {
  const handlers = Object.fromEntries(
    AGENT_BRIDGE_COMMAND_TYPES.map((type) => [type, async (request) => bridgeHandlerUnavailable(request)])
  );

  handlers["status.get"] = async (_request, { bridge, context } = {}) => {
    const status = typeof runtime.getStatus === "function"
      ? await runtime.getStatus()
      : {};
    const extensionId = compactString(status.extensionId || context?.extensionId || globalThis.chrome?.runtime?.id || "");
    const runtimeStatus = normalizeRuntimeStatus(status.runtime || status);
    const project = normalizeProjectStatus(status.project || status.flowProject || null, runtimeStatus);
    const auth = sanitizeAuthSummary(status.auth || status.license || null);
    return {
      bridgeEnabled: Boolean(bridge?.isEnabled?.()),
      bridge: {
        enabled: Boolean(bridge?.isEnabled?.()),
        implementation: "service_worker",
        nativeHostConnected: context?.nativeHostConnected === true,
        nativeHostName: compactString(context?.nativeHostName || context?.hostName || AGENT_BRIDGE_NATIVE_HOST),
        bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
        supportedCommands: [...AGENT_BRIDGE_COMMAND_TYPES]
      },
      extension: {
        id: extensionId,
        present: Boolean(extensionId),
        version: compactString(globalThis.chrome?.runtime?.getManifest?.()?.version || "")
      },
      runtime: runtimeStatus,
      connected: runtimeStatus.connected === true,
      activeTabId: runtimeStatus.activeTabId,
      projectId: runtimeStatus.projectId,
      project,
      auth,
      supportedCommands: [...AGENT_BRIDGE_COMMAND_TYPES]
    };
  };

  handlers["bridge.ws.refresh"] = async (request) => {
    if (typeof runtime.refreshWsBroker !== "function") {
      throw bridgeError("WS_BROKER_REFRESH_UNAVAILABLE", "WS broker refresh is not available from this bridge runtime.");
    }
    return runtime.refreshWsBroker(request.payload || {}, request);
  };

  handlers["agent.tab.connect"] = async (request) => {
    if (typeof runtime.connectThisFlowTab !== "function") {
      throw bridgeError("FLOW_TAB_CONNECT_UNAVAILABLE", "Connecting this Flow tab is not available from this bridge runtime.");
    }
    return runtime.connectThisFlowTab(request.payload || {}, request);
  };

  handlers["agent.context.get"] = async (request) => {
    if (typeof runtime.getAgentContext !== "function") {
      throw bridgeError("AGENT_CONTEXT_UNAVAILABLE", "Live Agent screen context is not available from this bridge runtime.");
    }
    return runtime.getAgentContext(request.payload || {}, request);
  };

  handlers["flow.tabs.list"] = async (request) => {
    if (typeof runtime.listFlowTabs !== "function") {
      throw bridgeError("FLOW_TABS_UNAVAILABLE", "Flow tab inventory is not available from this bridge runtime.");
    }
    return runtime.listFlowTabs(request.payload || {}, request);
  };

  handlers["lane.indicator.set"] = async (request) => {
    if (typeof runtime.setLaneIndicator !== "function") {
      throw bridgeError("LANE_INDICATOR_UNAVAILABLE", "Lane tab indicator is not available from this bridge runtime.");
    }
    return runtime.setLaneIndicator(request.payload || {}, request);
  };

  handlers["agent.screenshot.get"] = async (request) => {
    if (typeof runtime.getAgentScreenshot !== "function") {
      throw bridgeError("AGENT_SCREENSHOT_UNAVAILABLE", "Live Agent screenshot capture is not available from this bridge runtime.");
    }
    return runtime.getAgentScreenshot(request.payload || {}, request);
  };

  handlers["pair.start"] = async (request) => {
    if (typeof runtime.approvePairing !== "function") {
      throw bridgeError(
        "PAIRING_APPROVAL_REQUIRED",
        "Open Auto Flow and click Pair before starting CLI pairing."
      );
    }
    const approval = await runtime.approvePairing(request.payload || {}, request);
    if (approval?.approved === true) {
      return {
        approved: true,
        clientName: compactString(request.payload?.clientName || ""),
        expiresAt: compactString(approval.expiresAt || ""),
        source: compactString(approval.source || "sidepanel")
      };
    }
    throw bridgeError(
      compactString(approval?.code || "") || "PAIRING_APPROVAL_REQUIRED",
      compactString(approval?.message || "") || "Open Auto Flow and click Pair before starting CLI pairing.",
      approval?.details
    );
  };

  handlers["project.metadata.get"] = async (request) => {
    if (typeof runtime.getProjectMetadata !== "function") {
      throw bridgeError("METADATA_UNAVAILABLE", "Project metadata is not available from this bridge runtime.");
    }
    const result = await runtime.getProjectMetadata(request.payload || {}, request);
    const projectInitialData = result?.projectInitialData || result?.metadata || null;
    if (!projectInitialData) {
      throw bridgeError("METADATA_UNAVAILABLE", "Flow project metadata was not returned by the runtime.");
    }
    return {
      projectId: compactString(result.projectId || projectIdFromProjectInitialData(projectInitialData)),
      source: compactString(result.source || "flow.projectInitialData"),
      fetchedAt: compactString(result.fetchedAt || new Date().toISOString()),
      page: normalizePageSummary(result.page || null),
      metadata: projectInitialData,
      projectInitialData,
      ...(result.expectedManifest ? { expectedManifest: result.expectedManifest } : {}),
      ...(result.reconciliation ? { reconciliation: result.reconciliation } : {})
    };
  };

  handlers["project.media.list"] = async (request) => {
    if (typeof runtime.listProjectMedia !== "function") {
      throw bridgeError("PROJECT_MEDIA_UNAVAILABLE", "Project media list is not available from this bridge runtime.");
    }
    const result = await runtime.listProjectMedia(request.payload || {}, request);
    const rows = Array.isArray(result?.rows) ? result.rows : [];
    const items = Array.isArray(result?.items) ? result.items : [];
    const media = Array.isArray(result?.media) ? result.media : [];
    return {
      projectId: compactString(result?.projectId || result?.meta?.projectId || ""),
      source: compactString(result?.source || result?.meta?.source || "project.media.list"),
      fetchedAt: compactString(result?.fetchedAt || result?.meta?.fetchedAt || new Date().toISOString()),
      page: normalizePageSummary(result?.page || null),
      rows,
      items,
      media,
      meta: result?.meta && typeof result.meta === "object" ? result.meta : {}
    };
  };

  handlers["downloads.plan"] = async (request) => {
    if (typeof runtime.planDownloads === "function") {
      return normalizeDownloadPlanResponse(await runtime.planDownloads(request.payload || {}, request));
    }
    return planDownloadsFromPayload(request.payload || {});
  };

  handlers["downloads.execute"] = async (request) => {
    if (typeof runtime.executeDownloads === "function") {
      return runtime.executeDownloads(request.payload || {}, request);
    }
    throw bridgeError(
      "DOWNLOADS_EXECUTE_UNAVAILABLE",
      "Download execution is not wired in this bridge runtime. Use downloads.plan and download from the extension."
    );
  };

  handlers["flow.generate"] = async (request) => {
    if (typeof runtime.generateFlowApi === "function") {
      return runtime.generateFlowApi(request.payload || {}, request);
    }
    throw bridgeError(
      "FLOW_API_BRIDGE_UNAVAILABLE",
      "Auto Flow direct API generation is not wired in this runtime."
    );
  };

  handlers["flow.state.get"] = async (request) => {
    if (typeof runtime.getFlowApiState === "function") {
      return runtime.getFlowApiState(request.payload || {}, request);
    }
    throw bridgeError(
      "FLOW_API_BRIDGE_UNAVAILABLE",
      "Auto Flow direct API job state is not wired in this runtime."
    );
  };

  handlers["agent.prompt.submit"] = async (request) => {
    if (typeof runtime.submitAgentPrompt === "function") {
      return runtime.submitAgentPrompt(request.payload || {}, request);
    }
    throw bridgeError(
      "AGENT_PANEL_NOT_READY",
      "Direct Agent panel submission is not wired yet. Use the returned Agent prompt as a manual copy handoff."
    );
  };

  handlers["agent.retry.submit"] = async (request) => {
    if (typeof runtime.submitAgentRetry === "function") {
      return runtime.submitAgentRetry(request.payload || {}, request);
    }
    throw bridgeError(
      "AGENT_PANEL_NOT_READY",
      "Direct Agent retry submission is not wired yet. Use the retry prompt as a manual copy handoff."
    );
  };

  handlers["agent.refs.attach"] = async (request) => {
    if (typeof runtime.attachAgentRefs === "function") {
      return runtime.attachAgentRefs(request.payload || {}, request);
    }
    throw bridgeError(
      "AGENT_REF_ATTACH_UNAVAILABLE",
      "Agent reference attachment is not wired in this bridge runtime. Use dry-run planning, then attach the refs in Flow before submitting."
    );
  };

  handlers["agent.composer.submit"] = async (request) => {
    if (typeof runtime.submitAgentComposerDraft === "function") {
      return runtime.submitAgentComposerDraft(request.payload || {}, request);
    }
    throw bridgeError(
      "AGENT_COMPOSER_SUBMIT_UNAVAILABLE",
      "Current Agent composer draft submission is not wired in this bridge runtime."
    );
  };

  handlers["agent.credits.confirm"] = async (request) => {
    if (typeof runtime.confirmAgentCredits === "function") {
      return runtime.confirmAgentCredits(request.payload || {}, request);
    }
    throw bridgeError(
      "AGENT_CREDIT_CONFIRM_UNAVAILABLE",
      "Credit dialog confirmation is not wired in this bridge runtime."
    );
  };

  for (const type of [
    "fleetgen.setPrompts",
    "fleetgen.updateSettings",
    "fleetgen.launch",
    "fleetgen.executeDirect",
    "fleetgen.getCapabilities",
    "fleetgen.normalizeInputs",
    "fleetgen.getState",
    "fleetgen.getStatus",
    "fleetgen.getResult",
    "fleetgen.getOutbox"
  ]) {
    handlers[type] = async (request) => {
      if ((type === "fleetgen.launch" || type === "fleetgen.executeDirect") && request.payload?.captainAuthorized !== true) {
        throw bridgeError(
          "FLEET_GEN_CREDIT_APPROVAL_REQUIRED",
          "Fleet Gen launch and executeDirect require captainAuthorized:true before any generation can start."
        );
      }
      if (typeof runtime.executeFleetGenCommand === "function") {
        return runtime.executeFleetGenCommand({
          command: type.replace(/^fleetgen\./, ""),
          ...(request.payload || {})
        }, request);
      }
      throw bridgeError(
        "FLEET_GEN_UNAVAILABLE",
        "Flow Tool Builder Fleet Gen bridge is not wired in this runtime."
      );
    };
  }

  handlers["fleet.state.get"] = async (request) => {
    if (typeof runtime.getFleetGenState === "function") {
      return runtime.getFleetGenState(request.payload || {}, request);
    }
    throw bridgeError(
      "FLEETGEN_BRIDGE_UNAVAILABLE",
      "Fleet Gen page bridge is not wired in this bridge runtime."
    );
  };

  handlers["fleet.generate"] = async (request) => {
    if (typeof runtime.generateFleetGen === "function") {
      return runtime.generateFleetGen(request.payload || {}, request);
    }
    throw bridgeError(
      "FLEETGEN_BRIDGE_UNAVAILABLE",
      "Fleet Gen generation is not wired in this bridge runtime."
    );
  };

  return handlers;
}

export function createNativeBridgeStubHandlers() {
  return createNativeBridgeHandlers();
}

export const nativeBridge = createNativeBridge();

export function createNativeBridgePortController(options = {}) {
  const chromeApi = options.chromeApi || globalThis.chrome;
  const bridge = options.bridge || nativeBridge;
  const hostName = compactString(options.hostName || AGENT_BRIDGE_NATIVE_HOST);
  const enabledReader = typeof options.isEnabled === "function"
    ? options.isEnabled
    : (typeof options.enabledReader === "function" ? options.enabledReader : () => readAgentBridgeEnabled(chromeApi));
  const onEvent = typeof options.onEvent === "function" ? options.onEvent : () => {};
  const setTimer = typeof options.setTimeoutFn === "function" ? options.setTimeoutFn : globalThis.setTimeout?.bind(globalThis);
  const clearTimer = typeof options.clearTimeoutFn === "function" ? options.clearTimeoutFn : globalThis.clearTimeout?.bind(globalThis);
  const initialReconnectDelayMs = Number.isFinite(Number(options.reconnectDelayMs))
    ? Math.max(0, Number(options.reconnectDelayMs))
    : 1500;
  const maxReconnectDelayMs = Number.isFinite(Number(options.reconnectMaxDelayMs))
    ? Math.max(initialReconnectDelayMs, Number(options.reconnectMaxDelayMs))
    : 30000;
  const restartDisconnectTimeoutMs = Number.isFinite(Number(options.restartDisconnectTimeoutMs))
    ? Math.max(25, Number(options.restartDisconnectTimeoutMs))
    : 1000;
  const roundTripTimeoutMs = Number.isFinite(Number(options.roundTripTimeoutMs))
    ? Math.max(25, Number(options.roundTripTimeoutMs))
    : 2500;
  const watchdogIntervalMs = Number.isFinite(Number(options.watchdogIntervalMs))
    ? Math.max(0, Number(options.watchdogIntervalMs))
    : 30000;
  let port = null;
  let started = false;
  let startPromise = null;
  let refreshPromise = null;
  let queuedRefreshReason = null;
  let connecting = false;
  let storageListenerInstalled = false;
  let reconnectTimer = null;
  let watchdogTimer = null;
  let watchdogInFlight = false;
  let autoRestartInProgress = false;
  let nativeRequestSequence = 0;
  const pendingNativeRequests = new Map();
  let reconnectDelayMs = initialReconnectDelayMs;
  let lastError = "";
  let lastErrorCode = "";
  let lastEventType = "";
  let lastConnectedAt = "";
  let lastDisconnectedAt = "";
  let lastRoundTripAt = "";
  let lastRoundTripOk = false;
  let lastRoundTripError = "";
  let lastRoundTripErrorCode = "";
  let restartInProgress = false;
  let manualRestartInProgress = false;
  let controlledDisconnectResolver = null;

  async function start(reason = "startup") {
    started = true;
    installStorageListener();
    if (startPromise) return startPromise;
    startPromise = refresh(reason);
    try {
      return await startPromise;
    } finally {
      startPromise = null;
    }
  }

  async function refresh(reason = "refresh") {
    if (refreshPromise) {
      queuedRefreshReason = reason;
      return refreshPromise;
    }
    refreshPromise = refreshInternal(reason);
    try {
      return await refreshPromise;
    } finally {
      refreshPromise = null;
      const trailingReason = queuedRefreshReason;
      queuedRefreshReason = null;
      if (trailingReason !== null) {
        refresh(trailingReason).catch(() => {});
      }
    }
  }

  async function refreshInternal(reason = "refresh") {
    let enabled = false;
    try {
      enabled = await enabledReader();
    } catch (error) {
      onEvent({
        type: "agent_bridge.enabled_read_error",
        reason,
        error: compactString(error?.message || error || "agent_bridge_enabled_read_failed")
      });
    }
    bridge.setEnabled(enabled === true);
    if (!enabled) {
      cancelReconnect("disabled");
      cancelWatchdog("disabled");
      disconnect("disabled");
      return false;
    }
    const connected = connect(reason);
    if (connected) {
      await checkHealth(`refresh:${reason}`, { repair: true });
    }
    return currentDiagnostics().connected === true;
  }

  function connect(reason = "connect") {
    if (port) return true;
    if (connecting) return false;
    connecting = true;
    try {
      if (typeof chromeApi?.runtime?.connectNative !== "function") {
        recordError("agent_bridge.native_host.unavailable", "connectNative_unavailable");
        onEvent({
          type: "agent_bridge.native_host.unavailable",
          reason,
          error: "connectNative_unavailable"
        });
        scheduleReconnect("connect_unavailable", "connectNative_unavailable");
        return false;
      }
      port = chromeApi.runtime.connectNative(hostName);
      if (!port) {
        recordError("agent_bridge.native_host.unavailable", "connectNative_returned_empty_port");
        onEvent({
          type: "agent_bridge.native_host.unavailable",
          reason,
          error: "connectNative_returned_empty_port"
        });
        scheduleReconnect("connect_empty_port", "connectNative_returned_empty_port");
        return false;
      }
      const connectedPort = port;
      reconnectDelayMs = initialReconnectDelayMs;
      lastRoundTripOk = false;
      lastRoundTripAt = "";
      lastRoundTripError = "";
      lastRoundTripErrorCode = "";
      port.onMessage?.addListener?.((message) => {
        return (async () => {
          if (port !== connectedPort) return;
          if (resolveNativeResponse(message)) return;
          if (isNativeResponseFrame(message)) {
            onEvent({
              type: "agent_bridge.native_host.unmatched_response_dropped",
              requestType: compactString(message?.type || ""),
              requestId: compactString(message?.id || ""),
              ok: message?.ok === true,
              errorCode: compactString(message?.error?.code || "")
            });
            return;
          }
          onEvent({
            type: "agent_bridge.native_host.message_received",
            requestType: compactString(message?.type || ""),
            requestId: compactString(message?.id || "")
          });
          const response = await bridge.handleMessage(message, {
            nativeHostConnected: true,
            nativeHostName: hostName,
            extensionId: chromeApi?.runtime?.id || ""
          });
          onEvent({
            type: "agent_bridge.native_host.response_ready",
            requestType: compactString(message?.type || ""),
            requestId: compactString(message?.id || ""),
            ok: response?.ok === true,
            errorCode: compactString(response?.error?.code || "")
          });
          try {
            connectedPort?.postMessage?.(response);
            onEvent({
              type: "agent_bridge.native_host.response_posted",
              requestType: compactString(message?.type || ""),
              requestId: compactString(message?.id || "")
            });
          } catch (error) {
            markRoundTripFailure(error, "agent_bridge.native_host.post_error");
            scheduleHealthRepair("post_error", error);
            onEvent({
              type: "agent_bridge.native_host.post_error",
              requestType: compactString(message?.type || ""),
              requestId: compactString(message?.id || ""),
              error: compactString(error?.message || error || "native_bridge_post_failed")
            });
          }
        })().catch((error) => {
          markRoundTripFailure(error, "agent_bridge.native_host.message_error");
          scheduleHealthRepair("message_error", error);
          onEvent({
            type: "agent_bridge.native_host.message_error",
            requestType: compactString(message?.type || ""),
            requestId: compactString(message?.id || ""),
            error: compactString(error?.message || error || "native_bridge_message_failed")
          });
        });
      });
      port.onDisconnect?.addListener?.(() => {
        if (port !== connectedPort) return;
        const error = compactString(chromeApi?.runtime?.lastError?.message || "");
        const controlledDisconnect = manualRestartInProgress === true;
        recordError("agent_bridge.native_host.disconnected", error);
        lastDisconnectedAt = new Date().toISOString();
        onEvent({
          type: "agent_bridge.native_host.disconnected",
          error,
          controlled: controlledDisconnect
        });
        port = null;
        rejectPendingNativeRequests("NATIVE_HOST_DISCONNECTED", error || "Auto Flow native host disconnected.");
        lastRoundTripOk = false;
        cancelWatchdog("disconnect");
        if (controlledDisconnectResolver) {
          controlledDisconnectResolver({ ok: true, error });
          controlledDisconnectResolver = null;
        }
        if (!controlledDisconnect) scheduleReconnect("disconnect", error);
      });
      onEvent({
        type: "agent_bridge.native_host.connected",
        reason,
        hostName
      });
      lastError = "";
      lastErrorCode = "";
      lastEventType = "agent_bridge.native_host.connected";
      lastConnectedAt = new Date().toISOString();
      scheduleWatchdog("connect");
      return true;
    } catch (error) {
      port = null;
      lastRoundTripOk = false;
      recordError("agent_bridge.native_host.connect_error", compactString(error?.message || error || "connectNative_failed"));
      onEvent({
        type: "agent_bridge.native_host.connect_error",
        reason,
        hostName,
        error: compactString(error?.message || error || "connectNative_failed")
      });
      scheduleReconnect("connect_error", compactString(error?.message || error || "connectNative_failed"));
      return false;
    } finally {
      connecting = false;
    }
  }

  async function restart(reason = "manual_restart") {
    if (watchdogInFlight && !String(reason || "").startsWith("auto:")) {
      return restartInProgressResult(
        reason,
        "NATIVE_HOST_HEALTH_CHECK_IN_PROGRESS",
        "A native host health check is already in progress."
      );
    }
    if (restartInProgress) return restartInProgressResult(reason);
    restartInProgress = true;
    try {
      return await restartInternal(reason);
    } finally {
      restartInProgress = false;
    }
  }

  async function restartInternal(reason = "manual_restart") {
    started = true;
    installStorageListener();
    const events = [];
    const emit = (event = {}) => {
      const normalized = {
        ...event,
        reason: compactString(event.reason || reason)
      };
      events.push(normalized);
      onEvent(normalized);
    };
    emit({ type: "agent_bridge.native_host.restart_requested" });
    cancelReconnect("restart");
    cancelWatchdog("restart");
    const before = currentDiagnostics();

    let enabled = bridge.isEnabled();
    try {
      enabled = await enabledReader();
      bridge.setEnabled(enabled === true);
    } catch (error) {
      recordError("agent_bridge.enabled_read_error", compactString(error?.message || error || "agent_bridge_enabled_read_failed"));
      emit({
        type: "agent_bridge.native_host.restart_failed",
        error: lastError,
        code: lastErrorCode
      });
      return {
        ok: false,
        action: "restart",
        reason,
        before,
        after: currentDiagnostics(),
        events,
        error: {
          code: lastErrorCode || "AGENT_BRIDGE_ENABLED_READ_FAILED",
          message: lastError || "agent_bridge_enabled_read_failed"
        }
      };
    }

    if (!enabled) {
      disconnect("restart_disabled");
      emit({
        type: "agent_bridge.native_host.restart_failed",
        error: "native bridge is disabled",
        code: "BRIDGE_DISABLED"
      });
      return {
        ok: false,
        action: "restart",
        reason,
        before,
        after: currentDiagnostics(),
        events,
        error: {
          code: "BRIDGE_DISABLED",
          message: "native bridge is disabled"
        }
      };
    }

    manualRestartInProgress = true;
    try {
      if (port) {
        const oldPort = port;
        const disconnectResult = await waitForControlledDisconnect(() => {
          try {
            oldPort.disconnect?.();
          } catch (error) {
            return {
              ok: false,
              error: compactString(error?.message || error || "native_host_disconnect_failed")
            };
          }
          return { ok: true };
        });
        port = null;
        lastDisconnectedAt = new Date().toISOString();
        emit({
          type: "agent_bridge.native_host.restart_disconnect_complete",
          ok: disconnectResult.ok === true,
          error: compactString(disconnectResult.error || "")
        });
      } else {
        emit({
          type: "agent_bridge.native_host.restart_disconnect_complete",
          ok: true,
          skipped: true
        });
      }
    } finally {
      controlledDisconnectResolver = null;
      manualRestartInProgress = false;
    }

    reconnectDelayMs = initialReconnectDelayMs;
    lastError = "";
    lastErrorCode = "";
    lastRoundTripOk = false;
    lastRoundTripError = "";
    lastRoundTripErrorCode = "";
    emit({ type: "agent_bridge.native_host.restart_connect_started" });
    const connected = connect(`restart:${reason}`);
    const roundTrip = connected
      ? await verifyRoundTrip(`restart:${reason}`)
      : { ok: false, error: { code: lastErrorCode || "NATIVE_HOST_RESTART_FAILED", message: lastError || "native_host_restart_failed" } };
    const after = currentDiagnostics();
    if (connected && roundTrip.ok === true && after.connected === true) {
      emit({ type: "agent_bridge.native_host.restart_connected" });
      return {
        ok: true,
        action: "restart",
        reason,
        before,
        after: currentDiagnostics(),
        events
      };
    }
    const error = compactString(roundTrip.error?.message || lastError || after.error || "native_host_restart_failed");
    const code = compactString(roundTrip.error?.code || lastErrorCode || after.errorCode || "NATIVE_HOST_RESTART_FAILED");
    emit({
      type: "agent_bridge.native_host.restart_failed",
      error,
      code
    });
    return {
      ok: false,
      action: "restart",
      reason,
      before,
      after,
      events,
      error: {
        code,
        message: error
      }
    };
  }

  function restartInProgressResult(
    reason = "manual_restart",
    code = "NATIVE_HOST_RESTART_IN_PROGRESS",
    message = "A native host restart is already in progress."
  ) {
    const diagnostics = currentDiagnostics();
    return {
      ok: false,
      action: "restart",
      reason,
      skipped: true,
      before: diagnostics,
      after: diagnostics,
      events: [],
      error: {
        code,
        message
      }
    };
  }

  function waitForControlledDisconnect(disconnectFn) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = globalThis.setTimeout?.(() => finish({
        ok: false,
        error: "native host disconnect timed out"
      }), restartDisconnectTimeoutMs);
      controlledDisconnectResolver = finish;
      const immediate = disconnectFn();
      if (immediate?.ok === false) finish(immediate);

      function finish(result) {
        if (settled) return;
        settled = true;
        if (timer) globalThis.clearTimeout?.(timer);
        resolve(result || { ok: true });
      }
    });
  }

  function disconnect(reason = "disconnect") {
    cancelReconnect(reason);
    cancelWatchdog(reason);
    if (!port) return;
    try {
      port.disconnect?.();
    } catch {}
    port = null;
    rejectPendingNativeRequests("NATIVE_HOST_DISCONNECTED", "Auto Flow native host disconnected.");
    lastRoundTripOk = false;
    lastDisconnectedAt = new Date().toISOString();
    onEvent({
      type: "agent_bridge.native_host.disconnected",
      reason
    });
  }

  function scheduleReconnect(reason = "reconnect", error = "") {
    if (!started || reconnectTimer || !bridge.isEnabled() || typeof setTimer !== "function") return false;
    const delayMs = reconnectDelayMs;
    reconnectTimer = setTimer(async () => {
      reconnectTimer = null;
      await refresh(`reconnect:${reason}`);
    }, delayMs);
    reconnectDelayMs = Math.min(maxReconnectDelayMs, Math.max(initialReconnectDelayMs, delayMs * 2 || initialReconnectDelayMs));
    onEvent({
      type: "agent_bridge.native_host.reconnect_scheduled",
      reason,
      error: compactString(error || ""),
      delayMs
    });
    return true;
  }

  function scheduleWatchdog(reason = "watchdog") {
    if (!started || !bridge.isEnabled() || !port || watchdogIntervalMs <= 0 || watchdogTimer || typeof setTimer !== "function") return false;
    watchdogTimer = setTimer(async () => {
      watchdogTimer = null;
      await checkHealth(`watchdog:${reason}`, { repair: true });
    }, watchdogIntervalMs);
    onEvent({
      type: "agent_bridge.native_host.watchdog_scheduled",
      reason,
      delayMs: watchdogIntervalMs
    });
    return true;
  }

  function cancelWatchdog(reason = "cancel") {
    if (!watchdogTimer) return;
    try {
      clearTimer?.(watchdogTimer);
    } catch {}
    watchdogTimer = null;
    onEvent({
      type: "agent_bridge.native_host.watchdog_cancelled",
      reason
    });
  }

  function cancelReconnect(reason = "cancel") {
    if (!reconnectTimer) return;
    try {
      clearTimer?.(reconnectTimer);
    } catch {}
    reconnectTimer = null;
    reconnectDelayMs = initialReconnectDelayMs;
    onEvent({
      type: "agent_bridge.native_host.reconnect_cancelled",
      reason
    });
  }

  function installStorageListener() {
    if (storageListenerInstalled || typeof chromeApi?.storage?.onChanged?.addListener !== "function") return;
    chromeApi.storage.onChanged.addListener((changes = {}, areaName = "") => {
      if (areaName && areaName !== "local") return;
      if (!AGENT_BRIDGE_STORAGE_KEYS.some((key) => Object.prototype.hasOwnProperty.call(changes, key))) return;
      refresh("storage_change");
    });
    storageListenerInstalled = true;
  }

  async function checkHealth(reason = "watchdog", options = {}) {
    if (watchdogInFlight) {
      return {
        ok: lastRoundTripOk === true,
        skipped: true,
        reason: "health_check_in_flight",
        diagnostics: currentDiagnostics()
      };
    }
    if (!bridge.isEnabled()) {
      lastRoundTripOk = false;
      return {
        ok: false,
        skipped: true,
        reason: "bridge_disabled",
        diagnostics: currentDiagnostics()
      };
    }
    if (restartInProgress) {
      return {
        ok: lastRoundTripOk === true,
        skipped: true,
        reason: "restart_in_progress",
        diagnostics: currentDiagnostics()
      };
    }
    watchdogInFlight = true;
    cancelWatchdog(reason);
    try {
      const result = await verifyRoundTrip(reason);
      if (result.ok === true) return result;
      if (options.repair !== false) {
        await scheduleHealthRepair(reason, result.error || result);
      }
      return result;
    } finally {
      watchdogInFlight = false;
      scheduleWatchdog(reason);
    }
  }

  async function scheduleHealthRepair(reason = "watchdog", error = {}) {
    if (!started || autoRestartInProgress || manualRestartInProgress || restartInProgress) return false;
    autoRestartInProgress = true;
    onEvent({
      type: "agent_bridge.native_host.auto_reconnect_started",
      reason,
      error: compactString(error?.message || error || ""),
      code: compactString(error?.code || "")
    });
    try {
      const result = await restart(`auto:${reason}`);
      onEvent({
        type: result.ok ? "agent_bridge.native_host.auto_reconnect_ok" : "agent_bridge.native_host.auto_reconnect_failed",
        reason,
        error: compactString(result.error?.message || ""),
        code: compactString(result.error?.code || "")
      });
      if (result.ok !== true) {
        scheduleReconnect(`auto_reconnect_failed:${reason}`, result.error?.message || "");
      }
      return result.ok === true;
    } finally {
      autoRestartInProgress = false;
    }
  }

  async function verifyRoundTrip(reason = "health_check") {
    if (!port) {
      const error = bridgeError("NATIVE_HOST_DISCONNECTED", "Auto Flow native host port is not connected.");
      markRoundTripFailure(error, "agent_bridge.native_host.roundtrip_unavailable");
      return {
        ok: false,
        reason,
        error,
        diagnostics: currentDiagnostics()
      };
    }
    try {
      const response = await sendNativeRequest("status.get", {
        healthCheck: true,
        reason
      }, {
        reason,
        timeoutMs: roundTripTimeoutMs
      });
      const staleBlocker = nativeStatusStaleBlocker(response?.payload || {});
      if (staleBlocker) {
        throw bridgeError(
          compactString(staleBlocker.code || "STALE_NATIVE_HOST_PROCESS"),
          compactString(staleBlocker.message || "Chrome is still connected to an older Auto Flow native host."),
          staleBlocker.details
        );
      }
      if (response?.ok !== true) {
        throw bridgeError(
          compactString(response?.error?.code || "NATIVE_HOST_ROUND_TRIP_FAILED"),
          compactString(response?.error?.message || "Auto Flow native host status round-trip failed."),
          response?.error?.details
        );
      }
      markRoundTripOk();
      onEvent({
        type: "agent_bridge.native_host.roundtrip_ok",
        reason,
        state: compactString(response?.payload?.bridge?.state || ""),
        paired: response?.payload?.bridge?.paired === true
      });
      return {
        ok: true,
        reason,
        response,
        diagnostics: currentDiagnostics()
      };
    } catch (error) {
      markRoundTripFailure(error, "agent_bridge.native_host.roundtrip_failed");
      onEvent({
        type: "agent_bridge.native_host.roundtrip_failed",
        reason,
        error: compactString(error?.message || error || "native_host_roundtrip_failed"),
        code: compactString(error?.code || "")
      });
      return {
        ok: false,
        reason,
        error: {
          code: compactString(error?.code || "NATIVE_HOST_ROUND_TRIP_FAILED"),
          message: compactString(error?.message || error || "native_host_roundtrip_failed"),
          details: error?.details
        },
        diagnostics: currentDiagnostics()
      };
    }
  }

  function sendNativeRequest(type, payload = {}, options = {}) {
    if (!port) {
      return Promise.reject(bridgeError("NATIVE_HOST_DISCONNECTED", "Auto Flow native host port is not connected."));
    }
    const timeoutMs = options.timeoutMs || roundTripTimeoutMs;
    const request = createAgentBridgeRequest({
      id: `extension-health-${Date.now()}-${++nativeRequestSequence}`,
      type,
      payload,
      session: {
        source: "extension_watchdog",
        clientId: "auto-flow-extension",
        reason: compactString(options.reason || "")
      }
    });
    return new Promise((resolve, reject) => {
      const timer = setTimer?.(() => {
        pendingNativeRequests.delete(request.id);
        reject(bridgeError("NATIVE_HOST_ROUND_TRIP_TIMEOUT", `Auto Flow native host did not answer ${type} within ${timeoutMs}ms.`, {
          timeoutMs,
          requestId: request.id,
          type
        }));
      }, timeoutMs);
      pendingNativeRequests.set(request.id, {
        resolve,
        reject,
        timer
      });
      try {
        port.postMessage?.(request);
      } catch (error) {
        if (timer) clearTimer?.(timer);
        pendingNativeRequests.delete(request.id);
        reject(bridgeError("NATIVE_HOST_ROUND_TRIP_SEND_FAILED", compactString(error?.message || error || "native_host_roundtrip_send_failed")));
      }
    });
  }

  function resolveNativeResponse(message = {}) {
    if (!message || typeof message.ok !== "boolean") return false;
    const requestId = compactString(message.id);
    if (!requestId || !pendingNativeRequests.has(requestId)) return false;
    const pending = pendingNativeRequests.get(requestId);
    pendingNativeRequests.delete(requestId);
    if (pending.timer) clearTimer?.(pending.timer);
    pending.resolve(message);
    return true;
  }

  function isNativeResponseFrame(message = {}) {
    return message && typeof message.ok === "boolean";
  }

  function rejectPendingNativeRequests(code = "NATIVE_HOST_DISCONNECTED", message = "Auto Flow native host disconnected.") {
    const entries = [...pendingNativeRequests.values()];
    pendingNativeRequests.clear();
    for (const entry of entries) {
      if (entry.timer) clearTimer?.(entry.timer);
      entry.reject(bridgeError(code, message));
    }
  }

  function markRoundTripOk() {
    lastRoundTripOk = true;
    lastRoundTripAt = new Date().toISOString();
    lastRoundTripError = "";
    lastRoundTripErrorCode = "";
    lastError = "";
    lastErrorCode = "";
    lastEventType = "agent_bridge.native_host.roundtrip_ok";
  }

  function markRoundTripFailure(error = {}, eventType = "agent_bridge.native_host.roundtrip_failed") {
    lastRoundTripOk = false;
    lastRoundTripError = compactString(error?.message || error || "native_host_roundtrip_failed");
    lastRoundTripErrorCode = compactString(error?.code || classifyNativeBridgeError(lastRoundTripError, eventType) || "NATIVE_HOST_ROUND_TRIP_FAILED");
    lastError = lastRoundTripError;
    lastErrorCode = lastRoundTripErrorCode;
    lastEventType = eventType;
  }

  function currentDiagnostics() {
    const enabled = bridge.isEnabled();
    const nativePortConnected = Boolean(port);
    const connected = nativePortConnected && lastRoundTripOk === true;
    const reconnecting = Boolean(reconnectTimer || autoRestartInProgress || (!connected && nativePortConnected && enabled));
    const healthState = connected
      ? BROKER_HEALTH_STATES.READY
      : classifyBrokerHealth({
          brokerAvailable: nativePortConnected,
          extensionConnected: connected,
          reconnecting,
          enabled
        });
    return {
      started,
      connected,
      nativePortConnected,
      reconnecting,
      checking: Boolean(watchdogInFlight),
      state: healthState,
      healthState: normalizeBrokerHealthState(healthState),
      health: {
        state: healthState,
        brokerAvailable: nativePortConnected,
        extensionConnected: connected,
        reconnecting,
        enabled
      },
      reconnectDelayMs,
      watchdogIntervalMs,
      roundTripTimeoutMs,
      hostName,
      enabled,
      error: lastError,
      errorCode: lastErrorCode,
      lastRoundTripAt,
      lastRoundTripOk,
      lastRoundTripError,
      lastRoundTripErrorCode,
      lastEventType,
      lastConnectedAt,
      lastDisconnectedAt,
      bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
      extensionVersion: chromeApi?.runtime?.getManifest?.()?.version || ""
    };
  }

  return {
    start,
    refresh,
    restart,
    checkHealth,
    stop(reason = "stop") {
      started = false;
      disconnect(reason);
    },
    isConnected() {
      return currentDiagnostics().connected === true;
    },
    diagnostics() {
      return currentDiagnostics();
    }
  };

  function recordError(eventType = "", error = "") {
    lastEventType = compactString(eventType || "");
    lastError = compactString(error || "");
    lastErrorCode = classifyNativeBridgeError(lastError, lastEventType);
  }
}

function nativeStatusStaleBlocker(payload = {}) {
  const blockers = Array.isArray(payload?.blockers) ? payload.blockers : [];
  const stale = blockers.find((blocker) => compactString(blocker?.code) === "STALE_NATIVE_HOST_PROCESS");
  if (stale) return stale;
  if (compactString(payload?.bridge?.state) === "stale_native_host") {
    return {
      code: "STALE_NATIVE_HOST_PROCESS",
      message: "Chrome is still connected to an older Auto Flow native host."
    };
  }
  return null;
}

export async function readAgentBridgeEnabled(chromeApi = globalThis.chrome) {
  if (!chromeApi?.storage?.local?.get) return false;
  const stored = await chromeApi.storage.local.get(AGENT_BRIDGE_STORAGE_KEYS);
  if (Object.prototype.hasOwnProperty.call(stored || {}, AGENT_BRIDGE_ENABLED_STORAGE_KEY)) {
    return truthy(stored?.[AGENT_BRIDGE_ENABLED_STORAGE_KEY]);
  }
  const directSettings = stored?.["autoflow-agent-bridge-settings"];
  if (truthy(directSettings?.enabled) || truthy(directSettings?.agentBridgeEnabled) || truthy(directSettings?.nativeBridgeEnabled)) return true;
  const sidepanelState = stored?.[SIDEPANEL_STATE_STORAGE_KEY];
  return Boolean(
    truthy(sidepanelState?.settings?.agentBridgeEnabled) ||
    truthy(sidepanelState?.settings?.nativeBridgeEnabled) ||
    truthy(sidepanelState?.control?.agentMode?.bridgeEnabled) ||
    truthy(sidepanelState?.agentBridge?.enabled) ||
    truthy(sidepanelState?.runtime?.agentBridgeEnabled)
  );
}

function normalizeBridgeRequestForValidation(message = {}) {
  if (!message || typeof message !== "object" || message.type !== "downloads.plan") return message;
  const payload = message.payload && typeof message.payload === "object" ? message.payload : {};
  const hasMediaIds = Array.isArray(payload.mediaIds) && payload.mediaIds.some(compactString);
  if (hasMediaIds || compactString(payload.taskId)) return message;
  const mediaIds = mediaIdsFromRows(payload.reconciledRows || payload.rows);
  if (!mediaIds.length) return message;
  return {
    ...message,
    payload: {
      ...payload,
      mediaIds
    }
  };
}

function planDownloadsFromPayload(payload = {}) {
  const rows = Array.isArray(payload.reconciledRows) && payload.reconciledRows.length
    ? payload.reconciledRows
    : (Array.isArray(payload.rows) ? payload.rows : []);
  if (!rows.length) {
    return normalizeDownloadPlanResponse({
      execute: false,
      limitation: "Download execution is not enabled through the native bridge in this pass.",
      plan: {
        downloads: [],
        mediaDownloads: [],
        files: [],
        skipped: []
      },
      downloads: [],
      mediaDownloads: [],
      files: [],
      skipped: []
    });
  }

  const artifactPlan = planAgentRunArtifacts({
    ...payload,
    rows,
    runName: payload.runName || payload.name || "Agent Run",
    reservedArtifactKeys: payload.reservedArtifactKeys || [],
    reservedTargetPaths: payload.reservedTargetPaths || []
  });
  return normalizeDownloadPlanResponse({
    execute: false,
    limitation: "Downloads are not executed through the native bridge in this pass; returning the Auto Flow artifact plan only.",
    plan: artifactPlan,
    downloads: artifactPlan.downloads || [],
    mediaDownloads: artifactPlan.mediaDownloads || artifactPlan.downloads || [],
    files: artifactPlan.files || [],
    skipped: artifactPlan.skipped || []
  });
}

function normalizeDownloadPlanResponse(result = {}) {
  const plan = result.plan && typeof result.plan === "object"
    ? result.plan
    : {
        downloads: result.downloads || result.mediaDownloads || [],
        mediaDownloads: result.mediaDownloads || result.downloads || [],
        files: result.files || [],
        skipped: result.skipped || []
      };
  const downloads = Array.isArray(result.downloads)
    ? result.downloads
    : (Array.isArray(plan.downloads) ? plan.downloads : []);
  return {
    execute: result.execute === true,
    limitation: compactString(result.limitation || (result.execute === true ? "" : "Download execution is not enabled through the native bridge in this pass.")),
    planned: Number.isFinite(Number(result.planned)) ? Number(result.planned) : downloads.length,
    plan: {
      ...plan,
      downloads,
      mediaDownloads: Array.isArray(plan.mediaDownloads) ? plan.mediaDownloads : downloads
    },
    downloads,
    mediaDownloads: Array.isArray(result.mediaDownloads) ? result.mediaDownloads : downloads,
    files: Array.isArray(result.files) ? result.files : (Array.isArray(plan.files) ? plan.files : []),
    skipped: Array.isArray(result.skipped) ? result.skipped : (Array.isArray(plan.skipped) ? plan.skipped : [])
  };
}

function bridgeHandlerUnavailable(request = {}) {
  throw bridgeError(
    "HANDLER_NOT_CONFIGURED",
    `native bridge handler not configured for ${request.type || "unknown"}`
  );
}

function sanitizeAuthSummary(auth = null) {
  if (!auth || typeof auth !== "object") {
    return {
      available: false
    };
  }
  const usage = auth.usage && typeof auth.usage === "object" ? auth.usage : {};
  return {
    available: true,
    status: compactString(auth.status || auth.accountStatus || ""),
    signedIn: Boolean(auth.signedIn === true || auth.email || auth.userId || auth.status === "authenticated"),
    emailPresent: Boolean(compactString(auth.email)),
    userIdPresent: Boolean(compactString(auth.userId)),
    plan: compactString(auth.plan || auth.rawPlan || auth.tier || ""),
    tier: compactString(auth.tier || auth.plan || ""),
    subscriptionStatus: compactString(auth.subscriptionStatus || auth.subscription_status || auth.stripeSubscriptionStatus || auth.supabaseSubscriptionStatus || ""),
    billingHealth: compactString(auth.billingHealth || auth.billing?.health || ""),
    usage: {
      allowed: usage.allowed === true,
      unlimited: usage.unlimited === true,
      limit: safeNumber(usage.limit),
      used: safeNumber(usage.used),
      remaining: safeNumber(usage.remaining),
      resetAt: compactString(usage.resetAt || "")
    },
    degradedLocalMode: auth.degradedLocalMode === true,
    queueControlsAllowedWhileAuthPending: auth.queueControlsAllowedWhileAuthPending === true
  };
}

function normalizeRuntimeStatus(runtime = {}) {
  return {
    connected: runtime.connected === true,
    activeTabId: Number.isFinite(Number(runtime.activeTabId)) ? Number(runtime.activeTabId) : null,
    projectId: compactString(runtime.projectId),
    pageUrl: compactString(runtime.pageUrl || runtime.url),
    pageTitle: compactString(runtime.pageTitle || runtime.title),
    bridgeHealthy: runtime.bridgeHealthy === true,
    bridgeVersion: compactString(runtime.bridgeVersion),
    pageHookVersion: compactString(runtime.pageHookVersion),
    pageHookInstalled: runtime.pageHookInstalled === true,
    hasNativeFetch: runtime.hasNativeFetch === true,
    flowPageBlocked: runtime.flowPageBlocked === true,
    error: compactString(runtime.error || runtime.bridgeError || "")
  };
}

function normalizeProjectStatus(project = null, runtime = {}) {
  const source = project && typeof project === "object" ? project : {};
  const id = compactString(source.id || source.projectId || runtime.projectId || "");
  const activeTabId = Number(source.activeTabId || runtime.activeTabId || 0) || null;
  const active = source.active ?? source.connected ?? (runtime.connected === true && id ? true : null);
  return {
    state: compactString(source.state || (active === true ? "active" : (active === false ? "missing" : ""))),
    active,
    id,
    name: compactString(source.name || source.title || runtime.pageTitle || ""),
    activeTabId,
    url: compactString(source.url || source.pageUrl || runtime.pageUrl || "")
  };
}

function normalizePageSummary(page = null) {
  if (!page || typeof page !== "object") return null;
  return {
    tabId: Number.isFinite(Number(page.tabId)) ? Number(page.tabId) : null,
    url: compactString(page.url || page.href),
    title: compactString(page.title),
    projectId: compactString(page.projectId)
  };
}

function mediaIdsFromRows(rows = []) {
  const ids = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    collectMediaIds(row, ids);
  }
  return [...new Set(ids.map(compactString).filter(Boolean))];
}

function collectMediaIds(value, ids = []) {
  if (!value) return ids;
  if (typeof value === "string") return ids;
  if (Array.isArray(value)) {
    value.forEach((item) => collectMediaIds(item, ids));
    return ids;
  }
  if (typeof value !== "object") return ids;
  for (const [key, child] of Object.entries(value)) {
    if (/^(mediaId|mediaName|name)$/i.test(key) && typeof child === "string") {
      ids.push(child);
    } else if (child && typeof child === "object") {
      collectMediaIds(child, ids);
    }
  }
  return ids;
}

function projectIdFromProjectInitialData(value = {}) {
  const unwrapped = unwrapProjectInitialData(value);
  return compactString(unwrapped?.projectId || unwrapped?.project?.projectId || "");
}

function unwrapProjectInitialData(input = {}) {
  if (typeof input === "string") {
    try {
      return JSON.parse(input);
    } catch {
      return {};
    }
  }
  return input?.result?.data?.json || input?.data?.json || input?.json || input;
}

function bridgeError(code, message, details) {
  const error = new Error(message || code);
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}

function safeNumber(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
}

function truthy(value) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function classifyNativeBridgeError(error = "", eventType = "") {
  const text = `${eventType}\n${error}`.toLowerCase();
  if (!compactString(error) && /disconnected/.test(text)) return "NATIVE_HOST_DISCONNECTED";
  if (/access to the specified native messaging host is forbidden|forbidden|origin|not allowed/.test(text)) {
    return "EXTENSION_ORIGIN_MISMATCH";
  }
  if (/env:\s*node|node:\s*no such file|interpreter|launch|communicating with the native messaging host|host exited|eacces|permission denied/.test(text)) {
    return "INTERPRETER_LAUNCH_FAILURE";
  }
  if (/specified native messaging host not found|native messaging host.*not found|host not found|connectnative_unavailable|connectnative_returned_empty_port|missing/.test(text)) {
    return "NATIVE_HOST_UNAVAILABLE";
  }
  return compactString(error) ? "NATIVE_HOST_ERROR" : "";
}

function compactString(value = "") {
  return String(value ?? "").trim();
}
