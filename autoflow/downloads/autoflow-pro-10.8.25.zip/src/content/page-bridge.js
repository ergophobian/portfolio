(async function installAutoFlowRebuildBridge() {
  const PRIVACY_CONSENT_KEY = "autoflow_privacy_consent_v1";
  const PRIVACY_CONSENT_VERSION = "2026-08-17";
  const storedConsent = await chrome.storage.local.get(PRIVACY_CONSENT_KEY).catch(() => ({}));
  const consent = storedConsent?.[PRIVACY_CONSENT_KEY];
  if (consent?.accepted !== true || String(consent?.version || "") !== PRIVACY_CONSENT_VERSION) {
    return;
  }
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes?.[PRIVACY_CONSENT_KEY]) return;
    const next = changes[PRIVACY_CONSENT_KEY].newValue;
    const stillAccepted = next?.accepted === true && String(next?.version || "") === PRIVACY_CONSENT_VERSION;
    if (!stillAccepted) location.reload();
  });

  const SOURCE = "autoflow-1080-rebuild-v26";
  const BRIDGE_VERSION = "10.8.24-fleetgen-atomic-v3";
  const EXPECTED_PAGE_HOOK_VERSION = "10.8.24-video-feed-reconcile-v27";
  const EXPECTED_FLEETGEN_BRIDGE_VERSION = "10.8.24-fleetgen-atomic-v3";
  if (window.__afRebuildContentBridgeInstalled && window.__afRebuildContentBridgeVersion === BRIDGE_VERSION) {
    const hasFreshPageHook = window.__afRebuildPageHookInstalled === true &&
      window.__afRebuildPageHookVersion === EXPECTED_PAGE_HOOK_VERSION;
    if (!hasFreshPageHook) {
      injectPageHook();
    }
    const hasFreshFleetGenBridge = window.__afFleetGenBridgeInstalled === true &&
      window.__afFleetGenBridgeVersion === EXPECTED_FLEETGEN_BRIDGE_VERSION;
    if (!hasFreshFleetGenBridge) {
      injectFleetGenBridge();
    }
    try {
      chrome.runtime.sendMessage({
        type: "af.rebuild.bridge.health",
        payload: {
          ok: true,
          href: location.href,
          alreadyInstalled: true,
          bridgeVersion: BRIDGE_VERSION,
          pageHookVersion: window.__afRebuildPageHookVersion || "",
          pageHookInstalled: Boolean(window.__afRebuildPageHookInstalled),
          pageEpoch: window.__afRebuildPageEpoch || ""
        },
        meta: {
          createdAt: new Date().toISOString(),
          source: SOURCE
        }
      });
    } catch (_err) {}
    return;
  }
  window.__afRebuildContentBridgeInstalled = true;
  window.__afRebuildContentBridgeVersion = BRIDGE_VERSION;
  const pending = new Map();

  function isCurrentBridge() {
    return window.__afRebuildContentBridgeVersion === BRIDGE_VERSION;
  }

  function send(type, payload) {
    try {
      chrome.runtime.sendMessage({
        type,
        payload,
        meta: {
          createdAt: new Date().toISOString(),
          source: SOURCE
        }
      });
    } catch (_err) {
      // Content scripts can be invalidated during extension reloads.
    }
  }

  function injectPageHook() {
    const script = document.createElement("script");
    script.src = `${chrome.runtime.getURL("src/page/page-hook.js")}?v=${encodeURIComponent(BRIDGE_VERSION)}-${Date.now()}`;
    script.dataset.autoflowRebuild = "page-hook";
    script.async = false;
    script.onload = () => script.remove();
    script.onerror = () => script.remove();
    (document.documentElement || document.head).appendChild(script);
  }

  function injectFleetGenBridge() {
    const script = document.createElement("script");
    script.src = `${chrome.runtime.getURL("src/page/fleetgen-bridge.js")}?v=${encodeURIComponent(BRIDGE_VERSION)}-${Date.now()}`;
    script.dataset.autoflowRebuild = "fleetgen-bridge";
    script.async = false;
    script.onload = () => script.remove();
    script.onerror = () => script.remove();
    (document.documentElement || document.head).appendChild(script);
  }

  function requestPageHook(payload = {}, timeoutMs = 10000, requireFreshHook = true) {
    const requestId = crypto.randomUUID();
    const promise = new Promise((resolve) => {
      const timer = setTimeout(() => {
        pending.delete(requestId);
        resolve({ ok: false, error: "page_command_timeout" });
      }, timeoutMs);
      pending.set(requestId, { resolve, timer, requireFreshHook });
    });
    window.postMessage(
      {
        source: SOURCE,
        type: "af.rebuild.page.command",
        requestId,
        payload
      },
      "*"
    );
    return promise;
  }

  function requestFleetGen(payload = {}, timeoutMs = 10000) {
    const requestId = crypto.randomUUID();
    const promise = new Promise((resolve) => {
      const timer = setTimeout(() => {
        pending.delete(requestId);
        resolve({ ok: false, action: payload.action || "fleetGenInvoke", error: "fleetgen_command_timeout" });
      }, timeoutMs);
      pending.set(requestId, { resolve, timer, requireFreshHook: false, requireFleetGenBridge: true });
    });
    window.postMessage(
      {
        source: SOURCE,
        type: "af.rebuild.fleetgen.command",
        requestId,
        payload
      },
      "*"
    );
    return promise;
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== SOURCE) return;
    if (data.type === "af.rebuild.page.command.result" && data.requestId) {
      const entry = pending.get(data.requestId);
      if (!entry) return;
      if (entry.requireFreshHook && data.payload?.hookVersion !== EXPECTED_PAGE_HOOK_VERSION) {
        return;
      }
      pending.delete(data.requestId);
      clearTimeout(entry.timer);
      entry.resolve(data.payload || {});
      return;
    }
    if (data.type === "af.rebuild.fleetgen.command.result" && data.requestId) {
      const entry = pending.get(data.requestId);
      if (!entry) return;
      if (entry.requireFleetGenBridge && data.payload?.fleetGenBridgeVersion !== EXPECTED_FLEETGEN_BRIDGE_VERSION) {
        return;
      }
      pending.delete(data.requestId);
      clearTimeout(entry.timer);
      entry.resolve({
        isolatedWorldFleetGenType: typeof window.fleetGen,
        isolatedWorldHasFleetGen: typeof window.fleetGen !== "undefined",
        ...(data.payload || {})
      });
      return;
    }
    if (data.type !== "af.rebuild.page.event") return;
    send("af.rebuild.page.event", data.payload || {});
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!isCurrentBridge()) return false;
    if (message && (message.type === "af.rebuild.bridge.health" || message.type === "af.rebuild.bridge.health.v2" || message.type === "af.rebuild.bridge.health.v3" || message.type === "af.rebuild.bridge.health.v4")) {
      const requireFreshHook = message.type === "af.rebuild.bridge.health.v4";
      requestPageHook({ action: "health" }, 1500, requireFreshHook).then((hook) => {
        sendResponse({
          ok: true,
          href: location.href,
          bridgeVersion: BRIDGE_VERSION,
          pageHookVersion: hook?.hookVersion || "",
          pageHookInstalled: hook?.hookInstalled === true,
          pageEpoch: hook?.pageEpoch || window.__afRebuildPageEpoch || "",
          pageHookHealth: hook || null
        });
      });
      return true;
    }
    if (!message || (message.type !== "af.rebuild.page.command" && message.type !== "af.rebuild.page.command.v2" && message.type !== "af.rebuild.page.command.v3" && message.type !== "af.rebuild.page.command.v4")) return false;
    const timeoutMs = Math.max(1000, Number(message.payload?.timeoutMs || 10000));
    const action = String(message.payload?.action || "");
    if (action === "fleetGenInvoke" || action.startsWith("fleetGen.")) {
      requestFleetGen(message.payload || {}, timeoutMs).then((result) => sendResponse(result));
      return true;
    }
    const requireFreshHook = message.payload?.requireFreshHook !== false;
    requestPageHook(message.payload || {}, timeoutMs, requireFreshHook).then((result) => sendResponse(result));
    return true;
  });

  injectPageHook();
  injectFleetGenBridge();
  send("af.rebuild.bridge.health", { href: location.href });
})();
