import {
  createAcceptedPrivacyConsent,
  createDeclinedPrivacyConsent,
  PRIVACY_CONSENT_KEY,
  readPrivacyConsent,
  writePrivacyConsent
} from "../core/privacy/consent.js";

const CURRENT_RUNTIME_VERSION_KEY = "af_runtime_version";
const SHOW_LAUNCHER_KEY = "af_show_runtime_launcher";
const FLOW_TAB_PATTERNS = Object.freeze([
  "https://labs.google/*",
  "https://labs.google.com/*"
]);

const RUNTIMES = Object.freeze({
  current: {
    version: "10.8.25",
    path: "../sidepanel/index.html"
  }
});

function setConsentSurface(accepted) {
  const consent = document.getElementById("privacy-consent");
  const launcher = document.getElementById("runtime-launcher");
  if (consent) consent.hidden = accepted;
  if (launcher) launcher.hidden = !accepted;
}

function setConsentStatus(message = "") {
  const status = document.getElementById("privacy-consent-status");
  if (status) status.textContent = message;
}

function setConsentButtonsDisabled(disabled) {
  document.getElementById("privacy-accept")?.toggleAttribute("disabled", disabled);
  document.getElementById("privacy-decline")?.toggleAttribute("disabled", disabled);
}

async function activateCurrentFlowTabs() {
  const tabs = await chrome.tabs.query({ url: [...FLOW_TAB_PATTERNS] }).catch(() => []);
  await Promise.all(tabs
    .filter((tab) => Number(tab?.id || 0) > 0)
    .map((tab) => chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["src/content/page-bridge.js"]
    }).catch(() => null)));
}

async function launchRuntime() {
  const consent = await readPrivacyConsent(chrome.storage.local);
  if (!consent.accepted) {
    setConsentSurface(false);
    setConsentStatus("Agree to the privacy notice before launching AutoFlow Pro.");
    return;
  }
  const runtime = RUNTIMES.current;
  await chrome.storage.local.set({
    af_runtime_choice: "current",
    [CURRENT_RUNTIME_VERSION_KEY]: runtime.version,
    [SHOW_LAUNCHER_KEY]: false
  }).catch(() => {});
  window.location.href = runtime.path;
}

async function acceptPrivacyNotice() {
  setConsentButtonsDisabled(true);
  setConsentStatus("Saving your choice…");
  try {
    const record = createAcceptedPrivacyConsent();
    await writePrivacyConsent(chrome.storage.local, record);
    await activateCurrentFlowTabs();
    setConsentSurface(true);
    await launchRuntime();
  } catch (error) {
    setConsentStatus(`Could not save your choice: ${String(error?.message || error || "unknown error")}`);
    setConsentButtonsDisabled(false);
  }
}

async function declinePrivacyNotice() {
  setConsentButtonsDisabled(true);
  try {
    await writePrivacyConsent(chrome.storage.local, createDeclinedPrivacyConsent());
    await chrome.storage.local.remove([
      CURRENT_RUNTIME_VERSION_KEY,
      SHOW_LAUNCHER_KEY
    ]).catch(() => {});
    setConsentSurface(false);
    setConsentStatus("AutoFlow Pro remains inactive. You can review the policy and agree later.");
  } finally {
    setConsentButtonsDisabled(false);
  }
}

async function initializeGateway() {
  const consent = await readPrivacyConsent(chrome.storage.local);
  setConsentSurface(consent.accepted);
  if (!consent.accepted && consent.declinedAt) {
    setConsentStatus("AutoFlow Pro is inactive because consent was declined. You can agree later.");
  }
}

document.getElementById("launch-current")?.addEventListener("click", () => {
  launchRuntime();
});
document.getElementById("privacy-accept")?.addEventListener("click", () => {
  acceptPrivacyNotice();
});
document.getElementById("privacy-decline")?.addEventListener("click", () => {
  declinePrivacyNotice();
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes?.[PRIVACY_CONSENT_KEY]) return;
  readPrivacyConsent(chrome.storage.local).then((consent) => {
    setConsentSurface(consent.accepted);
  }).catch(() => {});
});

initializeGateway().catch((error) => {
  setConsentSurface(false);
  setConsentStatus(`Privacy choice unavailable: ${String(error?.message || error || "unknown error")}`);
});
