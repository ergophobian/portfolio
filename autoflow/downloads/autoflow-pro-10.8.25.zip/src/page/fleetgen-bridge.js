(function installAutoFlowFleetGenBridge() {
  const SOURCE = "autoflow-1080-rebuild-v26";
  const BRIDGE_VERSION = "10.8.24-fleetgen-atomic-v3";
  const METHODS = new Set(["executeDirect", "getCapabilities", "getOutbox", "getResult", "getState", "getStatus", "getStitchedResult", "halt", "launch", "normalizeInputs", "ping", "setPrompts", "stitchAll", "updateSettings", "version"]);

  if (window.__afFleetGenBridgeInstalled && window.__afFleetGenBridgeVersion === BRIDGE_VERSION) return;
  if (typeof window.__afFleetGenMessageHandler === "function") {
    window.removeEventListener("message", window.__afFleetGenMessageHandler);
  }
  window.__afFleetGenBridgeInstalled = true;
  window.__afFleetGenBridgeVersion = BRIDGE_VERSION;

  function compactString(value = "") {
    return String(value ?? "").trim();
  }

  function projectIdFromUrl(url = location.href) {
    return compactString(url).match(/\/project\/([0-9a-f-]{36})/i)?.[1] || "";
  }

  function availableMethods(api = window.fleetGen) {
    if (!api || typeof api !== "object") return [];
    return [...METHODS].filter((method) => typeof api[method] === "function");
  }

  function handshakeState() {
    const text = compactString(document.body?.innerText || "").slice(0, 200000);
    return {
      linked: /\bAGENT_LINKED\b/.test(text),
      marker: text.includes("AGENT_LINKED") ? "AGENT_LINKED" : "",
      title: compactString(document.title)
    };
  }

  function directSdkProbe() {
    const importMaps = [...document.querySelectorAll('script[type="importmap"]')]
      .map((node) => compactString(node.textContent || ""))
      .filter(Boolean);
    return {
      windowFlowType: typeof window.Flow,
      windowFlowGenerateType: typeof window.Flow?.generate,
      importMapFlowSdkPresent: importMaps.some((text) => text.includes("flow-sdk")),
      toolIframeCount: document.querySelectorAll("iframe").length
    };
  }

  function promptFiltersFromPayload(payload = {}) {
    const values = [];
    const add = (value) => {
      const text = compactString(value);
      if (text) values.push(text);
    };
    add(payload.prompt);
    add(payload.text);
    add(payload.promptText);
    add(payload.promptsText);
    if (Array.isArray(payload.promptFilters)) {
      payload.promptFilters.forEach(add);
    }
    return [...new Set(values)];
  }

  function timestampMs(value = null) {
    if (!value || typeof value !== "object") return 0;
    const candidates = [
      value.createdAt,
      value.created_at,
      value.createTime,
      value.createdTime,
      value.startedAt,
      value.started_at,
      value.submittedAt,
      value.completedAt,
      value.updatedAt,
      value.timestamp,
      value.time
    ];
    for (const candidate of candidates) {
      if (candidate === undefined || candidate === null || candidate === "") continue;
      if (typeof candidate === "number" && Number.isFinite(candidate)) {
        return candidate > 100000000000 ? Math.floor(candidate) : Math.floor(candidate * 1000);
      }
      const parsed = Date.parse(String(candidate));
      if (Number.isFinite(parsed)) return parsed;
    }
    return 0;
  }

  function filterFleetGenState(result, payload = {}) {
    if (!result || typeof result !== "object") return result;
    const prompts = promptFiltersFromPayload(payload);
    const minTimestampMs = Number(payload.runStartedAtMs || payload.startedAtMs || 0) || 0;
    if (!prompts.length && !minTimestampMs) return result;
    const filterArray = (items) => items.filter((item) => {
      if (!item || typeof item !== "object") return false;
      const prompt = compactString(item.prompt || item.text || item.inputPrompt || "");
      const promptMatch = prompts.length ? prompts.includes(prompt) : true;
      if (!promptMatch) return false;
      const itemTimestampMs = timestampMs(item);
      return !minTimestampMs || !itemTimestampMs || itemTimestampMs >= minTimestampMs;
    });
    const next = { ...result };
    let filtered = false;
    for (const key of ["items", "jobs", "records", "tasks", "generations"]) {
      if (!Array.isArray(result[key])) continue;
      next[key] = filterArray(result[key]);
      filtered = true;
    }
    if (filtered) {
      next.__autoFlowFiltered = {
        promptFilters: prompts,
        runStartedAtMs: minTimestampMs || null
      };
    }
    return next;
  }

  function baseEnvelope(payload = {}) {
    return {
      action: payload.action || "fleetGenInvoke",
      method: compactString(payload.method || String(payload.action || "").replace(/^fleetGen\./, "")),
      fleetGenBridgeVersion: BRIDGE_VERSION,
      href: location.href,
      projectId: projectIdFromUrl()
    };
  }

  function sanitize(value, seen = new WeakSet(), options = {}) {
    const includeMediaBytes = options.includeMediaBytes === true;
    if (value === null || value === undefined) return value;
    if (typeof value === "string") {
      if (!includeMediaBytes && value.length > 1000 && /^data:|^[A-Za-z0-9+/=]{1000,}$/.test(value)) {
        return `[omitted:${value.length}]`;
      }
      return value;
    }
    if (typeof value !== "object") return value;
    if (seen.has(value)) return "[circular]";
    seen.add(value);
    let out;
    if (Array.isArray(value)) {
      out = value.map((entry) => sanitize(entry, seen, options));
    } else {
      out = {};
      for (const [key, entry] of Object.entries(value)) {
        if (!includeMediaBytes && /^(base64|dataBase64|imageBytes|videoBytes|blob|previewDataUrl|dataUrl)$/i.test(key)) {
          out[key] = entry ? `[omitted:${String(entry).length}]` : entry;
          continue;
        }
        out[key] = sanitize(entry, seen, options);
      }
    }
    seen.delete(value);
    return out;
  }

  async function invokeFleetGen(payload = {}) {
    const envelope = baseEnvelope(payload);
    const method = envelope.method;
    const api = window.fleetGen;
    const diagnostics = () => ({ handshake: handshakeState(), directSdk: directSdkProbe() });
    const base = {
      ...envelope,
      hasFleetGen: Boolean(api && typeof api === "object"),
      availableMethods: availableMethods(api),
      ...(method === "ping" ? diagnostics() : {})
    };
    if (!api || typeof api !== "object") {
      return {
        ...base,
        ...(method === "ping" ? {} : diagnostics()),
        ok: false,
        error: "FLEETGEN_API_UNAVAILABLE"
      };
    }
    if (method === "ping" && typeof api.ping !== "function") {
      return {
        ...base,
        ok: true,
        result: {
          ok: true,
          synthetic: true,
          reason: "fleetgen_present",
          availableMethods: base.availableMethods
        }
      };
    }
    if (!METHODS.has(method) || typeof api[method] !== "function") {
      return {
        ...base,
        ...(method === "ping" ? {} : diagnostics()),
        ok: false,
        error: "FLEETGEN_METHOD_UNAVAILABLE"
      };
    }
    let result;
    if (method === "executeDirect") {
      const prompt = String(payload.prompt ?? payload.text ?? payload.promptsText ?? "");
      const config = payload.config && typeof payload.config === "object" ? payload.config : {};
      result = await api.executeDirect(prompt, config);
    } else if (method === "setPrompts") {
      result = await api.setPrompts(String(payload.text ?? payload.promptsText ?? ""));
    } else if (method === "updateSettings") {
      const config = payload.config && typeof payload.config === "object" ? payload.config : {};
      result = await api.updateSettings(config);
    } else if (method === "launch" || method === "normalizeInputs") {
      // Pass one atomic options object so launch does not depend on React state
      // settling after separate setPrompts/updateSettings calls.
      const config = payload.config && typeof payload.config === "object" ? payload.config : {};
      result = await api[method](config);
    } else if (method === "getResult") {
      result = await api.getResult(compactString(payload.commandId || payload.id));
    } else if (method === "version") {
      result = typeof api.version === "function" ? await api.version() : api.version;
    } else {
      result = await api[method]();
    }
    if (method === "getState") {
      result = filterFleetGenState(result, payload);
    }
    return {
      ...base,
      ok: true,
      result: sanitize(result, new WeakSet(), { includeMediaBytes: payload.includeMediaBytes === true })
    };
  }

  const handler = (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== SOURCE || data.type !== "af.rebuild.fleetgen.command") return;
    Promise.resolve()
      .then(() => invokeFleetGen(data.payload || {}))
      .then((payload) => {
        window.postMessage({
          source: SOURCE,
          type: "af.rebuild.fleetgen.command.result",
          requestId: data.requestId,
          payload
        }, "*");
      })
      .catch((error) => {
        window.postMessage({
          source: SOURCE,
          type: "af.rebuild.fleetgen.command.result",
          requestId: data.requestId,
          payload: {
            ok: false,
            ...baseEnvelope(data.payload || {}),
            error: compactString(error?.message || error || "fleetgen_command_failed")
          }
        }, "*");
      });
  };

  window.__afFleetGenMessageHandler = handler;
  window.addEventListener("message", handler);
})();
