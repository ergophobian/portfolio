import { FLOW_MODES, STORAGE_KEY } from "./runtime-config.js";
import { agentRunIsCanonical, agentRunMatchesActiveProject, isAgentRunTerminal, liveQueueItemsForProject } from "./agent-live-presentation.js";
import { LANGUAGE_OPTIONS, translate } from "./i18n.js";
import { renderControlWizard } from "./views/control-wizard.js";
import { showConfirm } from "./dialog.js";
import { buildMediaRedirectUrl, buildMediaThumbnailUrl, normalizeMediaRedirectUrl, normalizeMediaThumbnailUrl } from "../core/contracts/api.js";
import { buildGalleryItemsFromTasks, canonicalGalleryItems, deriveTaskOutputLedger, filterGalleryItemsForProject, filterUsableGalleryItems, generatedOutputMediaIdsFromTasks, referenceMediaIdsFromTasks } from "../core/gallery/media-ledger.js";
import { matchedReferenceIdsForPrompt } from "../core/gallery/animate-prompts.js";
import { totalSceneDuration } from "../core/gallery/scene-builder.js";
import { buildRecoveryReportFields } from "../core/queue/recovery-policy.js";
import { buildRetryModalTask } from "../core/queue/video-retry-policy.js";
import { cleanGalleryPromptText, galleryDisplayLabel, galleryPromptLabel, galleryPromptPreview } from "./gallery-text.js";

const PRO_PLANS = new Set(["pro", "team"]);
const ACTIVE_SUBSCRIPTION_STATUSES = new Set(["active", "trialing"]);
const REVIEW_DUCK_DONE_STATUSES = new Set(["complete", "done"]);
const REVIEW_DUCK_SUPPORT_STATUSES = new Set(["failed", "blocked", "download_failed", "download_incomplete", "partial"]);
const REVIEW_DUCK_ACTIVE_STATUSES = new Set(["starting", "submitting", "generating", "downloading", "retrying", "pending", "queued", "waiting"]);
const REVIEW_DUCK_ACTION_KEYS = Object.freeze({
  success: ["chromeStore"],
  support: ["discord", "telegram", "exportReport"]
});

function el(tag, opts, ...kids) {
  const node = document.createElement(tag);
  if (opts) {
    if (opts.class) node.className = opts.class;
    if (opts.id) node.id = opts.id;
    if (opts.text != null) node.textContent = opts.text;
    if (opts.value != null) node.value = opts.value;
    if (opts.checked != null) node.checked = Boolean(opts.checked);
    if (opts.data) {
      for (const [key, value] of Object.entries(opts.data)) node.dataset[key] = value;
    }
    if (opts.style) {
      for (const [key, value] of Object.entries(opts.style)) node.style[key] = value;
    }
    if (opts.attrs) {
      for (const [key, value] of Object.entries(opts.attrs)) {
        if (value == null || value === false) continue;
        node.setAttribute(key, value === true ? "" : value);
      }
    }
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    node.appendChild(typeof kid === "string" ? document.createTextNode(kid) : kid);
  }
  return node;
}

const icon = (name) => el("span", { class: "material-symbols-outlined", text: name });
const clear = (root) => { while (root.firstChild) root.removeChild(root.firstChild); };

const IMAGE_REFERENCE_SLOTS = [
  ["imagePromptRefs", "Image Reference", "image"],
  ["styleRefRefs", "Style Reference", "palette"],
  ["omniRefRefs", "Character Reference", "face"]
];

const VIDEO_REFERENCE_SLOTS = [
  ["startFrameRef", "Start Frame", "first_page"],
  ["endFrameRef", "End Frame", "last_page"],
  ["ingredientsRefs", "Ingredient Refs", "deployed_code"]
];

const INGREDIENT_REFERENCE_SLOTS = [
  ["ingredientsRefs", "Ingredients", "deployed_code"]
];

const VIDEO_MODEL_OPTIONS = [
  ["omni_flash", "Omni Flash"],
  ["veo3_lite", "Veo 3.1 - Lite"],
  ["default", "Default (Veo 3.1 - Lite [Lower Priority])"],
  ["veo3_lite_low", "Veo 3.1 - Lite [Lower Priority]"],
  ["veo3_fast", "Veo 3.1 - Fast"],
  ["veo3_fast_low", "Veo 3.1 - Fast [Lower Priority]"],
  ["veo3_quality", "Veo 3.1 - Quality"],
  ["veo2_fast", "Veo 2 - Fast"],
  ["veo2_quality", "Veo 2 - Quality"]
];

const INGREDIENTS_VIDEO_MODEL_OPTIONS = [
  ["omni_flash", "Omni Flash"],
  ["veo3_fast_low", "Veo 3.1 - Fast [Lower Priority]"],
  ["veo3_fast", "Veo 3.1 - Fast"]
];

function idsFromRefs(value = "") {
  return String(value || "").split(/\s+/).map((entry) => entry.trim()).filter(Boolean);
}

function allActiveRefIds(state) {
  return Object.values(state.control.references || {}).flatMap(idsFromRefs);
}

function oneToOneBatchRefIds(state) {
  return Array.isArray(state.control.oneToOneBatchRefIds)
    ? state.control.oneToOneBatchRefIds.map((id) => String(id || "").trim()).filter(Boolean)
    : [];
}

function savedReference(state, id) {
  return [
    ...(state.control?.transientReferenceItems || []),
    ...(state.referenceLibrary.savedItems || [])
  ].find((item) => item.id === id) || null;
}

function referenceRolesForMode(state) {
  if (state.control.mode === FLOW_MODES.textToImage) return ["imagePromptRefs", "styleRefRefs", "omniRefRefs"];
  if (state.control.mode === FLOW_MODES.ingredientsToVideo) return ["ingredientsRefs"];
  if (state.control.mode === FLOW_MODES.imageToVideo) return ["startFrameRef", "endFrameRef"];
  return [];
}

function mappingSourceRefIds(state) {
  const batchIds = oneToOneBatchRefIds(state);
  if (batchIds.length) return batchIds;
  return referenceRolesForMode(state).flatMap((role) => idsFromRefs(state.control.references?.[role]));
}

function mappingSourceRefs(state) {
  return mappingSourceRefIds(state)
    .map((id) => savedReference(state, id))
    .filter(Boolean);
}

function promptMapKey(_prompt, index) {
  return `line:${index}`;
}

function promptMapRows(state, prompts) {
  const promptRefMap = state.control.promptRefMap || {};
  const sourceIds = mappingSourceRefIds(state);
  const oneToOneIds = oneToOneBatchRefIds(state);
  const hasOneToOne = oneToOneIds.length > 0;
  const frameMode = state.control.mode === FLOW_MODES.imageToVideo;
  return prompts.map((prompt, index) => {
    const key = promptMapKey(prompt, index);
    const hasExplicitMap = Object.prototype.hasOwnProperty.call(promptRefMap, key);
    let effectiveIds = [];
    if (hasExplicitMap) {
      effectiveIds = Array.isArray(promptRefMap[key]) ? promptRefMap[key].filter((id) => sourceIds.includes(id)) : [];
    } else if (state.control.activeApplyMode === "match") {
      effectiveIds = matchedReferenceIdsForPrompt(prompt, sourceIds.map((id) => savedReference(state, id)).filter(Boolean), {
        limit: frameMode ? 2 : state.control.mode === FLOW_MODES.ingredientsToVideo ? 3 : 10
      });
    } else if (hasOneToOne) {
      if (frameMode && oneToOneIds.length >= prompts.length * 2) {
        effectiveIds = [oneToOneIds[index] || "", oneToOneIds[index + prompts.length] || ""].filter(Boolean);
      } else {
        effectiveIds = oneToOneIds[index] ? [oneToOneIds[index]] : [];
      }
    } else {
      effectiveIds = sourceIds;
    }
    return { key, prompt, index, effectiveIds };
  });
}

function referenceSlot(role, label, iconName, state) {
  const values = idsFromRefs(state.control.references[role]);
  const first = values.length ? savedReference(state, values[0]) : null;
  const active = Boolean(first);
  const media = active
    ? el("img", { attrs: { src: first.imageUrl || first.dataUrl || first.mediaUrl, alt: label, loading: "lazy" } })
    : icon(iconName);

  return el("div", { class: `reference-slot${active ? " has-image" : ""}` },
    el("button", {
      class: "reference-pick",
      data: { refRole: role },
      attrs: { type: "button", title: active ? `Change ${label}` : `Add ${label}` }
    },
      el("span", { class: "reference-media" }, media),
      el("span", { class: "reference-copy" },
        el("span", { class: "reference-title", text: label }),
        el("span", { class: "reference-meta", text: active ? `${values.length} image${values.length === 1 ? "" : "s"}` : "Add image" })
      )
    ),
    active ? el("button", {
      class: "reference-clear",
      data: { refClear: role },
      attrs: { type: "button", title: `Clear ${label}` }
    }, icon("close")) : null
  );
}

function modeBtn(active, mode, label, iconName) {
  return el("button", {
    class: `mode-btn${active ? " active" : ""}`,
    data: { mode },
    attrs: { type: "button" }
  }, icon(iconName), el("span", { text: label }));
}

function routeBtn(active, dataVal, label) {
  return el("button", {
    class: `route-btn${active ? " active" : ""}`,
    data: { submitPath: dataVal },
    attrs: { type: "button" }
  }, el("span", { text: label }));
}

function chip(active, dataKey, dataVal, label) {
  return el("button", {
    class: `chip${active ? " active" : ""}`,
    data: { [dataKey]: dataVal },
    attrs: { type: "button" },
    text: label
  });
}

function durationBtn(active, seconds) {
  return el("button", {
    class: `duration-btn${active ? " active" : ""}`,
    data: { videoLength: seconds },
    attrs: { type: "button" },
    text: `${seconds}s`
  });
}

// Suppress stale checkout-flow messages once the account is verified Pro.
// Messages set during sign-in/checkout (sendAccountCode, verifyAccountCode,
// openCheckout) shouldn't linger after the subscription activates — the
// PRO badge speaks for itself.
function visibleAccountMessage(state) {
  const message = state?.account?.message || "";
  if (!message) return "";
  if (hasProAccess(state) && /checkout|sign in once|signed in/i.test(message)) return "";
  return message;
}

function hasProAccess(state) {
  const account = state.account || {};
  if (account.status !== "signed_in") return false;
  if (!PRO_PLANS.has(account.plan)) return false;
  return ACTIVE_SUBSCRIPTION_STATUSES.has(account.subscriptionStatus) || account.plan === "team";
}

function hasGenerationAccess(state) {
  const account = state.account || {};
  if (hasProAccess(state)) return true;
  const usage = account.usage || {};
  return usage.allowed !== false && Number(usage.remaining || 0) > 0;
}

function formatUsageLine(account) {
  const usage = account.usage || {};
  if (usage.unlimited) return "Unlimited prompts";
  const used = Number.isFinite(Number(usage.used)) ? Number(usage.used) : 0;
  const limit = Number.isFinite(Number(usage.limit)) ? Number(usage.limit) : 10;
  return `${Math.min(used, limit)}/${limit} prompts today`;
}

function isAccountReadyForGeneration(state) {
  return state.account?.status === "signed_in" && hasGenerationAccess(state);
}

function formatResetLine(account) {
  const resetAt = account?.usage?.resetAt;
  if (!resetAt) return "Resets daily";
  const resetDate = new Date(resetAt);
  if (Number.isNaN(resetDate.getTime())) return "Resets daily";
  return `Resets ${resetDate.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
}

function authRetryLine(account, locale = "en") {
  if (!account?.authCodeResendAvailableAt) return "";
  const date = new Date(account.authCodeResendAvailableAt);
  if (Number.isNaN(date.getTime()) || date.getTime() <= Date.now()) return "";
  return translate("authRetryAfter", { time: date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) }, locale);
}

function renderAccountGate(state) {
  const account = state.account || {};
  const locale = state.control?.presets?.language || "en";
  const hasPro = hasProAccess(state);
  const signedIn = account.status === "signed_in";
  const pendingCode = account.status === "pending_confirmation";
  const pendingCheckout = Boolean(account.pendingCheckout);
  const retryLine = authRetryLine(account, locale);
  const resendBlocked = Boolean(retryLine);
  const usage = account.usage || {};
  const used = Number.isFinite(Number(usage.used)) ? Number(usage.used) : 0;
  const limit = Number.isFinite(Number(usage.limit)) ? Number(usage.limit) : 10;
  const pct = usage.unlimited ? 100 : Math.max(0, Math.min(100, (used / limit) * 100));
  const barClass = pct >= 100 ? "critical" : pct >= 70 ? "warning" : "";

  return el("div", { id: "freemiumBanner", class: hasPro ? "" : "is-visible" },
    el("div", { class: "banner-top" },
      el("span", { class: "banner-tier" }, icon("token"), translate(hasPro ? "proPlan" : "freePlan", {}, locale)),
      el("span", { class: "banner-usage", id: "bannerUsageText", text: formatUsageLine(account) })
    ),
    el("p", { class: "auth-email-hint banner-email-hint", text: signedIn ? translate("signedInUsageVerified", {}, locale) : translate("signInRequired", {}, locale) }),
    account.degradedLocalMode ? el("p", { class: "auth-email-hint account-degraded-local-mode", text: translate("authDegradedLocalMode", {}, locale) }) : null,
    el("div", { class: "usage-bar" },
      el("div", { class: `usage-bar-fill ${barClass}`.trim(), id: "bannerUsageBar", style: { width: `${pct}%` } })
    ),
    el("div", { id: "bannerResetTimer", style: { display: signedIn && !usage.unlimited && Number(usage.remaining || 0) <= 0 ? "block" : "none" } },
      icon("timer"),
      " Resets in ",
      el("span", { id: "bannerResetCountdown", text: formatResetLine(account).replace(/^Resets /, "") })
    ),
    el("div", { class: "banner-limits" },
      el("span", { class: "limit-item" }, icon("lock"), " 2K/4K downloads"),
      el("span", { class: "limit-item" }, icon("lock"), " 1080p/4K video"),
      el("span", { class: "limit-item" }, icon("lock"), " Multi-output (2-4)"),
      el("span", { class: "limit-item" }, icon("lock"), " Auto-download")
    ),
    el("button", { class: "banner-upgrade-btn", id: "bannerUpgradeBtn", attrs: { type: "button" } },
      icon("rocket_launch"),
      el("span", { text: translate("unlockPro", {}, locale) })
    ),
    !signedIn ? el("div", { id: "bannerAuthFlow", style: { display: "block", marginTop: "8px" } },
      el("div", { id: "bannerEmailStep", style: { display: pendingCode ? "none" : "flex", gap: "6px" } },
        el("input", { id: "bannerEmailInput", attrs: { type: "email", placeholder: "your@email.com", autocomplete: "email" } }),
        el("button", { id: "bannerSendCodeBtn", attrs: { type: "button" } }, el("span", { class: "auth-send-code-label", text: translate("sendCode", {}, locale) }))
      ),
      el("div", { id: "bannerOtpStep", style: { display: pendingCode ? "block" : "none", marginTop: "6px" } },
        el("p", { class: "auth-email-hint", text: translate("checkEmail", {}, locale) }),
        account.authCodeRequestError ? el("p", { class: "auth-email-hint account-error", text: account.authCodeRequestError }) : null,
        retryLine ? el("p", { class: "auth-email-hint account-rate-limit", text: retryLine }) : null,
        el("div", { style: { display: "flex", gap: "6px" } },
          el("input", { id: "bannerOtpInput", attrs: { type: "text", placeholder: translate("enterCode", {}, locale), maxlength: "10", autocomplete: "one-time-code", inputmode: "numeric" } }),
          el("button", { id: "bannerVerifyBtn", attrs: { type: "button" }, text: translate("verify", {}, locale) })
        ),
        el("p", { class: "auth-email-hint", text: translate("authNoCodeHelp", {}, locale) }),
        el("div", { class: "auth-recovery-actions" },
          el("button", { id: "bannerResendCodeBtn", class: "small-btn", attrs: { type: "button", disabled: resendBlocked ? "disabled" : null } }, icon("mail"), el("span", { text: translate("authResendCode", {}, locale) })),
          el("button", { id: "bannerChangeEmailBtn", class: "small-btn", attrs: { type: "button" } }, icon("edit"), el("span", { text: translate("authChangeEmail", {}, locale) })),
          el("button", { id: "bannerBackToExtensionBtn", class: "small-btn", attrs: { type: "button" } }, icon("arrow_back"), el("span", { text: translate("authBackToExtension", {}, locale) })),
          el("button", { id: "bannerCopySupportBtn", class: "small-btn", attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
          el("button", { id: "bannerExportReportBtn", class: "small-btn", attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
        )
      )
    ) : null
  );
}

function referenceSlotsForMode(state) {
  if (state.control.mode === FLOW_MODES.ingredientsToVideo) return INGREDIENT_REFERENCE_SLOTS;
  if (state.control.mode === FLOW_MODES.imageToVideo) return VIDEO_REFERENCE_SLOTS;
  if (state.control.mode === FLOW_MODES.textToImage) return IMAGE_REFERENCE_SLOTS;
  return [];
}

function buildStatusText(state, pending, submitted) {
  if (state.runtime.error) return state.runtime.error;
  if (state.queue.running) return `Running ${submitted || pending} job${submitted + pending === 1 ? "" : "s"}`;
  if (state.runtime.connected) return state.runtime.projectId ? `Connected to ${state.runtime.projectId}` : "Connected to Flow";
  return "Capture a Flow project tab to run the queue.";
}

export function renderControl(root, state, actions = {}) {
  // 10.8 wizard surface — Phase C. Replaces the legacy single-page Control layout.
  // Lifted from design-preview/variant-e.html via /plan-design-review and locked in /plan-eng-review.
  // Legacy renderControl logic preserved below the early-return for reference / rollback.
  renderControlWizard(root, state, {
    dispatch: makeWizardDispatch(state),
    showConfirm,
    onRun: actions.onRun,
    onAddToQueue: actions.onAddToQueue,
    onStartQueue: actions.onStartQueue,
  });
  return;

  // ── Legacy single-page Control rendering (unreachable while wizard is active) ── @i18n-skip
  clear(root);
  const pending = state.queue.items.filter((item) => item.status === "pending" || item.status === "waiting").length;
  const submitted = state.queue.items.filter((item) => item.status === "submitted" || item.status === "submitting" || item.status === "generating").length;
  const accountLocked = !isAccountReadyForGeneration(state);
  const refs = referenceSlotsForMode(state);
  const prompts = promptLines(state);
  const activeRefs = mappingSourceRefIds(state).length;
  const promptMapEnabled = Boolean(state.control.presets.mapLineRefs);
  const queueGroupCount = queueGroups(state.queue.items).length;
  const mappedRows = promptMapRows(state, prompts).filter((row) => row.effectiveIds.length > 0).length;
  const openInlineHelp = String(state.ui.openInlineHelpPanel || "");

  const modeSection = el("div", { id: "modeSelectionContainer", class: "mode-selection-container" },
    el("div", { id: "modeButtonGrid", class: "mode-button-grid" },
      modeBtn(state.control.mode === FLOW_MODES.textToImage, FLOW_MODES.textToImage, "Create Image", "palette"),
      modeBtn(state.control.mode === FLOW_MODES.textToVideo, FLOW_MODES.textToVideo, "Text to Video", "videocam"),
      modeBtn(state.control.mode === FLOW_MODES.imageToVideo, FLOW_MODES.imageToVideo, "Frame to Video", "image"),
      modeBtn(state.control.mode === FLOW_MODES.ingredientsToVideo, FLOW_MODES.ingredientsToVideo, "Ingredients", "grid_view")
    ),
    el("select", { id: "modeSelector", style: { display: "none" } },
      [
        [FLOW_MODES.textToVideo, "Text-to-Video"],
        [FLOW_MODES.imageToVideo, "Frame-to-Video"],
        [FLOW_MODES.ingredientsToVideo, "Ingredients to Video"],
        [FLOW_MODES.textToImage, "Create Image"]
      ].map(([value, label]) => el("option", { value, attrs: { value, selected: state.control.mode === value ? "selected" : null }, text: label }))
    )
  );

  const ingredientsMode = state.control.mode === FLOW_MODES.ingredientsToVideo;
  const omniT2v = state.control.mode === FLOW_MODES.textToVideo && /^(omni_flash|omni|abra)$/i.test(String(state.control.presets.model || ""));
  const omniI2v = state.control.mode === FLOW_MODES.imageToVideo && /^(omni_flash|omni|abra)$/i.test(String(state.control.presets.model || ""));
  const omniIngredients = ingredientsMode && /^(omni_flash|omni|abra)$/i.test(String(state.control.presets.ingredientsModel || ""));
  const activeVideoLength = ingredientsMode && !omniIngredients ? "8" : (state.control.presets.videoLength || "8");
  const durationChoices = (omniT2v || omniI2v || omniIngredients) ? ["4", "6", "8", "10"] : (ingredientsMode ? ["8"] : ["4", "6", "8"]);
  const videoDurationSection = state.control.mode !== FLOW_MODES.textToImage ? el("div", { id: "videoDurationSettingsRow", class: "video-duration-settings" },
    el("span", { class: "video-duration-label", text: "Video Length" }),
    el("div", { id: "videoDurationButtonRow", class: "duration-button-row" },
      durationChoices.map((seconds) => durationBtn(activeVideoLength === seconds, seconds))
    ),
    el("input", { id: "videoDurationSecondsInput", value: activeVideoLength, attrs: { type: "hidden" } })
  ) : null;

  const routeSection = el("div", { id: "submitRouteSettingsRow", class: "video-duration-settings submit-route-settings" },
    el("span", { class: "video-duration-label", text: "Submit Route" }),
    el("div", { id: "submitRouteButtonRow", class: "route-button-row" },
      routeBtn(state.control.presets.submitPath === "dom_first", "dom_first", "DOM"),
      routeBtn(state.control.presets.submitPath === "agent_first", "agent_first", "Agent"),
      routeBtn(state.control.presets.submitPath === "api_first", "api_first", "API")
    )
  );

  const hiddenCaptureButton = el("button", {
    id: "captureButton",
    class: "hidden-flow-capture",
    attrs: { type: "button", "aria-hidden": "true", tabindex: "-1" }
  }, "Capture Flow Project");

  const referenceSection = el("div", { id: "referenceImagesSection", class: "reference-library-section" },
    el("div", { class: "section-header collapsible-header" },
      el("span", { class: "section-title", text: "Reference Library" }),
      el("span", { id: "refImageCount", class: "sample-link", text: `(${(state.referenceLibrary.savedItems || []).length} saved)` }),
      el("button", { id: "uploadRefImageBtn", attrs: { type: "button" } }, icon("add_photo_alternate"), el("span", { text: "Add to library" })),
      icon("expand_more")
    ),
    el("input", { id: "refImageInput", attrs: { type: "file", accept: ".png,.jpg,.jpeg,.webp,.heic,.avif", multiple: true, hidden: true } }),
    el("input", { id: "imageInput", attrs: { type: "file", accept: ".png,.jpg,.jpeg,.webp,.heic,.avif", multiple: true, hidden: true } }),
    state.control.mode === FLOW_MODES.imageToVideo ? el("p", { id: "frameHint", class: "setting-hint compact-ref-hint", text: "1st image = First Frame, 2nd image = Last Frame (optional)" }) : null,
    refs.length ? el("div", { class: "active-reference-summary" },
      icon("checklist"),
      el("span", { text: activeRefs ? `${activeRefs} active reference${activeRefs === 1 ? "" : "s"}` : "Click library images to activate references for this mode." })
    ) : null,
    renderReferenceLibraryGrid(state)
  );

  const inputSection = el("div", { id: "promptContainer", class: "control-section input-container" },
    el("div", { class: "section-label", text: "Input" }),
    el("div", { class: "prompt-input-toolbar" },
      el("div", { class: "prompt-input-title" },
        el("span", { text: "Prompt List" }),
        el("a", { class: "sample-link", attrs: { href: "/sample_prompt_formats.html", target: "_blank", rel: "noopener noreferrer", id: "samplePromptLink" }, text: "(Format Guide)" })
      ),
      el("button", { id: "uploadPromptButton", class: "small-btn", attrs: { type: "button" } }, icon("upload_file"), el("span", { text: "Import file (.txt)" })),
      el("input", { id: "fileInput", attrs: { type: "file", accept: ".txt,text/plain", hidden: true } })
    ),
    el("div", { id: "imageModeContainer", class: "queue-image-upload-row" },
      el("div", { class: "queue-image-upload-copy" },
        el("span", { class: "queue-image-upload-title", text: "Queue Images" })
      ),
      el("div", { class: "image-upload-row" },
        el("button", { id: "uploadImageButton", class: "image-upload-option", attrs: { type: "button" } }, icon("upload_file"), el("span", { text: "Shared Ref Upload" })),
        el("button", { id: "imageMultiPromptHelpBtn", class: "image-inline-help", attrs: { type: "button", title: "How Shared Ref Upload works" }, text: "?" }),
        el("button", { id: "uploadImageOneTimeButton", class: "image-upload-option one-to-one", attrs: { type: "button" } }, icon("bolt"), el("span", { text: "1:1 Batch Upload" })),
        el("button", { id: "imageOneTimeHelpBtn", class: "image-inline-help", attrs: { type: "button", title: "How 1:1 Batch Upload works" }, text: "?" })
      ),
      el("div", { class: "summary-wrapper", style: { display: oneToOneBatchRefIds(state).length ? "flex" : "none" } },
        el("p", { id: "imageFileSummary" }, "Selected: ", el("span", { id: "imageCount", text: String(oneToOneBatchRefIds(state).length) }))
      ),
      el("div", { id: "imageMultiPromptHelpPanel", class: `image-help-panel${openInlineHelp === "imageMultiPromptHelpPanel" ? " open" : ""}`, text: "Same image(s) used as reference for all prompts. Upload once, every prompt gets the same ref. Great for a consistent style or subject across a batch." }),
      el("div", { class: "image-bulk-controls" },
        el("span", { class: "image-bulk-toggle-text", text: "Bulk mode: 1 image per prompt (line order)" }),
        el("label", { class: "image-bulk-switch", attrs: { for: "imageToVideoBulkToggle" } },
          el("input", { id: "imageToVideoBulkToggle", checked: oneToOneBatchRefIds(state).length > 0, attrs: { type: "checkbox" } }),
          el("span", { class: "image-bulk-switch-slider" })
        ),
        el("button", { id: "imageBulkHelpBtn", class: "image-inline-help", attrs: { type: "button", title: "How bulk mode works" }, text: "?" })
      ),
      el("div", { class: "image-bulk-controls" },
        el("span", { class: "image-bulk-toggle-text", text: "Repeat first prompt for all uploaded images" }),
        el("label", { class: "image-bulk-switch", attrs: { for: "imageSamePromptToggle" } },
          el("input", { id: "imageSamePromptToggle", attrs: { type: "checkbox" } }),
          el("span", { class: "image-bulk-switch-slider" })
        ),
        el("button", { id: "imageSamePromptHelpBtn", class: "image-inline-help", attrs: { type: "button", title: "How same-prompt mode works" }, text: "?" })
      ),
      el("div", { id: "imageBulkHelpPanel", class: `image-help-panel${openInlineHelp === "imageBulkHelpPanel" ? " open" : ""}`, text: "Bulk mode maps prompt line 1 to image 1, line 2 to image 2, and so on." }),
      el("div", { id: "imageOneTimeHelpPanel", class: `image-help-panel${openInlineHelp === "imageOneTimeHelpPanel" ? " open" : ""}`, text: "Each image maps to one prompt in order: image 1 -> prompt 1, image 2 -> prompt 2. Images are also tracked as a 1:1 batch." }),
      el("div", { id: "imageSamePromptHelpPanel", class: `image-help-panel${openInlineHelp === "imageSamePromptHelpPanel" ? " open" : ""}`, text: "When enabled, the first prompt is repeated for every uploaded image." })
    ),
    referenceSection,
    renderWorkflowHint(),
    el("textarea", {
      id: "prompts",
      class: "prompt-textarea",
      value: state.control.livePrompt,
      attrs: { rows: "5", placeholder: "One prompt per line." }
    }),
    el("div", { class: "prompt-map-controls" },
      el("label", { class: "prompt-map-toggle", attrs: { for: "promptMapToggle" } },
        el("input", { id: "promptMapToggle", checked: promptMapEnabled, attrs: { type: "checkbox" } }),
        el("span", { text: "Map references by prompt" })
      ),
      el("button", { id: "promptMapHelpBtn", class: "prompt-map-help-btn", attrs: { type: "button", title: "How mapping works" }, text: "?" }),
      el("span", { id: "promptInlineSummary", text: `${prompts.length} prompts \u2022 ${activeRefs} refs active \u2022 ${mappedRows} mapped` })
    ),
    el("div", { id: "promptMapHelpPanel", class: "prompt-map-help-panel", style: { display: state.control.promptMapOpen ? "block" : "none" }, text: "Activate one or more reference images, paste your prompts, then use mapped rows to control which refs attach to each prompt." }),
    renderPromptAssignList(state, prompts),
    el("div", { class: "prompt-queue-actions" },
      el("button", {
        id: "addToQueueButton",
        class: "button-primary",
        attrs: { type: "button", disabled: accountLocked ? "disabled" : null }
      }, icon("add_to_queue"), el("span", { text: "Add to Queue" })),
      el("button", { id: "openQueueButton", attrs: { type: "button" } },
        icon("list_alt"),
        el("span", { text: "Manage" }),
        el("span", { class: "queue-count-pill" }, "(", el("span", { id: "queueTaskCount", text: String(queueGroupCount) }), ")")
      )
    )
  );

  const queueSection = el("div", { class: "control-section" },
    el("div", { class: "section-label", text: "Queue" }),
    el("div", { class: "queue-controls" },
      el("button", { id: "clearQueueButton", attrs: { type: "button", title: "Clear queue", disabled: state.queue.running ? "disabled" : null } }, icon("delete_sweep"))
    ),
    renderQueueList(state.queue.items),
    el("div", { class: "auto-toggles-row" },
      el("label", { class: "auto-toggle-pill", attrs: { for: "autoStartNextJob" } },
        el("input", { id: "autoStartNextJob", checked: state.control.presets.autoStartNextJob, attrs: { type: "checkbox" } }),
        el("span", { text: "Auto-start next job in queue" })
      ),
      el("label", { class: "auto-toggle-pill", attrs: { for: "autoRetryFailedToggle" } },
        el("input", { id: "autoRetryFailedToggle", checked: state.control.presets.autoRetryFailedUntilZero, attrs: { type: "checkbox" } }),
        el("span", { text: "Auto retry failed until 0 (max 12 rounds)" })
      )
    )
  );

  const actionControls = el("div", { class: "action-controls" },
    el("div", { id: "startControlContainer" },
      el("button", {
        id: "mainActionButton",
        class: "button-primary",
        attrs: { type: "button", disabled: state.queue.running || accountLocked ? "disabled" : null, title: "Start Queue" }
      }, icon("play_arrow"), el("span", { text: state.queue.running ? "Running" : "Start Queue" })),
      el("button", { id: "startNewProjectButton", style: { display: "none" }, attrs: { type: "button" }, text: "Start New Project" }),
      el("button", { id: "startCurrentProjectButton", style: { display: "none" }, attrs: { type: "button" }, text: "Start Current Project" })
    ),
    el("button", { id: "skipJobButton", attrs: { type: "button", title: "Skip to next job", disabled: state.queue.running ? null : "disabled" } }, icon("skip_next"), el("span", { text: "Skip" })),
    el("button", { id: "stopButton", attrs: { type: "button", disabled: state.queue.running ? null : "disabled" } }, icon("stop"), el("span", { text: "Stop" }))
  );

  root.append(hiddenCaptureButton, modeSection, videoDurationSection, routeSection, renderAccountGate(state), inputSection, queueSection, actionControls);
}

export function renderHistory(root, state) {
  clear(root);
  const locale = state.control?.presets?.language || "en";
  const runs = Array.isArray(state.history?.runs) ? state.history.runs : [];
  root.append(
    el("div", { class: "history-view" },
      el("div", { class: "history-head" },
        el("div", null,
          el("div", { class: "section-label", text: "History" }),
          el("h2", { text: translate("pastPromptRuns", {}, locale) }),
          el("p", { text: translate("restoreRunHelp", {}, locale) })
        ),
        el("button", {
          id: "history-clear-btn",
          attrs: { type: "button", disabled: runs.length ? null : "disabled" }
        }, icon("delete_sweep"), el("span", { text: "Clear" }))
      ),
      runs.length
        ? el("div", { class: "history-list" }, runs.map((run) => renderHistoryCard(run, locale)))
        : el("div", { class: "history-empty" },
          icon("history"),
          el("strong", { text: translate("noPromptHistoryYet", {}, locale) }),
          el("span", { text: translate("autoFlowSaveHint", {}, locale) })
        )
    )
  );
}

function renderHistoryCard(run = {}, locale = "en") {
  // 3-row layout for scannability:
  //   1. Mode icon + label · count   |   time + route pill
  //   2. Prompt preview (prominent, not italic)
  //   3. Refs pill / thumbs   |   actions (Edit, Run again, Delete)
  //
  // Mode-specific accent colors via modeAccentClass help the eye pick out
  // entry types at a glance — gold for images, blue for video, purple
  // for ingredients.
  const refs = Array.isArray(run.refs) ? run.refs : [];
  const prompts = String(run.promptsText || "").split(/\n+/).map((line) => line.trim()).filter(Boolean);
  const promptCount = run.promptCount || prompts.length;
  const route = String(run.control?.presets?.submitPath || "").includes("dom") ? "DOM" : "API";
  const firstPrompt = prompts[0] || "";
  const mode = run.mode || "";

  const refsNode = refs.length
    ? el("div", { class: "history-refs-pill has-refs", attrs: { title: `${refs.length} reference${refs.length === 1 ? "" : "s"}` } },
        ...refs.slice(0, 4).map((ref) => el("span", {
          class: "history-ref-thumb",
          attrs: { title: ref.title || ref.fileName || "Reference" },
        }, ref.imageUrl
          ? el("img", { attrs: { src: ref.imageUrl, alt: ref.title || "Reference", loading: "lazy" } })
          : icon("image"))),
        refs.length > 4 ? el("span", { class: "history-more-refs", text: `+${refs.length - 4}` }) : null,
      )
    : el("div", { class: "history-refs-pill no-refs" }, icon("link_off"), el("span", { text: translate("noRefs", {}, locale) }));

  return el("article", { class: `history-card ${modeAccentClass(mode)}`, data: { historyId: run.id } },
    // Row 1 — mode identity + meta
    el("div", { class: "history-row history-row-head" },
      el("div", { class: "history-mode-chip" }, icon(modeIconName(mode))),
      el("strong", { class: "history-title", text: `${modeLabel(mode, locale)} · ${promptCount} prompt${promptCount === 1 ? "" : "s"}` }),
      el("span", { class: "history-meta", text: formatHistoryTime(run.createdAt) }),
      el("span", { class: "history-route-pill", text: route }),
    ),
    // Row 2 — prompt text (prominent)
    el("div", { class: "history-row history-row-prompt" },
      el("span", { class: "history-prompt-preview", text: firstPrompt || "(no prompt text)" }),
    ),
    // Row 3 — refs visibility + actions
    el("div", { class: "history-row history-row-foot" },
      refsNode,
      el("div", { class: "history-actions" },
        el("button", { data: { historyRestore: run.id }, attrs: { type: "button", title: translate("editPromptsAndRefs", {}, locale) } }, icon("edit"), el("span", { text: translate("edit", {}, locale) })),
        el("button", { data: { historyRun: run.id }, attrs: { type: "button", title: translate("runThisBatchAgain", {}, locale) } }, icon("replay"), el("span", { text: translate("runAgain", {}, locale) })),
        el("button", { data: { historyDelete: run.id }, class: "history-action-icon", attrs: { type: "button", title: translate("deleteHistoryEntry", {}, locale) } }, icon("close")),
      ),
    ),
  );
}

function formatHistoryTime(iso = "") {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "saved";
  return date.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function renderWorkflowHint() {
  return el("details", { id: "videoPromptHint", class: "workflow-hint" },
    el("summary", null,
      icon("movie_filter"),
      el("span", { text: "Image -> Video Workflow" }),
      el("span", { class: "workflow-click-expand", text: "click to expand" })
    ),
    el("div", { class: "workflow-hint-body" },
      el("div", null,
        "Use ",
        el("strong", { text: "Create Image" }),
        " first, then select your best images in ",
        el("strong", { text: "Gallery" }),
        " and click ",
        el("strong", { text: "Animate Images" }),
        ". Use this scene-tag format:"
      ),
      el("div", { class: "workflow-example" },
        el("span", { class: "scene-token", text: "[V99-S1]" }),
        " blue cat standing on grey background ",
        el("span", { class: "scene-separator", text: "|||" }),
        " ",
        el("span", { class: "scene-token", text: "[V99-S1]" }),
        " animate blue cat jumping"
      )
    )
  );
}

function renderReferenceLibraryGrid(state) {
  const items = state.referenceLibrary.savedItems || [];
  const active = new Set(allActiveRefIds(state));
  const oneToOne = new Set(oneToOneBatchRefIds(state));
  const previewIds = active.size ? [...active] : [...oneToOne];
  const hasAnyActiveSource = active.size > 0 || oneToOne.size > 0;
  const grid = el("div", { id: "refImagesGrid", class: "ref-images-grid" });
  if (!items.length) {
    grid.appendChild(el("p", { class: "ref-empty-message", text: "No library images yet. Click Add to library to upload." }));
  } else {
    for (const item of items.slice(0, 100)) {
      grid.appendChild(el("button", {
        class: `ref-library-thumb${active.has(item.id) ? " active" : ""}${oneToOne.has(item.id) ? " batch-active" : ""}`,
        data: { refLibraryId: item.id },
        attrs: { type: "button", title: item.title || item.fileName || "Reference image" }
      },
        el("img", { attrs: { src: item.imageUrl || item.dataUrl || item.mediaUrl, alt: item.title || "Reference image", loading: "lazy" } }),
        oneToOne.has(item.id) ? el("span", { class: "ref-batch-badge", text: "1:1" }) : null
      ));
    }
  }
  return el("div", { id: "refImagesContent", class: "ref-images-content" },
    el("div", { class: "ref-library-summary" },
      el("span", { text: oneToOne.size ? `${oneToOne.size} queued 1:1` : active.size ? `${active.size} active` : "No active references" }),
      el("span", { text: oneToOne.size ? "1:1 batch overrides selected library refs." : "Use selected refs for the next queue items." })
    ),
    grid,
    el("div", { class: "ref-library-actions" },
      el("button", { id: "refSelectAllBtn", attrs: { type: "button" }, text: "Select all" }),
      el("button", { id: "refClearMarkedBtn", attrs: { type: "button" }, text: "Deselect all" }),
      el("button", { id: "deleteSelectedRefsBtn", attrs: { type: "button", disabled: true }, text: "Delete Selected" }),
      el("button", { id: "clearRefImagesBtn", class: "ref-clear-all-btn", attrs: { type: "button" }, text: "Clear All" })
    ),
    el("div", { id: "noRefWarning", class: "no-ref-warning", style: { display: items.length && !hasAnyActiveSource ? "block" : "none" } },
      icon("warning"),
      el("span", { text: "No reference active - click image(s) above to activate" })
    ),
    el("div", { id: "selectedRefImage", class: "selected-ref-image", style: { display: hasAnyActiveSource ? "block" : "none" } },
      el("div", { class: "selected-ref-row" },
        el("div", { id: "selectedRefPreviews", class: "selected-ref-previews" },
          previewIds.slice(0, 6).map((id) => {
            const item = savedReference(state, id);
            return item ? el("img", { attrs: { src: item.imageUrl || item.dataUrl || item.mediaUrl, alt: item.title || "Selected reference" } }) : null;
          })
        ),
        el("div", { class: "selected-ref-copy" },
          el("div", { class: "selected-ref-title" }, icon("check_circle"), el("span", { id: "refActiveCount", text: String(previewIds.length) }), el("span", { text: oneToOne.size ? " 1:1 Batch Active" : " Reference Active" })),
          el("div", { id: "refAssignHint", text: oneToOne.size ? "Mapped by prompt row. Library selections are temporarily unchecked." : "Will be used for all prompts" })
        ),
        el("button", { id: "clearSelectedRef", attrs: { type: "button" } }, icon("close"), el("span", { text: "Clear" }))
      )
    )
  );
}

function renderPromptAssignList(state, prompts) {
  const open = state.control.promptMapOpen === true;
  const fullscreen = state.control.promptMapFullscreen === true;
  const frameMode = state.control.mode === FLOW_MODES.imageToVideo;
  const rows = promptMapRows(state, prompts);
  const mappedCount = rows.filter((row) => row.effectiveIds.length > 0).length;
  const sourceRefs = mappingSourceRefs(state);
  const sourceCount = sourceRefs.length;
  const classes = [
    fullscreen ? "assign-fullscreen" : "",
    frameMode ? "map-mode-frame" : "",
    oneToOneBatchRefIds(state).length ? "map-mode-one-to-one" : ""
  ].filter(Boolean).join(" ");

  const panel = el("div", { id: "promptAssignList", class: classes, style: { display: open ? "block" : "none" } });
  if (!prompts.length || (!sourceCount && state.control.mode !== FLOW_MODES.textToVideo)) {
    panel.append(
      el("p", {
        class: "prompt-map-empty",
        text: !prompts.length
          ? "Paste prompts first to map references."
          : "Activate reference images or upload a 1:1 batch to map prompt-by-prompt."
      }),
      promptAssignFooter(mappedCount, true)
    );
    return panel;
  }

  const toolbar = el("div", { class: "map-toolbar" },
      el("div", { class: "map-toolbar-actions" },
        el("button", { data: { mapAction: "map-all" }, attrs: { type: "button" }, text: frameMode ? "Map start/end" : "Map all refs" }),
        el("button", { data: { mapAction: "clear-selected" }, attrs: { type: "button" }, text: "Unmap all refs" }),
        el("button", { data: { mapAction: "clear-active-refs" }, attrs: { type: "button" }, text: "Clear active refs" }),
        el("button", { data: { mapAction: "map-one-to-one" }, attrs: { type: "button", disabled: sourceCount ? null : "disabled" }, text: "Map 1:1 by row" }),
        el("button", { id: "taskKeyManagerBtn", attrs: { type: "button", title: "Task Key Manager parity hook" }, text: "Task Key Manager" }),
        frameMode ? el("label", { class: "map-end-toggle" },
          el("input", { id: "mapEndFrameToggle", checked: true, attrs: { type: "checkbox" } }),
          el("span", { text: "End Frame" })
        ) : null
      ),
      el("div", { class: "map-toolbar-right" },
        el("span", { class: "map-source-summary", text: oneToOneBatchRefIds(state).length ? `${sourceCount} 1:1 batch ref${sourceCount === 1 ? "" : "s"}` : `${sourceCount} active ref${sourceCount === 1 ? "" : "s"}` }),
        el("button", { id: "assignFullscreenBtn", attrs: { type: "button" }, text: fullscreen ? "Exit fullscreen" : "Fullscreen" }),
        el("button", { id: "assignDoneBtn", attrs: { type: "button" }, text: "Hide" })
      )
    );
  const stats = renderMapStatsBar(rows.length, mappedCount);
  const grid = el("div", { class: "map-grid-wrap" },
      el("div", { class: `map-grid-head${frameMode ? " frame-mode" : ""}` },
        el("span", { text: "Sel" }),
        el("span", { text: "#" }),
        el("span", { text: "Prompt" }),
        el("span", { text: "Status" }),
        frameMode ? el("span", { text: "Start Frame" }) : el("span", { text: "Image" }),
        frameMode ? el("span", { text: "End Frame" }) : null
      ),
      el("div", { class: "map-grid-scroll" },
        rows.slice(0, 120).map((row) => renderPromptMapRow(row, sourceRefs, frameMode))
      )
    );

  if (fullscreen) {
    panel.append(
      el("div", { class: "map-split" },
        renderMapRefPool(sourceRefs, rows),
        el("div", { class: "map-split-content" },
          toolbar,
          stats,
          grid,
          promptAssignFooter(mappedCount, false)
        )
      )
    );
  } else {
    panel.append(toolbar, stats, grid, promptAssignFooter(mappedCount, false));
  }
  return panel;
}

function renderMapStatsBar(totalRows, mappedCount) {
  const total = Math.max(0, Number(totalRows || 0));
  const mapped = Math.max(0, Number(mappedCount || 0));
  const pct = total ? Math.round((mapped / total) * 100) : 0;
  return el("div", { class: "map-stats-bar-wrap" },
    el("div", { class: "map-stats-track" },
      el("div", { class: "map-stats-fill", style: { width: `${pct}%` } })
    ),
    el("span", { class: "map-stats-text", text: `${mapped}/${total} mapped` })
  );
}

function renderMapRefPool(sourceRefs, rows) {
  const usedIds = new Set(rows.flatMap((row) => row.effectiveIds || []));
  return el("aside", { class: "map-ref-pool" },
    el("div", { class: "map-pool-header", text: "Reference Pool" }),
    sourceRefs.length
      ? el("div", { class: "map-ref-pool-grid" }, sourceRefs.map((ref) => renderMapPoolItem(ref, usedIds.has(ref.id))))
      : el("div", { class: "map-pool-empty", text: "No active refs" }),
    el("div", { class: "map-pool-actions" },
      el("button", { data: { mapAction: "map-all" }, attrs: { type: "button" }, text: "Map all refs" }),
      el("button", { data: { mapAction: "map-one-to-one" }, attrs: { type: "button" }, text: "Map 1:1 by row" })
    ),
    el("div", { class: "map-pool-count", text: `${sourceRefs.length} available` })
  );
}

function renderMapPoolItem(ref, used) {
  const title = ref.title || ref.fileName || "Reference";
  return el("button", {
    class: "map-pool-item",
    data: { mapPoolRefId: ref.id },
    attrs: { type: "button", title }
  },
    el("img", {
      class: `map-pool-thumb${used ? " used" : ""}`,
      attrs: { src: ref.imageUrl || ref.dataUrl || ref.mediaUrl, alt: title, loading: "lazy" }
    }),
    el("span", { class: "map-pool-name", text: title })
  );
}

function promptAssignFooter(mappedCount, includeHide) {
  return el("div", { class: "assign-footer" },
    el("span", { id: "assignStatus", text: `${mappedCount} mapped` }),
    includeHide ? el("button", { id: "assignDoneBtn", attrs: { type: "button" }, text: "Hide" }) : null
  );
}

function renderPromptMapRow(row, sourceRefs, frameMode) {
  const status = row.effectiveIds.length ? "mapped" : "unmapped";
  const statusText = row.effectiveIds.length ? "Mapped" : "No Image";
  const promptPreview = row.prompt.length > 90 ? `${row.prompt.slice(0, 90)}...` : row.prompt;
  return el("div", {
    class: `map-grid-row${frameMode ? " frame-mode" : ""}`,
    data: { promptKey: row.key, promptIndex: String(row.index) }
  },
    el("input", { class: "map-row-check", data: { promptKey: row.key }, attrs: { type: "checkbox" } }),
    el("span", { class: "prompt-idx", text: String(row.index + 1).padStart(2, "0") }),
    el("span", { class: "prompt-text", attrs: { title: row.prompt }, text: promptPreview }),
    el("span", { class: `map-status-pill ${status}`, text: statusText }),
    frameMode
      ? renderFrameRefCell(row, sourceRefs, "start")
      : renderImageRefCell(row, sourceRefs),
    frameMode ? renderFrameRefCell(row, sourceRefs, "end") : null
  );
}

function renderImageRefCell(row, sourceRefs) {
  if (!sourceRefs.length) return el("span", { class: "map-ref-empty", text: "-" });
  return el("div", { class: "map-ref-cell" }, sourceRefs.map((ref) => renderMapRefThumb(ref, row, row.effectiveIds.includes(ref.id))));
}

function renderFrameRefCell(row, sourceRefs, slot) {
  if (!sourceRefs.length) return el("span", { class: "map-ref-empty", text: "-" });
  const slotIndex = slot === "end" ? 1 : 0;
  return el("div", { class: "map-ref-cell" }, sourceRefs.map((ref) => renderMapRefThumb(ref, row, row.effectiveIds[slotIndex] === ref.id, slot)));
}

function renderMapRefThumb(ref, row, assigned, frameSlot = "") {
  return el("button", {
    class: `map-ref-thumb-btn${assigned ? " assigned" : " unassigned"}`,
    data: { mapRefId: ref.id, mapPromptKey: row.key, mapFrameSlot: frameSlot },
    attrs: { type: "button", title: ref.title || ref.fileName || "Reference image" }
  },
    el("img", { class: "map-ref-thumb", attrs: { src: ref.imageUrl || ref.dataUrl || ref.mediaUrl, alt: ref.title || "Reference image", loading: "lazy" } })
  );
}

// @i18n-resume
export function renderGallery(root, state) {
  clear(root);
  const deletedIds = state.gallery.deletedIds || [];
  const activeProjectId = String(state.runtime?.projectId || "").trim();
  const referenceMediaIds = knownGalleryReferenceMediaIds(state);
  const generatedOutputMediaIds = generatedOutputMediaIdsFromTasks(state.queue.items || []);
  const projectItems = filterGalleryItemsForProject([
    ...(state.gallery.items || []),
    ...buildGalleryItemsFromTasks(state.queue.items || [])
  ], activeProjectId);
  const items = canonicalGalleryItems(projectItems, { projectId: activeProjectId, referenceMediaIds, generatedOutputMediaIds }).filter((item) => !deletedIds.includes(item.id));
  const selected = new Set(state.ui.selectedGalleryIds || []);
  const groups = {
    images: items.filter((item) => (item.kind || "images") === "images"),
    videos: items.filter((item) => item.kind === "videos")
  };
  const rawViewMode = state.ui.galleryViewMode || "grid";
  const viewMode = rawViewMode === "live" ? "grid" : rawViewMode;
  const sizeMode = state.ui.gallerySize || "small";
  const active = resolveActiveGalleryTab(state, groups, viewMode);
  const locale = state.control?.presets?.language || "en";
  const selectedVideos = groups.videos.filter((item) => selected.has(item.id)).length;
  const activeSelectedCount = groups[active].filter((item) => selected.has(item.id)).length;
  const activeItems = groups[active];
  const sortedActiveItems = sortGalleryItems(activeItems, state.ui.gallerySortOrder || "num-asc");
  const activeCount = activeItems.length;
  const refsById = new Map([
    ...(state.control?.transientReferenceItems || []),
    ...(state.referenceLibrary?.savedItems || [])
  ].map((ref) => [String(ref?.id || ""), ref]).filter(([id]) => id));
  const defaultRefId = refsById.size === 1 ? [...refsById.keys()][0] : "";

  root.classList.toggle("gallery-layout-large", sizeMode === "medium");
  root.appendChild(el("div", { class: `gallery-shell gallery-view-${viewMode} gallery-size-${sizeMode}` },
    el("div", { class: "gallery-subtabs" },
      galleryTab("images", translate("images", {}, locale), active, groups.images.length, "image"),
      galleryTab("videos", translate("videos", {}, locale), active, groups.videos.length, "movie")
    ),
    el("div", { class: "gallery-layout-controls" },
      el("span", { class: "gallery-layout-label", text: translate("viewLabel", {}, locale) }),
      el("div", { class: "gallery-layout-buttons" },
        galleryLayoutButton("grid", viewMode, "grid_view", translate("gridView", {}, locale)),
        galleryLayoutButton("table", viewMode, "table_rows", translate("tableView", {}, locale))
      ),
      el("span", { class: "gallery-layout-label gallery-size-label", text: translate("sizeLabel", {}, locale) }),
      el("div", { class: "gallery-layout-buttons" },
        gallerySizeButton("small", sizeMode, "S"),
        gallerySizeButton("medium", sizeMode, "M")
      )
    ),
    viewMode === "live"
      ? el("div", { class: "gallery-pane active" },
        renderGalleryHeader(active, state, activeCount, activeSelectedCount, selectedVideos, locale),
        renderLiveQueueGallery(state, selected)
      )
      : el("div", { class: "gallery-pane active" },
        renderGalleryHeader(active, state, activeCount, activeSelectedCount, selectedVideos, locale),
        renderGalleryHowTo(active, locale),
        galleryGrid(sortedActiveItems, selected, `gallery-${active}`, active === "images"
          ? translate("noImagesLoaded", {}, locale)
          : translate("noVideosLoaded", {}, locale), viewMode, refsById, defaultRefId)
      ),
    state.gallery.meta?.fetchedAt ? el("div", { class: "setting-hint gallery-last-scan", text: `Last scan ${formatTime(state.gallery.meta.fetchedAt)} - ${state.gallery.meta.source || "gallery"}` }) : null
  ));
}

function knownGalleryReferenceMediaIds(state = {}) {
  const referenceItems = [
    ...(state.control?.transientReferenceItems || []),
    ...(state.referenceLibrary?.savedItems || [])
  ];
  return [...new Set([
    ...referenceMediaIdsFromTasks(state.queue?.items || []),
    ...referenceItems.flatMap((item) => [item?.mediaId, item?.assetImageId])
  ].map((id) => String(id || "").trim()).filter(Boolean))];
}

export function renderLiveQueue(root, state) {
  const locale = state.control?.presets?.language || "en";
  const mediaCache = collectLiveQueuePreviewMedia(root);
  const shell = el("div", { class: "gallery-shell gallery-view-live" },
    el("div", { class: "live-queue-page-head" },
      el("div", null,
        el("div", { class: "section-label", text: translate("liveQueue", {}, locale) }),
        el("h2", { text: translate("liveQueueSubtitle", {}, locale) }),
        el("p", { text: translate("liveQueueDesc", {}, locale) })
      )
    ),
    renderLiveQueueGallery(state, new Set(state.ui.selectedGalleryIds || []), { showAllGroups: true })
  );
  reuseLiveQueuePreviewMedia(shell, mediaCache);
  clear(root);
  root.appendChild(shell);
}

function collectLiveQueuePreviewMedia(root) {
  const cache = new Map();
  root?.querySelectorAll?.(".live-preview-media[data-live-media-key]")?.forEach((node) => {
    const key = String(node.dataset.liveMediaKey || "");
    const src = String(node.getAttribute("src") || "");
    if (!key || !src || cache.has(key)) return;
    cache.set(key, { node, src, tagName: node.tagName });
  });
  return cache;
}

function reuseLiveQueuePreviewMedia(root, cache) {
  if (!cache?.size) return;
  root.querySelectorAll(".live-preview-media[data-live-media-key]").forEach((node) => {
    const key = String(node.dataset.liveMediaKey || "");
    const cached = cache.get(key);
    if (!cached || cached.tagName !== node.tagName || cached.src !== String(node.getAttribute("src") || "")) return;
    for (const attr of Array.from(node.attributes)) {
      cached.node.setAttribute(attr.name, attr.value);
    }
    for (const attr of Array.from(cached.node.attributes)) {
      if (!node.hasAttribute(attr.name)) cached.node.removeAttribute(attr.name);
    }
    node.replaceWith(cached.node);
    cache.delete(key);
  });
}

function resolveActiveGalleryTab(state, groups, viewMode) {
  if (viewMode === "live") {
    const liveKind = liveQueueMediaKind(state.queue?.items || []);
    if (liveKind) return liveKind;
  }
  return ["images", "videos"].includes(state.ui.galleryTab) ? state.ui.galleryTab : "images";
}

function liveQueueMediaKind(items = []) {
  const groups = queueGroups(items);
  const activeGroups = groups.filter((group) => group.statusClass !== "done");
  const group = (activeGroups.length ? activeGroups : groups.slice(-1)).at(-1);
  if (!group?.items?.length) return "";
  return group.items.some((item) => liveQueueIsVideoItem(item)) ? "videos" : "images";
}

export function renderSettings(root, state) {
  clear(root);
  const locale = state.control?.presets?.language || "en";
  const presets = state.control.presets;
  const hasAccess = hasProAccess(state);
  const signedIn = state.account?.status === "signed_in";
  const grid = el("div", { class: "settings-grid" },
    subheader("account_circle", "Account"),
    renderAccountSettings(state),

    subheader("tune", "General Settings"),
    field("Submit Route:", controlGroup(
      el("div", { id: "settingsSubmitRouteButtonRow", class: "route-button-row" },
        routeBtn(presets.submitPath === "dom_first", "dom_first", "DOM"),
        routeBtn(presets.submitPath === "agent_first", "agent_first", "Agent"),
        routeBtn(presets.submitPath === "api_first", "api_first", "API")
      )
    )),
    el("div", { id: "videoModeSettings", class: "mode-settings" },
      field("Videos per task:", select("repeatCountInput", presets.repeatCount, [["1", "1"], ["2", "2"], ["3", "3"], ["4", "4"]], "repeatCount")),
      field("Model (optional):", select("modelSelector", presets.model, VIDEO_MODEL_OPTIONS, "model")),
      field("Ingredients Video Model:", select("ingredientsModelSelector", presets.ingredientsModel, INGREDIENTS_VIDEO_MODEL_OPTIONS, "ingredientsModel")),
      field("Video Ratio:", select("aspectRatioSelector", presets.aspectRatio, [["landscape", "Landscape (16:9)"], ["portrait", "Portrait (9:16)"]], "aspectRatio")),
      field(translate("returnSilentVideos", {}, locale) + ":", controlGroup(checkInput("returnSilentVideosCheckbox", presets.returnSilentVideos !== false, "returnSilentVideos")))
    ),
    el("div", { id: "imageModeSettings", class: "mode-settings" },
      field("Images per task:", select("imageRepeatCountInput", presets.imageRepeatCount, [["1", "1"], ["2", "2"], ["3", "3"], ["4", "4"]], "imageRepeatCount")),
      field("Model:", select("imageModelSelector", presets.imageModel, [["nano_banana_pro", "Nano Banana Pro"], ["nano_banana_2", "Nano Banana 2"], ["nano_banana_2_lite", "Nano Banana 2 Lite"]], "imageModel")),
      field("Image Ratio:", select("imageAspectRatioSelector", presets.imageAspectRatio, [["landscape", "Landscape (16:9)"], ["landscape_4_3", "Landscape (4:3)"], ["square", "Square (1:1)"], ["portrait_3_4", "Portrait (3:4)"], ["portrait", "Portrait (9:16)"]], "imageAspectRatio"))
    ),
    field("Start from (Prompt/Image):", controlGroup(numberInput("startFromInput", presets.startFrom, "startFrom", { min: "1" }), el("span", { class: "unit", text: "number" }))),

    subheader("timer", "Timing"),
    el("div", { class: "control-label-with-tip wide" },
      el("label", { id: "waitTimeLabel", text: "Generation wait time (sec):" }),
      el("button", { class: "inline-help-tip", attrs: { type: "button", title: translate("waitTimeTip", {}, locale) }, text: "?" })
    ),
    el("div", { class: "control-group wide" },
      numberInput("minInitialWaitTime", presets.minInitialWaitTime, "minInitialWaitTime", { min: "1" }),
      el("span", { text: "to" }),
      numberInput("maxInitialWaitTime", presets.maxInitialWaitTime, "maxInitialWaitTime", { min: "1" })
    ),

    subheader("download", "Download Settings"),
    field("Auto-download videos:", controlGroup(checkInput("autoDownloadCheckbox", presets.autoDownload, "autoDownload"))),
    field("Video Resolution:", select("videoDownloadResolution", presets.videoDownloadResolution, [["720p", "Original (720p)"], ["1080p", "Upscaled (1080p)"], ["4k", "Upscaled (4K - 50 credits)"]], "videoDownloadResolution")),
    field("Auto-download images:", controlGroup(checkInput("autoDownloadImagesCheckbox", presets.autoDownloadImages, "autoDownloadImages"), select("imageAutoDownloadResolution", presets.imageAutoDownloadResolution, [["1k", "1K"], ["2k", "2K"], ["4k", "4K"]], "imageAutoDownloadResolution"))),
    field("Download Folder:", controlGroup(textInput("jobDownloadFolderInput", presets.downloadFolder, "downloadFolder"), el("label", { class: "auto-number-toggle", attrs: { for: "autoNumberFolderCheckbox" } }, checkInput("autoNumberFolderCheckbox", presets.autoNumberFolder, "autoNumberFolder"), el("span", { text: "Auto-number" })))),
    el("div", { class: "hint-text wide", text: translate("autoNumberFolderHint", {}, locale) }),
    field("Filename style:", select("filenameStyleSelect", presets.filenameStyle, [["detailed", "Scene token + prompt slug (default)"], ["prompt_prefix", "Prompt Prefix"], ["auto_flow", "Autoflow Format"], ["custom_template", "Custom Template"]], "filenameStyle")),
    renderFilenameTemplateControls(presets, locale),
    el("div", { class: "filename-preview-line wide" },
      el("span", { id: "filenamePreviewLabel", class: "filename-preview-label", text: translate("exampleLabel", {}, locale) }),
      el("span", { id: "filenameStylePreviewValue", class: "filename-preview-value", text: filenamePreview(presets) })
    ),
    el("div", { class: "hint-text wide", text: translate("disableAskWhereSave", {}, locale) }),

    subheader("language", "Interface"),
    field("Language:", select("languageSelector", presets.language, LANGUAGE_OPTIONS, "language")),

    subheader("credit_card", "Subscription"),
    el("div", {
      id: "manageSubSection",
      class: "wide subscription-manage-section",
      style: { display: signedIn ? "block" : "none" },
      attrs: { "aria-hidden": signedIn ? "false" : "true" }
    },
      el("button", {
        id: "manageSubBtn",
        class: "button-full account-manage-sub-btn",
        data: { billingAction: "manage" },
        attrs: { type: "button", "aria-label": translate("manageSubscription", {}, locale) }
      }, icon("credit_card"), el("span", { text: translate("manageSubscription", {}, locale) })),
      el("p", { class: "hint-text", text: signedIn ? translate("openStripeBilling", {}, locale) : translate("signInToManageBilling", {}, locale) })
    ),
    el("div", {
      id: "noSubSection",
      class: "wide",
      style: { display: hasAccess || signedIn ? "none" : "block" },
      attrs: { "aria-hidden": hasAccess || signedIn ? "true" : "false" }
    },
      el("p", { class: "hint-text", text: translate("noActiveSubscription", {}, locale) })
    ),

    subheader("build", "Maintenance"),
    maintenanceButton("clearFlowCacheBtn", "delete_sweep", "Clear Flow Cache", "danger"),
    el("p", { class: "hint-text wide", text: translate("clearFlowCacheHint", {}, locale) }),
    maintenanceButton("clearFlowCookiesBtn", "cookie", "Clear Flow Cookies", "warning"),
    el("p", { class: "hint-text wide", text: translate("clearFlowCookiesHint", {}, locale) }),
    maintenanceButton("clearAllFlowDataBtn", "mop", translate("clearAllFlowData", {}, locale), "danger"),
    el("p", { class: "hint-text wide", text: translate("clearAllFlowDataHint", {}, locale) })
  );
  root.appendChild(grid);
}

export function renderLogs(root, state) {
  clear(root);
  const locale = state.control?.presets?.language || "en";
  const lines = state.logs.items.slice(-200).map((entry) => {
    const time = formatTime(entry.createdAt);
    return `[${time}] [${entry.level}] [${entry.scope}] ${entry.message}`;
  });

  root.appendChild(el("div", { class: "logs-shell" },
    el("div", { class: "section-header log-main-header" },
      el("span", { class: "section-title", text: "Detailed Log" }),
      el("div", { class: "log-toolbar" },
        el("button", { id: "copyDebugReportBtn", class: "small-btn", attrs: { type: "button", title: translate("exportDebugReportTitle", {}, locale) } }, icon("download"), el("span", { class: "export-report-label", text: "Export Report" }))
      )
    ),
    el("div", { id: "logDisplay", class: "log-display" },
      lines.length ? lines.map((line) => el("div", { class: "log-line", text: line })) : el("div", { class: "log-line muted", text: translate("noLogsYet", {}, locale) })
    ),
    el("pre", { id: "logOutput", class: "log-pre hidden-log-output", text: lines.join("\n") })
  ));
}

export function renderMcpCli(root, state) {
  clear(root);
  const locale = state.control?.presets?.language || "en";
  const bridge = mcpCliAgentBridgeStatus(state, locale);
  const projectId = state.runtime?.projectId || translate("mcpCliCurrentProject", {}, locale);
  const extensionId = globalThis.chrome?.runtime?.id || "<extension-id>";
  const extensionVersion = globalThis.chrome?.runtime?.getManifest?.()?.version || "10.8.24";
  const installCommand = `npm install -g @autoflow-mcp/autoflow@${extensionVersion} && autoflow native install-host --extension-id ${extensionId}`;
  const docsHref = globalThis.chrome?.runtime?.getURL
    ? globalThis.chrome.runtime.getURL("docs/AGENT_MODE_MCP_CLI.html")
    : "../../docs/AGENT_MODE_MCP_CLI.html";
  root.appendChild(el("div", { class: "control-section mcp-cli-shell" },
    el("div", { class: "mcp-cli-hero" },
      el("div", { class: "mcp-cli-hero-copy" },
        el("div", { class: "afw-agent-doc-kicker", text: translate("mcpCliTitle", {}, locale) }),
        el("h2", { text: translate("mcpCliTitle", {}, locale) }),
        el("p", { text: translate("mcpCliIntro", {}, locale) })
      ),
      el("div", { class: `mcp-cli-status ${bridge.className}`, attrs: { title: bridge.title } },
        el("span", { class: "afw-bridge-dot" }),
        el("span", { text: bridge.label })
      )
    ),
    renderDirectPatchWorkRequest(state, locale),
    mcpCliBridgeCard(state, locale, installCommand),
    el("details", { class: "mcp-cli-advanced" },
      el("summary", { text: translate("mcpCliAdvancedSetup", {}, locale) }),
      el("div", { id: "mcpCliSetupSteps", class: "mcp-cli-command-grid" },
        mcpCliCommandCard(locale, translate("mcpCliSetupTitle", {}, locale), translate("mcpCliStepMcpBody", {}, locale), installCommand, "mcpCliInstallCommand"),
        mcpCliCommandCard(locale, translate("mcpCliStepPairTitle", {}, locale), translate("mcpCliStepPairBody", {}, locale), translate("mcpCliPairCommand", {}, locale), "mcpCliPairCommand")
      ),
      el("div", { class: "mcp-cli-resource-row" },
        el("a", { class: "mcp-cli-link", attrs: { href: "https://ergophobia.info/autoflow", target: "_blank", rel: "noopener noreferrer" } },
          icon("open_in_new"),
          el("span", { text: translate("website", {}, locale) })
        ),
        el("a", { class: "mcp-cli-link", attrs: { href: docsHref, target: "_blank", rel: "noopener noreferrer" } },
          icon("article"),
          el("span", { text: translate("mcpCliTitle", {}, locale) })
        )
      )
    ),
    el("div", { class: "mcp-cli-project-line" },
      el("span", { class: "filename-preview-label", text: translate("mcpCliProjectLabel", {}, locale) }),
      el("span", { class: "filename-preview-value", text: projectId })
    )
  ));
}

function renderDirectPatchWorkRequest(state, locale = "en") {
  const pending = state.control?.agentMode?.directPendingClient || {};
  const approved = state.control?.agentMode?.directApprovedClient || {};
  if (!pending.clientId || (approved.clientId === pending.clientId && approved.origin === pending.origin)) return null;
  const clientName = String(pending.clientName || "PatchWork").trim() || "PatchWork";
  return el("section", { class: "mcp-cli-bridge-card is-direct-request" },
    el("div", { class: "mcp-cli-bridge-head" },
      el("div", null,
        el("strong", { text: translate("directPatchWorkRequestTitle", { client: clientName }, locale) }),
        el("span", { text: translate("directPatchWorkRequestBody", {}, locale) })
      )
    ),
    el("div", { class: "mcp-cli-project-line" },
      el("span", { class: "filename-preview-label", text: translate("directPatchWorkRequestOrigin", { origin: pending.origin || "local PatchWork" }, locale) })
    ),
    el("button", {
      class: "mcp-cli-copy primary",
      data: { agentBridgeAction: "direct-approve" },
      attrs: { type: "button" }
    }, icon("task_alt"), el("span", { text: translate("directPatchWorkApprove", {}, locale) }))
  );
}

function mcpCliCommandCard(locale, title, body, command, commandId = "") {
  return el("article", { class: "mcp-cli-command-card" },
    el("div", { class: "mcp-cli-command-head" },
      el("div", null,
        el("strong", { text: title }),
        el("span", { text: body })
      ),
      el("button", {
        class: "mcp-cli-copy",
        data: { mcpCopyCommand: commandId || "command" },
        attrs: { type: "button", "data-command": command, title: translate("copy", {}, locale) }
      }, icon("content_copy"), el("span", { text: translate("copy", {}, locale) }))
    ),
    el("pre", { class: "mcp-cli-command-block" },
      el("code", { id: commandId || null, class: "mcp-cli-command", text: command })
    )
  );
}

function mcpCliBridgeCard(state, locale = "en", installCommand = "") {
  const flowPage = mcpCliFlowPageStatus(state, locale);
  const agentBridge = mcpCliAgentBridgeStatus(state, locale);
  const pairing = mcpCliPairingStatus(state, locale);
  const enabled = state.control?.agentMode?.bridgeEnabled === true || state.runtime?.agentBridge?.enabled === true;
  const ready = flowPage.className === "is-healthy" && agentBridge.className === "is-healthy" && pairing.className === "is-healthy";
  const projectId = String(state.runtime?.projectId || "");
  const tabId = String(state.runtime?.activeTabId || "");
  const target = projectId
    ? `${projectId.slice(0, 8)}…${tabId ? ` · tab ${tabId}` : ""}`
    : translate("mcpCliNoFlowTarget", {}, locale);
  return el("section", { class: "mcp-cli-bridge-card", attrs: { "aria-label": translate("mcpCliConnectTitle", {}, locale) } },
    el("div", { class: "mcp-cli-bridge-head" },
      el("div", null,
        el("strong", { text: ready ? translate("mcpCliConnectedTitle", {}, locale) : translate("mcpCliConnectTitle", {}, locale) }),
        el("span", { text: ready ? translate("mcpCliConnectedHelp", {}, locale) : translate("mcpCliConnectHelp", {}, locale) })
      )
    ),
    el("div", { class: "mcp-cli-current-target" },
      icon("tab"),
      el("span", { text: target })
    ),
    el("button", {
      class: "mcp-cli-connect primary",
      data: { agentBridgeAction: "connect" },
      attrs: { type: "button", disabled: projectId ? null : "disabled" }
    }, icon(ready ? "check_circle" : "link"), el("span", { text: ready ? translate("mcpCliReconnectThisTab", {}, locale) : translate("mcpCliConnectThisTab", {}, locale) })),
    el("div", { class: "mcp-cli-bridge-status-grid" },
      mcpCliStatusRow(locale, translate("mcpCliFlowPageBridge", {}, locale), flowPage),
      mcpCliStatusRow(locale, translate("mcpCliAutoFlowConnection", {}, locale), agentBridge),
      mcpCliStatusRow(locale, translate("mcpCliClientAccess", {}, locale), pairing)
    ),
    el("details", { class: "mcp-cli-technical-controls" },
      el("summary", { text: translate("mcpCliTechnicalControls", {}, locale) }),
      el("div", { class: "mcp-cli-bridge-actions" },
        el("button", {
          class: "mcp-cli-copy",
          data: { agentBridgeAction: enabled ? "disable" : "enable" },
          attrs: { type: "button" }
        }, icon(enabled ? "toggle_off" : "toggle_on"), el("span", { text: enabled ? translate("mcpCliDisableBridge", {}, locale) : translate("mcpCliEnableBridge", {}, locale) })),
        el("button", {
          class: "mcp-cli-copy",
          data: { agentBridgeAction: "retry" },
          attrs: { type: "button" }
        }, icon("restart_alt"), el("span", { text: translate("mcpCliRetryConnection", {}, locale) })),
        el("button", {
          class: "mcp-cli-copy",
          data: { agentBridgeAction: "legacy-native" },
          attrs: { type: "button", title: translate("mcpCliEnableLegacyNativeHelp", {}, locale) }
        }, icon("settings_ethernet"), el("span", { text: translate("mcpCliEnableLegacyNative", {}, locale) })),
        el("button", {
          class: "mcp-cli-copy",
          data: { mcpCopyCommand: "mcpCliInstallCommand" },
          attrs: { type: "button", "data-command": installCommand, title: translate("copy", {}, locale) }
        }, icon("content_copy"), el("span", { text: translate("mcpCliCopyInstallCommand", {}, locale) })),
        el("button", {
          class: "mcp-cli-copy",
          data: { agentBridgeAction: "diagnostics" },
          attrs: { type: "button" }
        }, icon("rule"), el("span", { text: translate("mcpCliRunDiagnostics", {}, locale) }))
      )
    )
  );
}

function mcpCliStatusRow(locale, label, status) {
  return el("div", { class: `mcp-cli-bridge-row ${status.className}`, attrs: { title: status.title } },
    el("span", { class: "mcp-cli-bridge-row-label", text: label }),
    el("span", { class: "mcp-cli-bridge-row-value" },
      el("span", { class: "afw-bridge-dot" }),
      el("span", { text: status.label })
    )
  );
}

function mcpCliFlowPageStatus(state, locale = "en") {
  const runtime = state.runtime || {};
  if (runtime.connected === true && runtime.bridgeHealthy === true) {
    return {
      className: "is-healthy",
      label: translate("mcpCliFlowPageConnected", {}, locale),
      title: runtime.projectId || translate("bridgeHealthyHelp", {}, locale)
    };
  }
  if (runtime.connected === true || runtime.activeTabId || runtime.projectId || runtime.pageUrl) {
    if (runtime.bridgeDegraded === true || runtime.bridgeError) {
      return {
        className: "is-degraded",
        label: translate("mcpCliFlowPageDegraded", {}, locale),
        title: runtime.bridgeError || translate("bridgeDegradedHelp", {}, locale)
      };
    }
    return {
      className: "is-checking",
      label: translate("bridgeChecking", {}, locale),
      title: runtime.bridgeError || translate("bridgeCheckingHelp", {}, locale)
    };
  }
  return {
    className: "is-offline",
    label: translate("mcpCliFlowPageDisconnected", {}, locale),
    title: translate("flowTabNotFoundGuidance", {}, locale)
  };
}

function mcpCliAgentBridgeStatus(state, locale = "en") {
  const runtime = state.runtime || {};
  const agentBridge = runtime.agentBridge || {};
  const locallyEnabled = state.control?.agentMode?.bridgeEnabled === true;
  if (agentBridge.connected === true) {
    return {
      className: "is-healthy",
      label: translate("mcpCliAgentBridgeConnected", {}, locale),
      title: agentBridge.hostName || translate("mcpCliBridgeConnectedHelp", {}, locale),
      help: translate("mcpCliBridgeConnectedHelp", {}, locale),
      showActions: false
    };
  }
  const errorCode = String(agentBridge.errorCode || agentBridge.state || "").toUpperCase();
  const errorText = String(agentBridge.error || agentBridge.lastError || "");
  if (/ORIGIN|FORBIDDEN|MISMATCH/.test(errorCode) || /forbidden|origin|not allowed/i.test(errorText)) {
    return {
      className: "is-degraded",
      label: translate("mcpCliAgentBridgeOriginMismatch", {}, locale),
      title: errorText || translate("mcpCliAgentBridgeOriginMismatchHelp", {}, locale)
    };
  }
  if (/INTERPRETER|LAUNCH|HOST_START|COMMUNICAT/.test(errorCode) || /env: node|node: No such file|communicating with the native messaging host|launch/i.test(errorText)) {
    return {
      className: "is-degraded",
      label: translate("mcpCliAgentBridgeInterpreterFailure", {}, locale),
      title: errorText || translate("mcpCliAgentBridgeInterpreterFailureHelp", {}, locale)
    };
  }
  if (/UNAVAILABLE|NOT_FOUND|MISSING/.test(errorCode) || /host not found|native host|native messaging host not found|specified native messaging host/i.test(errorText)) {
    return {
      className: "is-degraded",
      label: translate("mcpCliNativeHostUnavailable", {}, locale),
      title: errorText || translate("mcpCliNativeHostUnavailableHelp", {}, locale)
    };
  }
  if (agentBridge.reconnecting === true) {
    return {
      className: "is-reconnecting",
      label: translate("mcpCliAgentBridgeConnecting", {}, locale),
      title: translate("bridgeCheckingHelp", {}, locale)
    };
  }
  if (agentBridge.enabled === true || locallyEnabled) {
    return {
      className: "is-checking",
      label: translate("mcpCliAgentBridgeConnecting", {}, locale),
      title: translate("agentModePairingHelp", {}, locale)
    };
  }
  return {
    className: "is-offline",
    label: translate("mcpCliAgentBridgeDisabled", {}, locale),
    title: translate("mcpCliBridgeHelp", {}, locale)
  };
}

function mcpCliPairingStatus(state, locale = "en") {
  const agentBridge = state.runtime?.agentBridge || {};
  const agentMode = state.control?.agentMode || {};
  const expiresMs = Date.parse(agentMode.bridgePairingApprovalExpiresAt || "");
  const usedMs = Date.parse(agentMode.bridgePairingApprovalUsedAt || "");
  if (agentBridge.paired === true) {
    return {
      className: "is-healthy",
      label: translate("mcpCliPairingPaired", {}, locale),
      title: translate("mcpCliPairingPairedHelp", {}, locale)
    };
  }
  if (Number.isFinite(usedMs) && usedMs > 0) {
    return {
      className: "is-healthy",
      label: translate("mcpCliPairingPaired", {}, locale),
      title: translate("mcpCliPairingPairedHelp", {}, locale)
    };
  }
  if (Number.isFinite(expiresMs) && expiresMs > Date.now()) {
    return {
      className: "is-checking",
      label: translate("mcpCliPairingApprovalOpen", {}, locale),
      title: agentMode.bridgePairingApprovalExpiresAt || translate("agentModePairingHelp", {}, locale)
    };
  }
  if (Number.isFinite(expiresMs) && expiresMs <= Date.now()) {
    return {
      className: "is-degraded",
      label: translate("mcpCliPairingExpired", {}, locale),
      title: translate("mcpCliPairingExpiredHelp", {}, locale)
    };
  }
  return {
    className: "is-offline",
    label: translate("mcpCliPairingNotPaired", {}, locale),
    title: translate("agentModePairingHelp", {}, locale)
  };
}

export function renderScenes(root, state) {
  clear(root);
  const locale = state.control?.presets?.language || "en";
  const clips = [...(state.scenes?.clips || [])].sort((a, b) => Number(a.order || 0) - Number(b.order || 0));
  const selected = new Set(state.scenes?.selectedClipIds || []);
  const selectedClips = clips.filter((clip) => selected.has(clip.id));
  const selectedGalleryBacked = selectedClips.filter((clip) => clip.sourceGalleryId).length;
  const totalDuration = totalSceneDuration(clips);
  root.appendChild(el("div", { class: "control-section scenes-shell" },
    el("div", { class: "section-header" },
      el("strong", { class: "section-title", text: translate("sceneBuilder", {}, locale) }),
      el("span", { class: "sample-link", text: `${selectedClips.length}/${clips.length}` })
    ),
    el("div", { class: "scene-builder-toolbar" },
      el("button", { id: "sceneBuilderSelectAllBtn", attrs: { type: "button", disabled: clips.length ? null : "disabled", title: translate("selectAll", {}, locale) } }, icon("select_all"), el("span", { text: translate("selectAll", {}, locale) })),
      el("button", { id: "sceneBuilderDeselectAllBtn", attrs: { type: "button", disabled: selectedClips.length ? null : "disabled", title: translate("deselectAll", {}, locale) } }, icon("deselect"), el("span", { text: translate("deselectAll", {}, locale) })),
      el("button", { id: "sceneBuilderSelectGalleryBtn", attrs: { type: "button", disabled: selectedGalleryBacked ? null : "disabled", title: translate("gallery", {}, locale) } }, icon("photo_library"), el("span", { text: translate("gallery", {}, locale) }), el("span", { text: `(${selectedGalleryBacked})` })),
      el("button", { id: "sceneBuilderClearBtn", attrs: { type: "button", disabled: clips.length ? null : "disabled" } }, icon("delete_sweep"), el("span", { text: translate("clearScenes", {}, locale) })),
      el("span", { class: "scene-builder-total", text: translate("totalDurationDisplay", { duration: totalDuration }, locale) })
    ),
    el("p", { class: "setting-hint", text: translate("addFromGalleryHint", {}, locale) }),
    el("div", { class: "scene-builder-section-title" }, icon("movie"), el("span", { text: translate("clipList", {}, locale) })),
    clips.length
      ? el("div", { id: "sceneBuilderClipList", class: "scene-clip-list" }, clips.map((clip, index) => renderSceneClip(clip, index, clips.length, selected.has(clip.id), locale)))
      : el("div", { id: "sceneBuilderClipList", class: "gallery-empty", text: translate("sceneBuilderEmpty", {}, locale) }),
    el("div", { class: "scene-builder-section-title" }, icon("graphic_eq"), el("span", { text: translate("audioSection", {}, locale) })),
    el("div", { class: "scene-builder-audio-row" },
      icon("music_note"),
      el("span", { id: "sceneBuilderAudioName", class: "scene-builder-audio-name", text: state.scenes?.audioName || translate("noAudio", {}, locale) })
    )
  ));
}

function renderSceneClip(clip, index, total, selected = false, locale = "en") {
  const media = renderSceneClipMedia(clip, locale);
  const kindLabel = translate("videos", {}, locale);
  return el("div", { class: `scene-clip${selected ? " selected" : ""} is-${clip.kind || "videos"}`, data: { sceneClipId: clip.id } },
    el("label", { class: "scene-clip-select" },
      el("input", { data: { sceneSelectId: clip.id }, checked: selected, attrs: { type: "checkbox", "aria-label": translate("selectAll", {}, locale) } }),
      el("span", { class: "assign-index", text: String(index + 1).padStart(2, "0") })
    ),
    el("span", { class: "scene-clip-media" }, media),
    el("span", { class: "scene-clip-copy" },
      el("span", { class: "scene-clip-title", text: clip.title || translate("clipN", { n: index + 1 }, locale) }),
      el("span", { class: "scene-clip-kind", text: kindLabel }),
      el("span", { class: "scene-clip-prompt", text: clip.prompt || clip.mediaId || "" })
    ),
    el("span", { class: "scene-clip-actions" },
      el("button", { class: "scene-clip-btn", data: { sceneAction: "up", sceneClipId: clip.id }, attrs: { type: "button", title: translate("moveUp", {}, locale), disabled: index === 0 ? "disabled" : null } }, icon("keyboard_arrow_up")),
      el("button", { class: "scene-clip-btn", data: { sceneAction: "down", sceneClipId: clip.id }, attrs: { type: "button", title: translate("moveDown", {}, locale), disabled: index === total - 1 ? "disabled" : null } }, icon("keyboard_arrow_down")),
      el("button", { class: "scene-clip-btn", data: { sceneAction: "remove", sceneClipId: clip.id }, attrs: { type: "button", title: translate("remove", {}, locale) } }, icon("close"))
    )
  );
}

function renderSceneClipMedia(clip, locale = "en") {
  const mediaUrl = String(clip.mediaUrl || "").trim();
  const thumbnailUrl = String(clip.thumbnailUrl || "").trim();
  const title = clip.title || translate("sceneBuilder", {}, locale);
  if (clip.kind === "videos" && mediaUrl) {
    return el("video", { attrs: { src: mediaUrl, muted: true, playsinline: true, preload: "metadata" } });
  }
  if (thumbnailUrl) {
    return el("img", { attrs: { src: thumbnailUrl, alt: title, loading: "eager", decoding: "async", draggable: "false" } });
  }
  return icon("movie");
}

function renderAccountSettings(state) {
  const account = state.account || {};
  const locale = state.control?.presets?.language || "en";
  const signedIn = account.status === "signed_in";
  const pendingCode = account.status === "pending_confirmation";
  const hasAccess = hasProAccess(state);
  const email = account.email || "";
  const retryLine = authRetryLine(account, locale);
  const resendBlocked = Boolean(retryLine);
  return el("div", { id: "accountSection", class: "account-settings-form wide" },
    account.error ? el("div", { class: "setting-hint account-error", text: account.error }) : null,
    visibleAccountMessage(state) ? el("div", { class: "setting-hint account-message", text: visibleAccountMessage(state) }) : null,
    account.degradedLocalMode ? el("div", { class: "setting-hint account-message", text: translate("authDegradedLocalMode", {}, locale) }) : null,
    el("div", { id: "authSignedOut", style: { display: signedIn ? "none" : "block" } },
      el("p", { class: "setting-hint", text: translate("signInToRestore", {}, locale) }),
      el("div", { style: { display: pendingCode ? "none" : "flex", gap: "8px", alignItems: "center" } },
        el("input", { id: "authEmailInput", value: email, attrs: { type: "email", placeholder: "your@email.com", autocomplete: "email" } }),
        el("button", { id: "authSendLinkBtn", class: "btn-secondary", attrs: { type: "button" } }, icon("mail"), el("span", { class: "auth-send-code-label", text: translate("sendCode", {}, locale) }))
      ),
      el("p", { class: "auth-email-hint", text: translate("useAnyEmail", {}, locale) }),
      el("div", { id: "authOtpSection", style: { display: pendingCode ? "block" : "none", marginTop: "8px" } },
        el("p", { class: "auth-email-hint", text: translate("checkEmailAddress", { email: email || "your email" }, locale) }),
        account.authCodeRequestError ? el("p", { class: "auth-email-hint account-error", text: account.authCodeRequestError }) : null,
        retryLine ? el("p", { class: "auth-email-hint account-rate-limit", text: retryLine }) : null,
        el("div", { style: { display: "flex", gap: "8px", alignItems: "center" } },
          el("input", { id: "authOtpInput", value: account.otpCode || "", attrs: { type: "text", placeholder: translate("enterCode", {}, locale), maxlength: "10", autocomplete: "one-time-code", inputmode: "numeric" } }),
          el("button", { id: "authVerifyBtn", class: "btn-secondary", attrs: { type: "button" }, text: translate("verify", {}, locale) })
        ),
        el("p", { class: "auth-email-hint", text: translate("authNoCodeHelp", {}, locale) }),
        el("div", { class: "auth-recovery-actions" },
          el("button", { id: "authResendCodeBtn", class: "small-btn", attrs: { type: "button", disabled: resendBlocked ? "disabled" : null } }, icon("mail"), el("span", { text: translate("authResendCode", {}, locale) })),
          el("button", { id: "authChangeEmailBtn", class: "small-btn", attrs: { type: "button" } }, icon("edit"), el("span", { text: translate("authChangeEmail", {}, locale) })),
          el("button", { id: "authBackToExtensionBtn", class: "small-btn", attrs: { type: "button" } }, icon("arrow_back"), el("span", { text: translate("authBackToExtension", {}, locale) })),
          el("button", { id: "authCopySupportBtn", class: "small-btn", attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
          el("button", { id: "authExportReportBtn", class: "small-btn", attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
        )
      )
    ),
    el("div", { id: "authSignedIn", style: { display: signedIn ? "block" : "none" } },
      el("div", { class: "signed-in-card" },
        el("div", null,
          el("div", { class: "user-email", id: "userEmail", text: account.email || "" }),
          el("div", { class: "usage-line" },
            el("span", { id: "userTierBadge", class: `tier-badge ${hasAccess ? "pro" : "free"}`, text: hasAccess ? translate("proBadge", {}, locale) : translate("freeBadge", {}, locale) }),
            el("span", { id: "usageCounter", text: hasAccess ? translate("unlimitedPrompts", {}, locale) : formatUsageLine(account) })
          )
        ),
        el("div", { class: "button-row account-action-row" },
          el("button", { id: "refreshLicenseBtn", attrs: { type: "button", title: translate("refreshSubscriptionStatus", {}, locale) } }, icon("refresh")),
          el("button", { id: "authSignOutBtn", class: "btn-secondary", attrs: { type: "button" }, text: translate("signOut", {}, locale) }),
          el("button", {
            id: "accountManageSubBtn",
            class: "account-manage-sub-btn",
            data: { billingAction: "manage" },
            attrs: { type: "button" }
          }, icon("credit_card"), el("span", { text: translate("manageSubscription", {}, locale) }))
        )
      )
    )
  );
}

function renderFilenameTemplateControls(presets, locale = "en") {
  return el("div", { id: "filenameTemplateControls", class: "filename-template-controls wide" },
    el("p", { id: "filenameTemplateHelpText", class: "filename-template-help", text: translate("defaultNamingHint", {}, locale) }),
    filenameRow("Template prefix:", textInput("filenameTemplatePrefix", presets.filenameTemplatePrefix, "filenameTemplatePrefix", "Optional prefix")),
    filenameRow("Template index:", select("filenameTemplateIndex", presets.filenameTemplateIndex, [["none", "none"], ["n", "n"], ["nn", "nn"], ["nnn", "nnn"]], "filenameTemplateIndex")),
    filenameRow("Template prompt part:", select("filenameTemplatePromptPart", presets.filenameTemplatePromptPart, [["none", "none"], ["first_word", "first_word"], ["first_3_words", "first_3_words"], ["slug_8", "slug_8"]], "filenameTemplatePromptPart")),
    filenameRow("Template date:", select("filenameTemplateDate", presets.filenameTemplateDate, [["none", "none"], ["yyyymmdd", "yyyymmdd"], ["yymmdd_hhmm", "yymmdd_hhmm"]], "filenameTemplateDate")),
    filenameRow("Template suffix:", select("filenameTemplateSuffix", presets.filenameTemplateSuffix, [["none", "none"], ["rand4", "rand4"], ["rand8", "rand8"]], "filenameTemplateSuffix")),
    filenameRow("Template separator:", select("filenameTemplateSeparator", presets.filenameTemplateSeparator, [["_", "_"], ["-", "-"]], "filenameTemplateSeparator"))
  );
}

function filenamePreview(presets) {
  const style = String(presets.filenameStyle || "detailed");
  if (style === "detailed") return "01_A_white-cat-standing-on.png";
  if (style === "prompt_prefix") return "white-cat-standing-on_01_A.png";
  if (style === "auto_flow") return "V99-S4_A_grey-cat-upside-down.jpeg";
  const sep = presets.filenameTemplateSeparator || "_";
  const pieces = [];
  if (presets.filenameTemplatePrefix) pieces.push(presets.filenameTemplatePrefix);
  if (presets.filenameTemplateIndex !== "none") pieces.push(presets.filenameTemplateIndex === "n" ? "1" : presets.filenameTemplateIndex === "nnn" ? "001" : "01");
  if (presets.filenameTemplatePromptPart !== "none") pieces.push("white-cat-standing-on");
  if (presets.filenameTemplateDate === "yyyymmdd") pieces.push("20260427");
  if (presets.filenameTemplateDate === "yymmdd_hhmm") pieces.push("260427_1430");
  if (presets.filenameTemplateSuffix === "rand4") pieces.push("a7f2");
  if (presets.filenameTemplateSuffix === "rand8") pieces.push("a7f2c91b");
  const body = pieces.length ? pieces.join(sep) : "V99-S1_white-cat-standing-on";
  return `${body}.png`;
}

function field(labelText, control) {
  return [el("label", { text: labelText }), control];
}

function subheader(iconName, text) {
  return el("div", { class: "settings-subheader wide" }, icon(iconName), el("span", { text }));
}

function select(id, value, options, settingKey) {
  return el("select", { id, data: { settingKey } },
    options.map(([optionValue, label]) => el("option", {
      value: String(optionValue),
      attrs: { value: String(optionValue), selected: String(value) === String(optionValue) }
    }, label))
  );
}

function numberInput(id, value, settingKey, attrs = {}) {
  return el("input", { id, value: String(value ?? ""), class: "input-short", data: { settingKey }, attrs: { type: "number", ...attrs } });
}

function textInput(id, value, settingKey, placeholder = "") {
  return el("input", { id, value: String(value ?? ""), data: { settingKey }, attrs: { type: "text", placeholder } });
}

function checkInput(id, checked, settingKey) {
  return el("input", { id, checked, data: { settingKey }, attrs: { type: "checkbox" } });
}

function controlGroup(...kids) {
  return el("div", { class: "control-group" }, kids);
}

function filenameRow(labelText, control) {
  return el("div", { class: "filename-template-row" }, el("label", { text: labelText }), control);
}

function maintenanceButton(id, iconName, text, tone) {
  return el(
    "button",
    { id, class: `maintenance-btn ${tone}`, attrs: { type: "button" } },
    icon(iconName),
    el("span", { class: "maintenance-btn-label", text })
  );
}

function diagGroup(title, group, labels, hint = "") {
  return el("div", { class: "diag-suite-button-group", data: { suiteGroup: group } },
    el("div", { class: "diag-suite-button-group-title", text: title }),
    el("div", { class: "diag-suite-button-list" }, labels.map((label) => el("button", { class: "small-btn", attrs: { type: "button" }, text: label }))),
    hint ? el("div", { class: "diag-suite-hint", text: hint }) : null
  );
}

function diagDetails(title, group, labels) {
  return el("details", { class: "diag-suite-button-group", data: { suiteGroup: group } },
    el("summary", { class: "diag-suite-button-group-title", text: title }),
    el("div", { class: "diag-suite-button-list" }, labels.map((label) => el("button", { class: "small-btn", attrs: { type: "button" }, text: label })))
  );
}

function renderQueueList(items) {
  const queueList = el("div", { class: "queue-list", id: "queueList" });
  const groups = queueGroups(visibleQueueItems(items));
  if (!groups.length) {
    queueList.appendChild(el("div", { class: "gallery-empty", text: "No prompts queued." }));
    return queueList;
  }

  for (const group of groups.slice(0, 80)) {
    const first = group.items[0] || {};
    queueList.appendChild(el("div", { class: `queue-row is-${group.statusClass}` },
      icon(first.mode === FLOW_MODES.textToImage ? "image" : "movie"),
      el("span", { class: "q-copy" },
        el("span", { class: "q-title", text: group.title }),
        el("span", { class: "q-prompt", text: group.preview })
      ),
      el("span", { class: "q-status", text: group.statusLabel, attrs: { title: group.statusTitle } }),
      el("button", { class: "queue-row-btn", data: { queueAction: "remove", queueId: group.id }, attrs: { type: "button" } }, icon("close"))
    ));
  }
  return queueList;
}

function queueGroups(items = [], options = {}) {
  const grouped = new Map();
  const locale = options.locale || "en";
  for (const item of visibleQueueItems(items || [])) {
    const id = String(item.jobId || item.batchId || item.groupId || item.id || "").trim();
    if (!id) continue;
    if (!grouped.has(id)) grouped.set(id, { id, items: [] });
    grouped.get(id).items.push(item);
  }
  return [...grouped.values()].map((group) => {
    const first = group.items[0] || {};
    const queueRunning = options.queueRunning === true;
    return {
      ...group,
      queueRunning,
      title: first.jobTitle || `${modeLabel(first.mode, locale)} - ${group.items.length} prompt${group.items.length === 1 ? "" : "s"}`,
      preview: first.prompt || first.id || "Untitled job",
      statusClass: groupStatusClass(group.items, { queueRunning }),
      statusLabel: groupStatusLabel(group.items, { queueRunning }),
      statusTitle: group.items.map((item) => `${item.status || "pending"}: ${item.prompt || item.id || ""}`).join("\n")
    };
  });
}

function visibleQueueItems(items = []) {
  return (items || []).filter((item) => item?.hiddenFromLiveQueue !== true && item?.generationRepair !== true);
}

function modeLabel(mode = "", locale = "en") {
  const keyMap = {
    [FLOW_MODES.textToImage]: "createImage",
    [FLOW_MODES.imageToVideo]: "frameToVideo",
    [FLOW_MODES.textToVideo]: "textToVideo",
    [FLOW_MODES.ingredientsToVideo]: "ingredients",
    [FLOW_MODES.videoToVideo]: "videoToVideo",
  };
  const key = keyMap[mode];
  return key ? translate(key, {}, locale) : translate("appName", {}, locale);
}

function modeIconName(mode = "") {
  if (mode === FLOW_MODES.textToImage) return "palette";
  if (mode === FLOW_MODES.imageToVideo) return "image";
  if (mode === FLOW_MODES.textToVideo) return "videocam";
  if (mode === FLOW_MODES.ingredientsToVideo) return "grid_view";
  if (mode === FLOW_MODES.videoToVideo) return "movie_edit";
  return "auto_awesome";
}

function modeAccentClass(mode = "") {
  if (mode === FLOW_MODES.textToImage) return "is-create-image";
  if (mode === FLOW_MODES.imageToVideo) return "is-frame-to-video";
  if (mode === FLOW_MODES.textToVideo) return "is-text-to-video";
  if (mode === FLOW_MODES.ingredientsToVideo) return "is-ingredients";
  if (mode === FLOW_MODES.videoToVideo) return "is-video-to-video";
  return "is-default-mode";
}

function groupStatusClass(items = [], options = {}) {
  if (items.some((item) => ["failed", "blocked", "download_failed"].includes(liveQueueEffectiveStatus(item, options)))) return "error";
  if (items.some((item) => ["starting", "submitting", "generating", "downloading", "retrying"].includes(liveQueueEffectiveStatus(item, options)))) return "running";
  if (items.some((item) => ["download_incomplete", "partial"].includes(liveQueueEffectiveStatus(item, options)))) return "warning";
  if (items.length && items.every((item) => ["complete", "done"].includes(liveQueueEffectiveStatus(item, options)))) return "done";
  return "pending";
}

function groupStatusLabel(items = [], options = {}) {
  const total = items.length;
  const statuses = items.map((item) => liveQueueEffectiveStatus(item, options));
  const failed = statuses.filter((status) => ["failed", "blocked", "download_failed"].includes(status)).length;
  const incomplete = statuses.filter((status) => status === "download_incomplete").length;
  const partial = statuses.filter((status) => status === "partial").length;
  const retrying = statuses.filter((status) => status === "retrying").length;
  const done = statuses.filter((status) => ["complete", "done"].includes(status)).length;
  const running = statuses.filter((status) => ["starting", "submitting", "generating", "downloading", "retrying"].includes(status)).length;
  if (failed) return `${failed} failed`;
  if (retrying) return `${retrying} retrying`;
  if (running) return `${running} running`;
  if (incomplete) return `${incomplete} missing download`;
  if (partial) return `${partial} partial`;
  if (done && done === total) return "done";
  if (done) return `${done}/${total} done`;
  return `${total} prompt${total === 1 ? "" : "s"}`;
}

function galleryTab(tab, label, active, count, iconName) {
  return el("button", {
    class: `gallery-subtab${active === tab ? " active" : ""}`,
    data: { gallery: tab },
    attrs: { type: "button" }
  }, icon(iconName), el("span", { text: label }), el("span", { class: "gallery-tab-count", text: String(count) }));
}

function galleryLayoutButton(mode, active, iconName, title) {
  return el("button", {
    class: `gallery-layout-btn${active === mode ? " active" : ""}`,
    data: { galleryView: mode },
    attrs: { type: "button", title, "aria-pressed": active === mode ? "true" : "false" }
  }, icon(iconName));
}

function gallerySizeButton(size, active, label) {
  return el("button", {
    class: `gallery-layout-btn${active === size ? " active" : ""}`,
    data: { gallerySize: size },
    attrs: { type: "button", "aria-pressed": active === size ? "true" : "false" },
    text: label
  });
}

function renderGalleryHeader(active, state, activeCount, activeSelectedCount, selectedVideos, locale) {
  const isVideos = active === "videos";
  return el("div", { class: "gallery-header" },
    el("div", { class: "gallery-controls" },
      isVideos
        ? select("videoDownloadRes", state.control.presets.videoDownloadResolution, [["720p", "720p"], ["1080p", "1080p"], ["4k", "4K (50 credits)"]], "videoDownloadResolution")
        : select("downloadResolution", state.control.presets.imageAutoDownloadResolution, [["1k", "1K"], ["2k", "2K"], ["4k", "4K"]], "imageAutoDownloadResolution"),
      el("button", { id: "gallery-sync-btn", class: "scan-btn-gold", attrs: { type: "button", title: isVideos ? "Scroll Flow and scan generated videos" : "Scroll Flow and scan generated images" } }, icon("manage_search"), el("span", { text: translate("scanAll", {}, locale) })),
      !isVideos ? el("button", { id: "importGalleryImagesBtn", attrs: { type: "button", title: "Import local images into Gallery" } }, icon("upload"), el("span", { text: translate("importImages", {}, locale) })) : null,
      !isVideos ? el("input", { id: "galleryImportInput", attrs: { type: "file", accept: "image/*", multiple: true, hidden: true } }) : null,
      !isVideos ? el("button", { class: "inline-help-tip", data: { galleryHelp: "import" }, attrs: { type: "button", title: translate("galleryImportTip", {}, locale) }, text: "?" }) : null,
      select(isVideos ? "videoSortOrder" : "imageSortOrder", state.ui.gallerySortOrder || "num-asc", [["default", "Newest First"], ["num-asc", "1 -> 99"], ["num-desc", "99 -> 1"], ["az", "A -> Z"], ["za", "Z -> A"]], "gallerySortOrder"),
      el("span", { id: isVideos ? "videoGalleryCount" : "galleryCount", text: `${activeCount} ${translate(isVideos ? "videos" : "images", {}, locale)}` })
    ),
    isVideos ? renderVideoPlaybackToolbar(selectedVideos, state, locale) : null,
    el("div", { class: "gallery-actions gallery-selection-actions" },
      el("button", { id: isVideos ? "gallery-random-videos-btn" : "gallery-random-pick-btn", attrs: { type: "button", disabled: activeCount ? null : "disabled", title: "Randomly select one media item per prompt group" } }, icon("casino"), el("span", { text: translate("randomPick", {}, locale) })),
      !isVideos ? el("button", { id: "gallery-pick-matched-btn", attrs: { type: "button", disabled: activeCount ? null : "disabled", title: "Select items with matching prompt groups" } }, icon("auto_fix_high"), el("span", { text: translate("pickMatched", {}, locale) })) : null,
      !isVideos ? el("button", { class: "inline-help-tip", data: { galleryHelp: "matched" }, attrs: { type: "button", title: translate("galleryMatchedTip", {}, locale) }, text: "?" }) : null,
      el("button", { id: "gallery-select-all-btn", attrs: { type: "button", disabled: activeCount ? null : "disabled", title: `Select all visible ${isVideos ? "videos" : "images"}` } }, icon("select_all"), el("span", { text: translate("selectAll", {}, locale) })),
      el("button", { id: "gallery-deselect-all-btn", attrs: { type: "button", disabled: activeSelectedCount ? null : "disabled", title: "Clear selected media" } }, icon("deselect"), el("span", { text: translate("deselectAll", {}, locale) })),
      el("button", { class: "inline-help-tip", data: { galleryHelp: "selection" }, attrs: { type: "button", title: translate("gallerySelectionTip", {}, locale) }, text: "?" })
    ),
    renderGalleryInlineHelp(state, locale),
    el("div", { class: "gallery-actions" },
      el("button", {
        id: "gallery-download-btn",
        class: state.ui.galleryDownloadFeedback?.status === "running" ? "is-download-running" : "",
        attrs: {
          type: "button",
          disabled: activeSelectedCount && state.ui.galleryDownloadFeedback?.status !== "running" ? null : "disabled",
          "aria-busy": state.ui.galleryDownloadFeedback?.status === "running" ? "true" : "false"
        }
      }, icon("download"), el("span", { text: translate("download", {}, locale) }), el("span", { id: "gallery-download-count", text: `(${activeSelectedCount})` })),
      renderGalleryDownloadFeedback(state, locale),
      !isVideos
        ? el("button", { id: "gallery-animate-images-btn", attrs: { type: "button", disabled: activeCount ? null : "disabled" } }, icon("video_library"), el("span", { text: translate("animateImages", {}, locale) }))
        : null
    )
  );
}

function renderGalleryDownloadFeedback(state, locale = "en") {
  const feedback = state.ui?.galleryDownloadFeedback || {};
  if (feedback.status === "idle") return null;
  const labelKey = feedback.status === "running"
    ? "stagePreparingDownload"
    : feedback.status === "error" ? "stageDownloadFailed" : "stageRunComplete";
  const resolution = feedback.deliveredResolution || feedback.requestedResolution;
  const unavailable = feedback.unavailableResolution
    ? translate("galleryDownloadResolutionUnavailable", { resolution: feedback.unavailableResolution }, locale)
    : "";
  const progress = feedback.total > 0 ? `${feedback.completed}/${feedback.total}` : "";
  const detail = feedback.status === "error"
    ? [feedback.error, resolution, unavailable].filter(Boolean).join(" · ")
    : [progress, resolution, unavailable].filter(Boolean).join(" · ");
  return el("div", {
    id: "gallery-download-status",
    class: `gallery-download-status is-${feedback.status}`,
    attrs: { role: "status", "aria-live": "polite" }
  }, icon(feedback.status === "error" ? "error" : feedback.status === "running" ? "hourglass_top" : "check_circle"),
  el("span", { text: [translate(labelKey, {}, locale), detail].filter(Boolean).join(" · ") }));
}

function renderGalleryInlineHelp(state, locale = "en") {
  const key = String(state.ui.galleryHelpKey || "");
  const copy = {
    import: translate("galleryImportHelp", {}, locale),
    matched: translate("galleryMatchedHelp", {}, locale),
    selection: translate("gallerySelectionHelp", {}, locale),
  }[key];
  if (!copy) return null;
  return el("div", { id: "galleryInlineHelpPanel", class: "gallery-inline-help-panel" },
    el("span", { text: copy }),
    el("button", { id: "galleryHelpCloseBtn", attrs: { type: "button", title: translate("close", {}, locale) }, text: translate("close", {}, locale) })
  );
}

function renderVideoPlaybackToolbar(selectedVideos, state, locale = "en") {
  const speed = String(state.ui.videoSpeed || "1");
  const volume = String(state.ui.videoVolume || "0.05");
  return el("div", { class: "gallery-toolbar-row" },
    el("div", { class: "video-playback-group" },
      el("label", { text: translate("speedLabel", {}, locale) }),
      el("input", { id: "videoSpeedSlider", attrs: { type: "range", min: "0.25", max: "6", step: "0.05", value: speed } }),
      el("input", { id: "videoSpeedInput", class: "video-speed-input", value: speed, attrs: { type: "text", inputmode: "decimal", "aria-label": "Video speed" } }),
      el("label", { text: translate("volLabel", {}, locale) }),
      el("input", { id: "videoVolumeSlider", attrs: { type: "range", min: "0", max: "1", step: "0.05", value: volume } })
    ),
    el("div", { class: "gallery-toolbar-spacer" })
  );
}

function renderGalleryHowTo(active, locale = "en") {
  if (active !== "images") return null;
  return el("details", { id: "galleryHowTo", class: "gallery-how-to" },
    el("summary", null,
      icon("help_outline"),
      el("span", { text: translate("howToUse", {}, locale) }),
      el("span", { class: "workflow-click-expand", text: translate("clickToExpand", {}, locale) })
    ),
    el("div", { class: "gallery-how-to-body" },
      el("strong", { text: translate("i2vWorkflowLabel", {}, locale) }),
      el("br"),
      el("span", { text: translate("galleryWorkflowStep1", {}, locale) }),
      el("br"),
      el("span", { text: translate("galleryWorkflowStep2", {}, locale) }),
      el("br"),
      el("span", { text: translate("galleryWorkflowStep3", {}, locale) })
    )
  );
}

function renderLiveQueueGallery(state, selected = new Set(), options = {}) {
  const locale = state.control?.presets?.language || "en";
  const activeProjectId = String(state.runtime?.projectId || "").trim();
  const projectQueueItems = liveQueueItemsForProject(state.queue?.items, activeProjectId);
  const projectQueueState = {
    ...state,
    queue: {
      ...(state.queue || {}),
      items: projectQueueItems
    }
  };
  const allGroups = queueGroups(projectQueueItems, { queueRunning: state.queue?.running === true, locale });
  const activeGroups = allGroups.filter((group) => group.statusClass !== "done");
  const groups = options.showAllGroups
    ? (activeGroups.length ? activeGroups : allGroups)
    : (activeGroups.length ? activeGroups : allGroups.slice(-1)).slice(-1);
  const agentModel = collectAgentLiveQueueRows(state);
  const agentHasRun = Boolean(agentModel.run?.id || agentModel.rows.length);
  const agentCanonical = agentModel.active && agentRunIsCanonical({
    run: agentModel.run,
    hasRows: agentModel.rows.length > 0,
    queueItems: projectQueueItems,
    queueRunning: state.queue?.running === true
  });
  const agentPanel = renderAgentModeLiveQueuePanel(state, locale, agentModel);
  const groupNodes = groups.map((group) => {
    const prioritizedItems = [...group.items].sort((left, right) => {
      const rank = (item) => ["failed", "blocked", "running", "submitting", "generating", "pending"].indexOf(String(item?.status || "").toLowerCase());
      const leftRank = rank(left);
      const rightRank = rank(right);
      return (leftRank < 0 ? 99 : leftRank) - (rightRank < 0 ? 99 : rightRank);
    });
    const visibleItems = prioritizedItems.slice(0, 50);
    return el("div", { class: `live-queue-group is-${group.statusClass}` },
    renderLiveQueueStage(group, locale, state.queue?.runtimeEvents || []),
    el("div", { class: "live-queue-row live-queue-group-head" },
      icon(group.items[0]?.mode === FLOW_MODES.textToImage ? "image" : "movie"),
      el("span", { class: "q-copy" },
        el("span", { class: "q-title", text: group.title }),
        el("span", { class: "q-prompt", text: group.preview })
      ),
      el("span", { class: "q-status", text: group.statusLabel })
    ),
    el("div", { class: "live-queue-task-list" },
      renderAgentRowLimitNotice(visibleItems.length, group.items.length, locale),
      visibleItems.map((item) => renderLiveQueueTaskRow(item, group.items.indexOf(item), selected, { queueRunning: group.queueRunning }, locale))
    )
  );
  });
  return el("div", { id: "liveQueueContainer", class: "live-queue-wrap" },
    renderLiveQueueManager(projectQueueState, locale),
    agentPanel && agentHasRun && !agentCanonical
      ? el("details", { class: "live-queue-history agent-live-history" },
        el("summary", { text: translate("history", {}, locale) }),
        agentPanel)
      : agentPanel,
    renderLiveQueueRecoveryCard(projectQueueState, groups, locale),
    agentCanonical ? null : renderLiveQueueReviewDuck(groups, locale),
    groups.length
      ? (agentCanonical
        ? el("details", { class: "live-queue-history" },
          el("summary", { text: translate("history", {}, locale) }),
          groupNodes)
        : groupNodes)
      : el("div", { class: "gallery-empty", text: translate("noLiveQueueItems", {}, locale) }),
    renderHardQuotaModal(projectQueueState, locale),
    renderModelAccessModal(projectQueueState, locale),
    renderApiPathBlockedModal(projectQueueState, locale),
    renderRepairFailedModal(projectQueueState, locale)
  );
}

function renderLiveQueueRecoveryCard(state = {}, groups = [], locale = "en") {
  const items = visibleQueueItems(state.queue?.items || []);
  const runtimeEvents = Array.isArray(state.queue?.runtimeEvents) ? state.queue.runtimeEvents : [];
  const quotaTask = hardQuotaTask(items);
  if (quotaTask) {
    const fields = buildRecoveryReportFields(quotaTask, { tasks: items });
    return el("section", { class: "live-quota-banner", attrs: { role: "status" } },
      el("span", { class: "live-quota-icon" }, icon("warning")),
      el("span", { class: "live-quota-copy" },
        el("strong", { text: translate("flowQuotaReachedTitle", {}, locale) }),
        el("span", { text: translate("quotaCountsSummary", {
          completed: fields.completedTaskCountBeforeStop,
          downloaded: fields.downloadedCountBeforeStop,
          pending: fields.pendingTaskCountAfterStop
        }, locale) })
      ),
      el("button", { class: "live-quota-action", data: { copySupportSummary: quotaTask.id }, attrs: { type: "button", title: translate("copySupportSummary", {}, locale) } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) }))
    );
  }
  const modelAccess = modelAccessTask(items);
  if (modelAccess) {
    const fields = buildRecoveryReportFields(modelAccess, { tasks: items });
    return el("section", { class: "live-model-access-banner", attrs: { role: "status" } },
      el("span", { class: "live-model-access-icon" }, icon("lock")),
      el("span", { class: "live-model-access-copy" },
        el("strong", { text: fields.userFacingFailureTitle || translate("flowModelAccessDeniedTitle", {}, locale) }),
        el("span", { text: translate("modelAccessSummary", {
          model: modelAccess.model || translate("unknown", {}, locale),
          mode: modeLabel(modelAccess.mode || "", locale),
          path: modelAccess.submitPath || modelAccess.submitPathPreference || translate("unknown", {}, locale)
        }, locale) })
      ),
      el("button", { class: "live-model-access-action", data: { modelAccessAction: "chooseSupportedModel", modelAccessTaskId: modelAccess.id }, attrs: { type: "button", title: translate("chooseSupportedModel", {}, locale) } }, icon("tune"), el("span", { text: translate("chooseSupportedModel", {}, locale) })),
      el("button", { class: "live-model-access-action", data: { copySupportSummary: modelAccess.id }, attrs: { type: "button", title: translate("copySupportSummary", {}, locale) } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) }))
    );
  }
  const apiBlockedTask = apiPathBlockedTask(items);
  if (apiBlockedTask) {
    const fields = buildRecoveryReportFields(apiBlockedTask, { tasks: items });
    return el("section", { class: "live-api-path-banner", attrs: { role: "status" } },
      el("span", { class: "live-api-path-icon" }, icon("public")),
      el("span", { class: "live-api-path-copy" },
        el("strong", { text: translate("apiPathBlockedTitle", {}, locale) }),
        el("span", { text: translate("apiPathBlockedQuestion", {}, locale) }),
        el("small", { text: translate("apiPathBlockedSummary", {
          model: fields.modelSubmittedByApi || apiBlockedTask.model || translate("unknown", {}, locale),
          refs: fields.refCount,
          reused: fields.refsReusedForDomVerification ? translate("yes", {}, locale) : translate("no", {}, locale)
        }, locale) })
      ),
      el("button", { class: "live-api-path-action", data: { apiPathAction: "continueBrowserMode", apiPathTaskId: apiBlockedTask.id }, attrs: { type: "button", title: translate("continueWithBrowserMode", {}, locale) } }, icon("play_arrow"), el("span", { text: translate("continueWithBrowserMode", {}, locale) }))
    );
  }
  const latestRecovery = [...runtimeEvents].reverse().find((event) => String(event?.type || "").startsWith("flow_session_recovery."));
  const repairTask = items.find((item) => String(item?.recoveryPolicy || "") === "safe_recovery_ladder")
    || groups.flatMap((group) => group.items || []).find((item) => item?.flowSessionRecoveryAttempts);
  if (!latestRecovery && !repairTask) return null;
  const recovered = latestRecovery?.type === "flow_session_recovery.success" || repairTask?.recoveryFinalOutcome === "recovered";
  const failed = latestRecovery?.type === "flow_session_recovery.pause_unresolved" || repairTask?.recoveryFinalOutcome === "repair_failed";
  const task = repairTask || {};
  const step = task.recoveryCurrentStep || latestRecovery?.recoveryLevel || "classify_and_snapshot";
  const attempt = Number(task.recoveryAttemptCount || latestRecovery?.attempt || task.flowSessionRecoveryAttempts || 1) || 1;
  const failureClass = task.failureClass || latestRecovery?.failureClass || "flow_session_heat";
  return el("section", { class: `live-recovery-card${recovered ? " is-recovered" : ""}${failed ? " is-failed" : ""}`, attrs: { role: "status" } },
    el("span", { class: "live-recovery-spinner" }, icon(recovered ? "check_circle" : (failed ? "error" : "sync"))),
    el("span", { class: "live-recovery-copy" },
      el("strong", { text: translate(recovered ? "flowRecovered" : (failed ? "flowRepairFailed" : "repairingFlowSession"), {}, locale) }),
      el("span", { text: translate(recovered ? "flowRecoveredBody" : (failed ? "flowRepairFailedBody" : "repairingFlowSessionBody"), {}, locale) }),
      el("small", { text: translate("recoveryStepSummary", {
        step,
        attempt,
        failureclass: failureClass,
        mode: modeLabel(task.mode || "", locale),
        modelsuffix: task.model ? ` - ${task.model}` : ""
      }, locale) })
    )
  );
}

export function withoutDismissed(items = [], dismissedTaskIds = []) {
  const dismissed = new Set((dismissedTaskIds || []).map((id) => String(id || "")).filter(Boolean));
  return (items || []).filter((item) => !dismissed.has(String(item?.id || "")));
}

export function hardQuotaTask(items = [], dismissedTaskIds = []) {
  return withoutDismissed(items, dismissedTaskIds).find((item) => item?.recoverySkippedBecauseHardQuota === true || item?.failureClass === "flow_model_daily_quota_reached") || null;
}

export function modelAccessTask(items = [], dismissedTaskIds = []) {
  return withoutDismissed(items, dismissedTaskIds).find((item) => item?.recoverySkippedBecauseModelAccess === true ||
    item?.failureClass === "flow_model_access_denied" ||
    item?.failureClass === "api_first_model_access_denied") || null;
}

export function apiPathBlockedTask(items = [], dismissedTaskIds = []) {
  return withoutDismissed(items, dismissedTaskIds).find((item) => item?.apiFirstQuotaSuspected === true &&
    item?.userConfirmedSwitchToDom !== true &&
    item?.domVerificationAttempted === true &&
    (
      item?.domVerificationResult === "success" ||
      item?.finalQuotaClassification === "api_first_blocked_dom_available" ||
      item?.failureClass === "api_first_blocked_dom_available"
    )) || null;
}

function repairFailedTask(items = [], dismissedTaskIds = []) {
  const dismissed = new Set((dismissedTaskIds || []).map((id) => String(id || "")).filter(Boolean));
  return (items || []).find((item) => !dismissed.has(String(item?.id || "")) && (
    item?.recoveryFinalOutcome === "repair_failed" ||
    item?.failureClass === "flow_session_heat_unresolved" ||
    item?.failureClass === "dom_settings_menu_not_open" ||
    item?.recoveryFinalOutcome === "blocked_task_dom_settings_unavailable"
  )) || null;
}

function renderHardQuotaModal(state = {}, locale = "en") {
  const items = visibleQueueItems(state.queue?.items || []);
  const task = hardQuotaTask(items, state.ui?.dismissedRecoveryTaskIds || []);
  if (!task) return null;
  const fields = buildRecoveryReportFields(task, { tasks: items });
  return el("div", { class: "live-quota-modal-backdrop", data: { recoveryTaskId: task.id }, attrs: { role: "dialog", "aria-modal": "true", "aria-label": translate("flowQuotaReachedTitle", {}, locale) } },
    el("section", { class: "live-quota-modal" },
      el("button", { class: "live-quota-close", data: { quotaAction: "resumeLater" }, attrs: { type: "button", title: translate("resumeLater", {}, locale) } }, icon("close")),
      el("span", { class: "live-quota-modal-icon" }, icon("warning")),
      el("h3", { text: translate("flowQuotaReachedTitle", {}, locale) }),
      el("p", { text: translate("flowQuotaReachedBody", {}, locale) }),
      el("dl", { class: "live-quota-detail-grid" },
        quotaDetail("deployed_code", translate("model", {}, locale), task.model || translate("unknown", {}, locale)),
        quotaDetail("movie", translate("mode", {}, locale), modeLabel(task.mode || "", locale)),
        quotaDetail("check_circle", translate("completedBeforeStop", {}, locale), String(fields.completedTaskCountBeforeStop)),
        quotaDetail("download", translate("downloadedBeforeStop", {}, locale), String(fields.downloadedCountBeforeStop)),
        quotaDetail("schedule", translate("pendingCount", {}, locale), String(fields.pendingTaskCountAfterStop)),
        quotaDetail("warning", translate("error", {}, locale), task.lastError || task.flowErrorCode || "429 RESOURCE_EXHAUSTED", "is-error")
      ),
      el("div", { class: "live-quota-next" },
        el("strong", { text: translate("whatYouCanDo", {}, locale) }),
        el("ul", null,
          el("li", { text: translate("waitForQuotaReset", {}, locale) }),
          el("li", { text: translate("switchToAnotherModel", {}, locale) }),
          el("li", { text: translate("reduceRepeatResumeLater", {}, locale) })
        )
      ),
      el("div", { class: "live-quota-modal-actions" },
        el("button", { class: "primary", data: { quotaAction: "resumeLater" }, attrs: { type: "button" } }, icon("schedule"), el("span", { text: translate("resumeLater", {}, locale) })),
        el("button", { data: { quotaAction: "chooseSupportedModel" }, attrs: { type: "button" } }, icon("tune"), el("span", { text: translate("changeModelForPendingRows", {}, locale) })),
        el("button", { data: { copySupportSummary: task.id }, attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
        el("button", { data: { quotaAction: "exportReport" }, attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
      )
    )
  );
}

function renderModelAccessModal(state = {}, locale = "en") {
  const items = visibleQueueItems(state.queue?.items || []);
  const task = modelAccessTask(items, state.ui?.dismissedRecoveryTaskIds || []);
  if (!task) return null;
  const fields = buildRecoveryReportFields(task, { tasks: items });
  const affected = items.filter((item) => item?.failureClass === task.failureClass || item?.model === task.model).length || 1;
  return el("div", { class: "live-model-access-modal-backdrop", data: { recoveryTaskId: task.id }, attrs: { role: "dialog", "aria-modal": "true", "aria-label": translate("flowModelAccessDeniedTitle", {}, locale) } },
    el("section", { class: "live-model-access-modal" },
      el("button", { class: "live-model-access-close", data: { modelAccessAction: "pause" }, attrs: { type: "button", title: translate("pause", {}, locale) } }, icon("close")),
      el("span", { class: "live-model-access-modal-icon" }, icon("lock")),
      el("h3", { text: translate("flowModelAccessDeniedTitle", {}, locale) }),
      el("p", { text: fields.userFacingFailureBody || translate("flowModelAccessDeniedBody", {}, locale) }),
      el("dl", { class: "live-quota-detail-grid" },
        quotaDetail("deployed_code", translate("model", {}, locale), task.model || translate("unknown", {}, locale)),
        quotaDetail("movie", translate("mode", {}, locale), modeLabel(task.mode || "", locale)),
        quotaDetail("route", translate("submitPathLabel", {}, locale), task.submitPath || task.submitPathPreference || translate("unknown", {}, locale)),
        quotaDetail("format_list_numbered", translate("affectedTaskCount", {}, locale), String(affected)),
        quotaDetail("warning", translate("error", {}, locale), task.lastError || task.flowErrorCode || "403 PERMISSION_DENIED", "is-error")
      ),
      el("div", { class: "live-quota-modal-actions" },
        el("button", { class: "primary", data: { modelAccessAction: "chooseSupportedModel", modelAccessTaskId: task.id }, attrs: { type: "button" } }, icon("tune"), el("span", { text: translate("chooseSupportedModel", {}, locale) })),
        el("button", { data: { modelAccessAction: "switchPendingRowsToSelectedModel", modelAccessTaskId: task.id }, attrs: { type: "button" } }, icon("swap_horiz"), el("span", { text: translate("switchPendingRowsToSelectedModel", {}, locale) })),
        el("button", { data: { copySupportSummary: task.id }, attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
        el("button", { data: { modelAccessAction: "exportReport" }, attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
      )
    )
  );
}

function renderApiPathBlockedModal(state = {}, locale = "en") {
  const items = visibleQueueItems(state.queue?.items || []);
  const task = apiPathBlockedTask(items, state.ui?.dismissedRecoveryTaskIds || []);
  if (!task) return null;
  const fields = buildRecoveryReportFields(task, { tasks: items });
  return el("div", { class: "live-api-path-modal-backdrop", data: { recoveryModalKind: "api_path_blocked", recoveryTaskId: task.id }, attrs: { role: "dialog", "aria-modal": "true", "aria-label": translate("apiPathBlockedTitle", {}, locale) } },
    el("section", { class: "live-api-path-modal" },
      el("button", { class: "live-api-path-close", data: { apiPathAction: "pause", recoveryControl: "close" }, attrs: { type: "button", title: translate("pause", {}, locale) } }, icon("close")),
      el("span", { class: "live-api-path-modal-icon" }, icon("public")),
      el("h3", { text: translate("apiPathBlockedTitle", {}, locale) }),
      el("p", { text: translate("apiPathBlockedBody", {}, locale) }),
      el("dl", { class: "live-quota-detail-grid" },
        quotaDetail("deployed_code", translate("model", {}, locale), fields.modelSubmittedByApi || task.model || translate("unknown", {}, locale)),
        quotaDetail("movie", translate("mode", {}, locale), modeLabel(task.mode || "", locale)),
        quotaDetail("image", translate("referenceCount", {}, locale), String(fields.refCount)),
        quotaDetail("sync_saved_locally", translate("refsReused", {}, locale), fields.refsReusedForDomVerification ? translate("yes", {}, locale) : translate("no", {}, locale)),
        quotaDetail("playlist_add_check", translate("pendingRowsPreserved", {}, locale), fields.pendingRowsPreserved ? translate("yes", {}, locale) : translate("no", {}, locale))
      ),
      el("div", { class: "live-quota-modal-actions" },
        el("button", { class: "primary", data: { apiPathAction: "continueBrowserMode", apiPathTaskId: task.id, recoveryControl: "continue-browser-mode" }, attrs: { type: "button" } }, icon("play_arrow"), el("span", { text: translate("continueWithBrowserMode", {}, locale) })),
        el("button", { data: { apiPathAction: "pause", recoveryControl: "pause" }, attrs: { type: "button" } }, icon("pause"), el("span", { text: translate("pause", {}, locale) })),
        el("button", { data: { copySupportSummary: task.id }, attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
        el("button", { data: { apiPathAction: "exportReport", recoveryControl: "export-report" }, attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
      )
    )
  );
}

function renderRepairFailedModal(state = {}, locale = "en") {
  const items = visibleQueueItems(state.queue?.items || []);
  const task = repairFailedTask(items, state.ui?.dismissedRecoveryTaskIds || []);
  if (!task) return null;
  const retryTask = buildRetryModalTask(task) || {};
  const fields = buildRecoveryReportFields(task, { tasks: items });
  const steps = Array.isArray(fields.recoveryStepsAttempted) && fields.recoveryStepsAttempted.length
    ? fields.recoveryStepsAttempted.join(", ")
    : (task.recoveryCurrentStep || "safe recovery ladder");
  const title = fields.userFacingFailureTitle || translate("repairFailedModalTitle", {}, locale);
  const body = fields.userFacingFailureBody || translate("repairFailedModalBody", {}, locale);
  const isSettingsMenuFailure = task.failureClass === "dom_settings_menu_not_open" || task.recoveryFinalOutcome === "blocked_task_dom_settings_unavailable";
  return el("div", {
    class: "live-repair-failed-modal-backdrop",
    data: {
      recoveryModalKind: isSettingsMenuFailure ? "dom_settings_menu_not_open" : "repair_failed",
      retryOriginalMode: retryTask.retryOriginalMode || "",
      retrySurface: retryTask.retrySurface || "",
      retryMaxInputs: retryTask.retryMaxInputs ?? ""
    },
    attrs: { role: "dialog", "aria-modal": "true", "aria-label": title }
  },
    el("section", { class: "live-repair-failed-modal" },
      el("button", { class: "live-repair-failed-close", data: { repairAction: "close", repairTaskId: task.id, recoveryControl: "close" }, attrs: { type: "button", title: translate("close", {}, locale) } }, icon("close")),
      el("span", { class: "live-repair-failed-modal-icon" }, icon("build_circle")),
      el("h3", { text: title }),
      el("p", { text: body }),
      el("dl", { class: "live-quota-detail-grid" },
        quotaDetail("build", translate("recoveryStepsAttempted", {}, locale), steps),
        quotaDetail("error", translate("finalError", {}, locale), task.lastError || task.flowErrorCode || task.failureClass || translate("unknown", {}, locale), "is-error"),
        quotaDetail("recommend", translate("recommendedAction", {}, locale), fields.recommendedNextAction || translate("resumeLater", {}, locale))
      ),
      el("div", { class: "live-quota-modal-actions" },
        el("button", { class: "primary", data: { repairAction: "retryBrowserMode", repairTaskId: task.id, recoveryControl: "retry-browser-mode", retryOriginalMode: retryTask.retryOriginalMode || "", retrySurface: retryTask.retrySurface || "", retryInputRoles: (retryTask.retryInputRoles || []).join(","), retryFrameSlots: (retryTask.retryFrameSlots || []).join(","), retryMaxInputs: retryTask.retryMaxInputs ?? "", retryPromptFirst: retryTask.retryPromptFirst === true ? "1" : "0" }, attrs: { type: "button" } }, icon("replay"), el("span", { text: translate("retryBrowserMode", {}, locale) })),
        el("button", { data: { repairAction: "skipContinue", repairTaskId: task.id, recoveryControl: "skip-current-row" }, attrs: { type: "button" } }, icon("skip_next"), el("span", { text: translate("skipCurrentRowContinue", {}, locale) })),
        el("button", { data: { repairAction: "backToEditor", repairTaskId: task.id, recoveryControl: "back-to-editor" }, attrs: { type: "button" } }, icon("arrow_back"), el("span", { text: translate("backToEditor", {}, locale) })),
        el("button", { data: { repairAction: "pause", repairTaskId: task.id, recoveryControl: "pause" }, attrs: { type: "button" } }, icon("pause"), el("span", { text: translate("pause", {}, locale) })),
        el("button", { data: { copySupportSummary: task.id }, attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) })),
        el("button", { data: { repairAction: "exportReport", repairTaskId: task.id, recoveryControl: "export-report" }, attrs: { type: "button" } }, icon("download"), el("span", { text: translate("exportReport", {}, locale) }))
      )
    )
  );
}

function quotaDetail(iconName, label, value, className = "") {
  return el("div", { class: `live-quota-detail${className ? ` ${className}` : ""}` },
    el("dt", null, icon(iconName), el("span", { text: label })),
    el("dd", { text: value || "" })
  );
}

function renderLiveQueueReviewDuck(groups = [], locale = "en") {
  const items = groups.flatMap((group) => Array.isArray(group.items) ? group.items : []);
  if (!items.length) return null;
  const statuses = items.map((item) => liveQueueEffectiveStatus(item, { queueRunning: false }));
  const hasActive = statuses.some((status) => REVIEW_DUCK_ACTIVE_STATUSES.has(status));
  if (hasActive) return null;
  const hasSupport = statuses.some((status) => REVIEW_DUCK_SUPPORT_STATUSES.has(status));
  const allComplete = statuses.every((status) => REVIEW_DUCK_DONE_STATUSES.has(status));
  if (!hasSupport && !allComplete) return null;

  const kind = hasSupport ? "support" : "success";
  const actionKeys = REVIEW_DUCK_ACTION_KEYS[kind] || [];
  const ariaKey = kind === "support" ? "reviewDuckSupportAria" : "reviewDuckSuccessAria";
  const statusKey = kind === "support" ? "reviewDuckSupportStatus" : "reviewDuckCompleteStatus";
  const copyKey = kind === "support" ? "reviewDuckSupportCopy" : "reviewDuckSuccessCopy";
  return el("aside", {
    class: `review-duck-banner is-${kind}`,
    attrs: {
      "aria-label": translate(ariaKey, {}, locale),
      "data-review-duck-state": kind
    }
  },
    el("span", { class: "review-duck-stage", attrs: { "aria-hidden": "true" } },
      el("span", { class: "review-duck-sprite" }),
      kind === "success" ? el("span", { class: "review-duck-confetti one" }) : null,
      kind === "success" ? el("span", { class: "review-duck-confetti two" }) : null,
      kind === "success" ? el("span", { class: "review-duck-confetti three" }) : null
    ),
    el("span", { class: "review-duck-bubble" },
      el("span", { class: "review-duck-status", text: translate(statusKey, {}, locale) }),
      el("span", { class: "review-duck-message", text: translate(copyKey, {}, locale) }),
      el("span", { class: "review-duck-actions" },
        actionKeys.map((action) => renderReviewDuckAction(action, locale))
      )
    )
  );
}

function renderReviewDuckAction(action, locale = "en") {
  const labels = {
    chromeStore: "reviewDuckChromeStore",
    discord: "reviewDuckDiscord",
    telegram: "reviewDuckTelegram",
    exportReport: "reviewDuckExportReport"
  };
  const labelKey = labels[action] || "reviewDuckChromeStore";
  return el("button", {
    class: "review-duck-link",
    data: { reviewDuckAction: action },
    attrs: { type: "button", title: translate(labelKey, {}, locale) }
  }, el("span", { text: translate(labelKey, {}, locale) }));
}

function renderLiveQueueManager(state, locale = "en") {
  const items = visibleQueueItems(state.queue.items || []);
  const doneCount = items.filter((item) => ["complete", "done", "failed", "blocked", "download_failed", "download_incomplete"].includes(liveQueueEffectiveStatus(item))).length;
  const blockedCount = items.filter((item) => ["failed", "blocked", "download_failed"].includes(liveQueueEffectiveStatus(item))).length;
  const incompleteDownloadCount = items.filter((item) => liveQueueEffectiveStatus(item) === "download_incomplete").length;
  const openCount = Math.max(0, items.length - doneCount);
  return el("div", { class: "live-queue-manager" },
    el("div", { class: "live-queue-manager-copy" },
      el("strong", { text: translate("queueManager", {}, locale) }),
      el("span", { text: `${items.length} total - ${openCount} active - ${doneCount} finished${blockedCount ? ` - ${blockedCount} need attention` : ""}${incompleteDownloadCount ? ` - ${incompleteDownloadCount} missing download` : ""}` })
    ),
    el("div", { class: "live-queue-manager-actions" },
      el("button", { id: "liveQueueResumeBtn", attrs: { type: "button", disabled: blockedCount ? null : "disabled", title: "Resume blocked or failed tasks" } }, icon("play_arrow"), el("span", { text: translate("resume", {}, locale) })),
      el("button", { id: "liveQueueStopBtn", attrs: { type: "button", disabled: state.queue.running ? null : "disabled", title: "Stop the running queue" } }, icon("stop"), el("span", { text: translate("stop", {}, locale) })),
      el("button", { id: "liveQueueClearDoneBtn", attrs: { type: "button", disabled: doneCount ? null : "disabled", title: "Clear completed, failed, and blocked tasks" } }, icon("playlist_remove"), el("span", { text: translate("clearFinished", {}, locale) })),
      el("button", { id: "liveQueueClearAllBtn", class: "danger-soft", attrs: { type: "button", disabled: items.length ? null : "disabled", title: "Stop and clear the full queue" } }, icon("delete_sweep"), el("span", { text: translate("clearQueue", {}, locale) }))
    )
  );
}

function renderAgentModeLiveQueuePanel(state = {}, locale = "en", model = collectAgentLiveQueueRows(state)) {
  if (!model.active) return null;
  const activeTab = agentLiveQueueTab(state, model);
  return el("section", { class: "agent-live-panel", attrs: { "aria-label": translate("agentModeLiveQueue", {}, locale) } },
    el("div", { class: "agent-live-head" },
      el("div", { class: "agent-live-title" },
        icon("smart_toy"),
        el("span", null,
          el("strong", { text: translate("agentModeLiveQueue", {}, locale) }),
          el("small", { text: translate("agentModeLiveQueueDesc", {}, locale) })
        )
      ),
      el("div", { class: "agent-live-bridge" },
        el("span", { class: "agent-live-bridge-label", text: translate("agentBridgeStatus", {}, locale) }),
        renderAgentBridgeStatus(state, locale)
      )
    ),
    renderAgentLiveQueueSummary(model, locale),
    renderAgentLiveQueueReason(model, locale),
    renderAgentPendingAction(model, locale),
    el("div", { class: "agent-live-tabs", attrs: { role: "tablist", "aria-label": translate("agentModeLiveQueue", {}, locale) } },
      renderAgentLiveQueueTab("images", translate("agentImagesTab", {}, locale), model.summary.expectedImages, activeTab === "images"),
      renderAgentLiveQueueTab("videos", translate("agentVideosTab", {}, locale), model.summary.expectedVideos, activeTab === "videos")
    ),
    activeTab === "images"
      ? renderAgentImagesTab(model, locale)
      : renderAgentVideosTab(model, locale),
    model.run?.pendingRetry ? renderAgentRetryPreview(model, locale) : null
  );
}

function collectAgentLiveQueueRows(state = {}) {
  const run = firstObject(
    state.control?.agentRun,
    state.queue?.agentRun,
    state.agentRun,
    state.agent
  );
  const reconciliation = firstObject(
    run.reconciliation,
    state.control?.agentReconciliation,
    state.queue?.agentReconciliation,
    state.agent?.reconciliation
  );
  const matrix = firstObject(
    run.matrix,
    run.manifest,
    state.control?.agentMatrix,
    state.control?.agentManifest,
    state.agent?.manifest
  );
  const sourceRows = firstNonEmptyArray(
    reconciliation.rows,
    run.reconciledRows,
    run.rows,
    state.queue?.agentRows,
    state.agent?.rows,
    matrix.rows
  );
  const rows = sourceRows.map((row, index) => normalizeAgentLiveRow(row, index)).filter(Boolean);
  const projectMatches = agentRunMatchesActiveProject(run, state.runtime?.projectId);
  const active = projectMatches && Boolean(
    run.id ||
    run.status ||
    rows.length ||
    sourceRows.length ||
    state.control?.presets?.submitPath === "agent_first"
  );
  return {
    active,
    projectMatches,
    run,
    reconciliation,
    rows,
    summary: agentLiveSummary(run, reconciliation, rows)
  };
}

function renderAgentLiveQueueSummary(model = {}, locale = "en") {
  const summary = model.summary || {};
  const unresolved = Math.max(0, Number(summary.expectedImages || 0) - Number(summary.landedImages || 0))
    + Math.max(0, Number(summary.expectedVideos || 0) - Number(summary.landedVideos || 0));
  const terminal = isAgentRunTerminal(model.run?.status);
  const blockedLabelKey = agentPreSubmitBlockedLabelKey(model.run?.status);
  const labelKey = blockedLabelKey || (unresolved ? (terminal ? "agentMissing" : "agentWaiting") : "agentReview");
  const className = blockedLabelKey ? "is-blocked" : (unresolved ? (terminal ? "is-fail" : "is-pending") : "is-pending");
  return el("div", { class: "agent-live-summary" },
    agentMetric("agentImagesTab", `${summary.landedImages || 0}/${summary.expectedImages || 0}`, locale),
    agentMetric("agentVideosTab", `${summary.landedVideos || 0}/${summary.expectedVideos || 0}`, locale),
    agentMetric(labelKey, unresolved || summary.qaPending || 0, locale, className)
  );
}

function renderAgentLiveQueueReason(model = {}, locale = "en") {
  const run = model.run || {};
  const summary = model.summary || {};
  const unresolved = Math.max(0, Number(summary.expectedImages || 0) - Number(summary.landedImages || 0))
    + Math.max(0, Number(summary.expectedVideos || 0) - Number(summary.landedVideos || 0));
  const blockerMessage = String(run.blocker?.message || run.lastError || "").trim();
  const pendingRetry = run.pendingRetry && typeof run.pendingRetry === "object" ? run.pendingRetry : null;
  let text = "";
  let className = "";
  if (blockerMessage) {
    text = translate("agentRunNeedsAttention", { reason: blockerMessage }, locale);
    className = " is-blocked";
  } else if (pendingRetry) {
    text = translate("agentRetryPreparedNotSubmitted", { row: pendingRetry.rowId || "-" }, locale);
    className = " is-pending";
  } else if (unresolved && run.submitted === true) {
    text = translate("agentSubmittedWaitingForOutputs", { count: unresolved }, locale);
  } else if (unresolved && /reconcil/i.test(String(run.status || ""))) {
    text = translate("agentReconcilingOutputs", { count: unresolved }, locale);
  } else if (unresolved) {
    text = translate("agentRunNotSubmitted", {}, locale);
    className = " is-blocked";
  }
  return text
    ? el("div", { class: `agent-live-reason${className}`, attrs: { role: "status", title: text } }, icon(className.includes("blocked") ? "warning" : "info"), el("span", { text }))
    : null;
}

function renderAgentPendingAction(model = {}, locale = "en") {
  const run = model.run || {};
  const action = run.pendingAction && typeof run.pendingAction === "object" ? run.pendingAction : null;
  if (!action) return null;
  const text = String(action.text || run.agentContext?.uiState?.latestMessage?.text || "").trim();
  if (action.kind === "credit_confirmation") {
    const amountKnown = action.creditAmountKnown === true;
    const amount = Math.max(0, Number(action.creditAmount || 0) || 0);
    const persistentAllowed = run.creditPolicy?.persistentApproval === true;
    return el("section", { class: "agent-pending-action is-credit", attrs: { role: "alert" } },
      el("strong", { text: translate("agentQuestionTitle", {}, locale) }),
      el("p", { text: text || (amountKnown ? translate("agentCreditKnownAmount", { amount }, locale) : translate("agentCreditUnknownBlocked", {}, locale)) }),
      !amountKnown ? el("p", { class: "agent-action-warning", text: translate("agentCreditUnknownBlocked", {}, locale) }) : null,
      el("div", { class: "agent-pending-actions" },
        el("button", {
          data: { agentCreditAction: "approve_once" },
          attrs: { type: "button", disabled: amountKnown ? null : "disabled" }
        }, icon("check"), el("span", { text: translate("agentCreditApproveOnce", {}, locale) })),
        persistentAllowed ? el("button", {
          data: { agentCreditAction: "approve_persistent" },
          attrs: { type: "button", disabled: amountKnown ? null : "disabled" }
        }, icon("verified"), el("span", { text: translate("agentCreditApprovePersistent", {}, locale) })) : null,
        el("button", { data: { agentCreditAction: "keep_paused" }, attrs: { type: "button" } }, icon("pause"), el("span", { text: translate("agentKeepPaused", {}, locale) }))
      )
    );
  }
  const choices = (Array.isArray(action.choices) ? action.choices : [])
    .map((choice) => typeof choice === "string" ? choice : String(choice?.label || choice?.text || ""))
    .map((choice) => choice.trim())
    .filter(Boolean)
    .slice(0, 6);
  return el("section", { class: "agent-pending-action", attrs: { role: "alert" } },
    el("strong", { text: translate("agentQuestionTitle", {}, locale) }),
    text ? el("p", { text }) : null,
    choices.length ? el("div", { class: "agent-pending-actions" }, choices.map((choice) => el("button", {
      data: { agentAnswerChoice: choice },
      attrs: { type: "button", title: choice }
    }, el("span", { text: choice })))) : null,
    el("div", { class: "agent-custom-answer" },
      el("input", { id: "agentQuestionAnswerInput", attrs: { type: "text", placeholder: translate("agentQuestionCustomPlaceholder", {}, locale) } }),
      el("button", { data: { agentAnswerCustom: "1" }, attrs: { type: "button" } }, icon("send"), el("span", { text: translate("agentQuestionSend", {}, locale) }))
    )
  );
}

function agentMetric(labelKey, value, locale = "en", className = "") {
  const displayValue = typeof value === "string" && value.trim()
    ? value.trim()
    : String(Number.isFinite(Number(value)) ? Number(value) : 0);
  return el("span", { class: `agent-live-metric${className ? ` ${className}` : ""}` },
    el("b", { text: displayValue }),
    el("small", { text: translate(labelKey, {}, locale) })
  );
}

function renderAgentDownloadPlan(model = {}, locale = "en") {
  const run = model.run || {};
  const plan = run.artifactPlan || run.downloadPlan || {};
  const autoDownload = run.autoDownload === true || plan.autoDownload === true;
  const folder = plan.runFolder || plan.folder || run.downloadFolder || "Auto-Flow";
  const expectedImages = firstFiniteNumber(plan.expectedImages, run.expectedImages, model.summary?.expectedImages);
  const expectedVideos = firstFiniteNumber(plan.expectedVideos, run.expectedVideos, model.summary?.expectedVideos);
  const seenVideos = firstFiniteNumber(run.lastSeenFreshVideos, run.selectedMediaIds?.length, model.summary?.landedVideos);
  const status = String(run.status || (autoDownload ? "waiting_for_outputs" : "manual")).replace(/[_-]+/g, " ");
  return el("div", { class: `agent-download-plan${autoDownload ? " is-monitoring" : ""}` },
    el("div", { class: "agent-download-plan-copy" },
      el("strong", { text: translate("agentModeDownloadPlan", {}, locale) }),
      el("span", { text: translate("agentModeDownloadPlanHelp", {}, locale) })
    ),
    el("div", { class: "agent-download-plan-stats" },
      agentDownloadMetric("agentDownloadStatus", status, locale),
      agentDownloadMetric("agentDownloadFolderLabel", folder, locale),
      agentDownloadMetric("agentDownloadExpectedLabel", `${expectedImages} img / ${expectedVideos} vid`, locale),
      agentDownloadMetric("agentDownloadSeenLabel", seenVideos, locale)
    ),
    el("div", { class: "agent-download-plan-actions" },
      el("button", {
        data: { agentDownloadAction: "toggle_monitor" },
        attrs: { type: "button", title: translate("agentToggleDownloadMonitor", {}, locale) }
      }, icon(autoDownload ? "pause_circle" : "play_circle"), el("span", { text: autoDownload ? translate("agentModeDownloadMonitorOn", {}, locale) : translate("agentModeDownloadMonitorOff", {}, locale) })),
      el("button", {
        data: { agentDownloadAction: "refresh_gallery" },
        attrs: { type: "button", title: translate("agentRefreshGallery", {}, locale) }
      }, icon("sync"), el("span", { text: translate("agentRefreshGallery", {}, locale) }))
    )
  );
}

function agentDownloadMetric(labelKey, value, locale = "en") {
  return el("span", { class: "agent-download-metric" },
    el("small", { text: translate(labelKey, {}, locale) }),
    el("b", { text: String(value || "0") })
  );
}

function renderAgentRetryPreview(model = {}, locale = "en") {
  const run = model.run || {};
  const request = run.pendingRetry && typeof run.pendingRetry === "object" ? run.pendingRetry : null;
  const prompt = request ? agentRetryPromptText(request, model) : "";
  return el("div", { class: `agent-retry-preview${request ? " active" : ""}` },
    el("div", { class: "agent-retry-preview-head" },
      el("div", null,
        el("strong", { text: translate("agentRetryPromptPreview", {}, locale) }),
        el("span", { text: request ? `${translate("agentRetrySelectedRows", {}, locale)}: ${request.rowId || "-"}` : translate("agentNoRetrySelected", {}, locale) })
      ),
      el("button", {
        data: { agentCopyRetryPrompt: "1" },
        attrs: { type: "button", disabled: request ? null : "disabled", title: translate("agentCopyRetryPrompt", {}, locale) }
      }, icon("content_copy"), el("span", { text: translate("agentCopyRetryPrompt", {}, locale) }))
    ),
    el("pre", { class: "agent-retry-prompt-text" }, el("code", { text: prompt || translate("agentNoRetrySelected", {}, locale) })),
    el("textarea", {
      id: "agentRetryCustomPrompt",
      class: "agent-retry-custom-prompt",
      attrs: {
        rows: "3",
        disabled: request ? null : "disabled",
        placeholder: translate("agentRetryCustomPromptPlaceholder", {}, locale),
        "aria-label": translate("agentRetryCustomPromptPlaceholder", {}, locale)
      },
      text: prompt
    }),
    el("button", {
      class: "primary",
      data: { agentSubmitRetry: "1" },
      attrs: { type: "button", disabled: request ? null : "disabled" }
    }, icon("send"), el("span", { text: translate("agentSubmitScopedRetry", {}, locale) }))
  );
}

function renderAgentRetryQueue(model = {}, locale = "en") {
  const requests = Array.isArray(model.run?.retryRequests) ? model.run.retryRequests : [];
  return el("div", { class: "agent-retry-queue" },
    el("div", { class: "agent-retry-queue-head" },
      el("strong", { text: translate("agentRetryQueue", {}, locale) }),
      el("span", { text: `${requests.length} ${translate("agentRetrySelectedRows", {}, locale)}` }),
      el("button", {
        data: { agentRetryQueueAction: "clear" },
        attrs: { type: "button", disabled: requests.length ? null : "disabled" }
      }, icon("playlist_remove"), el("span", { text: translate("agentClearRetryQueue", {}, locale) }))
    ),
    requests.length
      ? el("div", { class: "agent-retry-queue-list" }, requests.slice(0, 6).map((request) => el("span", { class: "agent-retry-queue-pill" },
          el("b", { text: request.rowId || "-" }),
          el("small", { text: formatAgentLabel(request.mode || "video_only") })
        )))
      : null
  );
}

function agentRetryPromptText(request = {}, model = {}) {
  if (request.prompt) return String(request.prompt);
  const rowId = String(request.rowId || "").trim() || "row";
  const mode = formatAgentLabel(request.mode || "video_only");
  const issues = normalizeAgentIssues(request.issues).map(formatAgentLabel);
  const mediaId = request.mediaId || latestAgentMediaIdForRow(model, rowId);
  return [
    `Retry [${rowId}] ${mode}.`,
    issues.length ? `Issues: ${issues.join(", ")}.` : "Issue: needs human review.",
    mediaId ? `Use latest media context: ${mediaId}.` : "",
    "Do not regenerate unrelated rows."
  ].filter(Boolean).join(" ");
}

function latestAgentMediaIdForRow(model = {}, rowId = "") {
  const row = (model.rows || []).find((item) => item.rowId === rowId);
  return row?.latestVideo?.mediaId || row?.videos?.at?.(-1)?.mediaId || "";
}

function renderAgentLiveQueueTab(tab, label, count, active) {
  return el("button", {
    class: `agent-live-tab${active ? " active" : ""}`,
    data: { agentLiveTab: tab },
    attrs: { type: "button", role: "tab", "aria-selected": active ? "true" : "false" }
  },
    el("span", { text: label }),
    el("b", { text: String(Number.isFinite(Number(count)) ? Number(count) : 0) })
  );
}

const AGENT_LIVE_RENDER_LIMIT = 50;

function renderAgentRowLimitNotice(visibleCount, totalCount, locale = "en") {
  if (totalCount <= visibleCount) return null;
  return el("div", {
    class: "agent-live-limit-notice",
    text: translate("agentRowsShown", { visible: visibleCount, total: totalCount }, locale)
  });
}

function agentVisibleVideoRows(rows = []) {
  const pending = rows.filter((row) => !row?.latestVideo?.mediaId || !["complete", "completed", "downloaded"].includes(String(row?.status || "").toLowerCase()));
  const pendingIds = new Set(pending.map((row) => row.rowId));
  return [...pending, ...rows.filter((row) => !pendingIds.has(row.rowId))].slice(0, AGENT_LIVE_RENDER_LIMIT);
}

function renderAgentImagesTab(model = {}, locale = "en") {
  const rows = model.rows || [];
  const entries = rows.flatMap((row) => row.imageSlots.map((slot) => ({ row, slot })));
  if (!entries.length) return renderAgentEmptyState(locale);
  const visibleEntries = entries.slice(0, AGENT_LIVE_RENDER_LIMIT);
  return el("div", { class: "agent-live-table agent-live-images" },
    renderAgentRowLimitNotice(visibleEntries.length, entries.length, locale),
    renderAgentImageHeader(locale),
    visibleEntries.map(({ row, slot }, index) => renderAgentImageRow(row, slot, locale, index))
  );
}

function renderAgentVideosTab(model = {}, locale = "en") {
  const rows = model.rows || [];
  if (!rows.length) return renderAgentEmptyState(locale);
  const visibleRows = agentVisibleVideoRows(rows);
  return el("div", { class: "agent-live-table agent-live-videos" },
    renderAgentRowLimitNotice(visibleRows.length, rows.length, locale),
    renderAgentVideoHeader(locale),
    visibleRows.map((row) => renderAgentVideoRow(row, locale))
  );
}

function renderAgentImageHeader(locale = "en") {
  return el("div", { class: "agent-live-row agent-live-header" },
    el("span", { text: translate("agentRowId", {}, locale) }),
    el("span", { text: translate("agentImagePreview", {}, locale) }),
    el("span", { text: translate("agentStatus", {}, locale) }),
    el("span", { text: translate("action", {}, locale) })
  );
}

function renderAgentVideoHeader(locale = "en") {
  return el("div", { class: "agent-live-row agent-live-header" },
    el("span", { text: translate("agentRowId", {}, locale) }),
    el("span", { text: translate("agentOutput", {}, locale) }),
    el("span", { text: translate("agentStatus", {}, locale) }),
    el("span", { text: translate("action", {}, locale) })
  );
}

function renderAgentImageRow(row = {}, slot = {}, locale = "en", previewIndex = 0) {
  return el("div", { class: `agent-live-row agent-live-image-row is-${sanitizeAgentClassToken(agentOutputState(slot.status || row.status, slot.mediaId))}` },
    el("span", { class: "agent-live-row-id", text: row.displayRowId || row.rowId }),
    renderAgentOutputCell({
      media: renderAgentImageThumb(row, slot, locale, previewIndex),
      meta: renderAgentOutputVersionMeta(slot)
    }),
    renderAgentOutputStatusChip(agentImageStatusMeta(slot, locale)),
    el("button", {
      class: "agent-retry-btn",
      data: {
        agentRetryRow: row.rowId,
        agentRetryMode: "image_only",
        agentRetrySlot: slot.slotId || "",
        agentRetryMediaId: slot.mediaId || ""
      },
      attrs: { type: "button", title: translate("agentRetryRow", {}, locale) }
    }, icon("restart_alt"), el("span", { text: translate("agentRetry", {}, locale) }))
  );
}

function renderAgentVideoRow(row = {}, locale = "en") {
  const latest = row.latestVideo || row.videos.find((video) => video.isLatest) || row.videos.at(-1) || {};
  const issues = latest.issueChips?.length ? latest.issueChips : row.issueChips;
  return el("div", { class: `agent-live-row agent-live-video-row is-${sanitizeAgentClassToken(agentOutputState(row.status, latest.mediaId))}` },
    el("span", { class: "agent-live-row-id", text: row.displayRowId || row.rowId }),
    renderAgentOutputCell({
      media: renderAgentVideoThumb(row, latest, locale),
      meta: renderAgentOutputVersionMeta(latest)
    }),
    renderAgentOutputStatusChip(agentVideoStatusMeta(row, latest, locale)),
    el("button", {
      class: "agent-retry-btn",
      data: {
        agentRetryRow: row.rowId,
        agentRetryMode: "video_only",
        agentRetryMediaId: latest.mediaId || "",
        agentRetryIssues: issues.join(",")
      },
      attrs: { type: "button", title: translate("agentRetryLatest", {}, locale) }
    }, icon("restart_alt"), el("span", { text: translate("agentRetry", {}, locale) }))
  );
}

function renderAgentImageThumb(row = {}, slot = {}, locale = "en", previewIndex = 0) {
  const mediaId = String(slot.mediaId || "").trim();
  const src = normalizeMediaRedirectUrl(slot.thumbnailUrl || slot.mediaUrl || "", mediaId)
    || (mediaId ? buildMediaRedirectUrl({ mediaId }) : "");
  if (!src) {
    return el("span", { class: "agent-live-thumb empty", attrs: { title: translate("agentStillSlotId", {}, locale) } }, icon("image"));
  }
  const preview = {
    src,
    kind: "images",
    mediaId,
    galleryId: `${row.rowId}:${slot.slotId || mediaId}`,
    title: `${row.displayRowId || row.rowId} ${slot.slotId || ""}`.trim()
  };
  return el("button", {
    class: "agent-live-thumb",
    data: {
      livePreviewUrl: src,
      livePreviewKind: "images",
      livePreviewTitle: preview.title,
      livePreviewGroup: "agent-images",
      livePreviewIndex: String(previewIndex)
    },
    attrs: { type: "button", title: translate("doubleClickToPreview", {}, locale) }
  }, liveQueuePreviewMedia(preview, "thumb"));
}

function renderAgentVideoThumb(row = {}, video = {}, locale = "en") {
  const mediaId = String(video.mediaId || "").trim();
  const mediaUrl = normalizeMediaRedirectUrl(video.mediaUrl || "", mediaId)
    || (mediaId ? buildMediaRedirectUrl({ mediaId }) : "");
  if (!mediaUrl) {
    const titleKey = agentPreSubmitBlockedLabelKey(row.status) || (isAgentOutputMissing(row.status) ? "agentMissing" : "agentWaiting");
    return el("span", { class: "agent-live-thumb empty", attrs: { title: translate(titleKey, {}, locale) } }, icon("movie"));
  }
  const thumbnailUrl = normalizeMediaThumbnailUrl(video.thumbnailUrl || "", mediaId)
    || (mediaId ? buildMediaThumbnailUrl({ mediaId }) : mediaUrl);
  const title = `${row.displayRowId || row.rowId} ${translate("agentVideo", {}, locale)}`.trim();
  return el("button", {
    class: "agent-live-thumb",
    data: {
      livePreviewUrl: mediaUrl,
      livePreviewKind: "videos",
      livePreviewTitle: title,
      livePreviewGroup: "agent-videos"
    },
    attrs: { type: "button", title: translate("doubleClickToPreview", {}, locale) }
  }, liveQueuePreviewMedia({
    src: thumbnailUrl,
    kind: "videos",
    thumbnailOnly: true,
    mediaId,
    galleryId: `${row.rowId}:${mediaId}`,
    title
  }, "thumb"));
}

function renderAgentOutputCell({ media, meta } = {}) {
  return el("span", { class: "agent-output-cell" },
    media || el("span", { class: "agent-live-thumb empty" }, icon("image")),
    meta
  );
}

function renderAgentOutputVersionMeta(output = {}) {
  const mediaId = String(output.mediaId || "").trim();
  if (!mediaId) return null;
  const version = firstFiniteNumber(output.version, output.versionsCount, 1);
  const versionsCount = firstFiniteNumber(output.versionsCount, version, 1);
  const displayVersion = Math.max(version, versionsCount);
  if (displayVersion <= 1) return null;
  const previousCount = Array.isArray(output.previousMediaIds) ? output.previousMediaIds.length : Math.max(0, versionsCount - 1);
  const title = previousCount > 0
    ? `v${displayVersion} replaced ${previousCount} previous output${previousCount === 1 ? "" : "s"}`
    : `v${displayVersion}`;
  return el("span", { class: "agent-output-version", attrs: { title } },
    el("b", { text: `v${displayVersion}` })
  );
}

function renderAgentOutputStatusChip(meta = {}) {
  return el("span", { class: `agent-status-chip is-${sanitizeAgentClassToken(meta.state || "waiting")}`, text: meta.label || "-" });
}

function agentImageStatusMeta(slot = {}, locale = "en") {
  if (slot.mediaId) return { state: "ready", label: translate("agentReady", {}, locale) };
  const blockedLabelKey = agentPreSubmitBlockedLabelKey(slot.status);
  if (blockedLabelKey) return { state: "blocked", label: translate(blockedLabelKey, {}, locale) };
  if (String(slot.status || "").toLowerCase().includes("missing")) return { state: "missing", label: translate("agentMissing", {}, locale) };
  return { state: "waiting", label: translate("agentWaiting", {}, locale) };
}

function agentVideoStatusMeta(row = {}, latest = {}, locale = "en") {
  if (!latest.mediaId) {
    const blockedLabelKey = agentPreSubmitBlockedLabelKey(row.status);
    if (blockedLabelKey) return { state: "blocked", label: translate(blockedLabelKey, {}, locale) };
    return isAgentOutputMissing(row.status)
      ? { state: "missing", label: translate("agentMissing", {}, locale) }
      : { state: "waiting", label: translate("agentWaiting", {}, locale) };
  }
  const qaStatus = normalizeAgentQaStatus(latest.qaStatus || row.qaStatus);
  if (qaStatus === "fail") return { state: "missing", label: translate("agentRetry", {}, locale) };
  return { state: "ready", label: translate("agentReady", {}, locale) };
}

function agentOutputState(status = "", mediaId = "") {
  if (mediaId) return "ready";
  const raw = String(status || "").toLowerCase();
  if (isAgentPreSubmitBlockedStatus(raw)) return "blocked";
  if (isAgentOutputMissing(raw)) return "missing";
  return "waiting";
}

function isAgentOutputMissing(status = "") {
  const raw = String(status || "").toLowerCase();
  if (isAgentPreSubmitBlockedStatus(raw)) return false;
  return raw.includes("missing") || raw.includes("failed") || raw.includes("blocked");
}

function isAgentPreSubmitBlockedStatus(status = "") {
  return /^(setup_blocked|pre_submit_blocked)$/i.test(String(status || "").trim());
}

function agentPreSubmitBlockedLabelKey(status = "") {
  const normalized = String(status || "").trim().toLowerCase();
  if (normalized === "setup_blocked") return "agentSetupBlocked";
  if (normalized === "pre_submit_blocked") return "agentPreSubmitBlocked";
  return "";
}

function renderAgentQaChip(status = "pending", locale = "en") {
  const normalized = normalizeAgentQaStatus(status);
  const labelKey = normalized === "pass"
    ? "agentQaPass"
    : normalized === "fail"
      ? "agentQaFail"
      : "agentQaPending";
  return el("span", { class: `agent-qa-chip is-${normalized}`, text: translate(labelKey, {}, locale) });
}

function renderAgentIssueChips(issues = [], locale = "en") {
  const normalized = normalizeAgentIssues(issues);
  if (!normalized.length) return el("span", { class: "agent-issue-list is-empty" }, el("span", { class: "agent-live-empty", text: "-" }));
  return el("span", { class: "agent-issue-list", attrs: { title: translate("agentIssueChips", {}, locale) } },
    normalized.slice(0, 4).map((issue) => el("span", { class: "agent-issue-chip", text: formatAgentLabel(issue) })),
    normalized.length > 4 ? el("span", { class: "agent-issue-more", text: `+${normalized.length - 4}` }) : null
  );
}

function renderAgentEmptyState(locale = "en") {
  return el("div", { class: "agent-live-empty-state" },
    icon("hourglass_empty"),
    el("span", { text: translate("noAgentRowsYet", {}, locale) })
  );
}

function renderAgentBridgeStatus(state = {}, locale = "en") {
  const runtime = state.runtime || {};
  const bridge = runtime.connected !== true
    ? (runtime.activeTabId || runtime.projectId || runtime.pageUrl
      ? { className: "is-checking", label: translate("bridgeChecking", {}, locale), title: runtime.bridgeError || translate("bridgeCheckingHelp", {}, locale) }
      : { className: "is-offline", label: translate("bridgeOffline", {}, locale), title: translate("bridgeOfflineHelp", {}, locale) })
    : runtime.bridgeHealthy === true
      ? { className: "is-healthy", label: translate("bridgeHealthy", {}, locale), title: translate("bridgeHealthyHelp", {}, locale) }
      : runtime.bridgeDegraded === true
        ? { className: "is-degraded", label: translate("bridgeDegraded", {}, locale), title: runtime.bridgeError || translate("bridgeDegradedHelp", {}, locale) }
      : { className: "is-checking", label: translate("bridgeChecking", {}, locale), title: runtime.bridgeError || translate("bridgeCheckingHelp", {}, locale) };
  return el("span", {
    class: `afw-bridge-pill ${bridge.className}`,
    attrs: { title: bridge.title, "data-bridge-state": bridge.className.replace(/^is-/, "") }
  },
    el("span", { class: "afw-bridge-dot" }),
    el("span", { class: "afw-bridge-label", text: bridge.label })
  );
}

function normalizeAgentLiveRow(row = {}, index = 0) {
  const rowId = agentRowId(row, index);
  if (!rowId) return null;
  const imageMappingStrength = normalizeAgentMapping(row.imageMappingStrength || row.mappingConfidence || row.mapping || "");
  const imageSlots = normalizeAgentImageSlots(row, rowId, imageMappingStrength);
  const videos = normalizeAgentVideoVersions(row);
  const latestVideo = videos.find((video) => video.isLatest) || videos.at(-1) || null;
  const qaStatus = normalizeAgentQaStatus(row.qaStatus || row.qa?.status || latestVideo?.qaStatus || latestVideo?.qa?.status || "pending");
  const issueChips = normalizeAgentIssues(row.issueChips || row.issues || row.qaIssues || row.qa?.issues || latestVideo?.issueChips || latestVideo?.issues);
  return {
    rowId,
    displayRowId: String(row.displayTag || row.tag || row.rowId || rowId),
    title: String(row.title || row.prompt || row.videoPrompt || rowId),
    status: String(row.status || (latestVideo?.mediaId ? "video_landed" : imageSlots.some((slot) => slot.mediaId) ? "images_landed" : "pending")),
    expectedImages: firstFiniteNumber(row.expectedImages, row.expectedImageCount, imageSlots.length),
    expectedVideos: firstFiniteNumber(row.expectedVideos, row.expectedVideoCount, videos.length || 1),
    imageMappingStrength,
    imageSlots,
    videos,
    latestVideo,
    qaStatus,
    issueChips
  };
}

function normalizeAgentImageSlots(row = {}, rowId = "", fallbackMapping = "") {
  const sourceSlots = Array.isArray(row.imageSlots) && row.imageSlots.length
    ? row.imageSlots
    : Array.isArray(row.images) && row.images.length
      ? row.images
      : [];
  if (sourceSlots.length) {
    return sourceSlots.map((slot, index) => normalizeAgentImageSlot(slot, rowId, index, fallbackMapping));
  }
  const expectedImages = firstFiniteNumber(row.expectedImages, row.expectedImageCount, 0);
  return Array.from({ length: Math.max(0, expectedImages) }, (_, index) => normalizeAgentImageSlot({}, rowId, index, fallbackMapping));
}

function normalizeAgentImageSlot(slot = {}, rowId = "", index = 0, fallbackMapping = "") {
  const mediaId = agentMediaId(slot);
  return {
    slotId: String(slot.slotId || slot.imageAuditId || slot.afid || `${rowId}-IMG${index + 1}`),
    mediaId,
    mediaUrl: slot.mediaUrl || slot.url || "",
    thumbnailUrl: slot.thumbnailUrl || "",
    createTime: slot.createTime || "",
    prompt: String(slot.prompt || ""),
    version: firstFiniteNumber(slot.version, 0) || undefined,
    versionsCount: firstFiniteNumber(slot.versionsCount, 0) || undefined,
    isLatest: slot.isLatest === true,
    previousMediaIds: Array.isArray(slot.previousMediaIds) ? slot.previousMediaIds : [],
    status: String(slot.status || (mediaId ? "landed" : "pending")),
    mappingConfidence: normalizeAgentMapping(slot.mappingConfidence || slot.mapping || fallbackMapping || (mediaId ? "inferential" : "pending"))
  };
}

function normalizeAgentVideoVersions(row = {}) {
  const sourceVideos = Array.isArray(row.videos) && row.videos.length
    ? row.videos
    : Array.isArray(row.videoVersions) && row.videoVersions.length
      ? row.videoVersions
      : row.latestVideo
        ? [row.latestVideo]
        : [];
  return sourceVideos.map((video, index) => {
    const mediaId = agentMediaId(video);
    return {
      version: firstFiniteNumber(video.version, index + 1),
      mediaId,
      mediaUrl: video.mediaUrl || video.url || "",
      thumbnailUrl: video.thumbnailUrl || "",
      createTime: video.createTime || "",
      prompt: String(video.prompt || ""),
      isLatest: video.isLatest === true || index === sourceVideos.length - 1,
      qaStatus: normalizeAgentQaStatus(video.qaStatus || video.qa?.status || row.qaStatus || row.qa?.status || "pending"),
      issueChips: normalizeAgentIssues(video.issueChips || video.issues || video.qaIssues || video.qa?.issues || row.issueChips || row.issues)
    };
  });
}

function agentLiveSummary(run = {}, reconciliation = {}, rows = []) {
  const expectedImagesFromRows = rows.reduce((sum, row) => sum + Number(row.expectedImages || 0), 0);
  const expectedVideosFromRows = rows.reduce((sum, row) => sum + Number(row.expectedVideos || 0), 0);
  const landedImagesFromRows = rows.reduce((sum, row) => sum + row.imageSlots.filter((slot) => slot.mediaId || slot.status === "landed").length, 0);
  const landedVideosFromRows = rows.reduce((sum, row) => sum + row.videos.filter((video) => video.mediaId).length, 0);
  const qaCounts = rows.reduce((counts, row) => {
    const status = normalizeAgentQaStatus(row.latestVideo?.qaStatus || row.qaStatus);
    if (status === "pass") counts.qaPass += 1;
    else if (status === "fail") counts.qaFail += 1;
    else counts.qaPending += 1;
    return counts;
  }, { qaPending: 0, qaFail: 0, qaPass: 0 });
  return {
    expectedImages: firstFiniteNumber(run.expectedImages, run.expectedImageCount, reconciliation.expectedImages, expectedImagesFromRows),
    landedImages: firstFiniteNumber(run.landedImages, run.mappedImages, reconciliation.mappedImages, landedImagesFromRows),
    expectedVideos: firstFiniteNumber(run.expectedVideos, run.expectedVideoCount, reconciliation.expectedVideos, expectedVideosFromRows),
    landedVideos: firstFiniteNumber(run.landedVideos, run.presentVideos, reconciliation.presentVideos, run.lastSeenFreshVideos, landedVideosFromRows),
    qaPending: firstFiniteNumber(run.qaPending, qaCounts.qaPending),
    qaFail: firstFiniteNumber(run.qaFail, qaCounts.qaFail),
    qaPass: firstFiniteNumber(run.qaPass, qaCounts.qaPass)
  };
}

function agentLiveQueueTab(state = {}, model = {}) {
  const requested = String(state.ui?.agentLiveQueueTab || "").trim();
  if (requested === "images" || requested === "videos") return requested;
  return Number(model.summary?.expectedVideos || 0) > 0 ? "videos" : "images";
}

function agentRowId(row = {}, index = 0) {
  const explicit = String(row.rowId || row.id || "").trim();
  if (explicit) return explicit.replace(/^\[|\]$/g, "");
  const tag = String(row.tag || row.videoTag || row.finalVideoId || "").trim();
  if (tag) return tag.replace(/^\[|\]$/g, "");
  const clipNumber = Number.parseInt(row.clipNumber || row.rowIndex || index + 1, 10);
  return Number.isFinite(clipNumber) ? `V1-S${clipNumber}` : `row-${index + 1}`;
}

function firstObject(...values) {
  return values.find((value) => value && typeof value === "object" && !Array.isArray(value)) || {};
}

function firstNonEmptyArray(...values) {
  return values.find((value) => Array.isArray(value) && value.length) || [];
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return 0;
}

function agentMediaId(value = {}) {
  return String(value.mediaId || value.id || value.name || "").trim();
}

function normalizeAgentMapping(value = "") {
  const raw = String(value || "").trim().toLowerCase();
  if (raw === "deterministic") return "deterministic";
  if (raw === "inferential" || raw === "inferred") return "inferential";
  if (raw === "missing") return "missing";
  if (raw === "pending") return "pending";
  return raw || "pending";
}

function normalizeAgentQaStatus(value = "") {
  const raw = String(value || "").trim().toLowerCase();
  if (raw === "pass" || raw === "passed") return "pass";
  if (raw === "fail" || raw === "failed") return "fail";
  return "pending";
}

function normalizeAgentIssues(value = []) {
  const entries = Array.isArray(value) ? value : String(value || "").split(",");
  return [...new Set(entries.map((issue) => String(issue || "").trim()).filter(Boolean))];
}

function formatAgentLabel(value = "") {
  const text = String(value || "").trim().replace(/[_-]+/g, " ");
  return text || "-";
}

function shortAgentMediaId(mediaId = "") {
  const text = String(mediaId || "").trim();
  if (!text) return "-";
  return text.length > 16 ? `${text.slice(0, 8)}...${text.slice(-4)}` : text;
}

function sanitizeAgentClassToken(value = "") {
  return String(value || "pending").toLowerCase().replace(/[^a-z0-9_-]+/g, "-") || "pending";
}

function renderLiveQueueStage(group = {}, locale = "en", runtimeEvents = []) {
  const first = group.items?.[0] || {};
  const activeStatus = dominantLiveQueueStatus(group.items || [], { queueRunning: group.queueRunning === true });
  const requestedSubmitPath = String(first.submitPath || first.submitPathPreference || "api_first");
  const effectiveSubmitPath = String(first.submitPathPreference || requestedSubmitPath);
  const isApi = requestedSubmitPath !== "dom_first";
  const repairActive = requestedSubmitPath === "dom_first" && effectiveSubmitPath !== requestedSubmitPath;
  const apiBackendDomFallback = isApi && groupHasApiBackendDomFallback(group, runtimeEvents);
  const backendActive = isApi && !apiBackendDomFallback;
  const progress = liveQueueGroupProgress(group.items || []);
  const stage = liveQueueStageMeta(activeStatus, backendActive, progress, locale);
  const percent = progress.expectedCount ? Math.min(100, Math.round((progress.resultCount / progress.expectedCount) * 100)) : 0;
  const pathIcon = apiBackendDomFallback ? "sync" : (backendActive ? "cloud_sync" : "ads_click");
  const pathLabel = apiBackendDomFallback
    ? translate("apiToDomFallbackPath", {}, locale)
    : (backendActive ? translate("apiPath", {}, locale) : translate("domPath", {}, locale));
  const pathDetail = apiBackendDomFallback
    ? translate("apiToDomFallbackRun", {}, locale)
    : (repairActive ? translate("browserRunWithRepair", {}, locale) : (backendActive ? translate("backendRun", {}, locale) : translate("browserRun", {}, locale)));
  return el("div", { class: `live-queue-stage is-${activeStatus}` },
    el("div", { class: "live-stage-orb" },
      el("span", { class: `live-stage-icon ${["submitting", "generating", "downloading", "retrying"].includes(activeStatus) ? "is-active" : ""}` }, icon(stage.icon))
    ),
    el("div", { class: "live-stage-copy" },
      el("strong", { class: "live-stage-title", text: stage.title }),
      el("span", { class: "live-stage-desc", text: stage.detail }),
      el("span", { class: `live-stage-mode-pill ${backendActive ? "is-api" : "is-dom"}${apiBackendDomFallback ? " is-fallback" : ""}` },
        icon(pathIcon),
        el("b", { text: pathLabel }),
        el("em", { text: pathDetail })
      ),
      el("div", { class: "live-stage-progress", attrs: { "aria-label": `${progress.resultCount}/${progress.expectedCount}` } },
        el("span", { style: { width: `${percent}%` } })
      ),
      el("small", { text: `${progress.resultCount}/${progress.expectedCount} outputs${progress.savedCount ? ` - ${progress.savedCount} saved` : ""}` })
    ),
    el("div", { class: "live-stage-steps" },
      liveQueueStep("keyboard", translate("submitting", {}, locale), ["starting", "submitting"].includes(activeStatus)),
      liveQueueStep("auto_awesome_motion", translate("generating", {}, locale), ["generating"].includes(activeStatus)),
      liveQueueStep("restart_alt", "Retry", ["retrying"].includes(activeStatus)),
      liveQueueStep("download", translate("saving", {}, locale), ["downloading"].includes(activeStatus)),
      liveQueueStep("check_circle", translate("done", {}, locale), ["complete", "done"].includes(activeStatus))
    )
  );
}

function groupHasApiBackendDomFallback(group = {}, runtimeEvents = []) {
  const taskIds = new Set((group.items || [])
    .flatMap((item) => [item?.id, item?.taskId])
    .map((id) => String(id || "").trim())
    .filter(Boolean));
  const taskMatches = (event = {}) => {
    if (!taskIds.size) return true;
    return taskIds.has(String(event.taskId || "").trim());
  };
  if ((group.items || []).some((item) => String(item?.submitPath || "") === "dom_fallback" || item?.repairedFromApi === true)) {
    return true;
  }
  return (runtimeEvents || []).some((event) => {
    if (!taskMatches(event)) return false;
    const type = String(event?.type || "");
    if (type === "queue.api_backend.dom_fallback" || type === "queue.api_backend.dom_fallback_failed") return true;
    return type === "queue.submit.ok"
      && String(event?.submitPath || "") === "api_first"
      && String(event?.path || "") === "dom"
      && event?.repairedFromApi === true;
  });
}

function liveQueueGroupProgress(items = []) {
  return items.reduce((total, item) => {
    const progress = liveQueueProgress(item);
    return {
      resultCount: total.resultCount + progress.resultCount,
      expectedCount: total.expectedCount + progress.expectedCount,
      savedCount: total.savedCount + liveQueueSavedCount(item)
    };
  }, { resultCount: 0, expectedCount: 0, savedCount: 0 });
}

function dominantLiveQueueStatus(items = [], options = {}) {
  const statuses = items.map((item) => liveQueueEffectiveStatus(item, options));
  if (statuses.some((status) => ["failed", "blocked", "download_failed"].includes(status))) return "blocked";
  if (statuses.includes("downloading")) return "downloading";
  if (statuses.includes("retrying")) return "retrying";
  if (statuses.includes("partial")) return "partial";
  if (statuses.includes("generating")) return "generating";
  if (statuses.includes("submitting")) return "submitting";
  if (statuses.includes("starting")) return "starting";
  if (statuses.includes("download_incomplete")) return "download_incomplete";
  if (statuses.length && statuses.every((status) => ["complete", "done"].includes(status))) return "complete";
  return "pending";
}

function liveQueueStageMeta(status, isApi, progress = {}, locale = "en") {
  const t = (key) => translate(key, {}, locale);
  if (status === "starting") {
    return {
      icon: "hourglass_top",
      title: isApi ? t("stageStartingApi") : t("stageStartingBrowser"),
      detail: isApi ? t("stageStartingApiDetail") : t("stageStartingBrowserDetail"),
    };
  }
  if (status === "submitting") {
    return { icon: "keyboard", title: t("stageSubmittingTitle"), detail: t("stageSubmittingDetail") };
  }
  if (status === "generating") {
    if (progress.resultCount >= progress.expectedCount && progress.expectedCount > 0) {
      return { icon: "download", title: t("stagePreparingDownload"), detail: t("stagePreparingDownloadDetail") };
    }
    return {
      icon: "auto_awesome_motion",
      title: isApi ? t("stageGeneratingApi") : t("stageGeneratingDom"),
      detail: isApi ? t("stageGeneratingApiDetail") : t("stageGeneratingDomDetail"),
    };
  }
  if (status === "downloading") {
    return { icon: "download", title: t("stageSavingOutputs"), detail: t("stageSavingDetail") };
  }
  if (status === "retrying") {
    return { icon: "restart_alt", title: t("stageRetryingMissingOutputs"), detail: t("stageRetryingMissingOutputsDetail") };
  }
  if (status === "partial") {
    return { icon: "rule", title: t("stagePartialOutputs"), detail: t("stagePartialOutputsDetail") };
  }
  if (status === "download_failed") {
    return { icon: "error", title: t("stageDownloadFailed"), detail: t("stageDownloadFailedDetail") };
  }
  if (status === "download_incomplete") {
    return { icon: "download_for_offline", title: t("stageDownloadIncomplete"), detail: t("stageDownloadIncompleteDetail") };
  }
  if (status === "complete" || status === "done") {
    return { icon: "check_circle", title: t("stageRunComplete"), detail: t("stageRunCompleteDetail") };
  }
  if (status === "failed" || status === "blocked") {
    return { icon: "error", title: t("queueNeedsAttention"), detail: t("stageBlockedDetail") };
  }
  return { icon: "schedule", title: t("stageQueued"), detail: t("stageQueuedDetail") };
}

function liveQueueStep(iconName, label, active) {
  return el("span", { class: `live-stage-step${active ? " active" : ""}` },
    el("span", { class: "live-stage-step-icon" }, icon(iconName)),
    el("small", { text: label })
  );
}

function isT2iSavedReferenceAssetRowMissing(item = {}) {
  return item.failureClass === "t2i_saved_reference_asset_row_missing";
}

function modelDisplayName(model = "") {
  const raw = String(model || "").trim();
  if (raw === "nano_banana_2_lite") return "Nano Banana 2 Lite";
  if (raw === "nano_banana_2") return "Nano Banana 2";
  if (raw === "nano_banana_pro") return "Nano Banana Pro";
  return raw || "Default";
}

function renderT2iSavedReferenceRepairCard(item = {}, locale = "en") {
  if (!isT2iSavedReferenceAssetRowMissing(item)) return null;
  const taskId = String(item.id || "");
  const fileName = item.userActionRequiredReferenceFileName || item.refInputs?.[0]?.fileName || translate("t2iSavedReferenceDefaultFileName", {}, locale);
  const defaultApiError = translate("t2iSavedReferenceDefaultApiError", {}, locale);
  const originalError = item.apiBackendError || (/500/i.test(String(item.lastError || "")) ? defaultApiError : item.lastError || defaultApiError);
  const recovery = item.finalFallbackOutcome || translate("t2iSavedReferenceDefaultRecovery", {}, locale);
  return el("div", { class: "live-task-reference-repair" },
    el("div", { class: "live-task-reference-repair-copy" },
      el("strong", { text: item.userFacingFailureTitle || translate("t2iSavedReferenceMissingTitle", {}, locale) }),
      el("span", { text: item.userFacingFailureBody || translate("t2iSavedReferenceDefaultBody", {}, locale) }),
      el("dl", { class: "live-task-reference-repair-details" },
        el("dt", { text: translate("t2iSavedReferenceFileLabel", {}, locale) }), el("dd", { text: fileName }),
        el("dt", { text: translate("mode", {}, locale) }), el("dd", { text: translate("createImage", {}, locale) }),
        el("dt", { text: translate("model", {}, locale) }), el("dd", { text: modelDisplayName(item.model) }),
        el("dt", { text: translate("t2iSavedReferenceOriginalErrorLabel", {}, locale) }), el("dd", { text: originalError }),
        el("dt", { text: translate("t2iSavedReferenceRecoveryLabel", {}, locale) }), el("dd", { text: recovery })
      )
    ),
    el("div", { class: "live-task-reference-repair-actions" },
      el("button", { data: { liveTaskAction: "reuploadReference", taskId }, attrs: { type: "button" } }, icon("upload"), el("span", { text: translate("t2iSavedReferenceReuploadAction", {}, locale) })),
      el("button", { data: { liveTaskAction: "retryBrowserMode", taskId }, attrs: { type: "button" } }, icon("restart_alt"), el("span", { text: translate("t2iSavedReferenceRetryBrowserAction", {}, locale) })),
      el("button", { data: { liveTaskAction: "exportReport", taskId }, attrs: { type: "button" } }, icon("download"), el("span", { text: translate("reviewDuckExportReport", {}, locale) })),
      el("button", { data: { liveTaskAction: "copySupportSummary", taskId }, attrs: { type: "button" } }, icon("content_copy"), el("span", { text: translate("t2iSavedReferenceCopySupportAction", {}, locale) }))
    )
  );
}

function renderLiveQueueTaskRow(item = {}, index = 0, selected = new Set(), options = {}, locale = "en") {
  const status = liveQueueEffectiveStatus(item, options);
  const label = liveQueueStatusLabel(item, options, locale);
  const prompt = String(item.prompt || item.id || "Untitled task");
  const sourceFileName = item.mode === FLOW_MODES.videoToVideo ? String(item.sourceVideoFileName || item.sourceRefInput?.fileName || "").trim() : "";
  const rowLabel = sourceFileName ? `${sourceFileName} — ${prompt}` : prompt;
  const { resultCount, expectedCount } = liveQueueProgress(item);
  const thumb = liveQueueTaskThumb(item, locale);
  // For failed/blocked rows surface the FULL error message as a tooltip so
  // users can hover the compact label ("403 error") to see the verbose
  // backend payload that drove the truncation.
  const isErrorState = status === "failed" || status === "blocked";
  const activityTitle = isErrorState ? (liveQueueErrorTooltip(item) || label) : label;
  return el("div", { class: `live-queue-task is-${groupStatusClass([item], options)}` },
    el("span", { class: "live-task-index", text: String(index + 1).padStart(2, "0") }),
    el("span", { class: "live-task-main" },
      thumb,
      el("span", { class: "live-task-prompt", attrs: { title: rowLabel }, text: rowLabel })
    ),
    renderLiveQueueOutputStrip(item, selected, locale),
    el("span", { class: `live-task-activity${isErrorState ? " is-error" : ""}`, attrs: { title: activityTitle }, text: label }),
    isErrorState
      ? el("button", { class: "live-task-support-btn", data: { copySupportSummary: item.id }, attrs: { type: "button", title: translate("copySupportSummary", {}, locale) } }, icon("content_copy"), el("span", { text: translate("copySupportSummary", {}, locale) }))
      : (item.mode === FLOW_MODES.videoToVideo && ["complete", "completed", "done", "downloaded"].includes(status)
        ? el("button", { class: "live-task-support-btn", data: { liveTaskAction: "prepareVideoEditRedo", taskId: item.id }, attrs: { type: "button", title: translate("runAgain", {}, locale) } }, icon("restart_alt"), el("span", { text: translate("runAgain", {}, locale) }))
        : el("span", { class: "live-task-support-spacer" })),
    el("span", { class: "live-task-progress", text: `${Math.min(resultCount, expectedCount)}/${expectedCount}` }),
    el("span", { class: `live-task-dot status-${status}` }),
    renderT2iSavedReferenceRepairCard(item, locale)
  );
}

function liveQueueTaskThumb(item = {}, locale = "en") {
  const refPreviews = liveQueueInputReferencePreviews(item);
  if (refPreviews.length > 1) {
    const visibleRefs = refPreviews.slice(0, 3);
    return el("span", { class: "live-task-ref-strip", attrs: { title: `${refPreviews.length} input reference${refPreviews.length === 1 ? "" : "s"}` } },
      visibleRefs.map((preview, index) => el("button", {
        class: "live-task-ref-thumb",
        data: { livePreviewUrl: preview.src, livePreviewKind: preview.kind, livePreviewTitle: `${preview.title} ${index + 1}` },
        attrs: { type: "button", title: translate("doubleClickToPreview", {}, locale) }
      }, liveQueuePreviewMedia(preview, "thumb"))),
      refPreviews.length > visibleRefs.length ? el("span", { class: "live-task-ref-more", text: `+${refPreviews.length - visibleRefs.length}` }) : null
    );
  }
  if (item.mode === FLOW_MODES.textToImage && !refPreviews.length) return null;
  const preview = liveQueuePrimaryPreview(item);
  if (preview.src) {
    return el("button", {
      class: "live-task-thumb",
      data: { livePreviewUrl: preview.src, livePreviewKind: preview.kind, livePreviewTitle: preview.title },
      attrs: { type: "button", title: translate("doubleClickToPreview", {}, locale) }
    },
      liveQueuePreviewMedia(preview, "thumb")
    );
  }
  return el("span", { class: "live-task-thumb empty" }, icon(item.mode === FLOW_MODES.textToImage ? "image" : "movie"));
}

function liveQueuePrimaryPreview(item = {}) {
  return liveQueueInputPreview(item);
}

function liveQueueInputReferencePreviews(item = {}) {
  const refs = []
    .concat(Array.isArray(item.refInputs) ? item.refInputs : [])
    .concat(item.startRefInput ? [item.startRefInput] : [])
    .concat(item.endRefInput ? [item.endRefInput] : []);
  const seen = new Set();
  return refs
    .map((ref, index) => {
      const src = ref?.imageUrl || ref?.dataUrl || ref?.mediaUrl || "";
      const id = String(ref?.mediaId || ref?.assetImageId || ref?.id || ref?.blobStoreId || src || `${index}`).trim();
      if (!src || seen.has(id)) return null;
      seen.add(id);
      return {
        src,
        kind: "images",
        mediaId: id,
        galleryId: id,
        title: String(ref?.title || ref?.fileName || item.prompt || item.id || "Input reference")
      };
    })
    .filter(Boolean);
}

function liveQueueInputPreview(item = {}) {
  const refPreview = liveQueueInputReferencePreviews(item).find((preview) => preview.src);
  const refSrc = refPreview?.src || "";
  const src = refSrc || item.imageUrl || item.thumbnailUrl || "";
  return {
    src,
    kind: "images",
    mediaId: refPreview?.mediaId || item.mediaId || "",
    galleryId: refPreview?.galleryId || item.galleryId || "",
    title: String(item.prompt || item.id || "Input reference")
  };
}

function renderLiveQueueOutputStrip(item = {}, selected = new Set(), locale = "en") {
  const { expectedCount } = liveQueueProgress(item);
  const slots = liveQueueOutputSlots(item);
  if (!slots.some(Boolean)) {
    return el("span", { class: `live-output-strip is-empty${expectedCount > 1 ? " is-multi" : ""}` },
      Array.from({ length: Math.min(expectedCount, 4) }, (_, index) => (
        el("span", { class: "live-output-slot empty", attrs: { "aria-label": `Waiting for output ${index + 1}` } }, icon("hourglass_empty"))
      ))
    );
  }
  return el("span", { class: `live-output-strip${slots.length > 1 ? " is-multi" : ""}` },
    slots.slice(0, 6).map((preview, index) => preview
      ? el("button", {
          class: `live-output-slot${selected.has(preview.galleryId) ? " selected" : ""}`,
          data: {
            galleryId: preview.galleryId,
            livePreviewUrl: preview.previewUrl || preview.src,
            livePreviewKind: preview.kind,
            livePreviewTitle: `${preview.title} ${index + 1}`
          },
          attrs: { type: "button", title: translate("doubleClickToPreview", {}, locale) }
        }, liveQueuePreviewMedia(preview, "output"))
      : el("span", { class: "live-output-slot empty", attrs: { "aria-label": `Waiting for output ${index + 1}` } }, icon("hourglass_empty"))
    ),
    slots.length > 6 ? el("span", { class: "live-output-more", text: `+${slots.length - 6}` }) : null
  );
}

function liveQueueOutputSlots(item = {}) {
  const { expectedCount } = liveQueueProgress(item);
  const slotCount = Math.max(1, expectedCount);
  const slots = Array.from({ length: slotCount }, () => null);
  for (const preview of liveQueueOutputPreviews(item)) {
    const preferred = Number.isFinite(Number(preview.mediaIndex)) ? Number(preview.mediaIndex) : -1;
    const target = preferred >= 0 && preferred < slotCount && !slots[preferred]
      ? preferred
      : slots.findIndex((slot) => !slot);
    if (target < 0) break;
    slots[target] = preview;
  }
  return slots;
}

function liveQueueOutputPreviews(item = {}) {
  const kind = liveQueueIsVideoItem(item) ? "videos" : "images";
  const title = String(item.prompt || item.id || "Generated media");
  const isVideo = kind === "videos";
  const outputs = (Array.isArray(item.outputs) ? item.outputs : [])
    .filter((output) => !isVideo || liveQueueVideoOutputReady(output, item))
    .map((output) => ({
      src: liveQueueOutputThumbSrc(output, item, kind),
      previewUrl: isVideo ? liveQueueOutputMediaUrl(output, item) : "",
      thumbnailOnly: isVideo,
      kind,
      title,
      mediaId: output?.mediaId || "",
      mediaIndex: Number.isFinite(Number(output?.mediaIndex)) ? Number(output.mediaIndex) : -1,
      galleryId: output?.id || `${item.id}:${output?.mediaId || ""}`
    }))
    .filter((preview) => preview.src);
  if (outputs.length) return outputs;
  const statusRowPreviews = (Array.isArray(item.statusRows) ? item.statusRows : [])
    .filter((row) => !isVideo || liveQueueVideoOutputReady(row, item))
    .filter((row) => isVideo || ["complete", "pending"].includes(String(row?.status || "").toLowerCase()))
    .map((row, index) => {
      const mediaId = String(row?.id || row?.mediaId || "").trim();
      const src = liveQueueOutputThumbSrc(row, item, kind);
      return {
        src,
        previewUrl: isVideo ? liveQueueOutputMediaUrl(row, item) : "",
        thumbnailOnly: isVideo,
        kind,
        title,
        mediaId,
        mediaIndex: Number.isFinite(Number(row?.mediaIndex)) ? Number(row.mediaIndex) : index,
        galleryId: `${item.id}:${mediaId || index}`
      };
    })
    .filter((preview) => preview.src);
  if (statusRowPreviews.length) return statusRowPreviews;
  if (isVideo && !liveQueueVideoOutputReady({}, item)) return [];
  const referenceIds = new Set([
    ...(Array.isArray(item.refMediaIds) ? item.refMediaIds : []),
    item.startMediaId,
    item.endMediaId
  ].map((id) => String(id || "").trim()).filter(Boolean));
  return [...new Set((item.mediaIds || []).map((id) => String(id || "").trim()).filter((id) => id && !referenceIds.has(id)))]
    .slice(0, liveQueueProgress(item).expectedCount)
    .map((mediaId, index) => ({
      src: isVideo ? buildMediaThumbnailUrl({ mediaId }) : buildMediaRedirectUrl({ mediaId }),
      previewUrl: isVideo ? buildMediaRedirectUrl({ mediaId }) : "",
      thumbnailOnly: isVideo,
      kind,
      title,
      mediaId,
      mediaIndex: index,
      galleryId: `${item.id}:${mediaId}`
    }));
}

function liveQueueVideoOutputReady(source = {}, item = {}) {
  const status = String(source?.status || item?.status || "").toLowerCase();
  const rawStatus = String(source?.rawStatus || "").toUpperCase();
  const downloadStatus = String(source?.downloadStatus || "").toLowerCase();
  return Boolean(
    ["complete", "done", "download_incomplete"].includes(status) ||
    rawStatus === "MEDIA_GENERATION_STATUS_SUCCESSFUL" ||
    ["downloaded", "download_failed"].includes(downloadStatus) ||
    source?.downloadedAt
  );
}

function liveQueueOutputThumbSrc(source = {}, item = {}, kind = "images") {
  const mediaId = String(source?.mediaId || source?.id || item?.mediaId || "").trim();
  if (kind === "videos") {
    return normalizeMediaThumbnailUrl(source?.thumbnailUrl || "", mediaId)
      || (mediaId ? buildMediaThumbnailUrl({ mediaId }) : "");
  }
  return normalizeMediaRedirectUrl(source?.thumbnailUrl || source?.mediaUrl || "", mediaId)
    || (mediaId ? buildMediaRedirectUrl({ mediaId }) : "");
}

function liveQueueOutputMediaUrl(source = {}, item = {}) {
  const mediaId = String(source?.mediaId || source?.id || item?.mediaId || "").trim();
  return normalizeMediaRedirectUrl(source?.mediaUrl || "", mediaId)
    || (mediaId ? buildMediaRedirectUrl({ mediaId }) : "");
}

function liveQueuePreview(item = {}) {
  const outputSrc = (Array.isArray(item.outputs) ? item.outputs : [])
    .map((output) => normalizeMediaRedirectUrl(output?.thumbnailUrl || output?.mediaUrl || "", output?.mediaId || ""))
    .find(Boolean);
  const refs = []
    .concat(Array.isArray(item.refInputs) ? item.refInputs : [])
    .concat(item.startRefInput ? [item.startRefInput] : [])
    .concat(item.endRefInput ? [item.endRefInput] : []);
  const src = outputSrc
    || refs.map((ref) => ref?.imageUrl || ref?.dataUrl || ref?.mediaUrl || "").find(Boolean)
    || item.thumbnailUrl
    || item.imageUrl
    || normalizeMediaRedirectUrl(item.mediaUrl || "", item.mediaId || "")
    || (item.mediaIds?.[0] ? buildMediaRedirectUrl({ mediaId: item.mediaIds[0] }) : "");
  return {
    src,
    kind: liveQueueIsVideoItem(item) ? "videos" : "images",
    title: String(item.prompt || item.id || "Generated media")
  };
}

function liveQueuePreviewMedia(preview = {}, size = "thumb") {
  const mediaKey = liveQueuePreviewMediaKey(preview, size);
  if (preview.kind === "videos" && preview.thumbnailOnly) {
    return el("img", {
      class: `live-preview-media live-preview-${size}`,
      data: { liveMediaKey: mediaKey },
      attrs: { src: preview.src, alt: preview.title || "Generated video", loading: "eager", decoding: "async", draggable: "false" }
    });
  }
  if (preview.kind === "videos") {
    return el("video", {
      class: `live-preview-media live-preview-${size}`,
      data: { liveMediaKey: mediaKey },
      attrs: { src: preview.src, muted: true, playsinline: true, preload: size === "thumb" ? "metadata" : "none" }
    });
  }
  return el("img", {
    class: `live-preview-media live-preview-${size}`,
    data: { liveMediaKey: mediaKey },
    attrs: { src: preview.src, alt: preview.title || "Preview", loading: "eager", decoding: "async", draggable: "false" }
  });
}

function liveQueuePreviewMediaKey(preview = {}, size = "thumb") {
  return [
    size,
    preview.kind || "",
    preview.thumbnailOnly ? "thumbnail" : "media",
    preview.galleryId || "",
    preview.mediaId || "",
    preview.src || "",
    preview.previewUrl || ""
  ].join("|");
}

function liveQueueIsVideoItem(item = {}) {
  return item.mode !== FLOW_MODES.textToImage || String(item.kind || "").includes("video");
}

function liveQueueProgress(item = {}) {
  const ledger = deriveTaskOutputLedger(item);
  const isVideo = liveQueueIsVideoItem(item);
  if (isVideo) {
    const successfulStatusRows = Array.isArray(item.statusRows)
      ? item.statusRows.filter((row) => String(row?.status || "").toLowerCase() === "complete")
      : [];
    const resultCount = Number(item.foundVideos || ledger.resultCount || successfulStatusRows.length || 0);
    return { resultCount, expectedCount: ledger.expectedCount };
  }
  const resultCount = Number(item.outputs?.length || item.foundImages || item.mediaIds?.length || 0);
  return { resultCount, expectedCount: ledger.expectedCount };
}

function liveQueueSavedCount(item = {}) {
  return deriveTaskOutputLedger(item).savedCount;
}

function liveQueueEffectiveStatus(item = {}, options = {}) {
  const status = String(item.status || "pending");
  const outputLedger = deriveTaskOutputLedger(item);
  const { resultCount, expectedCount } = liveQueueProgress(item);
  const shouldAutoDownload = item?.download?.enabled === true;
  const savedCount = liveQueueSavedCount(item);
  const failedOutputCount = Math.max(outputLedger.failedIds.length, Number(item.failedOutputCount || item.missingOutputCount || 0) || 0);
  const expectedDownloads = outputLedger.expectedDownloadCount || Math.max(0, expectedCount - failedOutputCount);
  const retryStatus = String(item.retryStatus || "").toLowerCase();
  const failedDownloadCount = outputLedger.hasDownloadErrors ? 1 : 0;
  if (status === "pending" && options.queueRunning === true) return "starting";
  if ((status === "complete" || status === "done") && shouldAutoDownload && failedDownloadCount > 0) return "download_failed";
  if ((status === "complete" || status === "done") && resultCount < expectedCount) {
    if (retryStatus === "queued" || retryStatus === "repairing" || retryStatus === "retrying") return "retrying";
    return "partial";
  }
  if ((status === "complete" || status === "done") && shouldAutoDownload && savedCount < expectedDownloads) return "downloading";
  return status;
}

function liveQueueStatusLabel(item = {}, options = {}, locale = "en") {
  const status = liveQueueEffectiveStatus(item, options);
  if (status === "starting") return "Starting run";
  if (status === "submitting") return "Typing prompt into Flow";
  if (status === "generating") return "Generating in Flow";
  if (status === "downloading") return "Saving outputs";
  if (status === "retrying") {
    const { resultCount, expectedCount } = liveQueueProgress(item);
    return `Retrying missing outputs (${Math.min(resultCount, expectedCount)}/${expectedCount})`;
  }
  if (status === "partial") {
    const { resultCount, expectedCount } = liveQueueProgress(item);
    return `${Math.min(resultCount, expectedCount)}/${expectedCount} generated - missing output`;
  }
  if (status === "download_failed") return "Download failed";
  if (status === "download_incomplete") return "Download incomplete";
  if (status === "complete" || status === "done") return "Complete";
  if (status === "failed") {
    if (item.failureClass === "t2i_saved_reference_asset_row_missing") return translate("t2iSavedReferenceMissingTitle", {}, locale);
    if (item.failureClass === "prompt_safety") return "Needs prompt edit - skipped";
    if (item.failureClass === "generation_failed") return "Generation failed after retries";
    if (item.failureClass === "media_input") return "Reference/upload failed";
    return compactErrorLabel(item.lastError || item.error || item.reason || "Failed");
  }
  if (status === "blocked") return compactErrorLabel(item.lastError || item.blockerReason || item.error || item.reason || "Needs attention");
  if (status === "waiting") return "Waiting for next prompt";
  return "Queued";
}

// Collapse a verbose API/runtime error into a short label that fits on one
// line in the live queue row. Full message is preserved for the tooltip.
//   "403 PERMISSION_DENIED The caller does not have..." -> "403 error"
//   "Network request failed" -> "Network error"
//   undefined / "" -> "Error"
function compactErrorLabel(message = "") {
  const text = String(message || "").trim();
  if (!text) return "Error";
  // HTTP-like status code at the start of the message?
  const httpMatch = text.match(/\b([1-5]\d{2})\b/);
  if (httpMatch) return `${httpMatch[1]} error`;
  // Common error families — map to a single-word category
  const lower = text.toLowerCase();
  if (lower.includes("network") || lower.includes("fetch") || lower.includes("offline")) return "Network error";
  if (lower.includes("timeout") || lower.includes("timed out")) return "Timeout";
  if (lower.includes("auth") || lower.includes("unauthorized") || lower.includes("unauthenticated")) return "Auth error";
  if (lower.includes("rate") && lower.includes("limit")) return "Rate limited";
  if (lower.includes("quota")) return "Quota error";
  if (lower.includes("safety") || lower.includes("policy")) return "Policy error";
  return "Error";
}

// Full untruncated message for tooltips. Falls through the same property
// preference as liveQueueStatusLabel but without compaction.
function liveQueueErrorTooltip(item = {}) {
  return String(item.lastError || item.error || item.blockerReason || item.reason || "").trim();
}

function galleryGrid(items, selected, gridId, emptyText, viewMode = "grid", refsById = new Map(), defaultRefId = "") {
  const grid = el("div", { id: gridId, class: viewMode === "table" ? "gallery-table-view active" : "gallery-grid gallery-grid-view active" });
  if (!items.length) {
    grid.appendChild(el("div", { class: "gallery-empty", text: emptyText }));
    return grid;
  }
  if (viewMode === "table") {
    const grouped = groupGalleryItems(items);
    for (const [index, group] of grouped.entries()) {
      grid.appendChild(renderGalleryTableGroup(group, selected, index, refsById, defaultRefId));
    }
    return grid;
  }

  const grouped = groupGalleryItems(items);
  for (const group of grouped) {
    grid.appendChild(el("div", { class: `gallery-prompt-group ${group.aspect || ""}` },
      el("div", { class: "gallery-prompt-text" },
        el("span", { text: group.index }),
        el("span", { attrs: { title: group.fullPrompt || group.prompt }, text: group.prompt }),
        group.items.length > 1 ? el("span", { class: "gallery-group-count", text: `x${group.items.length}` }) : null
      ),
      el("div", { class: group.kind === "videos" ? "gallery-videos" : "gallery-images" },
        group.items.map((item) => renderGalleryMediaItem(item, selected, refsById, defaultRefId))
      )
    ));
  }
  return grid;
}

export function sortGalleryItems(items = [], order = "num-asc") {
  const indexed = items.map((item, index) => ({ item, index }));
  const title = (item) => String(item.prompt || item.title || item.fileName || item.mediaId || "").trim();
  const firstNumber = (item) => {
    const text = `${item.taskNumber || ""} ${item.jobIndex || ""} ${item.fileName || ""} ${item.title || ""} ${item.prompt || ""}`;
    const match = String(text).match(/\b(\d{1,4})\b/);
    return match ? Number(match[1]) : Number.POSITIVE_INFINITY;
  };
  const created = (item) => {
    const time = new Date(item.createdAt || item.downloadedAt || item.updatedAt || 0).getTime();
    return Number.isFinite(time) ? time : 0;
  };
  indexed.sort((a, b) => {
    if (order === "az" || order === "za") {
      const value = title(a.item).localeCompare(title(b.item), undefined, { numeric: true, sensitivity: "base" });
      return order === "za" ? -value : value;
    }
    if (order === "num-desc") {
      return (firstNumber(b.item) - firstNumber(a.item)) || (a.index - b.index);
    }
    if (order === "default") {
      return (created(b.item) - created(a.item)) || (b.index - a.index);
    }
    return (firstNumber(a.item) - firstNumber(b.item)) || (a.index - b.index);
  });
  return indexed.map((entry) => entry.item);
}

function galleryGroupKey(item = {}) {
  const prompt = galleryPromptLabel(item);
  if (prompt) return `prompt:${prompt.slice(0, 240)}`;
  const taskId = String(item.taskId || "").trim();
  if (taskId) return `task:${taskId}`;
  return `media:${item.kind || "media"}:${item.mediaId || item.id || "unknown"}`;
}

export function groupGalleryItems(items = []) {
  const groups = new Map();
  for (const item of items) {
    const key = galleryGroupKey(item);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }
  return [...groups.values()].map((groupItems, index) => {
    const fullPrompt = galleryDisplayLabel(groupItems[0]);
    return {
      prompt: galleryPromptPreview(fullPrompt, 10),
      fullPrompt,
      index: String(index + 1),
      kind: groupItems.some((item) => item.kind === "videos") ? "videos" : "images",
      aspect: groupItems.some((item) => /portrait|9:16/i.test(String(item.aspectRatio || ""))) ? "portrait" : "",
      items: groupItems
    };
  });
}

function renderGalleryMediaItem(item, selected, refsById = new Map(), defaultRefId = "") {
  const isVideo = item.kind === "videos";
  const isSelected = selected?.has?.(item.id);
  const aspectClass = galleryAspectClass(item);
  const hasPreview = galleryItemHasPreview(item, refsById, defaultRefId);
  const title = galleryDisplayLabel(item);
  const classes = [
    isVideo ? "gallery-video-item" : "gallery-image-item",
    aspectClass,
    isSelected ? "selected" : "",
    hasPreview ? "thumb-ready" : "thumb-unavailable"
  ].filter(Boolean).join(" ");
  const data = { galleryId: item.id };
  if (isVideo) {
    const previewUrl = galleryVideoPreviewUrl(item);
    if (previewUrl) data.videoPreviewUrl = previewUrl;
  }
  return el("button", { class: classes, data, attrs: { type: "button", tabindex: "-1", title } },
    renderGalleryMediaPreview(item, refsById, defaultRefId)
  );
}

export function galleryVideoPreviewUrl(item = {}) {
  if (item.kind !== "videos") return "";
  const mediaUrl = String(item.mediaUrl || "").trim();
  const mediaId = String(item.mediaId || "").trim();
  if (mediaUrl && !/mediaUrlType=MEDIA_URL_TYPE_THUMBNAIL/i.test(mediaUrl)) {
    return normalizeMediaRedirectUrl(mediaUrl, mediaId);
  }
  return mediaId ? buildMediaRedirectUrl({ mediaId }) : "";
}

function galleryItemHasPreview(item = {}, refsById = new Map(), defaultRefId = "") {
  if (item.kind === "videos") return Boolean(distinctGalleryThumbnailUrl(item) || galleryFallbackRefImage(item, refsById, defaultRefId));
  return Boolean(item.mediaUrl || item.thumbnailUrl);
}

function distinctGalleryThumbnailUrl(item = {}) {
  const thumbnailUrl = String(item.thumbnailUrl || "").trim();
  const mediaUrl = String(item.mediaUrl || "").trim();
  const mediaId = String(item.mediaId || "").trim();
  if (!thumbnailUrl) return item.kind === "videos" && mediaId ? buildMediaThumbnailUrl({ mediaId }) : "";
  if (thumbnailUrl === mediaUrl) return item.kind === "videos" && mediaId ? buildMediaThumbnailUrl({ mediaId }) : "";
  return thumbnailUrl;
}

function galleryFallbackRefImage(item = {}, refsById = new Map(), defaultRefId = "") {
  const ids = [
    item.fallbackThumbnailRefId,
    ...(Array.isArray(item.referenceIds) ? item.referenceIds : []),
    defaultRefId
  ].map((id) => String(id || "").trim()).filter(Boolean);
  for (const id of ids) {
    const ref = refsById.get(id);
    const src = ref?.imageUrl || ref?.dataUrl || ref?.mediaUrl || "";
    if (src) return src;
  }
  return "";
}

function renderGalleryMediaPreview(item = {}, refsById = new Map(), defaultRefId = "") {
  const isVideo = item.kind === "videos";
  const title = galleryDisplayLabel(item, { kind: isVideo ? "videos" : "images" });
  if (!isVideo) {
    const src = item.mediaUrl || item.thumbnailUrl || "";
    return src
      ? el("img", { attrs: { src, alt: title, loading: "lazy", decoding: "async", draggable: "false" } })
      : icon("image");
  }
  const thumbnailUrl = distinctGalleryThumbnailUrl(item);
  if (thumbnailUrl) {
    return el("span", { class: "gallery-video-preview" },
      el("img", { attrs: { src: thumbnailUrl, alt: title, loading: "lazy", decoding: "async", draggable: "false" } })
    );
  }
  const refImage = galleryFallbackRefImage(item, refsById, defaultRefId);
  if (refImage) {
    return el("span", { class: "gallery-video-preview gallery-video-preview-ref" },
      el("img", { attrs: { src: refImage, alt: title, loading: "lazy", decoding: "async", draggable: "false" } })
    );
  }
  return el("span", { class: "gallery-video-placeholder", attrs: { "aria-label": title } });
}

function galleryAspectClass(item = {}) {
  const raw = `${item.aspectRatio || item.aspect || item.orientation || ""}`.toLowerCase();
  if (/portrait|9:16|3:4|vertical/.test(raw)) return "aspect-portrait";
  if (/square|1:1/.test(raw)) return "aspect-square";
  if (/landscape|16:9|4:3|horizontal/.test(raw)) return "aspect-landscape";
  return "aspect-auto";
}

function renderGalleryTableRow(item, selected, index, refsById = new Map(), defaultRefId = "") {
  const isVideo = item.kind === "videos";
  const prompt = galleryPromptLabel(item);
  const title = galleryDisplayLabel(item, { kind: isVideo ? "videos" : "images" });
  return el("button", { class: `gallery-table-row${selected?.has?.(item.id) ? " selected" : ""}`, data: { galleryId: item.id }, attrs: { type: "button", tabindex: "-1" } },
    el("span", { class: "gallery-table-index", text: String(index + 1).padStart(2, "0") }),
    el("span", { class: "gallery-table-thumb" },
      renderGalleryMediaPreview(item, refsById, defaultRefId)
    ),
    el("span", { class: "gallery-table-copy" },
      el("span", { class: "gallery-table-title", attrs: { title }, text: galleryPromptPreview(title, 10) }),
      el("span", { class: "gallery-table-prompt", attrs: { title: prompt || title }, text: prompt || title })
    ),
    el("span", { class: "gallery-table-kind", text: isVideo ? "Video" : "Image" })
  );
}

function renderGalleryTableGroup(group, selected, index, refsById = new Map(), defaultRefId = "") {
  return el("div", { class: "gallery-table-group-row" },
    el("span", { class: "gallery-table-index", text: String(index + 1) }),
    el("span", { class: "gallery-table-group-prompt", attrs: { title: group.prompt }, text: group.prompt }),
    el("span", { class: "gallery-table-thumb-strip" },
      group.items.map((item) => renderGalleryMediaItem(item, selected, refsById, defaultRefId))
    ),
    el("span", { class: "gallery-table-kind", text: String(group.items.length) })
  );
}

function statusClass(status = "") {
  if (["complete", "done"].includes(status)) return "done";
  if (["failed", "blocked"].includes(status)) return "error";
  if (["submitting", "generating"].includes(status)) return "running";
  return "pending";
}

function statusLabel(q) {
  if (q.status === "complete") return "done";
  return q.status || "pending";
}

function promptLines(state) {
  return String(state.control.livePrompt || "").split(/\n+/).map((line) => line.trim()).filter(Boolean);
}

function formatTime(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "--:--";
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

// ── Wizard dispatch ────────────────────────────────────────────
// Builds a dispatch(patch) callback for the 10.8 wizard.
// Deep-merges patch into the current state and writes to chrome.storage.local.
// The sidepanel's chrome.storage.onChanged listener (app.js) picks it up and re-renders.
function makeWizardDispatch(currentState) {
  return (patch) => {
    if (!patch || typeof patch !== "object") return;
    const next = deepMergeState(currentState, patch);
    for (const key of Object.keys(currentState)) delete currentState[key];
    Object.assign(currentState, next);
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.set({ [STORAGE_KEY]: next });
    }
  };
}

function deepMergeState(base, patch) {
  if (Array.isArray(patch)) return patch.slice();
  if (patch && typeof patch === "object" && !Array.isArray(patch)) {
    const out = { ...(base && typeof base === "object" ? base : {}) };
    for (const [k, v] of Object.entries(patch)) {
      if (v && typeof v === "object" && !Array.isArray(v)) {
        out[k] = deepMergeState(out[k], v);
      } else {
        out[k] = v;
      }
    }
    return out;
  }
  return patch;
}
