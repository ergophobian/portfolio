// Keep in sync with the terminal agentRun statuses the product writes
// (see agentRunNeedsReconcile in app.js); in-flight statuses such as
// "downloading", "reconciling", and "submitted" must not match.
const AGENT_RUN_TERMINAL_STATUS = /complete|finished|failed|blocked|cancelled|partial|landed|downloaded|submit_error/i;

const LEGACY_TASK_TIME_FIELDS = Object.freeze([
  "completedAt",
  "updatedAt",
  "startedAt",
  "submittedAt",
  "submitAttemptStartedAt",
  "createdAt"
]);

export function isAgentRunTerminal(status = "") {
  return AGENT_RUN_TERMINAL_STATUS.test(String(status || ""));
}

export function agentRunMatchesActiveProject(run = {}, activeProjectId = "") {
  const runProjectId = String(run?.projectId || "").trim();
  const currentProjectId = String(activeProjectId || "").trim();
  return !runProjectId || !currentProjectId || runProjectId === currentProjectId;
}

export function liveQueueItemsForProject(items = [], activeProjectId = "") {
  const currentProjectId = String(activeProjectId || "").trim();
  const source = Array.isArray(items) ? items : [];
  if (!currentProjectId) return source;
  return source.filter((item) => {
    const itemProjectId = String(item?.projectId || "").trim();
    return !itemProjectId || itemProjectId === currentProjectId;
  });
}

function timestampMs(value) {
  if (typeof value === "number") return Number.isFinite(value) && value > 0 ? value : 0;
  const text = String(value || "").trim();
  if (!text) return 0;
  const parsed = Date.parse(text);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

function legacyTaskActivityMs(task = {}) {
  let latest = 0;
  for (const field of LEGACY_TASK_TIME_FIELDS) {
    latest = Math.max(latest, timestampMs(task?.[field]));
  }
  const events = Array.isArray(task?.events) ? task.events : [];
  for (const event of events) {
    latest = Math.max(latest, timestampMs(event?.at));
  }
  return latest;
}

export function newestLegacyQueueActivityMs(items = []) {
  let latest = 0;
  for (const item of Array.isArray(items) ? items : []) {
    latest = Math.max(latest, legacyTaskActivityMs(item));
  }
  return latest;
}

export function agentRunLastActivityMs(run = {}) {
  return Math.max(
    timestampMs(run?.completedAt),
    timestampMs(run?.lastReconcileCompletedAt),
    timestampMs(run?.lastReconcileStartedAt),
    timestampMs(run?.downloadCompletedAt),
    timestampMs(run?.downloadStartedAt),
    timestampMs(run?.lastSeenAt),
    timestampMs(run?.updatedAt),
    timestampMs(run?.startedAt)
  );
}

// Agent Mode is the canonical Live Queue surface only for the current logical
// run: an Agent run whose activity is at least as recent as the newest legacy
// DOM queue activity is canonical, and a run without legacy competition stays
// canonical. Once a newer legacy run starts (a running legacy queue or newer
// legacy task timestamps), the legacy run becomes canonical and the Agent run
// is history — even if the Agent run was abandoned in a non-terminal status.
// Rows-only residue with no run id/status is never a current run and cannot
// suppress a started legacy run.
export function agentRunIsCanonical({ run = null, hasRows = false, queueItems = [], queueRunning = false } = {}) {
  const agentRun = run && typeof run === "object" && !Array.isArray(run) ? run : {};
  const hasRunIdentity = Boolean(String(agentRun.id || "").trim()) || Boolean(String(agentRun.status || "").trim());
  if (!hasRunIdentity && !hasRows) return false;
  const legacyMs = newestLegacyQueueActivityMs(queueItems);
  if (!hasRunIdentity) return queueRunning !== true && !legacyMs;
  const agentMs = agentRunLastActivityMs(agentRun);
  if (queueRunning === true) {
    return !isAgentRunTerminal(agentRun.status) && agentMs > 0 && agentMs >= legacyMs;
  }
  if (!legacyMs) return true;
  return agentMs >= legacyMs;
}
