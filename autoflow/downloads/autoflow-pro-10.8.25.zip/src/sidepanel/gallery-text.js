export function isGenericGeneratedTitle(value = "") {
  return /^generated\s+(image|video|media)$/i.test(String(value || "").trim());
}

export function cleanGalleryPromptText(value = "") {
  let text = String(value || "").trim();
  const promptMatch = text.match(/<prompt>([\s\S]*?)<\/prompt>/i);
  if (promptMatch) text = promptMatch[1];
  text = text
    .replace(/<\/?(root|context|instruction|prompt)\b[^>]*>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text;
}

export function galleryPromptLabel(item = {}) {
  const prompt = cleanGalleryPromptText(item.prompt || "");
  if (prompt && !isGenericGeneratedTitle(prompt)) return prompt;
  const title = cleanGalleryPromptText(item.title || "");
  if (title && !isGenericGeneratedTitle(title)) return title;
  return "";
}

export function galleryDisplayLabel(item = {}, options = {}) {
  const prompt = galleryPromptLabel(item);
  if (prompt) return prompt;

  const fileName = cleanGalleryPromptText(item.fileName || item.name || item.mediaName || "");
  if (fileName && !isGenericGeneratedTitle(fileName)) return fileName;

  const rowId = cleanGalleryPromptText(item.rowId || item.tag || item.videoTag || item.finalVideoId || "");
  if (rowId) return rowId.startsWith("[") ? rowId : `[${rowId}]`;

  const kind = String(options.kind || item.kind || "").toLowerCase().includes("video") ? "Video" : "Image";
  const id = shortDisplayId(item.mediaId || item.id || item.mediaUrl || item.thumbnailUrl || "");
  return id ? `${kind} ${id}` : `Generated ${kind.toLowerCase()}`;
}

export function galleryPromptPreview(text = "", wordLimit = 10) {
  const words = String(text || "").trim().split(/\s+/).filter(Boolean);
  if (!words.length) return "Generated media";
  const limit = Math.max(1, Number(wordLimit || 10) || 10);
  return words.length > limit ? `${words.slice(0, limit).join(" ")}...` : words.join(" ");
}

function shortDisplayId(value = "") {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const parsed = new URL(raw);
    const name = parsed.searchParams.get("name") || parsed.searchParams.get("mediaId") || "";
    if (name) return shortDisplayId(name);
  } catch {}
  const compact = raw
    .replace(/^media:/i, "")
    .replace(/[^a-z0-9_-]+/gi, "")
    .replace(/^-+|-+$/g, "");
  return compact.slice(0, 8);
}
