const REFRESH_ACTIONS = new Set(["init", "state", "refresh"]);

function refreshErrorClass(auth = {}) {
  return String(
    auth?.authRefresh?.lastErrorClass ||
    auth?.refreshErrorClass ||
    auth?.license?.authRefresh?.lastErrorClass ||
    ""
  ).trim();
}

function refreshErrorText(auth = {}) {
  return String(
    auth?.authRefresh?.lastError ||
    auth?.refreshError ||
    auth?.license?.error ||
    ""
  ).trim();
}

function isAuthoritativeAuthRejection(auth = {}) {
  const errorClass = refreshErrorClass(auth);
  const status = Number(auth?.authRefresh?.lastStatus || auth?.refreshStatus || 0) || 0;
  const errorText = refreshErrorText(auth);
  return errorClass === "auth_rejected" ||
    status === 401 ||
    (status === 400 && /invalid_grant/i.test(errorText));
}

function isReachableServerDeny(auth = {}) {
  const license = auth?.license && typeof auth.license === "object" ? auth.license : {};
  const source = String(license.source || "").toLowerCase();
  return source === "server" && license.allowed === false;
}

function hasKnownProDisplay(account = {}) {
  return account.hasProAccess === true ||
    account.usage?.unlimited === true ||
    ["pro", "team"].includes(String(account.plan || "").toLowerCase());
}

export function shouldPreserveAccountDisplayAfterAuthRefresh({
  action = "",
  auth = {},
  account = {},
  previous = {},
  previousLastKnown = {}
} = {}) {
  if (!REFRESH_ACTIONS.has(String(action || ""))) return false;
  if (previousLastKnown.lastKnownAccountStatus !== "signed_in") return false;
  if (previous.status !== "signed_in") return false;
  if (isAuthoritativeAuthRejection(auth) || isReachableServerDeny(auth)) return false;
  if (refreshErrorClass(auth) !== "transient") return false;
  if (account.status === "signed_out") return true;
  return account.status === "signed_in" &&
    hasKnownProDisplay(previous) &&
    !hasKnownProDisplay(account);
}
