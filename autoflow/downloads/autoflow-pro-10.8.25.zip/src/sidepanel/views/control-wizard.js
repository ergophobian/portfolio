// Auto Flow 10.8 Control tab wizard.
// Renders a 3-step wizard (Prompts / References / Run) inside the Control tab.
// Bound to state.control + state.queue + state.referenceLibrary.
//
// Public API:
//   renderControlWizard(root, state, ctx)
//     root  - HTMLElement (the <section id="view-control"> container)
//     state - full sidepanel state (see runtime-config.js createDefaultState)
//     ctx   - { dispatch, showConfirm } where dispatch is (patch) => void merging
//             into state.control / state.ui / etc, showConfirm is the dialog helper
//
// Wiring is intentionally light for v1: CTAs and navigation update local state,
// Run dispatches a QueueAddJob via ctx.dispatch when the integration is ready.

import { FLOW_MODES } from "../runtime-config.js";
import { translate } from "../i18n.js";
import { CharacterFailureClass, normalizeCharacterHandle, parseAutoFlowPacket, parseCharacterPrompts, scanCharacterMentions, validateCharacterRun } from "../../core/characters/character-prompts.js";
import { buildCharacterSetupPlan, readyNativeCharacterMappingsForProject } from "../../core/characters/character-setup-runner.js";
import { matchedReferenceIdsForPrompt, splitAutoFlowPromptLine } from "../../core/gallery/animate-prompts.js";

const CONTROL_WIZARD_VERSION = "10.8.25";

// ── DOM helpers ────────────────────────────────────────────
function el(tag, opts, ...kids) {
  const node = document.createElement(tag);
  if (opts) {
    if (opts.class) node.className = opts.class;
    if (opts.id) node.id = opts.id;
    if (opts.text != null) node.textContent = opts.text;
    if (opts.title) node.title = opts.title;
    if (opts.value != null) node.value = opts.value;
    if (opts.placeholder) node.placeholder = opts.placeholder;
    if (opts.attrs) {
      for (const [k, v] of Object.entries(opts.attrs)) {
        if (v == null || v === false) continue;
        node.setAttribute(k, v === true ? "" : String(v));
      }
    }
    if (opts.style) for (const [k, v] of Object.entries(opts.style)) node.style[k] = v;
    if (opts.data) for (const [k, v] of Object.entries(opts.data)) node.dataset[k] = v;
    if (opts.on) for (const [evt, fn] of Object.entries(opts.on)) node.addEventListener(evt, fn);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    node.appendChild(typeof kid === "string" ? document.createTextNode(kid) : kid);
  }
  return node;
}

const icon = (name) => el("span", { class: "material-symbols-outlined", text: name });
const clear = (root) => { while (root.firstChild) root.removeChild(root.firstChild); };
const pad2 = (n) => String(n).padStart(2, "0");

const AGENT_MODE_FORMAT_BLOCK = `# AGENT INSTRUCTIONS
Use one row per final video. Preserve [V#-S#] row tags and AFID strings in prompt metadata. Do not render AFID, labels, captions, or visible text.

# PROJECT BRIEF
Describe the product, characters, style, reference rules, dialogue rules, and QA bar for this run.

# REFERENCES
List the uploaded references and which rows, @handles, or image slots they should guide.

# VIDEO PROMPTS
[V1-S1] AFID:V1-S1-IMG1 still image prompt ;; AFID:V1-S1-IMG2 optional second still ||| [V1-S1] final frame-to-video prompt using those stills.

# QA EXPECTATIONS
Check dialogue, speaker, timing, identity, product accuracy, and whether the ending is complete.

# RETRY ROWS
Retry only the listed row IDs, keep unrelated rows unchanged, and state the issue to fix. CLI/MCP controls are coming soon.`;

// Compact "History" jump button for the step header. Click activates the
// History route (ui.activeRoute = "history"). Shows a count badge if there
// are saved runs.
// Compact "Guide" jump button for the step header. Opens the sample prompt
// formats reference in a new tab via the document-level delegated handler in
// app.js (data-action="format-guide"). Lives next to History so the wizard's
// nav cluster keeps both jumps together.
function buildGuideJump(state) {
  return el("button", {
    class: "afw-guide-jump",
    attrs: { type: "button", title: tr(state, "formatGuide") },
    data: { action: "format-guide" },
  },
    icon("article"),
    el("span", { class: "afw-guide-jump-label", text: tr(state, "formatGuide") }),
  );
}

function buildHistoryJump(state, dispatch) {
  const runs = Array.isArray(state.history?.runs) ? state.history.runs : [];
  return el("button", {
    class: "afw-history-jump",
    attrs: {
      type: "button",
      title: runs.length
        ? `${tr(state, "openHistory")} (${runs.length})`
        : tr(state, "openHistory"),
    },
    on: { click: (e) => { stopControlEvent(e); dispatch({ ui: { activeRoute: "history" } }); } },
  },
    icon("history"),
    el("span", { class: "afw-history-jump-label", text: tr(state, "history") }),
    runs.length ? el("span", { class: "afw-history-jump-count", text: String(runs.length) }) : null,
  );
}

const localeFor = (state) => state?.control?.presets?.language || "en";
const tr = (state, key, params = {}) => translate(key, params, localeFor(state));
const modeName = (state, mode) => tr(state, mode?.labelKey || "mode");

// ── Mode → workflow metadata ─────────────────────────────────
const MODES = [
  { key: FLOW_MODES.textToImage,         labelKey: "createImage",   iconName: "palette",   needsRefs: false, defaultModelKey: "imageModel",       defaultAspectKey: "imageAspectRatio", defaultCountKey: "imageRepeatCount",       defaultDownloadResKey: "imageAutoDownloadResolution" },
  { key: FLOW_MODES.textToVideo,         labelKey: "textToVideo",   iconName: "videocam",  needsRefs: false, defaultModelKey: "model",            defaultAspectKey: "aspectRatio",      defaultCountKey: "repeatCount",            defaultDownloadResKey: "videoDownloadResolution" },
  { key: FLOW_MODES.imageToVideo,        labelKey: "frameToVideo",  iconName: "image",     needsRefs: true,  defaultModelKey: "model",            defaultAspectKey: "aspectRatio",      defaultCountKey: "repeatCount",            defaultDownloadResKey: "videoDownloadResolution" },
  { key: FLOW_MODES.ingredientsToVideo,  labelKey: "ingredients",   iconName: "grid_view", needsRefs: true,  defaultModelKey: "ingredientsModel", defaultAspectKey: "aspectRatio",      defaultCountKey: "repeatCount",            defaultDownloadResKey: "videoDownloadResolution" },
  { key: FLOW_MODES.videoToVideo,         labelKey: "videoToVideo",  iconName: "movie_edit", needsRefs: true, defaultModelKey: "model",            defaultAspectKey: "aspectRatio",      defaultCountKey: "repeatCount",            defaultDownloadResKey: "videoDownloadResolution" },
];

const REF_LIMITS = Object.freeze({
  [FLOW_MODES.textToImage]: 10,
  [FLOW_MODES.textToVideo]: 0,
  [FLOW_MODES.imageToVideo]: 2,
  [FLOW_MODES.ingredientsToVideo]: 3,
  // Omni edit accepts up to five visual references. Agent batching still
  // enforces ten total attachments (source videos + persistent images).
  [FLOW_MODES.videoToVideo]: 5,
});

const VIDEO_MODEL_OPTIONS = Object.freeze([
  ["omni_flash", "Omni Flash"],
  ["default", "Default (Veo 3.1 Lite - Lower Priority)"],
  ["veo3_lite", "Veo 3.1 Lite"],
  ["veo3_lite_low", "Veo 3.1 Lite - Lower Priority"],
  ["veo3_fast", "Veo 3.1 Fast"],
  ["veo3_fast_low", "Veo 3.1 Fast - Lower Priority"],
  ["veo3_quality", "Veo 3.1 Quality"]
]);

const TEXT_VIDEO_MODEL_OPTIONS = Object.freeze([
  ...VIDEO_MODEL_OPTIONS
]);

const INGREDIENTS_VIDEO_MODEL_OPTIONS = Object.freeze([
  ["omni_flash", "Omni Flash"],
  ["veo3_fast_low", "Veo 3.1 Fast - Lower Priority"],
  ["veo3_fast", "Veo 3.1 Fast"]
]);

// Predictable colour palette for ref thumbnails (when no preview URL is stored)
const REF_PALETTES = [
  "linear-gradient(135deg,#2b4a9a,#5fa9ff)",
  "linear-gradient(135deg,#1d2a4a,#7d3fff)",
  "linear-gradient(135deg,#1a1f33,#4f6cff)",
  "linear-gradient(135deg,#3a2c1a,#c98a2e)",
  "linear-gradient(135deg,#3a1422,#ff6f8e)",
  "linear-gradient(135deg,#0a3a3d,#7de5ff)",
];
function paletteFor(id) {
  let h = 0;
  const s = String(id || "");
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return REF_PALETTES[h % REF_PALETTES.length];
}
function glyphFor(name = "") {
  const trimmed = String(name || "").trim();
  return trimmed ? trimmed[0].toUpperCase() : "?";
}

function stopControlEvent(event) {
  event?.preventDefault?.();
  event?.currentTarget?.blur?.();
}

function formatModelLabel(value = "") {
  const raw = String(value || "").trim();
  const labels = {
    omni_flash: "Omni Flash",
    default: "Default",
    nano_banana_pro: "Nano Banana Pro",
    nano_banana_2: "Nano Banana 2",
    nano_banana_2_lite: "Nano Banana 2 Lite",
    veo3_lite: "Veo 3.1 Lite",
    veo3_lite_low: "Veo 3.1 Lite - Lower Priority",
    veo3_fast: "Veo 3.1 Fast",
    veo3_fast_low: "Veo 3.1 Fast - Lower Priority",
    veo3_quality: "Veo 3.1 Quality",
  };
  return labels[raw] || raw.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
}

function isOmniVideoModel(value = "") {
  return /^(omni_flash|omni|abra)$/i.test(String(value || "").trim());
}

function clickFileInputWithoutScroll(input) {
  if (!input) return;
  const pageY = document.scrollingElement?.scrollTop || 0;
  const shell = document.querySelector(".shell");
  const shellY = shell?.scrollTop || 0;
  const view = document.querySelector(".view.active");
  const viewY = view?.scrollTop || 0;
  input.click();
  const restore = () => {
    if (document.scrollingElement) document.scrollingElement.scrollTop = pageY;
    if (shell) shell.scrollTop = shellY;
    if (view) view.scrollTop = viewY;
  };
  requestAnimationFrame(restore);
  window.setTimeout(restore, 80);
}

// Compute prompt list from state.control.livePrompt
function parsePrompts(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function characterPromptText(state) {
  return String(state.control?.characterPromptText || "");
}

function readySavedCharacterMappings(state) {
  return readyNativeCharacterMappingsForProject({
    activeProjectId: state.runtime?.projectId || "",
    savedMappings: state.characters?.savedMappings || [],
    assets: state.characters?.assets || [],
    characterSources: state.control?.characterSources || {},
    setupRunner: state.control?.characterSetupRunner || {}
  });
}

function promptUsesReadySavedCharacterMapping(state, prompts = parsePrompts(state.control?.livePrompt)) {
  const readyHandles = new Set(readySavedCharacterMappings(state).map((mapping) => mapping.handle));
  if (!readyHandles.size) return false;
  return prompts.some((prompt) => scanCharacterMentions(prompt).some((mention) => readyHandles.has(normalizeCharacterHandle(mention.handle))));
}

function characterFeatureActive(state, prompts = parsePrompts(state.control?.livePrompt)) {
  if (activeSubmitPath(state) === "agent_first") return false;
  return characterPromptText(state).trim().length > 0 || promptUsesReadySavedCharacterMapping(state, prompts);
}

function savedCharacterRunAnalysis(state, prompts = parsePrompts(state.control?.livePrompt)) {
  const readyByHandle = new Map(readySavedCharacterMappings(state).map((mapping) => [mapping.handle, mapping]));
  const used = new Map();
  const undefinedHandles = new Set();
  const scenes = prompts.map((prompt, promptIndex) => {
    const required = [];
    const undefinedForScene = [];
    for (const mention of scanCharacterMentions(prompt)) {
      const handle = normalizeCharacterHandle(mention.handle);
      if (!handle) continue;
      if (readyByHandle.has(handle)) {
        required.push(handle);
        used.set(handle, (used.get(handle) || 0) + 1);
      } else {
        undefinedForScene.push(handle);
        undefinedHandles.add(handle);
      }
    }
    return {
      promptIndex,
      requiredCharacters: [...new Set(required)],
      undefinedCharacters: [...new Set(undefinedForScene)]
    };
  });
  const usedHandles = [...used.keys()];
  const assets = usedHandles.map((handle) => readyByHandle.get(handle)).filter(Boolean);
  const errors = [...undefinedHandles].map((handle) => ({
    code: CharacterFailureClass.undefinedMention,
    handle,
    message: `@${handle} is used in prompts but has no saved native Flow character mapping.`
  }));
  return {
    active: usedHandles.length > 0,
    ok: errors.length === 0,
    intents: assets.map((asset) => ({
      characterId: String(asset.characterId || `character:${asset.handle}`),
      handle: asset.handle,
      mention: `@${asset.handle}`,
      displayName: asset.displayName,
      description: "",
      additionalInfo: "",
      source: {
        mode: "saved_flow_character",
        flowCharacterId: asset.characterServerId,
        characterServerId: asset.characterServerId,
        projectId: asset.projectId || asset.activeProjectId || state.runtime?.projectId || ""
      },
      storage: {
        storeInFlow: true,
        saved: true
      },
      status: CharacterFailureClass.characterMappingReady
    })),
    errors,
    warnings: [],
    scenes,
    usedHandles,
    undefinedHandles: [...undefinedHandles]
  };
}

function characterRunAnalysis(state, prompts = parsePrompts(state.control?.livePrompt)) {
  const savedAnalysis = savedCharacterRunAnalysis(state, prompts);
  if (savedAnalysis.active && savedAnalysis.ok) return savedAnalysis;
  if (!characterFeatureActive(state)) {
    const parsed = parseCharacterPrompts("", {
      voiceCatalog: state.characters?.voiceCatalog || {},
      storeInFlow: state.characters?.storeInFlow === true
    });
    return { ...parsed, scenes: [], usedHandles: [], undefinedHandles: [], ok: true };
  }
  if (!characterPromptText(state).trim()) return savedAnalysis;
  return validateCharacterRun(prompts, characterPromptText(state), {
    voiceCatalog: state.characters?.voiceCatalog || {},
    storeInFlow: state.characters?.storeInFlow === true
  });
}

function workflowPromptTabLabelKey(mode = "") {
  if (mode === FLOW_MODES.textToImage) return "imagePrompts";
  if (mode === FLOW_MODES.imageToVideo) return "framePrompts";
  return "videoPrompts";
}

function compactSelect(settingKey, value, options) {
  return el("select", {
    class: "afw-val-btn",
    data: { settingKey }
  },
    options.map(([optionValue, label]) => el("option", {
      text: label,
      attrs: { value: optionValue, selected: String(value) === String(optionValue) }
    }))
  );
}

function autopilotPipelineOptions(state) {
  return [
    ["off", tr(state, "autopilotOff")],
    ["all", tr(state, "autopilotAll")],
    ["one", tr(state, "autopilotOne")],
  ];
}

function promptsHaveAutopilotVideoPrompts(prompts = []) {
  return prompts.length > 0 && prompts.every((prompt) => {
    const split = splitAutoFlowPromptLine(prompt);
    return split.isAutoFlowFormat && String(split.videoPrompt || "").trim();
  });
}

// ── Public render ────────────────────────────────────────────
// Module-level cursor that tracks the LAST RENDERED wizardStep so we can detect
// whether a re-render is a step transition (and which direction) vs an in-step
// state change. Set as a side effect of renderControlWizard.
let lastRenderedStep = null;

export function renderControlWizard(root, state, ctx = {}) {
  if (!root) return;
  const dispatch = typeof ctx.dispatch === "function" ? ctx.dispatch : () => {};
  const showConfirm = typeof ctx.showConfirm === "function" ? ctx.showConfirm : null;
  const onRun = typeof ctx.onRun === "function" ? ctx.onRun : null;

  clear(root);

  // Wrap everything in a wizard root so styles are scoped via .afw-* prefix
  const wizardRoot = el("div", { class: "afw-root" });
  wizardRoot.append(
    el("input", { id: "fileInput", attrs: { type: "file", accept: ".txt,text/plain", hidden: true } }),
    el("input", { id: "characterPromptFileInput", attrs: { type: "file", accept: ".txt,text/plain", hidden: true } }),
    el("input", { id: "refImageInput", attrs: { type: "file", accept: ".png,.jpg,.jpeg,.webp,.heic,.avif", multiple: true, hidden: true } }),
    el("input", { id: "imageInput", attrs: { type: "file", accept: ".png,.jpg,.jpeg,.webp,.heic,.avif", multiple: true, hidden: true } }),
    el("input", { id: "sourceVideoInput", attrs: { type: "file", accept: "video/*,.mp4,.mov,.webm", multiple: true, hidden: true } }),
    el("input", { id: "videoEditMediaInput", attrs: { type: "file", accept: "video/*,image/*,.mp4,.mov,.webm,.png,.jpg,.jpeg,.webp,.heic,.avif", multiple: true, hidden: true } }),
  );

  const c = state.control || {};
  const prompts = parsePrompts(c.livePrompt);
  const promptCount = prompts.length;

  const refs = allReferenceItems(state);

  const wizardStep = clampStep(c.wizardStep);
  const account = state.account || {};
  const isPro = account.plan === "pro" || account.plan === "team";
  const usage = account.usage || {};

  const M = MODES.find((m) => m.key === c.mode) || MODES[1];

  // ── Brand / status strip ───────────────────────────────────
  wizardRoot.appendChild(buildBrand(state));
  const accountStrip = buildAccountStrip(state);
  if (accountStrip) wizardRoot.appendChild(accountStrip);
  // Pro tier identity is rendered by the existing #header-usage-pill in
  // index.html — no wizard-side chip injection needed.

  // ── Mode buttons ─────────────────────────────────────────────
  wizardRoot.appendChild(buildModeFrame(state, dispatch, showConfirm));

  // ── Stepper ──────────────────────────────────────────────────
  wizardRoot.appendChild(buildStepper(wizardStep, dispatch, state));

  // ── Step view (header + body) ───────────────────────────────
  // Direction is "forward" if step number increased since last render,
  // "back" if it decreased, or null when nothing about the step changed.
  // CSS uses [data-anim] to choose the slide-in keyframe.
  const stepDirection = lastRenderedStep == null
    ? "init"
    : wizardStep > lastRenderedStep
      ? "forward"
      : wizardStep < lastRenderedStep
        ? "back"
        : null;
  lastRenderedStep = wizardStep;

  const stepView = el("div", {
    class: "afw-step-view",
    attrs: stepDirection ? { "data-anim": stepDirection } : null,
  });
  const videoEditUploadFirst = c.mode === FLOW_MODES.videoToVideo;
  if (wizardStep === 1) {
    stepView.append(
      buildStepHeaderNext(state, 1, videoEditUploadFirst ? "video_library" : "edit_note", videoEditUploadFirst ? "videoToVideoSource" : "addPrompts", dispatch, M, prompts, refs, promptCount),
      videoEditUploadFirst ? buildStep2Body(state, dispatch) : buildStep1Body(state, c.livePrompt || "", prompts, dispatch),
    );
  } else if (wizardStep === 2) {
    stepView.append(
      buildStepHeaderNext(state, 2, videoEditUploadFirst ? "edit_note" : "hub", videoEditUploadFirst ? "addPrompts" : "references", dispatch, M, prompts, refs, promptCount),
      videoEditUploadFirst ? buildStep1Body(state, c.livePrompt || "", prompts, dispatch) : buildStep2Body(state, dispatch),
    );
  } else {
    const lastRunError = String(c.lastRunError || "").trim();
    const errorBanner = lastRunError
      ? el("div", { class: "afw-run-error", attrs: { role: "alert" } },
          icon("error_outline"),
          el("span", { class: "afw-run-error-text", text: lastRunError }),
          el("button", {
            class: "afw-run-error-dismiss",
            attrs: { type: "button", title: tr(state, "close") },
            on: { click: (e) => {
              stopControlEvent(e);
              dispatch({ control: { lastRunError: "" } });
            } }
          }, icon("close"))
        )
      : null;
    stepView.append(
      buildStepHeaderRun(M, prompts, dispatch, state, onRun),
      ...(errorBanner ? [errorBanner] : []),
      buildStep3Body(state, prompts, refs, M, dispatch),
    );
  }
  wizardRoot.appendChild(stepView);

  // ── Step nav (Back + summary) ───────────────────────────────
  wizardRoot.appendChild(buildStepNav(state, wizardStep, M, prompts.length, c.presets, dispatch));

  root.appendChild(wizardRoot);

  // After a step change (forward or back), smooth-scroll the panel so the
  // STEPPER (not the step-view) lands at the top of the viewport. The
  // stepper is the minimum navigation context the user needs visible
  // (so they know which step they're on); everything below it is the
  // active step's content + step nav, which gets the maximum vertical
  // room. Brand strip + tabs + mode buttons scroll past — they're
  // constant chrome that doesn't need to stay visible during step
  // navigation. User reported v237/v238 didn't show the bottom CTAs;
  // v239 (which DOES show them) has the stepper at viewport top.
  // Skip on init render so the panel doesn't fight the user's
  // natural starting scroll position.
  if (stepDirection === "forward" || stepDirection === "back") {
    requestAnimationFrame(() => {
      const stepper = wizardRoot.querySelector(".afw-stepper");
      if (stepper?.scrollIntoView) {
        stepper.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    });
  }
}

// ── Helpers / sub-renderers ──────────────────────────────────

function clampStep(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 1;
  if (v < 1) return 1;
  if (v > 3) return 3;
  return Math.round(v);
}

function bridgeStatus(state) {
  const runtime = state.runtime || {};
  if (runtime.connected !== true) {
    const hasFlowTarget = Boolean(runtime.activeTabId || runtime.projectId || runtime.pageUrl);
    if (hasFlowTarget) {
      return {
        className: "is-checking",
        label: tr(state, "bridgeChecking"),
        title: runtime.bridgeError || tr(state, "bridgeCheckingHelp")
      };
    }
    return {
      className: "is-offline",
      label: tr(state, "bridgeOffline"),
      title: tr(state, "bridgeOfflineHelp")
    };
  }
  if (runtime.bridgeHealthy === true) {
    return {
      className: "is-healthy",
      label: tr(state, "bridgeHealthy"),
      title: tr(state, "bridgeHealthyHelp")
    };
  }
  if (runtime.bridgeDegraded === true) {
    return {
      className: "is-degraded",
      label: tr(state, "bridgeDegraded"),
      title: runtime.bridgeError || tr(state, "bridgeDegradedHelp")
    };
  }
  return {
    className: "is-checking",
    label: tr(state, "bridgeChecking"),
    title: runtime.bridgeError || tr(state, "bridgeCheckingHelp")
  };
}

function agentBridgeStatus(state) {
  const runtime = state.runtime || {};
  const agentBridge = runtime.agentBridge || {};
  const locallyEnabled = state.control?.agentMode?.bridgeEnabled === true;
  if (agentBridge.connected === true) {
    return {
      className: "is-healthy",
      label: tr(state, "connected"),
      title: agentBridge.hostName || tr(state, "agentModeBridgeControlsHelp")
    };
  }
  if (agentBridge.reconnecting === true) {
    return {
      className: "is-reconnecting",
      label: tr(state, "bridgeChecking"),
      title: tr(state, "bridgeCheckingHelp")
    };
  }
  if (agentBridge.enabled === true || locallyEnabled) {
    return {
      className: "is-checking",
      label: tr(state, "bridgeChecking"),
      title: tr(state, "agentModePairingHelp")
    };
  }
  return {
    className: "is-offline",
    label: tr(state, "bridgeOffline"),
    title: tr(state, "agentModePairingHelp")
  };
}

function buildBrand(state) {
  const project = state.runtime?.projectId || state.control?.presets?.downloadFolder || tr(state, "appName");
  const promptCount = parsePrompts(state.control?.livePrompt).length;
  const bridge = bridgeStatus(state);
  return el("div", { class: "afw-top" },
    el("div", { class: "afw-mark", text: "AF" }),
    el("div", { class: "afw-title-stack" },
      el("div", { class: "afw-t1" }, tr(state, "appName"),
        el("span", { class: "afw-v", text: `v${CONTROL_WIZARD_VERSION}` })),
      el("div", { class: "afw-t2" },
        el("span", { class: "afw-project-line" },
          el("span", {
            class: `afw-pdot ${state.runtime?.connected ? "is-connected" : "is-disconnected"}`,
            attrs: { title: state.runtime?.connected ? tr(state, "connected") : tr(state, "disconnected") }
          }),
          el("span", { class: "afw-project-text", text: tr(state, "projectPromptsReady", { project, count: promptCount }) }),
        ),
        el("span", {
          class: `afw-bridge-pill ${bridge.className}`,
          attrs: { title: bridge.title, "data-bridge-state": bridge.className.replace(/^is-/, "") }
        },
          el("span", { class: "afw-bridge-dot" }),
          el("span", { class: "afw-bridge-label", text: bridge.label }),
        ),
      ),
    ),
  );
}

function accountUsage(state) {
  const account = state.account || {};
  const usage = account.usage || {};
  const used = Number.isFinite(Number(usage.used)) ? Number(usage.used) : 0;
  const limit = Number.isFinite(Number(usage.limit)) ? Number(usage.limit) : 10;
  const remaining = Number.isFinite(Number(usage.remaining)) ? Number(usage.remaining) : Math.max(0, limit - used);
  const pro = usage.unlimited === true || ["pro", "team"].includes(String(account.plan || "").toLowerCase());
  return { account, usage, used, limit, remaining, pro, signedIn: account.status === "signed_in" };
}

function canRunFromAccount(state) {
  const info = accountUsage(state);
  return info.signedIn && (info.pro || info.remaining > 0);
}

function activeSubmitPath(state) {
  return state.control?.presets?.submitPath
    || state.control?.presets?.submitPathPreference
    || state.control?.submitPath
    || state.control?.submitPathPreference
    || "";
}

function agentPacketText(state) {
  return String(state.control?.packetImport?.rawText || state.control?.livePrompt || "");
}

function hasAgentImageFirstPacket(state) {
  const text = agentPacketText(state);
  if (!text.trim()) return false;
  const hasClipHeader = /(?:^|\n)\s*##\s*clip\s+\d+/i.test(text);
  const hasImageStep = /\*\*\s*(?:image\s+prompt|@img\d+|@frame\d+)/i.test(text);
  const hasVideoStep = /\*\*\s*(?:veo\s*3\s+prompt|video(?:\s*\([^)]*\))?)\s*\*\*/i.test(text);
  return hasClipHeader && hasImageStep && hasVideoStep;
}

function canAgentGenerateStartFrames(state, mode) {
  return mode?.key === FLOW_MODES.imageToVideo
    && activeSubmitPath(state) === "agent_first"
    && hasAgentImageFirstPacket(state);
}


function runBlockerLabel(state, promptCount = 0) {
  const info = accountUsage(state);
  if (!promptCount) return tr(state, "addPromptsToRun");
  const characterCheck = characterRunAnalysis(state);
  if (characterFeatureActive(state) && characterCheck.errors?.length) {
    const error = characterCheck.errors[0] || {};
    if (error.code === "CHARACTER_DUPLICATE_HANDLE") return tr(state, "duplicateCharacterBlocker", { handle: error.handle || "" });
    if (error.code === "CHARACTER_UNDEFINED_MENTION") return tr(state, "characterUndefinedBlocker", { handle: error.handle || "" });
    if (error.code === "CHARACTER_VOICE_UNRESOLVED") return tr(state, "characterVoiceBlocker");
    return error.message || tr(state, "characterErrorsFound", { count: characterCheck.errors.length });
  }
  if (!info.signedIn) return tr(state, "signInToRun");
  if (!info.pro && info.remaining <= 0) return tr(state, "dailyLimitReached");
  // Modes that require a reference image must have at least one attached
  // before Run is allowed. Without this guard the run handoff in app.js
  // mutates state.ui.activeRoute = "live" + renders preparing UI BEFORE
  // buildJobs() throws on the missing ref, causing a visible flash to
  // Live Queue and back to step 2 (the "Frame to Video glitches on Run
  // without an image" symptom).
  const mode = MODES.find((m) => m.key === state.control?.mode);
  if (state.control?.activeApplyMode === "repeat" && !(state.control?.oneToOneBatchRefIds || []).length) {
    return tr(state, "addRefToRun");
  }
  if (mode?.needsRefs) {
    const refIds = activeReferenceIdsForMode(state);
    const hasNativeCharacterRefs = state.control?.mode === FLOW_MODES.ingredientsToVideo
      && promptUsesReadySavedCharacterMapping(state, parsePrompts(state.control?.livePrompt));
    const hasAgentStartFrames = canAgentGenerateStartFrames(state, mode);
    if (!refIds.length && !hasNativeCharacterRefs && !hasAgentStartFrames) {
      return mode.key === FLOW_MODES.videoToVideo ? tr(state, "videoToVideoSourceEmpty") : tr(state, "addRefToRun");
    }
  }
  return "";
}

function buildAccountStrip(state) {
  const locale = state.control?.presets?.language || "en";
  const info = accountUsage(state);
  // Pro tier shows as the existing #header-usage-pill.is-pro chip in the
  // top header (rendered by index.html, toggled by app.js), not a full-width
  // strip in the wizard body.
  if (info.pro) return null;
  const pendingCheckout = Boolean(info.account?.pendingCheckout);
  const email = info.account?.email || "";
  const pct = info.pro ? 100 : Math.max(0, Math.min(100, (info.used / Math.max(1, info.limit)) * 100));
  const barClass = pct >= 100 ? "critical" : pct >= 70 ? "warning" : "";
  const usageLabel = info.signedIn
    ? translate("promptsToday", { used: Math.min(info.used, info.limit), limit: info.limit }, locale)
    : translate("login", {}, locale);
  return el("div", { id: "freemiumBanner", class: "is-visible afw-account-strip" },
    el("div", { class: "banner-top" },
      el("span", { class: "banner-tier" }, icon("token"), translate("freePlan", {}, locale)),
      el("span", { id: "bannerUsageText", class: "banner-usage", text: usageLabel }),
    ),
    el("p", { class: "auth-email-hint banner-email-hint", text: info.signedIn ? translate("signedInUsageVerified", {}, locale) : pendingCheckout ? translate("verifyEmailForCheckout", {}, locale) : translate("signInRequired", {}, locale) }),
    el("div", { class: "usage-bar" },
      el("div", { id: "bannerUsageBar", class: `usage-bar-fill ${barClass}`.trim(), style: { width: `${pct}%` } }),
    ),
    el("div", { id: "bannerResetTimer", style: { display: info.signedIn && info.remaining <= 0 ? "block" : "none", textAlign: "center", padding: "6px 0", fontSize: "11px", color: "#f44336", fontWeight: "600" } },
      icon("timer"),
      ` ${translate("resetsIn", {}, locale)} `,
      el("span", { id: "bannerResetCountdown", text: "--:--:--" }),
    ),
    el("div", { class: "banner-limits" },
      el("span", { class: "limit-item" }, icon("lock"), ` ${translate("limitHighResImages", {}, locale)}`),
      el("span", { class: "limit-item" }, icon("lock"), ` ${translate("limitHighResVideo", {}, locale)}`),
      el("span", { class: "limit-item" }, icon("lock"), ` ${translate("limitMultiOutput", {}, locale)}`),
      el("span", { class: "limit-item" }, icon("lock"), ` ${translate("limitAutoDownload", {}, locale)}`),
    ),
    el("button", { class: "banner-upgrade-btn", id: "bannerUpgradeBtn", attrs: { type: "button" } },
      icon("rocket_launch"),
      el("span", { text: info.signedIn ? translate("unlockPro", {}, locale) : pendingCheckout ? translate("continueProCheckout", {}, locale) : translate("signInUnlockPro", {}, locale) }),
    ),
    !info.signedIn ? el("div", { id: "bannerAuthFlow", class: "afw-account-auth" },
      el("div", { id: "bannerEmailStep" },
        el("input", { id: "bannerEmailInput", value: email, attrs: { type: "email", placeholder: "your@email.com", autocomplete: "email" } }),
        el("button", { id: "bannerSendCodeBtn", attrs: { type: "button" } }, el("span", { class: "auth-send-code-label", text: pendingCheckout ? translate("sendCheckoutCode", {}, locale) : translate("sendCode", {}, locale) })),
      ),
      el("div", { id: "bannerOtpStep", style: { display: state.account?.status === "pending_confirmation" ? "grid" : "none" } },
        el("input", { id: "bannerOtpInput", value: info.account?.otpCode || "", attrs: { type: "text", placeholder: translate("enterCode", {}, locale), maxlength: "10", autocomplete: "one-time-code", inputmode: "numeric" } }),
        el("button", { id: "bannerVerifyBtn", attrs: { type: "button" }, text: translate("verify", {}, locale) }),
      ),
    ) : null,
  );
}

function buildModeFrame(state, dispatch, showConfirm) {
  const grid = el("div", { class: "afw-mode-grid" });
  for (const m of MODES) {
    const active = state.control?.mode === m.key;
    const label = modeName(state, m);
    const btn = el("button", {
      class: "afw-mode-btn" + (active ? " active" : ""),
      attrs: { type: "button", title: label },
      on: { click: (e) => { stopControlEvent(e); handleModeChange(m.key, state, dispatch, showConfirm); } },
    }, icon(m.iconName), el("span", { text: label }));
    grid.appendChild(btn);
  }
  return el("div", { class: "afw-mode-frame" }, grid);
}

async function handleModeChange(newMode, state, dispatch, showConfirm) {
  if (state.control?.mode === newMode) {
    if (Number(state.control?.wizardStep || 1) !== 1) {
      dispatch({ control: { wizardStep: 1 } });
    }
    return;
  }
  const hasPrompts = parsePrompts(state.control?.livePrompt).length > 0;
  const hasRefs = Object.values(state.control?.references || {}).some((v) => String(v || "").trim().length > 0);
  const modePresetPatch = newMode === FLOW_MODES.videoToVideo
    ? { submitPath: "api_first", submitPathPreference: "api_first", model: "omni_flash", videoLength: "10" }
    : {};
  if (!hasPrompts && !hasRefs) {
    dispatch({ control: { mode: newMode, activeApplyMode: "shared", sourceVideo: null, sourceVideos: [], presets: modePresetPatch } });
    return;
  }
  if (!showConfirm) {
    dispatch({ control: { mode: newMode, activeApplyMode: "shared", sourceVideo: null, sourceVideos: [], presets: modePresetPatch } });
    return;
  }
  const ok = await showConfirm({
    title: tr(state, "switchModeTitle"),
    body: tr(state, "switchModeBody"),
    confirmLabel: tr(state, "switchModeConfirm"),
  });
  if (ok) {
    dispatch({
      control: {
        mode: newMode,
        activeApplyMode: "shared",
        livePrompt: "",
        characterPromptText: "",
        promptTab: "workflow_prompts",
        referencesTab: "prompt_references",
        runMappingTab: "prompt_mapping",
        characterSources: {},
        promptRefMap: {},
        oneToOneBatchRefIds: [],
        sourceVideo: null,
        sourceVideos: [],
        presets: modePresetPatch,
        references: {
          imagePromptRefs: "",
          styleRefRefs: "",
          omniRefRefs: "",
          startFrameRef: "",
          endFrameRef: "",
          ingredientsRefs: "",
        },
        wizardStep: 1,
      },
    });
  }
}

function buildStepper(currentStep, dispatch, state) {
  const step = (n, lbl) => {
    const cls = "afw-step" + (n < currentStep ? " done" : n === currentStep ? " active" : "");
    return el("div", {
      class: cls,
      attrs: { role: "button", "data-step": String(n) },
      on: { click: (e) => { stopControlEvent(e); dispatch({ control: { wizardStep: n } }); } },
    },
      el("div", { class: "afw-num" }, el("span", { text: String(n) })),
      el("div", { class: "afw-lbl", text: lbl }),
    );
  };
  const videoEdit = state.control?.mode === FLOW_MODES.videoToVideo;
  return el("div", { class: "afw-stepper" },
    el("div", { class: "afw-stepper-row" },
      step(1, videoEdit ? tr(state, "videos") : tr(state, "prompts")),
      step(2, videoEdit ? tr(state, "prompts") : tr(state, "references")),
      step(3, tr(state, "run"))
    ),
  );
}

function buildStepHeaderNext(state, stepNum, iconName, labelKey, dispatch, mode, prompts, refs, promptCount) {
  const isStep3 = stepNum === 3;
  // Back button — only shown when there's a previous step to go to.
  const back = stepNum > 1 ? el("button", {
    class: "afw-back-inline",
    attrs: { type: "button", title: tr(state, "back") },
    // Same blur-before-dispatch trick used by Next: keeps focus from
    // bouncing to <body> when the button gets re-rendered out from under us.
    on: { click: (e) => { stopControlEvent(e); dispatch({ control: { wizardStep: stepNum - 1 } }); } },
  }, icon("arrow_back"), tr(state, "back")) : null;

  const next = el("button", {
    class: isStep3 ? "afw-run" : "afw-next",
    attrs: { type: "button" },
    // Blur BEFORE dispatch so the button is unfocused while still on screen.
    // If we let it stay focused while the re-render destroys it, the browser
    // restores focus to <body> with a small scroll jump — the "tad" the user
    // felt. Blurring first releases focus cleanly.
    on: { click: (e) => { stopControlEvent(e); dispatch({ control: { wizardStep: stepNum + 1 } }); } },
  });
  if (isStep3) {
    next.append(icon("play_arrow"), document.createTextNode(tr(state, "runPromptCount", { count: promptCount })));
  } else {
    next.append(document.createTextNode(tr(state, "next")), icon("arrow_forward"));
  }
  return el("div", { class: "afw-step-header" },
    el("h2", {}, icon(iconName), tr(state, labelKey)),
    el("div", { class: "afw-step-actions" }, back, buildGuideJump(state), buildHistoryJump(state, dispatch), next),
  );
}

function buildStepHeaderRun(mode, prompts, dispatch, state, onRun) {
  const isVideo = String(mode.key || "").endsWith("video");
  const count = prompts.length;
  const isAppending = Boolean(state.queue?.running);
  const canRun = canRunFromAccount(state);
  const blocker = runBlockerLabel(state, count);
  const disabled = Boolean(blocker) || !canRun || !count;
  const actionLabel = isAppending ? tr(state, "addToQueue") : tr(state, "runPromptCount", { count });
  const actionIcon = disabled ? "lock" : isAppending ? "playlist_add" : "play_arrow";
  const back = el("button", {
    class: "afw-back-inline",
    attrs: { type: "button", title: tr(state, "back") },
    on: { click: (e) => { stopControlEvent(e); dispatch({ control: { wizardStep: 2 } }); } },
  }, icon("arrow_back"), tr(state, "back"));
  const run = el("button", {
    id: "generate-btn",
    class: "afw-run",
    attrs: { type: "button", title: blocker || actionLabel, disabled: disabled ? "disabled" : null },
    on: { click: (e) => {
      e.stopPropagation();
      stopControlEvent(e);
      if (!disabled && onRun) onRun();
    } },
  }, icon(actionIcon), blocker || actionLabel);
  return el("div", { class: "afw-step-header" },
    el("h2", {}, icon("rocket_launch"), tr(state, "reviewAndRun")),
    el("div", { class: "afw-step-actions" },
      back,
      buildGuideJump(state),
      buildHistoryJump(state, dispatch),
      el("div", { class: "afw-run-wrap" }, run),
    ),
  );
}

// ── Step 1: Prompts ──────────────────────────────────────────
function buildStep1Body(state, text, prompts, dispatch) {
  const agentFirst = activeSubmitPath(state) === "agent_first";
  const activeTab = !agentFirst && state.control?.promptTab === "character_prompts" ? "character_prompts" : "workflow_prompts";
  const mode = state.control?.mode || FLOW_MODES.textToVideo;
  const characterText = characterPromptText(state);
  const characterAnalysis = characterRunAnalysis(state, prompts);
  const tabs = agentFirst ? null : el("div", { class: "afw-tabs", attrs: { role: "tablist" } },
    el("button", {
      class: `afw-tab${activeTab === "workflow_prompts" ? " active" : ""}`,
      attrs: { type: "button", role: "tab", "aria-selected": activeTab === "workflow_prompts" ? "true" : "false" },
      on: { click: (e) => { stopControlEvent(e); dispatch({ control: { promptTab: "workflow_prompts" } }); } }
    }, tr(state, workflowPromptTabLabelKey(mode))),
    el("button", {
      class: `afw-tab${activeTab === "character_prompts" ? " active" : ""}`,
      attrs: { type: "button", role: "tab", "aria-selected": activeTab === "character_prompts" ? "true" : "false" },
      on: { click: (e) => { stopControlEvent(e); dispatch({ control: { promptTab: "character_prompts" } }); } }
    }, tr(state, "characterPrompts"))
  );
  if (activeTab === "character_prompts") {
    return buildCharacterPromptStepBody(state, characterText, characterAnalysis, dispatch, tabs);
  }
  let previewWrap;
  let countNode;
  const renderPreview = (nextText) => {
    const nextPrompts = parsePrompts(nextText);
    if (countNode) countNode.textContent = String(nextPrompts.length);
    if (!previewWrap) return;
    clear(previewWrap);
    appendPromptPreview(state, previewWrap, nextPrompts);
  };
  const ta = el("textarea", {
    id: "prompts",
    placeholder: tr(state, "promptPastePlaceholder"),
    on: {
      input: (e) => {
        renderPreview(e.target.value);
        dispatch({ control: { livePrompt: e.target.value } });
      },
    },
  });
  ta.value = text;

  countNode = el("b", { text: String(prompts.length) });
  const ct = el("span", { class: "afw-paste-ct" },
    countNode,
    ` ${tr(state, "promptsDetected")}`,
  );

  previewWrap = el("div", { class: "afw-prompt-preview-scroll" });
  appendPromptPreview(state, previewWrap, prompts);

  const videoEdit = mode === FLOW_MODES.videoToVideo;
  const sourceCount = Array.isArray(state.control?.sourceVideos) ? state.control.sourceVideos.length : 0;
  const reusePromptForAll = state.control?.videoEdit?.reusePromptForAll !== false;
  const activeVideoEditRefs = videoEdit
    ? savedItemsForActiveReferenceIds(state).map((item, index) => ({
        handle: `@image${index + 1}`,
        label: item.title || item.fileName || `Image ${index + 1}`
      }))
    : [];
  const handleBar = videoEdit && activeVideoEditRefs.length
    ? el("div", { class: "afw-handle-bar" },
        el("span", { class: "afw-handle-bar-label", text: tr(state, "videoEditMentionHelp") }),
        ...activeVideoEditRefs.map((item) => el("button", {
          class: "afw-handle-pill",
          attrs: { type: "button", title: item.label },
          on: { click: (event) => {
            stopControlEvent(event);
            const separator = ta.value && !/\s$/.test(ta.value) ? " " : "";
            ta.value = `${ta.value}${separator}${item.handle} `;
            renderPreview(ta.value);
            dispatch({ control: { livePrompt: ta.value } });
            ta.focus();
          } }
        }, item.handle))
      )
    : null;

  return el("div", { class: "afw-step-body" },
    tabs,
    videoEdit ? el("label", { class: "afw-save-library-toggle afw-reuse-prompt-toggle" },
      el("input", {
        checked: reusePromptForAll,
        attrs: { type: "checkbox" },
        on: { change: (event) => dispatch({ control: { videoEdit: { ...(state.control?.videoEdit || {}), reusePromptForAll: event.target.checked } } }) }
      }),
      el("span", { text: tr(state, "reusePromptForAll") }),
      el("small", { text: reusePromptForAll ? tr(state, "reusePromptForAllHelp", { count: sourceCount }) : tr(state, "onePromptPerVideoHelp", { count: sourceCount }) })
    ) : null,
    handleBar,
    el("p", { class: "afw-lede", text: videoEdit ? tr(state, "videoEditPromptHelp") : tr(state, "pasteBatchHelp") }),
    el("div", { class: "afw-paste" },
      ta,
      el("div", { class: "afw-paste-row" },
        el("button", { id: "uploadPromptButton", class: "afw-back", attrs: { type: "button", style: "padding:5px 10px;font-size:10.5px;" } }, icon("file_upload"), tr(state, "import")),
        el("button", { id: "pastePromptButton", class: "afw-back", attrs: { type: "button", style: "padding:5px 10px;font-size:10.5px;" } }, icon("content_paste"), tr(state, "paste")),
        ct,
      ),
    ),
    buildPacketImportPreview(state, ""),
    previewWrap,
  );
}

function buildCharacterPromptStepBody(state, text, analysis, dispatch, tabs) {
  let listWrap;
  let countNode;
  let issueNode;
  const renderParsed = (nextText) => {
    const next = validateCharacterRun(parsePrompts(state.control?.livePrompt), nextText, {
      voiceCatalog: state.characters?.voiceCatalog || {},
      storeInFlow: state.characters?.storeInFlow === true
    });
    if (countNode) countNode.textContent = String(next.intents.length);
    if (issueNode) issueNode.textContent = next.errors.length ? tr(state, "characterErrorsFound", { count: next.errors.length }) : "";
    if (!listWrap) return;
    clear(listWrap);
    appendCharacterPreview(state, listWrap, next);
  };
  const ta = el("textarea", {
    id: "characterPrompts",
    placeholder: tr(state, "characterPromptPlaceholder"),
    on: {
      input: (e) => {
        renderParsed(e.target.value);
        dispatch({ control: { characterPromptText: e.target.value } });
      },
    },
  });
  ta.value = text;
  countNode = el("b", { text: String(analysis.intents.length) });
  issueNode = el("span", { class: "afw-character-issues", text: analysis.errors.length ? tr(state, "characterErrorsFound", { count: analysis.errors.length }) : "" });
  listWrap = el("div", { class: "afw-character-list" });
  appendCharacterPreview(state, listWrap, analysis);
  return el("div", { class: "afw-step-body" },
    tabs,
    el("p", { class: "afw-lede", text: tr(state, "characterPromptHelp") }),
    el("div", { class: "afw-paste" },
      ta,
      el("div", { class: "afw-paste-row" },
        el("button", { id: "uploadCharacterPromptButton", class: "afw-back", attrs: { type: "button", style: "padding:5px 10px;font-size:10.5px;" } }, icon("file_upload"), tr(state, "import")),
        el("button", { id: "pasteCharacterPromptButton", class: "afw-back", attrs: { type: "button", style: "padding:5px 10px;font-size:10.5px;" } }, icon("content_paste"), tr(state, "paste")),
        el("span", { class: "afw-paste-ct" }, countNode, ` ${tr(state, "charactersDetected")}`),
      ),
    ),
    buildPacketImportPreview(state, "Character"),
    issueNode,
    listWrap,
  );
}

function buildPacketImportPreview(state, idSuffix = "") {
  const packetState = state.control?.packetImport || {};
  const rawText = String(packetState.rawText || "").trim();
  if (packetState.open !== true || !rawText) return null;
  const packet = parseAutoFlowPacket(rawText, {
    voiceCatalog: state.characters?.voiceCatalog || {},
    storeInFlow: state.characters?.storeInFlow === true
  });
  const handles = (items) => items.map((item) => `@${item.handle || item}`).filter(Boolean).join(", ");
  const issues = [
    packet.undefinedMentions.length ? tr(state, "packetUndefinedMentions", { handles: handles(packet.undefinedMentions) }) : "",
    packet.duplicateHandles.length ? tr(state, "packetDuplicateHandles", { handles: handles(packet.duplicateHandles) }) : "",
    packet.invalidHandles.length ? tr(state, "packetInvalidHandles", { handles: packet.invalidHandles.map((handle) => `@${handle}`).join(", ") }) : "",
    packet.unusedCharacters.length ? tr(state, "packetUnusedCharacters", { handles: handles(packet.unusedCharacters) }) : ""
  ].filter(Boolean);
  const applyDisabled = !packet.counts.characters || !packet.counts.scenes;
  return el("div", { class: `afw-packet-preview${packet.errors.length ? " has-issues" : ""}` },
    el("div", { class: "afw-packet-head" },
      el("div", { class: "afw-reflib-main" },
        el("div", { class: "afw-icn" }, icon("assignment")),
        el("div", { class: "afw-meta" },
          el("span", { class: "afw-name", text: tr(state, "packetPreviewTitle") }),
          el("span", { class: "afw-sub", text: tr(state, "packetCounts", { characters: packet.counts.characters, scenes: packet.counts.scenes, warnings: issues.length }) }),
        ),
      ),
      el("div", { class: "afw-packet-actions" },
        el("button", { id: `cancelAutoFlowPacketButton${idSuffix}`, class: "afw-back", attrs: { type: "button" } }, icon("close"), tr(state, "close")),
        el("button", { id: `applyAutoFlowPacketButton${idSuffix}`, class: "afw-add-btn", attrs: { type: "button", disabled: applyDisabled ? "disabled" : null } }, icon("check"), tr(state, "applyPacket"))
      )
    ),
    el("div", { class: "afw-packet-grid" },
      el("span", { class: "afw-character-pill", text: `${packet.counts.characters} ${tr(state, "characterPrompts")}` }),
      el("span", { class: "afw-character-pill", text: `${packet.counts.scenes} ${tr(state, "videoPrompts")}` }),
      packet.notesText ? el("span", { class: "afw-character-pill", text: tr(state, "packetNotesFound") }) : null,
      el("span", { class: "afw-character-pill is-warn", text: tr(state, "packetNativeSetupRequired") }),
      el("span", { class: "afw-character-pill is-warn", text: tr(state, "packetOmniReadiness") }),
      el("span", { class: "afw-character-pill", text: tr(state, "packetMappingsPreserved") })
    ),
    issues.length
      ? el("div", { class: "afw-packet-issues" }, issues.map((message) => el("div", { class: "afw-character-row is-error" },
          el("span", { class: "afw-character-handle", text: "!" }),
          el("span", { class: "afw-character-meta", text: message })
        )))
      : null
  );
}

function appendPromptPreview(state, previewWrap, prompts) {
  if (prompts.length === 0) {
    previewWrap.appendChild(el("div", { class: "afw-prompt-mini", attrs: { style: "color:var(--afw-text-soft); font-style:italic;" } },
      el("span", { class: "afw-idx", text: "-" }),
      el("div", { class: "afw-body", text: tr(state, "noPromptsYet") }),
    ));
    return;
  }
  prompts.forEach((p, i) => {
    const body = el("div", { class: "afw-body" });
    const parts = String(p || "").split(/(@[A-Za-z0-9_-]+)/g).filter(Boolean);
    parts.forEach((part) => body.appendChild(/^@[A-Za-z0-9_-]+$/.test(part)
      ? el("span", { class: "afw-inline-handle-pill", text: part })
      : document.createTextNode(part)));
    previewWrap.appendChild(el("div", { class: "afw-prompt-mini" },
      el("span", { class: "afw-idx", text: pad2(i + 1) }),
      body,
    ));
  });
}

function appendCharacterPreview(state, listWrap, analysis) {
  if (!analysis.intents.length && !analysis.errors.length) {
    listWrap.appendChild(el("div", { class: "afw-character-empty", text: tr(state, "characterParseEmpty") }));
    return;
  }
  for (const error of analysis.errors || []) {
    listWrap.appendChild(el("div", { class: "afw-character-row is-error" },
      el("span", { class: "afw-character-handle", text: error.handle ? `@${error.handle}` : "!" }),
      el("span", { class: "afw-character-meta", text: error.message || error.code || tr(state, "error") }),
    ));
  }
  for (const intent of analysis.intents || []) {
    const voiceLabel = intent.voice?.mode === "selected_flow_voice"
      ? intent.voice.flowVoiceName
      : intent.voice?.mode === "unresolved"
        ? tr(state, "characterVoiceBlocker")
        : tr(state, "characterVoiceNone");
    const usedCount = (analysis.scenes || []).filter((scene) => scene.requiredCharacters?.includes(intent.handle)).length;
    listWrap.appendChild(el("div", { class: `afw-character-row${intent.voice?.mode === "unresolved" ? " is-error" : ""}` },
      el("span", { class: "afw-character-handle", text: `@${intent.handle}` }),
      el("span", { class: "afw-character-meta", text: intent.description }),
      el("span", { class: "afw-character-pill", text: voiceLabel }),
      intent.additionalInfo ? el("span", { class: "afw-character-pill", text: tr(state, "characterInfoAdded") }) : null,
      usedCount ? el("span", { class: "afw-character-pill", text: `${usedCount} prompt${usedCount === 1 ? "" : "s"}` }) : null,
    ));
  }
}

// ── Step 2: References ──────────────────────────────────────
function buildStep2Body(state, dispatch) {
  const savedRefs = Array.isArray(state.referenceLibrary?.savedItems) ? state.referenceLibrary.savedItems : [];
  const allRefs = allReferenceItems(state);
  const lastSync = state.referenceLibrary?.lastSyncedAt || null;
  const totalSize = savedRefs.reduce((s, r) => s + (Number(r.bytes || r.size) || 0), 0);
  const mode = state.control?.mode || FLOW_MODES.textToVideo;
  const refs = mode === FLOW_MODES.videoToVideo
    ? allRefs.filter((item) => !/^video\//i.test(String(item?.mimeType || item?.type || "")))
    : allRefs;
  const activeRefIds = activeReferenceIdsForMode(state);
  const limit = REF_LIMITS[mode] ?? 0;
  const activeCta = state.control?.activeApplyMode || "shared";
  const refCopy = mode === FLOW_MODES.textToVideo
    ? tr(state, "textToVideoNoRefs")
    : mode === FLOW_MODES.imageToVideo
      ? tr(state, "frameToVideoRefsHelp")
      : mode === FLOW_MODES.ingredientsToVideo
        ? tr(state, "ingredientsRefsHelp")
        : mode === FLOW_MODES.videoToVideo
          ? tr(state, "videoEditPersistentRefsHelp")
          : tr(state, "createImageRefsHelp");
  const activeTab = mode === FLOW_MODES.videoToVideo
    ? "prompt_references"
    : state.control?.referencesTab === "character_sources" ? "character_sources" : "prompt_references";
  const tabs = mode === FLOW_MODES.videoToVideo ? null : buildSegmentTabs(state, [
    ["prompt_references", tr(state, "promptReferences")],
    ["character_sources", tr(state, "characterSources")]
  ], activeTab, (value) => dispatch({ control: { referencesTab: value } }));

  if (activeTab === "character_sources") {
    return buildCharacterSourcesStepBody(state, dispatch, tabs);
  }

  let videoSourceSection = null;
  if (mode === FLOW_MODES.videoToVideo) {
    const sources = Array.isArray(state.control?.sourceVideos) && state.control.sourceVideos.length
      ? state.control.sourceVideos
      : (state.control?.sourceVideo ? [state.control.sourceVideo] : []);
    const source = sources[0] || null;
    const uploadedCount = sources.filter((item) => item.mediaId || item.uploadStatus === "uploaded").length;
    const failedCount = sources.filter((item) => item.uploadStatus === "failed").length;
    const uploadingCount = sources.filter((item) => item.uploadStatus === "uploading").length;
    const displaySources = [
      ...sources.filter((item) => item.uploadStatus === "failed"),
      ...sources.filter((item) => item.uploadStatus !== "failed")
    ].slice(0, 50);
    const persistentCount = activeRefIds.length;
    const videosPerAgentMessage = Math.max(1, 10 - persistentCount);
    const engine = state.control?.presets?.submitPath === "api_first" ? "api_first" : "agent_first";
    const engineButton = (value, label, help) => el("button", {
      class: `afw-engine-choice${engine === value ? " active" : ""}`,
      attrs: { type: "button" },
      on: { click: (event) => {
        stopControlEvent(event);
        dispatch({ control: {
          videoEdit: { ...(state.control?.videoEdit || {}), engine: value },
          presets: { ...(state.control?.presets || {}), submitPath: value, submitPathPreference: value }
        } });
      } }
    }, el("strong", { text: label }), el("small", { text: help }));
    videoSourceSection = el("div", { class: "afw-video-source-section" },
      el("p", { class: "afw-lede", text: tr(state, "videoToVideoSourceHelp") }),
      el("div", { class: "afw-engine-picker" },
        engineButton("agent_first", tr(state, "agentVideoEditEngine"), tr(state, "agentVideoEditEngineHelp")),
        engineButton("api_first", tr(state, "omniVideoEditEngine"), tr(state, "omniVideoEditEngineHelp"))
      ),
      el("div", { class: `afw-video-source-card${source ? " is-ready" : ""}` },
        el("div", { class: "afw-icn" }, icon(source ? "movie" : "video_file")),
        el("div", { class: "afw-meta" },
          el("span", { class: "afw-name", text: source ? `${sources.length} ${tr(state, "videos")}` : tr(state, "videoToVideoSource") }),
          el("span", { class: "afw-sub", text: source
            ? tr(state, "videoEditUploadSummary", { uploaded: uploadedCount, total: sources.length, failed: failedCount, uploading: uploadingCount })
            : tr(state, "videoToVideoSourceEmpty") }),
          source ? el("span", { class: "afw-sub", text: engine === "agent_first"
            ? tr(state, "videoEditBatchCapacity", { videos: videosPerAgentMessage, images: persistentCount })
            : tr(state, "videoEditApiCapacity", { images: persistentCount }) }) : null
        ),
        source ? el("button", { id: "clearSourceVideoButton", class: "afw-back", attrs: { type: "button" } }, icon("close"), tr(state, "clear")) : null
      ),
      el("button", { id: "videoEditMediaUploadButton", class: "afw-big-upload", attrs: { type: "button" } },
        icon("upload"),
        el("span", { class: "afw-big-upload-copy" },
          el("strong", { text: tr(state, "addVideoEditMedia") }),
          el("small", { text: tr(state, "addVideoEditMediaHelp") })
        )
      ),
      failedCount ? el("div", { class: "afw-source-upload-actions" },
        el("button", { id: "retryFailedSourceVideosButton", class: "afw-back", attrs: { type: "button" } }, icon("refresh"), tr(state, "retryFailedUploads", { count: failedCount }))
      ) : null,
      displaySources.length ? el("div", { class: "afw-source-video-list" },
        ...displaySources.map((item, index) => el("div", { class: `afw-source-video-row is-${item.uploadStatus || (item.mediaId ? "uploaded" : "local")}` },
          el("span", { class: "afw-source-index", text: String(item.sourceIndex || index + 1).padStart(3, "0") }),
          el("span", { class: "afw-source-name", text: item.fileName || item.title || `Video ${index + 1}` }),
          el("span", { class: "afw-source-meta", text: `${Number(item.durationSeconds || 0).toFixed(1)}s · ${formatBytes(item.size || 0)}` }),
          el("span", { class: "afw-source-status", text: item.mediaId ? tr(state, "uploaded") : item.uploadStatus === "failed" ? tr(state, "failed") : item.uploadStatus === "uploading" ? tr(state, "uploading") : tr(state, "local") }),
          item.uploadError ? el("span", { class: "afw-source-error", text: item.uploadError }) : null
        )),
        sources.length > displaySources.length ? el("div", { class: "afw-source-list-more", text: tr(state, "moreVideosNotRendered", { count: sources.length - displaySources.length }) }) : null
      ) : null
    );
  }

  if (mode === FLOW_MODES.textToVideo) {
    return el("div", { class: "afw-step-body" },
      tabs,
      el("div", { class: "afw-no-refs-card" },
        el("div", { class: "afw-icn" }, icon("text_fields")),
        el("div", { class: "afw-meta" },
          el("span", { class: "afw-name", text: tr(state, "textToVideo") }),
          el("span", { class: "afw-sub", text: refCopy }),
        ),
      )
    );
  }

  const refLibRow = el("div", { class: "afw-reflib-row" },
    el("div", { class: "afw-reflib-main" },
      el("div", { class: "afw-icn" }, icon("collections_bookmark")),
      el("div", { class: "afw-meta" },
        el("span", { class: "afw-name", text: mode === FLOW_MODES.videoToVideo ? tr(state, "savedReferenceImages") : tr(state, "referenceLibrary") }),
        el("span", { class: "afw-sub", text: mode === FLOW_MODES.videoToVideo
          ? `${tr(state, "videoEditSavedImagesHelp")} ${tr(state, "refsSavedActive", { saved: savedRefs.length, size: formatBytes(totalSize), active: activeRefIds.length, limit })}`
          : tr(state, "refsSavedActive", { saved: savedRefs.length, size: formatBytes(totalSize), active: activeRefIds.length, limit }) }),
      ),
    ),
    mode === FLOW_MODES.videoToVideo ? null : el("button", { id: "addRefsToLibraryButton", class: "afw-add-btn", attrs: { type: "button" } },
      icon("add_photo_alternate"),
      el("span", { text: tr(state, "addToLibrary") })
    ),
  );

  const refStrip = el("div", { class: "afw-ref-strip" });
  if (refs.length === 0) {
    refStrip.appendChild(el("div", { class: "afw-rt-empty", text: tr(state, "dropFirstReference") }));
  } else {
    for (const r of refs) {
      const id = r.id || "";
      const active = activeRefIds.includes(id);
      refStrip.appendChild(el("div", {
        class: `afw-rt${active ? " active" : ""}${r.temporary ? " temporary" : ""}`,
        data: { refLibraryId: id },
        attrs: { title: r.title || r.name || r.fileName || r.id || "", draggable: true },
      },
        imageForRef(r, "afw-face"),
        el("div", { class: "afw-rname", text: r.title || r.fileName || r.name || r.id || "" }),
        r.temporary ? el("span", { class: "afw-temp-badge", text: tr(state, "run") }) : null,
        active ? el("span", { class: "afw-ref-check" }, icon("check")) : null,
        el("button", {
          class: "afw-ref-remove",
          data: { refDeleteId: id },
          attrs: { type: "button", title: tr(state, "removeFromLibrary") },
        }, icon("close")),
      ));
    }
  }

  const cta = (key, name, sub, iconName, tip) => el("button", {
    class: "afw-cta" + (activeCta === key ? " active" : ""),
    attrs: { type: "button", "data-cta": key, title: tip },
    on: { click: (e) => {
      stopControlEvent(e);
      dispatch({ control: applyModePatch(state, key) });
    } },
  },
    el("div", { class: "afw-icn" }, icon(iconName)),
    el("div", { class: "afw-meta" },
      el("span", { class: "afw-name", text: name }),
      el("span", { class: "afw-sub", text: sub }),
    ),
  );

  const ctaItems = [
    cta("shared", tr(state, "sharedRefUpload"), tr(state, "sharedRefUploadSub"), "collections", tr(state, "sharedRefUploadTip")),
    cta("batch",  tr(state, "batchRefUpload"),  tr(state, "batchRefUploadSub"), "upload", tr(state, "batchRefUploadTip")),
    cta("repeat", tr(state, "repeatFirstPrompt"), tr(state, "repeatFirstPromptSub"), "replay", tr(state, "repeatFirstPromptTip")),
    mode === FLOW_MODES.textToImage
      ? cta("chain", tr(state, "continuityPrompt"), tr(state, "continuityPromptSub"), "linear_scale", tr(state, "continuityPromptTip"))
      : null,
    mode === FLOW_MODES.textToImage
      ? cta("chain_match", tr(state, "continuityPromptPlus"), tr(state, "continuityPromptPlusSub"), "hub", tr(state, "continuityPromptPlusTip"))
      : null,
    cta("match",  tr(state, "autoMatch"),        tr(state, "autoMatchSub"), "auto_fix_high", tr(state, "autoMatchTip")),
  ].filter(Boolean);
  const ctaGrid = el("div", { class: "afw-cta-grid" }, ...ctaItems);

  return el("div", { class: "afw-step-body" },
    videoSourceSection,
    tabs,
    el("p", { class: "afw-lede", text: refCopy }),
    mode === FLOW_MODES.videoToVideo ? null : el("div", { class: "afw-eyebrow" }, icon("auto_fix_high"), tr(state, "applyReferences")),
    mode === FLOW_MODES.videoToVideo ? null : ctaGrid,
    mode === FLOW_MODES.videoToVideo ? null : el("button", { id: "referenceUploadButton", class: "afw-big-upload", attrs: { type: "button" } },
      icon("upload"),
      el("span", { class: "afw-big-upload-copy" },
        el("strong", { text: activeCta === "batch" ? tr(state, "uploadBatch") : tr(state, "uploadReferences") }),
        el("small", { text: activeCta === "batch" ? tr(state, "uploadBatchHelp") : tr(state, "uploadReferencesHelp") }),
      ),
    ),
    mode === FLOW_MODES.videoToVideo ? null : el("label", { class: "afw-save-library-toggle", attrs: { for: "saveUploadedRefsToLibraryToggle" } },
      el("input", {
        id: "saveUploadedRefsToLibraryToggle",
        checked: state.control?.saveUploadsToLibrary === true,
        attrs: { type: "checkbox" },
        on: { change: (event) => dispatch({ control: { saveUploadsToLibrary: event.target.checked } }) }
      }),
      el("span", { text: tr(state, "saveUploadsToLibrary") })
    ),
    refLibRow,
    refStrip,
    mode === FLOW_MODES.imageToVideo ? buildFrameReferenceSlots(state) : null,
    el("div", { class: "afw-ref-actions" },
      el("button", { id: "refSelectAllBtn", class: "afw-back", attrs: { type: "button", disabled: refs.length ? null : "disabled" } }, icon("select_all"), tr(state, "selectAll")),
      activeRefIds.length ? el("button", { id: "clearSelectedRef", class: "afw-back", attrs: { type: "button" } }, icon("backspace"), tr(state, "clearActiveReferences")) : null,
      el("button", { id: "clearRefImagesBtn", class: "afw-back", attrs: { type: "button", disabled: refs.length ? null : "disabled" } }, icon("delete"), tr(state, "clearReferenceLibrary"))
    ),
  );
}

function buildSegmentTabs(state, items, activeKey, onSelect) {
  return el("div", { class: "afw-tabs afw-tabs-compact", attrs: { role: "tablist" } },
    items.map(([key, label]) => el("button", {
      class: `afw-tab${activeKey === key ? " active" : ""}`,
      attrs: { type: "button", role: "tab", "aria-selected": activeKey === key ? "true" : "false" },
      on: { click: (event) => { stopControlEvent(event); onSelect?.(key); } }
    }, label))
  );
}

function buildCharacterSourcesStepBody(state, dispatch, tabs) {
  const analysis = characterRunAnalysis(state);
  const refs = allReferenceItems(state);
  const savedCount = Array.isArray(state.characters?.savedMappings) ? state.characters.savedMappings.length : 0;
  const activeCount = analysis.intents.length;
  const estimatedBytes = analysis.intents.reduce((sum, intent) => sum + Number(intent.storage?.estimatedBytes || 0), 0);
  const voiceOptions = [["", tr(state, "characterVoiceNone")], ...(state.characters?.voiceCatalog?.voices || []).map((voice) => [voice.displayName, voice.displayName])];
  const setupPlan = buildCharacterSetupPlan(analysis.intents, {
    sources: state.control?.characterSources || {},
    savedMappings: state.characters?.savedMappings || []
  });
  const runner = state.control?.characterSetupRunner || {};
  const runnerStatus = runner.status
    ? `${runner.readyCount || setupPlan.counts.ready}/${runner.totalCount || setupPlan.counts.total} · ${runner.status}`
    : `${setupPlan.counts.ready}/${setupPlan.counts.total} · ${setupPlan.status}`;
  const setupCard = el("div", { class: `afw-character-setup-card${setupPlan.ready ? " is-ready" : " is-blocked"}` },
    el("div", { class: "afw-reflib-main" },
      el("div", { class: "afw-icn" }, icon(setupPlan.ready ? "check_circle" : "badge")),
      el("div", { class: "afw-meta" },
        el("span", { class: "afw-name", text: tr(state, "characterSetupRunnerTitle") }),
        el("span", { class: "afw-sub", text: runnerStatus })
      )
    ),
    el("button", { id: "verifyNativeCharactersButton", class: "afw-add-btn", attrs: { type: "button", disabled: analysis.intents.length ? null : "disabled" } },
      icon("sync"),
      el("span", { text: tr(state, "characterSetupRunnerCta") })
    )
  );
  const rows = el("div", { class: "afw-character-list" });
  if (!analysis.intents.length) {
    rows.appendChild(el("div", { class: "afw-character-empty", text: tr(state, "characterParseEmpty") }));
  } else {
    for (const intent of analysis.intents) {
      const source = state.control?.characterSources?.[intent.handle] || {};
      const sourceMode = source.sourceMode || intent.source?.mode || "generate_from_description";
      const selectedRefId = String(source.sourceRefId || "");
      const sourceMediaId = String(source.sourceMediaId || "");
      const nativeCharacterId = String(source.flowCharacterId || source.characterServerId || "");
      const sourcePicker = refs.length
        ? el("div", { class: "afw-character-source-picker" },
            refs.map((ref) => {
              const id = String(ref.id || "");
              const active = id && id === selectedRefId;
              return el("button", {
                class: `afw-character-source-thumb${active ? " active" : ""}`,
                data: { characterSourceRefHandle: intent.handle, characterSourceRefId: id },
                attrs: { type: "button", title: ref.title || ref.fileName || ref.name || id }
              },
                imageForRef(ref, "afw-character-source-img"),
                el("span", { text: ref.title || ref.fileName || ref.name || id })
              );
            })
          )
        : el("div", { class: "afw-character-source-empty", text: tr(state, "characterSourceNoImages") });
      const statusLabel = nativeCharacterId
        ? tr(state, "characterStatusReady")
        : selectedRefId || sourceMediaId
          ? tr(state, "characterStatusClassicMatchReady")
          : sourceMode === "generate_from_description"
          ? tr(state, "characterSourceFromDescription")
          : tr(state, "characterStatusNeedsCreation");
      rows.appendChild(el("div", { class: `afw-character-source-row${intent.voice?.mode === "unresolved" ? " is-error" : ""}` },
        el("div", { class: "afw-character-source-main" },
          el("strong", { text: `@${intent.handle}` }),
          el("span", { text: intent.displayName }),
          el("small", { text: intent.voice?.mode === "selected_flow_voice" ? intent.voice.flowVoiceName : intent.voice?.mode === "unresolved" ? tr(state, "characterVoiceBlocker") : tr(state, "characterVoiceNone") }),
        ),
        el("div", { class: "afw-character-source-controls" },
          compactSelect(`characterSource:${intent.handle}:sourceMode`, sourceMode, [
            ["generate_from_description", tr(state, "characterSourceGenerate")],
            ["reference_library", tr(state, "characterSourceReference")],
            ["existing_flow_character", tr(state, "characterSourceExisting")],
            ["saved_flow_character", tr(state, "characterSourceSaved")]
          ]),
          compactSelect(`characterSource:${intent.handle}:requestedVoice`, source.requestedVoice || intent.voice?.flowVoiceName || "", voiceOptions),
          el("span", { class: "afw-character-pill", text: statusLabel }),
          selectedRefId ? el("button", {
            class: "afw-character-source-clear",
            data: { characterSourceClear: intent.handle },
            attrs: { type: "button", title: tr(state, "clear") || "Clear" }
          }, icon("close")) : null
        ),
        el("div", { class: "afw-character-source-label" }, icon("image"), tr(state, "characterSourcePickImage")),
        sourcePicker
      ));
    }
  }
  const sourceUpload = el("div", { class: "afw-character-source-upload" },
    el("div", { class: "afw-reflib-main" },
      el("div", { class: "afw-icn" }, icon("add_photo_alternate")),
      el("div", { class: "afw-meta" },
        el("span", { class: "afw-name", text: tr(state, "characterSourceUploadCta") }),
        el("span", { class: "afw-sub", text: tr(state, "characterSourceUploadHelp") }),
      ),
    ),
    el("button", { id: "characterSourceUploadButton", class: "afw-add-btn", attrs: { type: "button" } },
      icon("upload"),
      el("span", { text: tr(state, "uploadReferences") })
    )
  );
  const storage = el("div", { class: "afw-character-storage" },
    el("div", { class: "afw-reflib-main" },
      el("div", { class: "afw-icn" }, icon("badge")),
      el("div", { class: "afw-meta" },
        el("span", { class: "afw-name", text: tr(state, "flowCharacterStorage") }),
        el("span", { class: "afw-sub", text: tr(state, "characterStorageStats", { saved: savedCount, size: formatBytes(estimatedBytes), active: activeCount }) }),
      ),
    ),
    el("label", { class: "afw-save-library-toggle" },
      el("input", {
        id: "storeCharactersInFlowToggle",
        checked: state.characters?.storeInFlow === true,
        attrs: { type: "checkbox" },
        on: { change: (event) => dispatch({ characters: { storeInFlow: event.target.checked } }) }
      }),
      el("span", { text: tr(state, "storeCharactersInFlow") })
    )
  );
  return el("div", { class: "afw-step-body" },
    tabs,
    el("p", { class: "afw-lede", text: tr(state, "characterSourceHelp") }),
    setupCard,
    sourceUpload,
    storage,
    rows,
  );
}

function emptyReferencePatch(refs = {}) {
  return {
    imagePromptRefs: "",
    styleRefRefs: "",
    omniRefRefs: "",
    startFrameRef: "",
    endFrameRef: "",
    ingredientsRefs: "",
    ...Object.fromEntries(Object.keys(refs || {}).map((key) => [key, ""]))
  };
}

function referenceLimitForMode(mode = "") {
  if (mode === FLOW_MODES.textToImage) return 10;
  if (mode === FLOW_MODES.ingredientsToVideo) return 3;
  if (mode === FLOW_MODES.imageToVideo) return 2;
  return 0;
}

function referencesPatchForMode(mode = "", ids = [], refs = {}) {
  const next = emptyReferencePatch(refs);
  const cleanIds = ids.map((id) => String(id || "").trim()).filter(Boolean);
  if (mode === FLOW_MODES.imageToVideo) {
    next.startFrameRef = cleanIds[0] || "";
    next.endFrameRef = cleanIds[1] || "";
    return next;
  }
  if (mode === FLOW_MODES.ingredientsToVideo) {
    next.ingredientsRefs = cleanIds.slice(0, 3).join("\n");
    return next;
  }
  if (mode === FLOW_MODES.textToImage) {
    next.imagePromptRefs = cleanIds.slice(0, 10).join("\n");
  }
  return next;
}

function applyModePatch(state = {}, modeKey = "shared") {
  const control = state.control || {};
  const currentBatch = Array.isArray(control.oneToOneBatchRefIds)
    ? control.oneToOneBatchRefIds.map((id) => String(id || "").trim()).filter(Boolean)
    : [];
  const ids = activeReferenceIdsForMode(state).slice(0, modeKey === "batch" ? 500 : referenceLimitForMode(control.mode));
  const base = {
    activeApplyMode: modeKey,
    promptRefMap: {}
  };
  if (modeKey === "batch") {
    return {
      ...base,
      oneToOneBatchRefIds: ids,
      references: emptyReferencePatch(control.references),
      presets: { mapLineRefs: true },
      promptMapOpen: true
    };
  }
  if (modeKey === "repeat") {
    return {
      ...base,
      oneToOneBatchRefIds: ids,
      references: emptyReferencePatch(control.references),
      presets: { mapLineRefs: true },
      promptMapOpen: true
    };
  }
  if (modeKey === "match") {
    return {
      ...base,
      oneToOneBatchRefIds: [],
      references: currentBatch.length ? referencesPatchForMode(control.mode, ids, control.references) : control.references,
      presets: { mapLineRefs: true },
      promptMapOpen: true
    };
  }
  if (modeKey === "chain") {
    return {
      ...base,
      oneToOneBatchRefIds: [],
      references: control.mode === FLOW_MODES.textToImage
        ? referencesPatchForMode(control.mode, ids, control.references)
        : (currentBatch.length ? referencesPatchForMode(control.mode, ids, control.references) : control.references),
      presets: { mapLineRefs: true, imageRepeatCount: 1 },
      promptMapOpen: false
    };
  }
  if (modeKey === "chain_match") {
    return {
      ...base,
      oneToOneBatchRefIds: [],
      references: control.mode === FLOW_MODES.textToImage
        ? referencesPatchForMode(control.mode, ids, control.references)
        : (currentBatch.length ? referencesPatchForMode(control.mode, ids, control.references) : control.references),
      presets: { mapLineRefs: true, imageRepeatCount: 1 },
      promptMapOpen: true
    };
  }
  return {
    ...base,
    oneToOneBatchRefIds: [],
    references: currentBatch.length ? referencesPatchForMode(control.mode, ids, control.references) : control.references
  };
}

function buildFrameReferenceSlots(state) {
  const refs = state.control?.references || {};
  const allRefs = allReferenceItems(state);
  const byId = (id) => allRefs.find((ref) => ref.id === id) || null;
  const slot = (role, titleKey, fallback, required) => {
    const id = idsFromValue(refs[role]).at(0) || "";
    const ref = byId(id);
    return el("div", { class: `afw-frame-slot${ref ? " filled" : ""}` },
      el("div", { class: "afw-frame-slot-preview" },
        ref ? imageForRef(ref, "afw-frame-slot-img") : icon(role === "startFrameRef" ? "first_page" : "last_page")
      ),
      el("div", { class: "afw-frame-slot-copy" },
        el("strong", { text: tr(state, titleKey) }),
        el("span", { text: ref ? (ref.title || ref.fileName || ref.name || ref.id || "") : fallback }),
      ),
      ref ? el("button", {
        class: "afw-frame-slot-clear",
        data: { refClear: role },
        attrs: { type: "button", title: tr(state, "clear") || "Clear" }
      }, icon("close")) : el("span", { class: `afw-frame-slot-badge${required ? " required" : ""}`, text: required ? "Required" : "Optional" })
    );
  };
  return el("div", { class: "afw-frame-slots" },
    slot("startFrameRef", "startFrame", "Select or upload the first frame.", true),
    slot("endFrameRef", "endFrame", "Optional final frame.", false)
  );
}

function imageForRef(ref, className) {
  const src = ref.imageUrl || ref.dataUrl || ref.mediaUrl || "";
  if (src) {
    return el("img", {
      class: className,
      attrs: { src, alt: ref.title || ref.fileName || ref.name || "", loading: "lazy" },
    });
  }
  return el("div", {
    class: className,
    attrs: { style: `background: ${paletteFor(ref.id || ref.name)};` },
    text: glyphFor(ref.name || ref.title || ref.fileName),
  });
}

function allReferenceItems(state) {
  const saved = Array.isArray(state.referenceLibrary?.savedItems) ? state.referenceLibrary.savedItems : [];
  const transient = Array.isArray(state.control?.transientReferenceItems) ? state.control.transientReferenceItems : [];
  const sourceVideo = Array.isArray(state.control?.sourceVideos) && state.control.sourceVideos.length
    ? state.control.sourceVideos
    : (state.control?.sourceVideo ? [state.control.sourceVideo] : []);
  const seen = new Set();
  return [...sourceVideo, ...transient, ...saved].filter((item) => {
    const id = String(item?.id || "");
    if (!id || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
}

function idsFromValue(value) {
  return String(value || "").split(/\s+/).map((id) => id.trim()).filter(Boolean);
}

function savedItemsForActiveReferenceIds(state) {
  const active = new Set(activeReferenceIdsForMode(state));
  return allReferenceItems(state).filter((item) => active.has(String(item?.id || "")) && !/^video\//i.test(String(item?.mimeType || "")));
}

function activeReferenceIdsForMode(state) {
  const refs = state.control?.references || {};
  const batch = Array.isArray(state.control?.oneToOneBatchRefIds) ? state.control.oneToOneBatchRefIds : [];
  if (batch.length) return batch.map((id) => String(id || "").trim()).filter(Boolean);
  if (state.control?.mode === FLOW_MODES.textToImage) {
    return [...idsFromValue(refs.imagePromptRefs), ...idsFromValue(refs.styleRefRefs), ...idsFromValue(refs.omniRefRefs)];
  }
  if (state.control?.mode === FLOW_MODES.ingredientsToVideo) {
    return idsFromValue(refs.ingredientsRefs);
  }
  if (state.control?.mode === FLOW_MODES.imageToVideo) {
    return [...idsFromValue(refs.startFrameRef), ...idsFromValue(refs.endFrameRef)];
  }
  if (state.control?.mode === FLOW_MODES.videoToVideo) {
    return idsFromValue(refs.imagePromptRefs).slice(0, 5);
  }
  return [];
}

function formatBytes(n) {
  if (!n) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

// ── Step 3: Review & Run ──────────────────────────────────
function buildStep3Body(state, prompts, refs, mode, dispatch = () => {}) {
  const promptRefMap = state.control?.promptRefMap || {};
  void promptRefMap;
  const activeMappingTab = state.control?.runMappingTab === "character_mapping" ? "character_mapping" : "prompt_mapping";
  const mappingTabs = buildSegmentTabs(state, [
    ["prompt_mapping", tr(state, "promptMapping")],
    ["character_mapping", tr(state, "characterMapping")]
  ], activeMappingTab, (value) => dispatch({ control: { runMappingTab: value } }));

  const pairList = el("div", { class: "afw-pair-list" });
  if (prompts.length === 0) {
    pairList.appendChild(el("div", { class: "afw-pair-row" },
      el("div", { class: "afw-idx", text: "—" }),
      el("div", { class: "afw-text", text: tr(state, "noPromptsToRun") }),
      el("div", { class: "afw-refs" }),
    ));
  } else {
    prompts.forEach((p, i) => {
      const refIds = effectiveRefIdsForPrompt(state, p, i, prompts.length);
      const refsEl = el("div", { class: "afw-refs" });
      const shown = refIds.slice(0, 3);
      for (const rid of shown) {
        if (rid === "__af_previous_output__") {
          refsEl.appendChild(el("span", { class: "afw-no-ref afw-prev-output-ref", text: tr(state, "previousOutputRef") }));
          continue;
        }
        const r = refs.find((x) => x.id === rid);
        const thumb = r
          ? imageForRef(r, "afw-ref-mini-img")
          : el("div", { class: "afw-ref-mini-fallback", attrs: { style: `background: ${paletteFor(rid)};` }, text: glyphFor(rid) });
        refsEl.appendChild(el("div", {
          class: "afw-ref-mini",
          attrs: { title: r?.name || r?.title || r?.fileName || rid },
        }, thumb));
      }
      if (refIds.length > 3) {
        refsEl.appendChild(el("span", { class: "afw-no-ref", attrs: { style: "color:var(--afw-text-soft); background:transparent; border:0;" }, text: `+${refIds.length - 3}` }));
      }
      if (refIds.length === 0) {
        refsEl.appendChild(el("span", { class: "afw-no-ref", text: tr(state, "noRef") }));
      }
      pairList.appendChild(el("div", { class: "afw-pair-row", attrs: { title: p } },
        el("div", { class: "afw-idx", text: pad2(i + 1) }),
        el("div", { class: "afw-text", text: p }),
        refsEl,
      ));
    });
  }
  const characterMappingList = buildCharacterMappingList(state, prompts);

  const presets = state.control?.presets || {};
  const modelKey = mode.defaultModelKey;
  const aspectKey = mode.defaultAspectKey;
  const countKey = mode.defaultCountKey;
  const dlResKey = mode.defaultDownloadResKey;
  const dl = presets[dlResKey] || (mode.key === FLOW_MODES.textToImage ? "1k" : "720p");
  const autoDownloadOn = mode.key === FLOW_MODES.textToImage ? presets.autoDownloadImages !== false : presets.autoDownload !== false;

  const valSelect = (settingKey, value, options, selectOptions = {}) => el("select", {
    class: "afw-val-btn",
    data: { settingKey },
    attrs: {
      disabled: Boolean(selectOptions.disabled),
      "aria-disabled": Boolean(selectOptions.disabled)
    }
  },
    options.map(([optionValue, label]) => el("option", {
      text: label,
      attrs: { value: optionValue, selected: String(value) === String(optionValue) }
    }))
  );
  const modelOptions = mode.key === FLOW_MODES.textToImage
    ? ["nano_banana_pro", "nano_banana_2", "nano_banana_2_lite"].map((key) => [key, formatModelLabel(key)])
    : mode.key === FLOW_MODES.videoToVideo
      ? [["omni_flash", "Omni Flash"]]
    : mode.key === FLOW_MODES.ingredientsToVideo
      ? INGREDIENTS_VIDEO_MODEL_OPTIONS
      : mode.key === FLOW_MODES.textToVideo
        ? TEXT_VIDEO_MODEL_OPTIONS
        : VIDEO_MODEL_OPTIONS;
  const selectedModel = presets[modelKey];
  const aspectOptions = mode.key === FLOW_MODES.textToImage
    ? [["portrait", tr(state, "portrait")], ["square", tr(state, "square")], ["landscape", tr(state, "landscape")], ["portrait_3_4", "3:4"], ["landscape_4_3", "4:3"]]
    : [["portrait", tr(state, "portrait")], ["landscape", tr(state, "landscape")]];
  const countOptions = [["1", "x1"], ["2", "x2"], ["3", "x3"], ["4", "x4"]];
  const continuityMode = mode.key === FLOW_MODES.textToImage
    && (state.control?.activeApplyMode === "chain" || state.control?.activeApplyMode === "chain_match");
  const singleOutputMode = continuityMode || mode.key === FLOW_MODES.videoToVideo;
  const downloadOptions = mode.key === FLOW_MODES.textToImage
    ? [["1k", "1K"], ["2k", "2K"], ["4k", "4K"]]
    : [["720p", "720p"], ["1080p", "1080p"], ["4k", "4K"]];
  const routeOptions = mode.key === FLOW_MODES.videoToVideo
    ? [["agent_first", "Agent"], ["api_first", "Omni API"]]
    : [["api_first", "API"], ["agent_first", "Agent"], ["dom_first", "DOM"]];
  const silentVideoOptions = [["true", tr(state, "on")], ["false", tr(state, "off")]];
  const baseDurationOptions = [["4", "4s"], ["6", "6s"], ["8", "8s"]];
  const omniDurationOptions = [...baseDurationOptions, ["10", "10s"]];
  const durationOptions = mode.key === FLOW_MODES.ingredientsToVideo
    ? (isOmniVideoModel(presets.ingredientsModel) ? omniDurationOptions : [["8", "8s"]])
    : ((mode.key === FLOW_MODES.textToVideo || mode.key === FLOW_MODES.imageToVideo) && isOmniVideoModel(presets.model) ? omniDurationOptions : baseDurationOptions);
  const row = (iconName, label, sub, valNode, rowOptions = {}) => el("div", { class: `afw-gen-row${rowOptions.disabled ? " is-disabled" : ""}` },
    el("div", { class: "afw-icn-wrap" }, icon(iconName)),
    el("div", { class: "afw-label-stack" },
      el("div", { class: "afw-label" }, label, el("span", { class: "afw-default-tag", text: tr(state, "defaultLabel") })),
      el("div", { class: "afw-sub", text: sub }),
    ),
    valNode,
  );
  // Read directly from state.control.presets (already normalized by
  // normalizePresets, which preserves any valid stored value the user
  // saved). NO view-level "|| 'portrait'" fallbacks: those would override
  // the user's last-saved choice with a hardcoded preference. Per user
  // direction: 'shouldnt default to anything other than the settings the
  // user leaves it on.'
  const autopilotOptions = autopilotPipelineOptions(state);
  const autopilotReady = mode.key === FLOW_MODES.textToImage && promptsHaveAutopilotVideoPrompts(prompts);
  // These three settings materially change the requested outputs, so keep them
  // available as consistent per-run overrides and serialize them into the Agent
  // contract. Credit automation remains internal and is not shown here.
  const settingsCard = el("div", { class: "afw-gen-card" },
    row("tune", tr(state, "model"), tr(state, "modeModelList", { mode: modeName(state, mode) }), valSelect(modelKey, selectedModel, modelOptions)),
    row("aspect_ratio", tr(state, "aspectRatio"), tr(state, "outputFrame"), valSelect(aspectKey, presets[aspectKey], aspectOptions)),
    row(
      "repeat",
      tr(state, "generationsPerPrompt"),
      continuityMode ? tr(state, "continuityCountHelp") : mode.key === FLOW_MODES.videoToVideo ? tr(state, "videoToVideoSingleOutputHelp") : tr(state, "moreOptionsToPick"),
      valSelect(countKey, singleOutputMode ? "1" : presets[countKey], countOptions, { disabled: singleOutputMode }),
      { disabled: singleOutputMode }
    ),
    mode.key !== FLOW_MODES.textToImage && mode.key !== FLOW_MODES.videoToVideo && (mode.key !== FLOW_MODES.ingredientsToVideo || durationOptions.length > 1)
      ? row("timer", tr(state, "videoLength"), tr(state, "videoLengthHelp"), valSelect("videoLength", presets.videoLength, durationOptions))
      : null,
    mode.key !== FLOW_MODES.textToImage
      ? row("volume_off", tr(state, "returnSilentVideos"), tr(state, "returnSilentVideosHelp"), valSelect("returnSilentVideos", presets.returnSilentVideos !== false ? "true" : "false", silentVideoOptions))
      : null,
    row("download", tr(state, "autoDownload"), autoDownloadOn ? tr(state, "savesToDownloads") : tr(state, "reviewInGalleryFirst"), valSelect(dlResKey, dl, downloadOptions)),
    row("verified_user", tr(state, "submitRoute"), tr(state, "submitRouteHelp"), valSelect("submitPath", presets.submitPath, routeOptions)),
    // Credit-dialog automation is internal run policy, not a user-facing
    // generation setting. Known amounts continue for an explicit user run;
    // unknown amounts and persistent approval still fail closed.
    // T2I autopilot: animate generated images via Frame-to-Video after the
    // T2I run finishes. Only visible in textToImage mode — other modes
    // already produce video. See issue #208.
    mode.key === FLOW_MODES.textToImage
      ? row(
          "auto_awesome",
          tr(state, "autopilotLabel"),
          autopilotReady ? tr(state, "autopilotHelp") : tr(state, "autopilotDisabledHelp"),
          valSelect("autopilotT2IToF2V", autopilotReady ? (presets.autopilotT2IToF2V || "off") : "off", autopilotOptions, { disabled: !autopilotReady }),
          { disabled: !autopilotReady }
        )
      : null,
  );

  const isVideo = String(mode.key || "").endsWith("video");
  const sourceVideoCount = mode.key === FLOW_MODES.videoToVideo
    ? Math.max(1, Number(state.control?.sourceVideos?.length || (state.control?.sourceVideo ? 1 : 0)))
    : 0;
  const count = mode.key === FLOW_MODES.videoToVideo ? 1 : Number(presets[countKey] || 4);
  const out = mode.key === FLOW_MODES.videoToVideo ? sourceVideoCount : prompts.length * count;
  const min = Math.max(1, Math.round((mode.key === FLOW_MODES.videoToVideo ? sourceVideoCount : prompts.length) * (isVideo ? 1.4 : 0.5)));
  const estimate = el("div", { class: "afw-estimate" },
    el("div", { class: "afw-est-row" },
      el("span", { text: tr(state, "estimatedRuntime") }),
      el("b", { text: tr(state, "runtimeMinutes", { count: min }) }),
    ),
    el("div", { class: "afw-est-row" },
      el("span", { text: isVideo ? tr(state, "videosToGenerate") : tr(state, "imagesToGenerate") }),
      el("b", { text: String(out) }),
    ),
  );

  return el("div", { class: "afw-step-body" },
    el("p", { class: "afw-lede", text: tr(state, "reviewRunHelp") }),
    mappingTabs,
    el("div", { class: "afw-eyebrow" }, icon("checklist"), activeMappingTab === "character_mapping" ? tr(state, "characterMapping") : tr(state, "promptsToReferences"),
      el("span", { class: "afw-right" }, el("b", { text: String(prompts.length) }), ` ${tr(state, "total")}`),
    ),
    activeMappingTab === "character_mapping" ? characterMappingList : pairList,
    el("div", { class: "afw-eyebrow", attrs: { style: "margin-top:6px;" } }, icon("settings"), tr(state, "generation"),
      el("span", { class: "afw-right", text: tr(state, "settingsOverrideHere") }),
    ),
    settingsCard,
    estimate,
  );
}

function buildAgentModeDocsCard(state) {
  const translatedFormat = tr(state, "agentModeFormatBlock");
  const formatBlock = translatedFormat && translatedFormat !== "[agentModeFormatBlock]"
    ? translatedFormat
    : AGENT_MODE_FORMAT_BLOCK;
  const bulletKeys = [
    "agentModeDocsRowBullet",
    "agentModeDocsAfidBullet",
    "agentModeDocsBriefBullet",
    "agentModeDocsQaBullet"
  ];
  return el("div", { class: "afw-agent-doc-card" },
    el("div", { class: "afw-agent-doc-head" },
      el("div", null,
        el("div", { class: "afw-agent-doc-kicker", text: tr(state, "duckGuide") }),
        el("h3", { text: tr(state, "agentModeDocsTitle") }),
        el("p", { text: tr(state, "agentModeDocsIntro") })
      ),
      el("button", {
        class: "afw-agent-doc-copy",
        attrs: { type: "button", title: tr(state, "agentModeFormatLabel") },
        data: { copyAgentFormat: "1" }
      }, icon("content_copy"), el("span", { text: tr(state, "agentModeFormatLabel") }))
    ),
    el("ul", { class: "afw-agent-doc-list" },
      bulletKeys.map((key) => el("li", { text: tr(state, key) }))
    ),
    el("pre", { class: "afw-agent-format-block" },
      el("code", { text: formatBlock })
    )
  );
}

function buildAgentModeBridgeCard(state) {
  const bridge = agentBridgeStatus(state);
  const agentMode = state.control?.agentMode || {};
  const enabled = agentMode.bridgeEnabled === true;
  return el("div", { class: `afw-agent-bridge-card${enabled ? " active" : ""}` },
    el("div", { class: "afw-agent-bridge-main" },
      el("div", { class: "afw-agent-icon" }, icon("lan")),
      el("div", { class: "afw-agent-copy" },
        el("div", { class: "afw-agent-title" },
          el("span", { text: tr(state, "agentModeBridgeControls") }),
          el("span", { class: `afw-bridge-pill ${bridge.className}`, attrs: { title: bridge.title, "data-bridge-state": bridge.className.replace(/^is-/, "") } },
            el("span", { class: "afw-bridge-dot" }),
            el("span", { class: "afw-bridge-label", text: bridge.label })
          )
        ),
        el("div", { class: "afw-agent-help", text: tr(state, "agentModeBridgeControlsHelp") })
      )
    ),
    el("div", { class: "afw-agent-bridge-actions" },
      el("button", {
        class: "afw-agent-toggle",
        attrs: { type: "button", "aria-pressed": enabled ? "true" : "false" },
        data: { agentBridgeAction: "enable" }
      }, icon(enabled ? "toggle_on" : "toggle_off"), enabled ? tr(state, "agentModeBridgeEnabled") : tr(state, "agentModeEnableBridge")),
      el("button", {
        class: "afw-agent-toggle",
        attrs: { type: "button", title: tr(state, "agentModePairingHelp") },
        data: { agentBridgeAction: "pair" }
      }, icon("link"), tr(state, "agentModePairBridge"))
    )
  );
}

function buildAgentModePromptHelperCard(state) {
  const agentMode = state.control?.agentMode || {};
  return el("div", { class: "afw-agent-helper-card" },
    el("div", { class: "afw-agent-helper-head" },
      el("div", null,
        el("div", { class: "afw-agent-doc-kicker", text: tr(state, "agentModePromptHelper") }),
        el("h3", { text: tr(state, "agentModeDocsTitle") })
      ),
      el("div", { class: "afw-agent-helper-actions" },
        el("button", {
          class: "afw-agent-doc-copy",
          attrs: { type: "button", title: tr(state, "agentModeCopyMasterPrompt") },
          data: { agentCopyMasterPrompt: "1" }
        }, icon("content_copy"), el("span", { text: tr(state, "agentModeCopyMasterPrompt") })),
        el("button", {
          class: "afw-agent-doc-copy",
          attrs: { type: "button", title: tr(state, "agentModeBuildMatrix") },
          data: { agentBuildMatrix: "1" }
        }, icon("table"), el("span", { text: tr(state, "agentModeBuildMatrix") }))
      )
    ),
    el("div", { class: "afw-agent-helper-grid" },
      el("label", { class: "afw-agent-helper-field" },
        el("span", { text: tr(state, "agentModeAgentInstructions") }),
        el("textarea", {
          value: agentMode.agentInstructions || "",
          data: { settingKey: "agentMode:agentInstructions" },
          attrs: { rows: "4", placeholder: tr(state, "agentModeAgentInstructionsPlaceholder") }
        })
      ),
      el("label", { class: "afw-agent-helper-field" },
        el("span", { text: tr(state, "agentModeProjectBrief") }),
        el("textarea", {
          value: agentMode.projectBrief || "",
          data: { settingKey: "agentMode:projectBrief" },
          attrs: { rows: "4", placeholder: tr(state, "agentModeProjectBriefPlaceholder") }
        })
      )
    )
  );
}

function buildAgentModeDownloadPlanCard(state, prompts = [], mode = {}, autoDownloadOn = false) {
  const agentMode = state.control?.agentMode || {};
  const run = state.control?.agentRun || {};
  const presets = state.control?.presets || {};
  const isImageMode = mode.key === FLOW_MODES.textToImage;
  const countKey = mode.defaultCountKey || (isImageMode ? "imageRepeatCount" : "repeatCount");
  const count = Number(presets[countKey] || 1) || 1;
  const expectedImages = isImageMode ? prompts.length * count : 0;
  const expectedVideos = isImageMode ? 0 : prompts.length * count;
  const monitorOn = agentMode.downloadMonitorEnabled !== false;
  const folder = run.downloadPlan?.folder || run.artifactPlan?.runFolder || run.downloadFolder || presets.downloadFolder || "Auto-Flow";
  return el("div", { class: `afw-agent-download-card${monitorOn && autoDownloadOn ? " active" : ""}` },
    el("div", { class: "afw-agent-download-copy" },
      el("div", { class: "afw-agent-doc-kicker", text: tr(state, "agentModeDownloadPlan") }),
      el("h3", { text: tr(state, "agentModeAutoDownloadMonitor") }),
      el("p", { text: tr(state, "agentModeDownloadPlanHelp") })
    ),
    el("div", { class: "afw-agent-download-stats" },
      agentDownloadStat(state, "agentDownloadFolderLabel", folder),
      agentDownloadStat(state, "agentExpectedImages", expectedImages || run.expectedImages || 0),
      agentDownloadStat(state, "agentExpectedVideos", expectedVideos || run.expectedVideos || 0),
      agentDownloadStat(state, "agentDownloadSeenLabel", run.lastSeenFreshOutputs ?? run.lastSeenFreshVideos ?? 0)
    ),
    el("div", { class: "afw-agent-download-actions" },
      el("label", { class: "afw-agent-monitor-toggle" },
        el("input", {
          checked: monitorOn,
          data: { settingKey: "agentMode:downloadMonitorEnabled" },
          attrs: { type: "checkbox" }
        }),
        el("span", { text: monitorOn ? tr(state, "agentModeDownloadMonitorOn") : tr(state, "agentModeDownloadMonitorOff") })
      ),
      el("button", {
        class: "afw-agent-toggle",
        attrs: { type: "button" },
        data: { agentOpenLive: "1" }
      }, icon("list_alt"), tr(state, "agentModeOpenLiveQueue"))
    )
  );
}

function agentDownloadStat(state, labelKey, value) {
  return el("span", { class: "afw-agent-download-stat" },
    el("small", { text: tr(state, labelKey) }),
    el("b", { text: String(value) })
  );
}

function buildCharacterMappingList(state, prompts = []) {
  const analysis = characterRunAnalysis(state, prompts);
  const list = el("div", { class: "afw-pair-list afw-character-map-list" });
  if (!analysis.intents.length) {
    list.appendChild(el("div", { class: "afw-pair-row" },
      el("div", { class: "afw-idx", text: "@" }),
      el("div", { class: "afw-text", text: tr(state, "characterParseEmpty") }),
      el("div", { class: "afw-refs" }),
    ));
    return list;
  }
  for (const intent of analysis.intents) {
    const usedScenes = (analysis.scenes || [])
      .filter((scene) => scene.requiredCharacters?.includes(intent.handle))
      .map((scene) => pad2(Number(scene.promptIndex || 0) + 1));
    const voice = intent.voice?.mode === "selected_flow_voice"
      ? intent.voice.flowVoiceName
      : intent.voice?.mode === "unresolved"
        ? tr(state, "characterVoiceBlocker")
        : tr(state, "characterVoiceNone");
    const source = state.control?.characterSources?.[intent.handle] || {};
    const nativeCharacterId = String(source.flowCharacterId || source.characterServerId || "");
    const hasClassicSource = Boolean(source.sourceRefId || source.sourceMediaId);
    const status = nativeCharacterId
      ? tr(state, "characterStatusReady")
      : hasClassicSource
        ? tr(state, "characterStatusClassicMatchReady")
      : intent.voice?.mode === "unresolved"
        ? tr(state, "characterStatusFailed")
        : tr(state, "characterStatusNeedsCreation");
    list.appendChild(el("div", { class: `afw-pair-row afw-character-map-row${intent.voice?.mode === "unresolved" ? " is-error" : ""}` },
      el("div", { class: "afw-idx", text: `@${intent.handle}` }),
      el("div", { class: "afw-text", text: `${intent.displayName} · ${voice} · ${source.sourceMode || "generate_from_description"}` }),
      el("div", { class: "afw-refs" },
        usedScenes.length ? el("span", { class: "afw-character-pill", text: usedScenes.join(", ") }) : el("span", { class: "afw-no-ref", text: "unused" }),
        el("span", { class: "afw-character-pill", text: status }),
      ),
    ));
  }
  for (const error of analysis.errors || []) {
    list.appendChild(el("div", { class: "afw-pair-row afw-character-map-row is-error" },
      el("div", { class: "afw-idx", text: error.handle ? `@${error.handle}` : "!" }),
      el("div", { class: "afw-text", text: error.message || error.code }),
      el("div", { class: "afw-refs" }, el("span", { class: "afw-no-ref", text: tr(state, "error") })),
    ));
  }
  return list;
}

function promptMapKey(_prompt, index) {
  return `line:${index}`;
}

function effectiveRefIdsForPrompt(state, prompt, index, totalPrompts) {
  if (state.control?.mode === FLOW_MODES.textToImage && state.control?.activeApplyMode === "chain" && index > 0) {
    return ["__af_previous_output__"];
  }
  const sourceIds = activeReferenceIdsForMode(state);
  const map = state.control?.promptRefMap || {};
  const key = promptMapKey(prompt, index);
  if (Object.prototype.hasOwnProperty.call(map, key)) {
    return Array.isArray(map[key]) ? map[key].filter((id) => sourceIds.includes(id)) : [];
  }
  if (state.control?.activeApplyMode === "match" || state.control?.activeApplyMode === "chain_match") {
    const limit = state.control?.mode === FLOW_MODES.textToImage && state.control?.activeApplyMode === "chain_match" && index > 0
      ? Math.max(0, referenceLimitForMode(state.control.mode) - 1)
      : referenceLimitForMode(state.control?.mode);
    const matched = matchedReferenceIdsForPrompt(
      prompt,
      allReferenceItems(state).filter((item) => sourceIds.includes(item.id)),
      { limit }
    );
    return state.control?.mode === FLOW_MODES.textToImage && state.control?.activeApplyMode === "chain_match" && index > 0
      ? ["__af_previous_output__", ...matched]
      : matched;
  }
  const batch = Array.isArray(state.control?.oneToOneBatchRefIds)
    ? state.control.oneToOneBatchRefIds.map((id) => String(id || "").trim()).filter(Boolean)
    : [];
  if (batch.length) {
    if (state.control?.mode === FLOW_MODES.imageToVideo && batch.length >= totalPrompts * 2) {
      return [batch[index] || "", batch[index + totalPrompts] || ""].filter(Boolean);
    }
    return batch[index] ? [batch[index]] : [];
  }
  return sourceIds;
}

function buildStepNav(state, currentStep, mode, promptCount, presets, dispatch) {
  // Bottom strip is now just a centered step summary. Back moved up to the
  // step header (afw-step-actions). History moved up next to Next via
  // buildHistoryJump. The bottom row exists only to remind the user where
  // they are in the flow.
  const isVideo = String(mode.key || "").endsWith("video");
  const count = Number(presets?.[mode.defaultCountKey] || 4);
  const summary = currentStep === 3
    ? tr(state, "summaryOutputs", { prompts: promptCount, outputs: promptCount * count, media: isVideo ? tr(state, "videos") : tr(state, "images") })
    : tr(state, "summaryStep", { step: currentStep, mode: modeName(state, mode) });
  return el("div", { class: "afw-step-nav" },
    el("div", { class: "afw-step-summary", text: summary }),
  );
}
