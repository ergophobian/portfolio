import { readPrivacyConsent } from "../core/privacy/consent.js";

const consent = await readPrivacyConsent(chrome.storage.local);
if (!consent.accepted) {
  window.location.replace(chrome.runtime.getURL("src/gateway/gateway.html"));
} else {
  await import("./app.js");
}
