import { normalizeSceneClip, totalSceneDuration } from "../core/gallery/scene-builder.js";

export const PRODUCT_NAME = "Auto Flow";
export const STORAGE_KEY = "autoflow-10767-rebuild-sidepanel-state";

const VIDEO_MODEL_KEYS = Object.freeze([
  "omni_flash",
  "default",
  "veo3_lite",
  "veo3_lite_low",
  "veo3_fast",
  "veo3_fast_low",
  "veo3_quality"
]);

const INGREDIENTS_VIDEO_MODEL_KEYS = Object.freeze([
  "omni_flash",
  "veo3_fast_low",
  "veo3_fast"
]);

const SUBMIT_PATH_KEYS = Object.freeze([
  "dom_first",
  "api_first",
  "agent_first"
]);

export const FLOW_MODES = Object.freeze({
  textToImage: "text-to-image",
  textToVideo: "text-to-video",
  imageToVideo: "image-to-video",
  ingredientsToVideo: "ingredients-to-video",
  videoToVideo: "video-to-video"
});

export function createDefaultState(now = new Date().toISOString()) {
  return {
    version: 6,
    seededAt: now,
    ui: {
      activeRoute: "control",
      galleryTab: "images",
      galleryScope: "all",
      galleryViewMode: "grid",
      gallerySize: "small",
      gallerySortOrder: "num-asc",
      videoSpeed: "1",
      videoVolume: "0.05",
      selectedGalleryIds: [],
      galleryDownloadFeedback: {
        status: "idle",
        requestedResolution: "",
        deliveredResolution: "",
        unavailableResolution: "",
        completed: 0,
        total: 0,
        error: ""
      },
      deleteMarkedGalleryIds: [],
      dismissedRecoveryTaskIds: [],
      agentLiveQueueTab: "videos",
      openInlineHelpPanel: "",
      galleryHelpKey: "",
      helpOpen: false,
      activeHelpTopic: "text_to_video",
      walkthrough: null
    },
    runtime: {
      connected: false,
      activeTabId: null,
      projectId: "",
      pageUrl: "",
      pageTitle: "",
      bridgeHealthy: false,
      bridgeDegraded: false,
      bridgeVersion: "",
      pageHookVersion: "",
      pageHookInstalled: false,
      hasNativeFetch: false,
      flowPageBlocked: false,
      flowPageIssue: null,
      bridgeError: null,
      agentBridge: {
        enabled: false,
        connected: false,
        reconnecting: false,
        hostName: "",
        reconnectDelayMs: 0
      },
      error: null,
      lastSyncAt: null
    },
    control: {
      mode: FLOW_MODES.imageToVideo,
      livePrompt: "",
      characterPromptText: "",
      packetNotes: "",
      packetImport: {
        open: false,
        rawText: "",
        lastAppliedAt: "",
        lastStatus: ""
      },
      characterSetupRunner: {
        runId: "",
        status: "",
        startedAt: "",
        completedAt: "",
        readyCount: 0,
        totalCount: 0,
        blockers: [],
        proof: null
      },
      promptTab: "workflow_prompts",
      referencesTab: "prompt_references",
      runMappingTab: "prompt_mapping",
      wizardStep: 1,
      lastRunError: "",
      promptMapOpen: false,
      promptMapFullscreen: false,
      promptRefMap: {},
      oneToOneBatchRefIds: [],
      transientReferenceItems: [],
      saveUploadsToLibrary: false,
      sourceVideo: null,
      sourceVideos: [],
      videoEdit: {
        reusePromptForAll: true,
        engine: "agent_first",
        uploadConcurrency: 2,
        persistentReferenceIds: []
      },
      characterSources: {},
      autopilotPendingBatch: null,
      agentMode: {
        bridgeEnabled: false,
        agentInstructions: "",
        projectBrief: "",
        downloadMonitorEnabled: false,
        creditApproval: "ask_each_time",
        maxCreditsPerRun: 0,
        persistentCreditApproval: false,
        autoApproveFreeCredits: true,
        lastMasterPrompt: "",
        lastMasterPromptAt: "",
        bridgePairingApprovalRequestedAt: "",
        bridgePairingApprovalExpiresAt: "",
        bridgePairingApprovalUsedAt: "",
        bridgePairingApprovalClientId: "",
        directPendingClient: {},
        directApprovedClient: {}
      },
      agentRun: {
        id: "",
        status: "",
        projectId: "",
        startedAt: "",
        completedAt: "",
        rows: [],
        pendingRetry: null,
        retryRequests: [],
        autoDownload: false,
        downloadFolder: "Auto-Flow",
        downloadPlan: null,
        artifactPlan: null,
        downloadedMediaIds: [],
        failedDownloadMediaIds: [],
        selectedIds: [],
        selectedMediaIds: []
      },
      references: {
        imagePromptRefs: "",
        styleRefRefs: "",
        omniRefRefs: "",
        startFrameRef: "",
        endFrameRef: "",
        ingredientsRefs: ""
      },
      presets: {
        submitPath: "agent_first",
        submitPathPreference: "agent_first",
        videoLength: "8",
        aspectRatio: "portrait",
        imageAspectRatio: "portrait",
        model: "default",
        ingredientsModel: "omni_flash",
        imageModel: "nano_banana_pro",
        returnSilentVideos: true,
        repeatCount: 4,
        imageRepeatCount: 4,
        startFrom: 1,
        safeRefAttachMode: true,
        overnight403Recovery: false,
        minInitialWaitTime: 20,
        maxInitialWaitTime: 40,
        recaptchaCooldownSmallThreshold: 15,
        recaptchaCooldownSmallWait: 30,
        recaptchaCooldownLargeThreshold: 30,
        recaptchaCooldownLargeWait: 60,
        autoDownload: true,
        autoDownloadImages: true,
        videoDownloadResolution: "720p",
        videoDownloadMethodPreference: "auto",
        imageAutoDownloadResolution: "1k",
        imageDownloadMethodPreference: "auto",
        downloadFolder: "Auto-Flow",
        autoNumberFolder: true,
        downloadFolderRunIndex: 0,
        downloadFolderLastBase: "Auto-Flow",
        t2iSubmitMode: "safe_serial",
        t2iBatchSize: 2,
        filenameStyle: "detailed",
        filenameTemplatePrefix: "",
        filenameTemplateIndex: "nn",
        filenameTemplatePromptPart: "first_3_words",
        filenameTemplateDate: "none",
        filenameTemplateSuffix: "none",
        filenameTemplateSeparator: "_",
        language: "en",
        mapLineRefs: true,
        autoStartNextJob: true,
        autoRetryFailedUntilZero: false,
        autopilotT2IToF2V: "off"
      }
    },
    queue: {
      running: false,
      paused: false,
      items: [],
      runtimeEvents: [],
      authRefresh: null
    },
    gallery: {
      items: [],
      deletedIds: [],
      meta: {
        source: "not_synced",
        fetchedAt: null
      }
    },
    scenes: {
      clips: [],
      audioName: "",
      selectedClipIds: [],
      totalDuration: 0,
      updatedAt: null
    },
    referenceLibrary: {
      savedItems: [],
      lastSyncedAt: null
    },
    characters: {
      storeInFlow: false,
      voiceCatalog: {
        capturedAt: "",
        accountTier: "",
        voiceCount: 0,
        voices: [],
        catalogHash: ""
      },
      assets: [],
      savedMappings: []
    },
    history: {
      runs: []
    },
    settings: {
      persistLogs: true,
      requireFlowTab: true,
      debugCapture: false
    },
    account: {
      status: "unknown",
      email: null,
      userId: null,
      plan: "free",
      rawPlan: "free",
      subscriptionStatus: "inactive",
      stripeSubscriptionStatus: null,
      supabaseSubscriptionStatus: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: null,
      billingHealth: "unknown",
      billing: {
        health: "unknown",
        lastWebhookEventAt: null,
        lastBillingSyncAt: null,
        stripeCustomerMapped: null,
        mismatchReason: null
      },
      usage: {
        allowed: false,
        unlimited: false,
        limit: 10,
        used: 0,
        remaining: 10,
        resetAt: null
      },
      pendingCheckout: false,
      otpCode: "",
      message: null,
      error: null,
      authGateShown: false,
      authGateReason: "",
      authGateBlockingRecovery: false,
      authCodeRequestedAt: null,
      authCodeRequestError: null,
      authCodeRateLimited: false,
      authCodeResendAvailableAt: null,
      lastKnownAccountStatus: "unknown",
      lastKnownBillingHealth: "unknown",
      degradedLocalMode: false,
      authRefresh: null,
      supportExportAllowedWhileSignedOut: true,
      supportCopyAllowedWhileSignedOut: true,
      queueControlsAllowedWhileAuthPending: true,
      lastCheckedAt: null
    },
    logs: {
      items: [
        {
          id: "log-bootstrap",
          level: "info",
          scope: "bootstrap",
          message: `${PRODUCT_NAME} initialized.`,
          createdAt: now
        }
      ]
    },
    login: {
      status: "unknown",
      provider: "flow",
      lastCheckedAt: null,
      email: null,
      userId: null,
      providers: [],
      moodboards: []
    }
  };
}

export function mergeState(base, incoming) {
  if (!incoming || typeof incoming !== "object") return structuredClone(base);
  const output = deepMerge(structuredClone(base), incoming);
  output.version = base.version;

  if (output.ui.activeRoute === "scenes") {
    output.ui.activeRoute = "mcp_cli";
  }
  if (!["control", "live", "gallery", "history", "settings", "logs", "mcp_cli"].includes(output.ui.activeRoute)) {
    output.ui.activeRoute = "control";
  }
  if (!["images", "videos"].includes(output.ui.galleryTab)) {
    output.ui.galleryTab = "images";
  }
  output.ui.galleryScope = "all";
  if (!["grid", "table", "live"].includes(output.ui.galleryViewMode)) {
    output.ui.galleryViewMode = "grid";
  }
  if (!["small", "medium"].includes(output.ui.gallerySize)) {
    output.ui.gallerySize = "small";
  }
  if (!["default", "num-asc", "num-desc", "az", "za"].includes(output.ui.gallerySortOrder)) {
    output.ui.gallerySortOrder = "num-asc";
  }
  output.ui.videoSpeed = String(output.ui.videoSpeed || "1");
  output.ui.videoVolume = String(output.ui.videoVolume || "0.05");
  output.ui.dismissedRecoveryTaskIds = normalizeIdArray(output.ui.dismissedRecoveryTaskIds || []).slice(-100);
  if (!Object.values(FLOW_MODES).includes(output.control.mode)) {
    output.control.mode = FLOW_MODES.imageToVideo;
  }

  output.control.livePrompt = String(output.control.livePrompt || "");
  output.control.characterPromptText = String(output.control.characterPromptText || "");
  output.control.promptTab = ["workflow_prompts", "character_prompts"].includes(output.control.promptTab)
    ? output.control.promptTab
    : "workflow_prompts";
  output.control.referencesTab = ["prompt_references", "character_sources"].includes(output.control.referencesTab)
    ? output.control.referencesTab
    : "prompt_references";
  output.control.runMappingTab = ["prompt_mapping", "character_mapping"].includes(output.control.runMappingTab)
    ? output.control.runMappingTab
    : "prompt_mapping";
  output.control.wizardStep = clampInt(output.control.wizardStep, 1, 3, 1);
  output.control.promptMapOpen = Boolean(output.control.promptMapOpen);
  output.control.promptMapFullscreen = Boolean(output.control.promptMapFullscreen);
  output.control.promptRefMap = normalizePromptRefMap(output.control.promptRefMap);
  output.control.oneToOneBatchRefIds = normalizeIdArray(output.control.oneToOneBatchRefIds);
  output.control.transientReferenceItems = Array.isArray(output.control.transientReferenceItems)
    ? output.control.transientReferenceItems.slice(0, 100)
    : [];
  output.control.saveUploadsToLibrary = output.control.saveUploadsToLibrary === true;
  output.control.sourceVideo = normalizeSourceVideo(output.control.sourceVideo);
  output.control.sourceVideos = (Array.isArray(output.control.sourceVideos) ? output.control.sourceVideos : [])
    .map(normalizeSourceVideo)
    .filter(Boolean)
    .slice(0, 2000);
  if (!output.control.sourceVideos.length && output.control.sourceVideo) output.control.sourceVideos = [output.control.sourceVideo];
  output.control.sourceVideo = output.control.sourceVideos[0] || output.control.sourceVideo;
  output.control.videoEdit = normalizeVideoEdit(output.control.videoEdit);
  output.control.characterSources = normalizeCharacterSources(output.control.characterSources);
  output.control.characterSetupRunner = normalizeCharacterSetupRunner(output.control.characterSetupRunner);
  output.control.presets = normalizePresets(output.control.presets, Number(incoming.version || 0));
  output.control.references = normalizeReferences(output.control.references);
  output.queue.items = Array.isArray(output.queue.items) ? output.queue.items : [];
  output.queue.authRefresh = output.queue.authRefresh && typeof output.queue.authRefresh === "object"
    ? output.queue.authRefresh
    : null;
  output.gallery.items = Array.isArray(output.gallery.items) ? output.gallery.items : [];
  output.gallery.deletedIds = Array.isArray(output.gallery.deletedIds) ? output.gallery.deletedIds : [];
  output.ui.selectedGalleryIds = Array.isArray(output.ui.selectedGalleryIds) ? output.ui.selectedGalleryIds : [];
  const galleryDownloadFeedback = output.ui.galleryDownloadFeedback && typeof output.ui.galleryDownloadFeedback === "object"
    ? output.ui.galleryDownloadFeedback
    : {};
  const interruptedDownload = galleryDownloadFeedback.status === "running";
  output.ui.galleryDownloadFeedback = {
    status: interruptedDownload
      ? "error"
      : ["idle", "success", "error"].includes(galleryDownloadFeedback.status)
        ? galleryDownloadFeedback.status
        : "idle",
    requestedResolution: String(galleryDownloadFeedback.requestedResolution || ""),
    deliveredResolution: String(galleryDownloadFeedback.deliveredResolution || ""),
    unavailableResolution: String(galleryDownloadFeedback.unavailableResolution || ""),
    completed: Number.isFinite(Number(galleryDownloadFeedback.completed))
      ? Math.max(0, Number(galleryDownloadFeedback.completed))
      : 0,
    total: Number.isFinite(Number(galleryDownloadFeedback.total))
      ? Math.max(0, Number(galleryDownloadFeedback.total))
      : 0,
    error: interruptedDownload
      ? String(galleryDownloadFeedback.error || "Download interrupted before completion; retry the selected media.")
      : String(galleryDownloadFeedback.error || "")
  };
  output.ui.deleteMarkedGalleryIds = Array.isArray(output.ui.deleteMarkedGalleryIds) ? output.ui.deleteMarkedGalleryIds : [];
  output.ui.agentLiveQueueTab = ["images", "videos"].includes(output.ui.agentLiveQueueTab) ? output.ui.agentLiveQueueTab : "videos";
  output.ui.openInlineHelpPanel = String(output.ui.openInlineHelpPanel || "");
  output.ui.galleryHelpKey = String(output.ui.galleryHelpKey || "");
  output.ui.helpOpen = Boolean(output.ui.helpOpen);
  output.ui.activeHelpTopic = String(output.ui.activeHelpTopic || "text_to_video");
  output.ui.walkthrough = normalizeWalkthrough(output.ui.walkthrough);
  output.scenes = normalizeScenes(output.scenes);
  output.logs.items = Array.isArray(output.logs.items) ? output.logs.items.slice(-300) : [];
  output.referenceLibrary.savedItems = Array.isArray(output.referenceLibrary.savedItems)
    ? output.referenceLibrary.savedItems.slice(0, 100)
    : [];
  output.control.agentMode = normalizeAgentMode(output.control.agentMode);
  output.control.agentRun = normalizeAgentRun(output.control.agentRun);
  output.characters = normalizeCharacters(output.characters);
  output.history = normalizeHistory(output.history);
  output.account = normalizeAccount(output.account);
  return output;
}

function normalizePresets(presets = {}, sourceVersion = 0) {
  const base = createDefaultState().control.presets;
  const out = { ...base, ...(presets && typeof presets === "object" ? presets : {}) };
  // The validators below (allow-list checks + clampInt) replace any invalid
  // stored value with a system default. They are the single source of truth
  // for migration. We intentionally do NOT force-reset these keys for
  // sourceVersion < 3: that destroyed valid user choices on first load
  // (Alpha Bravo report 2026-05-04: Settings tab shows landscape but Run
  // page step 3 shows portrait — user's stored landscape was being wiped
  // by the migration on every cold load until first persistState bumped
  // version to 4).
  let submitPath = out.submitPath || out.submitPathPreference;
  // 10.8.23 makes Agent Mode the update default. Migrate once from every
  // pre-v6 route; after state persists as v6, later user selections remain
  // untouched on every startup.
  if (sourceVersion < 6) submitPath = "agent_first";
  if (submitPath === "dom_fallback") submitPath = "dom_first";
  out.submitPath = SUBMIT_PATH_KEYS.includes(submitPath) ? submitPath : "agent_first";
  out.submitPathPreference = out.submitPath;
  out.videoLength = ["4", "6", "8", "10"].includes(String(out.videoLength)) ? String(out.videoLength) : "8";
  out.aspectRatio = ["landscape", "portrait"].includes(out.aspectRatio) ? out.aspectRatio : "portrait";
  out.imageAspectRatio = ["landscape", "landscape_4_3", "square", "portrait_3_4", "portrait"].includes(out.imageAspectRatio)
    ? out.imageAspectRatio
    : "portrait";
  out.repeatCount = clampInt(out.repeatCount, 1, 4, 4);
  out.imageRepeatCount = clampInt(out.imageRepeatCount, 1, 4, 4);
  out.startFrom = clampInt(out.startFrom, 1, 9999, 1);
  out.minInitialWaitTime = clampInt(out.minInitialWaitTime, 1, 999, 20);
  out.maxInitialWaitTime = Math.max(out.minInitialWaitTime, clampInt(out.maxInitialWaitTime, 1, 999, 40));
  out.recaptchaCooldownSmallThreshold = clampInt(out.recaptchaCooldownSmallThreshold, 1, 999, 15);
  out.recaptchaCooldownSmallWait = clampInt(out.recaptchaCooldownSmallWait, 0, 999, 30);
  out.recaptchaCooldownLargeThreshold = clampInt(out.recaptchaCooldownLargeThreshold, 1, 999, 30);
  out.recaptchaCooldownLargeWait = clampInt(out.recaptchaCooldownLargeWait, 0, 999, 60);
  out.t2iBatchSize = clampInt(out.t2iBatchSize, 1, 3, 2);
  out.model = VIDEO_MODEL_KEYS.includes(out.model) ? out.model : "default";
  out.ingredientsModel = INGREDIENTS_VIDEO_MODEL_KEYS.includes(out.ingredientsModel) ? out.ingredientsModel : "omni_flash";
  const storedImageModel = out.imageModel === "imagen_4" ? "nano_banana_2" : out.imageModel;
  out.imageModel = ["nano_banana_pro", "nano_banana_2", "nano_banana_2_lite"].includes(storedImageModel) ? storedImageModel : "nano_banana_pro";
  out.returnSilentVideos = out.returnSilentVideos !== false && out.returnSilentVideos !== "false";
  out.videoDownloadResolution = ["720p", "1080p", "4k"].includes(out.videoDownloadResolution) ? out.videoDownloadResolution : "720p";
  out.videoDownloadMethodPreference = ["auto", "api", "dom"].includes(out.videoDownloadMethodPreference) ? out.videoDownloadMethodPreference : "auto";
  out.imageAutoDownloadResolution = ["1k", "2k", "4k"].includes(out.imageAutoDownloadResolution) ? out.imageAutoDownloadResolution : "1k";
  out.imageDownloadMethodPreference = ["auto", "api", "dom"].includes(out.imageDownloadMethodPreference) ? out.imageDownloadMethodPreference : "auto";
  out.t2iSubmitMode = ["safe_serial", "fast_batch"].includes(out.t2iSubmitMode) ? out.t2iSubmitMode : "safe_serial";
  out.filenameStyle = ["detailed", "prompt_prefix", "auto_flow", "custom_template"].includes(out.filenameStyle) ? out.filenameStyle : "detailed";
  out.autopilotT2IToF2V = ["off", "all", "one"].includes(out.autopilotT2IToF2V) ? out.autopilotT2IToF2V : "off";
  out.filenameTemplateIndex = ["none", "n", "nn", "nnn"].includes(out.filenameTemplateIndex) ? out.filenameTemplateIndex : "nn";
  out.filenameTemplatePromptPart = ["none", "first_word", "first_3_words", "slug_8"].includes(out.filenameTemplatePromptPart) ? out.filenameTemplatePromptPart : "first_3_words";
  out.filenameTemplateDate = ["none", "yyyymmdd", "yymmdd_hhmm"].includes(out.filenameTemplateDate) ? out.filenameTemplateDate : "none";
  out.filenameTemplateSuffix = ["none", "rand4", "rand8"].includes(out.filenameTemplateSuffix) ? out.filenameTemplateSuffix : "none";
  out.filenameTemplateSeparator = ["_", "-"].includes(out.filenameTemplateSeparator) ? out.filenameTemplateSeparator : "_";
  out.downloadFolder = normalizeDownloadFolderBase(out.downloadFolder);
  out.downloadFolderRunIndex = clampInt(out.downloadFolderRunIndex, 0, 9999, 0);
  out.downloadFolderLastBase = normalizeDownloadFolderBase(out.downloadFolderLastBase || out.downloadFolder);
  out.filenameTemplatePrefix = String(out.filenameTemplatePrefix || "");
  out.language = normalizeLanguage(out.language);
  out.safeRefAttachMode = Boolean(out.safeRefAttachMode);
  out.overnight403Recovery = Boolean(out.overnight403Recovery);
  out.autoDownload = Boolean(out.autoDownload);
  out.autoDownloadImages = Boolean(out.autoDownloadImages);
  out.autoNumberFolder = Boolean(out.autoNumberFolder);
  out.mapLineRefs = Boolean(out.mapLineRefs);
  out.autoStartNextJob = Boolean(out.autoStartNextJob);
  out.autoRetryFailedUntilZero = Boolean(out.autoRetryFailedUntilZero);
  return out;
}

function normalizeDownloadFolderBase(value = "Auto-Flow") {
  const raw = String(value || "Auto-Flow").trim();
  if (raw === "Auto-Flow-01") return "Auto-Flow";
  return raw || "Auto-Flow";
}

function clampInt(value, min, max, fallback) {
  const next = Number.parseInt(value, 10);
  if (!Number.isFinite(next)) return fallback;
  return Math.max(min, Math.min(max, next));
}

function normalizeReferences(refs = {}) {
  const base = createDefaultState().control.references;
  return Object.fromEntries(
    Object.keys(base).map((key) => [key, String(refs?.[key] || "")])
  );
}

function normalizeSourceVideo(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const id = String(value.id || value.blobStoreId || "").trim();
  if (!id) return null;
  return {
    id,
    blobStoreId: String(value.blobStoreId || ""),
    title: String(value.title || value.fileName || "Source video"),
    fileName: String(value.fileName || "source-video.mp4"),
    mimeType: String(value.mimeType || "video/mp4"),
    size: Math.max(0, Number(value.size || 0) || 0),
    durationSeconds: Math.max(0, Number(value.durationSeconds || 0) || 0),
    width: Math.max(0, Number(value.width || 0) || 0),
    height: Math.max(0, Number(value.height || 0) || 0),
    mediaId: String(value.mediaId || ""),
    workflowId: String(value.workflowId || ""),
    transcoded: value.transcoded === true,
    uploadStatus: ["local", "uploading", "uploaded", "failed"].includes(String(value.uploadStatus || ""))
      ? String(value.uploadStatus)
      : (value.mediaId ? "uploaded" : "local"),
    uploadAttempts: Math.max(0, Number(value.uploadAttempts || 0) || 0),
    uploadError: String(value.uploadError || ""),
    uploadedAt: String(value.uploadedAt || ""),
    sourceIndex: Math.max(0, Number(value.sourceIndex || 0) || 0),
    createdAt: String(value.createdAt || "")
  };
}

function normalizeVideoEdit(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    reusePromptForAll: source.reusePromptForAll !== false,
    engine: source.engine === "api_first" ? "api_first" : "agent_first",
    uploadConcurrency: clampInt(source.uploadConcurrency, 1, 3, 2),
    persistentReferenceIds: normalizeIdArray(source.persistentReferenceIds || []).slice(0, 5)
  };
}

function normalizeCharacterSources(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return Object.fromEntries(Object.entries(source).slice(0, 100).map(([handle, entry]) => {
    const item = entry && typeof entry === "object" ? entry : {};
    return [String(handle || "").trim().toLowerCase(), {
      sourceMode: ["generate_from_description", "uploaded_image", "reference_library", "existing_flow_character", "saved_flow_character", "unset"].includes(item.sourceMode)
        ? item.sourceMode
        : "generate_from_description",
      sourceRefId: String(item.sourceRefId || ""),
      sourceMediaId: String(item.sourceMediaId || ""),
      flowCharacterId: String(item.flowCharacterId || ""),
      characterServerId: String(item.characterServerId || item.flowCharacterId || ""),
      flowDisplayName: String(item.flowDisplayName || ""),
      projectId: String(item.projectId || item.activeProjectId || ""),
      activeProjectId: String(item.activeProjectId || item.projectId || ""),
      storedMappingProjectId: String(item.storedMappingProjectId || ""),
      mappingProjectMatchesActiveProject: item.mappingProjectMatchesActiveProject === true,
      requestedVoice: String(item.requestedVoice || ""),
      resolvedVoiceName: String(item.resolvedVoiceName || ""),
      additionalInfo: String(item.additionalInfo || ""),
      status: String(item.status || ""),
      setupStatus: String(item.setupStatus || item.status || ""),
      characterServerIdHash: String(item.characterServerIdHash || ""),
      storedCharacterServerIdHash: String(item.storedCharacterServerIdHash || ""),
      proofTimestamp: String(item.proofTimestamp || ""),
      proofIds: Array.isArray(item.proofIds) ? item.proofIds.slice(0, 10).map((id) => String(id || "")).filter(Boolean) : []
    }];
  }).filter(([handle]) => handle));
}

function normalizeCharacterSetupRunner(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    runId: String(source.runId || ""),
    status: String(source.status || ""),
    startedAt: String(source.startedAt || ""),
    completedAt: String(source.completedAt || ""),
    projectId: String(source.projectId || ""),
    readyCount: clampInt(source.readyCount, 0, 500, 0),
    totalCount: clampInt(source.totalCount, 0, 500, 0),
    blockers: Array.isArray(source.blockers) ? source.blockers.slice(0, 100).map((item) => ({
      handle: String(item?.handle || ""),
      status: String(item?.status || ""),
      reason: String(item?.reason || "")
    })) : [],
    proof: source.proof && typeof source.proof === "object" ? {
      traceEventName: String(source.proof.traceEventName || ""),
      activeProjectPreflight: Array.isArray(source.proof.activeProjectPreflight)
        ? source.proof.activeProjectPreflight.slice(0, 100).filter((item) => item && typeof item === "object")
        : [],
      imageRowsAccepted: source.proof.imageRowsAccepted === true,
      nativeRows: clampInt(source.proof.nativeRows, 0, 1000, 0),
      imageRows: clampInt(source.proof.imageRows, 0, 1000, 0),
      route: String(source.proof.route || ""),
      creationEndpoint: String(source.proof.creationEndpoint || ""),
      saveEndpoint: String(source.proof.saveEndpoint || ""),
      imageEndpoint: String(source.proof.imageEndpoint || ""),
      flowTabReloadAfterSetup: source.proof.flowTabReloadAfterSetup && typeof source.proof.flowTabReloadAfterSetup === "object"
        ? {
          ok: source.proof.flowTabReloadAfterSetup.ok !== false,
          action: String(source.proof.flowTabReloadAfterSetup.action || ""),
          reason: String(source.proof.flowTabReloadAfterSetup.reason || ""),
          error: String(source.proof.flowTabReloadAfterSetup.error || ""),
          tabReload: source.proof.flowTabReloadAfterSetup.tabReload && typeof source.proof.flowTabReloadAfterSetup.tabReload === "object"
            ? {
              ok: source.proof.flowTabReloadAfterSetup.tabReload.ok !== false,
              tabId: clampInt(source.proof.flowTabReloadAfterSetup.tabReload.tabId, 0, Number.MAX_SAFE_INTEGER, 0),
              error: String(source.proof.flowTabReloadAfterSetup.tabReload.error || "")
            }
            : null,
          wait: source.proof.flowTabReloadAfterSetup.wait && typeof source.proof.flowTabReloadAfterSetup.wait === "object"
            ? {
              ok: source.proof.flowTabReloadAfterSetup.wait.ok !== false,
              tabId: clampInt(source.proof.flowTabReloadAfterSetup.wait.tabId, 0, Number.MAX_SAFE_INTEGER, 0),
              url: String(source.proof.flowTabReloadAfterSetup.wait.url || ""),
              error: String(source.proof.flowTabReloadAfterSetup.wait.error || "")
            }
            : null
        }
        : null,
      creationAttempts: Array.isArray(source.proof.creationAttempts)
        ? source.proof.creationAttempts.slice(0, 100).filter((item) => item && typeof item === "object")
        : []
    } : null,
    error: String(source.error || "")
  };
}

function normalizeCharacters(characters = {}) {
  const source = characters && typeof characters === "object" ? characters : {};
  const voiceCatalogSource = source.voiceCatalog && typeof source.voiceCatalog === "object" ? source.voiceCatalog : {};
  const voices = Array.isArray(voiceCatalogSource.voices)
    ? voiceCatalogSource.voices.slice(0, 100).map((voice) => ({
        displayName: String(voice?.displayName || voice?.name || ""),
        normalizedName: String(voice?.normalizedName || ""),
        description: String(voice?.description || ""),
        flowVoiceId: String(voice?.flowVoiceId || voice?.id || ""),
        previewAvailable: Boolean(voice?.previewAvailable),
        selector: String(voice?.selector || "")
      })).filter((voice) => voice.displayName)
    : [];
  return {
    storeInFlow: source.storeInFlow === true,
    voiceCatalog: {
      capturedAt: String(voiceCatalogSource.capturedAt || ""),
      accountTier: String(voiceCatalogSource.accountTier || ""),
      voiceCount: Number.isFinite(Number(voiceCatalogSource.voiceCount)) ? Number(voiceCatalogSource.voiceCount) : voices.length,
      voices,
      catalogHash: String(voiceCatalogSource.catalogHash || "")
    },
    assets: Array.isArray(source.assets) ? source.assets.slice(0, 200).filter((asset) => asset && typeof asset === "object") : [],
    savedMappings: Array.isArray(source.savedMappings) ? source.savedMappings.slice(0, 100).filter((mapping) => mapping && typeof mapping === "object") : []
  };
}

function normalizeHistory(history = {}) {
  const runs = Array.isArray(history?.runs) ? history.runs : [];
  return {
    runs: runs
      .filter((run) => run && typeof run === "object")
      .map((run) => ({
        id: String(run.id || ""),
        title: String(run.title || ""),
        mode: Object.values(FLOW_MODES).includes(run.mode) ? run.mode : FLOW_MODES.imageToVideo,
        promptCount: clampInt(run.promptCount, 0, 10000, 0),
        promptsText: String(run.promptsText || ""),
        createdAt: String(run.createdAt || ""),
        projectId: String(run.projectId || ""),
        refs: Array.isArray(run.refs) ? run.refs.slice(0, 20).map(normalizeHistoryRef).filter(Boolean) : [],
        control: normalizeHistoryControl(run.control)
      }))
      .filter((run) => run.id && run.promptsText.trim())
      .slice(0, 50)
  };
}

function normalizeHistoryRef(ref = {}) {
  const id = String(ref.id || "").trim();
  if (!id) return null;
  return {
    id,
    blobStoreId: String(ref.blobStoreId || ""),
    title: String(ref.title || ref.fileName || "Reference"),
    fileName: String(ref.fileName || ref.title || "reference.png"),
    mediaId: String(ref.mediaId || ""),
    imageUrl: String(ref.imageUrl || ref.mediaUrl || "")
  };
}

function normalizeHistoryControl(control = {}) {
  const base = createDefaultState().control;
  const refs = normalizeReferences(control?.references || {});
  return {
    mode: Object.values(FLOW_MODES).includes(control?.mode) ? control.mode : base.mode,
    livePrompt: String(control?.livePrompt || ""),
    characterPromptText: String(control?.characterPromptText || ""),
    promptTab: ["workflow_prompts", "character_prompts"].includes(control?.promptTab) ? control.promptTab : base.promptTab,
    referencesTab: ["prompt_references", "character_sources"].includes(control?.referencesTab) ? control.referencesTab : base.referencesTab,
    runMappingTab: ["prompt_mapping", "character_mapping"].includes(control?.runMappingTab) ? control.runMappingTab : base.runMappingTab,
    wizardStep: clampInt(control?.wizardStep, 1, 3, 1),
    lastRunError: String(control?.lastRunError || ""),
    promptMapOpen: Boolean(control?.promptMapOpen),
    promptMapFullscreen: false,
    promptRefMap: normalizePromptRefMap(control?.promptRefMap || {}),
    oneToOneBatchRefIds: normalizeIdArray(control?.oneToOneBatchRefIds || []),
    sourceVideo: normalizeSourceVideo(control?.sourceVideo),
    sourceVideos: (Array.isArray(control?.sourceVideos) ? control.sourceVideos : []).map(normalizeSourceVideo).filter(Boolean).slice(0, 2000),
    videoEdit: normalizeVideoEdit(control?.videoEdit || {}),
    references: refs,
    characterSources: normalizeCharacterSources(control?.characterSources || {}),
    activeApplyMode: String(control?.activeApplyMode || "shared"),
    presets: normalizePresets(control?.presets || {}, 4)
  };
}

function normalizeAgentMode(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    bridgeEnabled: source.bridgeEnabled === true,
    agentInstructions: String(source.agentInstructions || "").slice(0, 20000),
    projectBrief: String(source.projectBrief || "").slice(0, 20000),
    downloadMonitorEnabled: source.downloadMonitorEnabled === true,
    creditApproval: source.creditApproval === "within_cap" ? "within_cap" : "ask_each_time",
    maxCreditsPerRun: Math.max(0, Math.min(100000, Number(source.maxCreditsPerRun || 0) || 0)),
    persistentCreditApproval: source.persistentCreditApproval === true,
    autoApproveFreeCredits: source.autoApproveFreeCredits !== false,
    lastMasterPrompt: String(source.lastMasterPrompt || "").slice(0, 200000),
    lastMasterPromptAt: String(source.lastMasterPromptAt || ""),
    bridgePairingApprovalRequestedAt: String(source.bridgePairingApprovalRequestedAt || ""),
    bridgePairingApprovalExpiresAt: String(source.bridgePairingApprovalExpiresAt || ""),
    bridgePairingApprovalUsedAt: String(source.bridgePairingApprovalUsedAt || ""),
    bridgePairingApprovalClientId: String(source.bridgePairingApprovalClientId || "").slice(0, 160),
    directPendingClient: normalizeDirectBrowserClient(source.directPendingClient),
    directApprovedClient: normalizeDirectBrowserClient(source.directApprovedClient)
  };
}

function normalizeDirectBrowserClient(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    requestId: String(source.requestId || "").slice(0, 200),
    clientId: String(source.clientId || "").slice(0, 160),
    clientName: String(source.clientName || "").slice(0, 120),
    origin: String(source.origin || "").slice(0, 500),
    tabId: Number(source.tabId || 0) || null,
    windowId: Number(source.windowId || 0) || null,
    requestedAt: String(source.requestedAt || ""),
    approvedAt: String(source.approvedAt || "")
  };
}

function normalizeAgentRun(value = {}) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    ...source,
    id: String(source.id || ""),
    status: String(source.status || ""),
    projectId: String(source.projectId || ""),
    startedAt: String(source.startedAt || ""),
    completedAt: String(source.completedAt || ""),
    rows: Array.isArray(source.rows) ? source.rows.slice(0, 2000).filter((row) => row && typeof row === "object") : [],
    pendingRetry: source.pendingRetry && typeof source.pendingRetry === "object" && !Array.isArray(source.pendingRetry)
      ? { ...source.pendingRetry }
      : null,
    retryRequests: Array.isArray(source.retryRequests) ? source.retryRequests.slice(0, 100).filter((item) => item && typeof item === "object") : [],
    autoDownload: source.autoDownload === true,
    downloadFolder: normalizeDownloadFolderBase(source.downloadFolder || "Auto-Flow"),
    downloadPlan: source.downloadPlan && typeof source.downloadPlan === "object" && !Array.isArray(source.downloadPlan) ? { ...source.downloadPlan } : null,
    artifactPlan: source.artifactPlan && typeof source.artifactPlan === "object" && !Array.isArray(source.artifactPlan) ? { ...source.artifactPlan } : null,
    downloadedMediaIds: normalizeIdArray(source.downloadedMediaIds || []),
    failedDownloadMediaIds: normalizeIdArray(source.failedDownloadMediaIds || []),
    selectedIds: normalizeIdArray(source.selectedIds || []),
    selectedMediaIds: normalizeIdArray(source.selectedMediaIds || [])
  };
}

function normalizeIdArray(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map((id) => String(id || "").trim()).filter(Boolean))];
}

function normalizePromptRefMap(value = {}) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  const output = {};
  for (const [key, ids] of Object.entries(value)) {
    const normalizedKey = String(key || "").trim();
    if (!normalizedKey) continue;
    output[normalizedKey] = Array.isArray(ids)
      ? ids.map((id) => String(id || "").trim()).filter(Boolean)
      : [];
  }
  return output;
}

function normalizeAccount(account) {
  const source = account && typeof account === "object" ? account : {};
  return {
    status: ["unknown", "signed_out", "signed_in", "pending_confirmation"].includes(source.status) ? source.status : "unknown",
    email: source.email || null,
    userId: source.userId || null,
    plan: ["free", "pro", "team"].includes(source.plan) ? source.plan : "free",
    rawPlan: source.rawPlan || source.plan || "free",
    subscriptionStatus: source.subscriptionStatus || "inactive",
    stripeSubscriptionStatus: source.stripeSubscriptionStatus || null,
    supabaseSubscriptionStatus: source.supabaseSubscriptionStatus || null,
    currentPeriodEnd: source.currentPeriodEnd || null,
    cancelAtPeriodEnd: source.cancelAtPeriodEnd ?? null,
    billingHealth: source.billingHealth || source.billing?.health || "unknown",
    billing: {
      health: source.billing?.health || source.billingHealth || "unknown",
      lastWebhookEventAt: source.billing?.lastWebhookEventAt || null,
      lastBillingSyncAt: source.billing?.lastBillingSyncAt || null,
      stripeCustomerMapped: source.billing?.stripeCustomerMapped ?? null,
      mismatchReason: source.billing?.mismatchReason || null
    },
    usage: normalizeUsage(source.usage),
    pendingCheckout: Boolean(source.pendingCheckout),
    otpCode: source.otpCode || "",
    message: source.message || null,
    error: source.error || null,
    authGateShown: source.authGateShown === true,
    authGateReason: source.authGateReason || "",
    authGateBlockingRecovery: source.authGateBlockingRecovery === true,
    authCodeRequestedAt: source.authCodeRequestedAt || null,
    authCodeRequestError: source.authCodeRequestError || null,
    authCodeRateLimited: source.authCodeRateLimited === true,
    authCodeResendAvailableAt: source.authCodeResendAvailableAt || null,
    lastKnownAccountStatus: source.lastKnownAccountStatus || "unknown",
    lastKnownBillingHealth: source.lastKnownBillingHealth || "unknown",
    degradedLocalMode: source.degradedLocalMode === true,
    authRefresh: source.authRefresh && typeof source.authRefresh === "object" ? source.authRefresh : null,
    supportExportAllowedWhileSignedOut: source.supportExportAllowedWhileSignedOut !== false,
    supportCopyAllowedWhileSignedOut: source.supportCopyAllowedWhileSignedOut !== false,
    queueControlsAllowedWhileAuthPending: source.queueControlsAllowedWhileAuthPending !== false,
    lastCheckedAt: source.lastCheckedAt || null
  };
}

function normalizeScenes(scenes = {}) {
  const source = scenes && typeof scenes === "object" ? scenes : {};
  const clips = Array.isArray(source.clips) ? source.clips : [];
  const normalizedClips = clips.slice(0, 200).map(normalizeSceneClip).filter(Boolean);
  const clipIds = new Set(normalizedClips.map((clip) => clip.id));
  return {
    clips: normalizedClips,
    audioName: String(source.audioName || ""),
    selectedClipIds: normalizeIdArray(source.selectedClipIds || []).filter((id) => clipIds.has(id)),
    totalDuration: totalSceneDuration(normalizedClips),
    updatedAt: source.updatedAt || null
  };
}

function normalizeWalkthrough(walkthrough) {
  if (!walkthrough || typeof walkthrough !== "object") return null;
  return {
    topicId: String(walkthrough.topicId || "text_to_video"),
    stepIndex: clampInt(walkthrough.stepIndex, 0, 99, 0)
  };
}

function normalizeLanguage(language = "en") {
  const raw = String(language || "en").trim().toLowerCase().replace("_", "-");
  const primary = raw.split("-")[0];
  const allowed = new Set(["en", "vi", "tr", "ar", "de", "fr", "ja", "id", "ko", "it", "ru", "nl", "hi", "th", "ur", "bn", "es", "tl", "pt"]);
  if (raw === "es-419") return "es";
  if (raw === "pt-br" || raw === "pt-pt") return "pt";
  if (raw === "fil") return "tl";
  return allowed.has(primary) ? primary : "en";
}

function normalizeUsage(usage = {}) {
  const limit = Number.isFinite(Number(usage.limit)) ? Number(usage.limit) : 10;
  const used = Number.isFinite(Number(usage.used)) ? Number(usage.used) : 0;
  const remaining = Number.isFinite(Number(usage.remaining)) ? Number(usage.remaining) : Math.max(0, limit - used);
  return {
    allowed: usage.allowed === true,
    unlimited: usage.unlimited === true,
    limit,
    used,
    remaining,
    resetAt: usage.resetAt || null
  };
}

function deepMerge(target, source) {
  if (!source || typeof source !== "object") return target;
  for (const [key, value] of Object.entries(source)) {
    if (Array.isArray(value)) {
      target[key] = [...value];
      continue;
    }
    if (value && typeof value === "object") {
      target[key] = deepMerge(target[key] && typeof target[key] === "object" ? target[key] : {}, value);
      continue;
    }
    target[key] = value;
  }
  return target;
}
