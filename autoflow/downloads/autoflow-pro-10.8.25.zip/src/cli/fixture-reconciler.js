import {
  isCaptainExplicitlyAuthorized,
  isSubmitConfirmCreditsAuthorized
} from "../core/agent/agent-credit-policy.js";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import {
  buildAgentF2VMatrix,
  buildAgentGenericMatrix,
  buildAgentOmniMultiFrameMatrix,
  buildAgentPromptText,
  parseAutoFlowAgentPacket
} from "../core/agent/agent-mode.js";
import {
  appendAgentAfidPromptContract,
  buildAgentManifestFromMatrix,
  buildAgentManifestFromPromptText,
  buildAgentManifestPromptText,
  buildAgentMatrixFromManifest
} from "../core/agent/agent-manifest.js";
import { reconcileAgentProject } from "../core/agent/agent-reconciler.js";
import { buildAgentRetryPrompt } from "../core/agent/agent-retry-prompts.js";
import { planAgentRunArtifacts } from "../core/agent/agent-run-artifacts.js";
import { normalizeAgentRunOptions } from "../core/agent/agent-run-profile.js";
import { evaluateTranscriptQa } from "../core/qa/transcript-qa.js";

export async function reconcileFixture(fixturePath, options = {}) {
  const absolutePath = path.resolve(options.cwd || process.cwd(), fixturePath);
  const raw = await readJsonFile(absolutePath);
  const expectedManifest = options.expectedManifest || (options.expectedManifestPath
    ? await readJsonFile(path.resolve(options.cwd || process.cwd(), options.expectedManifestPath))
    : null);
  if (expectedManifest) {
    return reconcileExpectedProjectData(raw, expectedManifest, {
      ...options,
      source: "fixture",
      fixture: fixturePath
    });
  }
  return reconcileProjectData(raw, {
    ...options,
    source: "fixture",
    fixture: fixturePath
  });
}

export async function buildAgentPromptBundleFromFile(inputPath, options = {}) {
  const absolutePath = path.resolve(options.cwd || process.cwd(), inputPath);
  const promptSourceText = await fs.readFile(absolutePath, "utf8");
  return buildAgentPromptBundleFromText(promptSourceText, {
    ...options,
    inputPath
  });
}

export async function buildAgentPromptBundleFromText(promptSourceText = "", options = {}) {
  const runOptions = normalizeAgentRunOptions(options);
  const references = await buildReferenceDescriptors(options);
  const parsedPacket = parseAutoFlowAgentPacket(promptSourceText);
  const promptRowManifest = buildAgentManifestFromPromptText(promptSourceText, {
    title: options.title
  });
  const agentMode = String(options.agentMode || options.mode || "auto").toLowerCase();
  const hasOmniFrames = parsedPacket.clips.some((clip) => Array.isArray(clip.frames) && clip.frames.length > 0);
  let matrix = null;
  let manifest = null;
  let promptText = "";
  let inputKind = "generic_prompts";

  if (parsedPacket.clips.length) {
    const matrixBuilder = agentMode === "omni-multiframe" || (agentMode === "auto" && hasOmniFrames)
      ? buildAgentOmniMultiFrameMatrix
      : buildAgentF2VMatrix;
    matrix = matrixBuilder({
      packetText: promptSourceText,
      rows: options.rows || (matrixBuilder === buildAgentOmniMultiFrameMatrix ? "all" : 1),
      repeatCount: runOptions.videoOutputsPerRow || runOptions.repeatCount || 1,
      videoLength: options.videoLength || options.length || options.duration || (matrixBuilder === buildAgentOmniMultiFrameMatrix ? "8-10" : runOptions.videoLength || "8"),
      aspectRatio: runOptions.aspectRatio || "portrait",
      model: options.videoModel || runOptions.model || (matrixBuilder === buildAgentOmniMultiFrameMatrix ? "Omni" : undefined),
      reference: references[0] || {},
      references,
      confirmCredits: isSubmitConfirmCreditsAuthorized(options),
      captainAuthorized: isCaptainExplicitlyAuthorized(options),
      autonomy: options.autonomy,
      maxSelfHealRetries: options.maxSelfHealRetries,
      suppressOnScreenText: options.suppressOnScreenText
    });
    manifest = buildAgentManifestFromMatrix(matrix);
    matrix.manifest = manifest;
    promptText = appendAgentAfidPromptContract(buildAgentPromptText(matrix), manifest);
    inputKind = matrixBuilder === buildAgentOmniMultiFrameMatrix ? "omni_packet" : "f2v_packet";
  } else if (promptRowManifest.rows.length) {
    matrix = buildAgentMatrixFromManifest(promptRowManifest, {
      mode: options.mode,
      repeatCount: runOptions.videoOutputsPerRow || runOptions.repeatCount || 1,
      videoLength: runOptions.videoLength || "8",
      aspectRatio: runOptions.aspectRatio || "portrait",
      model: options.videoModel || runOptions.model || "",
      autonomy: options.autonomy,
      maxSelfHealRetries: options.maxSelfHealRetries,
      suppressOnScreenText: options.suppressOnScreenText
    });
    manifest = matrix.manifest;
    promptText = buildAgentManifestPromptText(manifest, {
      title: matrix.title,
      settings: matrix.settings,
      autonomy: options.autonomy,
      maxSelfHealRetries: options.maxSelfHealRetries,
      suppressOnScreenText: options.suppressOnScreenText
    });
    inputKind = "afid_prompt_rows";
  } else {
    matrix = buildAgentGenericMatrix({
      mode: options.mode || "text-to-image",
      prompts: splitPromptLines(promptSourceText),
      repeatCount: runOptions.repeatCount || 1,
      videoLength: runOptions.videoLength || "8",
      aspectRatio: runOptions.aspectRatio || "portrait",
      model: options.videoModel || options.imageModel || runOptions.model || "",
      referenceStrategy: options.referenceStrategy || {},
      references,
      confirmCredits: isSubmitConfirmCreditsAuthorized(options),
      captainAuthorized: isCaptainExplicitlyAuthorized(options),
      autonomy: options.autonomy,
      maxSelfHealRetries: options.maxSelfHealRetries,
      suppressOnScreenText: options.suppressOnScreenText
    });
    manifest = buildAgentManifestFromMatrix(matrix);
    matrix.manifest = manifest;
    promptText = appendAgentAfidPromptContract(buildAgentPromptText(matrix), manifest);
  }

  if (!Array.isArray(matrix?.rows) || !matrix.rows.length) {
    throw new Error("No Agent rows were built from input text.");
  }

  return {
    ok: true,
    command: "agent build-matrix",
    inputPath: options.inputPath || "",
    inputKind,
    rowsBuilt: matrix.rowsBuilt || matrix.rows.length,
    matrixKind: matrix.kind,
    expectedImages: matrix.expectedImages ?? manifest.expectedImageCount ?? 0,
    expectedVideos: matrix.expectedVideos ?? manifest.expectedVideoCount ?? 0,
    manifestExpectedImages: manifest.expectedImageCount ?? 0,
    manifestExpectedVideos: manifest.expectedVideoCount ?? 0,
    references,
    matrix,
    manifest,
    promptText
  };
}

export async function writeAgentPromptBundle(bundle = {}, outDir, options = {}) {
  if (!outDir) return {};
  const absoluteOutDir = path.resolve(options.cwd || process.cwd(), outDir);
  await fs.mkdir(absoluteOutDir, { recursive: true });
  const matrixPath = path.join(absoluteOutDir, "agent-matrix.json");
  const manifestPath = path.join(absoluteOutDir, "agent-manifest.json");
  const promptPath = path.join(absoluteOutDir, "agent-master-prompt.txt");
  const summaryPath = path.join(absoluteOutDir, "README.md");
  await fs.writeFile(matrixPath, `${JSON.stringify(bundle.matrix, null, 2)}\n`);
  await fs.writeFile(manifestPath, `${JSON.stringify(bundle.manifest, null, 2)}\n`);
  await fs.writeFile(promptPath, bundle.promptText);
  await fs.writeFile(summaryPath, buildAgentBundleSummary(bundle, {
    inputPath: bundle.inputPath,
    matrixPath,
    manifestPath,
    promptPath
  }));
  return {
    outDir: absoluteOutDir,
    matrixPath,
    manifestPath,
    promptPath,
    summaryPath
  };
}

export function reconcileExpectedProjectData(rawProjectData, expectedManifest, options = {}) {
  const reconciled = reconcileAgentProject({
    projectInitialData: rawProjectData,
    expectedManifest
  });
  return {
    ok: true,
    command: "agent reconcile",
    source: options.source || "metadata",
    fixture: options.fixture || null,
    reconciler: "agent-reconciler",
    result: options.includeRawRows === true ? reconciled : omitMediaRecords(reconciled)
  };
}

export function reconcileProjectData(rawProjectData, options = {}) {
  const projectData = unwrapProjectData(rawProjectData);
  const projectContents = projectData.projectContents || {};
  const mediaItems = Array.isArray(projectContents.media) ? projectContents.media : [];
  const media = mediaItems.map(parseMediaItem);
  const videos = media.filter((item) => item.kind === "video");
  const images = media.filter((item) => item.kind === "image");
  const taggedVideos = videos.filter((item) => item.rowIds.length);
  const taggedImages = images.filter((item) => item.rowIds.length || item.afid);
  const rowSummary = summarizeRows(taggedVideos);

  const result = {
    ok: true,
    command: "agent reconcile",
    source: options.source || "metadata",
    fixture: options.fixture || null,
    project: {
      id: projectData.projectId || "",
      name: projectData.projectName || ""
    },
    media: {
      total: media.length,
      images: images.length,
      videos: videos.length,
      unknown: media.filter((item) => item.kind === "unknown").length,
      taggedImages: taggedImages.length,
      taggedVideos: taggedVideos.length
    },
    rows: rowSummary,
    limitations: [
      "CLI fallback maps videos by [V#-S#] prompt tags only.",
      "Image mapping is inferential unless AFID tags are present.",
      "Use the bridge/native reconciler for authoritative queue ownership."
    ]
  };
  if (options.includeRawRows === true) {
    result.mediaRecords = media;
  }
  return result;
}

export function buildRetryPayload(rowIds = [], options = {}) {
  const project = options.project || "current";
  const issue = String(options.issue || "").trim();
  const issueLabels = normalizeIssueLabels(options.issues || issue);
  const issueChips = issueLabels.map(issueChipKey);
  const normalizedRows = uniqueStrings(rowIds.map(normalizeRowId));
  const expectedDialogue = normalizeStringList(options.expectedDialogue || options.dialogue || options.dialogues);
  const notes = String(options.notes || "").trim();
  const latestMediaContext = normalizeLatestMediaContext(normalizedRows, options.latestMediaContext || options.latestMedia);
  const mode = normalizeRetryMode(options.mode || "video-only");
  return {
    project,
    runId: options.runId || project,
    taskId: options.taskId || "",
    rows: normalizedRows,
    rowIds: normalizedRows,
    mode,
    issue,
    issueLabel: issueLabels[0] || issue,
    issues: issueChips,
    issueChips,
    notes,
    expectedDialogue,
    latestMediaContext,
    ...(compactString(options.projectId) ? { projectId: compactString(options.projectId) } : {}),
    ...(compactString(options.tabId) ? { tabId: compactString(options.tabId) } : {}),
    ...(compactString(options.laneId) ? { laneId: compactString(options.laneId) } : {}),
    ...(isSubmitConfirmCreditsAuthorized(options) ? { confirmCredits: true } : {}),
    ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {}),
    retryPrompts: normalizedRows.map((rowId) => ({
      rowId,
      prompt: buildAgentRetryPrompt({
        sceneId: rowId,
        issues: issueLabels.length ? issueLabels : issue,
        details: notes,
        expectedDialogue
      })
    })),
    retry: normalizedRows.map((rowId) => ({
      rowId,
      issue,
      issues: issueChips,
      notes,
      expectedDialogue,
      latestMediaContext: latestMediaContext[rowId] || null,
      action: "regenerate_targeted_row"
    }))
  };
}

export async function readJsonRows(sourcePath, options = {}) {
  const absolutePath = path.resolve(options.cwd || process.cwd(), sourcePath);
  const source = await readJsonFile(absolutePath);
  if (Array.isArray(source)) return source;
  if (Array.isArray(source.rows)) return source.rows;
  if (Array.isArray(source.result?.rows)) return source.result.rows;
  return [];
}

export async function evaluateTranscriptRows(rows = [], options = {}) {
  const outputRows = [];
  for (const row of Array.isArray(rows) ? rows : []) {
    const transcriptText = row.transcript || (row.transcriptPath
      ? await fs.readFile(path.resolve(options.cwd || process.cwd(), row.transcriptPath), "utf8")
      : "");
    const qa = evaluateTranscriptQa({
      expectedLines: row.expectedDialogue || row.expectedLines || [],
      requiredPhrases: row.requiredPhrases || [],
      extraPhraseWarnings: row.extraPhraseWarnings || [],
      transcriptText,
      aliasMap: options.aliasMap
    });
    const issueChips = normalizeIssueLabels(row.issueChips || []);
    const retryPrompt = options.generateRetryPrompts === false || (qa.level === "pass" && !issueChips.length)
      ? ""
      : buildAgentRetryPrompt({
          sceneId: row.rowId,
          issues: issueChips.length ? issueChips : issuesFromQa(qa),
          details: row.notes || "",
          expectedDialogue: expectedDialogueText(row.expectedDialogue || row.expectedLines || [])
        });
    outputRows.push({
      rowId: row.rowId,
      level: qa.level,
      summary: qa.summary,
      issues: qa.issues,
      lines: qa.lines,
      retryPrompt
    });
  }
  return {
    ok: true,
    command: "qa transcripts",
    rows: outputRows,
    summary: summarizeQa(outputRows)
  };
}

export function planAgentArtifacts(input = {}, options = {}) {
  const rows = extractReconciledRows(input);
  const plan = planAgentRunArtifacts({
    runName: options.runName || input.runName || input.name || "Agent Run",
    outputRoot: options.outputRoot || input.outputRoot || undefined,
    runSlug: options.runSlug || input.runSlug || undefined,
    rows,
    latestOnly: Object.hasOwn(options, "latestOnly")
      ? options.latestOnly !== false
      : (Object.hasOwn(options, "onlyLatest") ? options.onlyLatest !== false : true),
    includeImages: options.includeImages,
    includeVideos: options.includeVideos,
    qaStatuses: qaStatusesFromOnly(options.only || options.qaStatus || options.qaStatuses),
    retryPrompts: options.retryPrompts || input.retryPrompts || {},
    reservedTargetPaths: options.reservedTargetPaths || input.reservedTargetPaths || [],
    reservedArtifactKeys: options.reservedArtifactKeys || input.reservedArtifactKeys || [],
    filenameStyle: options.filenameStyle || input.filenameStyle || "",
    filenameTemplatePrefix: options.filenameTemplatePrefix || input.filenameTemplatePrefix || "",
    filenameTemplateIndex: options.filenameTemplateIndex || input.filenameTemplateIndex || "",
    filenameTemplatePromptPart: options.filenameTemplatePromptPart || input.filenameTemplatePromptPart || "",
    filenameTemplateDate: options.filenameTemplateDate || input.filenameTemplateDate || "",
    filenameTemplateSuffix: options.filenameTemplateSuffix || input.filenameTemplateSuffix || "",
    filenameTemplateSeparator: options.filenameTemplateSeparator || input.filenameTemplateSeparator || "",
    imageResolution: options.imageResolution || input.imageResolution || "",
    videoResolution: options.videoResolution || input.videoResolution || ""
  });
  return {
    ok: true,
    command: "agent artifacts download-plan",
    plan
  };
}

export async function readJsonFile(filePath) {
  return JSON.parse(await fs.readFile(filePath, "utf8"));
}

function unwrapProjectData(raw) {
  if (raw?.result?.data?.json) return raw.result.data.json;
  if (raw?.data?.json) return raw.data.json;
  if (raw?.json?.projectContents) return raw.json;
  if (raw?.projectContents) return raw;
  return {};
}

function parseMediaItem(item = {}) {
  const prompt = extractPromptText(item);
  const rowIds = extractRowIds(prompt);
  const afid = extractAfid(prompt);
  const kind = item.video || item.generatedVideo ? "video" : item.image || item.generatedImage ? "image" : "unknown";
  return {
    mediaId: item.name || item.mediaId || item.id || "",
    workflowId: item.workflowId || item.image?.generatedImage?.workflowId || "",
    workflowStepId: item.workflowStepId || "",
    createTime: item.mediaMetadata?.createTime || item.createTime || "",
    kind,
    prompt,
    rowIds,
    afid
  };
}

function extractPromptText(item = {}) {
  const values = [
    item.video?.generatedVideo?.prompt,
    item.image?.generatedImage?.prompt,
    item.mediaMetadata?.mediaTitle,
    item.mediaMetadata?.requestData?.prompt,
    ...(item.mediaMetadata?.requestData?.promptInputs || []).flatMap((input = {}) => [
      input.textInput,
      ...(input.structuredPrompt?.parts || []).map((part = {}) => part.text)
    ])
  ];
  return uniqueStrings(values).join("\n");
}

function extractRowIds(text = "") {
  const rowIds = [];
  for (const match of String(text).matchAll(/\[(V\d+-S\d+)\]/gi)) {
    rowIds.push(normalizeRowId(match[1]));
  }
  return uniqueStrings(rowIds);
}

function extractAfid(text = "") {
  const match = String(text).match(/\bAFID:([A-Z0-9_-]+)\b/i);
  return match ? match[1].toUpperCase() : "";
}

function summarizeRows(taggedVideos = []) {
  const versionsByRow = new Map();
  for (const item of taggedVideos) {
    for (const rowId of item.rowIds) {
      const versions = versionsByRow.get(rowId) || [];
      versions.push({
        mediaId: item.mediaId,
        workflowId: item.workflowId,
        workflowStepId: item.workflowStepId,
        createTime: item.createTime
      });
      versionsByRow.set(rowId, versions);
    }
  }

  const present = [...versionsByRow.keys()].sort(compareRowIds);
  const expected = inferExpectedRows(present);
  const expectedSet = new Set(expected);
  const missing = expected.filter((rowId) => !versionsByRow.has(rowId));
  const duplicates = present.filter((rowId) => (versionsByRow.get(rowId) || []).length > 1);
  const versions = {};

  for (const rowId of present) {
    const rowVersions = (versionsByRow.get(rowId) || []).sort(compareByCreateTime);
    versions[rowId] = rowVersions.map((version, index) => ({
      ...version,
      latest: index === rowVersions.length - 1
    }));
  }

  return {
    expected: expected.length,
    present: present.filter((rowId) => expectedSet.size ? expectedSet.has(rowId) : true).length,
    presentRows: present,
    missingRows: missing,
    duplicateRows: duplicates,
    versions
  };
}

function inferExpectedRows(presentRows = []) {
  const groups = new Map();
  for (const rowId of presentRows) {
    const match = rowId.match(/^(V\d+)-S(\d+)$/);
    if (!match) continue;
    const group = groups.get(match[1]) || [];
    group.push(Number.parseInt(match[2], 10));
    groups.set(match[1], group);
  }
  const [version, numbers] = [...groups.entries()].sort((a, b) => b[1].length - a[1].length)[0] || [];
  if (!version || !numbers?.length) return presentRows;
  const max = Math.max(...numbers);
  return Array.from({ length: max }, (_, index) => `${version}-S${index + 1}`);
}

function compareByCreateTime(a, b) {
  return String(a.createTime || "").localeCompare(String(b.createTime || ""));
}

function compareRowIds(a, b) {
  const pa = parseRowId(a);
  const pb = parseRowId(b);
  if (pa.version !== pb.version) return pa.version - pb.version;
  return pa.scene - pb.scene;
}

function parseRowId(rowId = "") {
  const match = normalizeRowId(rowId).match(/^V(\d+)-S(\d+)$/);
  return {
    version: match ? Number.parseInt(match[1], 10) : Number.MAX_SAFE_INTEGER,
    scene: match ? Number.parseInt(match[2], 10) : Number.MAX_SAFE_INTEGER
  };
}

function normalizeRowId(value = "") {
  return String(value || "").trim().replace(/^\[/, "").replace(/\]$/, "").toUpperCase();
}

function uniqueStrings(values = []) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))];
}

function omitMediaRecords(reconciled = {}) {
  const { mediaRecords, ...rest } = reconciled;
  return rest;
}

async function buildReferenceDescriptors(options = {}) {
  const refs = normalizeStringList(options.ref || options.refs || options.reference || options.references);
  const handles = normalizeStringList(options.handle || options.handles);
  const roles = normalizeStringList(options.refRole || options.refRoles || options.role || options.roles);
  const cwd = options.cwd || process.cwd();
  const descriptors = [];
  for (let index = 0; index < refs.length; index += 1) {
    const refPath = path.resolve(cwd, refs[index]);
    const bytes = await fs.readFile(refPath);
    descriptors.push({
      handle: handles[index] || defaultReferenceHandle(index),
      fileName: path.basename(refPath),
      role: roles[index] || defaultReferenceRole(index),
      sha256: crypto.createHash("sha256").update(bytes).digest("hex"),
      bytes: bytes.length,
      path: refPath
    });
  }
  return descriptors;
}

function buildAgentBundleSummary(bundle = {}, paths = {}) {
  return [
    "# Auto Flow Agent Matrix",
    "",
    bundle.inputPath ? `- Prompt file: \`${bundle.inputPath}\`` : "",
    `- Rows built: ${bundle.rowsBuilt}`,
    `- Matrix kind: ${bundle.matrixKind}`,
    `- Input kind: ${bundle.inputKind}`,
    `- Expected images: ${bundle.expectedImages}`,
    `- Expected videos: ${bundle.expectedVideos}`,
    paths.manifestPath ? `- Manifest: \`${paths.manifestPath}\`` : "",
    paths.promptPath ? `- Prompt: \`${paths.promptPath}\`` : "",
    "",
    "Use `agent-master-prompt.txt` as the copy-paste prompt for Flow Agent."
  ].filter(Boolean).join("\n");
}

function splitPromptLines(value = "") {
  return String(value || "")
    .replace(/\r\n?/g, "\n")
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function normalizeStringList(value) {
  if (value == null || value === false || value === true) return [];
  const list = Array.isArray(value) ? value : [value];
  return list.flatMap((item) => String(item || "").split(/\r?\n/))
    .map((item) => item.trim())
    .filter(Boolean);
}

function compactString(value = "") {
  return String(value || "").trim();
}

function normalizeIssueLabels(value) {
  return uniqueStrings(normalizeStringList(value).map((issue) => String(issue || "")
    .trim()
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .toLowerCase()));
}

function issueChipKey(issue = "") {
  return String(issue || "").trim().replace(/\s+/g, "_");
}

function normalizeRetryMode(value = "") {
  const normalized = String(value || "").trim().replace(/[_\s]+/g, "-").toLowerCase();
  if (["image-only", "video-only", "images-and-video"].includes(normalized)) return normalized;
  return "video-only";
}

function normalizeLatestMediaContext(rowIds = [], value) {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) return value;
  const mediaIds = normalizeStringList(value);
  const context = {};
  rowIds.forEach((rowId, index) => {
    const mediaId = mediaIds[index] || mediaIds[0] || "";
    if (mediaId) context[rowId] = { mediaId };
  });
  return context;
}

function expectedDialogueText(lines = []) {
  return (Array.isArray(lines) ? lines : [lines]).map((line) => {
    if (line && typeof line === "object") return line.text || line.dialogue || line.line || "";
    return line;
  }).map((line) => String(line || "").trim()).filter(Boolean);
}

function issuesFromQa(qa = {}) {
  const issueTypes = new Set((qa.issues || []).map((issue) => issue.type));
  const issues = [];
  if (issueTypes.has("ending_cutoff")) issues.push("ending cut off");
  if (issueTypes.has("missing_line") || issueTypes.has("missing_required_phrase")) issues.push("missing line");
  if (!issues.length && qa.level && qa.level !== "pass") issues.push("wrong dialogue");
  return issues;
}

function summarizeQa(rows = []) {
  const counts = rows.reduce((acc, row) => {
    acc[row.level] = (acc[row.level] || 0) + 1;
    return acc;
  }, {});
  return {
    total: rows.length,
    pass: counts.pass || 0,
    warn: counts.warn || 0,
    fail: counts.fail || 0,
    needsHumanReview: counts.needs_human_review || 0
  };
}

function extractReconciledRows(input = {}) {
  if (Array.isArray(input)) return input;
  if (Array.isArray(input.rows)) return input.rows;
  if (Array.isArray(input.reconciledRows)) return input.reconciledRows;
  if (Array.isArray(input.result?.rows)) return input.result.rows;
  if (Array.isArray(input.plan?.manifest?.rows)) return input.plan.manifest.rows;
  return [];
}

function qaStatusesFromOnly(value) {
  const values = normalizeStringList(value);
  if (!values.length) return [];
  return values.map((item) => {
    const normalized = item.toLowerCase().replace(/[-\s]+/g, "_");
    if (normalized === "passed") return "pass";
    if (normalized === "failed") return "fail";
    return normalized;
  });
}

function defaultReferenceHandle(index = 0) {
  return index === 0 ? "@image1" : `@image${index + 1}`;
}

function defaultReferenceRole(index = 0) {
  return index === 0 ? "primary reference" : `reference ${index + 1}`;
}
