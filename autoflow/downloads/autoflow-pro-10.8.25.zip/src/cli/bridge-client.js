import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createAgentBridgeRequest } from "../core/agent/agent-bridge-protocol.js";
import {
  getDefaultBrokerSocketPath,
  sendBrokerRequest
} from "../../native-host/broker.js";
import { BROKER_HEALTH_STATES } from "../core/agent/broker-health.js";

const DEFAULT_TIMEOUT_MS = 30000;
const DEFAULT_BROKER_ENSURE_TIMEOUT_MS = 2500;
const BROKER_ENSURE_POLL_MS = 25;
const PACKAGE_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const DEFAULT_BRIDGE_CANDIDATES = [
  "native-host/auto-flow-native-host.mjs",
  "native-host/autoflow-native-host.js",
  "native-host/index.js",
  "native-host/host.js"
];
const WINDOWS_STAGED_NATIVE_HOST_REL = path.join(
  "AppData",
  "Roaming",
  "AutoFlowNativePackage",
  "native-host",
  "auto-flow-native-host.mjs"
);
const brokerEnsureFlights = new Map();
const supervisedBrokers = new Map();

export class BridgeUnavailableError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = "BridgeUnavailableError";
    this.code = "bridge_unavailable";
    this.details = details;
  }
}

export class BridgeResponseError extends Error {
  constructor(message, response = {}) {
    super(message);
    this.name = "BridgeResponseError";
    this.code = response.error?.code || response.code || "bridge_error";
    this.response = response;
  }
}

const FLOW_AUTH_HTTP_401_PATTERN = /\bhttp[_\s-]?401\b|\b401[\s_-]*unauthorized\b|\bunauthorized[\s_-]*401\b/i;

export function isFlowAuthExpiredError(error = {}) {
  const responseError = error?.response?.error || {};
  const details = responseError.details || error?.response?.details || {};
  const httpStatus = Number(details.status || error?.status || 0);
  if (httpStatus === 401) return true;
  const code = String(error?.code || responseError.code || "");
  const message = String(error?.message || responseError.message || "");
  return FLOW_AUTH_HTTP_401_PATTERN.test(`${code} ${message}`);
}

export function createBridgeRequest(type, payload = {}, options = {}) {
  const now = options.now || new Date();
  const requestId = options.requestId || `af-cli-${now.getTime()}-${Math.random().toString(16).slice(2)}`;
  return createAgentBridgeRequest({
    id: requestId,
    type,
    payload,
    auth: {
      mode: "extension_session",
      ...(pairingTokenFromOptions(options) ? { pairingToken: pairingTokenFromOptions(options) } : {})
    },
    session: {
      source: "autoflow_cli_native_bridge",
      clientId: options.clientId || "autoflow-cli"
    }
  });
}

function pairingTokenFromOptions(options = {}) {
  const env = options.env || process.env;
  return String(
    options.pairingToken
    || options.pairingCredential
    || env.AUTOFLOW_PAIRING_TOKEN
    || env.AUTOFLOW_PAIRING_CREDENTIAL
    || env.AUTOFLOW_BRIDGE_TOKEN
    || ""
  ).trim();
}

export async function requestBridge(type, payload = {}, options = {}) {
  const request = createBridgeRequest(type, payload, options);
  const brokerRequired = options.requireBrokerSocket === true || options.serviceWorkerRequired === true;
  const explicitCommand = brokerRequired ? "" : explicitBridgeCommand(options);
  if (!explicitCommand) {
    const socketPath = resolveBridgeSocketPath(options);
    try {
      const response = await requestThroughBroker(socketPath, request, options);
      return bridgeResult(request, response, `unix:${socketPath}`);
    } catch (error) {
      if (shouldAutoStartBroker(error, options, brokerRequired)) {
        const started = await autoStartBrokerDaemon(socketPath, options).catch((startError) => ({
          ok: false,
          error: startError
        }));
        if (started?.ok === true) {
          const response = await sendBrokerRequest(socketPath, request, options);
          return bridgeResult(request, response, `unix:${socketPath}`);
        }
      }
      if (error instanceof BridgeResponseError) throw error;
      if (isAmbiguousBrokerWriteError(error)
        || !commandFallbackAllowed(options)
        || brokerRequired
        || explicitBridgeSocket(options)) {
        throw brokerUnavailableError(error, socketPath);
      }
    }
  }

  if (!commandFallbackAllowed(options)) {
    throw brokerUnavailableError(new Error("Auto Flow native broker socket is unavailable."), resolveBridgeSocketPath(options));
  }
  const bridgeCommand = resolveBridgeCommand(options);
  if (!bridgeCommand) {
    throw new BridgeUnavailableError("Auto Flow native bridge host was not found.", {
      candidates: listNativeHostCandidates(options)
    });
  }

  const response = await sendNativeMessage(bridgeCommand, request, {
    ...options,
    nativeHostRole: "cli_fallback",
    allowInMemoryFallback: true
  });
  return bridgeResult(request, response, bridgeCommand.display);
}

export async function ensureBroker(options = {}) {
  const socketPath = resolveBridgeSocketPath(options);
  const timeoutMs = boundedPositiveInteger(
    options.brokerEnsureTimeoutMs || options.ensureTimeoutMs,
    DEFAULT_BROKER_ENSURE_TIMEOUT_MS,
    250,
    10000
  );
  const activeStatus = await probeBroker(socketPath, options).catch(() => null);
  if (activeStatus) {
    return {
      ok: true,
      started: false,
      socketPath,
      status: activeStatus,
      healthState: brokerHealthStateFromStatus(activeStatus)
    };
  }
  if (options.ensureBroker === false) {
    throw brokerError("NATIVE_BROKER_UNAVAILABLE", "Auto Flow native broker is unavailable and broker ensure is disabled.", {
      socketPath,
      healthState: BROKER_HEALTH_STATES.BROKER_UNAVAILABLE
    });
  }

  const existingSupervisor = supervisedBrokers.get(socketPath);
  if (existingSupervisor && existingSupervisor.child.exitCode === null && existingSupervisor.child.signalCode === null) {
    const status = await waitForBrokerStatus(socketPath, timeoutMs, options).catch(() => null);
    if (status) {
      return {
        ok: true,
        started: true,
        socketPath,
        supervisorPid: existingSupervisor.supervisorPid,
        status,
        healthState: brokerHealthStateFromStatus(status)
      };
    }
    await stopBrokerSupervisor(socketPath);
  }

  const flight = brokerEnsureFlights.get(socketPath);
  if (flight) return flight;
  const promise = startSupervisedBroker(socketPath, timeoutMs, options);
  brokerEnsureFlights.set(socketPath, promise);
  try {
    return await promise;
  } finally {
    brokerEnsureFlights.delete(socketPath);
  }
}

export async function stopBrokerSupervisor(socketPath) {
  const record = supervisedBrokers.get(String(socketPath || ""));
  if (!record) return { ok: true, stopped: false, socketPath: String(socketPath || "") };
  supervisedBrokers.delete(record.socketPath);
  const child = record.child;
  if (child.exitCode !== null || child.signalCode) return { ok: true, stopped: false, socketPath: record.socketPath };
  child.kill("SIGTERM");
  await Promise.race([
    new Promise((resolve) => child.once("exit", resolve)),
    new Promise((resolve) => setTimeout(resolve, 500))
  ]);
  if (child.exitCode === null && !child.signalCode) child.kill("SIGKILL");
  return { ok: true, stopped: true, socketPath: record.socketPath, pid: child.pid };
}

export function resolveBrokerCommand(options = {}) {
  const env = options.env || process.env;
  const explicit = options.brokerCommand || env.AUTOFLOW_BROKER_COMMAND;
  if (explicit) {
    const parts = splitCommand(explicit);
    if (!parts.length) return null;
    return { command: parts[0], args: parts.slice(1), display: explicit };
  }

  const hostPath = listNativeHostCandidates(options).find((candidate) => fs.existsSync(candidate));
  return hostPath
    ? { command: process.execPath, args: [hostPath], display: hostPath }
    : null;
}

function shouldAutoStartBroker(error, options = {}, brokerRequired = false) {
  const env = options.env || process.env;
  if (env.AUTOFLOW_BRIDGE_AUTOSTART === "0" || env.AUTOFLOW_BRIDGE_AUTOSTART === "false") return false;
  if (options.autoStartBroker === false) return false;
  if (explicitBridgeSocket(options) || explicitBridgeCommand(options)) return false;
  if (!brokerRequired && options.autoStartBroker !== true) return false;
  const code = String(error?.code || "").toUpperCase();
  const causeCode = String(error?.details?.causeCode || "").toUpperCase();
  return code === "NATIVE_BROKER_UNAVAILABLE" && (!causeCode || ["ENOENT", "ECONNREFUSED"].includes(causeCode));
}

async function autoStartBrokerDaemon(socketPath, options = {}) {
  const env = options.env || process.env;
  const cwd = PACKAGE_ROOT;
  const binPath = path.join(PACKAGE_ROOT, "bin/autoflow.js");
  const command = fs.existsSync(binPath) ? process.execPath : "autoflow";
  const args = fs.existsSync(binPath)
    ? [binPath, "bridge", "up", "--foreground", "--port", String(options.wsPort || options.port || env.AUTOFLOW_WS_BROKER_PORT || "auto"), "--json"]
    : ["bridge", "up", "--foreground", "--port", String(options.wsPort || options.port || env.AUTOFLOW_WS_BROKER_PORT || "auto"), "--json"];
  const child = spawn(command, args, {
    cwd,
    detached: true,
    stdio: "ignore",
    env: {
      ...env,
      AUTOFLOW_BRIDGE_AUTOSTART: "0",
      AUTOFLOW_BRIDGE_SOCKET: socketPath
    }
  });
  child.on("error", () => {});
  child.unref?.();
  const deadline = Date.now() + positiveInteger(options.brokerStartTimeoutMs, 2500);
  while (Date.now() < deadline) {
    await delay(100);
    try {
      await sendBrokerRequest(socketPath, createBridgeRequest("status.get", {
        source: "broker_autostart_probe"
      }, {
        ...options,
        clientId: "autoflow-cli-autostart"
      }), {
        ...options,
        timeoutMs: Math.min(1000, positiveInteger(options.timeoutMs, 1000))
      });
      return { ok: true };
    } catch {}
  }
  return {
    ok: false,
    pid: child.pid || 0
  };
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function bridgeResult(request, response, host) {
  if (response?.ok === false || response?.success === false || response?.error) {
    throw new BridgeResponseError(response.error?.message || response.message || "Bridge command failed.", response);
  }
  return {
    request,
    response,
    host
  };
}

export function resolveBridgeSocketPath(options = {}) {
  return options.bridgeSocketPath
    || options.socketPath
    || options.bridgeSocket
    || getDefaultBrokerSocketPath(options);
}

/**
 * Absolute native-host candidates for CLI pair/status/doctor fallback.
 * Order: package moduleRoot (global npm install), Windows staged
 * AutoFlowNativePackage, then cwd-relative legacy paths.
 */
export function listNativeHostCandidates(options = {}) {
  const cwd = options.cwd || process.cwd();
  const env = options.env || process.env;
  const platform = options.platform || process.platform;
  const moduleRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
  const homeDir = options.homeDir
    ? path.resolve(String(options.homeDir))
    : (env.USERPROFILE || env.HOME || os.homedir());

  const candidates = [
    path.join(moduleRoot, "native-host", "auto-flow-native-host.mjs")
  ];

  if (platform === "win32" && homeDir) {
    candidates.push(path.join(homeDir, WINDOWS_STAGED_NATIVE_HOST_REL));
  }

  for (const relative of DEFAULT_BRIDGE_CANDIDATES) {
    candidates.push(path.resolve(cwd, relative));
  }

  // Preserve order while dropping duplicates (Windows path casing).
  const seen = new Set();
  return candidates.filter((candidate) => {
    const key = process.platform === "win32" || platform === "win32"
      ? String(candidate).toLowerCase()
      : String(candidate);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function resolveBridgeCommand(options = {}) {
  const env = options.env || process.env;
  const explicit = options.bridgeCommand || env.AUTOFLOW_BRIDGE_COMMAND;
  if (explicit) {
    const parts = splitCommand(explicit);
    if (!parts.length) return null;
    return {
      command: parts[0],
      args: parts.slice(1),
      display: explicit
    };
  }

  // Prefer package moduleRoot / staged Windows host over cwd so a global
  // Windows `autoflow` install works from any directory (pair/status/doctor).
  for (const absolutePath of listNativeHostCandidates(options)) {
    if (!fs.existsSync(absolutePath)) continue;
    return {
      command: process.execPath,
      args: [absolutePath],
      display: absolutePath
    };
  }

  return null;
}

export function encodeNativeMessage(message) {
  const body = Buffer.from(JSON.stringify(message), "utf8");
  const header = Buffer.alloc(4);
  header.writeUInt32LE(body.length, 0);
  return Buffer.concat([header, body]);
}

export function decodeNativeMessage(buffer) {
  if (!buffer?.length) {
    throw new BridgeUnavailableError("Bridge host returned no output.");
  }

  if (buffer.length >= 4) {
    const length = buffer.readUInt32LE(0);
    if (length > 0 && buffer.length >= length + 4) {
      return JSON.parse(buffer.subarray(4, 4 + length).toString("utf8"));
    }
  }

  const text = buffer.toString("utf8").trim();
  if (!text) throw new BridgeUnavailableError("Bridge host returned empty output.");
  return JSON.parse(text);
}

async function sendNativeMessage(bridgeCommand, request, options = {}) {
  const timeoutMs = positiveInteger(options.timeoutMs, DEFAULT_TIMEOUT_MS);
  const env = {
    ...(options.env || process.env)
  };
  if (options.nativeHostRole) env.AUTOFLOW_NATIVE_HOST_ROLE = options.nativeHostRole;
  if (options.allowInMemoryFallback === true) env.AUTOFLOW_ALLOW_IN_MEMORY_FALLBACK = "1";
  const child = spawn(bridgeCommand.command, bridgeCommand.args, {
    cwd: options.cwd || process.cwd(),
    env,
    stdio: ["pipe", "pipe", "pipe"]
  });

  const stdout = [];
  const stderr = [];
  child.stdout.on("data", (chunk) => stdout.push(chunk));
  child.stderr.on("data", (chunk) => stderr.push(chunk));

  const exit = new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      child.kill("SIGTERM");
      reject(new BridgeUnavailableError("Bridge host timed out.", { timeoutMs, host: bridgeCommand.display }));
    }, timeoutMs);

    child.on("error", (error) => {
      clearTimeout(timer);
      reject(new BridgeUnavailableError(error.message, { host: bridgeCommand.display }));
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code });
    });
  });

  child.stdin.end(encodeNativeMessage(request));
  const { code } = await exit;
  const output = Buffer.concat(stdout);
  if (!output.length) {
    const errorText = Buffer.concat(stderr).toString("utf8").trim();
    throw new BridgeUnavailableError(errorText || `Bridge host exited without a response.`, {
      host: bridgeCommand.display,
      exitCode: code
    });
  }

  const decoded = decodeNativeMessage(output);
  if (code !== 0 && decoded?.ok !== false && decoded?.success !== false && !decoded?.error) {
    throw new BridgeUnavailableError(`Bridge host exited with code ${code}.`, {
      host: bridgeCommand.display,
      exitCode: code
    });
  }
  return decoded;
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function boundedPositiveInteger(value, fallback, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, positiveInteger(value, fallback)));
}

async function requestThroughBroker(socketPath, request, options = {}) {
  try {
    return await sendBrokerRequest(socketPath, request, options);
  } catch (error) {
    if (!shouldEnsureBroker(options) || !isRetryableBrokerUnavailable(error)) throw error;
    await ensureBroker({ ...options, ensureBroker: true });
    return sendBrokerRequest(socketPath, request, options);
  }
}

async function startSupervisedBroker(socketPath, timeoutMs, options = {}) {
  const brokerCommand = resolveBrokerCommand(options);
  if (!brokerCommand) {
    throw brokerError("NATIVE_BROKER_COMMAND_NOT_FOUND", "Auto Flow native broker host was not found for supervised startup.", {
      socketPath,
      healthState: BROKER_HEALTH_STATES.BROKER_UNAVAILABLE
    });
  }

  const env = {
    ...(options.env || process.env),
    AUTOFLOW_NATIVE_HOST_ROLE: "broker_supervisor",
    AUTOFLOW_BRIDGE_SOCKET: socketPath,
    AUTOFLOW_BROKER_SOCKET: socketPath
  };
  const child = spawn(brokerCommand.command, brokerCommand.args, {
    cwd: options.cwd || brokerCommandCwd(brokerCommand),
    env,
    detached: true,
    stdio: "ignore"
  });
  child.unref();
  const record = {
    ok: true,
    started: true,
    socketPath,
    supervisorPid: child.pid,
    child,
    close: () => stopBrokerSupervisor(socketPath)
  };
  supervisedBrokers.set(socketPath, record);
  const startupFailure = new Promise((resolve, reject) => {
    child.once("exit", (code, signal) => {
      if (supervisedBrokers.get(socketPath)?.child === child) supervisedBrokers.delete(socketPath);
      if (code === 0 && !signal) return;
      reject(brokerError(
        "NATIVE_BROKER_SUPERVISOR_EXITED",
        `Auto Flow native broker supervisor exited during bootstrap (code ${code === null ? "null" : code}, signal ${signal || "none"}).`,
        { socketPath, exitCode: code, signal: signal || "" }
      ));
    });
    child.once("error", (error) => {
      if (supervisedBrokers.get(socketPath)?.child === child) supervisedBrokers.delete(socketPath);
      reject(brokerError(
        "NATIVE_BROKER_SPAWN_FAILED",
        error?.message || "Auto Flow native broker supervisor failed to spawn.",
        { socketPath, causeCode: error?.code || "" }
      ));
    });
  });

  try {
    const status = await Promise.race([
      waitForBrokerStatus(socketPath, timeoutMs, options),
      startupFailure
    ]);
    return {
      ok: true,
      started: true,
      socketPath,
      supervisorPid: child.pid,
      status,
      healthState: brokerHealthStateFromStatus(status)
    };
  } catch (error) {
    await stopBrokerSupervisor(socketPath);
    throw brokerError("NATIVE_BROKER_BOOTSTRAP_FAILED", error?.message || String(error || "Auto Flow native broker did not become ready."), {
      socketPath,
      supervisorPid: child.pid,
      healthState: BROKER_HEALTH_STATES.BROKER_UNAVAILABLE,
      causeCode: error?.details?.causeCode || error?.code || ""
    });
  }
}

function brokerCommandCwd(brokerCommand = {}) {
  const display = String(brokerCommand.display || "");
  if (path.isAbsolute(display) && fs.existsSync(display)) {
    return path.dirname(path.dirname(display));
  }
  return process.cwd();
}

async function probeBroker(socketPath, options = {}) {
  const response = await sendBrokerRequest(socketPath, {
    id: `af-broker-probe-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type: "status.get",
    payload: { source: "autoflow_broker_ensure" },
    session: { source: "autoflow_broker_ensure", clientId: "autoflow-broker-supervisor" }
  }, {
    ...options,
    timeoutMs: boundedPositiveInteger(options.brokerProbeTimeoutMs, 250, 50, 2000)
  });
  return response?.ok === true ? response : null;
}

async function waitForBrokerStatus(socketPath, timeoutMs, options = {}) {
  const deadline = Date.now() + timeoutMs;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const status = await probeBroker(socketPath, options);
      if (status) return status;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, BROKER_ENSURE_POLL_MS));
  }
  throw brokerError("NATIVE_BROKER_BOOTSTRAP_TIMEOUT", `Auto Flow native broker did not become ready within ${timeoutMs}ms.`, {
    socketPath,
    timeoutMs,
    healthState: BROKER_HEALTH_STATES.BROKER_UNAVAILABLE,
    causeCode: lastError?.code || ""
  });
}

function brokerHealthStateFromStatus(response = {}) {
  return response?.payload?.health?.state
    || response?.payload?.bridge?.health?.state
    || response?.payload?.bridge?.healthState
    || (response?.payload?.bridge?.extensionConnected === false
      ? BROKER_HEALTH_STATES.EXTENSION_DISCONNECTED
      : BROKER_HEALTH_STATES.READY);
}

function isAmbiguousBrokerWriteError(error = {}) {
  return error?.code === "NATIVE_BROKER_WRITE_AMBIGUOUS" || error?.details?.writeStarted === true;
}

function isRetryableBrokerUnavailable(error = {}) {
  if (isAmbiguousBrokerWriteError(error)) return false;
  if (error?.code === "NATIVE_BROKER_UNAVAILABLE") return true;
  return ["ENOENT", "ECONNREFUSED", "ECONNRESET", "EPIPE"].includes(String(error?.details?.causeCode || ""));
}

function shouldEnsureBroker(options = {}) {
  if (options.ensureBroker === false) return false;
  const env = options.env || process.env;
  return options.ensureBroker === true || options.superviseBroker === true || env.AUTOFLOW_SUPERVISE_BROKER === "1";
}

function brokerUnavailableError(error = {}, socketPath = "") {
  const details = error?.details || {};
  const ambiguousWrite = isAmbiguousBrokerWriteError(error);
  return new BridgeUnavailableError(
    ambiguousWrite
      ? "Auto Flow native broker write result is ambiguous; the request was not retried."
      : "Auto Flow native broker socket is unavailable.",
    {
      socketPath,
      code: error?.code || "NATIVE_BROKER_UNAVAILABLE",
      healthState: details.healthState || (ambiguousWrite
        ? BROKER_HEALTH_STATES.AMBIGUOUS_WRITE
        : BROKER_HEALTH_STATES.BROKER_UNAVAILABLE),
      details
    }
  );
}

function brokerError(code, message, details = {}) {
  const error = new Error(message);
  error.code = code;
  error.details = details;
  return error;
}

function splitCommand(value = "") {
  const matches = String(value).match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
  return matches.map((part) => {
    if ((part.startsWith('"') && part.endsWith('"')) || (part.startsWith("'") && part.endsWith("'"))) {
      return part.slice(1, -1);
    }
    return part;
  });
}

function explicitBridgeCommand(options = {}) {
  const env = options.env || process.env;
  return options.bridgeCommand || env.AUTOFLOW_BRIDGE_COMMAND || "";
}

function explicitBridgeSocket(options = {}) {
  const env = options.env || process.env;
  return options.bridgeSocketPath
    || options.socketPath
    || options.bridgeSocket
    || env.AUTOFLOW_BRIDGE_SOCKET
    || env.AUTOFLOW_BROKER_SOCKET
    || "";
}

function commandFallbackDisabled(options = {}) {
  const env = options.env || process.env;
  return options.commandFallback === false
    || options.disableCommandFallback === true
    || env.AUTOFLOW_DISABLE_BRIDGE_COMMAND_FALLBACK === "1";
}

function commandFallbackAllowed(options = {}) {
  const env = options.env || process.env;
  return !commandFallbackDisabled(options)
    && (options.commandFallback === true
      || options.allowInMemoryFallback === true
      || env.AUTOFLOW_ALLOW_IN_MEMORY_FALLBACK === "1");
}
