import { agentVideoTagFromImageAuditId, extractAgentImageAuditId, extractAgentVideoTag, parseAgentProjectMetadata } from "../core/agent/agent-project-metadata.js";
import { buildMediaRedirectUrl, buildMediaThumbnailUrl } from "../core/contracts/api.js";
import { DEFAULT_DOWNLOAD_FILENAME_STYLE } from "../core/gallery/download-filename-options.js";
import { planMediaDownloads } from "../core/gallery/media-ledger.js";

export function galleryMediaFromProjectMetadata(projectInitialData = {}, options = {}) {
  const records = parseAgentProjectMetadata(projectInitialData)
    .filter(isGeneratedSuccessfulMediaRecord)
    .map((record, index) => normalizeGalleryMediaRecord(record, {
      index,
      projectId: options.projectId
    }))
    .filter((record) => record.mediaId && (record.kind === "image" || record.kind === "video"));
  return filterGalleryMedia(records, options);
}

export function galleryMediaFromProjectMediaList(input = {}, options = {}) {
  const sourceRecords = Array.isArray(input)
    ? input
    : [
        ...(Array.isArray(input.media) ? input.media : []),
        ...(Array.isArray(input.rows) ? input.rows : []),
        ...(Array.isArray(input.items) ? input.items : [])
      ];
  const seen = new Set();
  const records = [];
  for (const source of sourceRecords) {
    const record = normalizeProjectMediaListRecord(source, {
      index: records.length,
      projectId: options.projectId || input.projectId
    });
    if (!record.mediaId || (record.kind !== "image" && record.kind !== "video")) continue;
    if (!isCompleteGalleryStatus(record.status, source)) continue;
    const key = `${record.kind}:${record.mediaId}`;
    if (seen.has(key)) continue;
    seen.add(key);
    records.push(record);
  }
  return filterGalleryMedia(records, options);
}

export function filterGalleryMedia(records = [], options = {}) {
  const type = normalizeGalleryType(options.type || options.kind || "");
  const latest = parseGalleryLatest(options.latest, 0);
  let filtered = [...records];
  if (type) filtered = filtered.filter((record) => record.kind === type);
  filtered.sort(compareGalleryNewestFirst);
  if (latest > 0) filtered = filtered.slice(0, latest);
  return filtered;
}

export function summarizeGalleryMedia(records = []) {
  return {
    images: records.filter((record) => record.kind === "image").length,
    videos: records.filter((record) => record.kind === "video").length
  };
}

export function selectGalleryDownloadMedia(records = [], options = {}) {
  const mediaId = compactString(options.mediaId || options.mediaID || "");
  if (mediaId) {
    const match = records.find((record) => record.mediaId === mediaId);
    return match ? [match] : [];
  }
  return filterGalleryMedia(records, {
    type: options.type || options.kind || "",
    latest: options.latest
  });
}

export function buildGalleryDownloadPlan(records = [], options = {}) {
  const filenameStyle = options.filenameStyle || DEFAULT_DOWNLOAD_FILENAME_STYLE;
  const items = records.map((record, index) => galleryDownloadItem(record, index, {
    rowId: options.rowId
  }));
  const downloads = planMediaDownloads(items, {
    selectedIds: records.map((record) => record.mediaId),
    folder: options.folder || "Auto Flow Gallery",
    imageResolution: options.imageResolution || "1k",
    videoResolution: options.videoResolution || "720p",
    filenameStyle,
    filenameTemplatePrefix: options.filenameTemplatePrefix || "",
    filenameTemplateIndex: options.filenameTemplateIndex || "",
    filenameTemplatePromptPart: options.filenameTemplatePromptPart || "",
    filenameTemplateDate: options.filenameTemplateDate || "",
    filenameTemplateSuffix: options.filenameTemplateSuffix || "",
    filenameTemplateSeparator: options.filenameTemplateSeparator || "",
    allowDuplicateTargetSuffix: options.allowDuplicateTargetSuffix === true || filenameStyle === "auto_flow"
  });
  return {
    runFolder: "Auto-Flow-Gallery",
    downloads,
    mediaDownloads: downloads,
    files: [],
    skipped: []
  };
}

export function normalizeGalleryType(value = "") {
  const normalized = compactString(value).toLowerCase();
  if (!normalized || normalized === "all") return "";
  if (normalized === "image" || normalized === "images") return "image";
  if (normalized === "video" || normalized === "videos") return "video";
  return normalized;
}

export function parseGalleryLatest(value, fallback = 0) {
  if (value === undefined || value === null || value === "") return fallback;
  const raw = compactString(value);
  if (!/^[1-9]\d*$/.test(raw)) return fallback;
  const parsed = Number.parseInt(raw, 10);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : fallback;
}

export function isValidGalleryLatest(value) {
  if (value === undefined || value === null || value === "") return true;
  return parseGalleryLatest(value, 0) > 0;
}

export function galleryMediaListTimeoutMs(options = {}) {
  const value = options.mediaListTimeoutMs || options.galleryTimeoutMs || options.timeoutMs;
  if (value === undefined || value === null || value === "" || value === true || value === false) return undefined;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

export function isKnownGalleryType(value = "") {
  const raw = compactString(value).toLowerCase();
  return !raw || raw === "all" || raw === "image" || raw === "images" || raw === "video" || raw === "videos";
}

function normalizeGalleryMediaRecord(record = {}, options = {}) {
  const mediaId = compactString(record.mediaId);
  const kind = normalizeGalleryType(record.kind);
  const rowId = galleryRowIdForRecord(record, options.rowId);
  return {
    mediaId,
    kind,
    type: kind,
    status: "complete",
    rowId,
    workflowId: compactString(record.workflowId),
    workflowStepId: compactString(record.workflowStepId),
    createTime: compactString(record.createTime),
    updateTime: compactString(record.updateTime),
    prompt: compactString(record.prompt),
    title: compactString(record.title),
    videoTag: record.videoTag || null,
    imageAuditId: record.imageAuditId || null,
    inputMediaIds: Array.isArray(record.inputMediaIds) ? record.inputMediaIds : [],
    projectId: compactString(record.projectId || options.projectId),
    index: options.index || 0
  };
}

function normalizeProjectMediaListRecord(record = {}, options = {}) {
  const mediaId = compactString(record.mediaId || record.id || record.name);
  const kind = normalizeGalleryType(record.kind || record.type || record.mediaType);
  const imageAuditId = record.imageAuditId || extractAgentImageAuditId(`${record.prompt || ""}\n${record.title || ""}`);
  const rowId = galleryRowIdForRecord({
    ...record,
    imageAuditId,
    videoTag: record.videoTag || record.rowTag || record.rowId || extractAgentVideoTag(`${record.prompt || ""}\n${record.title || ""}`)
  }, options.rowId);
  const status = normalizeGalleryStatus(galleryStatusValue(record));
  return {
    mediaId,
    kind,
    type: kind,
    status,
    rowId,
    workflowId: compactString(record.workflowId),
    workflowStepId: compactString(record.workflowStepId),
    mediaGenerationId: compactString(record.mediaGenerationId),
    createTime: compactString(record.createTime || record.createdAt),
    updateTime: compactString(record.updateTime || record.updatedAt),
    prompt: compactString(record.prompt),
    title: compactString(record.title),
    videoTag: record.videoTag || rowId || null,
    imageAuditId,
    inputMediaIds: Array.isArray(record.inputMediaIds) ? record.inputMediaIds : [],
    projectId: compactString(record.projectId || options.projectId),
    index: options.index || 0,
    source: compactString(record.source),
    matchMethod: compactString(record.matchMethod)
  };
}

function normalizeGalleryStatus(value = "") {
  const raw = compactString(value);
  if (!raw) return "complete";
  const upper = raw.toUpperCase();
  if (/(^|_)(SUCCESS|SUCCESSFUL|SUCCEEDED|COMPLETE|COMPLETED|READY)$/.test(upper)) return "complete";
  if (/(^|_)(FAIL|FAILED|REJECT|REJECTED|CANCEL|CANCELLED|CANCELED)$/.test(upper)) return "failed";
  if (/(^|_)(PENDING|RUNNING|PROCESSING)$/.test(upper)) return "pending";
  return raw.toLowerCase();
}

function isCompleteGalleryStatus(status = "", source = {}) {
  const normalized = normalizeGalleryStatus(status);
  if (normalized === "complete") return true;
  const rawStatus = rawGalleryStatusValue(source);
  if (normalized === "unknown" && !rawStatus && source?.source === "project_initial_data") return true;
  if (source?.status === undefined && source?.rawStatus === undefined && source?.mediaStatus === undefined) return true;
  return false;
}

function galleryStatusValue(record = {}) {
  return compactString(
    record.status
    || rawGalleryStatusValue(record)
  );
}

function rawGalleryStatusValue(record = {}) {
  return compactString(
    record.rawStatus
    || record.mediaGenerationStatus
    || record.mediaStatus?.mediaGenerationStatus
    || record.mediaStatus?.status
    || (typeof record.mediaStatus === "string" ? record.mediaStatus : "")
  );
}

function isGeneratedSuccessfulMediaRecord(record = {}) {
  const raw = record.raw && typeof record.raw === "object" ? record.raw : {};
  if (record.kind === "image" && !raw.image?.generatedImage) return false;
  if (record.kind === "video" && !raw.video?.generatedVideo) return false;
  if (hasPendingOperation(raw)) return false;
  const status = mediaGenerationStatus(raw);
  if (!status) return true;
  return /SUCCESS|SUCCEEDED|COMPLETE|COMPLETED|READY/i.test(status);
}

function mediaGenerationStatus(raw = {}) {
  return compactString(
    raw.mediaMetadata?.mediaStatus?.mediaGenerationStatus
    || raw.mediaMetadata?.mediaStatus?.status
    || raw.mediaMetadata?.generationStatus
    || raw.mediaStatus?.mediaGenerationStatus
    || raw.status
  );
}

function hasPendingOperation(raw = {}) {
  const operation = raw.video?.operation || raw.image?.operation || raw.operation || null;
  if (!operation || typeof operation !== "object") return false;
  if (operation.error) return true;
  return operation.done === false;
}

function galleryDownloadItem(record = {}, index = 0, options = {}) {
  const pluralKind = record.kind === "image" ? "images" : "videos";
  const rowId = galleryRowIdForRecord(record, options.rowId);
  const prompt = promptWithRowId(record.prompt || record.title || `${record.kind || "media"} ${index + 1}`, rowId);
  return {
    id: `agent-gallery:${record.mediaId}`,
    mediaId: record.mediaId,
    kind: pluralKind,
    projectId: record.projectId || "",
    taskNumber: index + 1,
    mediaIndex: index,
    title: record.title || `${record.kind || "media"} ${index + 1}`,
    prompt,
    source: "flow-project",
    matchMethod: "gallery_media_id",
    workflowId: record.workflowId || "",
    workflowStepId: record.workflowStepId || "",
    createdAt: record.createTime || "",
    mediaUrl: buildMediaRedirectUrl({ mediaId: record.mediaId }),
    thumbnailUrl: record.kind === "video"
      ? buildMediaThumbnailUrl({ mediaId: record.mediaId })
      : buildMediaRedirectUrl({ mediaId: record.mediaId })
  };
}

function galleryRowIdForRecord(record = {}, fallback = "") {
  return compactString(
    record.rowId
    || record.videoTag
    || agentVideoTagFromImageAuditId(record.imageAuditId)
    || fallback
    || ""
  );
}

function promptWithRowId(prompt = "", rowId = "") {
  const text = compactString(prompt);
  const tag = compactString(rowId).replace(/^\[|\]$/g, "");
  if (!tag || /\[[^\]]+\]/.test(text)) return text;
  return `[${tag}] ${text || "media"}`;
}

function compareGalleryNewestFirst(left = {}, right = {}) {
  const timeDelta = toTime(right.createTime) - toTime(left.createTime);
  if (timeDelta) return timeDelta;
  return String(right.mediaId || "").localeCompare(String(left.mediaId || ""));
}

function toTime(value = "") {
  const millis = Date.parse(value);
  return Number.isFinite(millis) ? millis : 0;
}

function compactString(value = "") {
  return String(value || "").trim();
}
