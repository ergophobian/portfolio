import fsSync from "node:fs";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { BridgeResponseError, BridgeUnavailableError, isFlowAuthExpiredError, requestBridge } from "./bridge-client.js";
import { resolveDownloadMediaKind } from "../core/media/download-media-kind.js";
import { runAutoFlowTool } from "../mcp/autoflow-tools.js";
import { buildAgentRuntimeContext } from "../core/agent/agent-context.js";
import { planAgentRefAttachments, verifyAgentRefAttachmentChips } from "../core/agent/agent-ref-attachments.js";
import {
  buildAgentRunWaitPollingPlan,
  waitForAgentRunCompletion
} from "../core/agent/agent-run-wait.js";
import {
  buildAgentRunProfile,
  missingRowsFromWaitProgress
} from "../core/agent/agent-run-profile.js";
import { createAgentRunId, prependAgentRunEnvelope } from "../core/agent/agent-run-preflight.js";
import {
  createCreditPolicyState,
  buildStandingCreditPolicy,
  buildCaptainAuthorizedCreditApproval,
  evaluateStandingCreditPolicy,
  isCaptainExplicitlyAuthorized,
  isSubmitConfirmCreditsAuthorized,
  resolveCreditApprovalDecision,
  resolveCreditPersistentApproval
} from "../core/agent/agent-credit-policy.js";
import {
  extractAgentArtifactRows,
  mediaIdsFromAgentArtifactPlan,
  scopeAgentArtifactInput,
  scopeAgentArtifactPlan
} from "../core/agent/agent-artifact-scope.js";
import { buildAgentRenderFallbackInspection } from "../core/agent/agent-render-fallback.js";
import { AGENT_BRIDGE_COMMAND_TYPES } from "../core/agent/agent-bridge-protocol.js";
import { agentTargetPayloadFields } from "../core/agent/agent-submit-guard.js";
import {
  shouldAutoRetryAgentWait,
  summarizeAgentCreditPolicy
} from "../core/agent/agent-supervision-policy.js";
import { normalizeDownloadFilenameOptions } from "../core/gallery/download-filename-options.js";
import {
  createNativeBroker,
  getAutoFlowRuntimeDir,
  getDefaultBrokerSocketPath,
  sendBrokerRequest
} from "../../native-host/broker.js";
import { fetchCdpTargets, summarizeCdpTargets } from "../../scripts/agent-lane-inventory.mjs";
import { buildAgentLiveSmokePack, writeAgentLiveSmokePack } from "../../scripts/create-agent-live-smoke-pack.mjs";
import {
  AUTO_FLOW_NATIVE_HOST_NAME,
  buildNativeHostRepairCommand,
  validateNativeHostExtensionId
} from "../core/native/native-host-manifests.js";
import {
  buildAgentPromptBundleFromFile,
  buildRetryPayload,
  evaluateTranscriptRows,
  planAgentArtifacts,
  readJsonFile,
  readJsonRows,
  reconcileExpectedProjectData,
  reconcileFixture,
  reconcileProjectData,
  writeAgentPromptBundle
} from "./fixture-reconciler.js";
import {
  buildFlowStateSnapshot,
  compactFlowStateError,
  flowStatePreconditionFailure,
  flowStateStatusSummary
} from "../core/agent/flow-state.js";
import {
  buildGalleryDownloadPlan,
  galleryMediaListTimeoutMs,
  galleryMediaFromProjectMediaList,
  isKnownGalleryType,
  isValidGalleryLatest,
  selectGalleryDownloadMedia,
  summarizeGalleryMedia
} from "./gallery-media.js";

const EXIT_OK = 0;
const EXIT_USAGE = 1;
const EXIT_BRIDGE = 2;
const EXIT_AUTH = 3;
const EXIT_PROJECT = 4;
const EXIT_BUSY = 5;
const PACKAGE_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const UNKNOWN_VERSION = "unknown";
const NATIVE_HOST_RESTART_REQUIREMENT = "After repairing the native host manifest, fully quit the affected Chrome testing profile/window and reopen it so Chrome reloads the native messaging manifest.";

const HELP = `Auto Flow CLI

Usage:
  autoflow pair [--code CODE|--reset] [--json]
  autoflow bridge up [--foreground] [--port auto|N] [--json]
  autoflow bridge targets [--project-id PID] [--tab-id TID] [--lane-id LID] [--port PORT] [--json]
  autoflow bridge use --project-id PID --tab-id TID --lane-id LID [--port PORT] [--json]
  autoflow lane use NAME [--project-id PID --tab-id TID] [--port PORT] [--json]
  autoflow lane list [--json]
  autoflow lane unbind NAME [--json]
  autoflow status [--project current] [--json]
  autoflow connect [--project-id PID] [--tab-id TID] [--json]
  autoflow flow state [--project current] [--project-id PID] [--tab-id TID] [--json]
  autoflow targets [--project current] [--json]
  autoflow context [--json]
  autoflow doctor [--fix] [--extension-id ID] [--all-browser-manifests] [--profile-dir DIR] [--json]
  autoflow update [--extension-id ID|--port 9222] [--all-browser-manifests] [--profile-dir DIR] [--dry-run] [--yes] [--json]
  autoflow capabilities [--json]
  autoflow native install-host --extension-id <extension-id> [--doctor] [--fix] [--all-browser-manifests] [--profile-dir DIR] [--dry-run]
  autoflow skill install --target claude|codex|both [--scope user|project] [--force] [--dry-run] [--json]
  autoflow lane inventory --port 9222 --json
  autoflow fleet generate --prompt TEXT [--input prompts.txt] --project-id PID --tab-id TID [--lane-id LID] [--type image|video|t2i|t2v|i2v|v2v] [--model MODEL] [--video-model MODEL] [--aspect-ratio 1:1] [--duration-seconds 4|6|8] [--first-frame-image-media-id MID] [--source-video-media-id MID] [--source-video-mode edit|extend] [--concurrency N] [--count-per-prompt N] [--direct] [--manifest-path manifest.json] [--dry-run] [--json]
  autoflow agent build-matrix --input prompts.txt [--out DIR] [--json]
  autoflow agent prompts --input prompts.txt [--out agent-master-prompt.txt] [--json]
  autoflow agent chat --prompt TEXT [--project current] [--project-id PID] [--tab-id TID] [--wait-reply] [--json]
  autoflow agent run --input prompts.txt [--agent-ref HANDLE=/abs/ref.png] [--autonomy full-self-heal] [--auto-approve rephrases,missing_outputs] [--project current] [--project-id PID] [--tab-id TID] [--lane-id LID] [--confirm-credits] [--dry-run] [--json]
  autoflow agent run-and-wait --input prompts.txt [--agent-ref HANDLE=/abs/ref.png] [--project current] [--project-id PID] [--tab-id TID] [--wait-timeout-ms MS] [--quiet-ms MS] [--poll-ms MS] [--max-unchanged-polls N] [--credit-cap N] [--json]
  autoflow agent context --project current [--project-id PID] [--tab-id TID] [--expected-manifest PATH] [--include-raw] [--json]
  autoflow agent screenshot --project current [--project-id PID] [--tab-id TID] [--out screenshot.jpg] [--json]
  autoflow agent confirm-credits --project-id PID --tab-id TID [--dont-ask-again] [--json]
  autoflow agent refs attach --ref HANDLE=PATH_OR_FLOW [--project-id PID --tab-id TID] [--dry-run] [--json]
  autoflow agent smoke-pack --out .context/agent-live-smoke --json
  autoflow agent reconcile --project current [--expected-manifest PATH] [--fixture PATH] [--json]
  autoflow agent gallery list [--project current] [--project-id PID --tab-id TID] [--type image|video] [--latest N] [--json]
  autoflow agent gallery download --media-id ID --out DIR --project-id PID --tab-id TID [--row-id V1-S1] [--filename-style auto_flow|detailed|prompt_prefix|custom_template] [--video-resolution 1080p] [--json]
  autoflow agent gallery download --type video --latest N --out DIR --project-id PID --tab-id TID [--row-id V1-S1] [--filename-style auto_flow|detailed|prompt_prefix|custom_template] [--video-resolution 1080p] [--json]
  autoflow agent clips download --expected-manifest manifest.json --project-id PID --tab-id TID [--row-id ROW] [--json]
  autoflow agent clips repair --row-id ROW --expected-manifest manifest.json --project-id PID --tab-id TID [--notes TEXT] [--json]
  autoflow agent retry V1-S1 V1-S4 --issue wrong-speaker [--notes TEXT] [--dialogue TEXT] [--json]
  autoflow agent artifacts download-plan --reconciled rows.json [--run-name NAME] [--only passed] [--filename-style auto_flow|detailed|prompt_prefix|custom_template] [--video-resolution 1080p] [--execute --out DIR] [--json]
  autoflow qa transcripts --rows qa-rows.json [--json]
  autoflow retry V1-S1 V1-S4 --issue wrong-speaker [--project current] [--json]

Target options (Agent live submit):
  --project-id PID       Require this Flow project id; fails closed (AGENT_TARGET_MISMATCH) if the active tab differs.
  --tab-id TID           Require this Chrome tab id; prevents a newer Flow tab from stealing the submit.
	  --lane-id LID          Opaque lane label for diagnostics; the safety lock is per Chrome tab.
	  AUTOFLOW_LANE          Per-terminal default named lane. Live commands resolve it to exact project/tab first.
	  --autonomy MODE       none, credit-only, or full-self-heal. Default: full-self-heal.
	  --auto-approve LIST   Comma list: rephrases, missing_outputs, credits. Credits still require explicit approval.
	  --max-self-heal-retries N
	                        Safe at-level Flow Agent repair attempts per affected row. Default: 2.
	  --confirm-credits      Allow credit-confirm fallback only inside a captain-authorized batch.
	  --captain-authorized   Mark this batch as captain-authorized; known-amount credit prompts auto-confirm and prefer persistent approval.
	  --credit-cap N         Auto-confirm Flow Agent credit dialogs only while cumulative spend remains at or below this cap.
	  --dont-ask-again       On captain-authorized credit approvals, click the persistent "Yes, and don't ask again" choice instead of one-time Yes; ignored for standing-policy approvals.

Live generation preflight:
  Fleet Gen is the default generation engine. Use 'autoflow fleet generate'
  for new image/video batches, then use Agent Mode and DOM/API routes only when
  the workflow explicitly needs Agent repair, legacy queue behavior, or fallback.
  Before a live run, choose the image model, video model, image/video aspect ratios,
  outputs per row, video length, Return silent videos setting, and exact credit approval.
  Default to full-self-heal: submit intent, let Flow Agent repair safe policy/missing-output
  failures, and retry only affected rows before escalating hard blockers.
  Do not rely on CLI/MCP defaults for paid or user-facing batches.

Model cost context:
  Run 'autoflow context --json' before planning a live run.
  Cheapest/cost-safe video default: Veo 3.1 - Lite [Lower Priority].
  Omni Flash is not the cheapest; use it for Omni-specific workflows after approval.

Bridge options:
  --bridge-command CMD   Native host command. Defaults to native-host/* when present.
  --bridge-socket PATH   Native broker unix socket path (or set AUTOFLOW_BRIDGE_SOCKET).
  --timeout-ms MS        Native bridge timeout. Defaults to 30000.

Diagnostics (two separate doctors, they check different layers):
  autoflow doctor                        Live bridge only: pairing, auth, active project, queue. Needs a paired bridge. Does NOT check the native-host manifest/install.
  autoflow native install-host --doctor  Native-host manifest/install only: manifest path, allowed origin, launcher/executable, registry. Needs no bridge. Does NOT check pairing or Flow state.
  When setup fails, run the manifest doctor first (works before pairing), then the bridge doctor after you pair.

External usage (driving Auto Flow from another project):
  The CLI is cwd-independent: all file paths resolve against the current directory.
  Point it at a paired bridge with --bridge-socket PATH (or AUTOFLOW_BRIDGE_SOCKET),
  or --bridge-command CMD (or AUTOFLOW_BRIDGE_COMMAND). Run 'autoflow pair' first.
  Concurrent live submits to the same target return AGENT_TARGET_BUSY (exit 5); retry shortly.

Examples:
  autoflow status --json
  autoflow flow state --json
  autoflow targets --json
  autoflow lane use fruit-vids --project-id 3f9f46f3-... --tab-id 1234 --json
  AUTOFLOW_LANE=fruit-vids autoflow agent context --json
  autoflow context --json
  autoflow update --port 9222 --all-browser-manifests --yes
  autoflow lane inventory --port 9222 --json
  autoflow fleet generate --prompt "a red apple on a wooden table" --project-id 3f9f46f3-... --tab-id 1234 --direct --json
  autoflow native install-host --extension-id aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa --doctor --all-browser-manifests
  autoflow skill install --target both --force
  autoflow agent build-matrix --input prompts.txt --out .autoflow/run-1 --json
  autoflow agent smoke-pack --out .context/agent-live-smoke --json
  autoflow agent chat --prompt "What is the latest visible Agent state?" --project-id 3f9f46f3-... --tab-id 1234 --wait-reply --json
  autoflow agent run --input prompts.txt --agent-ref HOST_001=/abs/host.png --project-id 3f9f46f3-... --tab-id 1234 --json
  autoflow agent run-and-wait --input prompts.txt --project-id 3f9f46f3-... --tab-id 1234 --quiet-ms 45000 --poll-ms 5000 --wait-timeout-ms 1200000 --json
  autoflow agent context --project current --json
  autoflow agent confirm-credits --project-id 3f9f46f3-... --tab-id 1234 --json
  autoflow agent refs attach --ref HOST_001=flow:V1-S1/media-id --dry-run --json
  autoflow agent reconcile --project current --fixture .context/flow-agent-poc/ghkcu-boxing-simple-format/latest-flow-projectInitialData.raw.json
  autoflow agent gallery list --project-id 3f9f46f3-... --tab-id 1234 --json
  autoflow agent gallery download --type video --latest 1 --out ./downloads --project-id 3f9f46f3-... --tab-id 1234 --row-id V1-S1 --filename-style auto_flow --json
  autoflow agent retry V1-S1 V1-S4 --issue wrong-speaker --json
  autoflow qa transcripts --rows qa-rows.json --json`;

export async function runCli(argv = [], io = {}) {
  const stdout = io.stdout || process.stdout;
  const stderr = io.stderr || process.stderr;
  let parsed;
  let options = {
    cwd: io.cwd || process.cwd(),
    env: io.env || process.env,
    json: argv.some((token) => /^--json(?:=|$)/.test(String(token || "")))
  };

  try {
    parsed = parseArgs(argv);
    options = {
      ...parsed.options,
      cwd: io.cwd || process.cwd(),
      env: io.env || process.env
    };
  } catch (error) {
    writeError(stderr, options, {
      code: "invalid_option",
      message: error.message || String(error)
    });
    return EXIT_USAGE;
  }

  if (parsed.options.version) {
    stdout.write(`autoflow ${await readPackageVersion()}\n`);
    return EXIT_OK;
  }

  if (parsed.options.help || parsed.positionals.length === 0) {
    stdout.write(`${HELP}\n`);
    return EXIT_OK;
  }

  try {
    const [command, subcommand] = parsed.positionals;
    if (command === "pair") return await runPair(options, stdout);
    if (command === "bridge" && subcommand === "up") return await runBridgeUp(options, stdout);
    if (command === "bridge" && subcommand === "targets") return await runBridgeTargets(options, stdout);
    if (command === "bridge" && subcommand === "use") return await runBridgeUse(options, stdout);
    if (command === "lane" && subcommand === "use") return await runNamedLaneUse(parsed.positionals.slice(2), options, stdout);
    if (command === "lane" && subcommand === "list") return await runNamedLaneList(options, stdout);
    if (command === "lane" && subcommand === "unbind") return await runNamedLaneUnbind(parsed.positionals.slice(2), options, stdout);
    if (command === "status") return await runStatus(options, stdout);
    if (command === "connect") return await runConnect(options, stdout);
    if (command === "flow" && subcommand === "state") return await runFlowState(options, stdout);
    if (command === "targets" || (command === "flow" && subcommand === "tabs")) return await runTargets(options, stdout);
    if (command === "context") return runContext(options, stdout);
    if (command === "doctor") return await runDoctor(options, stdout);
    if (command === "update") return await runUpdate(options, stdout);
    if (command === "capabilities") return runCapabilities(options, stdout);
    if (command === "native" && subcommand === "install-host") return runNativeInstallHost(options, stdout, stderr);
    if (command === "skill" && subcommand === "install") return await runSkillInstall(options, stdout);
    if (command === "lane" && subcommand === "inventory") return await runLaneInventory(options, stdout);
    if (command === "fleet" && subcommand === "generate") return await runFleetGenerate(options, stdout);
    if (command === "agent" && subcommand === "build-matrix") return await runAgentBuildMatrix(options, stdout);
    if (command === "agent" && subcommand === "prompts") return await runAgentPrompts(options, stdout);
    if (command === "agent" && subcommand === "chat") return await runAgentChat(options, stdout);
    if (command === "agent" && subcommand === "run") return await runAgentRun(options, stdout);
    if (command === "agent" && subcommand === "run-and-wait") return await runAgentRunAndWait(options, stdout);
    if (command === "agent" && subcommand === "context") return await runAgentContext(options, stdout);
    if (command === "agent" && subcommand === "screenshot") return await runAgentScreenshot(options, stdout);
    if (command === "agent" && subcommand === "confirm-credits") return await runAgentConfirmCredits(options, stdout);
    if (command === "agent" && subcommand === "refs" && parsed.positionals[2] === "attach") return await runAgentRefsAttach(options, stdout);
    if (command === "agent" && subcommand === "smoke-pack") return await runAgentSmokePack(options, stdout);
    if (command === "agent" && subcommand === "reconcile") return await runAgentReconcile(options, stdout);
    if (command === "agent" && subcommand === "gallery" && parsed.positionals[2] === "list") return await runAgentGalleryList(options, stdout);
    if (command === "agent" && subcommand === "gallery" && parsed.positionals[2] === "download") return await runAgentGalleryDownload(options, stdout);
    if (command === "agent" && subcommand === "clips" && parsed.positionals[2] === "download") return await runAgentClipsDownload(options, stdout);
    if (command === "agent" && subcommand === "clips" && parsed.positionals[2] === "repair") return await runAgentClipsRepair(options, stdout);
    if (command === "agent" && subcommand === "retry") return await runRetry(parsed.positionals.slice(2), options, stdout);
    if (command === "agent" && subcommand === "artifacts" && parsed.positionals[2] === "download-plan") {
      return await runAgentDownloadPlan(options, stdout);
    }
    if (command === "qa" && subcommand === "transcripts") return await runQaTranscripts(options, stdout);
    if (command === "retry") return await runRetry(parsed.positionals.slice(1), options, stdout);

    writeError(stdout, options, {
      code: "unknown_command",
      message: `Unknown command: ${parsed.positionals.join(" ")}`
    });
    return EXIT_USAGE;
  } catch (error) {
    if (error instanceof BridgeUnavailableError) {
      writeBridgeUnavailable(stdout, options, error);
      return EXIT_BRIDGE;
    }
    if (error instanceof BridgeResponseError) {
      if (writeNonTerminalBridgeState(stdout, options, error)) return EXIT_OK;
      writeBridgeError(stdout, options, error);
      return exitCodeForBridgeError(error);
    }
    writeError(stderr, options, {
      code: "cli_error",
      message: error.message
    });
    return EXIT_USAGE;
  }
}

async function readPackageVersion() {
  try {
    const raw = await fs.readFile(path.join(PACKAGE_ROOT, "package.json"), "utf8");
    return JSON.parse(raw).version || "0.0.0";
  } catch {
    return "0.0.0";
  }
}

export function parseArgs(argv = []) {
  const positionals = [];
  const options = {};

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (!token.startsWith("--")) {
      positionals.push(token);
      continue;
    }

    const [rawKey, inlineValue] = token.slice(2).split(/=(.*)/s, 2);
    const key = camelCase(rawKey);
    if (["json", "help", "dryRun", "latestOnly", "includeRaw", "includeRawRows", "confirmCredits", "yesCredits", "dontAskAgain", "persistentApproval", "waitReply", "captainAuthorized", "authorizedBatch", "direct", "executeDirect", "waitUntilDone"].includes(key)) {
      options[key] = inlineValue === undefined || parseBooleanFlagValue(inlineValue);
      continue;
    }

    const next = argv[index + 1];
    if (inlineValue !== undefined) {
      setOption(options, key, inlineValue);
    } else if (next && !next.startsWith("--")) {
      setOption(options, key, next);
      index += 1;
    } else {
      options[key] = true;
    }
  }

  return { positionals, options };
}

async function runFleetGenerate(options, stdout) {
  const promptText = await fleetPromptTextFromOptions(options);
  if (!promptText) {
    writeError(stdout, options, {
      code: "missing_prompt",
      message: "fleet generate requires --prompt TEXT, --prompt-text TEXT, --prompts-text TEXT, or --input prompts.txt."
    });
    return EXIT_USAGE;
  }
  const args = {
    ...options,
    promptsText: promptText,
    referenceImageMediaIds: listOptionValues(options.referenceImageMediaIds || options.referenceImageMediaId || options.refMediaId || options.refMediaIds),
    dryRun: options.dryRun === true,
    direct: options.direct === true,
    executeDirect: options.executeDirect === true,
    waitUntilDone: options.waitUntilDone !== false,
    manifestPath: optionString(options.manifestPath || options.outboxPath || options.outputPath || options.out),
    metadata: fleetCliMetadata(options)
  };
  if (!Object.keys(args.metadata || {}).length) delete args.metadata;
  const result = await runAutoFlowTool("autoflow_fleet_generate", args, {
    cwd: options.cwd || process.cwd(),
    env: options.env || process.env
  });
  writeResult(stdout, options, {
    ...result,
    command: "fleet generate"
  }, humanFleetGenerate);
  if (result.ok === false) {
    return result.code === "INVALID_INPUT" ? EXIT_USAGE : EXIT_BRIDGE;
  }
  return EXIT_OK;
}

async function runAgentBuildMatrix(options, stdout) {
  if (!options.input || options.input === true) {
    writeError(stdout, options, {
      code: "missing_input",
      message: "agent build-matrix requires --input prompts.txt."
    });
    return EXIT_USAGE;
  }
  const bundle = await buildAgentPromptBundleFromFile(String(options.input), options);
  const files = await writeAgentPromptBundle(bundle, options.out, options);
  const result = {
    ok: true,
    command: "agent build-matrix",
    inputKind: bundle.inputKind,
    rowsBuilt: bundle.rowsBuilt,
    matrixKind: bundle.matrixKind,
    expectedImages: bundle.expectedImages,
    expectedVideos: bundle.expectedVideos,
    ...files,
    matrix: options.includeMatrix ? bundle.matrix : undefined,
    manifest: options.includeManifest ? bundle.manifest : undefined
  };
  writeResult(stdout, options, result, () => {
    const pathLine = files.matrixPath ? ` Matrix: ${files.matrixPath}.` : "";
    return `Built ${bundle.rowsBuilt} Agent row${bundle.rowsBuilt === 1 ? "" : "s"}.${pathLine}`;
  });
  return EXIT_OK;
}

async function runAgentPrompts(options, stdout) {
  if (!options.input || options.input === true) {
    writeError(stdout, options, {
      code: "missing_input",
      message: "agent prompts requires --input prompts.txt."
    });
    return EXIT_USAGE;
  }
  const bundle = await buildAgentPromptBundleFromFile(String(options.input), options);
  let promptPath = "";
  if (options.out && options.out !== true) {
    promptPath = pathResolve(options.cwd, options.out);
    await writeTextFile(promptPath, bundle.promptText);
  }
  const result = {
    ok: true,
    command: "agent prompts",
    inputKind: bundle.inputKind,
    rowsBuilt: bundle.rowsBuilt,
    matrixKind: bundle.matrixKind,
    expectedImages: bundle.expectedImages,
    expectedVideos: bundle.expectedVideos,
    promptPath,
    promptText: bundle.promptText,
    manifest: options.includeManifest ? bundle.manifest : undefined
  };
  writeResult(stdout, options, result, () => bundle.promptText);
  return EXIT_OK;
}

async function runAgentChat(options, stdout) {
  const prompt = await agentChatPromptFromOptions(options);
  if (!prompt) {
    writeError(stdout, options, {
      code: "missing_prompt",
      message: "agent chat requires --prompt TEXT or --input prompt.txt."
    });
    return EXIT_USAGE;
  }
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent chat");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const payload = {
    project: options.project || "current",
    mode: options.mode || "agent",
    prompt,
    chatOnly: true,
    ensureManagedAgentInstructions: false,
    ensureNativeSettings: false,
    preserveConversationPanel: true,
    runProfile: buildAgentRunProfile({}, options),
    ...(isSubmitConfirmCreditsAuthorized(options) ? { confirmCredits: true } : {}),
    ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {}),
    ...(options.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(options)
  };
  const request = { type: "agent.prompt.submit", payload };
  const contextPayload = {
    project: options.project || "current",
    includeRaw: options.includeRaw === true,
    ...agentTargetPayloadFields(options)
  };
  if (options.dryRun) {
    writeResult(stdout, options, {
      ok: true,
      command: "agent chat",
      dryRun: true,
      request,
      wait: options.waitReply ? {
        enabled: true,
        request: { type: "agent.context.get", payload: contextPayload }
      } : { enabled: false }
    }, () => "Dry run built Agent chat request; bridge request was not sent.");
    return EXIT_OK;
  }
  const targetError = liveAgentTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }
  const bridgeOptions = {
    ...(await withStoredPairingToken(options)),
    timeoutMs: bridgeRequestTimeoutMs(options),
    serviceWorkerRequired: true,
    commandFallback: false
  };
  try {
    const baseline = options.waitReply
      ? await requestAgentContextSnapshot(contextPayload, bridgeOptions)
      : null;
    const baselineKeys = new Set(latestAgentMessages(baseline).map(agentMessageKey));
    const submitBridgeResult = await requestBridge(request.type, payload, bridgeOptions);
    const submitResponse = unwrapBridgeResponse(submitBridgeResult);
    const wait = options.waitReply
      ? await waitForAgentReply({
        contextPayload,
        bridgeOptions,
        baselineKeys,
        prompt,
        accepted: submitResponse?.submitted === true || submitResponse?.accepted?.ok === true,
        acceptedSignal: submitResponse?.accepted?.signal || "",
        timeoutMs: Number(options.waitTimeoutMs || options.replyTimeoutMs || 60000),
        pollMs: Number(options.pollMs || options.pollIntervalMs || 1000)
      })
      : { enabled: false };
    writeResult(stdout, options, {
      ok: wait.enabled ? wait.ok : true,
      command: "agent chat",
      source: "bridge",
      bridgeHost: submitBridgeResult.host,
      response: submitResponse,
      wait
    }, humanAgentChat);
    return !wait.enabled || wait.ok ? EXIT_OK : EXIT_BRIDGE;
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent chat",
      request,
      waitRequest: options.waitReply ? { type: "agent.context.get", payload: contextPayload } : undefined
    }, "Bridge unavailable; Agent chat request was not sent.");
    return EXIT_BRIDGE;
  }
}

async function runAgentRun(options, stdout) {
  if (!options.input || options.input === true) {
    writeError(stdout, options, {
      code: "missing_input",
      message: "agent run requires --input prompts.txt."
    });
    return EXIT_USAGE;
  }
  const bundle = await buildAgentPromptBundleFromFile(String(options.input), options);
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent run");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const payload = buildAgentRunPayload(bundle, options);
  const request = { type: "agent.prompt.submit", payload };
  if (options.dryRun) {
    writeResult(stdout, options, {
      ok: true,
      command: "agent run",
      dryRun: true,
      bundle: summarizeBundle(bundle),
      request
    }, () => `Dry run built ${bundle.rowsBuilt} Agent row${bundle.rowsBuilt === 1 ? "" : "s"}; bridge request was not sent.`);
    return EXIT_OK;
  }
  const targetError = liveAgentTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      timeoutMs: bridgeRequestTimeoutMs(options) || options.timeoutMs,
      serviceWorkerRequired: true,
      commandFallback: false
    });
    writeResult(stdout, options, {
      ok: true,
      command: "agent run",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      bundle: summarizeBundle(bundle),
      response: unwrapBridgeResponse(bridgeResult)
    }, () => `Agent batch submitted through Auto Flow bridge for ${bundle.rowsBuilt} row${bundle.rowsBuilt === 1 ? "" : "s"}.`);
    return EXIT_OK;
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent run",
      request,
      bundle: summarizeBundle(bundle)
    }, "Bridge unavailable; Agent batch request was not sent.");
    return EXIT_BRIDGE;
  }
}

async function runAgentRunAndWait(options, stdout) {
  if (!options.input || options.input === true) {
    writeError(stdout, options, {
      code: "missing_input",
      message: "agent run-and-wait requires --input prompts.txt."
    });
    return EXIT_USAGE;
  }
  const bundle = await buildAgentPromptBundleFromFile(String(options.input), options);
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent run-and-wait");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const payload = buildAgentRunPayload(bundle, options);
  const request = { type: "agent.prompt.submit", payload };
  const polling = buildAgentRunWaitPollingPlan(options);

  if (options.dryRun) {
    writeResult(stdout, options, {
      ok: true,
      command: "agent run-and-wait",
      dryRun: true,
      bundle: summarizeBundle(bundle),
      request,
      polling,
      autoRetry: buildAutoRetryPlan(options)
    }, () => `Dry run built ${bundle.rowsBuilt} Agent row${bundle.rowsBuilt === 1 ? "" : "s"}; run-and-wait bridge requests were not sent.`);
    return EXIT_OK;
  }

  const targetError = liveAgentTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }

  const bridgeOptions = {
    ...(await withStoredPairingToken(options)),
    timeoutMs: bridgeRequestTimeoutMs(options),
    serviceWorkerRequired: true,
    commandFallback: false
  };
  try {
    const submitBridgeResult = await requestBridge(request.type, payload, bridgeOptions);
    const submitResponse = unwrapBridgeResponse(submitBridgeResult);
    const resolvedRunId = agentRunId(options, payload, bundle);
    const metadataPayload = {
      project: options.project || "current",
      expectedManifest: bundle.manifest,
      runId: resolvedRunId,
      ...agentTargetPayloadFields(options)
    };
    const contextPayload = {
      project: options.project || "current",
      expectedManifest: bundle.manifest,
      includeRaw: false,
      runId: resolvedRunId,
      ...agentTargetPayloadFields(options)
    };
    let lastAgentContext = null;
    const resolvedAgentActions = new Set();
    const submittedDraftHashes = new Set();
    const creditPolicyState = createCreditPolicyState(buildStandingCreditPolicy(options, options.env || process.env));
    const waitOnce = () => waitForAgentRunCompletion({
      expectedImages: bundle.expectedImages ?? bundle.manifestExpectedImages,
      expectedVideos: bundle.expectedVideos ?? bundle.manifestExpectedVideos,
      timeoutMs: options.waitTimeoutMs || options.runTimeoutMs || options.timeoutMs,
      quietMs: options.quietMs || options.quietDelayMs,
      pollMs: options.pollMs || options.pollIntervalMs,
      stalledNoProgressPolls: options.stalledNoProgressPolls || options.noProgressPolls || options.maxUnchangedPolls,
      defaultMode: options.retryMode,
      reconcile: async () => {
        const bridgeResult = await requestBridge("project.metadata.get", metadataPayload, bridgeOptions);
        const response = unwrapBridgeResponse(bridgeResult);
        const metadata = response.metadata || response.projectInitialData || response;
        return {
          ...reconcileExpectedProjectData(metadata, bundle.manifest, {
            source: "bridge",
            includeRawRows: options.includeRawRows === true
          }),
          bridgeHost: bridgeResult.host
        };
      },
      inspect: async ({ progress, startedAtMs }) => {
        const attemptContextPayload = {
          ...contextPayload,
          progress,
          runStartedAt: new Date(startedAtMs).toISOString(),
          submittedDraftHashes: [...submittedDraftHashes]
        };
        lastAgentContext = await requestAgentContextSnapshot(attemptContextPayload, bridgeOptions).catch(() => null);
        const actionResolution = await maybeResolveAgentActionDuringWait({
          context: lastAgentContext,
          options,
          bridgeOptions,
          resolvedAgentActions,
          submittedDraftHashes,
          runId: contextPayload.runId,
          creditPolicyState
        });
        if (actionResolution) return actionResolution;
        return buildAgentRenderFallbackInspection({
          context: lastAgentContext,
          progress
        });
      }
    });
    let wait = await waitOnce();
    const autoRetry = await maybeRetryMissingAgentRows({
      wait,
      options,
      bundle,
      bridgeOptions,
      waitOnce
    });
    if (autoRetry?.rounds?.length) {
      wait = autoRetry.finalWait || wait;
    }
    writeResult(stdout, options, {
      ok: wait.ok,
      command: "agent run-and-wait",
      source: "bridge",
      bridgeHost: submitBridgeResult.host,
      bundle: summarizeBundle(bundle),
      response: submitResponse,
      wait,
      autoRetry,
      creditPolicy: summarizeAgentCreditPolicy(options, creditPolicyState),
      agentContext: lastAgentContext ? summarizeAgentContextForWait(lastAgentContext) : null
    }, humanAgentRunWait);
    return wait.ok ? EXIT_OK : runWaitExitCode(wait);
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent run-and-wait",
      request,
      bundle: summarizeBundle(bundle),
      polling
    }, "Bridge unavailable; Agent batch request was not sent.");
    return EXIT_BRIDGE;
  }
}

async function runAgentConfirmCredits(options, stdout) {
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent confirm-credits");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const targetError = liveAgentTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }
  const payload = {
    project: options.project || "current",
    persistentApproval: options.dontAskAgain === true || options.persistentApproval === true,
    ...agentTargetPayloadFields(options)
  };
  const request = { type: "agent.credits.confirm", payload };
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      serviceWorkerRequired: true,
      commandFallback: false
    });
    const response = unwrapBridgeResponse(bridgeResult);
    writeResult(stdout, options, {
      ok: true,
      command: "agent confirm-credits",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      response
    }, () => response?.confirmed
      ? "Confirmed the visible Flow Agent credit dialog."
      : "No visible Flow Agent credit dialog was pending.");
    return EXIT_OK;
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent confirm-credits",
      request
    }, "Bridge unavailable; credit dialog was not confirmed.");
    return EXIT_BRIDGE;
  }
}

async function runAgentContext(options, stdout) {
  options = withLaneDefault(options);
  const expectedManifest = await readExpectedManifest(options);
  const payload = {
    project: options.project || "current",
    includeRaw: options.includeRaw === true,
    ...(expectedManifest ? { expectedManifest } : {}),
    ...agentTargetPayloadFields(options)
  };
  const request = { type: "agent.context.get", payload };
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      serviceWorkerRequired: true,
      commandFallback: false
    });
    const response = unwrapBridgeResponse(bridgeResult);
    writeResult(stdout, options, {
      ok: true,
      command: "agent context",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      response
    }, humanAgentScreenContext);
    return EXIT_OK;
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent context",
      request
    }, "Bridge unavailable; live Agent screen context was not read.");
    return EXIT_BRIDGE;
  }
}

async function runAgentScreenshot(options, stdout) {
  options = withLaneDefault(options);
  const payload = {
    project: options.project || "current",
    format: options.format || "jpeg",
    ...(options.quality && options.quality !== true ? { quality: Number(options.quality) } : {}),
    ...(options.fullPage === true ? { fullPage: true } : {}),
    ...agentTargetPayloadFields(options)
  };
  const request = { type: "agent.screenshot.get", payload };
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      serviceWorkerRequired: true,
      commandFallback: false
    });
    const response = unwrapBridgeResponse(bridgeResult);
    const screenshot = response?.screenshot || {};
    const base64 = String(screenshot.dataBase64 || "");
    if (!base64) {
      throw new BridgeResponseError("Agent screenshot response did not include image data.", bridgeResult.response);
    }
    const format = screenshot.format === "png" ? "png" : "jpg";
    const outPath = pathResolve(options.cwd, options.out && options.out !== true
      ? options.out
      : path.join(".context", `autoflow-agent-screenshot-${Date.now()}.${format}`));
    await fs.mkdir(path.dirname(outPath), { recursive: true });
    await fs.writeFile(outPath, Buffer.from(base64, "base64"));
    const safeResponse = {
      ...response,
      screenshot: {
        ...screenshot,
        dataBase64: undefined,
        path: outPath
      }
    };
    writeResult(stdout, options, {
      ok: true,
      command: "agent screenshot",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      path: outPath,
      response: safeResponse
    }, () => `Agent screenshot saved: ${outPath}`);
    return EXIT_OK;
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent screenshot",
      request
    }, "Bridge unavailable; live Agent screenshot was not captured.");
    return EXIT_BRIDGE;
  }
}

async function runAgentRefsAttach(options, stdout) {
  const refs = arrayOption(options.ref || options.refs || options.attachment || options.attachments);
  if (!refs.length) {
    writeError(stdout, options, {
      code: "missing_refs",
      message: "agent refs attach requires at least one --ref HANDLE=PATH_OR_FLOW."
    });
    return EXIT_USAGE;
  }
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent refs attach");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const liveAttach = options.dryRun !== true;
  if (liveAttach) {
    const targetError = liveAgentTargetError(options);
    if (targetError) {
      writeError(stdout, options, targetError);
      return EXIT_USAGE;
    }
  }
  const targetRefs = arrayOption(options.targetRef || options.targetRefs);
  const visibleChips = arrayOption(options.visibleChip || options.visibleChips);
  const plan = planAgentRefAttachments({
    refs,
    targetRefs,
    projectId: options.projectId,
    tabId: options.tabId
  }, {
    liveAttach,
    projectId: options.projectId,
    tabId: options.tabId
  });
  if (plan.ok !== true) {
    writeError(stdout, options, {
      code: plan.code || "AGENT_REF_PLAN_INVALID",
      message: plan.message || "Agent reference attachment plan is invalid.",
      errors: plan.errors || [],
      plan
    });
    return EXIT_USAGE;
  }
  const chipProof = visibleChips.length ? verifyAgentRefAttachmentChips(plan, visibleChips) : null;
  const payload = {
    project: options.project || "current",
    refs,
    targetRefs,
    visibleChips,
    plan: chipProof?.ok === true ? chipProof : plan,
    ...(options.forceAttach === true || options.forceAttachRefs === true ? { forceAttach: true } : {}),
    ...(options.timeoutMs && options.timeoutMs !== true ? { timeoutMs: options.timeoutMs } : {}),
    ...(options.dryRun === true ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(options)
  };
  const request = { type: "agent.refs.attach", payload };
  if (options.dryRun === true) {
    writeResult(stdout, options, {
      ok: true,
      command: "agent refs attach",
      dryRun: true,
      plan,
      chipProof,
      request
    }, () => `Dry run planned ${plan.attachments.length} Agent reference attachment${plan.attachments.length === 1 ? "" : "s"}; bridge request was not sent.`);
    return EXIT_OK;
  }
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      serviceWorkerRequired: true,
      commandFallback: false
    });
    const response = unwrapBridgeResponse(bridgeResult);
    writeResult(stdout, options, {
      ok: true,
      command: "agent refs attach",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      plan,
      chipProof,
      response
    }, () => `Agent reference attach request sent for ${plan.attachments.length} ref${plan.attachments.length === 1 ? "" : "s"}.`);
    return EXIT_OK;
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "agent refs attach",
      request,
      plan,
      chipProof
    }, "Bridge unavailable; Agent reference attachment request was not sent.");
    return EXIT_BRIDGE;
  }
}

async function runPair(options, stdout) {
  if (options.reset) {
    const credentialPath = cliPairingCredentialPath(options);
    await fs.rm(credentialPath, { force: true }).catch(() => {});
    const bridgeResult = await requestBridge("pair.reset", {
      clientName: "autoflow-cli"
    }, {
      ...options,
      serviceWorkerRequired: true,
      autoStartBroker: true
    });
    const response = unwrapBridgeResponse(bridgeResult);
    return writeResult(stdout, options, {
      ok: true,
      command: "pair",
      action: "reset",
      credentialPath,
      response
    }, () => "Auto Flow pairing reset. Run `autoflow pair` to pair again.");
  }
  const type = options.code ? "pair.confirm" : "pair.start";
  const payload = options.code ? { pairingCode: String(options.code) } : { clientName: "autoflow-cli" };
  const bridgeResult = await requestBridge(type, payload, {
    ...options,
    serviceWorkerRequired: true,
    commandFallback: false
  });
  const response = unwrapBridgeResponse(bridgeResult);
  if (options.code && response?.pairingToken) {
    const credentialPath = await writeCliPairingCredential(options, {
      pairingToken: response.pairingToken,
      clientId: response.clientId || options.clientId || "autoflow-cli",
      pairedAt: new Date().toISOString()
    });
    response.pairingCredentialStored = Boolean(credentialPath);
    response.pairingCredentialPath = credentialPath || "";
  }
  const safeResponse = redactPairingToken(response);
  const result = {
    ok: true,
    command: "pair",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    response: safeResponse
  };
  writeResult(stdout, options, result, () => {
    if (options.code) {
      return "Pairing confirmed through Auto Flow bridge.";
    }
    const pairingCode = safeResponse?.pairingCode ? String(safeResponse.pairingCode) : "";
    if (pairingCode) {
      return [
        `Pairing started through Auto Flow bridge. Pairing code: ${pairingCode}`,
        `Next: run  autoflow pair --code ${pairingCode}  to finish pairing.`
      ].join("\n");
    }
    return "Pairing started through Auto Flow bridge. Re-run with --json to read the pairing code, then run: autoflow pair --code <code>";
  });
  return EXIT_OK;
}

async function runBridgeUp(options, stdout) {
  if (options.foreground === true) {
    const broker = createNativeBroker({
      env: options.env,
      socketPath: options.bridgeSocket || options.socketPath || options.bridgeSocketPath || undefined,
      wsEnabled: true,
      wsPort: options.port || options.wsPort || "auto"
    });
    await broker.start();
    const status = broker.statusPayload();
    writeResult(stdout, options, {
      ok: true,
      command: "bridge up",
      foreground: true,
      broker: {
        brokerInstanceId: status.bridge?.brokerInstanceId || "",
        socketPath: status.bridge?.socketPath || "",
        wsUrl: status.bridge?.wsUrl || "",
        httpUrl: status.bridge?.httpUrl || "",
        protocolVersion: status.bridge?.bridgeProtocolVersion || null
      },
      status
    }, (result) => `Auto Flow bridge broker running at ${result.broker.socketPath}; WS ${result.broker.wsUrl || "unavailable"}.`);
    await waitForShutdownSignal(broker);
    return EXIT_OK;
  }

  const binPath = path.join(PACKAGE_ROOT, "bin/autoflow.js");
  const socketPath = options.bridgeSocket
    || options.socketPath
    || options.bridgeSocketPath
    || getDefaultBrokerSocketPath({ env: options.env || process.env });
  const requestedPort = options.port || options.wsPort || "auto";
  const controlTimeoutMs = Math.min(1500, Number(options.timeoutMs || 1500) || 1500);
  const enableExistingBrokerWs = async () => {
    const response = await sendBrokerRequest(socketPath, {
      id: `af-cli-bridge-up-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type: "broker.ws.enable",
      payload: { port: requestedPort },
      session: { source: "autoflow_cli", clientId: "autoflow-cli" }
    }, { timeoutMs: controlTimeoutMs });
    if (response?.ok !== true) {
      const error = new Error(response?.error?.message || "Auto Flow broker did not enable its WS listener.");
      error.code = response?.error?.code || "WS_BROKER_ENABLE_FAILED";
      throw error;
    }
    const status = response?.payload?.status || null;
    if (!response?.payload?.wsUrl || !status?.bridge?.wsUrl) {
      const error = new Error("Auto Flow broker responded without a discoverable WS listener.");
      error.code = "WS_BROKER_ENABLE_INCOMPLETE";
      throw error;
    }
    return { payload: response.payload, status };
  };

  let enabled = null;
  let lastError = null;
  let reusedExistingBroker = false;
  try {
    enabled = await enableExistingBrokerWs();
    reusedExistingBroker = true;
  } catch (error) {
    lastError = error;
  }

  let child = null;
  if (!enabled) {
    child = spawnDetachedBroker(binPath, options, socketPath);
    const deadline = Date.now() + (Number(options.timeoutMs || 5000) || 5000);
    while (Date.now() < deadline) {
      await sleep(100);
      try {
        enabled = await enableExistingBrokerWs();
        break;
      } catch (error) {
        lastError = error;
      }
    }
  }

  if (!enabled) {
    const upgradeRequired = lastError?.code === "UNKNOWN_COMMAND" || lastError?.code === "INVALID_COMMAND";
    writeError(stdout, options, {
      code: upgradeRequired ? "WS_BROKER_UPGRADE_REQUIRED" : "WS_BROKER_UNAVAILABLE",
      message: upgradeRequired
        ? "The active Auto Flow broker predates runtime WS activation. Update/restart the native host, then run autoflow bridge up again."
        : "Auto Flow bridge broker did not expose a WS listener before timeout.",
      details: {
        pid: child?.pid || 0,
        socketPath,
        lastErrorCode: lastError?.code || "",
        lastError: lastError?.message || ""
      }
    });
    return EXIT_BRIDGE;
  }

  const status = enabled.status;
  writeResult(stdout, options, {
    ok: true,
    command: "bridge up",
    foreground: false,
    pid: child?.pid || 0,
    reusedExistingBroker,
    broker: {
      brokerInstanceId: enabled.payload.brokerInstanceId || status.bridge?.brokerInstanceId || "",
      socketPath: enabled.payload.socketPath || status.bridge?.socketPath || socketPath,
      wsUrl: enabled.payload.wsUrl || status.bridge?.wsUrl || "",
      browserWsUrl: enabled.payload.browserWsUrl || status.bridge?.browserWsUrl || "",
      httpUrl: enabled.payload.httpUrl || status.bridge?.httpUrl || "",
      protocolVersion: status.bridge?.bridgeProtocolVersion || null
    },
    status
  }, (result) => `Auto Flow bridge broker ready at ${result.broker.socketPath}; WS ${result.broker.wsUrl}.`);
  return EXIT_OK;
}

function spawnDetachedBroker(binPath, options = {}, socketPath = "") {
  const args = [binPath, "bridge", "up", "--foreground", "--port", String(options.port || options.wsPort || "auto"), "--json"];
  const child = spawn(process.execPath, args, {
    cwd: PACKAGE_ROOT,
    detached: true,
    stdio: "ignore",
    env: {
      ...(options.env || process.env),
      AUTOFLOW_BRIDGE_AUTOSTART: "0",
      ...(socketPath ? { AUTOFLOW_BRIDGE_SOCKET: socketPath } : {})
    }
  });
  child.unref?.();
  return child;
}

async function waitForShutdownSignal(broker) {
  await new Promise((resolve) => {
    const shutdown = () => resolve();
    process.once("SIGINT", shutdown);
    process.once("SIGTERM", shutdown);
  });
  await broker.close().catch(() => {});
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runBridgeTargets(options, stdout) {
  const payload = bridgeTargetPayloadFields(options);
  const bridgeResult = await requestBridge("bridge.targets.list", payload, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const result = {
    ok: true,
    command: "bridge targets",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    selectedExtension: response.selectedExtension || null,
    requestedTarget: response.requestedTarget || payload,
    response
  };
  writeResult(stdout, options, result, humanBridgeTargets);
  return EXIT_OK;
}

async function runBridgeUse(options, stdout) {
  const missing = [];
  if (!String(options.projectId || "").trim()) missing.push("--project-id");
  if (!String(options.tabId || "").trim()) missing.push("--tab-id");
  if (!laneIdFromOptions(options)) missing.push("--lane-id");
  if (missing.length) {
    writeError(stdout, options, {
      code: "missing_bridge_target",
      message: `bridge use requires ${missing.join(" and ")}.`
    });
    return EXIT_USAGE;
  }
  const payload = bridgeTargetPayloadFields(options);
  const bridgeResult = await requestBridge("bridge.target.use", payload, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const result = {
    ok: true,
    command: "bridge use",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    selectedExtension: response.selectedExtension || null,
    requestedTarget: response.requestedTarget || payload,
    laneId: response.laneId || payload.laneId || "",
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    response
  };
  writeResult(stdout, options, result, humanBridgeUse);
  return EXIT_OK;
}

async function runNamedLaneUse(positionals = [], options, stdout) {
  const laneId = laneIdFromPositionals(positionals, options);
  if (!laneId) {
    writeError(stdout, options, {
      code: "missing_lane_name",
      message: "lane use requires a name, for example: autoflow lane use fruit-vids."
    });
    return EXIT_USAGE;
  }
  const payload = {
    laneId,
    ...bridgeTargetPayloadFields({ ...options, laneId })
  };
  const bridgeResult = await requestBridge("lane.use", payload, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const selected = response.selectedTarget || response.selectedExtension || {};
  const result = {
    ok: true,
    command: "lane use",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    laneId: response.laneId || laneId,
    name: response.name || response.laneId || laneId,
    projectId: selected.projectId || response.selection?.projectId || "",
    tabId: selected.tabId || response.selection?.tabId || "",
    selectedTarget: selected,
    selection: response.selection || null,
    indicator: response.indicator || null,
    response
  };
  writeResult(stdout, options, result, humanNamedLaneUse);
  return EXIT_OK;
}

async function runNamedLaneList(options, stdout) {
  const bridgeResult = await requestBridge("lane.list", bridgeTargetPayloadFields(options), await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const result = {
    ok: true,
    command: "lane list",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    lanes: Array.isArray(response.lanes) ? response.lanes : [],
    connectedExtensions: Array.isArray(response.connectedExtensions) ? response.connectedExtensions : [],
    response
  };
  writeResult(stdout, options, result, humanNamedLaneList);
  return EXIT_OK;
}

async function runNamedLaneUnbind(positionals = [], options, stdout) {
  const laneId = laneIdFromPositionals(positionals, options);
  if (!laneId) {
    writeError(stdout, options, {
      code: "missing_lane_name",
      message: "lane unbind requires a name, for example: autoflow lane unbind fruit-vids."
    });
    return EXIT_USAGE;
  }
  const bridgeResult = await requestBridge("lane.unbind", { laneId }, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const result = {
    ok: true,
    command: "lane unbind",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    laneId: response.laneId || laneId,
    removed: response.removed === true,
    previous: response.previous || null,
    response
  };
  writeResult(stdout, options, result, humanNamedLaneUnbind);
  return EXIT_OK;
}

async function runConnect(options, stdout) {
  options = withLaneDefault(options);
  const payload = {
    ...agentTargetPayloadFields(options),
    ...(options.windowId ? { windowId: Number(options.windowId) } : {})
  };
  const request = { type: "agent.tab.connect", payload };
  try {
    const bridgeResult = await requestBridge(request.type, payload, {
      ...(await withStoredPairingToken(options)),
      serviceWorkerRequired: true,
      commandFallback: false
    });
    const response = unwrapBridgeResponse(bridgeResult);
    writeResult(stdout, options, {
      ok: true,
      command: "connect",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      projectId: response.projectId || payload.projectId || "",
      tabId: response.tabId || payload.tabId || "",
      laneId: response.laneId || "",
      code: response.code || "FLOW_PAGE_CONNECTED",
      nextAction: response.nextAction || "",
      response
    }, humanConnect);
    return EXIT_OK;
  } catch (error) {
    if (error instanceof BridgeResponseError) {
      writeError(stdout, options, {
        code: error.code || "FLOW_PAGE_BRIDGE_DEGRADED",
        message: error.message || "Connecting this Flow tab failed.",
        details: {
          nextAction: error.details?.nextAction || "Stay on this Flow tab and run autoflow connect again.",
          request,
          response: error.response || {}
        }
      });
      return EXIT_PROJECT;
    }
    if (!(error instanceof BridgeUnavailableError)) throw error;
    writeBridgeActionNeeded(stdout, options, error, {
      command: "connect",
      request
    }, "Bridge unavailable; this Flow tab was not connected.");
    return EXIT_BRIDGE;
  }
}

async function runStatus(options, stdout) {
  options = withLaneDefault(options);
  const explicitLegacyCommand = Boolean(options.bridgeCommand || options.env?.AUTOFLOW_BRIDGE_COMMAND);
  const payload = {
    project: options.project || "current",
    ...bridgeTargetPayloadFields(options)
  };
  const bridgeResult = await requestBridge("status.get", payload, {
    ...(await withStoredPairingToken(options)),
    serviceWorkerRequired: !explicitLegacyCommand,
    ...(explicitLegacyCommand ? {} : { commandFallback: false }),
    autoStartBroker: !explicitLegacyCommand
  });
  const result = normalizeStatusResult(bridgeResult);
  writeResult(stdout, options, result, humanStatus);
  return statusExitCode(result);
}

async function runFlowState(options, stdout) {
  const target = agentTargetPayloadFields(options);
  const bridgeOptions = await withStoredPairingToken(options);
  const statusRequest = {
    type: "status.get",
    payload: {
      project: options.project || "current",
      ...bridgeTargetPayloadFields(options)
    }
  };
  let statusBridgeResult;
  try {
    statusBridgeResult = await requestBridge(statusRequest.type, statusRequest.payload, bridgeOptions);
  } catch (error) {
    if (!(error instanceof BridgeUnavailableError)) throw error;
    const result = {
      command: "flow state",
      ...compactFlowStateError({
        code: "FLOW_STATE_BRIDGE_DOWN",
        precondition: "bridge_down",
        message: "flow_state precondition missing: Auto Flow native broker socket is unavailable.",
        request: statusRequest,
        details: error.details || {}
      })
    };
    writeResult(stdout, options, result, humanFlowState);
    return EXIT_BRIDGE;
  }

  const status = normalizeStatusResult(statusBridgeResult);
  const precondition = flowStatePreconditionFailure(status);
  if (precondition) {
    const result = {
      command: "flow state",
      ...compactFlowStateError({
        ...precondition,
        status,
        request: statusRequest
      })
    };
    writeResult(stdout, options, result, humanFlowState);
    return flowStateExitCode(result);
  }

  const contextRequest = {
    type: "agent.context.get",
    payload: {
      project: options.project || "current",
      includeRaw: false,
      ...target
    }
  };
  let contextBridgeResult;
  let agentContext;
  try {
    contextBridgeResult = await requestBridge(contextRequest.type, contextRequest.payload, {
      ...bridgeOptions,
      serviceWorkerRequired: true,
      commandFallback: false
    });
    agentContext = unwrapBridgeResponse(contextBridgeResult);
  } catch (error) {
    if (error instanceof BridgeUnavailableError) {
      const result = {
        command: "flow state",
        ...compactFlowStateError({
          code: "FLOW_STATE_BRIDGE_DOWN",
          precondition: "bridge_down",
          message: "flow_state precondition missing: bridge went down before the Flow page snapshot could be read.",
          status,
          request: contextRequest,
          details: error.details || {}
        })
      };
      writeResult(stdout, options, result, humanFlowState);
      return EXIT_BRIDGE;
    }
    if (error instanceof BridgeResponseError) {
      const code = String(error.code || "BRIDGE_ERROR").toUpperCase();
      const pagePrecondition = /TARGET_MISMATCH|FLOW_TAB|PROJECT|PAGE/.test(code);
      const result = {
        command: "flow state",
        ...compactFlowStateError({
          code: pagePrecondition ? "FLOW_STATE_PAGE_NOT_FLOW" : `FLOW_STATE_${code}`,
          precondition: pagePrecondition ? "page_not_flow" : "context_unavailable",
          message: pagePrecondition
            ? "flow_state precondition missing: active page is not the requested Google Flow project tab."
            : `flow_state precondition missing: Flow page snapshot unavailable (${code}).`,
          status,
          request: contextRequest,
          details: { response: error.response || {} }
        })
      };
      writeResult(stdout, options, result, humanFlowState);
      return flowStateExitCode(result);
    }
    throw error;
  }

  const snapshot = buildFlowStateSnapshot({
    status,
    agentContext,
    requestedTarget: target
  });
  const result = {
    command: "flow state",
    source: "bridge",
    bridgeHost: contextBridgeResult?.host || statusBridgeResult.host,
    compact: true,
    status: flowStateStatusSummary(status),
    ...snapshot
  };
  writeResult(stdout, options, result, humanFlowState);
  return flowStateExitCode(result);
}

async function runTargets(options, stdout) {
  options = withLaneDefault(options);
  const payload = {
    project: options.project || "current",
    ...(options.projectId && options.projectId !== true ? { projectId: String(options.projectId) } : {}),
    ...(options.laneId && options.laneId !== true ? { laneId: String(options.laneId) } : {}),
    ...(options.port && options.port !== true ? { port: String(options.port) } : {})
  };
  const bridgeResult = await requestBridge("flow.tabs.list", payload, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const targets = Array.isArray(response.tabs)
    ? response.tabs
    : (Array.isArray(response.targets) ? response.targets : []);
  const result = {
    ok: true,
    command: "targets",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    activeTabId: response.activeTabId || null,
    activeProjectId: response.activeProjectId || "",
    count: Number.isFinite(Number(response.count)) ? Number(response.count) : targets.length,
    targets,
    response
  };
  writeResult(stdout, options, result, humanTargets);
  return targets.length ? EXIT_OK : EXIT_PROJECT;
}

async function runDoctor(options, stdout) {
  const bridgeProbe = await probeBridgeStatus(options);
  const extensionDetection = await detectExtensionId(options, bridgeProbe.status);
  const nativeDoctor = extensionDetection.id
    ? nativeHostDoctorReport(options, extensionDetection.id, { fix: options.fix === true })
    : emptyNativeDoctor(extensionDetection);
  const result = {
    ok: bridgeProbe.ok === true && nativeDoctor.ok === true,
    command: "doctor",
    version: await readPackageVersion(),
    extension: {
      id: extensionDetection.id,
      version: bridgeProbe.status?.extension?.version || "",
      detectedFrom: extensionDetection.detectedFrom
    },
    nativeHost: {
      hostName: AUTO_FLOW_NATIVE_HOST_NAME,
      launcherPath: nativeDoctorLauncherPath(nativeDoctor, options),
      hostScriptPath: defaultNativeHostScriptPath(),
      nodePath: process.execPath,
      socketPath: bridgeProbe.status?.nativeRuntime?.socketPath || options.bridgeSocket || "",
      brokerConnected: bridgeProbe.ok === true,
      manifests: nativeDoctorManifests(nativeDoctor)
    },
    repairs: nativeDoctor.repairs || [],
    restartRequired: {
      browser: nativeDoctor.restartRequired?.browser === true,
      reason: nativeDoctor.restartRequired?.reason || ""
    },
    status: bridgeProbe.status || null,
    bridge: bridgeProbe.bridge || null,
    capabilities: capabilitiesPayload()
  };
  writeResult(stdout, options, result, humanDoctor);
  if (result.ok) return EXIT_OK;
  if (!extensionDetection.id && options.fix === true) return EXIT_USAGE;
  if (nativeDoctor.ok !== true && options.fix === true) return EXIT_BRIDGE;
  return bridgeProbe.exitCode || EXIT_BRIDGE;
}

async function probeBridgeStatus(options = {}) {
  try {
    const bridgeResult = await requestBridge("status.get", {
      project: options.project || "current",
      ...bridgeTargetPayloadFields(options)
    }, await withStoredPairingToken(options));
    const status = normalizeStatusResult(bridgeResult);
    return {
      ok: status.ok === true,
      status,
      bridge: { state: "connected" },
      exitCode: statusExitCode(status)
    };
  } catch (error) {
    if (error instanceof BridgeUnavailableError) {
      return {
        ok: false,
        status: null,
        bridge: {
          state: "unavailable",
          error: {
            code: error.code,
            message: error.message,
            details: error.details || {}
          }
        },
        exitCode: EXIT_BRIDGE
      };
    }
    if (error instanceof BridgeResponseError) {
      return {
        ok: false,
        status: null,
        bridge: {
          state: "error",
          error: {
            code: error.code,
            message: error.message,
            response: error.response
          }
        },
        exitCode: exitCodeForBridgeError(error)
      };
    }
    throw error;
  }
}

async function runUpdate(options, stdout) {
  const bridgeProbe = await probeBridgeStatus(options);
  const extensionDetection = await detectExtensionId(options, bridgeProbe.status);
  if (!extensionDetection.id) {
    const result = {
      ok: false,
      command: "update",
      error: {
        code: "extension_id_required",
        message: "Pass --extension-id <id> or --port 9222 so Auto Flow can detect the mounted extension id."
      },
      bridge: bridgeProbe.bridge || null
    };
    writeResult(stdout, options, result, () => result.error.message);
    return EXIT_USAGE;
  }

  const dryRun = options.dryRun === true || options.yes !== true;
  const clients = buildUpdateClientPlans(options);
  const skillsPlan = buildSkillInstallPlan({
    ...options,
    target: "both",
    force: true,
    dryRun
  });
  const skills = dryRun || !skillsPlan.ok ? skillsPlan : await installSkillsFromPlan(skillsPlan);
  const nativeDoctor = nativeHostDoctorReport(options, extensionDetection.id, {
    fix: true,
    dryRun
  });
  const skillRestartClients = restartClientsForSkills(skills);
  const result = {
    ok: skills.ok !== false && nativeDoctorRepairOk(nativeDoctor),
    command: "update",
    version: await readPackageVersion(),
    dryRun,
    requiresYes: options.yes !== true,
    writesPlanned: options.yes === true && dryRun !== true,
    extension: {
      id: extensionDetection.id,
      detectedFrom: extensionDetection.detectedFrom
    },
    plan: {
      package: await buildPackageUpdatePlan(),
      nativeHost: {
        action: "repair_manifests",
        command: buildNativeHostRepairCommand({
          extensionId: extensionDetection.id,
          profileDir: firstOption(options.profileDir),
          allBrowserManifests: options.allBrowserManifests !== false
        }),
        profileDirs: arrayOption(options.profileDir),
        allBrowserManifests: options.allBrowserManifests !== false
      },
      skills: skillsPlan,
      clients
    },
    nativeHost: {
      hostName: AUTO_FLOW_NATIVE_HOST_NAME,
      launcherPath: nativeDoctorLauncherPath(nativeDoctor, options),
      hostScriptPath: defaultNativeHostScriptPath(),
      nodePath: process.execPath,
      manifests: nativeDoctorManifests(nativeDoctor)
    },
    skills,
    clients,
    repairs: nativeDoctor.repairs || [],
    restartRequired: {
      browser: dryRun ? false : nativeDoctor.restartRequired?.browser === true,
      clients: dryRun ? [] : [...new Set([
        ...clients.filter((client) => client.restartRequired === true).map((client) => client.client),
        ...skillRestartClients
      ])],
      reason: nativeDoctor.restartRequired?.reason || ""
    },
    bridge: bridgeProbe.bridge || null
  };
  writeResult(stdout, options, result, humanUpdate);
  return result.ok ? EXIT_OK : EXIT_BRIDGE;
}

function runCapabilities(options, stdout) {
  const result = {
    ok: true,
    command: "capabilities",
    ...capabilitiesPayload()
  };
  writeResult(stdout, options, result, () => `Auto Flow CLI supports ${result.commands.length} command${result.commands.length === 1 ? "" : "s"}.`);
  return EXIT_OK;
}

function runContext(options, stdout) {
  const result = {
    ok: true,
    command: "context",
    ...buildAgentRuntimeContext()
  };
  writeResult(stdout, options, result, humanAgentContext);
  return EXIT_OK;
}

function runNativeInstallHost(options, stdout, stderr) {
  const scriptPath = path.join(PACKAGE_ROOT, "scripts/install-native-host.mjs");
  const forwarded = nativeInstallHostArgs(options);
  const result = spawnSync(process.execPath, [scriptPath, ...forwarded], {
    cwd: PACKAGE_ROOT,
    env: options.env || process.env,
    encoding: "utf8"
  });
  if (result.stdout) stdout.write(result.stdout);
  if (result.stderr) stderr.write(result.stderr);
  if (result.error) {
    writeError(stderr, options, {
      code: "native_install_host_failed",
      message: result.error.message || String(result.error)
    });
    return EXIT_USAGE;
  }
  return Number.isFinite(result.status) ? result.status : EXIT_USAGE;
}

function nativeInstallHostArgs(options = {}) {
  const forwarded = [];
  const valuedOptions = [
    ["extension-id", options.extensionId],
    ["host-path", options.hostPath],
    ["host-script-path", options.hostScriptPath],
    ["launcher-path", options.launcherPath],
    ["manifest-dir", options.manifestDir],
    ["profile-dir", options.profileDir],
    ["home-dir", options.homeDir],
    ["receipt-path", options.receiptPath],
    ["platform", options.platform],
    ["chmod", options.chmod]
  ];
  for (const [name, rawValue] of valuedOptions) {
    for (const value of arrayOption(rawValue)) {
      if (value === undefined || value === null || value === true || value === false || value === "") continue;
      forwarded.push(`--${name}`, String(value));
    }
  }
  for (const [name, value] of [
    ["doctor", options.doctor],
    ["fix", options.fix],
    ["dry-run", options.dryRun],
    ["all-browser-manifests", options.allBrowserManifests],
    ["auto-detect", options.autoDetect],
    ["require-socket", options.requireSocket]
  ]) {
    if (value === true) forwarded.push(`--${name}`);
  }
  return forwarded;
}

function nativeHostDoctorReport(options = {}, extensionId = "", flags = {}) {
  const scriptPath = path.join(PACKAGE_ROOT, "scripts/install-native-host.mjs");
  const installOptions = { ...options };
  if (!installOptions.launcherPath && !installOptions.hostPath) {
    installOptions.launcherPath = defaultNativeLauncherPath(options);
  }
  const forwarded = nativeInstallHostArgs({
    ...installOptions,
    extensionId,
    doctor: true,
    fix: flags.fix === true,
    dryRun: flags.dryRun === true
  });
  const result = spawnSync(process.execPath, [scriptPath, ...forwarded], {
    cwd: PACKAGE_ROOT,
    env: options.env || process.env,
    encoding: "utf8"
  });
  const parsed = parseJsonObject(result.stdout);
  if (parsed) {
    return {
      ...parsed,
      exitStatus: result.status,
      stderr: result.stderr || undefined
    };
  }
  return {
    ok: false,
    hostName: AUTO_FLOW_NATIVE_HOST_NAME,
    launcherPath: defaultNativeLauncherPath(options),
    manifests: [],
    repairs: [],
    restartRequired: { browser: false, reason: "" },
    error: {
      code: "native_host_doctor_failed",
      message: result.error?.message || result.stderr || result.stdout || "native-host doctor failed"
    },
    exitStatus: result.status
  };
}

function emptyNativeDoctor(extensionDetection = {}) {
  return {
    ok: false,
    hostName: AUTO_FLOW_NATIVE_HOST_NAME,
    launcherPath: "",
    manifests: [],
    repairs: extensionDetection.error ? [{
      code: "EXTENSION_ID_REQUIRED",
      message: extensionDetection.error.message
    }] : [],
    restartRequired: { browser: false, reason: "" }
  };
}

async function detectExtensionId(options = {}, status = null) {
  const explicit = validateNativeHostExtensionId(options.extensionId);
  if (explicit.ok) return { id: explicit.value, detectedFrom: "extension-id" };

  const statusId = validateNativeHostExtensionId(status?.extension?.id || status?.extensionId || "");
  if (statusId.ok) return { id: statusId.value, detectedFrom: "bridge-status" };

  const cdpId = await detectExtensionIdFromCdp(options);
  if (cdpId) return { id: cdpId, detectedFrom: "cdp-port" };

  return {
    id: "",
    detectedFrom: "",
    error: {
      code: "extension_id_required",
      message: "Pass --extension-id <id> or --port <cdp-port> for native-host manifest repair."
    }
  };
}

async function detectExtensionIdFromCdp(options = {}) {
  if (!options.port || options.port === true) return "";
  try {
    const targets = await fetchCdpTargets(String(options.port), options);
    const summary = summarizeCdpTargets(targets, {
      port: String(options.port),
      extensionId: options.extensionId || ""
    });
    const candidate = validateNativeHostExtensionId(summary.extensionId);
    if (candidate.ok) return candidate.value;
  } catch {}
  return "";
}

function defaultNativeLauncherPath(options = {}) {
  if (options.launcherPath && options.launcherPath !== true) return path.resolve(String(options.launcherPath));
  if (options.hostPath && options.hostPath !== true && !/\.mjs$/i.test(String(options.hostPath))) return path.resolve(String(options.hostPath));
  const home = options.homeDir && options.homeDir !== true
    ? path.resolve(String(options.homeDir))
    : userHomeDir(options.env || process.env);
  if (process.platform === "win32") return path.join(home, "AppData/Roaming/AutoFlowNativePackage/native-host/auto-flow-native-host.exe");
  return path.join(home, "Library/Application Support/Auto Flow/native-host-launch.sh");
}

function defaultNativeHostScriptPath() {
  const distHostPath = path.join(PACKAGE_ROOT, "dist/native-host/auto-flow-native-host.mjs");
  if (fsSync.existsSync(distHostPath)) return distHostPath;
  return path.join(PACKAGE_ROOT, "native-host/auto-flow-native-host.mjs");
}

function nativeDoctorManifests(nativeDoctor = {}) {
  if (Array.isArray(nativeDoctor.nativeHost?.manifests)) return nativeDoctor.nativeHost.manifests;
  if (Array.isArray(nativeDoctor.manifests)) return nativeDoctor.manifests;
  return [];
}

function nativeDoctorLauncherPath(nativeDoctor = {}, options = {}) {
  return nativeDoctor.nativeHost?.launcherPath
    || nativeDoctor.launcherPath
    || nativeDoctor.hostPath
    || defaultNativeLauncherPath(options);
}

function nativeDoctorRepairOk(nativeDoctor = {}) {
  const manifests = nativeDoctorManifests(nativeDoctor);
  return manifests.length > 0 && manifests.every((entry) => entry.status === "ok" || entry.plannedManifest);
}

async function buildPackageUpdatePlan() {
  return {
    packageName: "@autoflow-mcp/autoflow",
    installedVersion: await readPackageVersion(),
    action: "manual_npm_update",
    command: "npm install -g @autoflow-mcp/autoflow@latest"
  };
}

function buildUpdateClientPlans() {
  return [
    { client: "claude-code", action: "restart_after_skill_update", restartRequired: true },
    { client: "codex", action: "restart_after_skill_update", restartRequired: true }
  ];
}

function restartClientsForSkills(skills = {}) {
  const installs = Array.isArray(skills.installs) ? skills.installs : [];
  const clients = [];
  for (const entry of installs) {
    if (entry.installed !== true) continue;
    if (entry.target === "claude") clients.push("claude-code");
    if (entry.target === "codex") clients.push("codex");
  }
  return clients;
}

function firstOption(value) {
  return arrayOption(value)[0] || "";
}

function parseJsonObject(value = "") {
  try {
    const parsed = JSON.parse(String(value || ""));
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

function humanDoctor(result = {}) {
  const bridge = result.bridge?.state || "unknown";
  const nativeState = result.nativeHost?.manifests?.every((entry) => entry.status === "ok") ? "native host ok" : "native host needs attention";
  if (result.ok) return `Auto Flow doctor passed (${bridge}; ${nativeState}).`;
  const repair = result.repairs?.[0]?.message ? ` ${result.repairs[0].message}` : "";
  return `Auto Flow doctor blocked (${bridge}; ${nativeState}).${repair}`;
}

function humanUpdate(result = {}) {
  const mode = result.dryRun ? "planned" : "updated";
  const restart = [];
  if (result.restartRequired?.browser) restart.push("browser");
  if (Array.isArray(result.restartRequired?.clients) && result.restartRequired.clients.length) {
    restart.push(result.restartRequired.clients.join(", "));
  }
  const restartText = restart.length ? ` Restart required: ${restart.join("; ")}.` : "";
  return `Auto Flow update ${mode}.${restartText}`;
}

async function runLaneInventory(options, stdout) {
  const port = String(options.port || "9222");
  try {
    const targets = await fetchCdpTargets(port, options);
    const summary = summarizeCdpTargets(targets, {
      port,
      extensionId: options.extensionId || ""
    });
    if (options.write && options.write !== true) {
      const writePath = pathResolve(options.cwd, options.write);
      await fs.mkdir(path.dirname(writePath), { recursive: true });
      await fs.writeFile(writePath, `${JSON.stringify(summary, null, 2)}\n`);
    }
    writeResult(stdout, options, {
      command: "lane inventory",
      ...summary
    }, humanLaneInventory);
    return summary.ok ? EXIT_OK : EXIT_BRIDGE;
  } catch (error) {
    writeResult(stdout, options, {
      ok: false,
      command: "lane inventory",
      port,
      error: {
        code: "lane_inventory_failed",
        message: error?.message || String(error || "lane inventory failed")
      }
    }, (result) => `Lane inventory failed on 127.0.0.1:${result.port}: ${result.error.message}`);
    return EXIT_BRIDGE;
  }
}

function liveAgentTargetError(options = {}) {
  const missing = [];
  if (!String(options.projectId || "").trim()) missing.push("--project-id");
  if (!String(options.tabId || "").trim()) missing.push("--tab-id");
  if (!missing.length) return null;
  return {
    code: "missing_target",
    message: `agent run live submit requires ${missing.join(" and ")}. Run 'autoflow lane use <name> --project-id <projectId> --tab-id <tabId>' or set AUTOFLOW_LANE to a bound named lane.`
  };
}

async function runAgentSmokePack(options, stdout) {
  const pack = buildAgentLiveSmokePack(options);
  const written = await writeAgentLiveSmokePack(pack, options);
  writeResult(stdout, options, {
    ok: true,
    command: "agent smoke-pack",
    runId: written.runId,
    outDir: written.outDir,
    port: written.port,
    extensionId: written.extensionId,
    tags: written.tags,
    files: written.files
  }, humanAgentSmokePack);
  return EXIT_OK;
}

async function runAgentReconcile(options, stdout) {
  options = withLaneDefault(options);
  const project = options.project || "current";
  const expectedManifest = await readExpectedManifest(options);
  if (options.fixture) {
    const result = await reconcileFixture(options.fixture, {
      cwd: options.cwd,
      project,
      expectedManifest,
      includeRawRows: options.includeRawRows === true
    });
    writeResult(stdout, options, result, humanReconcile);
    return EXIT_OK;
  }

  const metadataPayload = {
    project,
    ...(expectedManifest ? { expectedManifest } : {}),
    ...(compactString(options.runId) ? { runId: compactString(options.runId) } : {}),
    ...agentTargetPayloadFields(options)
  };
  const bridgeResult = await requestBridge("project.metadata.get", metadataPayload, await withStoredPairingToken(options));
  const payload = unwrapBridgeResponse(bridgeResult);
  const metadata = payload.metadata || payload.projectInitialData || payload;
  const bridgeExpectedManifest = payload.expectedManifest && typeof payload.expectedManifest === "object" && !Array.isArray(payload.expectedManifest)
    ? payload.expectedManifest
    : null;
  const effectiveExpectedManifest = expectedManifest || bridgeExpectedManifest;
  const result = effectiveExpectedManifest
    ? {
        ...reconcileExpectedProjectData(metadata, effectiveExpectedManifest, {
          source: "bridge",
          includeRawRows: options.includeRawRows === true
        }),
        bridgeHost: bridgeResult.host
      }
    : {
        ...reconcileProjectData(metadata, {
          source: "bridge",
          includeRawRows: options.includeRawRows === true
        }),
        bridgeHost: bridgeResult.host
      };
  writeResult(stdout, options, result, humanReconcile);
  return result.reconciler || result.project?.id ? EXIT_OK : EXIT_PROJECT;
}

async function runAgentGalleryList(options, stdout) {
  options = withLaneDefault(options);
  const optionsError = galleryOptionsError(options, ["project", "projectId", "tabId", "type", "latest", "mediaId"]);
  if (optionsError) {
    writeError(stdout, options, optionsError);
    return EXIT_USAGE;
  }
  const result = await fetchAgentGalleryMedia(options);
  writeResult(stdout, options, result, humanAgentGalleryList);
  return EXIT_OK;
}

async function runAgentGalleryDownload(options, stdout) {
  const optionsError = galleryOptionsError(options, ["project", "projectId", "tabId", "type", "latest", "mediaId", "rowId"]);
  if (optionsError) {
    writeError(stdout, options, optionsError);
    return EXIT_USAGE;
  }
  const namingOptions = cliDownloadFilenameOptions(options);
  if (namingOptions.error) {
    writeError(stdout, options, namingOptions.error);
    return EXIT_USAGE;
  }
  const resolutionError = downloadResolutionOptionsError(options);
  if (resolutionError) {
    writeError(stdout, options, resolutionError);
    return EXIT_USAGE;
  }
  if (!options.out || options.out === true) {
    writeError(stdout, options, {
      code: "missing_out",
      message: "agent gallery download requires --out <dir>."
    });
    return EXIT_USAGE;
  }
  if (!options.mediaId && !options.latest) {
    writeError(stdout, options, {
      code: "missing_gallery_selection",
      message: "agent gallery download requires --media-id <id> or --latest N with --type image|video."
    });
    return EXIT_USAGE;
  }
  if (options.latest && !options.type) {
    writeError(stdout, options, {
      code: "missing_gallery_type",
      message: "agent gallery download --latest requires --type image|video."
    });
    return EXIT_USAGE;
  }
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent gallery download");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  const targetError = galleryDownloadTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }

  const gallery = await fetchAgentGalleryMedia(options.mediaId ? {
    ...options,
    latest: "",
    type: options.type || ""
  } : {
    ...options,
    latest: "",
    type: ""
  });
  const selected = selectGalleryDownloadMedia(gallery.media, options);
  if (!selected.length) {
    writeError(stdout, options, {
      code: options.mediaId ? "gallery_media_id_not_found" : "gallery_no_media",
      message: options.mediaId
        ? `No visible Flow media matched media id ${options.mediaId}.`
        : "No visible Flow media matched the gallery download selection."
    });
    return EXIT_PROJECT;
  }

  const plan = buildGalleryDownloadPlan(selected, {
    folder: options.folder || options.outputRoot,
    imageResolution: options.imageResolution,
    videoResolution: options.videoResolution,
    rowId: options.rowId,
    ...namingOptions.options
  });
  const mediaIds = selected.map((record) => record.mediaId).filter(Boolean);
  const downloadTimeoutMs = downloadExecuteTimeoutMs(options);
  const payload = {
    plan,
    mediaIds,
    runName: options.runName || "Gallery",
    timeoutMs: downloadTimeoutMs,
    ...namingOptions.options,
    ...agentTargetPayloadFields(options)
  };
  const bridgeResult = await requestBridge("downloads.execute", payload, {
    ...(await withStoredPairingToken(options)),
    timeoutMs: bridgeRequestTimeoutMs(options) || downloadTimeoutMs + 15000,
    serviceWorkerRequired: true,
    commandFallback: false
  });
  const response = unwrapBridgeResponse(bridgeResult);
  const outDir = pathResolve(options.cwd, String(options.out));
  const copied = await copyGalleryBridgeDownloadResponseToOut(response, plan, outDir);
  writeResult(stdout, options, {
    ok: copied.ok,
    command: "agent gallery download",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    projectId: gallery.projectId,
    outDir,
    count: selected.length,
    mediaIds,
    media: selected,
    plan,
    saved: copied.saved,
    errors: copied.errors,
    resolvedDuplicateErrors: copied.resolvedDuplicateErrors
  }, humanAgentGalleryDownload);
  if (copied.ok) return EXIT_OK;
  if (unresolvedErrorsAreFlowAuthExpired(copied.errors)) return EXIT_AUTH;
  return EXIT_BRIDGE;
}

async function runAgentClipsDownload(options, stdout) {
  const args = cliClipPipelineArgs(options);
  const result = await runAutoFlowTool("autoflow_clip_pipeline_download", args, {
    cwd: options.cwd,
    env: options.env || process.env
  });
  writeResult(stdout, options, {
    command: "agent clips download",
    ...result
  }, humanAgentClipsDownload);
  return result.ok === true ? EXIT_OK : clipPipelineExitCode(result);
}

async function runAgentClipsRepair(options, stdout) {
  const rowId = compactString(options.rowId || options.row || "");
  if (!rowId) {
    writeError(stdout, options, {
      code: "missing_row",
      message: "agent clips repair requires --row-id ROW."
    });
    return EXIT_USAGE;
  }
  const result = await runAutoFlowTool("autoflow_clip_pipeline_repair", {
    ...cliClipPipelineArgs(options),
    rowId,
    issue: options.issue || "",
    notes: options.notes || options.note || ""
  }, {
    cwd: options.cwd,
    env: options.env || process.env
  });
  writeResult(stdout, options, {
    command: "agent clips repair",
    ...result
  }, humanAgentClipsRepair);
  return result.ok === true ? EXIT_OK : clipPipelineExitCode(result);
}

function cliClipPipelineArgs(options = {}) {
  const rowIds = arrayOption(options.rowIds || options.rows);
  const mediaIds = arrayOption(options.mediaIds || options.mediaId);
  return {
    project: options.project || "current",
    projectId: options.projectId,
    tabId: options.tabId,
    laneId: options.laneId,
    bridgeSocket: options.bridgeSocket,
    expectedManifestPath: options.expectedManifest || options.expectedManifestPath || options.manifest,
    reconciledPath: options.reconciled || options.reconciledPath,
    rowId: options.rowId,
    rowIds: rowIds.length ? rowIds : undefined,
    mediaIds: mediaIds.length ? mediaIds : undefined,
    runName: options.runName,
    outputRoot: options.outputRoot,
    only: options.only,
    includeImages: options.includeImages,
    includeVideos: options.includeVideos,
    latestOnly: options.latestOnly !== false,
    execute: options.execute !== false,
    autoApprove: options.autoApprove,
    maxCreditsPerRun: options.maxCreditsPerRun || options.autoApproveMaxCredits || options.creditLimit,
    autoApproveFree: options.autoApproveFree,
    confirmCredits: isSubmitConfirmCreditsAuthorized(options, options.env || process.env),
    ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {}),
    quietMs: options.quietMs,
    pollMs: options.pollMs,
    waitTimeoutMs: options.waitTimeoutMs || options.timeoutMs,
    metadataTimeoutMs: options.metadataTimeoutMs,
    timeoutMs: options.timeoutMs,
    includeRawRows: options.includeRawRows === true
  };
}

function clipPipelineExitCode(result = {}) {
  if (result.code === "BRIDGE_UNAVAILABLE") return EXIT_BRIDGE;
  if (result.code === "INVALID_INPUT") return EXIT_USAGE;
  if (result.state === "waiting_for_credit_approval") return EXIT_AUTH;
  return EXIT_BRIDGE;
}

async function fetchAgentGalleryMedia(options = {}) {
  const mediaListTimeoutMs = galleryMediaListTimeoutMs(options);
  const requestPayload = {
    project: options.project || "current",
    ...(options.mediaId ? { mediaId: options.mediaId } : {}),
    ...(options.type ? { type: options.type } : {}),
    ...(mediaListTimeoutMs ? { timeoutMs: mediaListTimeoutMs } : {}),
    ...agentTargetPayloadFields(options)
  };
  const bridgeResult = await requestBridge("project.media.list", requestPayload, {
    ...(await withStoredPairingToken(options)),
    timeoutMs: bridgeRequestTimeoutMs(options) || mediaListTimeoutMs || 30000,
    serviceWorkerRequired: true,
    commandFallback: false
  });
  const response = unwrapBridgeResponse(bridgeResult);
  const projectId = String(response.projectId || options.projectId || "").trim();
  const media = galleryMediaFromProjectMediaList(response, {
    projectId,
    type: options.type,
    latest: options.latest
  });
  return {
    ok: true,
    command: "agent gallery list",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    projectId,
    count: media.length,
    summary: summarizeGalleryMedia(media),
    filters: {
      type: options.type || "",
      latest: options.latest || ""
    },
    media
  };
}

function galleryDownloadTargetError(options = {}) {
  const missing = [];
  if (!String(options.projectId || "").trim()) missing.push("--project-id");
  if (!String(options.tabId || "").trim()) missing.push("--tab-id");
  if (!missing.length) return null;
  return {
    code: "missing_target",
    message: `agent gallery download requires ${missing.join(" and ")} so downloads cannot target the wrong Flow tab. Use 'autoflow lane use <name>' or pass the exact project/tab target.`
  };
}

function cliDownloadFilenameOptions(options = {}, normalizeOptions = {}) {
  const normalized = normalizeDownloadFilenameOptions(options, normalizeOptions);
  if (normalized.ok) return { options: normalized.options };
  return {
    error: {
      code: "invalid_filename_option",
      message: normalized.message
    }
  };
}

function downloadResolutionOptionsError(options = {}) {
  if (Object.hasOwn(options, "imageResolution")) {
    const value = String(options.imageResolution === true ? "" : options.imageResolution ?? "").trim().toLowerCase();
    if (!["1k", "2k", "4k"].includes(value)) {
      return {
        code: "invalid_download_resolution",
        message: "--image-resolution must be 1k, 2k, or 4k."
      };
    }
  }
  if (Object.hasOwn(options, "videoResolution")) {
    const value = String(options.videoResolution === true ? "" : options.videoResolution ?? "").trim().toLowerCase();
    if (!["720p", "1080p", "4k"].includes(value)) {
      return {
        code: "invalid_download_resolution",
        message: "--video-resolution must be 720p, 1080p, or 4k."
      };
    }
  }
  return null;
}

function galleryOptionsError(options = {}, keys = []) {
  for (const key of keys) {
    if (!Object.hasOwn(options, key)) continue;
    const value = options[key];
    if (value === true || value === false || Array.isArray(value) || String(value ?? "").trim() === "") {
      return {
        code: "invalid_gallery_option",
        message: `agent gallery requires --${kebabCase(key)} to have a non-empty value.`
      };
    }
  }
  if (Object.hasOwn(options, "type") && !isKnownGalleryType(options.type)) {
    return {
      code: "invalid_gallery_option",
      message: "agent gallery --type must be image, images, video, videos, or all."
    };
  }
  if (Object.hasOwn(options, "latest") && !isValidGalleryLatest(options.latest)) {
    return {
      code: "invalid_gallery_latest",
      message: "agent gallery --latest must be a positive integer."
    };
  }
  return null;
}

async function runRetry(rowArgs, options, stdout) {
  const rowIds = rowArgs.filter((value) => !String(value).startsWith("--"));
  if (!rowIds.length) {
    writeError(stdout, options, {
      code: "missing_rows",
      message: "Retry requires at least one row id, for example V1-S1."
    });
    return EXIT_USAGE;
  }
  if (!options.issue || options.issue === true) {
    writeError(stdout, options, {
      code: "missing_issue",
      message: "Retry requires --issue."
    });
    return EXIT_USAGE;
  }
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent retry");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;

  const payload = buildRetryPayload(rowIds, {
    project: options.project || "current",
    issue: options.issue,
    issues: options.issues,
    notes: options.notes,
    mode: options.mode,
    runId: options.runId,
    taskId: options.taskId,
    expectedDialogue: options.dialogue || options.expectedDialogue,
    latestMedia: options.latestMedia,
    env: options.env || process.env,
    ...(isSubmitConfirmCreditsAuthorized(options) ? { confirmCredits: true } : {}),
    ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {}),
    ...agentTargetPayloadFields(options)
  });

  const targetError = liveAgentTargetError(options);
  if (targetError) {
    writeError(stdout, options, targetError);
    return EXIT_USAGE;
  }

  try {
    const bridgeResult = await requestBridge("agent.retry.submit", payload, await withStoredPairingToken(options));
    const result = {
      ok: true,
      command: "retry",
      source: "bridge",
      bridgeHost: bridgeResult.host,
      payload,
      response: unwrapBridgeResponse(bridgeResult)
    };
    writeResult(stdout, options, result, () => `Retry submitted for ${payload.rowIds.join(", ")}.`);
    return EXIT_OK;
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    const result = {
      ok: false,
      command: "retry",
      source: "payload",
      actionNeeded: bridgeActionNeeded(),
      error: {
        code: error.code,
        message: error.message
      },
      request: {
        type: "agent.retry.submit",
        payload
      }
    };
    writeResult(stdout, options, result, () => [
      "Bridge unavailable; retry request was not sent.",
      JSON.stringify(result.request, null, 2)
    ].join("\n"));
    return EXIT_BRIDGE;
  }
}

async function runAgentDownloadPlan(options, stdout) {
  if (!options.reconciled || options.reconciled === true) {
    writeError(stdout, options, {
      code: "missing_reconciled",
      message: "agent artifacts download-plan requires --reconciled rows.json."
    });
    return EXIT_USAGE;
  }
  const namingOptions = cliDownloadFilenameOptions(options, { defaultStyle: "" });
  if (namingOptions.error) {
    writeError(stdout, options, namingOptions.error);
    return EXIT_USAGE;
  }
  const resolutionError = downloadResolutionOptionsError(options);
  if (resolutionError) {
    writeError(stdout, options, resolutionError);
    return EXIT_USAGE;
  }
  const reconciled = await readJsonFile(pathResolve(options.cwd, options.reconciled));
  const scopedInput = scopeAgentArtifactInput(reconciled, {
    rowIds: options.rowId || options.rowIds || options.rows,
    mediaIds: options.mediaId || options.mediaIds
  });
  const result = planAgentArtifacts(scopedInput, {
    runName: options.runName,
    outputRoot: options.outputRoot,
    only: options.only,
    qaStatus: options.qaStatus,
    latestOnly: options.latestOnly !== false,
    imageResolution: options.imageResolution,
    videoResolution: options.videoResolution,
    ...namingOptions.options
  });
  result.plan = scopeAgentArtifactPlan(result.plan, {
    rowIds: options.rowId || options.rowIds || options.rows,
    mediaIds: options.mediaId || options.mediaIds
  });
  if (!options.execute) {
    writeResult(stdout, options, result, () => {
      const downloads = result.plan.downloads.length;
      return `Planned ${downloads} download${downloads === 1 ? "" : "s"} into ${result.plan.runFolder}. Re-run with --execute --out <dir> to actually save the files.`;
    });
    return EXIT_OK;
  }
  if (!options.out || options.out === true) {
    writeError(stdout, options, {
      code: "missing_out",
      message: "agent artifacts download-plan --execute requires --out <dir> to copy files into."
    });
    return EXIT_USAGE;
  }
  const laneResolution = await resolveNamedLaneTargetOptionsForCommand(options, stdout, "agent artifacts download-plan");
  if (!laneResolution.ok) return laneResolution.exitCode;
  options = laneResolution.options;
  // The extension performs the real download (it has the Flow session); it returns
  // each saved file's absolute path, which we then copy into the caller's --out dir.
  const mediaIds = mediaIdsFromAgentArtifactPlan(result.plan);
  const reconciledRows = extractAgentArtifactRows(scopedInput);
  const downloadTimeoutMs = downloadExecuteTimeoutMs(options);
  const payload = {
    plan: result.plan,
    reconciledRows,
    mediaIds,
    runName: options.runName || "",
    timeoutMs: downloadTimeoutMs,
    ...namingOptions.options,
    ...agentTargetPayloadFields(options)
  };
  const bridgeResult = await requestBridge("downloads.execute", payload, {
    ...(await withStoredPairingToken(options)),
    timeoutMs: bridgeRequestTimeoutMs(options) || downloadTimeoutMs + 15000,
    serviceWorkerRequired: true,
    commandFallback: false
  });
  const response = unwrapBridgeResponse(bridgeResult);
  const outDir = pathResolve(options.cwd, String(options.out));
  await fs.mkdir(outDir, { recursive: true });
  const plannedByMediaId = new Map((result.plan.downloads || [])
    .map((download) => [String(download.mediaId || ""), download])
    .filter(([mediaId]) => Boolean(mediaId)));
  const responseErrors = Array.isArray(response.errors) ? response.errors : [];
  const pathEntries = new Map(Object.entries(response.paths || {}));
  const resolvedDuplicateErrors = [];
  const unresolvedErrors = [];
  for (const errorEntry of responseErrors) {
    const mediaId = String(errorEntry?.mediaId || "");
    const errorCode = String(errorEntry?.error || "");
    if (mediaId && errorCode === "duplicate_artifact" && !pathEntries.has(mediaId)) {
      const planned = plannedByMediaId.get(mediaId) || {};
      const existingPath = await existingDuplicateArtifactPath(planned, mediaId);
      if (existingPath) {
        pathEntries.set(mediaId, existingPath);
        resolvedDuplicateErrors.push({ ...errorEntry, recovered: true, src: existingPath });
        continue;
      }
    }
    unresolvedErrors.push(enrichDownloadError(errorEntry, plannedByMediaId.get(mediaId)));
  }
  const saved = [];
  for (const [mediaId, srcPath] of pathEntries.entries()) {
    const planned = plannedByMediaId.get(String(mediaId)) || {};
    const relativeDest = destinationPathForBridgeDownload(planned, srcPath);
    const destPath = path.join(outDir, relativeDest);
    try {
      await fs.mkdir(path.dirname(destPath), { recursive: true });
      await fs.copyFile(String(srcPath), destPath);
      const duplicateRecovered = resolvedDuplicateErrors.some((entry) => String(entry.mediaId || "") === String(mediaId));
      saved.push({ mediaId, src: srcPath, dest: destPath, ...(duplicateRecovered ? { duplicateRecovered: true } : {}) });
    } catch (copyError) {
      saved.push({ mediaId, src: srcPath, error: copyError?.message || "copy_failed" });
    }
  }
  const savedOk = saved.filter((entry) => entry.dest);
  const onlyResolvedErrors = responseErrors.length > 0 && unresolvedErrors.length === 0;
  const ok = (response.ok !== false || onlyResolvedErrors) && !unresolvedErrors.length && savedOk.length > 0 && savedOk.length === saved.length;
  writeResult(stdout, options, {
    ok,
    command: "agent artifacts download-plan",
    execute: true,
    source: "bridge",
    bridgeHost: bridgeResult.host,
    outDir,
    saved,
    errors: unresolvedErrors,
    resolvedDuplicateErrors
  }, () => `Saved ${savedOk.length} file${savedOk.length === 1 ? "" : "s"} into ${outDir}.`);
  if (ok) return EXIT_OK;
  if (unresolvedErrorsAreFlowAuthExpired(unresolvedErrors)) return EXIT_AUTH;
  return EXIT_BRIDGE;
}

function unresolvedErrorsAreFlowAuthExpired(errors = []) {
  if (!Array.isArray(errors) || !errors.length) return false;
  return errors.some((entry) =>
    String(entry?.code || "") === "FLOW_DOWNLOAD_AUTH_EXPIRED"
    || String(entry?.failureClass || "") === "download_auth");
}

async function runQaTranscripts(options, stdout) {
  let rows = [];
  if (options.rows && options.rows !== true) {
    rows = await readJsonRows(String(options.rows), options);
  } else if (options.row && options.transcript) {
    rows = [{
      rowId: options.row,
      transcriptPath: options.transcript,
      expectedDialogue: options.dialogue || options.expectedDialogue
    }];
  }
  if (!rows.length) {
    writeError(stdout, options, {
      code: "missing_rows",
      message: "qa transcripts requires --rows qa-rows.json."
    });
    return EXIT_USAGE;
  }
  const result = await evaluateTranscriptRows(rows, {
    cwd: options.cwd,
    generateRetryPrompts: options.generateRetryPrompts !== false
  });
  writeResult(stdout, options, result, humanQaTranscripts);
  return EXIT_OK;
}

function enrichDownloadError(errorEntry = {}, planned = {}) {
  const enriched = { ...errorEntry };
  const rowId = String(planned?.rowId || "").trim();
  const kind = String(planned?.kind || "").trim();
  const relativePath = String(planned?.relativePath || "").trim();
  const filename = String(planned?.filename || "").trim();
  const classification = classifyDownloadExecutionError(enriched.error, kind, filename || relativePath);
  if (rowId && !enriched.rowId) enriched.rowId = rowId;
  if (kind && !enriched.kind) enriched.kind = kind;
  if (relativePath && !enriched.relativePath) enriched.relativePath = relativePath;
  if (filename && !enriched.filename) enriched.filename = filename;
  if (classification) {
    if (!enriched.code) enriched.code = classification.code;
    if (!enriched.failureClass) enriched.failureClass = classification.failureClass;
    if (enriched.retryable === undefined) enriched.retryable = classification.retryable;
    if (!enriched.actionNeeded) enriched.actionNeeded = classification.actionNeeded;
    if (!Array.isArray(enriched.nextActions) || !enriched.nextActions.length) {
      enriched.nextActions = classification.nextActions;
    }
  }
  return enriched;
}

function classifyDownloadExecutionError(error = "", kind = "", filename = "") {
  const reason = String(error || "");
  // Only positive image evidence (image kind, or an image filename when kind is
  // missing) is expired Flow auth. Video and genuinely-unknown media stay generic
  // so slow-but-valid video readiness lag is never routed through EXIT_AUTH.
  if (/^download_bad_content:html_/i.test(reason) && resolveDownloadMediaKind(kind, filename) === "images") {
    return {
      code: "FLOW_DOWNLOAD_AUTH_EXPIRED",
      failureClass: "download_auth",
      retryable: false,
      actionNeeded: "Refresh or re-authenticate the target Flow lane, then rerun reconcile and downloads. Do not regenerate the media just to fix downloads.",
      nextActions: [
        "Refresh the exact Flow tab/project used for this run and confirm the Google/Flow session is still signed in.",
        "Rerun autoflow agent reconcile with the same projectId/tabId.",
        "Rerun autoflow agent artifacts download-plan --execute with the same reconciled rows."
      ]
    };
  }
  return null;
}

function isRetryPayloadFallbackError(error) {
  if (error instanceof BridgeUnavailableError) return true;
  return error instanceof BridgeResponseError
    && String(error.code || "").toUpperCase() === "EXTENSION_BRIDGE_NOT_CONNECTED";
}

function normalizeStatusResult(bridgeResult) {
  const response = unwrapBridgeResponse(bridgeResult);
  const bridge = response.bridge || response.nativeBridge || {};
  const extension = response.extension || {};
  const auth = response.auth || response.session || {};
  const project = response.project || response.flowProject || {};
  const runtime = response.runtime || {};
  const versions = response.versions || {};
  const blockers = Array.isArray(response.blockers) ? response.blockers.filter((entry) => entry && typeof entry === "object") : [];
  const nativeRuntime = response.nativeRuntime && typeof response.nativeRuntime === "object" ? response.nativeRuntime : null;
  const installedNativeHost = response.installedNativeHost && typeof response.installedNativeHost === "object" ? response.installedNativeHost : null;
  const runtimeAgentBridge = runtime.agentBridge && typeof runtime.agentBridge === "object" ? runtime.agentBridge : {};
  const preferredTransport = response.preferredTransport || bridge.preferredTransport || runtimeAgentBridge.preferredTransport || "ws_broker";
  const activeTransport = response.activeTransport || bridge.activeTransport || runtimeAgentBridge.activeTransport || null;
  const transports = normalizeTransportDiagnostics(response.transports || bridge.transports || runtimeAgentBridge);
  const packageVersion = nonblankVersion(
    bridge.packageVersion
      || versions.packageVersion
      || response.packageVersion
      || nativeRuntime?.packageVersion
      || installedNativeHost?.packageVersion
      || readPackageVersionSync()
  );
  const extensionVersion = nonblankVersion(extension.version || versions.extensionVersion || response.extensionVersion);
  const nativeHostVersion = nonblankVersion(
    bridge.nativeHostVersion
      || versions.nativeHostVersion
      || response.nativeHostVersion
      || nativeRuntime?.nativeHostVersion
      || installedNativeHost?.nativeHostVersion
  );
  const bridgeProtocolVersion = positiveProtocolVersion(
    bridge.bridgeProtocolVersion
      ?? versions.bridgeProtocolVersion
      ?? response.bridgeProtocolVersion
      ?? nativeRuntime?.bridgeProtocolVersion
      ?? installedNativeHost?.bridgeProtocolVersion
  );
  const authenticated = auth.authenticated ?? (auth.signedIn === true ? true : (auth.signedIn === false ? false : null));
  const projectId = project.id || project.projectId || response.projectId || runtime.projectId || "";
  const projectActive = project.active ?? project.connected ?? response.projectConnected ?? (runtime.connected === true && projectId ? true : null);
  const activeTabId = Number.isFinite(Number(runtime.activeTabId ?? response.activeTabId ?? project.activeTabId))
    ? Number(runtime.activeTabId ?? response.activeTabId ?? project.activeTabId)
    : null;
  const result = {
    ok: true,
    command: "status",
    source: "bridge",
    bridgeHost: bridgeResult.host,
    bridge: {
      state: bridge.state || (response.extensionConnected === false ? "extension_disconnected" : "connected"),
      preferredTransport,
      activeTransport,
      paired: bridge.paired ?? response.paired ?? true,
      extensionConnected: bridge.extensionConnected ?? response.extensionConnected ?? null,
      brokerInstanceId: bridge.brokerInstanceId || "",
      wsUrl: bridge.wsUrl || "",
      httpUrl: bridge.httpUrl || "",
      packageVersion,
      bridgeProtocolVersion,
      nativeHostVersion
    },
    preferredTransport,
    activeTransport,
    transports,
    extension: {
      present: extension.present ?? response.extensionPresent ?? response.extensionConnected ?? null,
      id: extension.id || response.extensionId || "",
      version: extensionVersion
    },
    versions: {
      extensionVersion,
      packageVersion,
      bridgeProtocolVersion,
      nativeHostVersion
    },
    auth: {
      state: auth.state || (authenticated === false ? "missing" : "unknown"),
      authenticated,
      paired: auth.paired ?? response.paired ?? null
    },
    runtime: {
      connected: runtime.connected ?? response.connected ?? null,
      activeTabId,
      projectId: runtime.projectId || response.projectId || project.id || ""
    },
    activeTabId,
    project: {
      id: projectId,
      name: project.name || response.projectName || "",
      active: projectActive,
      state: project.state || (projectActive === true ? "active" : (projectActive === false ? "missing" : "")),
      activeTabId
    },
    nativeRuntime,
    installedNativeHost,
    blockers
  };
  result.nativeHostHealth = buildNativeHostHealth(result);
  result.blockers = enrichNativeHostBlockers(result.blockers, result.nativeHostHealth);
  result.ok = statusExitCode(result) === EXIT_OK;
  return result;
}

function statusExitCode(result) {
  if (hasStatusBlocker(result, "STALE_NATIVE_HOST_PROCESS")) return EXIT_BRIDGE;
  if (statusVersionIncomplete(result)) return EXIT_BRIDGE;
  if (statusVersionMismatch(result)) return EXIT_BRIDGE;
  if (result.extension.present === false || result.bridge.extensionConnected === false) return EXIT_BRIDGE;
  if (result.auth.authenticated === false || result.auth.state === "missing" || result.auth.state === "pairing_required" || result.bridge.paired === false) return EXIT_AUTH;
  if (result.project.active !== true || !result.project.id || result.project.state === "missing" || result.project.state === "unknown") return EXIT_PROJECT;
  return EXIT_OK;
}

function humanStatus(result) {
  const extension = result.extension.id ? `extension ${result.extension.id}` : "extension status unknown";
  const project = result.project.id ? `project ${result.project.id}` : "project unknown";
  const staleHost = statusBlocker(result, "STALE_NATIVE_HOST_PROCESS");
  if (staleHost) {
    return staleHost.message || "Chrome is still connected to an older Auto Flow native host.";
  }
  if (statusVersionMismatch(result)) {
    return `Version mismatch: extension ${result.versions.extensionVersion}, CLI/MCP ${result.versions.packageVersion}`;
  }
  if (statusVersionIncomplete(result)) {
    return "Version handshake incomplete: extension, CLI/MCP package, native host, and bridge protocol versions are all required.";
  }
  if (result.extension.present === false || result.bridge.extensionConnected === false) {
    return "Bridge host is reachable, but the Auto Flow extension bridge is not connected.";
  }
  return `Bridge ${result.bridge.state}. ${extension}. ${project}.`;
}

function humanFlowState(result = {}) {
  if (result.ok === false) {
    return `${result.precondition || "flow_state_unavailable"}: ${result.message || "Flow state unavailable."}`;
  }
  const page = result.page || {};
  const dialogs = Array.isArray(result.dialogs) ? result.dialogs.length : 0;
  const auth = result.auth?.valid === true ? "valid" : result.auth?.valid === false ? "invalid" : "unknown";
  return [
    `Flow state ${result.state || "unknown"}`,
    `project=${page.projectId || "unknown"}`,
    `tab=${page.tabId || "unknown"}`,
    `mode=${result.mode || "unknown"}`,
    `composerReady=${result.composerReady === true ? "true" : "false"}`,
    `dialogs=${dialogs}`,
    `auth=${auth}`,
    `pending=${result.pending?.waitingOn || "unknown"}`
  ].join(" ");
}

function flowStateExitCode(result = {}) {
  if (result.ok !== false && result.auth?.valid !== false) return EXIT_OK;
  const precondition = String(result.precondition || result.state || "").toLowerCase();
  if (precondition.includes("page")) return EXIT_PROJECT;
  if (precondition.includes("auth") || result.auth?.valid === false) return EXIT_AUTH;
  return EXIT_BRIDGE;
}

function statusVersionIncomplete(result = {}) {
  const versions = result.versions || {};
  const extensionVersion = String(versions.extensionVersion || "").trim();
  const packageVersion = String(versions.packageVersion || "").trim();
  const nativeHostVersion = String(versions.nativeHostVersion || "").trim();
  const bridgeProtocolVersion = Number(versions.bridgeProtocolVersion);
  return !knownVersion(extensionVersion) || !knownVersion(packageVersion) || !knownVersion(nativeHostVersion) || !Number.isFinite(bridgeProtocolVersion) || bridgeProtocolVersion <= 0;
}

function statusVersionMismatch(result = {}) {
  const extensionVersion = String(result.versions?.extensionVersion || "").trim();
  const packageVersion = String(result.versions?.packageVersion || "").trim();
  return Boolean(knownVersion(extensionVersion) && knownVersion(packageVersion) && extensionVersion !== packageVersion);
}

function normalizeTransportDiagnostics(value = {}) {
  const source = value && typeof value === "object" ? value : {};
  const ws = source.ws_broker && typeof source.ws_broker === "object" ? source.ws_broker : {};
  const cdp = source.cdp_bridge && typeof source.cdp_bridge === "object" ? source.cdp_bridge : {};
  const nativeLegacy = source.native_messaging_legacy && typeof source.native_messaging_legacy === "object"
    ? source.native_messaging_legacy
    : {};
  return {
    ws_broker: {
      enabled: ws.enabled === true,
      state: compactString(ws.state || (ws.connected ? "connected" : "unknown")),
      connected: ws.connected === true,
      brokenLink: compactString(ws.brokenLink),
      code: compactString(ws.code || ws.errorCode),
      nextAction: compactString(ws.nextAction),
      wsUrl: compactString(ws.wsUrl || ws.brokerUrl),
      httpUrl: compactString(ws.httpUrl)
    },
    cdp_bridge: {
      enabled: cdp.enabled === true,
      state: compactString(cdp.state || "dev_discovery_only"),
      connected: cdp.connected === true,
      brokenLink: compactString(cdp.brokenLink || "cdp_bridge.discovery_only"),
      code: compactString(cdp.code || cdp.errorCode || "CDP_DISCOVERY_ONLY"),
      nextAction: compactString(cdp.nextAction || "Ignore for normal onboarding; CDP is dev/discovery tooling only.")
    },
    native_messaging_legacy: {
      enabled: nativeLegacy.enabled === true,
      state: compactString(nativeLegacy.state || "disabled"),
      connected: nativeLegacy.connected === true,
      brokenLink: compactString(nativeLegacy.brokenLink || (nativeLegacy.connected ? "" : "native_messaging_legacy.disabled")),
      code: compactString(nativeLegacy.code || nativeLegacy.errorCode || (nativeLegacy.connected ? "" : "NATIVE_MESSAGING_LEGACY_DISABLED")),
      nextAction: compactString(nativeLegacy.nextAction || (nativeLegacy.connected ? "" : "No action needed unless legacy native messaging was explicitly enabled."))
    }
  };
}

function statusBlocker(result = {}, code = "") {
  const normalizedCode = String(code || "").toUpperCase();
  return (Array.isArray(result.blockers) ? result.blockers : []).find((blocker) => String(blocker?.code || "").toUpperCase() === normalizedCode) || null;
}

function hasStatusBlocker(result = {}, code = "") {
  return Boolean(statusBlocker(result, code));
}

function nonblankVersion(value) {
  const text = String(value ?? "").trim();
  return text || UNKNOWN_VERSION;
}

function knownVersion(value) {
  const text = String(value || "").trim().toLowerCase();
  return Boolean(text && text !== UNKNOWN_VERSION);
}

function positiveProtocolVersion(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function readPackageVersionSync() {
  try {
    const raw = fsSync.readFileSync(path.join(PACKAGE_ROOT, "package.json"), "utf8");
    return String(JSON.parse(raw).version || "").trim();
  } catch {
    return "";
  }
}

function buildNativeHostHealth(result = {}) {
  const installed = result.installedNativeHost && typeof result.installedNativeHost === "object" ? result.installedNativeHost : {};
  const runtime = result.nativeRuntime && typeof result.nativeRuntime === "object" ? result.nativeRuntime : {};
  const blocker = statusBlocker(result, "STALE_NATIVE_HOST_PROCESS");
  const extensionId = chromeExtensionId(result.extension?.id || "");
  const installedExtensionId = chromeExtensionId(installed.extensionId || "");
  const actualOrigins = nativeHostActualOrigins(installed, installedExtensionId);
  const manifestPath = compactString(installed.manifestPath || installed.manifest || "");
  const hostPath = compactString(installed.hostPath || installed.path || installed.launcherPath || installed.hostScriptPath || runtime.hostScriptPath || "");
  const expectedOrigin = extensionId ? `chrome-extension://${extensionId}/` : "";
  const repairCommand = extensionId
    ? `autoflow native install-host --extension-id ${extensionId}`
    : "autoflow native install-host --extension-id <extension-id>";
  const mismatches = Array.isArray(blocker?.details?.mismatches) ? blocker.details.mismatches : [];

  return {
    state: blocker ? "stale_native_host" : (result.bridge?.state || "unknown"),
    actionable: Boolean(blocker || manifestPath || hostPath || expectedOrigin || actualOrigins.length),
    manifestPath,
    expectedOrigin,
    actualOrigin: actualOrigins[0] || "",
    actualOrigins,
    hostPath,
    hostScriptPath: compactString(installed.hostScriptPath || runtime.hostScriptPath || ""),
    runningHostPath: compactString(runtime.hostScriptPath || ""),
    repairCommand,
    restartRequirement: NATIVE_HOST_RESTART_REQUIREMENT,
    mismatches
  };
}

function nativeHostActualOrigins(installed = {}, installedExtensionId = "") {
  const explicit = Array.isArray(installed.allowedOrigins)
    ? installed.allowedOrigins
    : (Array.isArray(installed.allowed_origins) ? installed.allowed_origins : []);
  const origins = explicit
    .map((origin) => compactString(origin))
    .filter(Boolean);
  if (!origins.length && installedExtensionId) origins.push(`chrome-extension://${installedExtensionId}/`);
  return [...new Set(origins)];
}

function enrichNativeHostBlockers(blockers = [], nativeHostHealth = {}) {
  if (!Array.isArray(blockers) || !blockers.length) return blockers;
  return blockers.map((blocker) => {
    if (String(blocker?.code || "").toUpperCase() !== "STALE_NATIVE_HOST_PROCESS") return blocker;
    return {
      ...blocker,
      details: {
        ...(blocker.details || {}),
        actionable: nativeHostHealth
      }
    };
  });
}

function chromeExtensionId(value = "") {
  const raw = compactString(value).replace(/^chrome-extension:\/\//i, "").replace(/\/$/, "");
  return /^[a-p]{32}$/i.test(raw) ? raw.toLowerCase() : "";
}

function bridgeTargetPayloadFields(options = {}) {
  const fields = {};
  if (options.projectId && options.projectId !== true) fields.projectId = String(options.projectId).trim();
  if (options.tabId && options.tabId !== true) fields.tabId = String(options.tabId).trim();
  const laneId = laneIdFromOptions(options);
  if (laneId) fields.laneId = laneId;
  if (options.port && options.port !== true) fields.port = String(options.port).trim();
  return fields;
}

function withLaneDefault(options = {}) {
  const laneId = laneIdFromOptions(options);
  if (!laneId || (options.laneId && options.laneId !== true)) return options;
  return {
    ...options,
    laneId
  };
}

async function resolveNamedLaneTargetOptions(options = {}) {
  const laneId = laneIdFromOptions(options);
  if (!laneId) return options;
  if (String(options.projectId || "").trim() && String(options.tabId || "").trim()) {
    return {
      ...options,
      laneId
    };
  }
  const payload = {
    laneId,
    ...bridgeTargetPayloadFields({ ...options, laneId })
  };
  const bridgeResult = await requestBridge("lane.use", payload, await withStoredPairingToken(options));
  const response = unwrapBridgeResponse(bridgeResult);
  const selected = response.selectedTarget || response.selectedExtension || response.selection || {};
  const projectId = String(selected.projectId || response.selection?.projectId || "").trim();
  const tabId = String(selected.tabId || response.selection?.tabId || "").trim();
  return {
    ...options,
    laneId: response.laneId || laneId,
    ...(projectId ? { projectId } : {}),
    ...(tabId ? { tabId } : {})
  };
}

async function resolveNamedLaneTargetOptionsForCommand(options = {}, stdout, command = "") {
  try {
    return {
      ok: true,
      options: options.dryRun === true ? withLaneDefault(options) : await resolveNamedLaneTargetOptions(options)
    };
  } catch (error) {
    if (!isRetryPayloadFallbackError(error)) throw error;
    const laneId = laneIdFromOptions(options);
    const request = {
      type: "lane.use",
      payload: {
        laneId,
        ...bridgeTargetPayloadFields({ ...options, laneId })
      }
    };
    writeBridgeActionNeeded(stdout, options, error, {
      command,
      request
    }, "Bridge unavailable; named lane target was not resolved.");
    return {
      ok: false,
      exitCode: EXIT_BRIDGE
    };
  }
}

function laneIdFromPositionals(positionals = [], options = {}) {
  return compactString(positionals[0] || options.name || options.lane || options.laneName || options.laneId || envLaneId(options));
}

function laneIdFromOptions(options = {}) {
  return compactString((options.laneId && options.laneId !== true) ? options.laneId : envLaneId(options));
}

function envLaneId(options = {}) {
  const env = options.env || process.env;
  return compactString(env.AUTOFLOW_LANE || "");
}

function humanLaneInventory(result) {
  const blockers = result.recommended?.blockers || [];
  const blockerText = blockers.length ? ` Blockers: ${blockers.join("; ")}.` : "";
  return [
    `Lane inventory on 127.0.0.1:${result.port}: ${result.flowProjects?.length || 0} Flow project tab(s), extension ${result.extensionId || "not detected"}.`,
    `Live submit safe: ${result.recommended?.liveSubmitSafe ? "yes" : "no"}.${blockerText}`
  ].join(" ");
}

function humanTargets(result) {
  if (!result.targets.length) return "No open Flow project tabs were returned by the Auto Flow extension.";
  const active = result.activeTabId ? ` Active tab ${result.activeTabId}.` : "";
  return `Found ${result.targets.length} Flow target${result.targets.length === 1 ? "" : "s"}.${active} Use --project-id and --tab-id from this output for live Agent submits.`;
}

function humanBridgeTargets(result) {
  const count = result.connectedExtensions?.length || 0;
  const selected = result.selectedExtension?.projectId ? ` Selected project ${result.selectedExtension.projectId}.` : "";
  return `Found ${count} connected Auto Flow bridge target${count === 1 ? "" : "s"}.${selected}`;
}

function humanConnect(result) {
  if (result.ok === false) {
    return `Connect failed: ${result.code || "FLOW_PAGE_BRIDGE_DEGRADED"}. ${result.nextAction || "Stay on this Flow tab and run autoflow connect again."}`;
  }
  return `Connected Flow project ${result.projectId || result.response?.projectId || "current"} tab ${result.tabId || result.response?.tabId || "unknown"}. Agents can send commands now.`;
}

function humanBridgeUse(result) {
  const target = result.selectedExtension || {};
  return `Selected Auto Flow bridge lane ${result.laneId || "unknown"} for project ${target.projectId || result.requestedTarget?.projectId || "unknown"}.`;
}

function humanNamedLaneUse(result) {
  const indicator = result.indicator?.ok === false ? " Indicator failed; title/badge may need re-bind after reload." : "";
  return `Named lane ${result.name || result.laneId} is bound to project ${result.projectId || "unknown"} tab ${result.tabId || "unknown"}.${indicator}`;
}

function humanNamedLaneList(result) {
  const lanes = Array.isArray(result.lanes) ? result.lanes : [];
  if (!lanes.length) return "No named Auto Flow lanes are bound.";
  return lanes.map((lane) => {
    const state = lane.connected ? "connected" : (lane.ambiguous ? "ambiguous" : (lane.rebindAvailable ? "rebind-available" : "gone"));
    return `${lane.name || lane.laneId}: ${state} project ${lane.projectId || "unknown"} tab ${lane.tabId || "unknown"} last-used ${lane.lastUsed || "never"}`;
  }).join("\n");
}

function humanNamedLaneUnbind(result) {
  return result.removed
    ? `Unbound named lane ${result.laneId}.`
    : `Named lane ${result.laneId} was not bound.`;
}

function humanAgentSmokePack(result) {
  return `Created Agent live smoke pack: ${result.outDir}\nCommands: ${result.files.commandsFile}`;
}

function humanReconcile(result) {
  if (result.reconciler) {
    const reconciled = result.result || {};
    const missing = reconciled.missingVideoTags?.length ? ` Missing: ${reconciled.missingVideoTags.join(", ")}.` : "";
    return `Reconciled ${result.source} with expected manifest. ${reconciled.presentVideos}/${reconciled.expectedVideos} videos present.${missing}`;
  }
  const project = result.project.id || "unknown project";
  const missing = result.rows.missingRows.length ? ` Missing: ${result.rows.missingRows.join(", ")}.` : "";
  const duplicate = result.rows.duplicateRows.length ? ` Duplicates: ${result.rows.duplicateRows.join(", ")}.` : "";
  return [
    `Reconciled ${result.source} for ${project}.`,
    `${result.media.total} media (${result.media.images} images, ${result.media.videos} videos).`,
    `${result.rows.present}/${result.rows.expected} tagged video rows present.${missing}${duplicate}`
  ].join(" ");
}

function humanAgentGalleryList(result) {
  const summary = result.summary || {};
  return `Listed ${result.count || 0} visible gallery media item${result.count === 1 ? "" : "s"} (${summary.images || 0} images, ${summary.videos || 0} videos).`;
}

function humanAgentGalleryDownload(result) {
  const saved = Array.isArray(result.saved) ? result.saved.filter((entry) => entry.dest).length : 0;
  const attempted = Number(result.count || result.mediaIds?.length || 0) || saved;
  const copyFailures = Array.isArray(result.saved) ? result.saved.filter((entry) => entry.error).length : 0;
  const bridgeFailures = Array.isArray(result.errors) ? result.errors.length : 0;
  const failed = Math.max(0, attempted - saved, copyFailures + bridgeFailures);
  if (result.ok === false || failed > 0) {
    return `Saved ${saved} of ${attempted} gallery files into ${result.outDir}; ${failed} failed.`;
  }
  return `Saved ${saved} gallery file${saved === 1 ? "" : "s"} into ${result.outDir}.`;
}

function humanAgentClipsDownload(result = {}) {
  const downloaded = Array.isArray(result.downloadedMediaIds) ? result.downloadedMediaIds.length : 0;
  const pending = Array.isArray(result.pendingRowIds) ? result.pendingRowIds.length : 0;
  if (result.ok === true) return `Clip pipeline downloaded ${downloaded} media file${downloaded === 1 ? "" : "s"}.`;
  if (result.state === "waiting_for_credit_approval") return "Clip pipeline is waiting for credit approval.";
  return `Clip pipeline downloaded ${downloaded} media file${downloaded === 1 ? "" : "s"}; ${pending} row${pending === 1 ? "" : "s"} still pending.`;
}

function humanAgentClipsRepair(result = {}) {
  const oldCount = Array.isArray(result.oldMediaIds) ? result.oldMediaIds.length : 0;
  const newCount = Array.isArray(result.newMediaIds) ? result.newMediaIds.length : 0;
  if (result.ok === true) return `Clip repair replaced row ${result.rowId || "unknown"}: ${oldCount} old media id${oldCount === 1 ? "" : "s"}, ${newCount} new.`;
  return `Clip repair did not finish for row ${result.rowId || "unknown"}; ${newCount} replacement media id${newCount === 1 ? "" : "s"} downloaded.`;
}

function humanAgentRunWait(result) {
  const progress = result.wait?.progress || {};
  const counts = `${progress.presentImages || 0}/${progress.expectedImages || 0} images, ${progress.presentVideos || 0}/${progress.expectedVideos || 0} videos`;
  if (result.wait?.ok) return `Agent batch completed: ${counts}.`;
  if (result.wait?.status === "waiting_for_user") {
    const action = result.wait?.inspection?.actionRequired || result.wait?.actionRequired || {};
    const reply = action.recommendedResponse ? ` Recommended reply: ${truncateForHuman(action.recommendedResponse, 180)}` : "";
    return `Agent batch is waiting for user input (${action.kind || result.wait.blockedReason || "agent_message_response"}): ${counts}.${reply}`;
  }
  const errors = result.wait?.errors || [];
  const error = errors.length ? ` Last error: ${errors[errors.length - 1].message}` : "";
  return `Agent batch wait timed out: ${counts}.${error}`;
}

function humanQaTranscripts(result) {
  return `QA checked ${result.summary.total} transcript row${result.summary.total === 1 ? "" : "s"}: ${result.summary.pass} pass, ${result.summary.warn} warn, ${result.summary.fail} fail, ${result.summary.needsHumanReview} need review.`;
}

async function copyGalleryBridgeDownloadResponseToOut(response = {}, plan = {}, outDir = "") {
  await fs.mkdir(outDir, { recursive: true });
  const plannedByMediaId = new Map((plan.downloads || [])
    .map((download) => [String(download.mediaId || ""), download])
    .filter(([mediaId]) => Boolean(mediaId)));
  const responseErrors = Array.isArray(response.errors) ? response.errors : [];
  const pathEntries = new Map(Object.entries(response.paths || {}));
  const resolvedDuplicateErrors = [];
  const unresolvedErrors = [];
  for (const errorEntry of responseErrors) {
    const mediaId = String(errorEntry?.mediaId || "");
    const errorCode = String(errorEntry?.error || "").toUpperCase();
    if (mediaId && (errorCode === "DUPLICATE_ARTIFACT" || errorCode === "ARTIFACT_RESERVED") && !pathEntries.has(mediaId)) {
      const planned = plannedByMediaId.get(mediaId) || {};
      const existingPath = await existingDuplicateArtifactPath(planned, mediaId);
      if (existingPath) {
        pathEntries.set(mediaId, existingPath);
        resolvedDuplicateErrors.push({ ...errorEntry, recovered: true, src: existingPath });
        continue;
      }
    }
    unresolvedErrors.push(enrichDownloadError(errorEntry, plannedByMediaId.get(mediaId)));
  }
  const saved = [];
  for (const [mediaId, srcPath] of pathEntries.entries()) {
    const planned = plannedByMediaId.get(String(mediaId)) || {};
    const relativeDest = destinationPathForBridgeDownload(planned, srcPath);
    const destPath = path.join(outDir, relativeDest);
    try {
      await fs.mkdir(path.dirname(destPath), { recursive: true });
      await fs.copyFile(String(srcPath), destPath);
      const duplicateRecovered = resolvedDuplicateErrors.some((entry) => String(entry.mediaId || "") === String(mediaId));
      saved.push({ mediaId, src: srcPath, dest: destPath, ...(duplicateRecovered ? { duplicateRecovered: true } : {}) });
    } catch (copyError) {
      saved.push({ mediaId, src: srcPath, error: copyError?.message || "copy_failed" });
    }
  }
  const savedOk = saved.filter((entry) => entry.dest);
  const onlyResolvedErrors = responseErrors.length > 0 && unresolvedErrors.length === 0;
  return {
    ok: (response.ok !== false || onlyResolvedErrors) && !unresolvedErrors.length && savedOk.length > 0 && savedOk.length === saved.length,
    saved,
    errors: unresolvedErrors,
    resolvedDuplicateErrors
  };
}

function humanAgentContext(result) {
  const videoDefault = result.recommendedDefaults?.videoModel || "Veo 3.1 - Lite [Lower Priority]";
  return [
    `Auto Flow Agent context loaded. Cost-safe video default: ${videoDefault}.`,
    "Omni Flash is not the cheapest; use it only for Omni-specific workflows after approval."
  ].join(" ");
}

function humanAgentScreenContext(result) {
  const response = result.response || result;
  const latestMessages = Array.isArray(response.latestMessages) ? response.latestMessages : [];
  const latestMessage = latestMessages.at(-1);
  if (response.state === "blocked") {
    const blocker = Array.isArray(response.blockers) ? response.blockers[0] : null;
    const row = blocker?.rowId ? ` ${blocker.rowId}` : "";
    return `Flow Agent is blocked${row}: ${blocker?.failureClass || "agent_blocked"}. Use response.retryPrompts for the targeted retry.`;
  }
  if (response.state === "waiting_for_user") {
    const waitingOn = response.uiState?.waitingOn ? ` (${response.uiState.waitingOn})` : "";
    const action = response.uiState?.actionRequired;
    if (action?.recommendedResponse) {
      return `Flow Agent is waiting for user input${waitingOn}. Recommended reply: ${truncateForHuman(action.recommendedResponse, 180)}`;
    }
    const message = latestMessage?.text ? ` Latest: ${truncateForHuman(latestMessage.text, 220)}` : "";
    return `Flow Agent is waiting for user input${waitingOn}.${message}`;
  }
  if (response.state === "running") return "Flow Agent appears to be running or queued; do not retry yet.";
  if (latestMessage?.text) return `Latest Flow Agent message: ${truncateForHuman(latestMessage.text, 240)}`;
  return "Flow Agent screen context read; no visible policy blocker was detected.";
}

function humanAgentChat(result) {
  const wait = result.wait || {};
  if (wait.enabled && wait.ok && wait.latestMessage?.text) {
    return `Agent replied: ${truncateForHuman(wait.latestMessage.text, 260)}`;
  }
  if (wait.enabled && !wait.ok) {
    return "Agent chat submitted, but no new visible Agent reply was detected before timeout.";
  }
  return "Agent chat submitted through Auto Flow bridge.";
}

function truncateForHuman(value = "", limit = 240) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= limit) return text;
  return `${text.slice(0, Math.max(0, limit - 1)).trim()}…`;
}

async function agentChatPromptFromOptions(options = {}) {
  if (options.prompt && options.prompt !== true) return String(options.prompt).trim();
  if (options.message && options.message !== true) return String(options.message).trim();
  if (options.input && options.input !== true) {
    return String(await fs.readFile(pathResolve(options.cwd, options.input), "utf8")).trim();
  }
  return "";
}

async function fleetPromptTextFromOptions(options = {}) {
  const direct = optionString(options.promptsText || options.promptText || options.prompt);
  if (direct) return direct;
  if (options.input && options.input !== true) {
    return String(await fs.readFile(pathResolve(options.cwd, options.input), "utf8")).trim();
  }
  return "";
}

function fleetCliMetadata(options = {}) {
  const metadata = {};
  for (const [key, value] of Object.entries({
    agentId: options.agentId,
    batchId: options.batchId,
    sessionId: options.sessionId,
    runId: options.runId,
    laneId: options.laneId
  })) {
    const normalized = optionString(value);
    if (normalized) metadata[key] = normalized;
  }
  return metadata;
}

function optionString(value = "") {
  if (value === undefined || value === null || value === true || value === false) return "";
  return compactString(value);
}

function listOptionValues(value) {
  const values = Array.isArray(value) ? value : [value];
  return values
    .flatMap((entry) => String(entry || "").split(","))
    .map(compactString)
    .filter(Boolean);
}

function humanFleetGenerate(result = {}) {
  if (result.dryRun) {
    const promptCount = String(result.request?.payload?.promptsText || "").split(/\r?\n/).map((line) => line.trim()).filter(Boolean).length;
    return `Dry run built Fleet Gen request for ${promptCount || 0} prompt${promptCount === 1 ? "" : "s"}; bridge request was not sent.`;
  }
  const mediaCount = Array.isArray(result.mediaIds) ? result.mediaIds.length : 0;
  const manifest = result.manifestPath ? ` Manifest: ${result.manifestPath}.` : "";
  const mediaSuffix = ` with ${mediaCount} media id${mediaCount === 1 ? "" : "s"}.${manifest}`;
  if (result.ok === false) {
    const reason = optionString(result.message || result.error || result.code || result.response?.error || result.response?.message || result.response?.status);
    return `Fleet Gen run failed${reason ? ` (${reason})` : ""}${mediaSuffix}`;
  }
  if (result.timedOut === true || result.response?.timedOut === true) {
    return `Fleet Gen run timed out before completion${mediaSuffix}`;
  }
  return `Fleet Gen run completed${mediaSuffix}`;
}

async function requestAgentContextSnapshot(payload = {}, bridgeOptions = {}) {
  const bridgeResult = await requestBridge("agent.context.get", payload, bridgeOptions);
  return unwrapBridgeResponse(bridgeResult);
}

function unwrapBridgeResponse(bridgeResult = {}) {
  const response = bridgeResult?.response;
  return response?.payload || response?.result || response || {};
}

async function waitForAgentReply({
  contextPayload = {},
  bridgeOptions = {},
  baselineKeys = new Set(),
  prompt = "",
  accepted = false,
  acceptedSignal = "",
  timeoutMs = 60000,
  pollMs = 1000
} = {}) {
  const startedAt = Date.now();
  const timeout = Math.max(1000, Number(timeoutMs) || 60000);
  const interval = Math.max(250, Number(pollMs) || 1000);
  const promptText = String(prompt || "").replace(/\s+/g, " ").trim();
  let lastContext = null;
  let attempts = 0;
  let emptyConversationPolls = 0;
  while (Date.now() - startedAt < timeout) {
    attempts += 1;
    lastContext = await requestAgentContextSnapshot(contextPayload, bridgeOptions);
    const messages = latestAgentMessages(lastContext);
    const newMessages = messages.filter((message) => {
      const key = agentMessageKey(message);
      const text = String(message.text || "").replace(/\s+/g, " ").trim();
      return key && !baselineKeys.has(key) && text && text !== promptText;
    });
    if (newMessages.length) {
      return {
        enabled: true,
        ok: true,
        attempts,
        elapsedMs: Date.now() - startedAt,
        latestMessage: newMessages.at(-1),
        latestMessages: messages,
        context: lastContext
      };
    }
    const context = lastContext?.response || lastContext || {};
    const conversationHistoryDisappeared = accepted === true
      && baselineKeys.size > 0
      && messages.length === 0
      && context?.composer?.visible === true
      && context?.generationActive !== true
      && context?.composer?.generationActive !== true;
    emptyConversationPolls = conversationHistoryDisappeared ? emptyConversationPolls + 1 : 0;
    if (emptyConversationPolls >= 5) {
      return {
        enabled: true,
        ok: false,
        attempts,
        elapsedMs: Date.now() - startedAt,
        latestMessages: messages,
        context: lastContext,
        accepted: true,
        sideEffectRetryBlocked: true,
        reconcileOnly: true,
        error: {
          code: "AGENT_CHAT_SESSION_RESET_AFTER_ACCEPTANCE",
          message: "Flow accepted the chat submit, then the visible conversation history disappeared before a reply was observed. Do not submit the prompt again; reconcile the accepted session read-only."
        },
        details: {
          acceptedSignal: String(acceptedSignal || ""),
          baselineMessageCount: baselineKeys.size,
          emptyConversationPolls
        }
      };
    }
    await new Promise((resolve) => setTimeout(resolve, interval));
  }
  return {
    enabled: true,
    ok: false,
    attempts,
    elapsedMs: Date.now() - startedAt,
    latestMessages: latestAgentMessages(lastContext),
    context: lastContext,
    error: {
      code: "AGENT_REPLY_TIMEOUT",
      message: `No new visible Flow Agent reply detected within ${timeout}ms.`
    }
  };
}

function latestAgentMessages(context = {}) {
  const response = context.response || context;
  return Array.isArray(response.latestMessages) ? response.latestMessages : [];
}

function agentMessageKey(message = {}) {
  const text = String(message.text || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (!text) return "";
  return text;
}

function summarizeAgentContextForWait(context = {}) {
  return {
    state: context.state || "unknown",
    blockers: Array.isArray(context.blockers) ? context.blockers : [],
    retryPrompts: Array.isArray(context.retryPrompts) ? context.retryPrompts : [],
    latestMessages: Array.isArray(context.latestMessages) ? context.latestMessages.slice(-3) : [],
    uiState: context.uiState || {}
  };
}

async function maybeResolveAgentActionDuringWait({
  context = {},
  options = {},
  bridgeOptions = {},
  resolvedAgentActions = new Set(),
  submittedDraftHashes = new Set(),
  runId = "",
  creditPolicyState = createCreditPolicyState(buildStandingCreditPolicy(options, options.env || process.env))
} = {}) {
  const action = context?.uiState?.actionRequired || null;
  if (!action?.kind) return null;
  const key = agentActionResolutionKey(context, action);
  if (key && resolvedAgentActions.has(key)) return null;

  if (action.kind === "drafted_followup" && action.autoResolvable === true && action.draftHash) {
    if (key) resolvedAgentActions.add(key);
    submittedDraftHashes.add(String(action.draftHash || "").trim());
    const resolvedRunId = compactString(runId || context.runId || options.runId || "current");
    const payload = {
      project: options.project || "current",
      runId: resolvedRunId,
      expectedDraftHash: String(action.draftHash || "").trim(),
      idempotencyKey: agentComposerSubmitIdempotencyKey({
        runId: resolvedRunId,
        draftHash: action.draftHash,
        projectId: options.projectId,
        tabId: options.tabId
      }),
      reason: "expected_output_followup",
      ...agentTargetPayloadFields(options)
    };
    const bridgeResult = await requestBridge("agent.composer.submit", payload, bridgeOptions);
    const response = unwrapBridgeResponse(bridgeResult);
    return {
      stop: false,
      status: "action_resolved",
      reason: "agent_drafted_followup_submitted",
      actionRequired: compactAgentAction(action),
      actionResolution: {
        type: "current_composer_submit",
        request: { type: "agent.composer.submit", payload },
        response
      }
    };
  }

  if (action.kind === "credit_confirmation") {
    const standingDecision = evaluateStandingCreditPolicy(action, context, creditPolicyState);
    const creditLimitConfigured = creditPolicyState.policy?.limitConfigured === true;
    const captainApproval = buildCaptainAuthorizedCreditApproval(options, options.env || process.env);
    const approvalDecision = resolveCreditApprovalDecision(standingDecision, captainApproval);
    if (!approvalDecision.approved) {
      const reason = creditApprovalBlockReason(standingDecision, creditLimitConfigured);
      return {
        stop: true,
        status: "waiting_for_credit_approval",
        reason,
        actionRequired: compactAgentAction(action),
        creditPolicy: {
          approved: false,
          reason: standingDecision.reason,
          creditAmount: standingDecision.creditAmount,
          remainingCredits: standingDecision.remainingCredits,
          creditCap: Number.isFinite(Number(creditPolicyState.policy?.maxCreditsPerRun))
            ? Number(creditPolicyState.policy.maxCreditsPerRun)
            : undefined
        },
        nextAction: creditLimitConfigured
          ? "Raise or remove the configured standing credit cap (--max-credits-per-run / AUTOFLOW_MAX_CREDITS_PER_RUN) to allow this spend; confirmCredits cannot exceed the cap."
          : "Run inside a captain-authorized batch or use agent confirm-credits after explicit user approval."
      };
    }
    if (key) resolvedAgentActions.add(key);
    const payload = {
      project: options.project || "current",
      persistentApproval: resolveCreditPersistentApproval(approvalDecision, options),
      creditPromptEvent: compactAgentAction(action),
      ...agentTargetPayloadFields(options)
    };
    const bridgeResult = await requestBridge("agent.credits.confirm", payload, bridgeOptions);
    const response = unwrapBridgeResponse(bridgeResult);
    if (response?.confirmed === true) {
      if (key) resolvedAgentActions.add(key);
      return {
        stop: false,
        status: "action_resolved",
        reason: "agent_credit_confirmation_answered",
        actionRequired: compactAgentAction(action),
        actionResolution: {
          type: "credit_confirmation",
          request: { type: "agent.credits.confirm", payload },
          response,
          creditPolicy: approvalDecision
        }
      };
    }
    return {
      stop: true,
      status: "waiting_for_credit_approval",
      reason: "agent_credit_confirmation_required",
      actionRequired: compactAgentAction(action),
      actionResolution: {
        type: "credit_confirmation",
        request: { type: "agent.credits.confirm", payload },
        response,
        creditPolicy: approvalDecision
      }
    };
  }

  return {
    stop: true,
    status: "waiting_for_user",
    reason: `agent_${String(action.kind || "message_response")}_required`,
    actionRequired: compactAgentAction(action)
  };
}

function agentActionResolutionKey(context = {}, action = {}) {
  if (action.kind === "drafted_followup" && action.draftHash) {
    return `drafted_followup:${String(action.draftHash || "").trim()}`;
  }
  const latest = Array.isArray(context.latestMessages) ? context.latestMessages.at(-1) : null;
  const text = String(latest?.text || action.recommendedResponse || action.recommendedAction || "").replace(/\s+/g, " ").trim().toLowerCase();
  if (action.kind === "credit_confirmation") {
    const dialogKey = String(action.dialogId || action.id || latest?.id || text || "visible_dialog").trim().toLowerCase();
    return `credit_confirmation:${String(action.creditAmount || "").trim() || "unknown"}:${dialogKey}`;
  }
  return `${String(action.kind || "action").trim()}:${text}`;
}

function creditApprovalBlockReason(decision = {}, creditLimitConfigured = false) {
  if (creditLimitConfigured && decision.reason === "credit_policy_exceeded") return "agent_credit_cap_exceeded";
  if (decision.reason === "credit_amount_unknown") return "agent_credit_amount_unknown";
  return "agent_credit_confirmation_requires_captain_authorization";
}

function agentComposerSubmitIdempotencyKey({ runId = "", draftHash = "", projectId = "", tabId = "" } = {}) {
  return [
    "composer",
    compactString(runId || "current"),
    compactString(projectId || "project"),
    compactString(tabId || "tab"),
    compactString(draftHash)
  ].join(":");
}

function compactAgentAction(action = {}) {
  const compact = {
    kind: String(action.kind || "").trim(),
    autoResolvable: action.autoResolvable === true,
    recommendedResponse: String(action.recommendedResponse || "").trim(),
    recommendedAction: String(action.recommendedAction || "").trim(),
    defaultChoice: String(action.defaultChoice || "").trim(),
    choices: Array.isArray(action.choices) ? action.choices.map(compactAgentChoice).filter(Boolean).slice(0, 6) : []
  };
  if (action.draftHash) compact.draftHash = String(action.draftHash || "").trim();
  if (action.draftText) compact.draftText = String(action.draftText || "").trim();
  if (Number.isFinite(Number(action.creditAmount))) compact.creditAmount = Number(action.creditAmount);
  if (action.creditAmountKnown === true) compact.creditAmountKnown = true;
  if (action.freeTier === true) compact.freeTier = true;
  if (action.currency) compact.currency = String(action.currency || "").trim();
  return compact;
}

function compactAgentChoice(choice = "") {
  if (choice && typeof choice === "object") {
    const id = String(choice.id || "").trim();
    const label = String(choice.label || choice.text || "").trim();
    if (!id && !label) return null;
    return {
      id,
      label,
      persistent: choice.persistent === true
    };
  }
  const label = String(choice || "").trim();
  return label ? { id: "", label, persistent: false } : null;
}

function capabilitiesPayload() {
  return {
    commands: [
      "pair",
      "status",
      "targets",
      "context",
      "doctor",
      "update",
      "capabilities",
      "skill install",
      "native install-host",
      "lane use",
      "lane list",
      "lane unbind",
      "lane inventory",
      "agent build-matrix",
      "agent prompts",
      "agent run",
      "agent run-and-wait",
      "agent context",
      "agent confirm-credits",
      "agent refs attach",
      "agent smoke-pack",
      "agent reconcile",
      "agent retry",
      "agent artifacts download-plan",
      "qa transcripts",
      "retry"
    ],
    bridge: {
      supportedCommands: [...AGENT_BRIDGE_COMMAND_TYPES],
      transport: "native-broker"
    },
    safety: {
      liveTargetRequired: true,
      creditConfirmationDefault: "off",
      partialDownloadFailsCommand: true
    },
    modelCostGuide: buildAgentRuntimeContext().modelCostGuide
  };
}

async function runSkillInstall(options, stdout) {
  const plan = buildSkillInstallPlan(options);
  if (!plan.ok) {
    writeResult(stdout, options, plan, () => plan.error.message);
    return EXIT_USAGE;
  }
  if (plan.dryRun) {
    writeResult(stdout, options, plan, humanSkillInstall);
    return EXIT_OK;
  }
  const result = await installSkillsFromPlan(plan);
  writeResult(stdout, options, result, humanSkillInstall);
  return result.ok ? EXIT_OK : EXIT_USAGE;
}

async function installSkillsFromPlan(plan) {
  const installs = [];
  for (const entry of plan.installs) {
    try {
      await fs.mkdir(path.dirname(entry.destinationPath), { recursive: true });
      const existed = await pathExists(entry.destinationPath);
      if (existed && !plan.force) {
        installs.push({
          ...entry,
          installed: false,
          existed: true,
          error: {
            code: "skill_exists",
            message: `${entry.destinationPath} already exists. Re-run with --force to update it.`
          }
        });
        continue;
      }
      if (existed) await fs.rm(entry.destinationPath, { recursive: true, force: true });
      await fs.cp(entry.sourcePath, entry.destinationPath, { recursive: true });
      installs.push({ ...entry, installed: true, existed });
    } catch (error) {
      installs.push({
        ...entry,
        installed: false,
        error: {
          code: "skill_install_failed",
          message: error?.message || String(error)
        }
      });
    }
  }
  const result = {
    ...plan,
    installs,
    ok: installs.every((entry) => entry.installed === true)
  };
  return result;
}

function buildSkillInstallPlan(options = {}) {
  const scope = String(options.scope || "user").trim().toLowerCase();
  if (!["user", "project"].includes(scope)) {
    return {
      ok: false,
      command: "skill install",
      error: {
        code: "invalid_scope",
        message: "--scope must be user or project."
      }
    };
  }
  const targets = parseSkillTargets(options.target || "both");
  if (!targets.length) {
    return {
      ok: false,
      command: "skill install",
      error: {
        code: "invalid_target",
        message: "--target must be claude, codex, or both."
      }
    };
  }
  const installs = targets.map((target) => {
    const sourcePath = path.join(PACKAGE_ROOT, `${target}-skills/autoflow-agent`);
    return {
      target,
      scope,
      skillName: "autoflow-agent",
      sourcePath,
      destinationPath: skillDestinationPath(target, scope, options)
    };
  });
  return {
    ok: true,
    command: "skill install",
    dryRun: options.dryRun === true,
    force: options.force === true,
    restartRequired: true,
    installs
  };
}

function parseSkillTargets(value = "both") {
  const rawTargets = Array.isArray(value) ? value : String(value || "both").split(",");
  const targets = new Set();
  for (const rawTarget of rawTargets) {
    const target = String(rawTarget || "").trim().toLowerCase();
    if (target === "both") {
      targets.add("claude");
      targets.add("codex");
    } else if (target === "claude" || target === "codex") {
      targets.add(target);
    } else if (target) {
      return [];
    }
  }
  return [...targets];
}

function skillDestinationPath(target, scope, options = {}) {
  const root = scope === "project"
    ? options.cwd || process.cwd()
    : userHomeDir(options.env || process.env);
  const vendorDir = target === "claude" ? ".claude" : ".codex";
  return path.join(root, vendorDir, "skills", "autoflow-agent");
}

function userHomeDir(env = process.env) {
  return env.HOME || env.USERPROFILE || os.homedir();
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function humanSkillInstall(result) {
  const lines = [];
  const verb = result.dryRun ? "Would install" : "Installed";
  const installedCount = result.installs.filter((entry) => result.dryRun || entry.installed).length;
  lines.push(`${verb} ${installedCount} Auto Flow agent skill${installedCount === 1 ? "" : "s"}.`);
  for (const entry of result.installs) {
    const status = result.dryRun ? "plan" : (entry.installed ? "ok" : "blocked");
    lines.push(`- ${entry.target}: ${entry.destinationPath} (${status})`);
    if (entry.error?.message) lines.push(`  ${entry.error.message}`);
  }
  lines.push("Restart Claude/Codex so the newly installed skill is loaded.");
  return lines.join("\n");
}

async function withStoredPairingToken(options = {}) {
  if (hasPairingToken(options)) return options;
  const credential = await readCliPairingCredential(options);
  if (!credential?.pairingToken) return options;
  return {
    ...options,
    pairingToken: credential.pairingToken,
    clientId: options.clientId || credential.clientId || "autoflow-cli"
  };
}

function hasPairingToken(options = {}) {
  const env = options.env || process.env;
  return Boolean(
    options.pairingToken
    || options.pairingCredential
    || env.AUTOFLOW_PAIRING_TOKEN
    || env.AUTOFLOW_PAIRING_CREDENTIAL
    || env.AUTOFLOW_BRIDGE_TOKEN
  );
}

async function readCliPairingCredential(options = {}) {
  try {
    return JSON.parse(await fs.readFile(cliPairingCredentialPath(options), "utf8"));
  } catch {
    return null;
  }
}

async function writeCliPairingCredential(options = {}, credential = {}) {
  const pairingToken = String(credential.pairingToken || "").trim();
  if (!pairingToken) return null;
  const filePath = cliPairingCredentialPath(options);
  await fs.mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 });
  await fs.writeFile(filePath, `${JSON.stringify({
    pairingToken,
    clientId: credential.clientId || "autoflow-cli",
    pairedAt: credential.pairedAt || new Date().toISOString()
  }, null, 2)}\n`, { mode: 0o600 });
  await fs.chmod(filePath, 0o600).catch(() => {});
  return filePath;
}

function cliPairingCredentialPath(options = {}) {
  const env = options.env || process.env;
  if (env.AUTOFLOW_PAIRING_STORE) return path.resolve(env.AUTOFLOW_PAIRING_STORE);
  return path.join(getAutoFlowRuntimeDir({ env }), "cli-pairing.json");
}

function writeBridgeUnavailable(stream, options, error) {
  const errorCode = String(error?.code || "WS_BROKER_UNAVAILABLE");
  writeResult(stream, options, {
    ok: false,
    preferredTransport: "ws_broker",
    activeTransport: null,
    error: {
      code: errorCode,
      message: error.message,
      details: error.details || {}
    },
    bridge: {
      state: "unavailable",
      preferredTransport: "ws_broker",
      activeTransport: null
    },
    transports: {
      ws_broker: {
        enabled: false,
        state: "unavailable",
        connected: false,
        brokenLink: "ws_broker.package_daemon",
        code: errorCode,
        nextAction: "Run autoflow bridge up, then retry autoflow status."
      },
      cdp_bridge: {
        enabled: false,
        state: "dev_discovery_only",
        connected: false,
        brokenLink: "cdp_bridge.discovery_only",
        code: "CDP_DISCOVERY_ONLY",
        nextAction: "Ignore for normal onboarding; CDP is dev/discovery tooling only."
      },
      native_messaging_legacy: {
        enabled: false,
        state: "disabled",
        connected: false,
        brokenLink: "native_messaging_legacy.disabled",
        code: "NATIVE_MESSAGING_LEGACY_DISABLED",
        nextAction: "No action needed unless legacy native messaging was explicitly enabled."
      }
    }
  }, () => "WS broker unavailable. Run `autoflow bridge up`, then `autoflow pair`.");
}

function redactPairingToken(response = {}) {
  if (!response || typeof response !== "object" || !response.pairingToken) return response;
  const pairingToken = String(response.pairingToken || "");
  const preview = response.pairingTokenPreview || `${pairingToken.slice(0, 4)}...${pairingToken.slice(-4)}`;
  const { pairingToken: _pairingToken, ...rest } = response;
  return {
    ...rest,
    pairingTokenPreview: preview,
    pairingTokenStored: true
  };
}

const NON_TERMINAL_BRIDGE_STATE_CODES = new Set([
  "dispatch_uncertain",
  "visible_unmapped_output",
  "provisional_match",
  "waiting_for_agent",
  "waiting_for_choice",
  "policy_blocked"
]);

function writeNonTerminalBridgeState(stream, options, error) {
  const code = String(error?.code || error?.response?.error?.code || "").trim().toLowerCase();
  if (!NON_TERMINAL_BRIDGE_STATE_CODES.has(code)) return false;
  const details = error?.response?.error?.details || {};
  const result = {
    ok: true,
    nonTerminal: true,
    code,
    state: compactString(details.state || code),
    message: compactString(error?.message || error?.response?.error?.message || code),
    latestMessage: compactString(details.latestMessage || details.latestAgentMessage || ""),
    latestMessages: Array.isArray(details.latestMessages) ? details.latestMessages : [],
    pendingControls: Array.isArray(details.pendingControls) ? details.pendingControls : [],
    visibleCandidates: Array.isArray(details.visibleCandidates) ? details.visibleCandidates : [],
    matchEvidence: details.matchEvidence || details.evidence || {},
    bridgeCapabilities: details.bridgeCapabilities || details.capabilities || {},
    nextActions: Array.isArray(details.nextActions) && details.nextActions.length
      ? details.nextActions
      : suggestedNextActionsForNonTerminalBridgeState(code),
    response: error?.response || {}
  };
  writeResult(stream, options, result, humanNonTerminalBridgeState);
  return true;
}

function suggestedNextActionsForNonTerminalBridgeState(code) {
  if (code === "waiting_for_choice") return ["Read latestMessage and answer the visible Flow Agent choice before submitting new prompts."];
  if (code === "waiting_for_agent") return ["Wait for the Flow Agent to finish or run agent context again after the quiet window."];
  if (code === "policy_blocked") return ["Ask the Flow Agent to rephrase the same intent at a safer level, then retry the blocked rows."];
  if (code === "visible_unmapped_output" || code === "provisional_match") return ["Preview or download visible candidates before regenerating; do not mark the row missing yet."];
  if (code === "dispatch_uncertain") return ["Check latestMessages and visibleCandidates; reconcile again before resubmitting."];
  return ["Inspect state and continue the Agent conversation instead of treating this as a terminal command failure."];
}

function humanNonTerminalBridgeState(result = {}) {
  if (result.latestMessage) return `Agent state ${result.state}: ${truncateForHuman(result.latestMessage, 220)}`;
  return `Agent state ${result.state || result.code}: continue from nextActions; do not treat this as a terminal failure.`;
}

function writeBridgeError(stream, options, error) {
  const authClassification = classifyBridgeAuthError(error);
  writeResult(stream, options, {
    ok: false,
    ...(authClassification ? {
      code: authClassification.code,
      failureClass: authClassification.failureClass,
      actionNeeded: authClassification.actionNeeded,
      nextActions: authClassification.nextActions
    } : {}),
    error: {
      code: error.code,
      message: error.message,
      ...(authClassification ? {
        normalizedCode: authClassification.code,
        failureClass: authClassification.failureClass
      } : {}),
      response: error.response
    }
  }, () => `Bridge error: ${error.message}`);
}

function classifyBridgeAuthError(error = {}) {
  if (!isFlowAuthExpiredError(error)) return null;
  return {
    code: "FLOW_AUTH_EXPIRED",
    failureClass: "flow_auth",
    actionNeeded: "Refresh or re-authenticate the target Flow lane, then rerun the same read/download command. Do not regenerate media just to fix expired Flow auth.",
    nextActions: [
      "Refresh the exact Flow tab/project used for this run and confirm the Google/Flow session is still signed in.",
      "Rerun autoflow status and the same reconcile/download command with the same projectId/tabId.",
      "If auth still returns 401, switch to a lane where Flow metadata loads without an OAuth callback or sign-in page."
    ]
  };
}

function writeBridgeActionNeeded(stream, options, error, extra, humanMessage) {
  writeResult(stream, options, {
    ok: false,
    source: "payload",
    actionNeeded: bridgeActionNeeded(),
    error: {
      code: error.code,
      message: error.message,
      details: error.details || {}
    },
    ...extra
  }, () => [
    humanMessage,
    JSON.stringify(extra.request, null, 2)
  ].join("\n"));
}

function writeError(stream, options, error) {
  writeResult(stream, options, { ok: false, error }, () => error.message);
}

function writeResult(stream, options, result, humanFormatter) {
  if (options.json) {
    stream.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }
  stream.write(`${humanFormatter(result)}\n`);
}

function exitCodeForBridgeError(error) {
  if (classifyBridgeAuthError(error)) return EXIT_AUTH;
  const code = String(error.code || "").toLowerCase();
  if (code.includes("busy")) return EXIT_BUSY;
  if (code.includes("auth")) return EXIT_AUTH;
  if (code.includes("mismatch") || code.includes("project")) return EXIT_PROJECT;
  return EXIT_BRIDGE;
}

function runWaitExitCode(wait = {}) {
  const hasProgress = (wait.progress?.presentImages || 0) > 0 || (wait.progress?.presentVideos || 0) > 0;
  if (!hasProgress && Array.isArray(wait.errors) && wait.errors.length) return EXIT_BRIDGE;
  return EXIT_PROJECT;
}

function buildAutoRetryPlan(options = {}) {
  const retryFailedGenerations = options.autoRetryFailures !== false && options.autoRetryFailedGenerations !== false;
  const retryMissingOutputs = options.autoRetryMissing === true || options.retryMissing === true;
  const maxRounds = clampPositiveInteger(options.maxRetryRounds || options.retryRounds, 1);
  return {
    enabled: retryMissingOutputs || retryFailedGenerations,
    retryMissingOutputs,
    retryFailedGenerations,
    maxRounds,
    issue: String(options.retryIssue || "missing output"),
    mode: String(options.retryMode || "video-only"),
    notes: String(options.retryNotes || "Generate only the missing row outputs. Do not regenerate completed rows or create extra variations.")
  };
}

async function maybeRetryMissingAgentRows({
  wait,
  options = {},
  bundle = {},
  bridgeOptions = {},
  waitOnce
} = {}) {
  const plan = buildAutoRetryPlan(options);
  const hasRetryableWait = wait?.retryable === true && normalizeRetryRows(wait?.retry?.rows).length > 0;
  if ((!plan.enabled && !hasRetryableWait) || wait?.ok || typeof waitOnce !== "function") {
    return {
      ...plan,
      rounds: [],
      finalWait: wait
    };
  }

  const rounds = [];
  let currentWait = wait;
  for (let round = 1; round <= plan.maxRounds; round += 1) {
    const retry = currentWait?.retry || {};
    const hasExplicitRetry = currentWait?.retryable === true && normalizeRetryRows(retry.rows).length > 0;
    if (currentWait?.blocked === true && currentWait?.retryable !== true) break;
    if (hasExplicitRetry && !shouldAutoRetryAgentWait({ wait: currentWait, plan, options })) break;
    if (!plan.retryMissingOutputs && !hasExplicitRetry) break;
    const rows = normalizeRetryRows(retry.rows).length
      ? normalizeRetryRows(retry.rows)
      : missingRowsFromWaitProgress(currentWait);
    if (!rows.length) break;
    const issue = compactString(retry.issue) || plan.issue;
    const notes = compactString(retry.notes) || plan.notes;
    const retryPayload = buildRetryPayload(rows, {
      project: options.project || "current",
      issue,
      mode: compactString(retry.mode) || plan.mode,
      notes,
      runId: options.runId || "current",
      taskId: options.taskId,
      projectId: options.projectId,
      tabId: options.tabId,
      laneId: options.laneId,
      env: options.env || process.env,
      confirmCredits: isSubmitConfirmCreditsAuthorized(options, options.env || process.env),
      ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {})
    });
    const rowRetryPrompts = retryPromptsForRows(retry.retryPrompts, rows);
    const payload = {
      ...retryPayload,
      expectedManifest: bundle.manifest || null,
      runProfile: buildAgentRunProfile(bundle, options),
      ...(rowRetryPrompts.length ? { retryPrompts: rowRetryPrompts } : {}),
      ...agentTargetPayloadFields(options)
    };
    const request = { type: "agent.retry.submit", payload };
    const bridgeResult = await requestBridge(request.type, request.payload, bridgeOptions);
    currentWait = await waitOnce();
    rounds.push({
      round,
      rows,
      reason: currentWait?.blockedReason || currentWait?.blocker?.failureClass || "",
      request,
      response: unwrapBridgeResponse(bridgeResult),
      wait: currentWait
    });
    if (currentWait.ok) break;
  }

  return {
    ...plan,
    rounds,
    finalWait: currentWait
  };
}

function bridgeRequestTimeoutMs(options = {}) {
  const value = options.bridgeTimeoutMs || options.bridgeRequestTimeoutMs;
  if (value === undefined || value === null || value === "" || value === true || value === false) return undefined;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function downloadExecuteTimeoutMs(options = {}) {
  const value = options.timeoutMs || options.downloadTimeoutMs || options.downloadExecuteTimeoutMs;
  if (value === undefined || value === null || value === "" || value === true || value === false) return 600000;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 600000;
}

function normalizeRetryRowId(value = "") {
  const entry = String(value || "").trim().replace(/^\[/, "").replace(/\]$/, "");
  return /^v\d+-s\d+(?:-img\d+)?$/i.test(entry) ? entry.toUpperCase() : entry;
}

function normalizeRetryRows(value = []) {
  return [...new Set((Array.isArray(value) ? value : [value])
    .map(normalizeRetryRowId)
    .filter(Boolean))];
}

function retryPromptsForRows(retryPrompts = [], rows = []) {
  const rowSet = new Set(normalizeRetryRows(rows).map((rowId) => rowId.toUpperCase()));
  return (Array.isArray(retryPrompts) ? retryPrompts : [])
    .map((entry) => ({
      rowId: normalizeRetryRowId(entry?.rowId),
      prompt: String(entry?.prompt || entry?.text || "").trim()
    }))
    .filter((entry) => entry.rowId && entry.prompt && (!rowSet.size || rowSet.has(entry.rowId.toUpperCase())));
}

function clampPositiveInteger(value, fallback = 1) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed) || parsed < 1) return fallback;
  return parsed;
}

function arrayOption(value) {
  if (value === undefined || value === null || value === true || value === false) return [];
  const values = Array.isArray(value) ? value : [value];
  return values
    .flatMap((entry) => String(entry || "").split(","))
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function compactString(value = "") {
  return String(value || "").trim().replace(/\s+/g, " ");
}

async function readExpectedManifest(options = {}) {
  const manifestPath = options.expectedManifest || options.expectedManifestPath || options.manifest;
  if (!manifestPath || manifestPath === true) return null;
  return await readJsonFile(pathResolve(options.cwd, manifestPath));
}

function buildAgentRunPayload(bundle = {}, options = {}) {
  const refFields = agentRunRefPayloadFields(options);
  const runProfile = buildAgentRunProfile(bundle, options);
  const explicitRunId = options.runId && options.runId !== true ? compactString(options.runId) : "";
  const runId = explicitRunId || createAgentRunId({ dryRun: options.dryRun === true });
  const batchId = compactString(bundle.matrix?.batch?.batchId || "BATCH-001");
  const prompt = prependAgentRunEnvelope(bundle.promptText, {
    runId,
    batchId,
    expectedImages: bundle.expectedImages ?? bundle.manifestExpectedImages ?? 0,
    expectedVideos: bundle.expectedVideos ?? bundle.manifestExpectedVideos ?? 0,
    rowCount: bundle.rowsBuilt ?? bundle.matrix?.rows?.length ?? 0
  });
  return {
    project: options.project || "current",
    mode: "agent",
    prompt,
    matrix: bundle.matrix,
    manifest: bundle.manifest,
    runProfile,
    attachments: refFields.attachments || [],
    ...refFields,
    runId,
    startNewAgentSession: true,
    ...(isCaptainExplicitlyAuthorized(options) ? { captainAuthorized: true } : {}),
    ...(isSubmitConfirmCreditsAuthorized(options) ? { confirmCredits: true } : {}),
    ...(options.dryRun ? { dryRun: true } : {}),
    ...agentTargetPayloadFields(options)
  };
}

function agentRunId(options = {}, payload = {}, bundle = {}) {
  return compactString(
    options.runId
    || payload.runId
    || payload.runProfile?.runId
    || bundle.matrix?.runId
    || bundle.manifest?.runId
    || bundle.manifest?.title
    || "current"
  );
}

function agentRunRefPayloadFields(options = {}) {
  const refs = arrayOption(options.agentRef || options.agentRefs);
  const attachments = arrayOption(options.agentAttachment || options.agentAttachments);
  const allRefs = [...refs, ...attachments];
  const targetRefs = arrayOption(options.targetRef || options.targetRefs);
  if (!allRefs.length && !targetRefs.length) return { attachments: [] };
  const plan = planAgentRefAttachments({
    refs: allRefs,
    targetRefs,
    projectId: options.projectId,
    tabId: options.tabId
  }, {
    liveAttach: options.dryRun !== true,
    projectId: options.projectId,
    tabId: options.tabId
  });
  const explicitAttachTimeoutMs = options.attachTimeoutMs || options.timeoutMs;
  const attachTimeoutMs = explicitAttachTimeoutMs && explicitAttachTimeoutMs !== true
    ? Number(explicitAttachTimeoutMs)
    : Math.min(300000, 15000 + (allRefs.length * 30000));
  return {
    refs: allRefs,
    targetRefs,
    attachments: [],
    refPlan: plan,
    ...(options.forceAttach === true || options.forceAttachRefs === true ? { forceAttach: true } : {}),
    attachTimeoutMs
  };
}

function summarizeBundle(bundle = {}) {
  return {
    inputKind: bundle.inputKind,
    rowsBuilt: bundle.rowsBuilt,
    matrixKind: bundle.matrixKind,
    expectedImages: bundle.expectedImages,
    expectedVideos: bundle.expectedVideos,
    manifestExpectedImages: bundle.manifestExpectedImages,
    manifestExpectedVideos: bundle.manifestExpectedVideos
  };
}

function parseBooleanFlagValue(value) {
  const text = String(value ?? "").trim();
  if (text === "") return true;
  const normalized = text.toLowerCase();
  if (["1", "true", "yes", "on", "enabled", "always"].includes(normalized)) return true;
  if (["0", "false", "no", "off", "disabled", "never"].includes(normalized)) return false;
  throw new Error(`Invalid boolean flag value "${value}". Use true/false, 1/0, yes/no, on/off, enabled/disabled, or always/never.`);
}

function setOption(options, key, value) {
  if (options[key] === undefined) {
    options[key] = value;
  } else if (Array.isArray(options[key])) {
    options[key].push(value);
  } else {
    options[key] = [options[key], value];
  }
}

async function writeTextFile(filePath, text) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, text);
}

function pathResolve(cwd, value) {
  return path.resolve(cwd || process.cwd(), String(value || ""));
}

function safeCliRelativePath(value = "", fallback = "download.bin") {
  const raw = String(value || "").trim() || fallback;
  const normalized = path.normalize(raw).replace(/^([/\\])+/, "");
  const parts = normalized.split(/[\\/]+/).filter((part) => part && part !== "." && part !== "..");
  return parts.join(path.sep) || fallback;
}

function destinationPathForBridgeDownload(planned = {}, srcPath = "") {
  const relativeDest = safeCliRelativePath(planned.filename || planned.relativePath || path.basename(String(srcPath)));
  const sourceExt = safeSourceExtension(srcPath);
  if (!sourceExt) return relativeDest;
  const parsed = path.parse(relativeDest);
  if (!parsed.ext || parsed.ext.toLowerCase() === sourceExt.toLowerCase()) return relativeDest;
  return path.join(parsed.dir, `${parsed.name}${sourceExt}`);
}

async function existingDuplicateArtifactPath(planned = {}, mediaId = "") {
  const relativeSource = safeCliRelativePath(planned.filename || planned.relativePath || "", "");
  if (!relativeSource) return "";
  const candidate = path.join(downloadsRootDir(), relativeSource);
  try {
    const stats = await fs.stat(candidate);
    if (stats.isFile() && stats.size > 0) return candidate;
  } catch {}
  const fallback = await findExistingArtifactWithActualExtension(candidate, mediaId);
  if (fallback) return fallback;
  return "";
}

async function findExistingArtifactWithActualExtension(candidatePath = "", mediaId = "") {
  const directory = path.dirname(candidatePath);
  const plannedBase = path.parse(candidatePath).name;
  const mediaToken = String(mediaId || "").split("-")[0] || "";
  try {
    const entries = await fs.readdir(directory, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const entryPath = path.join(directory, entry.name);
      const parsed = path.parse(entry.name);
      const sameBase = parsed.name === plannedBase;
      const sameMedia = mediaToken && entry.name.includes(mediaToken);
      if (!sameBase && !sameMedia) continue;
      const stats = await fs.stat(entryPath);
      if (stats.isFile() && stats.size > 0) return entryPath;
    }
  } catch {}
  return "";
}

function downloadsRootDir() {
  return process.env.AUTOFLOW_DOWNLOADS_DIR || path.join(os.homedir(), "Downloads");
}

function safeSourceExtension(srcPath = "") {
  const ext = path.extname(String(srcPath || "")).toLowerCase();
  if (!/^\.[a-z0-9]{2,8}$/.test(ext)) return "";
  return ext;
}

function bridgeActionNeeded() {
  return "Enable Auto Flow Bridge in the extension and run `autoflow pair`, then retry this request.";
}

function camelCase(value = "") {
  return String(value).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}

function kebabCase(value = "") {
  return String(value || "")
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/_/g, "-")
    .toLowerCase();
}
