#!/usr/bin/env node
import {
  decodeNativeMessageFrames,
  encodeNativeMessage
} from "./native-message.js";
import net from "node:net";
import {
  createInMemoryPairingState,
  handleNativeHostMessage
} from "./host-core.js";
import {
  createNativeBroker,
  forceReclaimBrokerSocket,
  getDefaultBrokerSocketPath,
  sendBrokerRequest
} from "./broker.js";
import { createAgentBridgeErrorResponse } from "../src/core/agent/agent-bridge-protocol.js";

const DEBUG_LOG_PATH = process.env.AUTOFLOW_NATIVE_DEBUG_LOG || "";
const BROKER_PROXY_STATUS_TIMEOUT_MS = 500;
const BROKER_SUPERVISOR_ROLE = "broker_supervisor";

if (process.argv.includes("--self-test") || process.argv.includes("self-test")) {
  console.log(JSON.stringify({
    ok: true,
    role: "native-host-self-test",
    nodePath: process.execPath,
    platform: process.platform,
    hostScript: new URL(import.meta.url).pathname
  }));
  process.exit(0);
}

if (process.env.AUTOFLOW_NATIVE_HOST_ROLE === "cli_fallback") {
  runFallbackStdioHost();
} else {
  await runBrokerNativeHost();
}

async function runBrokerNativeHost() {
  const extensionId = extensionIdFromNativeHostArgs(process.argv) || process.env.AUTOFLOW_EXTENSION_ID || "auto-flow-extension";
  debugLog("host.start", {
    role: "broker",
    socket: process.env.AUTOFLOW_BRIDGE_SOCKET || process.env.AUTOFLOW_BROKER_SOCKET || "",
    extensionId
  });
  let broker = null;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    broker = createNativeBroker({
      env: process.env
    });

    try {
      await broker.start();
      break;
    } catch (error) {
      if (error?.code === "NATIVE_BROKER_ALREADY_RUNNING") {
        const socketPath = getDefaultBrokerSocketPath({ env: process.env });
        const activeStatus = await requestActiveBrokerStatus(socketPath).catch(() => null);
        if (attempt === 0 && brokerStatusIsStale(activeStatus)) {
          await requestStaleBrokerShutdown(socketPath).catch((error) => {
            debugLog("host.stale_broker_shutdown_failed", {
              socket: socketPath,
              error: error?.message || String(error || "stale broker shutdown failed")
            });
          });
          await waitForBrokerSocketInactive(socketPath).catch(() => {});
          await forceReclaimBrokerSocket(socketPath);
          debugLog("host.stale_broker_reclaimed", {
            socket: socketPath,
            blockers: activeStatus?.payload?.blockers || []
          });
          continue;
        }
        if (process.env.AUTOFLOW_NATIVE_HOST_ROLE === BROKER_SUPERVISOR_ROLE) return;
        await runBrokerExtensionProxy({
          socketPath,
          extensionId
        });
        return;
      }
      writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
        code: error?.code || "NATIVE_BROKER_START_FAILED",
        message: error?.message || String(error || "native broker start failed")
      }));
      process.exitCode = 1;
      return;
    }
  }

  if (!broker?.server) {
    writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
      code: "NATIVE_BROKER_STALE_TAKEOVER_FAILED",
      message: "Auto Flow native host could not take over the stale native broker socket."
    }));
    process.exitCode = 1;
    return;
  }

  if (process.env.AUTOFLOW_NATIVE_HOST_ROLE === BROKER_SUPERVISOR_ROLE) {
    await keepBrokerSupervisorAlive(broker);
    return;
  }

  const registration = broker.registerExtension({
    extensionId,
    send: (message) => {
      debugLog("host.to_extension", {
        id: message?.id || "",
        type: message?.type || "",
        ok: message?.ok
      });
      writeMessage(message);
    }
  });

  runStdioMessageLoop({
    handleMessage: (message) => broker.handleExtensionMessage(message),
    async close() {
      registration.close();
      await broker.close();
    }
  });
}

async function keepBrokerSupervisorAlive(broker) {
  let closed = false;
  const shutdown = async () => {
    if (closed) return;
    closed = true;
    await broker.close().catch(() => {});
  };
  process.once("SIGTERM", shutdown);
  process.once("SIGINT", shutdown);
  await new Promise(() => {});
}

async function requestActiveBrokerStatus(socketPath) {
  return sendBrokerRequest(socketPath, {
    id: `proxy-status-${Date.now()}`,
    type: "status.get",
    payload: {
      source: "native_host_proxy_preflight"
    },
    session: {
      source: "native_host_proxy_preflight",
      clientId: "auto-flow-native-host"
    }
  }, {
    timeoutMs: BROKER_PROXY_STATUS_TIMEOUT_MS
  });
}

async function requestStaleBrokerShutdown(socketPath) {
  return sendBrokerRequest(socketPath, {
    id: `proxy-shutdown-stale-${Date.now()}`,
    type: "broker.shutdown_if_stale",
    payload: {
      source: "native_host_proxy_preflight"
    },
    session: {
      source: "native_host_proxy_preflight",
      clientId: "auto-flow-native-host"
    }
  }, {
    timeoutMs: BROKER_PROXY_STATUS_TIMEOUT_MS
  });
}

async function waitForBrokerSocketInactive(socketPath, timeoutMs = BROKER_PROXY_STATUS_TIMEOUT_MS) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (!await canConnectToBroker(socketPath)) return true;
    await delay(25);
  }
  return false;
}

function canConnectToBroker(socketPath) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ path: socketPath });
    const timer = setTimeout(() => {
      socket.destroy();
      resolve(false);
    }, 100);
    socket.once("connect", () => {
      clearTimeout(timer);
      socket.destroy();
      resolve(true);
    });
    socket.once("error", () => {
      clearTimeout(timer);
      resolve(false);
    });
  });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function brokerStatusIsStale(response = {}) {
  const payload = response?.payload || {};
  const blockers = Array.isArray(payload.blockers) ? payload.blockers : [];
  return blockers.some((blocker) => String(blocker?.code || "") === "STALE_NATIVE_HOST_PROCESS")
    || String(payload?.bridge?.state || "") === "stale_native_host";
}

async function runBrokerExtensionProxy({ socketPath, extensionId }) {
  debugLog("host.start", {
    role: "broker_extension_proxy",
    socket: socketPath,
    extensionId
  });
  const socket = net.createConnection({ path: socketPath });
  let brokerPending = Buffer.alloc(0);
  let extensionPending = Buffer.alloc(0);
  let closed = false;

  await new Promise((resolve, reject) => {
    socket.once("connect", resolve);
    socket.once("error", reject);
  }).catch((error) => {
    writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
      code: error?.code || "NATIVE_BROKER_PROXY_CONNECT_FAILED",
      message: error?.message || "Could not connect to the running Auto Flow native broker."
    }));
    process.exitCode = 1;
  });
  if (process.exitCode) return;

  socket.write(encodeNativeMessage({
    id: `proxy-register-${Date.now()}`,
    type: "broker.extension.register",
    payload: {
      extensionId,
      metadata: {
        nativeHostRole: "broker_extension_proxy",
        packageVersion: packageVersionFromEnv(),
        nativeHostVersion: packageVersionFromEnv()
      }
    }
  }));

  socket.on("data", (chunk) => {
    brokerPending = Buffer.concat([brokerPending, chunk]);
    let decoded;
    try {
      decoded = decodeNativeMessageFrames(brokerPending);
    } catch (error) {
      writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
        code: "NATIVE_BROKER_PROXY_DECODE_FAILED",
        message: error?.message || String(error || "broker proxy decode failed")
      }));
      brokerPending = Buffer.alloc(0);
      return;
    }
    brokerPending = decoded.remaining;
    for (const message of decoded.messages) {
      if (message?.type === "broker.extension.register") continue;
      writeMessage(message);
    }
  });

  socket.once("error", (error) => {
    if (closed) return;
    writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
      code: error?.code || "NATIVE_BROKER_PROXY_FAILED",
      message: error?.message || "Auto Flow native broker proxy failed."
    }));
  });
  socket.once("close", shutdown);

  process.stdin.on("data", (chunk) => {
    extensionPending = Buffer.concat([extensionPending, chunk]);
    let decoded;
    try {
      decoded = decodeNativeMessageFrames(extensionPending);
    } catch (error) {
      socket.write(encodeNativeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
        code: "NATIVE_PROXY_EXTENSION_DECODE_FAILED",
        message: error?.message || String(error || "extension proxy decode failed")
      })));
      extensionPending = Buffer.alloc(0);
      return;
    }
    extensionPending = decoded.remaining;
    for (const message of decoded.messages) {
      socket.write(encodeNativeMessage(message));
    }
  });
  process.stdin.on("end", shutdown);
  process.once("SIGTERM", shutdown);
  process.once("SIGINT", shutdown);
  process.stdin.resume();

  function shutdown() {
    if (closed) return;
    closed = true;
    socket.destroy();
  }
}

function extensionIdFromNativeHostArgs(argv = []) {
  const origin = argv.map((value) => String(value || "")).find((value) => /^chrome-extension:\/\/[a-p]{32}\/?$/i.test(value));
  return origin ? origin.replace(/^chrome-extension:\/\//i, "").replace(/\/$/, "").toLowerCase() : "";
}

function runFallbackStdioHost() {
  if (process.env.AUTOFLOW_ALLOW_IN_MEMORY_FALLBACK !== "1") {
    writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
      code: "IN_MEMORY_FALLBACK_DISABLED",
      message: "The in-memory native host fallback is disabled. Start or ensure the Auto Flow broker socket instead."
    }));
    process.exitCode = 1;
    return;
  }
  const state = createInMemoryPairingState();
  runStdioMessageLoop({
    handleMessage: (message) => handleNativeHostMessage(message, state)
  });
}

function packageVersionFromEnv() {
  return process.env.npm_package_version || "10.8.23";
}

function runStdioMessageLoop(options = {}) {
  let pending = Buffer.alloc(0);
  let queue = Promise.resolve();
  let closed = false;

  process.stdin.on("data", (chunk) => {
    pending = Buffer.concat([pending, chunk]);
    queue = queue.then(processPendingFrames).catch((error) => {
      debugLog("host.frame_error", {
        error: error?.message || String(error || "native host fatal error")
      });
      writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
        code: "NATIVE_HOST_FATAL",
        message: error?.message || String(error || "native host fatal error")
      }));
    });
  });

  process.stdin.on("end", shutdown);
  process.once("SIGTERM", shutdown);
  process.once("SIGINT", shutdown);
  process.stdin.resume();

  async function processPendingFrames() {
    let decoded;
    try {
      decoded = decodeNativeMessageFrames(pending);
    } catch (error) {
      pending = Buffer.alloc(0);
      writeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
        code: "NATIVE_MESSAGE_PARSE_FAILED",
        message: error?.message || String(error || "native message parse failed")
      }));
      return;
    }

    pending = decoded.remaining;
    for (const message of decoded.messages) {
      debugLog("host.from_extension", {
        id: message?.id || "",
        type: message?.type || "",
        ok: message?.ok
      });
      const response = await options.handleMessage(message);
      if (response) {
        debugLog("host.reply_extension", {
          id: response?.id || "",
          type: response?.type || "",
          ok: response?.ok
        });
        writeMessage(response);
      }
    }
  }

  async function shutdown() {
    if (closed) return;
    closed = true;
    await options.close?.();
    process.exit(0);
  }
}

function writeMessage(message) {
  process.stdout.write(encodeNativeMessage(message));
}

function debugLog(event, details = {}) {
  if (!DEBUG_LOG_PATH) return;
  const line = JSON.stringify({
    at: new Date().toISOString(),
    event,
    ...details
  });
  fsAppendLine(DEBUG_LOG_PATH, line);
}

function fsAppendLine(filePath, line) {
  import("node:fs/promises")
    .then(({ appendFile }) => appendFile(filePath, `${line}\n`).catch(() => {}))
    .catch(() => {});
}
