export const MAX_NATIVE_MESSAGE_BYTES = 1024 * 1024;
export const MAX_NATIVE_SOCKET_MESSAGE_BYTES = 16 * 1024 * 1024;

export function encodeNativeMessage(message, options = {}) {
  const maxBytes = positiveInt(options.maxBytes, MAX_NATIVE_MESSAGE_BYTES);
  const body = Buffer.from(JSON.stringify(message ?? {}), "utf8");
  if (body.length > maxBytes) {
    throw new RangeError(`native message exceeds ${maxBytes} bytes`);
  }
  const header = Buffer.alloc(4);
  header.writeUInt32LE(body.length, 0);
  return Buffer.concat([header, body]);
}

export function decodeNativeMessageFrames(input, options = {}) {
  const maxBytes = positiveInt(options.maxBytes, MAX_NATIVE_MESSAGE_BYTES);
  const buffer = Buffer.isBuffer(input) ? input : Buffer.from(input || []);
  const messages = [];
  let offset = 0;

  while (buffer.length - offset >= 4) {
    const length = buffer.readUInt32LE(offset);
    if (length > maxBytes) {
      throw new RangeError(`native message exceeds ${maxBytes} bytes`);
    }
    const frameEnd = offset + 4 + length;
    if (buffer.length < frameEnd) break;
    const body = buffer.subarray(offset + 4, frameEnd).toString("utf8");
    messages.push(JSON.parse(body));
    offset = frameEnd;
  }

  return {
    messages,
    remaining: buffer.subarray(offset)
  };
}

function positiveInt(value, fallback) {
  const numeric = Number.parseInt(value, 10);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : fallback;
}
