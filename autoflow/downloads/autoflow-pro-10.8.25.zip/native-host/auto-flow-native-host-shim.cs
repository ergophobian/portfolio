using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

class AutoFlowNativeHostShim
{
    static int Main()
    {
        string dir = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
        string configPath = Path.Combine(dir, "auto-flow-native-host.windows.json");
        string config = File.Exists(configPath) ? File.ReadAllText(configPath) : "";
        string node = ConfigValue(config, "nodePath", "node.exe");
        string script = ConfigValue(config, "scriptPath", Path.Combine(dir, "auto-flow-native-host.mjs"));
        string extensionId = ConfigValue(config, "extensionId", "");
        string socketPath = ConfigValue(config, "socketPath", @"\\.\pipe\auto-flow-agent-bridge-" + Environment.UserName.ToLowerInvariant());
        string debugLogPath = ConfigValue(config, "debugLogPath", "");

        var psi = new ProcessStartInfo(node, "\"" + script + "\"")
        {
            UseShellExecute = false,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        if (!String.IsNullOrWhiteSpace(extensionId)) psi.EnvironmentVariables["AUTOFLOW_EXTENSION_ID"] = extensionId;
        psi.EnvironmentVariables["AUTOFLOW_BRIDGE_SOCKET"] = socketPath;
        psi.EnvironmentVariables["AUTOFLOW_BROKER_SOCKET"] = socketPath;
        if (!String.IsNullOrWhiteSpace(debugLogPath)) psi.EnvironmentVariables["AUTOFLOW_NATIVE_DEBUG_LOG"] = debugLogPath;

        var child = Process.Start(psi);
        if (child == null) return 2;

        Task.Run(() => {
            try {
                Pump(Console.OpenStandardInput(), child.StandardInput.BaseStream, true);
                child.StandardInput.Close();
            } catch {}
        });

        var outputTask = Task.Run(() => {
            try {
                Pump(child.StandardOutput.BaseStream, Console.OpenStandardOutput(), true);
            } catch {}
        });

        Task.Run(() => {
            try {
                child.StandardError.BaseStream.CopyTo(Stream.Null);
            } catch {}
        });

        child.WaitForExit();
        try { outputTask.Wait(1000); } catch {}
        return child.ExitCode;
    }

    static void Pump(Stream input, Stream output, bool flush)
    {
        byte[] buffer = new byte[8192];
        while (true)
        {
            int read = input.Read(buffer, 0, buffer.Length);
            if (read <= 0) break;
            output.Write(buffer, 0, read);
            if (flush) output.Flush();
        }
    }

    static string ConfigValue(string json, string key, string fallback)
    {
        if (String.IsNullOrEmpty(json)) return fallback;
        var match = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
        if (!match.Success) return fallback;
        return Regex.Unescape(match.Groups[1].Value);
    }
}
