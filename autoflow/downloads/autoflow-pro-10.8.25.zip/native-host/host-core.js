import {
  AGENT_BRIDGE_VERSION,
  createAgentBridgeErrorResponse,
  createAgentBridgeSuccessResponse,
  normalizeBridgeError,
  validateAgentBridgeRequest
} from "../src/core/agent/agent-bridge-protocol.js";
import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

export function createInMemoryPairingState(options = {}) {
  return {
    storage: options.storage || (options.pairingStorePath ? "file" : "memory"),
    pendingPairing: null,
    pairedClients: new Map(),
    codeGenerator: typeof options.codeGenerator === "function"
      ? options.codeGenerator
      : generatePairingCode,
    tokenGenerator: typeof options.tokenGenerator === "function"
      ? options.tokenGenerator
      : generatePairingToken,
    now: typeof options.now === "function"
      ? options.now
      : () => new Date().toISOString()
  };
}

export async function handleNativeHostMessage(message = {}, state = createInMemoryPairingState(), options = {}) {
  const validation = validateAgentBridgeRequest(message);
  if (!validation.ok) {
    return createAgentBridgeErrorResponse(message, validation.error);
  }

  const request = validation.request;
  try {
    if (request.type === "pair.start") return handlePairStart(request, state);
    if (request.type === "pair.confirm") return handlePairConfirm(request, state);
    if (request.type === "status.get") return handleStatusGet(request, state, options);

    if (typeof options.forwardToExtension === "function") {
      return options.forwardToExtension(request, state);
    }

    return createAgentBridgeErrorResponse(request, {
      code: "EXTENSION_BRIDGE_NOT_CONNECTED",
      message: `${request.type} requires service-worker integration`
    });
  } catch (error) {
    return createAgentBridgeErrorResponse(request, normalizeBridgeError({
      code: error?.code || "NATIVE_HOST_HANDLER_FAILED",
      message: error?.message || String(error || "native host handler failed"),
      details: error?.details
    }));
  }
}

function handlePairStart(request, state) {
  const pairingCode = stringValue(state.codeGenerator());
  const pairingId = `pair-${pairingCode}`;
  state.pendingPairing = {
    pairingId,
    pairingCode,
    clientName: stringValue(request.payload.clientName || request.session?.clientId || "local-client"),
    createdAt: state.now()
  };
  return createAgentBridgeSuccessResponse(request, {
    pairingId,
    pairingCode,
    storage: state.storage,
    expiresAt: null
  });
}

function handlePairConfirm(request, state) {
  const pairingCode = stringValue(request.payload.pairingCode);
  const pending = state.pendingPairing;
  if (!pending || pending.pairingCode !== pairingCode) {
    return createAgentBridgeErrorResponse(request, {
      code: "PAIRING_CODE_INVALID",
      message: "pairing code is invalid or expired"
    });
  }

  const clientId = stringValue(request.session?.clientId || request.payload.clientId || pending.clientName || "local-client");
  const pairingToken = stringValue(state.tokenGenerator());
  state.pairedClients.set(clientId, {
    clientId,
    pairingId: pending.pairingId,
    pairingTokenHash: hashPairingToken(pairingToken),
    pairingTokenPreview: tokenPreview(pairingToken),
    pairedAt: state.now()
  });
  state.pendingPairing = null;

  return createAgentBridgeSuccessResponse(request, {
    paired: true,
    pairingId: pending.pairingId,
    clientId,
    pairingToken,
    pairingTokenPreview: tokenPreview(pairingToken),
    storage: state.storage
  });
}

export function pairedClientMatchesToken(client = {}, pairingToken = "") {
  const token = stringValue(pairingToken);
  const expectedHash = stringValue(client.pairingTokenHash);
  if (!token || !expectedHash) return false;
  const actualHash = hashPairingToken(token);
  const left = Buffer.from(expectedHash);
  const right = Buffer.from(actualHash);
  return left.length === right.length && timingSafeEqual(left, right);
}

function handleStatusGet(request, state, options = {}) {
  if (typeof options.statusProvider === "function") {
    return createAgentBridgeSuccessResponse(request, options.statusProvider(request, state));
  }

  return createAgentBridgeSuccessResponse(request, {
    paired: state.pairedClients.size > 0,
    pairedClientCount: state.pairedClients.size,
    pendingPairing: Boolean(state.pendingPairing),
    extensionConnected: false,
    storage: state.storage,
    bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
    packageVersion: process.env.npm_package_version || ""
  });
}

function generatePairingCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function generatePairingToken() {
  return `aft_${randomBytes(32).toString("base64url")}`;
}

function hashPairingToken(value = "") {
  return createHash("sha256").update(stringValue(value), "utf8").digest("hex");
}

function tokenPreview(value = "") {
  const token = stringValue(value);
  return token ? `${token.slice(0, 8)}...${token.slice(-4)}` : "";
}

function stringValue(value) {
  return String(value ?? "").trim();
}
