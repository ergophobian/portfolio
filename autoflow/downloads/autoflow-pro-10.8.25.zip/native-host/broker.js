import fs from "node:fs";
import { chmod, mkdir, open, readFile, rm, stat, unlink, writeFile } from "node:fs/promises";
import crypto from "node:crypto";
import http from "node:http";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  AGENT_BRIDGE_VERSION,
  createAgentBridgeErrorResponse,
  createAgentBridgeRequest,
  createAgentBridgeSuccessResponse
} from "../src/core/agent/agent-bridge-protocol.js";
import {
  BROWSER_BRIDGE_CAPABILITIES,
  BROWSER_BROKER_WS_PATH,
  BROWSER_CLIENT_HELLO_TYPE,
  BROWSER_PRE_PAIR_COMMANDS,
  BROWSER_TRANSPORT,
  buildBrowserClientHelloPayload,
  findForbiddenBinaryMedia,
  isAllowedBrowserOrigin,
  isBrowserCapabilityAllowed,
  parseBrowserOriginAllowlist
} from "../src/core/agent/browser-broker-transport.js";
import {
  createInMemoryPairingState,
  handleNativeHostMessage,
  pairedClientMatchesToken
} from "./host-core.js";
import {
  decodeNativeMessageFrames,
  encodeNativeMessage,
  MAX_NATIVE_SOCKET_MESSAGE_BYTES
} from "./native-message.js";
import { BROKER_HEALTH_STATES, buildBrokerHealth } from "../src/core/agent/broker-health.js";
import {
  importBrowserReferenceFromUrl,
  parseRefImportOriginAllowlist
} from "../src/core/agent/browser-ref-import.js";

const DEFAULT_REQUEST_TIMEOUT_MS = 30000;
const SOCKET_CONNECT_TIMEOUT_MS = 300;
const LOCK_RECLAIM_MAX_ATTEMPTS = 5;
const LOCK_RECLAIM_RETRY_DELAY_MS = 10;
const SOCKET_FILE_NAME = "agent-bridge.sock";
const DISCOVERY_FILE_NAME = "bridge.json";
const WINDOWS_PIPE_NAME = "auto-flow-agent-bridge";
const DEBUG_LOG_PATH = process.env.AUTOFLOW_NATIVE_DEBUG_LOG || "";
const NATIVE_HOST_VERSION = "10.8.24";
const NATIVE_HOST_STARTED_AT = new Date().toISOString();
const DEFAULT_WS_PATH = "/v1/extension";
const DEFAULT_BROWSER_WS_PATH = BROWSER_BROKER_WS_PATH;
const DEFAULT_HELLO_PATH = "/v1/hello";
const DEFAULT_WS_PORT = 17677;
const DEFAULT_WS_PORT_RANGE = Object.freeze(Array.from({ length: 10 }, (_unused, index) => DEFAULT_WS_PORT + index));
const MAX_WS_FRAME_BUFFER_BYTES = MAX_NATIVE_SOCKET_MESSAGE_BYTES;
const BROWSER_MEDIA_PATH_PREFIX = "/v1/browser-media/";
const BROWSER_MEDIA_GRANT_TTL_MS = 2 * 60 * 1000;
const WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
const BROWSER_PRE_PAIR_COMMAND_SET = new Set(BROWSER_PRE_PAIR_COMMANDS);

export function createNativeBroker(options = {}) {
  return new NativeBroker(options);
}

export function getAutoFlowRuntimeDir(options = {}) {
  const env = options.env || process.env;
  if (env.AUTOFLOW_RUNTIME_DIR) return path.resolve(env.AUTOFLOW_RUNTIME_DIR);
  if (process.platform === "darwin") {
    return path.join(os.homedir(), "Library", "Application Support", "Auto Flow", "runtime");
  }
  return path.join(os.tmpdir(), `auto-flow-${process.getuid?.() ?? "user"}`);
}

export function getDefaultBrokerSocketPath(options = {}) {
  const env = options.env || process.env;
  return env.AUTOFLOW_BRIDGE_SOCKET
    || env.AUTOFLOW_BROKER_SOCKET
    || (platformFromOptions(options) === "win32" ? windowsBrokerPipePath(options) : "")
    || path.join(getAutoFlowRuntimeDir(options), SOCKET_FILE_NAME);
}

export function getDefaultBridgeDiscoveryPath(options = {}) {
  const env = options.env || process.env;
  return env.AUTOFLOW_BRIDGE_DISCOVERY_FILE
    || path.join(getAutoFlowRuntimeDir(options), DISCOVERY_FILE_NAME);
}

export async function readBridgeDiscoveryFile(options = {}) {
  const filePath = options.discoveryPath || getDefaultBridgeDiscoveryPath(options);
  const raw = await readFile(filePath, "utf8");
  return JSON.parse(raw);
}

export async function forceReclaimBrokerSocket(socketPath) {
  if (!socketPath || isWindowsNamedPipePath(socketPath)) {
    return {
      ok: false,
      skipped: true,
      socketPath: stringValue(socketPath)
    };
  }
  const lockPath = `${socketPath}.lock`;
  await rm(socketPath, { force: true }).catch(() => {});
  await rm(lockPath, { force: true }).catch(() => {});
  return {
    ok: true,
    socketPath,
    lockPath
  };
}

export async function sendBrokerRequest(socketPath, request, options = {}) {
  const timeoutMs = positiveInteger(options.timeoutMs, DEFAULT_REQUEST_TIMEOUT_MS);
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ path: socketPath });
    let pending = Buffer.alloc(0);
    let connected = false;
    let writeStarted = false;
    let settled = false;
    const timer = setTimeout(() => {
      finish(reject, brokerError(
        writeStarted ? "NATIVE_BROKER_WRITE_AMBIGUOUS" : "NATIVE_BROKER_TIMEOUT",
        writeStarted
          ? "Auto Flow native broker did not acknowledge the request before the connection timed out; the write result is ambiguous and must not be retried."
          : `Auto Flow native broker timed out after ${timeoutMs}ms.`,
        requestFailureDetails({ socketPath, timeoutMs, request, writeStarted })
      ));
    }, timeoutMs);

    socket.once("connect", () => {
      connected = true;
      try {
        const encoded = encodeNativeMessage(request);
        writeStarted = true;
        socket.write(encoded);
      } catch (error) {
        finish(reject, brokerError("NATIVE_BROKER_WRITE_FAILED", error?.message || String(error), requestFailureDetails({
          socketPath,
          request,
          writeStarted,
          causeCode: error?.code || ""
        })));
      }
    });

    socket.on("data", (chunk) => {
      try {
        pending = Buffer.concat([pending, chunk]);
        const decoded = decodeNativeMessageFrames(pending, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES });
        pending = decoded.remaining;
        if (!decoded.messages.length) return;
        finish(resolve, decoded.messages[0]);
      } catch (error) {
        finish(reject, brokerError("NATIVE_BROKER_RESPONSE_INVALID", error?.message || String(error), requestFailureDetails({
          socketPath,
          request,
          writeStarted,
          connected
        })));
      }
    });

    socket.once("error", (error) => {
      finish(reject, brokerError(
        writeStarted ? "NATIVE_BROKER_WRITE_AMBIGUOUS" : "NATIVE_BROKER_UNAVAILABLE",
        writeStarted
          ? "Auto Flow native broker disconnected after accepting a request write; the result is ambiguous and must not be retried."
          : (error?.message || "Auto Flow native broker is unavailable."),
        requestFailureDetails({
          socketPath,
          request,
          writeStarted,
          connected,
          causeCode: error?.code || ""
        })
      ));
    });

    socket.once("end", () => {
      if (!settled) {
        finish(reject, brokerError(
          writeStarted ? "NATIVE_BROKER_WRITE_AMBIGUOUS" : "NATIVE_BROKER_NO_RESPONSE",
          writeStarted
            ? "Auto Flow native broker closed after accepting a request write; the result is ambiguous and must not be retried."
            : "Auto Flow native broker closed without a response.",
          requestFailureDetails({ socketPath, request, writeStarted, connected })
        ));
      }
    });

    socket.once("close", () => {
      if (settled) return;
      finish(reject, brokerError(
        writeStarted ? "NATIVE_BROKER_WRITE_AMBIGUOUS" : "NATIVE_BROKER_UNAVAILABLE",
        writeStarted
          ? "Auto Flow native broker closed after accepting a request write; the result is ambiguous and must not be retried."
          : "Auto Flow native broker closed before a response was received.",
        requestFailureDetails({ socketPath, request, writeStarted, connected })
      ));
    });

    function finish(callback, value) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.destroy();
      callback(value);
    }
  });
}

class NativeBroker {
  constructor(options = {}) {
    const env = options.env || process.env;
    this.socketPath = options.socketPath || getDefaultBrokerSocketPath(options);
    this.lockPath = options.lockPath
      || (isWindowsNamedPipePath(this.socketPath) ? "" : `${this.socketPath}.lock`);
    this.lockHandle = null;
    this.lockId = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    this.socketIdentity = null;
    this.pairingStorePath = options.pairingStorePath
      || env.AUTOFLOW_BROKER_PAIRING_STORE
      || (options.env ? path.join(getAutoFlowRuntimeDir(options), "broker-pairings.json") : "");
    this.requestTimeoutMs = positiveInteger(
      options.requestTimeoutMs || env.AUTOFLOW_BRIDGE_FORWARD_TIMEOUT_MS || env.AUTOFLOW_BRIDGE_REQUEST_TIMEOUT_MS,
      DEFAULT_REQUEST_TIMEOUT_MS
    );
    this.state = options.pairingState || createInMemoryPairingState(options);
    this.server = null;
    this.startPromise = null;
    this.closePromise = null;
    this.clientSockets = new Set();
    this.httpServer = null;
    this.wsConnections = new Set();
    this.extension = null;
    this.extensions = new Map();
    this.extensionSequence = 0;
    this.brokerInstanceId = options.brokerInstanceId || `broker-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    this.wsEnabled = options.wsEnabled === true || options.ws === true || Boolean(env.AUTOFLOW_WS_BROKER_PORT || env.AUTOFLOW_BRIDGE_WS_PORT);
    this.wsHost = options.wsHost || env.AUTOFLOW_WS_BROKER_HOST || "127.0.0.1";
    this.wsPortSetting = options.wsPort ?? env.AUTOFLOW_WS_BROKER_PORT ?? env.AUTOFLOW_BRIDGE_WS_PORT ?? "auto";
    this.wsPortRange = normalizeWsPortRange(options.wsPortRange, DEFAULT_WS_PORT_RANGE);
    this.allowUndiscoverableWsPort = options.allowUndiscoverableWsPort === true || Number(this.wsPortSetting) === 0;
    this.allowNoOriginWs = options.allowNoOriginWs === true;
    this.allowedExtensionId = stringValue(options.allowedExtensionId || env.AUTOFLOW_EXTENSION_ID || "");
    this.wsRegistrationSecret = stringValue(options.wsRegistrationSecret || env.AUTOFLOW_WS_REGISTRATION_SECRET || "");
    this.registrationProof = "";
    this.wsPort = null;
    this.wsPath = options.wsPath || DEFAULT_WS_PATH;
    this.browserWsPath = options.browserWsPath || DEFAULT_BROWSER_WS_PATH;
    this.allowedBrowserOrigins = parseBrowserOriginAllowlist(
      options.allowedBrowserOrigins ?? options.browserOrigins ?? env.AUTOFLOW_BROWSER_ORIGINS,
      {
        // Opt-in default loopback only when explicitly requested (tests / local PatchWork).
        allowDefaultLoopback: options.allowDefaultBrowserLoopbackOrigins === true
          || env.AUTOFLOW_BROWSER_ALLOW_DEFAULT_LOOPBACK === "1"
      }
    );
    // Loopback pages (127.0.0.1/localhost, ANY port) may discover the broker
    // and request pairing by default — the sidepanel Pair Bridge click and the
    // pairing token remain the human consent gates. Remote origins still need
    // the explicit allowlist. Disable with AUTOFLOW_BROWSER_LOOPBACK=off.
    this.allowBrowserLoopbackOrigins = options.allowBrowserLoopbackOrigins !== false
      && stringValue(env.AUTOFLOW_BROWSER_LOOPBACK).toLowerCase() !== "off";
    this.allowedRefImportOrigins = parseRefImportOriginAllowlist(
      options.allowedRefImportOrigins ?? env.AUTOFLOW_REF_IMPORT_ORIGINS,
      { includePatchWorkDefault: options.includePatchWorkDefaultRefOrigin !== false }
    );
    this.refImportRuntimeDir = path.resolve(options.refImportRuntimeDir || getAutoFlowRuntimeDir(options));
    this.refImporter = typeof options.refImporter === "function"
      ? options.refImporter
      : importBrowserReferenceFromUrl;
    this.allowMissingBrowserOrigin = options.allowMissingBrowserOrigin === true;
    this.browserClientCount = 0;
    this.browserMediaGrants = new Map();
    this.browserMediaGrantTtlMs = positiveInteger(options.browserMediaGrantTtlMs, BROWSER_MEDIA_GRANT_TTL_MS);
    this.httpUrl = "";
    this.wsUrl = "";
    this.browserWsUrl = "";
    this.discoveryPath = options.discoveryPath || getDefaultBridgeDiscoveryPath(options);
    this.laneSelections = new Map();
    this.pendingExtensionRequests = new Map();
    this.now = typeof options.now === "function" ? options.now : () => new Date().toISOString();
    this.versionInfoProvider = typeof options.versionInfoProvider === "function"
      ? options.versionInfoProvider
      : () => ({ ...nativeVersionInfo(), ...(isPlainObject(options.versionInfo) ? options.versionInfo : {}) });
    this.installedIdentityProvider = typeof options.installedIdentityProvider === "function"
      ? options.installedIdentityProvider
      : () => normalizeInstalledIdentity(options.installedIdentity || installedNativeHostIdentity(options));
  }

  async start() {
    if (this.server?.listening) return this;
    if (this.startPromise) return this.startPromise;
    this.startPromise = this.startInternal();
    try {
      return await this.startPromise;
    } finally {
      this.startPromise = null;
    }
  }

  async close() {
    if (this.closePromise) return this.closePromise;
    this.closePromise = this.closeInternal();
    try {
      return await this.closePromise;
    } finally {
      this.closePromise = null;
    }
  }

  async startInternal() {
    await this.loadPairingStore();
    let server = null;
    try {
      await this.acquireSocketLock();
      await prepareSocketPath(this.socketPath);

      server = net.createServer((socket) => {
        this.handleSocket(socket);
      });

      await new Promise((resolve, reject) => {
        const onError = (error) => reject(error);
        server.once("error", onError);
        server.listen(this.socketPath, () => {
          server.off("error", onError);
          resolve();
        });
      });
      this.server = server;

      await chmod(this.socketPath, 0o600).catch(() => {});
      this.socketIdentity = await currentSocketIdentity(this.socketPath);
      if (this.wsEnabled) await this.startLoopbackServer();
      await this.writeRuntimeDiscovery();
    } catch (error) {
      server?.close?.(() => {});
      this.server = null;
      this.socketIdentity = null;
      await this.closeLoopbackServer();
      await this.releaseSocketLock();
      throw error;
    }
    return this;
  }

  async closeInternal() {
    if (this.startPromise) await this.startPromise.catch(() => {});
    const pending = [...this.pendingExtensionRequests.values()];
    this.pendingExtensionRequests.clear();
    for (const entry of pending) {
      clearTimeout(entry.timeout || entry.timer);
      entry.reject(brokerError("EXTENSION_BRIDGE_NOT_CONNECTED", "Auto Flow extension bridge disconnected."));
    }

    this.extension = null;
    this.extensions.clear();
    for (const socket of [...this.clientSockets]) {
      socket.destroy();
    }
    this.clientSockets.clear();
    await this.closeLoopbackServer();
    if (this.server) {
      const server = this.server;
      this.server = null;
      await new Promise((resolve) => {
        server.close(() => resolve());
      });
    }
    await this.removeOwnedSocketPath();
    await this.releaseSocketLock();
  }

  async acquireSocketLock() {
    if (!this.lockPath) return;
    await mkdir(path.dirname(this.lockPath), { recursive: true, mode: 0o700 });
    const payload = JSON.stringify({
      pid: process.pid,
      lockId: this.lockId,
      socketPath: this.socketPath,
      lockedAt: this.now(),
      nativeRuntime: this.nativeVersionInfo().nativeRuntime
    }, null, 2);
    let attempts = 0;
    for (;;) {
      try {
        this.lockHandle = await open(this.lockPath, "wx", 0o600);
        await this.lockHandle.writeFile(`${payload}\n`);
        return;
      } catch (error) {
        if (error?.code !== "EEXIST") throw error;
        const existing = await readLockFile(this.lockPath);
        const live = lockOwnerAlive(existing);
        const activeSocket = fs.existsSync(this.socketPath) && await canConnect(this.socketPath);
        if (activeSocket) {
          throw brokerError("NATIVE_BROKER_ALREADY_RUNNING", `Auto Flow native broker is already running at ${this.socketPath}`, {
            socketPath: this.socketPath,
            lockPath: this.lockPath,
            lock: existing
          });
        }
        if (live && attempts < LOCK_RECLAIM_MAX_ATTEMPTS) {
          attempts += 1;
          await delay(LOCK_RECLAIM_RETRY_DELAY_MS);
          continue;
        }
        await rm(this.lockPath, { force: true }).catch(() => {});
        if (!live) attempts += 1;
        if (!live && attempts >= LOCK_RECLAIM_MAX_ATTEMPTS) {
          throw brokerError("NATIVE_BROKER_LOCK_RECLAIM_FAILED", `Auto Flow native broker could not reclaim stale lock at ${this.lockPath}.`, {
            socketPath: this.socketPath,
            lockPath: this.lockPath,
            attempts
          });
        }
        await delay(LOCK_RECLAIM_RETRY_DELAY_MS);
      }
    }
  }

  async releaseSocketLock() {
    const handle = this.lockHandle;
    this.lockHandle = null;
    if (handle) await handle.close().catch(() => {});
    if (handle && this.lockPath) {
      const current = await readLockFile(this.lockPath);
      if (!current.lockId || current.lockId === this.lockId) {
        await rm(this.lockPath, { force: true }).catch(() => {});
      }
    }
  }

  async removeOwnedSocketPath() {
    if (isWindowsNamedPipePath(this.socketPath)) return;
    if (this.lockPath) {
      const currentLock = await readLockFile(this.lockPath);
      if (currentLock.lockId && currentLock.lockId !== this.lockId) {
        this.socketIdentity = null;
        return;
      }
    }
    const identity = await currentSocketIdentity(this.socketPath);
    if (identity && sameSocketIdentity(identity, this.socketIdentity)) {
      await rm(this.socketPath, { force: true }).catch(() => {});
    }
    this.socketIdentity = null;
  }

  registerExtension(connection = {}) {
    if (typeof connection.send !== "function") {
      throw new TypeError("native broker extension registration requires send(message)");
    }

    const extensionId = stringValue(connection.extensionId || connection.id || "auto-flow-extension");
    const transport = stringValue(connection.transport || connection.metadata?.transport || "native_messaging_legacy");
    const registrationProof = stringValue(connection.registrationProof);
    // A service-worker restart can briefly leave its old WebSocket alive. Treat
    // the persisted profile proof as the browser-profile identity and replace
    // that stale socket instead of showing the same Flow tab twice.
    if (registrationProof) {
      for (const existing of [...this.extensions.values()]) {
        if (existing.id !== extensionId || existing.transport !== transport || existing.registrationProof !== registrationProof) continue;
        this.unregisterExtension(existing);
        try {
          existing.disconnect?.("superseded_profile_connection");
        } catch {}
      }
    }

    const ownerId = `extension-${++this.extensionSequence}`;
    const extension = {
      key: ownerId,
      ownerId,
      token: Symbol("extension"),
      id: extensionId,
      connectedAt: this.now(),
      lastSeenAt: this.now(),
      metadata: isPlainObject(connection.metadata) ? { ...connection.metadata } : {},
      transport,
      registrationProof,
      disconnect: typeof connection.disconnect === "function" ? connection.disconnect : null,
      send: connection.send
    };
    extension.metadata.transport = extension.transport;

    this.extensions.set(extension.key, extension);
    this.extension = extension;
    debugLog("broker.extension_registered", {
      extensionId: extension.id,
      extensionKey: extension.key,
      ownerId: extension.ownerId,
      extensionVersion: extension.metadata?.extensionVersion || "",
      transport: extension.transport
    });
    return {
      extensionKey: extension.key,
      ownerId: extension.ownerId,
      extensionId: extension.id,
      connectedAt: extension.connectedAt,
      close: () => this.unregisterExtension(extension)
    };
  }

  unregisterExtension(registration = this.extension) {
    const extension = this.resolveExtensionRegistration(registration);
    if (!extension?.token) return false;

    this.extensions.delete(extension.key);
    if (this.extension?.token === extension.token) {
      const remaining = [...this.extensions.values()];
      this.extension = remaining.length ? remaining[remaining.length - 1] : null;
    }
    debugLog("broker.extension_unregistered", {
      extensionId: extension.id,
      extensionKey: extension.key,
      ownerId: extension.ownerId
    });
    let rejected = 0;
    for (const [pendingKey, entry] of this.pendingExtensionRequests) {
      if (entry.ownerId !== extension.ownerId) continue;
      this.pendingExtensionRequests.delete(pendingKey);
      clearTimeout(entry.timeout || entry.timer);
      rejected += 1;
      entry.reject(brokerError("EXTENSION_BRIDGE_NOT_CONNECTED", "Auto Flow extension bridge disconnected.", {
        ownerId: entry.ownerId,
        requestId: entry.requestId,
        method: entry.method
      }));
    }
    debugLog("broker.extension_unregistered_pending_rejected", {
      extensionId: extension.id,
      extensionKey: extension.key,
      ownerId: extension.ownerId,
      rejected
    });
    return true;
  }

  resolveExtensionRegistration(registration = this.extension, options = {}) {
    if (registration?.token) return registration;
    const ownerId = stringValue(registration?.ownerId || registration?.extensionKey || registration?.key);
    if (ownerId) {
      return this.extensions.get(ownerId) || (options.allowStale ? {
        key: ownerId,
        ownerId,
        id: stringValue(registration?.extensionId || registration?.id),
        metadata: isPlainObject(registration?.metadata) ? { ...registration.metadata } : {}
      } : null);
    }
    return registration ? null : this.extension;
  }

  extensionOwnerId(extension = this.extension) {
    return stringValue(extension?.ownerId || extension?.key || extension?.extensionKey);
  }

  pendingExtensionRequestKey(ownerId, requestId) {
    return `${stringValue(ownerId)}\u001f${stringValue(requestId)}`;
  }

  pendingExtensionRequestsForRequestId(requestId) {
    const normalizedRequestId = stringValue(requestId);
    if (!normalizedRequestId) return [];
    return [...this.pendingExtensionRequests.entries()]
      .filter(([, entry]) => entry.requestId === normalizedRequestId);
  }

  async handleExtensionMessage(ownerOrMessage = {}, maybeMessage = undefined) {
    const hasExplicitOwner = maybeMessage !== undefined;
    const owner = hasExplicitOwner ? this.resolveExtensionRegistration(ownerOrMessage, { allowStale: true }) : null;
    const message = hasExplicitOwner ? maybeMessage : ownerOrMessage;
    const requestId = stringValue(message.id);
    const ownerId = this.extensionOwnerId(owner);
    const pendingMatches = this.pendingExtensionRequestsForRequestId(requestId);
    debugLog("broker.from_extension", {
      id: requestId,
      type: message?.type || "",
      ok: message?.ok,
      ownerId,
      pending: pendingMatches.length > 0,
      pendingMatches: pendingMatches.length
    });
    if (pendingMatches.length && typeof message.ok === "boolean") {
      let pendingKey = "";
      let pending = null;
      if (ownerId) {
        pendingKey = this.pendingExtensionRequestKey(ownerId, requestId);
        pending = this.pendingExtensionRequests.get(pendingKey) || null;
      } else if (pendingMatches.length === 1) {
        [pendingKey, pending] = pendingMatches[0];
      }
      if (!pending) {
        const expectedOwnerIds = pendingMatches.map(([, entry]) => entry.ownerId).filter(Boolean);
        const error = {
          code: "BRIDGE_RESPONSE_OWNER_MISMATCH",
          message: "Auto Flow extension response owner did not match the routed request owner.",
          details: {
            requestId,
            responseOwnerId: ownerId,
            expectedOwnerIds,
            pendingExtensionRequests: this.pendingExtensionRequestSummaries({
              requestId
            })
          }
        };
        debugLog("broker.extension_response_owner_mismatch", {
          requestId,
          responseOwnerId: ownerId,
          expectedOwnerIds
        });
        return createAgentBridgeErrorResponse(message, error);
      }
      clearTimeout(pending.timeout || pending.timer);
      this.pendingExtensionRequests.delete(pendingKey);
      pending.resolve(message);
      return null;
    }
    if (typeof message.ok === "boolean") {
      const error = {
        code: "BRIDGE_RESPONSE_NOT_PENDING",
        message: "Auto Flow extension response did not match a pending broker request.",
        details: {
          requestId,
          responseOwnerId: ownerId
        }
      };
      debugLog("broker.extension_response_not_pending", {
        requestId,
        responseOwnerId: ownerId,
        type: message?.type || ""
      });
      return createAgentBridgeErrorResponse(message, error);
    }

    return this.handleClientRequest(message);
  }

  async handleClientRequest(message = {}) {
    debugLog("broker.from_client", {
      id: message?.id || "",
      type: message?.type || "",
      hasExtension: Boolean(this.extension),
      extensionCount: this.extensions.size
    });
    if (message?.type === "bridge.targets.list") {
      const payload = await this.bridgeTargetsPayload(message.payload || {});
      return createAgentBridgeSuccessResponse(message, payload);
    }
    if (message?.type === "bridge.target.use") {
      try {
        const payload = await this.useBridgeTarget(message.payload || {});
        return createAgentBridgeSuccessResponse(message, payload);
      } catch (error) {
        return createAgentBridgeErrorResponse(message, normalizeBridgeRoutingError(error));
      }
    }
    if (message?.type === "pair.reset") {
      this.state.pairedClients.clear();
      this.state.pendingPairing = null;
      this.laneSelections.clear();
      this.allowedExtensionId = "";
      this.registrationProof = "";
      const persistence = await this.persistPairingStore({ action: "pair.reset" });
      return createAgentBridgeSuccessResponse(message, {
        reset: true,
        pairingStorePath: this.pairingStorePath,
        persistence
      });
    }
    if (message?.type === "lane.use") {
      try {
        const payload = await this.useNamedLane(message.payload || {});
        return createAgentBridgeSuccessResponse(message, payload);
      } catch (error) {
        return createAgentBridgeErrorResponse(message, normalizeBridgeRoutingError(error));
      }
    }
    if (message?.type === "lane.list") {
      try {
        const payload = await this.namedLaneRegistryPayload(message.payload || {});
        return createAgentBridgeSuccessResponse(message, payload);
      } catch (error) {
        return createAgentBridgeErrorResponse(message, normalizeBridgeRoutingError(error));
      }
    }
    if (message?.type === "lane.unbind") {
      try {
        const payload = await this.unbindNamedLane(message.payload || {});
        return createAgentBridgeSuccessResponse(message, payload);
      } catch (error) {
        return createAgentBridgeErrorResponse(message, normalizeBridgeRoutingError(error));
      }
    }
    if (message?.type === "broker.ws.enable") {
      const previous = {
        wsEnabled: this.wsEnabled,
        wsPortSetting: this.wsPortSetting,
        allowUndiscoverableWsPort: this.allowUndiscoverableWsPort
      };
      const alreadyAvailable = Boolean(this.httpServer && this.wsUrl);
      if (!alreadyAvailable) {
        const requestedPort = message?.payload?.port ?? message?.payload?.wsPort ?? "auto";
        this.wsEnabled = true;
        this.wsPortSetting = requestedPort;
        this.allowUndiscoverableWsPort = Number(requestedPort) === 0;
        try {
          await this.startLoopbackServer();
          await this.writeRuntimeDiscovery();
        } catch (error) {
          await this.closeLoopbackServer().catch(() => {});
          this.wsEnabled = previous.wsEnabled;
          this.wsPortSetting = previous.wsPortSetting;
          this.allowUndiscoverableWsPort = previous.allowUndiscoverableWsPort;
          return createAgentBridgeErrorResponse(message, {
            code: error?.code || "WS_BROKER_ENABLE_FAILED",
            message: error?.message || String(error || "Auto Flow WS broker could not be enabled.")
          });
        }
      }
      let status = this.statusPayload();
      const extensionRefresh = [];
      if (status.bridge?.wsUrl) {
        const legacyExtensions = [...this.extensions.values()]
          .filter((extension) => extension.transport === "native_messaging_legacy");
        for (const extension of legacyExtensions) {
          try {
            const response = await this.sendToExtension(internalBridgeRequest("bridge.ws.refresh", {
              wsUrl: status.bridge.wsUrl,
              timeoutMs: 5000
            }), extension);
            extensionRefresh.push({
              extensionId: extension.id,
              ownerId: extension.ownerId,
              ok: response?.ok === true,
              code: stringValue(response?.error?.code)
            });
          } catch (error) {
            extensionRefresh.push({
              extensionId: extension.id,
              ownerId: extension.ownerId,
              ok: false,
              code: stringValue(error?.code || "WS_BROKER_REFRESH_FAILED")
            });
          }
        }
        status = this.statusPayload();
      }
      return createAgentBridgeSuccessResponse(message, {
        enabled: Boolean(status.bridge?.wsUrl),
        activated: !alreadyAvailable,
        brokerInstanceId: status.bridge?.brokerInstanceId || this.brokerInstanceId,
        socketPath: this.socketPath,
        wsUrl: status.bridge?.wsUrl || "",
        browserWsUrl: status.bridge?.browserWsUrl || "",
        httpUrl: status.bridge?.httpUrl || "",
        extensionRefresh,
        status
      });
    }
    if (message?.type === "broker.shutdown_if_stale") {
      const payload = this.statusPayload();
      const stale = Array.isArray(payload.blockers)
        && payload.blockers.some((blocker) => stringValue(blocker?.code) === "STALE_NATIVE_HOST_PROCESS");
      if (!stale) {
        return createAgentBridgeErrorResponse(message, {
          code: "NATIVE_BROKER_NOT_STALE",
          message: "Auto Flow native broker is current and will not shut down."
        });
      }
      setTimeout(() => {
        this.close().catch((error) => {
          debugLog("broker.shutdown_if_stale_failed", {
            error: error?.message || String(error || "broker stale shutdown failed")
          });
        });
      }, 0);
      return createAgentBridgeSuccessResponse(message, {
        shuttingDown: true,
        blockers: payload.blockers,
        socketPath: this.socketPath
      });
    }
    if (message?.type === "pair.start") {
      const approvalError = await this.requirePairingApproval(message);
      if (approvalError) return approvalError;
    }
    let routedExtension = null;
    try {
      routedExtension = await this.extensionForRequest(message);
    } catch (error) {
      return createAgentBridgeErrorResponse(message, normalizeBridgeRoutingError(error));
    }
    if (message?.type === "status.get" && routedExtension && this.isClientPaired(message)) {
      const response = await this.forwardToExtension(message, { extension: routedExtension });
      if (response?.ok === false || response?.error) return response;
      return {
        ...response,
        payload: this.mergeForwardedStatusPayload(response.payload || {}, routedExtension)
      };
    }
    if (message?.type === "pair.confirm" && this.wsEnabled) {
      const extensionStillConnected = Boolean(
        routedExtension?.token
        && this.extensions.get(routedExtension.key)?.token === routedExtension.token
      );
      const pinnedProof = stringValue(routedExtension?.registrationProof);
      if (!extensionStillConnected || !routedExtension?.id || !pinnedProof) {
        return createAgentBridgeErrorResponse(message, {
          code: "WS_EXTENSION_REGISTRATION_PROOF_REQUIRED",
          message: "Pairing requires the approved WS extension to remain connected with a registration proof. Reopen Auto Flow, then retry pairing."
        });
      }
    }
    const response = await handleNativeHostMessage(message, this.state, {
      statusProvider: () => this.statusPayload(),
      forwardToExtension: (request) => this.forwardToExtension(request, { extension: routedExtension })
    });
    if (message?.type === "pair.confirm" && response?.ok === true) {
      if (!this.allowedExtensionId && routedExtension?.id) {
        this.allowedExtensionId = routedExtension.id;
      }
      if (!this.registrationProof) {
        const pinnedProof = stringValue(routedExtension?.registrationProof);
        if (pinnedProof) this.registrationProof = pinnedProof;
      }
      await this.persistPairingStore({ action: "pair.confirm" });
    }
    return response;
  }

  async loadPairingStore() {
    if (!this.pairingStorePath) return;
    const raw = await readFile(this.pairingStorePath, "utf8").catch(() => "");
    if (!raw) return;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return;
    }
    const clients = Array.isArray(parsed?.pairedClients) ? parsed.pairedClients : [];
    const restored = new Map();
    for (const client of clients) {
      const clientId = stringValue(client?.clientId);
      const pairingTokenHash = stringValue(client?.pairingTokenHash);
      if (!clientId || !pairingTokenHash) continue;
      restored.set(clientId, {
        clientId,
        pairingId: stringValue(client?.pairingId),
        pairingTokenHash,
        pairingTokenPreview: stringValue(client?.pairingTokenPreview),
        pairedAt: stringValue(client?.pairedAt)
      });
    }
    this.state.pairedClients = restored;
    const selections = parsed?.laneSelections;
    const restoredSelections = new Map();
    if (Array.isArray(selections)) {
      for (const selection of selections) {
        const laneId = stringValue(selection?.laneId);
        if (!laneId) continue;
        restoredSelections.set(laneId, normalizeLaneSelection(selection));
      }
    } else if (isPlainObject(selections)) {
      for (const [laneId, selection] of Object.entries(selections)) {
        const normalizedLaneId = stringValue(selection?.laneId || laneId);
        if (!normalizedLaneId) continue;
        restoredSelections.set(normalizedLaneId, normalizeLaneSelection({ ...selection, laneId: normalizedLaneId }));
      }
    }
    this.laneSelections = restoredSelections;
    this.allowedExtensionId = stringValue(parsed?.allowedExtensionId || this.allowedExtensionId);
    this.registrationProof = stringValue(parsed?.registrationProof || this.registrationProof);
    this.state.storage = "file";
  }

  async savePairingStore() {
    if (!this.pairingStorePath) return;
    const pairedClients = [...this.state.pairedClients.values()].map((client) => ({
      clientId: stringValue(client.clientId),
      pairingId: stringValue(client.pairingId),
      pairingTokenHash: stringValue(client.pairingTokenHash),
      pairingTokenPreview: stringValue(client.pairingTokenPreview),
      pairedAt: stringValue(client.pairedAt)
    })).filter((client) => client.clientId && client.pairingTokenHash);
    await mkdir(path.dirname(this.pairingStorePath), { recursive: true, mode: 0o700 });
    const payload = JSON.stringify({
      version: 1,
      storage: "file",
      allowedExtensionId: this.allowedExtensionId,
      registrationProof: this.registrationProof,
      pairedClients,
      laneSelections: [...this.laneSelections.values()].map((selection) => normalizeLaneSelection(selection))
    }, null, 2);
    await writeFile(this.pairingStorePath, `${payload}\n`, { mode: 0o600 });
    await chmod(this.pairingStorePath, 0o600).catch(() => {});
    this.state.storage = "file";
  }

  async persistPairingStore(context = {}) {
    try {
      await this.savePairingStore();
      return { ok: true };
    } catch (error) {
      debugLog("broker.pairing_store_save_failed", {
        ...context,
        code: error?.code || "",
        message: error?.message || String(error || "pairing store save failed")
      });
      return {
        ok: false,
        error: {
          code: error?.code || "PAIRING_STORE_SAVE_FAILED",
          message: error?.message || String(error || "pairing store save failed")
        }
      };
    }
  }

  async requirePairingApproval(request = {}) {
    let extension;
    try {
      extension = await this.extensionForRequest(request);
    } catch (error) {
      return createAgentBridgeErrorResponse(request, normalizeBridgeRoutingError(error));
    }
    if (!extension) {
      return createAgentBridgeErrorResponse(request, {
        code: "EXTENSION_BRIDGE_NOT_CONNECTED",
        message: "Auto Flow extension bridge is not connected. Open Auto Flow and approve the requesting client."
      });
    }
    let response;
    try {
      response = await this.sendToExtension(request, extension);
    } catch (error) {
      return createAgentBridgeErrorResponse(request, {
        code: error?.code || "PAIRING_APPROVAL_UNAVAILABLE",
        message: error?.message || "Auto Flow extension did not approve pairing.",
        details: error?.details
      });
    }
    if (response?.ok === false || response?.error) return response;
    if (response?.payload?.approved === true) return null;
    return createAgentBridgeErrorResponse(request, {
      code: "PAIRING_APPROVAL_REQUIRED",
      message: "Open Auto Flow and click Pair before starting CLI pairing."
    });
  }

  statusPayload() {
    const brokerAvailable = Boolean(this.server?.listening);
    const extensionConnected = Boolean(this.extension);
    const pairedClientCount = this.state.pairedClients.size;
    const paired = pairedClientCount > 0;
    const versionInfo = this.nativeVersionInfo();
    const installedNativeHost = this.installedNativeHostIdentity();
    const nativeHostBlockers = staleNativeHostBlockers(versionInfo.nativeRuntime, installedNativeHost);
    // A package-owned WS daemon is not the installed legacy native host. Keep
    // legacy mismatch diagnostics scoped to that fallback transport instead of
    // blocking an otherwise healthy WS broker.
    const blockers = this.wsEnabled ? [] : nativeHostBlockers;
    const bridgeState = blockers.length
      ? "stale_native_host"
      : (!brokerAvailable
        ? "broker_unavailable"
        : (extensionConnected ? (paired ? "connected" : "pairing_required") : "extension_disconnected"));
    const transport = isWindowsNamedPipePath(this.socketPath) ? "windows_named_pipe" : "unix_socket";
    const health = buildBrokerHealth({
      brokerAvailable,
      extensionConnected,
      paired,
      socketPath: this.socketPath,
      transport
    });
    const activeTransport = extensionConnected
      ? stringValue(this.extension?.transport || this.extension?.metadata?.transport || "native_messaging_legacy")
      : "";
    const wsAvailable = Boolean(this.wsEnabled && this.wsUrl);
    const transportDiagnostics = buildTransportDiagnostics({
      bridgeState,
      activeTransport,
      extensionConnected,
      paired,
      wsAvailable,
      wsUrl: this.wsUrl,
      browserWsUrl: this.browserWsUrl,
      httpUrl: this.httpUrl,
      browserOriginsConfigured: this.allowedBrowserOrigins.length > 0 || this.allowBrowserLoopbackOrigins,
      browserLoopbackAllowed: this.allowBrowserLoopbackOrigins,
      browserClientCount: this.browserClientCount,
      nativeConnected: activeTransport === "native_messaging_legacy" && extensionConnected,
      blockers: nativeHostBlockers
    });
    return {
      health,
      bridge: {
        state: bridgeState,
        healthState: health.state,
        health,
        hostAlive: brokerAvailable,
        socketPath: this.socketPath,
        transport,
        preferredTransport: "ws_broker",
        activeTransport: activeTransport || null,
        brokerInstanceId: this.brokerInstanceId,
        wsUrl: this.wsUrl,
        browserWsUrl: this.browserWsUrl,
        browserWsPath: this.browserWsPath,
        allowedBrowserOriginCount: this.allowedBrowserOrigins.length,
        allowedRefImportOriginCount: this.allowedRefImportOrigins.length,
        httpUrl: this.httpUrl,
        extensionConnected,
        paired,
        pairedClientCount,
        pendingPairing: Boolean(this.state.pendingPairing),
        storage: this.state.storage,
        bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
        packageVersion: versionInfo.packageVersion,
        nativeHostVersion: versionInfo.nativeHostVersion
      },
      preferredTransport: "ws_broker",
      activeTransport: activeTransport || null,
      transports: transportDiagnostics,
      pendingExtensionRequests: this.pendingExtensionRequestSummaries(),
      lanes: [...this.laneSelections.values()].map((selection) => paired
        ? normalizeLaneSelection(selection)
        : redactedLaneSelection(selection)),
      nativeRuntime: versionInfo.nativeRuntime,
      installedNativeHost,
      blockers,
      extension: {
        present: extensionConnected,
        id: this.extension?.id || "",
        connectedAt: this.extension?.connectedAt || null,
        version: this.extension?.metadata?.extensionVersion || "",
        transport: activeTransport || null
      },
      versions: {
        extensionVersion: this.extension?.metadata?.extensionVersion || "",
        packageVersion: versionInfo.packageVersion,
        bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
        nativeHostVersion: versionInfo.nativeHostVersion
      },
      auth: {
        state: paired ? "paired" : "pairing_required",
        paired
      },
      project: {
        state: "unknown",
        active: null,
        id: "",
        name: ""
      },
      extensionConnected,
      paired,
      storage: this.state.storage
    };
  }

  pendingExtensionRequestSummaries(filter = {}) {
    const nowMs = Date.now();
    const requestIdFilter = stringValue(filter.requestId);
    const ownerIdFilter = stringValue(filter.ownerId);
    return [...this.pendingExtensionRequests.values()]
      .filter((entry) => !requestIdFilter || entry.requestId === requestIdFilter)
      .filter((entry) => !ownerIdFilter || entry.ownerId === ownerIdFilter)
      .map((entry) => ({
        requestId: entry.requestId,
        ownerId: entry.ownerId,
        extensionId: entry.extensionId,
        projectId: entry.projectId,
        tabId: entry.tabId,
        laneId: entry.laneId,
        method: entry.method,
        ageMs: Math.max(0, nowMs - (entry.createdAtMs || nowMs))
      }));
  }

  nativeVersionInfo() {
    const versionInfo = this.versionInfoProvider();
    const packageVersion = stringValue(versionInfo?.packageVersion);
    const nativeHostVersion = stringValue(versionInfo?.nativeHostVersion);
    return {
      packageVersion,
      nativeHostVersion,
      bridgeProtocolVersion: Number(versionInfo?.bridgeProtocolVersion || AGENT_BRIDGE_VERSION),
      nativeRuntime: normalizeNativeRuntime(versionInfo?.nativeRuntime || versionInfo, {
        packageVersion,
        nativeHostVersion
      })
    };
  }

  installedNativeHostIdentity() {
    return normalizeInstalledIdentity(this.installedIdentityProvider());
  }

  mergeForwardedStatusPayload(payload = {}, registeredExtension = this.extension) {
    const local = this.statusPayload();
    const bridge = isPlainObject(payload.bridge) ? payload.bridge : {};
    const extension = isPlainObject(payload.extension) ? payload.extension : {};
    const versions = isPlainObject(payload.versions) ? payload.versions : {};
    const extensionVersion = stringValue(
      versions.extensionVersion
      || extension.version
      || payload.extensionVersion
      || registeredExtension?.metadata?.extensionVersion
      || local.versions.extensionVersion
    );
    const mergedVersions = {
      extensionVersion,
      packageVersion: local.versions.packageVersion,
      bridgeProtocolVersion: local.versions.bridgeProtocolVersion,
      nativeHostVersion: local.versions.nativeHostVersion
    };
    return {
      ...payload,
      bridge: {
        ...local.bridge,
        ...bridge,
        state: local.blockers.length ? "stale_native_host" : (bridge.state || local.bridge.state),
        preferredTransport: "ws_broker",
        activeTransport: local.bridge.activeTransport || bridge.activeTransport || null,
        wsUrl: local.bridge.wsUrl,
        browserWsUrl: local.bridge.browserWsUrl,
        browserWsPath: local.bridge.browserWsPath,
        allowedBrowserOriginCount: local.bridge.allowedBrowserOriginCount,
        httpUrl: local.bridge.httpUrl,
        brokerInstanceId: local.bridge.brokerInstanceId,
        packageVersion: mergedVersions.packageVersion,
        bridgeProtocolVersion: mergedVersions.bridgeProtocolVersion,
        nativeHostVersion: mergedVersions.nativeHostVersion
      },
      preferredTransport: "ws_broker",
      activeTransport: local.activeTransport || null,
      transports: local.transports,
      extension: {
        ...extension,
        present: extension.present ?? local.extension.present,
        id: stringValue(extension.id || local.extension.id),
        version: extensionVersion,
        transport: local.activeTransport || extension.transport || null
      },
      versions: mergedVersions,
      nativeRuntime: local.nativeRuntime,
      installedNativeHost: local.installedNativeHost,
      blockers: mergeBlockers(payload.blockers, local.blockers)
    };
  }

  async forwardToExtension(request, options = {}) {
    let extension = options.extension || null;
    try {
      extension = extension || await this.extensionForRequest(request);
      request = this.enrichLaneRoutedRequest(request);
    } catch (error) {
      return createAgentBridgeErrorResponse(request, normalizeBridgeRoutingError(error));
    }
    if (!extension) {
      return createAgentBridgeErrorResponse(request, {
        code: "EXTENSION_BRIDGE_NOT_CONNECTED",
        message: "Auto Flow extension bridge is not connected. Open Chrome with the Auto Flow extension bridge enabled."
      });
    }
    if (!this.isClientPaired(request)) {
      return createAgentBridgeErrorResponse(request, {
        code: "PAIRING_REQUIRED",
        message: "Pair this local client with Auto Flow before sending bridge commands."
      });
    }

    try {
      return await this.sendToExtension(request, extension);
    } catch (error) {
      return createAgentBridgeErrorResponse(request, {
        code: error?.code || "EXTENSION_BRIDGE_FAILED",
        message: error?.message || String(error || "extension bridge failed"),
        details: error?.details
      });
    }
  }

  enrichLaneRoutedRequest(request = {}) {
    const payload = isPlainObject(request.payload) ? request.payload : {};
    const laneId = stringValue(payload.laneId);
    if (!laneId) return request;
    const selection = this.laneSelections.get(laneId);
    if (!selection?.projectId || !selection?.tabId) return request;
    const hasFullPayloadTarget = Boolean(payload.projectId && payload.tabId);
    if (hasFullPayloadTarget) return request;
    return {
      ...request,
      payload: {
        ...payload,
        laneId,
        projectId: selection.projectId,
        tabId: String(selection.tabId)
      }
    };
  }

  isClientPaired(request = {}) {
    if (!this.state.pairedClients.size) return false;
    const clientId = stringValue(request.session?.clientId || request.payload?.clientId);
    if (!clientId) return false;
    const client = this.state.pairedClients.get(clientId);
    if (!client) return false;
    const pairingToken = stringValue(
      request.auth?.pairingToken
      || request.auth?.pairingCredential
      || request.payload?.pairingToken
      || request.payload?.pairingCredential
    );
    return pairedClientMatchesToken(client, pairingToken);
  }

  async sendToExtension(request, extension = this.extension) {
    if (!extension) {
      throw brokerError("EXTENSION_BRIDGE_NOT_CONNECTED", "Auto Flow extension bridge disconnected.");
    }
    const requestId = stringValue(request.id);
    if (!requestId) throw brokerError("INVALID_REQUEST_ID", "request id must be a non-empty string");
    const ownerId = this.extensionOwnerId(extension);
    if (!ownerId) throw brokerError("EXTENSION_BRIDGE_NOT_CONNECTED", "Auto Flow extension bridge owner is unavailable.");
    const pendingKey = this.pendingExtensionRequestKey(ownerId, requestId);
    if (this.pendingExtensionRequests.has(pendingKey)) {
      throw brokerError("DUPLICATE_REQUEST_ID", `request already pending: ${requestId}`);
    }
    const requestTimeoutMs = extensionForwardTimeoutMs(request, this.requestTimeoutMs);
    const payload = isPlainObject(request.payload) ? request.payload : {};
    debugLog("broker.to_extension", {
      id: requestId,
      type: request?.type || "",
      timeoutMs: requestTimeoutMs,
      extensionKey: extension.key || "",
      ownerId,
      extensionId: extension.id || "",
      projectId: stringValue(payload.projectId),
      tabId: stringValue(payload.tabId),
      laneId: stringValue(payload.laneId)
    });

    const responsePromise = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pendingExtensionRequests.delete(pendingKey);
        debugLog("broker.extension_timeout", {
          id: requestId,
          type: request?.type || "",
          ownerId,
          extensionKey: extension.key || "",
          extensionId: extension.id || "",
          timeoutMs: requestTimeoutMs
        });
        reject(brokerError("EXTENSION_BRIDGE_TIMEOUT", `Auto Flow extension bridge timed out after ${requestTimeoutMs}ms.`, {
          timeoutMs: requestTimeoutMs,
          ownerId,
          requestId,
          method: stringValue(request?.type)
        }));
      }, requestTimeoutMs);
      this.pendingExtensionRequests.set(pendingKey, {
        requestId,
        ownerId,
        extensionId: stringValue(extension.id),
        extensionVersion: stringValue(extension.metadata?.extensionVersion),
        projectId: stringValue(payload.projectId),
        tabId: stringValue(payload.tabId),
        laneId: stringValue(payload.laneId),
        method: stringValue(request?.type),
        createdAt: this.now(),
        createdAtMs: Date.now(),
        resolve,
        reject,
        timeout,
        timer: timeout
      });
    });

    try {
      extension.lastSeenAt = this.now();
      await extension.send(request);
    } catch (error) {
      const pending = this.pendingExtensionRequests.get(pendingKey);
      if (pending) {
        clearTimeout(pending.timeout || pending.timer);
        this.pendingExtensionRequests.delete(pendingKey);
      }
      debugLog("broker.extension_send_failed", {
        id: requestId,
        type: request?.type || "",
        ownerId,
        error: error?.message || String(error || "extension bridge send failed")
      });
      throw brokerError("EXTENSION_BRIDGE_SEND_FAILED", error?.message || String(error || "extension bridge send failed"));
    }

    return responsePromise;
  }

  async bridgeTargetsPayload(payload = {}) {
    const connectedExtensions = await this.connectedExtensionTargets(payload);
    const laneId = stringValue(payload.laneId || payload.requestedTarget?.laneId);
    const selectedExtension = laneId ? this.selectedExtensionSummary(laneId, connectedExtensions) : null;
    const requestedTarget = normalizeRequestedTarget(payload.requestedTarget || payload);
    return {
      connectedExtensions,
      selectedExtension,
      requestedTarget,
      lanes: this.laneSummaries(connectedExtensions),
      count: connectedExtensions.length
    };
  }

  async useBridgeTarget(payload = {}) {
    const requestedTarget = normalizeRequestedTarget(payload);
    const laneId = requestedTarget.laneId;
    if (!requestedTarget.projectId || !requestedTarget.tabId || !laneId) {
      throw brokerError("INVALID_BRIDGE_TARGET", "bridge target selection requires projectId, tabId, and laneId.", {
        requestedTarget
      });
    }
    const connectedExtensions = await this.connectedExtensionTargets(payload);
    const matches = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
    if (!matches.length) {
      throw brokerError("BRIDGE_TARGET_NOT_CONNECTED", "No connected Auto Flow extension matches the requested bridge target.", {
        requestedTarget,
        connectedExtensions
      });
    }
    if (matches.length > 1) {
      throw brokerError("BRIDGE_TARGET_AMBIGUOUS", "Multiple connected Auto Flow extensions match the requested bridge target.", {
        requestedTarget,
        matches
      });
    }
    const selectedExtension = matches[0];
    const previousSelection = this.laneSelections.get(laneId) || null;
    const clearedIndicator = await this.clearPreviousLaneIndicator(laneId, previousSelection, selectedExtension, connectedExtensions);
    const selection = this.persistLaneSelection(laneId, selectedExtension, {
      reason: "bridge.target.use"
    });
    const persistence = await this.persistPairingStore({ action: "bridge.target.use", laneId });
    const indicator = await this.setLaneIndicator(laneId, selectedExtension).catch((error) => ({
      ok: false,
      error: normalizeBridgeRoutingError(error)
    }));
    return {
      ok: true,
      selectedExtension,
      selectedTarget: selectedExtension,
      selection,
      requestedTarget,
      laneId,
      connectedExtensions,
      persistence,
      clearedIndicator,
      indicator
    };
  }

  async useNamedLane(payload = {}) {
    const laneId = payloadLaneId(payload);
    if (!laneId) {
      throw brokerError("INVALID_LANE_NAME", "named lane use requires a lane name.", { payload });
    }
    const connectedExtensions = await this.connectedExtensionTargets({ ...payload, laneId });
    const existing = this.laneSelections.get(laneId) || null;
    const requestedTarget = normalizeRequestedTarget({ ...payload, laneId });
    const selectedTarget = selectNamedLaneTarget(laneId, existing, requestedTarget, connectedExtensions);
    const clearedIndicator = await this.clearPreviousLaneIndicator(laneId, existing, selectedTarget, connectedExtensions);
    const selection = this.persistLaneSelection(laneId, selectedTarget, {
      reason: existing ? "lane.use" : "lane.auto_create"
    });
    const persistence = await this.persistPairingStore({ action: "lane.use", laneId });
    const indicator = await this.setLaneIndicator(laneId, selectedTarget).catch((error) => ({
      ok: false,
      error: normalizeBridgeRoutingError(error)
    }));
    return {
      ok: true,
      laneId,
      name: laneId,
      selectedExtension: selectedTarget,
      selectedTarget,
      selection,
      requestedTarget,
      connectedExtensions,
      persistence,
      clearedIndicator,
      indicator,
      message: `Named lane ${laneId} is bound to project ${selection.projectId} tab ${selection.tabId}.`
    };
  }

  async namedLaneRegistryPayload(payload = {}) {
    const connectedExtensions = await this.connectedExtensionTargets(payload).catch(() => []);
    return {
      ok: true,
      lanes: this.laneSummaries(connectedExtensions),
      connectedExtensions,
      count: this.laneSelections.size
    };
  }

  async unbindNamedLane(payload = {}) {
    const laneId = payloadLaneId(payload);
    if (!laneId) {
      throw brokerError("INVALID_LANE_NAME", "named lane unbind requires a lane name.", { payload });
    }
    const previous = this.laneSelections.get(laneId) || null;
    const connectedExtensions = previous ? await this.connectedExtensionTargets({ laneId }).catch(() => []) : [];
    const clearedIndicator = await this.clearPreviousLaneIndicator(laneId, previous, null, connectedExtensions);
    const removed = this.laneSelections.delete(laneId);
    const persistence = await this.persistPairingStore({ action: "lane.unbind", laneId });
    return {
      ok: true,
      laneId,
      name: laneId,
      removed,
      persistence,
      clearedIndicator,
      previous: previous ? normalizeLaneSelection(previous) : null
    };
  }

  persistLaneSelection(laneId, selectedTarget = {}, options = {}) {
    const now = this.now();
    const previous = this.laneSelections.get(laneId) || {};
    const selection = normalizeLaneSelection({
      ...previous,
      laneId,
      extensionKey: selectedTarget.extensionKey,
      extensionId: selectedTarget.extensionId,
      extensionVersion: selectedTarget.extensionVersion,
      projectId: selectedTarget.projectId,
      tabId: String(selectedTarget.tabId || ""),
      pageUrl: selectedTarget.pageUrl,
      pageTitle: selectedTarget.pageTitle,
      profileHint: selectedTarget.profileHint,
      cdpPortHint: selectedTarget.cdpPortHint,
      selectedAt: previous.selectedAt || now,
      lastUsedAt: now,
      lastBindReason: options.reason || previous.lastBindReason || ""
    });
    this.laneSelections.set(laneId, selection);
    return selection;
  }

  laneSummaries(connectedExtensions = []) {
    return [...this.laneSelections.values()]
      .map((selection) => laneSummary(selection, connectedExtensions))
      .sort((a, b) => String(b.lastUsedAt || b.selectedAt || "").localeCompare(String(a.lastUsedAt || a.selectedAt || "")));
  }

  async clearPreviousLaneIndicator(laneId, previousSelection = null, selectedTarget = null, connectedExtensions = []) {
    if (!previousSelection) return null;
    if (selectedTarget && sameLaneTarget(previousSelection, selectedTarget)) return null;
    const previousTarget = connectedExtensions.find((target) => targetMatchesRequestedTarget(target, previousSelection))
      || previousSelection;
    if (!previousTarget?.tabId) return { ok: false, skipped: true, reason: "previous_lane_tab_missing" };
    return this.setLaneIndicator(laneId, previousTarget, { connected: false }).catch((error) => ({
      ok: false,
      error: normalizeBridgeRoutingError(error)
    }));
  }

  async setLaneIndicator(laneId, target = {}, options = {}) {
    const extension = this.extensions.get(target.extensionKey);
    if (!extension) {
      throw brokerError("LANE_INDICATOR_TARGET_NOT_CONNECTED", `Named lane ${laneId} indicator target is not connected.`, {
        laneId,
        target
      });
    }
    const request = internalBridgeRequest("lane.indicator.set", {
      laneId,
      projectId: stringValue(target.projectId),
      tabId: String(target.tabId || ""),
      connected: options.connected !== false
    });
    const response = await this.sendToExtension(request, extension);
    if (response?.ok === false || response?.error) {
      throw brokerError(
        response?.error?.code || "LANE_INDICATOR_FAILED",
        response?.error?.message || `Named lane ${laneId} tab indicator failed.`,
        response?.error?.details
      );
    }
    return response?.payload || response;
  }

  async extensionForRequest(request = {}) {
    const payload = isPlainObject(request.payload) ? request.payload : {};
    const laneId = stringValue(payload.laneId);
    if (laneId && this.laneSelections.has(laneId)) {
      return this.extensionForLane(laneId, payload);
    }
    if (payload.projectId && payload.tabId) {
      const requestedTarget = normalizeRequestedTarget(payload);
      const connectedExtensions = await this.connectedExtensionTargets(payload);
      const matches = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
      if (matches.length === 1) {
        return this.extensions.get(matches[0].extensionKey) || null;
      }
      if (!matches.length) {
        throw brokerError("BRIDGE_TARGET_NOT_CONNECTED", "No connected Auto Flow extension matches the requested bridge target.", {
          requestedTarget,
          connectedExtensions
        });
      }
      if (matches.length > 1) {
        throw brokerError("BRIDGE_TARGET_AMBIGUOUS", "Multiple connected Auto Flow extensions match the requested bridge target.", {
          requestedTarget,
          matches
        });
      }
    }
    if (laneId) {
      throw brokerError("BRIDGE_TARGET_NOT_SELECTED", `No Auto Flow bridge target is selected for lane ${laneId}.`, {
        laneId
      });
    }
    return this.extension;
  }

  async extensionForLane(laneId, payload = {}) {
    const selection = this.laneSelections.get(laneId);
    if (!selection) {
      throw brokerError("BRIDGE_TARGET_NOT_SELECTED", `No Auto Flow bridge target is selected for lane ${laneId}.`, {
        laneId
      });
    }
    const requestedTransport = stringValue(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
    const chromeSessionApi = (requestedTransport === "api" || requestedTransport === "agent_api")
      && payload.chromeSessionAuth === true;
    if (chromeSessionApi) {
      const requestedProjectId = stringValue(payload.projectId);
      if (!requestedProjectId || requestedProjectId !== stringValue(selection.projectId)) {
        throw brokerError("AGENT_TARGET_MISMATCH", `Chrome-session API request does not match lane ${laneId}'s approved project.`, {
          laneId,
          requestedProjectId,
          selectedProjectId: stringValue(selection.projectId)
        });
      }
      const selectedExtension = selection.extensionKey ? this.extensions.get(selection.extensionKey) : null;
      if (!selectedExtension) {
        throw brokerError("LANE_EXTENSION_DISCONNECTED", `The Auto Flow extension approved for lane ${laneId} is not connected.`, {
          laneId,
          extensionKey: selection.extensionKey || ""
        });
      }
      return selectedExtension;
    }
    const selectionTarget = normalizeRequestedTarget(selection);
    const payloadTarget = normalizeRequestedTarget({
      ...payload,
      laneId
    });
    const hasFullPayloadTarget = Boolean(payloadTarget.projectId && payloadTarget.tabId);
    const requestedTarget = hasFullPayloadTarget
      ? payloadTarget
      : normalizeRequestedTarget({
        ...selection,
        laneId
      });
    const connectedExtensions = await this.connectedExtensionTargets(requestedTarget);
    const keyMatches = selection.extensionKey
      ? connectedExtensions.filter((target) => target.extensionKey === selection.extensionKey)
      : [];
    const validKeyMatches = keyMatches.filter((target) => targetMatchesRequestedTarget(target, selectionTarget)
      && targetMatchesRequestedTarget(target, requestedTarget));
    if (validKeyMatches.length === 1) {
      this.persistLaneSelection(laneId, validKeyMatches[0], { reason: "lane.route_exact" });
      return this.extensions.get(validKeyMatches[0].extensionKey) || null;
    }
    if (validKeyMatches.length > 1) {
      throw brokerError("BRIDGE_TARGET_AMBIGUOUS", `Multiple connected Auto Flow bridge targets match lane ${laneId}.`, {
        laneId,
        requestedTarget,
        matches: validKeyMatches
      });
    }
    const matches = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
    if (matches.length > 1) {
      throw brokerError("BRIDGE_TARGET_AMBIGUOUS", `Multiple connected Auto Flow bridge targets match lane ${laneId}.`, {
        laneId,
        requestedTarget,
        matches
      });
    }
    if (matches.length === 1) {
      this.persistLaneSelection(laneId, matches[0], { reason: hasFullPayloadTarget ? "lane.route_override" : "lane.route_rebind" });
      return this.extensions.get(matches[0].extensionKey) || null;
    }
    if (!hasFullPayloadTarget && selection.projectId) {
      const projectMatches = connectedExtensions.filter((target) => stringValue(target.projectId) === stringValue(selection.projectId));
      if (projectMatches.length === 1) {
        const rebound = this.persistLaneSelection(laneId, projectMatches[0], { reason: "lane.route_rebind_by_project" });
        return this.extensions.get(rebound.extensionKey) || null;
      }
      if (projectMatches.length > 1) {
        throw brokerError(
          "LANE_TARGET_AMBIGUOUS",
          `Named lane ${laneId} is bound to project ${selection.projectId}, but multiple Flow tabs for that project are open. Re-bind with: autoflow lane use ${laneId} --project-id ${selection.projectId} --tab-id <tabId>.`,
          { laneId, projectId: selection.projectId, expected: selection, matches: projectMatches }
        );
      }
    }
    if (!hasFullPayloadTarget && keyMatches.length) {
      const selected = keyMatches[0];
      throw brokerError("AGENT_TARGET_MISMATCH", `Selected Auto Flow bridge target for lane ${laneId} changed project or tab.`, {
        laneId,
        selected,
        expected: selection,
        requestedTarget
      });
    }
    throw brokerError("LANE_TARGET_GONE", `Named lane ${laneId} is bound to project ${selection.projectId || "(unknown)"} tab ${selection.tabId || "(unknown)"}, but that Flow tab is gone. Re-bind with: autoflow lane use ${laneId} --project-id ${selection.projectId || "<projectId>"} --tab-id <tabId>.`, {
      laneId,
      expected: selection,
      requestedTarget,
      connectedExtensions
    });
  }

  async connectedExtensionTargets(payload = {}) {
    const requestedTarget = normalizeRequestedTarget(payload.requestedTarget || payload);
    const targetGroups = await Promise.all([...this.extensions.values()].map(async (extension) => {
      const summaries = await this.extensionTargetSummaries(extension, requestedTarget).catch((error) => ([{
        extensionKey: extension.key,
        extensionId: extension.id,
        extensionVersion: stringValue(extension.metadata?.extensionVersion),
        transport: extension.transport,
        connectedAt: extension.connectedAt,
        lastSeenAt: this.now(),
        profileHint: stringValue(extension.metadata?.profileHint),
        cdpPortHint: normalizeNullableNumber(extension.metadata?.cdpPortHint),
        error: {
          code: error?.code || "BRIDGE_TARGET_STATUS_FAILED",
          message: error?.message || String(error || "bridge target status failed")
        }
      }]));
      return summaries.map((summary) => ({
          ...summary,
          requestedMatch: targetMatchesRequestedTarget(summary, requestedTarget),
          stale: isStaleExtensionTarget(summary, requestedTarget),
          selected: isSelectedTarget(summary, this.laneSelections)
        }));
    }));
    return collapseTransportHandoverTargets(targetGroups.flat());
  }

  async extensionTargetSummaries(extension, requestedTarget = {}) {
    const statusRequest = internalBridgeRequest("status.get", {
      project: "current",
      ...(requestedTarget.laneId ? { laneId: requestedTarget.laneId } : {})
    });
    const tabsRequest = internalBridgeRequest("flow.tabs.list", {
      project: "current"
    });
    const [statusResponse, tabsResponse] = await Promise.all([
      this.sendToExtension(statusRequest, extension),
      this.sendToExtension(tabsRequest, extension).catch(() => null)
    ]);
    const statusPayload = statusResponse?.payload || {};
    const tabsPayload = tabsResponse?.payload || {};
    const tabs = Array.isArray(tabsPayload.tabs) ? tabsPayload.tabs : [];
    const statusProjectId = stringValue(statusPayload.project?.id || statusPayload.projectId || statusPayload.runtime?.projectId);
    const statusTabId = normalizeNullableNumber(statusPayload.runtime?.activeTabId ?? statusPayload.activeTabId ?? statusPayload.project?.activeTabId);
    const extensionVersion = stringValue(
      statusPayload.extension?.version
      || statusPayload.versions?.extensionVersion
      || extension.metadata?.extensionVersion
    );
    const base = {
      extensionKey: extension.key,
      extensionId: stringValue(statusPayload.extension?.id || extension.id),
      extensionVersion,
      packageVersion: stringValue(statusPayload.versions?.packageVersion || statusPayload.bridge?.packageVersion),
      nativeHostVersion: stringValue(statusPayload.versions?.nativeHostVersion || statusPayload.bridge?.nativeHostVersion),
      bridgeProtocolVersion: normalizeNullableNumber(statusPayload.versions?.bridgeProtocolVersion || statusPayload.bridge?.bridgeProtocolVersion),
      transport: extension.transport,
      connectedAt: extension.connectedAt,
      lastSeenAt: this.now(),
      profileHint: stringValue(extension.metadata?.profileHint),
      cdpPortHint: normalizeNullableNumber(extension.metadata?.cdpPortHint)
    };
    extension.lastSeenAt = this.now();
    const tabSummaries = tabs.map((tab) => {
      const projectId = stringValue(tab?.projectId || tab?.target?.projectId || "");
      const tabId = normalizeNullableNumber(tab?.tabId || tab?.target?.tabId);
      if (!projectId || !tabId) return null;
      return {
        ...base,
        projectId,
        tabId,
        pageUrl: stringValue(tab?.url || ""),
        pageTitle: stringValue(tab?.title || ""),
        active: tab?.active === true,
        isRuntimeTarget: Boolean(
          (statusTabId && tabId === statusTabId)
          || (statusProjectId && projectId === statusProjectId)
        )
      };
    }).filter(Boolean);
    if (tabSummaries.length) return tabSummaries;
    const projectId = statusProjectId;
    const tabId = statusTabId;
    return [{
      ...base,
      projectId,
      tabId,
      pageUrl: "",
      pageTitle: stringValue(statusPayload.project?.name || ""),
      active: Boolean(tabId),
      isRuntimeTarget: Boolean(tabId || projectId)
    }];
  }

  async extensionTargetSummary(extension, requestedTarget = {}) {
    const summaries = await this.extensionTargetSummaries(extension, requestedTarget);
    return summaries[0] || {};
  }

  selectedExtensionSummary(laneId, connectedExtensions = []) {
    const selection = this.laneSelections.get(laneId);
    if (!selection) return null;
    return connectedExtensions.find((target) => target.extensionKey === selection.extensionKey)
      || connectedExtensions.find((target) => targetMatchesRequestedTarget(target, selection))
      || { ...selection };
  }

  handleSocket(socket) {
    let pending = Buffer.alloc(0);
    let queue = Promise.resolve();
    let extensionRegistration = null;

    this.clientSockets.add(socket);
    socket.once("close", () => {
      this.clientSockets.delete(socket);
      if (extensionRegistration) {
        extensionRegistration.close();
        extensionRegistration = null;
      }
    });

    socket.on("data", (chunk) => {
      pending = Buffer.concat([pending, chunk]);
      queue = queue.then(async () => {
        let decoded;
        try {
          decoded = decodeNativeMessageFrames(pending, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES });
        } catch (error) {
          pending = Buffer.alloc(0);
          socket.write(encodeNativeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
            code: "NATIVE_BROKER_MESSAGE_INVALID",
            message: error?.message || String(error || "native broker message invalid")
          })));
          return;
        }

        pending = decoded.remaining;
        for (const message of decoded.messages) {
          if (isBrokerExtensionRegisterMessage(message)) {
            if (extensionRegistration) extensionRegistration.close();
            const payload = isPlainObject(message.payload) ? message.payload : {};
            extensionRegistration = this.registerExtension({
              extensionId: payload.extensionId,
              metadata: payload.metadata,
              send: async (request) => {
                socket.write(encodeNativeMessage(request, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES }));
              }
            });
            socket.write(encodeNativeMessage({
              id: stringValue(message.id),
              type: "broker.extension.register",
              ok: true,
              payload: {
                extensionKey: extensionRegistration.extensionKey,
                extensionId: extensionRegistration.extensionId,
                connectedAt: extensionRegistration.connectedAt
              }
            }, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES }));
            continue;
          }
          if (extensionRegistration && typeof message.ok === "boolean") {
            const response = await this.handleExtensionMessage(extensionRegistration, message);
            if (response) {
              socket.write(encodeNativeMessage(response, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES }));
            }
            continue;
          }
          const response = await this.handleClientRequest(message);
          socket.write(encodeNativeMessage(response, { maxBytes: MAX_NATIVE_SOCKET_MESSAGE_BYTES }));
        }
      }).catch((error) => {
        socket.write(encodeNativeMessage(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
          code: error?.code || "NATIVE_BROKER_HANDLER_FAILED",
          message: error?.message || String(error || "native broker handler failed")
        })));
      });
    });
  }

  async startLoopbackServer() {
    if (this.httpServer) return;
    const autoPort = this.wsPortSetting === "auto" || this.wsPortSetting === true || this.wsPortSetting === "";
    const requestedPort = autoPort ? DEFAULT_WS_PORT : Number(this.wsPortSetting);
    if (!Number.isInteger(requestedPort) || requestedPort < 0 || requestedPort > 65535) {
      throw brokerError("WS_BROKER_PORT_INVALID", `Invalid Auto Flow WS broker port: ${this.wsPortSetting}`);
    }
    if (!autoPort && requestedPort !== 0 && !DEFAULT_WS_PORT_RANGE.includes(requestedPort) && !this.allowUndiscoverableWsPort) {
      throw brokerError(
        "WS_BROKER_PORT_UNDISCOVERABLE",
        `Auto Flow WS broker port ${requestedPort} is outside the extension discovery range ${DEFAULT_WS_PORT_RANGE[0]}-${DEFAULT_WS_PORT_RANGE[DEFAULT_WS_PORT_RANGE.length - 1]}. Use --port auto or a port in that range.`
      );
    }
    this.httpServer = http.createServer((request, response) => this.handleHttpRequest(request, response));
    this.httpServer.on("upgrade", (request, socket) => this.handleWsUpgrade(request, socket));
    if (autoPort) {
      await listenOnFirstAvailablePort(this.httpServer, this.wsHost, this.wsPortRange);
    } else {
      await listenHttpServer(this.httpServer, this.wsHost, requestedPort);
    }
    const address = this.httpServer.address();
    this.wsPort = Number(address?.port || requestedPort);
    this.httpUrl = `http://${this.wsHost}:${this.wsPort}`;
    this.wsUrl = `ws://${this.wsHost}:${this.wsPort}${this.wsPath}`;
    this.browserWsUrl = `ws://${this.wsHost}:${this.wsPort}${this.browserWsPath}`;
  }

  async closeLoopbackServer() {
    for (const connection of this.wsConnections) {
      try {
        connection.destroy();
      } catch {}
    }
    this.wsConnections.clear();
    this.browserClientCount = 0;
    this.browserMediaGrants.clear();
    this.wsUrl = "";
    this.browserWsUrl = "";
    this.httpUrl = "";
    this.wsPort = null;
    if (!this.httpServer) return;
    const server = this.httpServer;
    this.httpServer = null;
    await new Promise((resolve) => server.close(() => resolve()));
  }

  handleHttpRequest(request, response) {
    const url = new URL(request.url || "/", "http://127.0.0.1");
    if (!isLoopbackRemoteAddress(request.socket?.remoteAddress)) {
      writeJsonResponse(response, 403, {
        ok: false,
        error: {
          code: "WS_BROKER_FORBIDDEN",
          message: "Auto Flow broker HTTP endpoints are loopback-only."
        }
      });
      return;
    }
    const requestOrigin = stringValue(request.headers?.origin);
    const allowedBrowserOrigin = requestOrigin
      && isAllowedBrowserOrigin(requestOrigin, this.allowedBrowserOrigins, {
        allowLoopback: this.allowBrowserLoopbackOrigins
      })
      ? requestOrigin
      : "";
    if (url.pathname === DEFAULT_HELLO_PATH && requestOrigin && !allowedBrowserOrigin) {
      writeJsonResponse(response, 403, {
        ok: false,
        error: {
          code: "BROWSER_ORIGIN_NOT_ALLOWED",
          message: "Browser origin is not allowed to discover the Auto Flow broker."
        }
      });
      return;
    }
    const corsHeaders = browserCorsHeaders(allowedBrowserOrigin);
    if (url.pathname.startsWith(BROWSER_MEDIA_PATH_PREFIX)) {
      this.handleBrowserMediaRequest(request, response, url, allowedBrowserOrigin, corsHeaders);
      return;
    }
    if (request.method === "OPTIONS" && url.pathname === DEFAULT_HELLO_PATH) {
      writeJsonResponse(response, 204, {}, corsHeaders);
      return;
    }
    if (request.method === "GET" && url.pathname === DEFAULT_HELLO_PATH) {
      writeJsonResponse(response, 200, {
        ok: true,
        protocol: "auto-flow.agent.bridge",
        protocolVersion: AGENT_BRIDGE_VERSION,
        brokerInstanceId: this.brokerInstanceId,
        socketPath: this.socketPath,
        wsUrl: this.wsUrl,
        browserWsUrl: this.browserWsUrl,
        browserWsPath: this.browserWsPath,
        allowedBrowserOriginCount: this.allowedBrowserOrigins.length,
        browserOriginsConfigured: this.allowedBrowserOrigins.length > 0 || this.allowBrowserLoopbackOrigins,
      browserLoopbackAllowed: this.allowBrowserLoopbackOrigins,
        httpUrl: this.httpUrl,
        status: this.statusPayload()
      }, corsHeaders);
      return;
    }
    writeJsonResponse(response, 404, {
      ok: false,
      error: {
        code: "WS_BROKER_NOT_FOUND",
        message: "Auto Flow broker endpoint not found."
      }
    });
  }

  pruneBrowserMediaGrants(now = Date.now()) {
    for (const [token, grant] of this.browserMediaGrants.entries()) {
      if (now >= Number(grant?.expiresAt || 0)) this.browserMediaGrants.delete(token);
    }
  }

  registerBrowserMediaGrants(response = {}, session = {}) {
    if (!response?.ok || !isPlainObject(response.payload)) return response;
    const downloads = Array.isArray(response.payload.downloads) ? response.payload.downloads : [];
    if (!downloads.length || !this.httpUrl) return response;
    this.pruneBrowserMediaGrants();
    const origin = stringValue(session.origin)
      || (this.allowMissingBrowserOrigin && this.allowedBrowserOrigins.length === 1 ? this.allowedBrowserOrigins[0] : "");
    const decorated = downloads.map((download) => {
      const filePath = path.resolve(stringValue(download?.filename || download?.path));
      if (download?.ok !== true || !filePath || !fs.existsSync(filePath)) return download;
      let fileStat;
      try { fileStat = fs.statSync(filePath); } catch { return download; }
      if (!fileStat.isFile() || fileStat.size <= 0) return download;
      const token = crypto.randomBytes(32).toString("base64url");
      this.browserMediaGrants.set(token, {
        token,
        origin,
        filePath,
        mediaId: stringValue(download.mediaId),
        fileName: path.basename(stringValue(download.plannedFilename) || filePath),
        contentType: browserMediaContentType(stringValue(download.plannedFilename) || filePath),
        size: fileStat.size,
        expiresAt: Date.now() + this.browserMediaGrantTtlMs
      });
      return {
        ...download,
        browserDownloadUrl: `${this.httpUrl}${BROWSER_MEDIA_PATH_PREFIX}${token}`,
        browserDownloadExpiresAt: new Date(Date.now() + this.browserMediaGrantTtlMs).toISOString()
      };
    });
    return { ...response, payload: { ...response.payload, downloads: decorated } };
  }

  handleBrowserMediaRequest(request, response, url, allowedBrowserOrigin, corsHeaders) {
    if (!allowedBrowserOrigin) {
      writeJsonResponse(response, 403, { ok: false, error: { code: "BROWSER_ORIGIN_NOT_ALLOWED", message: "Browser media handoff requires an allowlisted browser origin." } });
      return;
    }
    if (request.method === "OPTIONS") {
      writeJsonResponse(response, 204, {}, corsHeaders);
      return;
    }
    if (request.method !== "GET" && request.method !== "HEAD") {
      writeJsonResponse(response, 405, { ok: false, error: { code: "BROWSER_MEDIA_METHOD_NOT_ALLOWED", message: "Browser media handoff supports GET and HEAD only." } }, corsHeaders);
      return;
    }
    this.pruneBrowserMediaGrants();
    const token = stringValue(url.pathname.slice(BROWSER_MEDIA_PATH_PREFIX.length));
    const grant = this.browserMediaGrants.get(token);
    if (!grant || grant.origin !== allowedBrowserOrigin) {
      writeJsonResponse(response, 404, { ok: false, error: { code: "BROWSER_MEDIA_GRANT_INVALID", message: "Browser media handoff is invalid or expired." } }, corsHeaders);
      return;
    }
    let fileStat;
    try { fileStat = fs.statSync(grant.filePath); } catch {
      this.browserMediaGrants.delete(token);
      writeJsonResponse(response, 410, { ok: false, error: { code: "BROWSER_MEDIA_FILE_MISSING", message: "Downloaded media is no longer available." } }, corsHeaders);
      return;
    }
    response.writeHead(200, {
      ...corsHeaders,
      "content-type": grant.contentType,
      "content-length": String(fileStat.size),
      "cache-control": "no-store",
      "content-disposition": `inline; filename*=UTF-8''${encodeURIComponent(grant.fileName)}`,
      "x-autoflow-media-id": grant.mediaId
    });
    if (request.method === "HEAD") {
      response.end();
      return;
    }
    fs.createReadStream(grant.filePath).pipe(response);
  }

  handleWsUpgrade(request, socket) {
    const url = new URL(request.url || "/", "http://127.0.0.1");
    if (!isLoopbackRemoteAddress(socket.remoteAddress)) {
      socket.destroy();
      return;
    }
    const isExtensionPath = url.pathname === this.wsPath;
    const isBrowserPath = url.pathname === this.browserWsPath;
    if (!isExtensionPath && !isBrowserPath) {
      socket.destroy();
      return;
    }
    if (isExtensionPath && !isAllowedWsOrigin(request.headers.origin, this.allowNoOriginWs)) {
      rejectWsUpgrade(socket, 403, "Forbidden");
      return;
    }
    if (isBrowserPath) {
      if (!this.allowedBrowserOrigins.length && !this.allowMissingBrowserOrigin
        && !this.allowBrowserLoopbackOrigins) {
        rejectWsUpgrade(socket, 403, "Forbidden");
        return;
      }
      if (!isAllowedBrowserOrigin(request.headers.origin, this.allowedBrowserOrigins, {
        allowMissingOrigin: this.allowMissingBrowserOrigin,
        allowLoopback: this.allowBrowserLoopbackOrigins
      })) {
        rejectWsUpgrade(socket, 403, "Forbidden");
        return;
      }
    }
    const key = stringValue(request.headers["sec-websocket-key"]);
    if (!key) {
      socket.destroy();
      return;
    }
    const accept = crypto.createHash("sha1").update(`${key}${WS_GUID}`).digest("base64");
    socket.write([
      "HTTP/1.1 101 Switching Protocols",
      "Upgrade: websocket",
      "Connection: Upgrade",
      `Sec-WebSocket-Accept: ${accept}`,
      "\r\n"
    ].join("\r\n"));
    if (isBrowserPath) {
      this.handleWsBrowserClientSocket(socket, { origin: request.headers.origin });
      return;
    }
    this.handleWsExtensionSocket(socket, { origin: request.headers.origin });
  }

  handleWsBrowserClientSocket(socket, options = {}) {
    this.wsConnections.add(socket);
    this.browserClientCount += 1;
    let pending = Buffer.alloc(0);
    let fragmentedTextFrame = null;
    let queue = Promise.resolve();
    let helloAccepted = false;
    let grantedCapabilities = [...BROWSER_BRIDGE_CAPABILITIES];
    const origin = stringValue(options.origin);
    const sendJson = (message) => wsSendText(socket, JSON.stringify(message));

    let released = false;
    const releaseBrowserClient = () => {
      if (released) return;
      released = true;
      this.wsConnections.delete(socket);
      this.browserClientCount = Math.max(0, this.browserClientCount - 1);
    };
    socket.once("close", releaseBrowserClient);
    socket.once("error", releaseBrowserClient);
    socket.on("data", (chunk) => {
      if (pending.length + chunk.length > MAX_WS_FRAME_BUFFER_BYTES) {
        pending = Buffer.alloc(0);
        fragmentedTextFrame = null;
        sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
          code: "WS_FRAME_TOO_LARGE",
          message: "Auto Flow browser WS frame buffer exceeded the maximum bridge message size."
        }));
        socket.destroy();
        return;
      }
      pending = Buffer.concat([pending, chunk]);
      queue = queue.then(async () => {
        let decoded;
        try {
          decoded = decodeWsTextFrames(pending, fragmentedTextFrame);
        } catch (error) {
          pending = Buffer.alloc(0);
          fragmentedTextFrame = null;
          sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
            code: "WS_BROKER_MESSAGE_INVALID",
            message: error?.message || String(error || "browser ws broker message invalid")
          }));
          return;
        }
        pending = decoded.remaining;
        fragmentedTextFrame = decoded.fragmentedTextFrame || null;
        if (decoded.closed) {
          socket.end(wsCloseFrame());
          return;
        }
        for (const text of decoded.messages) {
          let message;
          try {
            message = JSON.parse(text);
          } catch (error) {
            sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
              code: "WS_BROKER_JSON_INVALID",
              message: error?.message || String(error || "browser ws broker json invalid")
            }));
            continue;
          }
          if (isBrokerExtensionRegisterMessage(message)) {
            sendJson(createAgentBridgeErrorResponse(message, {
              code: "BROWSER_EXTENSION_REGISTER_FORBIDDEN",
              message: "Browser clients cannot register as the Auto Flow extension. Use /v1/extension from the extension service worker."
            }));
            continue;
          }
          const response = await this.handleBrowserClientMessage(message, {
            origin,
            helloAccepted,
            grantedCapabilities,
            markHello(nextCapabilities) {
              helloAccepted = true;
              grantedCapabilities = nextCapabilities;
            }
          });
          if (response) sendJson(response);
        }
      }).catch((error) => {
        sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
          code: error?.code || "WS_BROKER_HANDLER_FAILED",
          message: error?.message || String(error || "browser ws broker handler failed")
        }));
      });
    });
  }

  async handleBrowserClientMessage(message = {}, session = {}) {
    const type = stringValue(message?.type);
    const requestId = stringValue(message?.id);

    if (type === BROWSER_CLIENT_HELLO_TYPE) {
      const payload = isPlainObject(message.payload) ? message.payload : {};
      const hello = buildBrowserClientHelloPayload({
        requestedCapabilities: payload.requestedCapabilities || payload.capabilities,
        protocolVersion: AGENT_BRIDGE_VERSION,
        brokerInstanceId: this.brokerInstanceId,
        browserWsPath: this.browserWsPath,
        browserWsUrl: this.browserWsUrl,
        httpUrl: this.httpUrl,
        origin: session.origin,
        clientId: stringValue(payload.clientId || message.session?.clientId)
      });
      if (!hello.capabilityResult.ok) {
        return createAgentBridgeErrorResponse(message, {
          code: hello.capabilityResult.code,
          message: hello.capabilityResult.message,
          details: { unsupported: hello.capabilityResult.unsupported }
        });
      }
      if (typeof session.markHello === "function") {
        session.markHello(hello.capabilities);
      }
      return {
        protocol: "auto-flow.agent.bridge",
        version: AGENT_BRIDGE_VERSION,
        id: requestId || `hello-${Date.now()}`,
        type: BROWSER_CLIENT_HELLO_TYPE,
        ok: true,
        payload: {
          ...hello,
          grantedCapabilities: hello.capabilities,
          allowedBrowserOriginCount: this.allowedBrowserOrigins.length,
          allowedRefImportOriginCount: this.allowedRefImportOrigins.length,
          pairedClientCount: this.state.pairedClients.size,
          extensionConnected: Boolean(this.extension)
        }
      };
    }

    if (!session.helloAccepted) {
      return createAgentBridgeErrorResponse(message, {
        code: "BROWSER_HELLO_REQUIRED",
        message: "Browser clients must complete broker.client.hello capability handshake before sending bridge commands."
      });
    }

    if (!isBrowserCapabilityAllowed(type, session.grantedCapabilities)) {
      return createAgentBridgeErrorResponse(message, {
        code: "BROWSER_CAPABILITY_UNSUPPORTED",
        message: `Browser client capability is not granted for this session: ${type || "(missing)"}`,
        details: {
          grantedCapabilities: session.grantedCapabilities,
          transport: BROWSER_TRANSPORT
        }
      });
    }

    const binaryHit = findForbiddenBinaryMedia(message);
    if (binaryHit) {
      return createAgentBridgeErrorResponse(message, {
        code: "BROWSER_BINARY_MEDIA_FORBIDDEN",
        message: "Browser bridge rejects binary media payloads. Pass mediaId/reference ids or local paths handled by the extension; never data URLs or base64 blobs.",
        details: binaryHit
      });
    }

    if (!BROWSER_PRE_PAIR_COMMAND_SET.has(type) && !this.isClientPaired(message)) {
      return createAgentBridgeErrorResponse(message, {
        code: "PAIRING_REQUIRED",
        message: "Pair this browser client with Auto Flow before sending bridge commands."
      });
    }

    if (type === "agent.refs.importUrl") {
      const importPayload = message.payload || {};
      if (!stringValue(importPayload.sourceUrl) || !stringValue(importPayload.fileName)) {
        return createAgentBridgeErrorResponse(message, {
          code: "INVALID_PAYLOAD",
          message: "agent.refs.importUrl requires sourceUrl and fileName metadata."
        });
      }
      try {
        const payload = await this.refImporter(importPayload, {
          allowedOrigins: this.allowedRefImportOrigins,
          includePatchWorkDefault: false,
          runtimeDir: this.refImportRuntimeDir
        });
        return createAgentBridgeSuccessResponse(message, payload);
      } catch (error) {
        return createAgentBridgeErrorResponse(message, {
          code: error?.code || "REF_IMPORT_FAILED",
          message: error?.message || "Auto Flow could not stage the browser reference URL.",
          details: error?.details
        });
      }
    }

    if (type === "downloads.execute" && !hasExactBrowserDownloadScope(message.payload || {})) {
      return createAgentBridgeErrorResponse(message, {
        code: "BROWSER_DOWNLOAD_SCOPE_REQUIRED",
        message: "Browser downloads.execute requires exact project/target scope plus explicit rowIds and mediaIds.",
        details: { required: ["projectId", "tabId or approved Chrome-session lane", "rowIds", "mediaIds"] }
      });
    }

    const response = await this.handleClientRequest(message);
    return type === "downloads.execute"
      ? this.registerBrowserMediaGrants(response, session)
      : response;
  }

  handleWsExtensionSocket(socket, options = {}) {
    this.wsConnections.add(socket);
    let pending = Buffer.alloc(0);
    let fragmentedTextFrame = null;
    let queue = Promise.resolve();
    let extensionRegistration = null;
    const sendJson = (message) => wsSendText(socket, JSON.stringify(message));

    socket.once("close", () => {
      this.wsConnections.delete(socket);
      if (extensionRegistration) {
        extensionRegistration.close();
        extensionRegistration = null;
      }
    });
    socket.once("error", () => {
      this.wsConnections.delete(socket);
    });
    socket.on("data", (chunk) => {
      if (pending.length + chunk.length > MAX_WS_FRAME_BUFFER_BYTES) {
        pending = Buffer.alloc(0);
        fragmentedTextFrame = null;
        sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
          code: "WS_FRAME_TOO_LARGE",
          message: "Auto Flow WS frame buffer exceeded the maximum bridge message size."
        }));
        socket.destroy();
        return;
      }
      pending = Buffer.concat([pending, chunk]);
      queue = queue.then(async () => {
        let decoded;
        try {
          decoded = decodeWsTextFrames(pending, fragmentedTextFrame);
        } catch (error) {
          pending = Buffer.alloc(0);
          fragmentedTextFrame = null;
          sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
            code: "WS_BROKER_MESSAGE_INVALID",
            message: error?.message || String(error || "ws broker message invalid")
          }));
          return;
        }
        pending = decoded.remaining;
        fragmentedTextFrame = decoded.fragmentedTextFrame || null;
        if (decoded.closed) {
          socket.end(wsCloseFrame());
          return;
        }
        for (const text of decoded.messages) {
          let message;
          try {
            message = JSON.parse(text);
          } catch (error) {
            sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
              code: "WS_BROKER_JSON_INVALID",
              message: error?.message || String(error || "ws broker json invalid")
            }));
            continue;
          }
          if (isBrokerExtensionRegisterMessage(message)) {
            if (extensionRegistration) extensionRegistration.close();
            const payload = isPlainObject(message.payload) ? message.payload : {};
            const claimedExtensionId = stringValue(payload.extensionId);
            const originValue = stringValue(options.origin);
            const originExtensionId = extensionIdFromWsOrigin(options.origin);
            if (originExtensionId && claimedExtensionId && originExtensionId !== claimedExtensionId) {
              sendJson(createAgentBridgeErrorResponse(message, {
                code: "WS_EXTENSION_ORIGIN_MISMATCH",
                message: "Auto Flow WS extension id does not match the WebSocket origin."
              }));
              continue;
            }
            if (this.allowedExtensionId) {
              let trustedExtensionId = originExtensionId;
              if (!trustedExtensionId && !originValue && this.allowNoOriginWs) {
                trustedExtensionId = claimedExtensionId;
              }
              if (trustedExtensionId !== this.allowedExtensionId) {
                sendJson(createAgentBridgeErrorResponse(message, {
                  code: "WS_EXTENSION_NOT_ALLOWED",
                  message: "Auto Flow WS extension id does not match the paired extension."
                }));
                continue;
              }
            }
            const presentedSecret = stringValue(payload.registrationSecret);
            const presentedProof = hashRegistrationSecret(presentedSecret);
            if (this.wsRegistrationSecret) {
              if (!constantTimeEquals(presentedSecret, this.wsRegistrationSecret)) {
                sendJson(createAgentBridgeErrorResponse(message, {
                  code: "WS_EXTENSION_REGISTRATION_PROOF_INVALID",
                  message: "Auto Flow WS extension registration secret is missing or does not match the broker."
                }));
                continue;
              }
            }
            // The chrome-extension:// Origin already proves the signed extension id.
            // Registration secrets distinguish profile instances; they must not
            // globally lock every other Chrome profile out of the broker.
            const extensionId = originExtensionId || claimedExtensionId;
            extensionRegistration = this.registerExtension({
              extensionId,
              registrationProof: presentedProof,
              transport: payload.transport || payload.metadata?.transport || "ws_broker",
              metadata: {
                ...(payload.metadata || {}),
                transport: payload.transport || payload.metadata?.transport || "ws_broker"
              },
              disconnect: () => socket.destroy(),
              send: async (request) => sendJson(request)
            });
            sendJson({
              id: stringValue(message.id),
              type: "broker.extension.register",
              ok: true,
              payload: {
                extensionKey: extensionRegistration.extensionKey,
                extensionId: extensionRegistration.extensionId,
                connectedAt: extensionRegistration.connectedAt,
                brokerInstanceId: this.brokerInstanceId,
                protocolVersion: AGENT_BRIDGE_VERSION,
                paired: this.state.pairedClients.size > 0
              }
            });
            continue;
          }
          if (message?.type === "broker.extension.ping") {
            sendJson(createAgentBridgeSuccessResponse(message, {
              pong: true,
              brokerInstanceId: this.brokerInstanceId,
              protocolVersion: AGENT_BRIDGE_VERSION,
              at: this.now()
            }));
            continue;
          }
          if (extensionRegistration && typeof message.ok === "boolean") {
            const response = await this.handleExtensionMessage(extensionRegistration, message);
            if (response) sendJson(response);
            continue;
          }
          sendJson(createAgentBridgeErrorResponse(message, {
            code: "WS_EXTENSION_NOT_REGISTERED",
            message: "Auto Flow extension must register before sending bridge frames."
          }));
        }
      }).catch((error) => {
        sendJson(createAgentBridgeErrorResponse({ id: "", type: "status.get" }, {
          code: error?.code || "WS_BROKER_HANDLER_FAILED",
          message: error?.message || String(error || "ws broker handler failed")
        }));
      });
    });
  }

  async writeRuntimeDiscovery() {
    if (!this.discoveryPath) return;
    const payload = {
      protocol: "auto-flow.agent.bridge",
      protocolVersion: AGENT_BRIDGE_VERSION,
      brokerInstanceId: this.brokerInstanceId,
      socketPath: this.socketPath,
      wsUrl: this.wsUrl,
      browserWsUrl: this.browserWsUrl,
      browserWsPath: this.browserWsPath,
      allowedBrowserOriginCount: this.allowedBrowserOrigins.length,
      httpUrl: this.httpUrl,
      pid: process.pid,
      startedAt: NATIVE_HOST_STARTED_AT,
      updatedAt: this.now()
    };
    await mkdir(path.dirname(this.discoveryPath), { recursive: true, mode: 0o700 });
    await writeFile(this.discoveryPath, `${JSON.stringify(payload, null, 2)}\n`, { mode: 0o600 });
    await chmod(this.discoveryPath, 0o600).catch(() => {});
  }
}

function listenHttpServer(server, host, port) {
  return new Promise((resolve, reject) => {
      const onError = (error) => {
        server.off("listening", onListening);
        reject(error);
      };
      const onListening = () => {
        server.off("error", onError);
        resolve();
      };
      server.once("error", onError);
      server.listen(port, host, onListening);
    });
}

async function listenOnFirstAvailablePort(server, host, ports) {
  let lastError = null;
  for (const port of ports) {
    try {
      await listenHttpServer(server, host, port);
      return port;
    } catch (error) {
      lastError = error;
      if (error?.code !== "EADDRINUSE") throw error;
    }
  }
  throw brokerError(
    "WS_BROKER_PORT_RANGE_UNAVAILABLE",
    `No Auto Flow WS broker port is available in ${ports[0]}-${ports[ports.length - 1]}.`,
    { cause: lastError?.message || String(lastError || "port range unavailable") }
  );
}

function nativeVersionInfo() {
  const packageInfo = nearestPackageInfo();
  const packageVersion = packageInfo.version;
  const brokerModulePath = fileURLToPath(import.meta.url);
  const hostScriptPath = path.resolve(process.argv[1] || brokerModulePath);
  return {
    packageVersion,
    nativeHostVersion: NATIVE_HOST_VERSION,
    bridgeProtocolVersion: AGENT_BRIDGE_VERSION,
    nativeRuntime: {
      pid: process.pid,
      startedAt: NATIVE_HOST_STARTED_AT,
      nodePath: process.execPath,
      hostScriptPath,
      brokerModulePath,
      packageRoot: packageInfo.packageRoot,
      packageVersion,
      nativeHostVersion: NATIVE_HOST_VERSION,
      bridgeProtocolVersion: AGENT_BRIDGE_VERSION
    }
  };
}

function internalBridgeRequest(type, payload = {}) {
  return createAgentBridgeRequest({
    id: `broker-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    payload,
    session: {
      source: "native_broker",
      clientId: "native-broker"
    }
  });
}

function normalizeRequestedTarget(value = {}) {
  const source = isPlainObject(value) ? value : {};
  return {
    projectId: stringValue(source.projectId),
    tabId: stringValue(source.tabId),
    laneId: stringValue(source.laneId),
    port: stringValue(source.port),
    profileHint: stringValue(source.profileHint),
    cdpPortHint: normalizeNullableNumber(source.cdpPortHint || source.port)
  };
}

function normalizeLaneSelection(value = {}) {
  const source = isPlainObject(value) ? value : {};
  return {
    laneId: stringValue(source.laneId),
    name: stringValue(source.name || source.laneId),
    extensionKey: stringValue(source.extensionKey),
    extensionId: stringValue(source.extensionId),
    extensionVersion: stringValue(source.extensionVersion),
    projectId: stringValue(source.projectId),
    tabId: stringValue(source.tabId),
    pageUrl: stringValue(source.pageUrl),
    pageTitle: stringValue(source.pageTitle),
    profileHint: stringValue(source.profileHint),
    cdpPortHint: normalizeNullableNumber(source.cdpPortHint || source.port),
    selectedAt: stringValue(source.selectedAt),
    lastUsedAt: stringValue(source.lastUsedAt || source.usedAt),
    lastBindReason: stringValue(source.lastBindReason || source.reason)
  };
}

function redactedLaneSelection(value = {}) {
  const selection = normalizeLaneSelection(value);
  return {
    laneId: selection.laneId,
    name: selection.name,
    projectId: selection.projectId,
    tabId: selection.tabId,
    profileHint: selection.profileHint,
    cdpPortHint: selection.cdpPortHint,
    selectedAt: selection.selectedAt,
    lastUsedAt: selection.lastUsedAt,
    lastBindReason: selection.lastBindReason,
    pageUrl: "",
    pageTitle: ""
  };
}

function payloadLaneId(payload = {}) {
  return stringValue(payload.laneId || payload.name || payload.lane || "");
}

function selectNamedLaneTarget(laneId, existingSelection, requestedTarget = {}, connectedExtensions = []) {
  const explicitTarget = Boolean(requestedTarget.projectId || requestedTarget.tabId || requestedTarget.profileHint || requestedTarget.cdpPortHint !== null);
  const concreteTargets = connectedExtensions.filter(isConcreteLaneTarget);
  if (requestedTarget.projectId && requestedTarget.tabId) {
    return singleLaneMatch(laneId, requestedTarget, connectedExtensions, {
      absentCode: "LANE_TARGET_NOT_CONNECTED",
      absentMessage: `Named lane ${laneId} could not bind because project ${requestedTarget.projectId} tab ${requestedTarget.tabId} is not connected. Open the Flow tab, then re-run autoflow lane use ${laneId} --project-id ${requestedTarget.projectId} --tab-id ${requestedTarget.tabId}.`
    });
  }
  if (requestedTarget.tabId) {
    return singleLaneMatch(laneId, requestedTarget, connectedExtensions, {
      absentCode: "LANE_TARGET_NOT_CONNECTED",
      absentMessage: `Named lane ${laneId} could not bind because tab ${requestedTarget.tabId} is not connected. Re-bind with autoflow lane use ${laneId} --project-id <projectId> --tab-id ${requestedTarget.tabId}.`
    });
  }
  if (requestedTarget.projectId) {
    const matches = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
    if (matches.length === 1) return matches[0];
    if (matches.length > 1) {
      throw brokerError(
        "LANE_TARGET_AMBIGUOUS",
        `Named lane ${laneId} matched multiple Flow tabs for project ${requestedTarget.projectId}. Re-bind with: autoflow lane use ${laneId} --project-id ${requestedTarget.projectId} --tab-id <tabId>.`,
        { laneId, projectId: requestedTarget.projectId, matches }
      );
    }
    throw brokerError(
      "LANE_TARGET_NOT_CONNECTED",
      `Named lane ${laneId} could not bind because project ${requestedTarget.projectId} is not open. Open the Flow project, then re-run autoflow lane use ${laneId} --project-id ${requestedTarget.projectId} --tab-id <tabId>.`,
      { laneId, projectId: requestedTarget.projectId, connectedExtensions }
    );
  }
  if (explicitTarget) {
    const matches = concreteTargets.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
    if (matches.length === 1) return matches[0];
    if (matches.length > 1) {
      throw brokerError(
        "LANE_TARGET_AMBIGUOUS",
        `Named lane ${laneId} matched multiple Flow tabs. Re-bind with: autoflow lane use ${laneId} --project-id <projectId> --tab-id <tabId>.`,
        { laneId, requestedTarget, matches }
      );
    }
    throw brokerError("LANE_TARGET_NOT_CONNECTED", `Named lane ${laneId} target is not connected.`, {
      laneId,
      requestedTarget,
      connectedExtensions
    });
  }
  if (existingSelection) {
    const exact = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, existingSelection));
    if (exact.length === 1) return exact[0];
    if (exact.length > 1) {
      throw brokerError("LANE_TARGET_AMBIGUOUS", `Named lane ${laneId} matched multiple connected Flow tabs. Re-bind with: autoflow lane use ${laneId} --project-id ${existingSelection.projectId || "<projectId>"} --tab-id <tabId>.`, {
        laneId,
        expected: existingSelection,
        matches: exact
      });
    }
    const projectMatches = existingSelection.projectId
      ? connectedExtensions.filter((target) => stringValue(target.projectId) === stringValue(existingSelection.projectId))
      : [];
    if (projectMatches.length === 1) return projectMatches[0];
    if (projectMatches.length > 1) {
      throw brokerError(
        "LANE_TARGET_AMBIGUOUS",
        `Named lane ${laneId} is bound to project ${existingSelection.projectId}, but multiple Flow tabs for that project are open. Re-bind with: autoflow lane use ${laneId} --project-id ${existingSelection.projectId} --tab-id <tabId>.`,
        { laneId, projectId: existingSelection.projectId, expected: existingSelection, matches: projectMatches }
      );
    }
    throw brokerError(
      "LANE_TARGET_GONE",
      `Named lane ${laneId} is bound to project ${existingSelection.projectId || "(unknown)"} tab ${existingSelection.tabId || "(unknown)"}, but that Flow tab is gone. Re-bind with: autoflow lane use ${laneId} --project-id ${existingSelection.projectId || "<projectId>"} --tab-id <tabId>.`,
      { laneId, expected: existingSelection, connectedExtensions }
    );
  }
  if (!concreteTargets.length) {
    throw brokerError("LANE_TARGET_NOT_CONNECTED", `Named lane ${laneId} could not auto-create because no concrete Flow project tab is connected. Open a Flow tab, then re-run autoflow lane use ${laneId}.`, {
      laneId,
      connectedExtensions
    });
  }
  const activeMatches = concreteTargets.filter((target) => target.active === true || target.isRuntimeTarget === true);
  if (activeMatches.length === 1) return activeMatches[0];
  if (concreteTargets.length === 1) return concreteTargets[0];
  throw brokerError(
    "LANE_TARGET_AMBIGUOUS",
    `Named lane ${laneId} needs an exact Flow tab. Run autoflow targets --json, then bind with: autoflow lane use ${laneId} --project-id <projectId> --tab-id <tabId>.`,
    { laneId, connectedExtensions }
  );
}

function singleLaneMatch(laneId, requestedTarget = {}, connectedExtensions = [], options = {}) {
  const matches = connectedExtensions.filter((target) => targetMatchesRequestedTarget(target, requestedTarget));
  if (matches.length === 1) return matches[0];
  if (matches.length > 1) {
    throw brokerError("LANE_TARGET_AMBIGUOUS", `Named lane ${laneId} matched multiple Flow tabs. Re-bind with: autoflow lane use ${laneId} --project-id ${requestedTarget.projectId || "<projectId>"} --tab-id <tabId>.`, {
      laneId,
      requestedTarget,
      matches
    });
  }
  throw brokerError(options.absentCode || "LANE_TARGET_NOT_CONNECTED", options.absentMessage || `Named lane ${laneId} target is not connected.`, {
    laneId,
    requestedTarget,
    connectedExtensions
  });
}

function isConcreteLaneTarget(target = {}) {
  return Boolean(!target.error && stringValue(target.projectId) && stringValue(target.tabId));
}

function sameLaneTarget(a = {}, b = {}) {
  const aProjectId = stringValue(a.projectId);
  const bProjectId = stringValue(b.projectId);
  const aTabId = stringValue(a.tabId);
  const bTabId = stringValue(b.tabId);
  return Boolean(aProjectId && bProjectId && aTabId && bTabId && aProjectId === bProjectId && aTabId === bTabId);
}

function laneSummary(selection = {}, connectedExtensions = []) {
  const normalized = normalizeLaneSelection(selection);
  const exact = connectedExtensions.find((target) => targetMatchesRequestedTarget(target, normalized)) || null;
  const projectMatches = normalized.projectId
    ? connectedExtensions.filter((target) => stringValue(target.projectId) === normalized.projectId)
    : [];
  const rebindTarget = exact ? null : (projectMatches.length === 1 ? projectMatches[0] : null);
  return {
    name: normalized.laneId,
    laneId: normalized.laneId,
    projectId: normalized.projectId,
    tabId: normalized.tabId,
    connected: Boolean(exact),
    rebindAvailable: Boolean(rebindTarget),
    ambiguous: !exact && projectMatches.length > 1,
    lastUsed: normalized.lastUsedAt || normalized.selectedAt || "",
    lastUsedAt: normalized.lastUsedAt || "",
    selectedAt: normalized.selectedAt || "",
    pageTitle: normalized.pageTitle,
    pageUrl: normalized.pageUrl,
    target: exact || rebindTarget || null,
    selection: normalized,
    rebindCommand: normalized.projectId
      ? `autoflow lane use ${normalized.laneId} --project-id ${normalized.projectId} --tab-id <tabId>`
      : `autoflow lane use ${normalized.laneId} --project-id <projectId> --tab-id <tabId>`
  };
}

function collapseTransportHandoverTargets(targets = []) {
  const source = Array.isArray(targets) ? targets : [];
  const groups = new Map();
  for (const target of source) {
    const projectId = stringValue(target?.projectId);
    const tabId = stringValue(target?.tabId);
    if (!projectId || !tabId) continue;
    const key = [stringValue(target?.extensionId), projectId, tabId, stringValue(target?.pageUrl)].join("|");
    const group = groups.get(key) || [];
    group.push(target);
    groups.set(key, group);
  }
  const collapsedKeys = new Set();
  const replacementByKey = new Map();
  for (const [key, group] of groups) {
    if (group.length !== 2) continue;
    const ws = group.filter((target) => target.transport === "ws_broker");
    const legacy = group.filter((target) => target.transport === "native_messaging_legacy");
    if (ws.length !== 1 || legacy.length !== 1) continue;
    if (stringValue(ws[0].extensionVersion) !== stringValue(legacy[0].extensionVersion)) continue;
    // Same extension + tab on both transports is one Chrome profile, not two.
    // Two profiles cannot share a tabId, so do not require a 30s handover window.
    collapsedKeys.add(key);
    replacementByKey.set(key, {
      ...ws[0],
      transportHandover: true,
      fallbackTransports: ["native_messaging_legacy"],
      supersededExtensionKeys: [legacy[0].extensionKey]
    });
  }
  const emitted = new Set();
  const output = [];
  for (const target of source) {
    const projectId = stringValue(target?.projectId);
    const tabId = stringValue(target?.tabId);
    const key = [stringValue(target?.extensionId), projectId, tabId, stringValue(target?.pageUrl)].join("|");
    if (!collapsedKeys.has(key)) {
      output.push(target);
      continue;
    }
    if (emitted.has(key)) continue;
    emitted.add(key);
    output.push(replacementByKey.get(key));
  }
  return output;
}

function targetMatchesRequestedTarget(target = {}, requested = {}) {
  const expectedProjectId = stringValue(requested.projectId);
  const expectedTabId = stringValue(requested.tabId);
  const expectedProfileHint = stringValue(requested.profileHint);
  const expectedCdpPortHint = normalizeNullableNumber(requested.cdpPortHint || requested.port);
  if (expectedProjectId && stringValue(target.projectId) !== expectedProjectId) return false;
  if (expectedTabId && stringValue(target.tabId) !== expectedTabId) return false;
  if (expectedProfileHint && stringValue(target.profileHint) !== expectedProfileHint) return false;
  if (expectedCdpPortHint !== null && normalizeNullableNumber(target.cdpPortHint) !== expectedCdpPortHint) return false;
  return Boolean(expectedProjectId || expectedTabId || expectedProfileHint || expectedCdpPortHint !== null);
}

function isStaleExtensionTarget(target = {}, requested = {}) {
  const version = stringValue(target.extensionVersion);
  if (version && requested?.expectedExtensionVersion && version !== stringValue(requested.expectedExtensionVersion)) return true;
  if (requested.projectId && target.projectId && target.projectId !== requested.projectId) return true;
  if (requested.tabId && target.tabId && stringValue(target.tabId) !== stringValue(requested.tabId)) return true;
  return false;
}

function isSelectedTarget(target = {}, laneSelections = new Map()) {
  for (const selection of laneSelections.values()) {
    if (target.extensionKey && target.extensionKey === selection.extensionKey) return true;
    if (targetMatchesRequestedTarget(target, selection)) return true;
  }
  return false;
}

function normalizeBridgeRoutingError(error = {}) {
  return {
    code: error?.code || "BRIDGE_TARGET_ROUTING_FAILED",
    message: error?.message || String(error || "bridge target routing failed"),
    ...(error?.details !== undefined ? { details: error.details } : {})
  };
}

function isBrokerExtensionRegisterMessage(message = {}) {
  return stringValue(message?.type) === "broker.extension.register";
}

function normalizeNullableNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
}

function packageVersionFromNearestPackageJson() {
  return nearestPackageInfo().version;
}

function nearestPackageInfo() {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [
    path.join(here, "../package.json"),
    path.join(here, "../../package.json"),
    path.join(process.cwd(), "package.json")
  ];
  for (const candidate of candidates) {
    try {
      const parsed = JSON.parse(fs.readFileSync(candidate, "utf8"));
      if (parsed?.version) {
        return {
          packageJsonPath: candidate,
          packageRoot: path.dirname(candidate),
          version: String(parsed.version)
        };
      }
    } catch {}
  }
  return {
    packageJsonPath: "",
    packageRoot: "",
    version: ""
  };
}

function normalizeNativeRuntime(value = {}, fallback = {}) {
  const source = isPlainObject(value) ? value : {};
  const packageVersion = stringValue(source.packageVersion || fallback.packageVersion);
  const nativeHostVersion = stringValue(source.nativeHostVersion || fallback.nativeHostVersion);
  return {
    pid: Number.isFinite(Number(source.pid)) ? Number(source.pid) : process.pid,
    startedAt: stringValue(source.startedAt || NATIVE_HOST_STARTED_AT),
    nodePath: stringValue(source.nodePath || process.execPath),
    hostScriptPath: stringValue(source.hostScriptPath || path.resolve(process.argv[1] || "")),
    brokerModulePath: stringValue(source.brokerModulePath || fileURLToPath(import.meta.url)),
    packageRoot: stringValue(source.packageRoot || nearestPackageInfo().packageRoot),
    packageVersion,
    nativeHostVersion,
    bridgeProtocolVersion: Number(source.bridgeProtocolVersion || fallback.bridgeProtocolVersion || AGENT_BRIDGE_VERSION)
  };
}

function normalizeInstalledIdentity(value = {}) {
  if (!isPlainObject(value)) return {};
  return {
    installedAt: stringValue(value.installedAt),
    extensionId: stringValue(value.extensionId),
    packageVersion: stringValue(value.packageVersion),
    nativeHostVersion: stringValue(value.nativeHostVersion),
    bridgeProtocolVersion: Number(value.bridgeProtocolVersion || 0) || null,
    nodePath: stringValue(value.nodePath),
    launcherPath: stringValue(value.launcherPath),
    hostScriptPath: stringValue(value.hostScriptPath),
    manifestPath: stringValue(value.manifestPath),
    packageRoot: stringValue(value.packageRoot),
    launcherSha256: stringValue(value.launcherSha256),
    hostScriptSha256: stringValue(value.hostScriptSha256),
    brokerSha256: stringValue(value.brokerSha256)
  };
}

function installedNativeHostIdentity(options = {}) {
  const env = options.env || process.env;
  const receiptPath = env.AUTOFLOW_NATIVE_INSTALL_RECEIPT
    || path.join(os.homedir(), "Library", "Application Support", "Auto Flow", "native-host-install.json");
  try {
    return normalizeInstalledIdentity(JSON.parse(fs.readFileSync(receiptPath, "utf8")));
  } catch {
    return {};
  }
}

function normalizeComparableHostPath(value) {
  return stringValue(value)
    .replace(/\\/g, "/")
    .replace(/\/+/g, "/")
    .replace(/\/$/u, "")
    .toLowerCase();
}

function comparablePathBasename(value) {
  const normalized = normalizeComparableHostPath(value);
  const index = normalized.lastIndexOf("/");
  return index >= 0 ? normalized.slice(index + 1) : normalized;
}

function comparablePathDirname(value) {
  const normalized = normalizeComparableHostPath(value);
  const index = normalized.lastIndexOf("/");
  return index >= 0 ? normalized.slice(0, index) : "";
}

function hostScriptPathsMatch(runtimeHostScriptPath, installedHostScriptPath, installed = {}) {
  if (path.resolve(installedHostScriptPath) === path.resolve(runtimeHostScriptPath)) return true;
  const runtime = normalizeComparableHostPath(runtimeHostScriptPath);
  const installedCandidates = [
    normalizeComparableHostPath(installedHostScriptPath),
    normalizeComparableHostPath(installed.launcherPath)
  ].filter(Boolean);
  if (!runtime || comparablePathBasename(runtime) !== "auto-flow-native-host.mjs") return false;
  const runtimeDir = comparablePathDirname(runtime);
  return installedCandidates.some((candidate) => comparablePathBasename(candidate) === "auto-flow-native-host.exe"
    && comparablePathDirname(candidate) === runtimeDir);
}

function staleNativeHostBlockers(runtime = {}, installed = {}) {
  if (!isPlainObject(installed) || (!installed.packageVersion && !installed.hostScriptPath && !installed.nativeHostVersion)) return [];
  const mismatches = [];
  if (!runtime?.packageVersion || !runtime?.nativeHostVersion) {
    mismatches.push("running native host did not report package/native versions");
  }
  if (installed.packageVersion && runtime.packageVersion && installed.packageVersion !== runtime.packageVersion) {
    mismatches.push(`running package ${runtime.packageVersion} does not match installed package ${installed.packageVersion}`);
  }
  if (installed.nativeHostVersion && runtime.nativeHostVersion && installed.nativeHostVersion !== runtime.nativeHostVersion) {
    mismatches.push(`running native host ${runtime.nativeHostVersion} does not match installed native host ${installed.nativeHostVersion}`);
  }
  if (installed.hostScriptPath && runtime.hostScriptPath && !hostScriptPathsMatch(runtime.hostScriptPath, installed.hostScriptPath, installed)) {
    mismatches.push("running host script path does not match installed host script path");
  }
  if (!mismatches.length) return [];
  return [{
    code: "STALE_NATIVE_HOST_PROCESS",
    message: "Chrome is still connected to an older Auto Flow native host.",
    recovery: [
      "Click Retry Native Host",
      "If restart fails, fully quit only the selected Chrome testing profile and reopen it"
    ],
    details: {
      mismatches,
      running: runtime,
      installed
    }
  }];
}

function mergeBlockers(...groups) {
  const blockers = [];
  for (const group of groups) {
    if (Array.isArray(group)) blockers.push(...group.filter(isPlainObject));
  }
  const seen = new Set();
  return blockers.filter((blocker) => {
    const key = `${blocker.code || ""}:${blocker.message || ""}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function buildTransportDiagnostics({
  bridgeState = "unknown",
  activeTransport = "",
  extensionConnected = false,
  paired = false,
  wsAvailable = false,
  wsUrl = "",
  browserWsUrl = "",
  httpUrl = "",
  browserOriginsConfigured = false,
  browserClientCount = 0,
  nativeConnected = false,
  blockers = []
} = {}) {
  const staleNative = Array.isArray(blockers)
    && blockers.some((blocker) => stringValue(blocker?.code).toUpperCase() === "STALE_NATIVE_HOST_PROCESS");
  const wsState = !wsAvailable
    ? "unavailable"
    : (!extensionConnected ? "extension_disconnected" : (paired ? "connected" : "pairing_required"));
  const browserState = !wsAvailable
    ? "unavailable"
    : (!browserOriginsConfigured
      ? "origins_not_configured"
      : (!extensionConnected ? "extension_disconnected" : (paired ? "ready" : "pairing_required")));
  return {
    ws_broker: {
      enabled: wsAvailable,
      state: activeTransport === "ws_broker" ? bridgeState : wsState,
      connected: activeTransport === "ws_broker" && extensionConnected,
      brokenLink: wsAvailable
        ? (!extensionConnected ? "ws_broker.extension_socket" : (!paired ? "ws_broker.pairing_required" : ""))
        : "ws_broker.package_daemon",
      code: wsAvailable
        ? (!extensionConnected ? "WS_EXTENSION_DISCONNECTED" : (!paired ? "PAIRING_APPROVAL_REQUIRED" : ""))
        : "WS_BROKER_UNAVAILABLE",
      nextAction: wsAvailable
        ? (!extensionConnected ? "Open Chrome with AutoFlow installed, then open the sidepanel." : (!paired ? "Run autoflow pair and click Pair Bridge." : ""))
        : "Run autoflow bridge up, then retry autoflow status.",
      wsUrl,
      browserWsUrl,
      httpUrl
    },
    browser_client: {
      enabled: wsAvailable && browserOriginsConfigured,
      state: browserState,
      connected: browserClientCount > 0,
      clientCount: browserClientCount,
      brokenLink: !wsAvailable
        ? "browser_client.package_daemon"
        : (!browserOriginsConfigured
          ? "browser_client.origins_not_configured"
          : (!extensionConnected ? "browser_client.extension_socket" : (!paired ? "browser_client.pairing_required" : ""))),
      code: !wsAvailable
        ? "WS_BROKER_UNAVAILABLE"
        : (!browserOriginsConfigured
          ? "BROWSER_ORIGINS_NOT_CONFIGURED"
          : (!extensionConnected ? "WS_EXTENSION_DISCONNECTED" : (!paired ? "PAIRING_APPROVAL_REQUIRED" : ""))),
      nextAction: !wsAvailable
        ? "Run autoflow bridge up, then retry."
        : (!browserOriginsConfigured
          ? "Set AUTOFLOW_BROWSER_ORIGINS to a comma-separated origin allowlist (for example http://127.0.0.1:5173)."
          : (!extensionConnected
            ? "Open Chrome with AutoFlow installed and ensure the WS broker extension is connected."
            : (!paired ? "Pair the browser client with Auto Flow before sending bridge commands." : ""))),
      browserWsUrl,
      httpUrl
    },
    cdp_bridge: {
      enabled: false,
      state: "dev_discovery_only",
      connected: false,
      brokenLink: "cdp_bridge.discovery_only",
      code: "CDP_DISCOVERY_ONLY",
      nextAction: "Ignore for normal onboarding; use ws_broker. CDP is only for dev lane discovery and E2E proof."
    },
    native_messaging_legacy: {
      enabled: nativeConnected || staleNative,
      state: staleNative ? "stale_native_host" : (nativeConnected ? bridgeState : "disabled"),
      connected: nativeConnected,
      brokenLink: nativeConnected ? "" : "native_messaging_legacy.disabled",
      code: staleNative ? "STALE_NATIVE_HOST_PROCESS" : (nativeConnected ? "" : "NATIVE_MESSAGING_LEGACY_DISABLED"),
      nextAction: nativeConnected
        ? ""
        : "No action needed unless legacy native messaging was explicitly enabled."
    }
  };
}

function browserMediaContentType(filePath = "") {
  const extension = path.extname(String(filePath || "")).toLowerCase();
  if (extension === ".jpg" || extension === ".jpeg") return "image/jpeg";
  if (extension === ".png") return "image/png";
  if (extension === ".webp") return "image/webp";
  if (extension === ".mp4") return "video/mp4";
  if (extension === ".webm") return "video/webm";
  return "application/octet-stream";
}

function browserCorsHeaders(origin = "") {
  const value = stringValue(origin);
  if (!value) return {};
  return {
    "access-control-allow-origin": value,
    "access-control-allow-methods": "GET, OPTIONS",
    "access-control-allow-headers": "content-type",
    vary: "Origin"
  };
}

function writeJsonResponse(response, statusCode, payload, extraHeaders = {}) {
  const body = statusCode === 204 ? Buffer.alloc(0) : Buffer.from(JSON.stringify(payload), "utf8");
  response.writeHead(statusCode, {
    "content-type": "application/json",
    "content-length": String(body.length),
    "cache-control": "no-store",
    ...extraHeaders
  });
  response.end(body);
}

function rejectWsUpgrade(socket, statusCode = 403, reason = "Forbidden") {
  try {
    socket.write([
      `HTTP/1.1 ${statusCode} ${reason}`,
      "Connection: close",
      "\r\n"
    ].join("\r\n"));
  } catch {}
  try {
    socket.destroy();
  } catch {}
}

function isLoopbackRemoteAddress(address = "") {
  const value = stringValue(address);
  return value === "127.0.0.1" || value === "::1" || value === "::ffff:127.0.0.1";
}

function isAllowedWsOrigin(origin, allowMissingOrigin = false) {
  const value = stringValue(origin);
  if (!value) return allowMissingOrigin === true;
  return value.startsWith("chrome-extension://");
}

function extensionIdFromWsOrigin(origin) {
  const value = stringValue(origin);
  const match = value.match(/^chrome-extension:\/\/([a-z]{32})(?:\/)?$/i);
  return match ? match[1] : "";
}

function hashRegistrationSecret(secret) {
  const value = stringValue(secret);
  if (!value) return "";
  return crypto.createHash("sha256").update(value, "utf8").digest("hex");
}

function constantTimeEquals(candidate, expected) {
  const candidateBuffer = Buffer.from(stringValue(candidate), "utf8");
  const expectedBuffer = Buffer.from(stringValue(expected), "utf8");
  if (candidateBuffer.length !== expectedBuffer.length) return false;
  return crypto.timingSafeEqual(candidateBuffer, expectedBuffer);
}

function wsSendText(socket, text = "") {
  const payload = Buffer.from(String(text), "utf8");
  let header;
  if (payload.length < 126) {
    header = Buffer.from([0x81, payload.length]);
  } else if (payload.length <= 0xffff) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(payload.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(payload.length), 2);
  }
  socket.write(Buffer.concat([header, payload]));
}

function wsCloseFrame() {
  return Buffer.from([0x88, 0x00]);
}

function decodeWsTextFrames(buffer, fragmentedTextFrame = null) {
  const messages = [];
  let offset = 0;
  let fragments = fragmentedTextFrame ? [...fragmentedTextFrame] : null;
  while (offset + 2 <= buffer.length) {
    const first = buffer[offset];
    const second = buffer[offset + 1];
    const fin = (first & 0x80) === 0x80;
    const opcode = first & 0x0f;
    const masked = (second & 0x80) === 0x80;
    let length = second & 0x7f;
    let headerLength = 2;
    if (length === 126) {
      if (offset + 4 > buffer.length) break;
      length = buffer.readUInt16BE(offset + 2);
      headerLength = 4;
    } else if (length === 127) {
      if (offset + 10 > buffer.length) break;
      const bigLength = buffer.readBigUInt64BE(offset + 2);
      if (bigLength > BigInt(MAX_WS_FRAME_BUFFER_BYTES)) throw brokerError("WS_FRAME_TOO_LARGE", "Auto Flow WS frame is too large.");
      length = Number(bigLength);
      headerLength = 10;
    }
    if (length > MAX_WS_FRAME_BUFFER_BYTES) throw brokerError("WS_FRAME_TOO_LARGE", "Auto Flow WS frame is too large.");
    const maskLength = masked ? 4 : 0;
    const frameEnd = offset + headerLength + maskLength + length;
    if (frameEnd > buffer.length) break;
    const mask = masked ? buffer.subarray(offset + headerLength, offset + headerLength + 4) : null;
    const payloadStart = offset + headerLength + maskLength;
    const payload = Buffer.from(buffer.subarray(payloadStart, payloadStart + length));
    if (masked) {
      for (let index = 0; index < payload.length; index += 1) payload[index] ^= mask[index % 4];
    }
    if ((opcode === 0x8 || opcode === 0x9 || opcode === 0xA) && !fin) {
      throw brokerError("WS_CONTROL_FRAME_FRAGMENTED", "Auto Flow WS control frames must not be fragmented.");
    }
    if (opcode === 0x8) {
      return { messages, remaining: Buffer.alloc(0), closed: true };
    }
    if (opcode === 0x9) {
      // Ping frames are ignored; extension also sends JSON heartbeats.
    } else if (opcode === 0x1) {
      if (fragments) {
        throw brokerError("WS_FRAME_UNSUPPORTED", "Auto Flow WS received a new text frame before the prior fragmented frame completed.");
      }
      if (fin) messages.push(payload.toString("utf8"));
      else {
        fragments = [payload];
        if (totalBufferLength(fragments) > MAX_WS_FRAME_BUFFER_BYTES) {
          throw brokerError("WS_FRAME_TOO_LARGE", "Auto Flow WS fragmented message is too large.");
        }
      }
    } else if (opcode === 0x0) {
      if (!fragments) {
        throw brokerError("WS_CONTINUATION_UNEXPECTED", "Auto Flow WS received a continuation frame without an open text frame.");
      }
      fragments.push(payload);
      if (totalBufferLength(fragments) > MAX_WS_FRAME_BUFFER_BYTES) {
        throw brokerError("WS_FRAME_TOO_LARGE", "Auto Flow WS fragmented message is too large.");
      }
      if (fin) {
        messages.push(Buffer.concat(fragments).toString("utf8"));
        fragments = null;
      }
    } else if (opcode !== 0xA) {
      throw brokerError("WS_FRAME_UNSUPPORTED", `Unsupported Auto Flow WS opcode: ${opcode}`);
    }
    offset = frameEnd;
  }
  return {
    messages,
    remaining: buffer.subarray(offset),
    fragmentedTextFrame: fragments
  };
}

function debugLog(event, details = {}) {
  if (!DEBUG_LOG_PATH) return;
  const line = JSON.stringify({
    at: new Date().toISOString(),
    event,
    ...details
  });
  import("node:fs/promises")
    .then(({ appendFile }) => appendFile(DEBUG_LOG_PATH, `${line}\n`).catch(() => {}))
    .catch(() => {});
}

async function prepareSocketPath(socketPath) {
  if (isWindowsNamedPipePath(socketPath)) return;
  const dir = path.dirname(socketPath);
  await mkdir(dir, { recursive: true, mode: 0o700 });
  await chmod(dir, 0o700).catch(() => {});

  if (!fs.existsSync(socketPath)) return;
  const current = await stat(socketPath).catch(() => null);
  if (!current) return;
  if (!current.isSocket()) {
    throw brokerError("NATIVE_BROKER_SOCKET_PATH_CONFLICT", `broker socket path exists and is not a socket: ${socketPath}`);
  }
  const active = await canConnect(socketPath);
  if (active) {
    throw brokerError("NATIVE_BROKER_ALREADY_RUNNING", `Auto Flow native broker is already running at ${socketPath}`);
  }
  await unlink(socketPath).catch(() => {});
}

async function readLockFile(lockPath) {
  try {
    const parsed = JSON.parse(await readFile(lockPath, "utf8"));
    return isPlainObject(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function lockOwnerAlive(lock = {}) {
  const pid = Number(lock?.pid || 0);
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error?.code === "EPERM";
  }
}

async function currentSocketIdentity(socketPath) {
  if (!socketPath || isWindowsNamedPipePath(socketPath)) return null;
  const current = await stat(socketPath).catch(() => null);
  if (!current?.isSocket?.()) return null;
  return {
    dev: current.dev,
    ino: current.ino
  };
}

function sameSocketIdentity(left, right) {
  if (!left || !right) return false;
  return left.dev === right.dev && left.ino === right.ino;
}

function platformFromOptions(options = {}) {
  return options.platform || process.platform;
}

function windowsBrokerPipePath(options = {}) {
  const env = options.env || process.env;
  const rawUser = env.USERNAME || env.USER || os.userInfo?.().username || "user";
  const suffix = String(rawUser)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    || "user";
  return `\\\\.\\pipe\\${WINDOWS_PIPE_NAME}-${suffix}`;
}

function isWindowsNamedPipePath(socketPath = "") {
  return String(socketPath).startsWith("\\\\.\\pipe\\");
}

function canConnect(socketPath) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ path: socketPath });
    const timer = setTimeout(() => {
      socket.destroy();
      resolve(false);
    }, SOCKET_CONNECT_TIMEOUT_MS);
    socket.once("connect", () => {
      clearTimeout(timer);
      socket.destroy();
      resolve(true);
    });
    socket.once("error", () => {
      clearTimeout(timer);
      resolve(false);
    });
  });
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function brokerError(code, message, details) {
  const error = new Error(message);
  error.code = code;
  if (details !== undefined) error.details = details;
  return error;
}

function requestFailureDetails({ socketPath, timeoutMs, request = {}, writeStarted = false, connected = false, causeCode = "" } = {}) {
  return {
    socketPath,
    ...(timeoutMs ? { timeoutMs } : {}),
    requestId: stringValue(request?.id),
    requestType: stringValue(request?.type),
    writeStarted: writeStarted === true,
    connected: connected === true,
    healthState: writeStarted
      ? BROKER_HEALTH_STATES.AMBIGUOUS_WRITE
      : BROKER_HEALTH_STATES.BROKER_UNAVAILABLE,
    ...(causeCode ? { causeCode } : {})
  };
}

function extensionForwardTimeoutMs(request = {}, fallbackMs = DEFAULT_REQUEST_TIMEOUT_MS) {
  const fleetGenerateTransportGraceMs = 45000;
  const fleetGenerateTimeoutCapMs = 660000;
  const payloadTimeoutTypes = new Set([
    "downloads.execute",
    "flow.generate",
    "flow.state.get",
    "agent.refs.attach",
    "agent.prompt.submit",
    "agent.retry.submit",
    "agent.credits.confirm",
    "fleetgen.launch",
    "fleetgen.executeDirect",
    "fleet.generate",
    "fleet.state.get"
  ]);
  if (!payloadTimeoutTypes.has(request.type)) return fallbackMs;
  const requested = positiveInteger(
    request.payload?.timeoutMs || request.payload?.attachTimeoutMs,
    fallbackMs
  );
  if (request.type === "fleet.generate" || request.type === "flow.generate") {
    return Math.min(requested + fleetGenerateTransportGraceMs, fleetGenerateTimeoutCapMs);
  }
  return Math.min(requested, 600000);
}

function hasExactBrowserDownloadScope(payload = {}) {
  const transport = stringValue(payload.agentTransport || payload.agentSubmitPath).toLowerCase();
  const chromeSessionTarget = (transport === "api" || transport === "agent_api")
    && payload.chromeSessionAuth === true
    && stringValue(payload.laneId);
  return Boolean(
    stringValue(payload.projectId)
    && (stringValue(payload.tabId) || chromeSessionTarget)
    && Array.isArray(payload.rowIds)
    && payload.rowIds.some(stringValue)
    && Array.isArray(payload.mediaIds)
    && payload.mediaIds.some(stringValue)
  );
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function normalizeWsPortRange(value, fallback) {
  if (!Array.isArray(value)) return fallback;
  const ports = [...new Set(value
    .map((port) => Number.parseInt(port, 10))
    .filter((port) => Number.isInteger(port) && port > 0 && port <= 65535))];
  return ports.length ? ports : fallback;
}

function totalBufferLength(buffers) {
  return buffers.reduce((total, buffer) => total + buffer.length, 0);
}

function stringValue(value) {
  return String(value ?? "").trim();
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
